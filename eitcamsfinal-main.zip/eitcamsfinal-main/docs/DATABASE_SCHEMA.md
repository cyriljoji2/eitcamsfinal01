# Google Sheets Database Schema & Architecture Plan (Corrected Specification)
**Electrix Institute of Technology (EIT) — Academic & Administrative Management Gateway**
*Phase 2: Corrected Database Design & Vercel-Compatible Serverless Integration Plan*

---

## 1. Executive Summary & Google Sheets Integration Architecture

### Vercel-Compatible Serverless Architecture
All Google Sheets operations are routed through server-side serverless functions located in `/api/*` (e.g., `/api/sheets.ts`).
- **Zero Static Private Key Credentials**: Conforms strictly to Google Cloud organizational policy `iam.disableServiceAccountKeyCreation`. No downloaded service account JSON keys or RSA private keys are used.
- **Keyless Workload Identity Federation (WIF)**: Vercel OIDC generates short-lived JWT assertion tokens exchanged via Google Cloud Security Token Service (STS) and IAM Service Account Impersonation for scoped access tokens.
- **Environment Variable Contract**: Only non-sensitive descriptors are used (`GOOGLE_SERVICE_ACCOUNT_EMAIL`, `GOOGLE_SHEETS_SPREADSHEET_ID`, `GCP_PROJECT_ID`, `GCP_PROJECT_NUMBER`, `GCP_WORKLOAD_IDENTITY_POOL_ID`, `GCP_WORKLOAD_IDENTITY_PROVIDER_ID`).
- **Vercel Serverless Function Standard**: Handlers follow the standard `export default async function handler(req, res)` signature, ensuring deployment compatibility across Vercel, Node/Express, and Google Cloud Run.
- **Client Security Boundary**: The browser client sends only authenticated session tokens or API requests to `/api/*`; the server executes all Sheets API v4 operations.

```
+-------------------------------------------------------------------------+
|                              Browser Client                             |
|          (React 19 + TypeScript + Tailwind v4 + Lucide Icons)           |
|            - Preserved Portals: Student, Employee, Parent               |
+------------------------------------+------------------------------------+
                                     |
               HTTPS POST/GET (/api/auth, /api/sheets)
                                     |
+------------------------------------v------------------------------------+
|               Vercel Serverless API Functions (/api/*)                  |
|  - Authenticates users via AuthUsers (bcrypt/argon2 password hashes)    |
|  - Blocks self-registration of 6 Permanent Office accounts              |
|  - Resolves many-to-many parent-student links (ParentStudentLinks)      |
|  - Enforces separation: Faculty Courses vs Non-Teaching Office Roles    |
|  - Allocates atomic, collision-free registration numbers                |
+------------------------------------+------------------------------------+
                                     |
              Google STS & IAM WIF (Vercel OIDC Token Exchange)
                                     |
+------------------------------------v------------------------------------+
|               EIT Master Google Spreadsheet (15 Worksheets)             |
+-------------------------------------------------------------------------+
```

---

## 2. The Restored Six Permanent Institutional Offices

These six institutional offices are permanent system records. They are fixed, pre-seeded, and **cannot be duplicated, self-registered, or renamed**.

| Office Name | Canonical Username | Super Admin? | Office Code | Scope & Description |
| :--- | :--- | :--- | :--- | :--- |
| **Administration Office** | `admin` | **Yes (Super Admin)** | `ADM` | Central governance, staff assignments, institutional policies, and master system settings. |
| **Admissions Office** | `admissionsoffice` | No | `ADM-OFF` | Manages candidate intake, applicant verification, enrollment quotas, and student onboarding. |
| **Academic Office** | `academicoffice` | No | `ACA` | Coordinates curriculum governance, academic calendar, and faculty course assignments. |
| **COE Office** | `coeoffice` | No | `COE` | Autonomous Controller of Examinations. Oversees exam sessions, hall tickets, marks moderation, and transcripts. |
| **Finance Office** | `financeoffice` | No | `FIN` | Manages tuition fee schedules, student dues, payment reconciliations, and financial receipts. |
| **Hostel Office** | `hosteloffice` | No | `HOS` | Supervises residential halls, room/bed allocations, warden authorizations, and student housing. |

---

## 3. The 15 Worksheets Specification

### Worksheet 1: `PermanentOffices`
*Stores the six immutable permanent offices.*
- **Columns**:
  - `office_id` (PK, string, format `PO-001` to `PO-006`)
  - `office_key` (UK, enum: `ADMINISTRATION`, `ADMISSIONS`, `ACADEMIC`, `COE`, `FINANCE`, `HOSTEL`)
  - `office_name` (string, e.g., `"Administration Office"`)
  - `canonical_username` (UK, string: `admin`, `admissionsoffice`, `academicoffice`, `coeoffice`, `financeoffice`, `hosteloffice`)
  - `office_code` (UK, string: `ADM`, `ADM-OFF`, `ACA`, `COE`, `FIN`, `HOS`)
  - `description` (string)
  - `is_super_admin` (boolean, `TRUE` for `admin`)
  - `is_system_reserved` (boolean, always `TRUE`)
  - `allow_self_registration` (boolean, always `FALSE`)
  - `primary_contact_email` (string)
  - `created_at` (ISO 8601 UTC)
  - `status` (enum: `ACTIVE`, `ARCHIVED`)

---

### Worksheet 2: `AuthUsers`
*Stores account identities, username uniqueness, secure password hashes, linked records, roles, and security metadata. Passwords are NEVER stored in plaintext.*
- **Columns**:
  - `user_id` (PK, string, format `USR-{YYYY}-{SEQ}` or UUID)
  - `username` (UK, lowercase unique string, e.g., `admin`, `admissionsoffice`, `EIT-STU-2026-CSE-0042`)
  - `password_hash` (string, salted bcrypt `$2b$12$...` or argon2 hash — NEVER plaintext)
  - `password_salt` (string, optional cryptographic salt)
  - `portal_type` (enum: `student`, `employee`, `parent`)
  - `role` (enum: `SUPER_ADMIN`, `OFFICE_ADMIN`, `FACULTY`, `NON_TEACHING_STAFF`, `STUDENT`, `PARENT`)
  - `linked_record_type` (enum: `PERMANENT_OFFICE`, `EMPLOYEE`, `STUDENT`, `PARENT`)
  - `linked_record_id` (FK to `PermanentOffices.office_id`, `Employees.employee_id`, `Students.student_id`, or `Parents.parent_id`)
  - `account_status` (enum: `ACTIVE`, `LOCKED`, `SUSPENDED`, `PASSWORD_RESET_REQUIRED`)
  - `failed_login_attempts` (integer, reset on success; account locks at $\ge 5$ failed attempts)
  - `lockout_until` (ISO timestamp or empty)
  - `last_login_at` (ISO timestamp)
  - `password_updated_at` (ISO timestamp)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 3: `Employees`
*Staff master directory distinguishing Teaching (faculty) from Non-Teaching personnel.*
- **Columns**:
  - `employee_id` (PK, string, format `EMP-{YYYY}-{SEQ}`)
  - `registration_number` (UK, string: `EIT-TCH-{DEPT}-{YYYY}-{SEQ}` or `EIT-NTC-{DEPT}-{YYYY}-{SEQ}`)
  - `category` (enum: `TEACHING`, `NON_TEACHING`)
  - `first_name` (string)
  - `last_name` (string)
  - `institutional_email` (UK, string, e.g., `initial.lastname@eit.edu`)
  - `phone_number` (string, E.164)
  - `primary_department` (string, e.g., `CSE`, `ECE`, `ADM`, `FIN`)
  - `designation` (string, e.g., `Associate Professor`, `Junior Accountant`)
  - `employment_status` (enum: `ACTIVE`, `ON_LEAVE`, `PROBATION`, `RESIGNED`, `RETIRED`, `TERMINATED`)
  - `date_of_joining` (ISO date `YYYY-MM-DD`)
  - `reporting_manager_id` (FK to `Employees.employee_id`, optional)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 4: `FacultyCourseAssignments`
*Separated teaching faculty course allocations. Teaching faculty are never placed in non-teaching office assignments.*
- **Columns**:
  - `faculty_assignment_id` (PK, string, format `FCA-{YYYY}-{SEQ}`)
  - `employee_id` (FK to `Employees.employee_id`, strictly validated `category === TEACHING`)
  - `course_code` (string, e.g., `CS201`)
  - `course_title` (string, e.g., `Data Structures & Algorithms`)
  - `department` (string, e.g., `CSE`)
  - `semester` (integer `1`-`8`)
  - `academic_year` (string, e.g., `2026-2027`)
  - `section` (string, e.g., `A`)
  - `role_in_course` (enum: `PRIMARY_INSTRUCTOR`, `CO_INSTRUCTOR`, `LAB_FACULTY`, `TEACHING_ASSISTANT`)
  - `assignment_status` (enum: `ACTIVE`, `COMPLETED`, `CANCELLED`)
  - `assigned_by_office_id` (FK to `PermanentOffices.office_id`, must be `PO-003` `ACADEMIC`)
  - `effective_from` (ISO date `YYYY-MM-DD`)
  - `effective_to` (ISO date `YYYY-MM-DD`, optional)
  - `created_at` (ISO timestamp)

---

### Worksheet 5: `OfficeAssignments`
*Administration assigns Non-Teaching staff to one or more of the 6 permanent offices.*
- **Columns**:
  - `assignment_id` (PK, string, format `OAS-{YYYY}-{SEQ}`)
  - `employee_id` (FK to `Employees.employee_id`, strictly validated `category === NON_TEACHING`)
  - `office_id` (FK to `PermanentOffices.office_id`)
  - `assigned_role_title` (string, e.g., `Junior Accountant`, `Hostel Warden`, `Assistant Registrar`)
  - `assignment_status` (enum: `ACTIVE`, `REVOKED`, `EXPIRED`, `TRANSFERRED`)
  - `assigned_by_employee_id` (FK to `Employees.employee_id`, must hold `ADMINISTRATION` office authority)
  - `effective_from` (ISO date `YYYY-MM-DD`)
  - `effective_to` (ISO date `YYYY-MM-DD`, optional)
  - `created_at` (ISO timestamp)

---

### Worksheet 6: `OfficePermissions`
*Granular module permissions managed exclusively by the respective authorized office.*
- **Columns**:
  - `permission_id` (PK, string, format `OPM-{YYYY}-{SEQ}`)
  - `assignment_id` (FK to `OfficeAssignments.assignment_id`)
  - `office_id` (FK to `PermanentOffices.office_id`)
  - `employee_id` (FK to `Employees.employee_id`)
  - `module_name` (string, e.g., `FeeCollections`, `MarksEntry`, `RoomAllocation`, `AdmissionsIntake`)
  - `permission_scope` (enum: `READ`, `WRITE`, `APPROVE`, `AUDIT`, `ADMIN`)
  - `granted_by_employee_id` (FK to `Employees.employee_id`, must hold `ADMIN` scope in that office)
  - `granted_at` (ISO timestamp)
  - `expires_at` (ISO timestamp, optional)
  - `status` (enum: `ACTIVE`, `REVOKED`)

---

### Worksheet 7: `Students`
*Student master records with unique automatic registration numbers.*
- **Columns**:
  - `student_id` (PK, string, format `STU-{YYYY}-{SEQ}` or UUID)
  - `registration_number` (UK, string: `EIT-STU-{YYYY}-{PROG}-{SEQ}`)
  - `first_name` (string)
  - `last_name` (string)
  - `date_of_birth` (ISO date `YYYY-MM-DD`)
  - `gender` (enum: `MALE`, `FEMALE`, `OTHER`)
  - `institutional_email` (UK, string `@student.eit.edu`)
  - `personal_phone` (string, E.164)
  - `program_name` (string, e.g., `B.Tech Computer Science & Engineering`)
  - `department` (string, e.g., `CSE`)
  - `admission_year` (integer, e.g., `2026`)
  - `current_semester` (integer `1`-`8`)
  - `section` (string, e.g., `A`)
  - `enrollment_status` (enum: `ENROLLED`, `SUSPENDED`, `GRADUATED`, `WITHDRAWN`, `ON_LEAVE`)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 8: `Parents`
*Parent and guardian profiles.*
- **Columns**:
  - `parent_id` (PK, string, format `PAR-{YYYY}-{SEQ}`)
  - `first_name` (string)
  - `last_name` (string)
  - `email` (UK, string)
  - `primary_phone` (UK, string, E.164)
  - `alternate_phone` (string, optional)
  - `residential_address` (string)
  - `status` (enum: `ACTIVE`, `INACTIVE`)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 9: `ParentStudentLinks`
*Explicit many-to-many relationship supporting multiple parents per student and multiple students per parent.*
- **Columns**:
  - `link_id` (PK, string, format `PSL-{YYYY}-{SEQ}`)
  - `parent_id` (FK to `Parents.parent_id`)
  - `student_id` (FK to `Students.student_id`)
  - `student_registration_number` (FK to `Students.registration_number`)
  - `relationship` (enum: `FATHER`, `MOTHER`, `LEGAL_GUARDIAN`, `OTHER`)
  - `is_primary_contact` (boolean)
  - `can_view_grades` (boolean)
  - `can_view_attendance` (boolean)
  - `can_view_finance` (boolean)
  - `emergency_priority` (integer: `1`, `2`, `3`)
  - `status` (enum: `ACTIVE`, `REVOKED`)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 10: `AcademicRecords`
*Academic progression, coursework, credits, SGPA, and cumulative GPA.*
- **Columns**:
  - `record_id` (PK, string, format `ACR-{YYYY}-{SEQ}`)
  - `student_id` (FK to `Students.student_id`)
  - `registration_number` (FK to `Students.registration_number`)
  - `semester` (integer `1`-`8`)
  - `academic_year` (string, e.g., `2026-2027`)
  - `course_code` (string, e.g., `CS201`)
  - `course_title` (string)
  - `credits` (integer `1`-`6`)
  - `grade_point` (decimal `0.0`-`10.0`)
  - `letter_grade` (enum: `O`, `A+`, `A`, `B+`, `B`, `C`, `P`, `F`)
  - `sgpa` (decimal)
  - `cgpa` (decimal)
  - `academic_standing` (enum: `GOOD_STANDING`, `ACADEMIC_PROBATION`, `DEANS_LIST`, `HONORS`)
  - `published_by_office_id` (FK, must be `PO-004` `COE`)
  - `updated_at` (ISO timestamp)

---

### Worksheet 11: `Attendance`
*Daily and session-wise attendance logged by assigned teaching faculty.*
- **Columns**:
  - `attendance_id` (PK, string, format `ATT-{YYYY}-{SEQ}`)
  - `date` (ISO date `YYYY-MM-DD`)
  - `course_code` (string, e.g., `CS201`)
  - `session_slot` (string, e.g., `09:00-10:00 AM`)
  - `student_id` (FK to `Students.student_id`)
  - `registration_number` (FK to `Students.registration_number`)
  - `status` (enum: `PRESENT`, `ABSENT`, `EXCUSED`, `LATE`)
  - `recorded_by_employee_id` (FK to `Employees.employee_id`, must be assigned faculty)
  - `remarks` (string, optional)
  - `created_at` (ISO timestamp)

---

### Worksheet 12: `Examinations`
*Exam marks, evaluations, hall tickets, and moderation.*
- **Columns**:
  - `exam_id` (PK, string, format `EXM-{YYYY}-{SEQ}`)
  - `exam_session` (string, e.g., `MID_SEM_FALL_2026`)
  - `course_code` (string)
  - `student_id` (FK to `Students.student_id`)
  - `hall_ticket_number` (string)
  - `internal_marks` (number `0`-`40`)
  - `external_marks` (number `0`-`60`)
  - `total_marks` (number `0`-`100`)
  - `max_marks` (number, default `100`)
  - `exam_status` (enum: `SCHEDULED`, `APPEARED`, `ABSENT`, `MALPRACTICE`, `WITHHELD`, `DECLARED`)
  - `evaluated_by_employee_id` (FK to `Employees.employee_id`)
  - `moderated_by_office_id` (FK to `PermanentOffices.office_id`, `COE`)
  - `published_at` (ISO timestamp, optional)

---

### Worksheet 13: `Finance`
*Fee schedules, invoices, transactions, and settlement receipts.*
- **Columns**:
  - `invoice_id` (PK, string, format `INV-{YYYY}-{SEQ}`)
  - `student_id` (FK to `Students.student_id`)
  - `registration_number` (FK to `Students.registration_number`)
  - `fee_category` (enum: `TUITION`, `HOSTEL`, `EXAM`, `LIBRARY`, `LABORATORY`, `LATE_FEE`)
  - `academic_year` (string)
  - `semester` (integer `1`-`8`)
  - `amount_due` (decimal)
  - `amount_paid` (decimal)
  - `currency` (string, `USD` or `INR`)
  - `payment_status` (enum: `PENDING`, `PARTIAL`, `PAID`, `REFUNDED`, `OVERDUE`, `WAIVED`)
  - `transaction_reference` (string, optional)
  - `payment_method` (string, optional)
  - `payment_date` (ISO timestamp, optional)
  - `verified_by_employee_id` (FK to `Employees.employee_id`, Finance office staff)
  - `created_at` (ISO timestamp)
  - `updated_at` (ISO timestamp)

---

### Worksheet 14: `Hostel`
*Hostel building blocks, rooms, bed assignments, and warden approvals.*
- **Columns**:
  - `allocation_id` (PK, string, format `HST-{YYYY}-{SEQ}`)
  - `student_id` (FK to `Students.student_id`)
  - `registration_number` (FK to `Students.registration_number`)
  - `hostel_block_name` (string, e.g., `Block A - Aryabhata Hall`)
  - `room_number` (string, e.g., `304`)
  - `bed_identifier` (string, e.g., `A`, `B`)
  - `status` (enum: `REQUESTED`, `ALLOCATED`, `OCCUPIED`, `VACATED`, `SUSPENDED`)
  - `check_in_date` (ISO date `YYYY-MM-DD`)
  - `check_out_date` (ISO date `YYYY-MM-DD`, optional)
  - `allocated_by_employee_id` (FK to `Employees.employee_id`, Hostel staff)
  - `approved_by_office_id` (FK, must be `PO-006` `HOSTEL`)
  - `emergency_contact_phone` (string)
  - `created_at` (ISO timestamp)

---

### Worksheet 15: `AuditLogs`
*Immutable, append-only operational audit trail.*
- **Columns**:
  - `log_id` (PK, string, format `LOG-{YYYY}-{SEQ}`)
  - `timestamp` (ISO 8601 UTC)
  - `actor_id` (string: user_id, employee_id, or `SYSTEM`)
  - `actor_role` (enum: `SUPER_ADMIN`, `OFFICE_ADMIN`, `FACULTY`, `NON_TEACHING_STAFF`, `STUDENT`, `PARENT`, `SYSTEM`)
  - `action` (enum: `LOGIN_ATTEMPT`, `CREATE`, `UPDATE`, `DELETE`, `PERMISSION_GRANT`, `PERMISSION_REVOKE`, `OFFICE_ASSIGN`, `COURSE_ASSIGN`, `PAYMENT_RECEIPT`, `GRADE_SUBMIT`, `GRADE_APPROVE`)
  - `target_worksheet` (string)
  - `target_record_id` (string)
  - `description` (string)
  - `client_ip` (string, optional)
  - `user_agent` (string, optional)

---

## 4. Safe Server-Side Unique Registration Number Allocation

- **Students**:
  $$\text{Format: } \mathbf{EIT-STU-\{YEAR\}-\{PROGRAM\}-\{SEQ(4)\}}$$
  - *Example*: `EIT-STU-2026-CSE-0001`
  - *Algorithm*: Queries `Students` worksheet filtered by admission year and program code, extracts the maximum assigned sequence number, increments by 1, and verifies against `AuthUsers.username` prior to row insertion.
- **Teaching Employees**:
  $$\text{Format: } \mathbf{EIT-TCH-\{DEPT\}-\{YEAR\}-\{SEQ(3)\}}$$
  - *Example*: `EIT-TCH-CSE-2026-001`
- **Non-Teaching Employees**:
  $$\text{Format: } \mathbf{EIT-NTC-\{DEPT\}-\{YEAR\}-\{SEQ(3)\}}$$
  - *Example*: `EIT-NTC-ADM-2026-001`

Sequence allocation is performed server-side with duplicate check verification.

---

## 5. Summary of Schema Changes & Improvements

1. **Restored Canonical Permanent Offices**:
   - Replaced temporary names with exact specifications: Administration Office (`admin`, Super Admin), Admissions Office (`admissionsoffice`), Academic Office (`academicoffice`), COE Office (`coeoffice`), Finance Office (`financeoffice`), and Hostel Office (`hosteloffice`).
2. **Added `AuthUsers` Worksheet**:
   - Centralized authentication identities with salted password hashes (never plaintext).
   - Rate limiting, failed login counters, lockout timestamps, and role-based access control.
3. **Added `ParentStudentLinks` Worksheet**:
   - Replaced flat single-parent link with full many-to-many relationship supporting multiple parents per student and multiple students per parent with granular visibility permissions.
4. **Separated Teaching Faculty from Office Assignments**:
   - Created `FacultyCourseAssignments` for academic course delivery.
   - Dedicated `OfficeAssignments` strictly to non-teaching personnel assigned to permanent offices by Administration.
5. **Vercel-Compatible Keyless Serverless Integration**:
   - Created `/api/sheets.ts` and `/api/sheetsAuth.ts` serverless handlers utilizing Vercel OIDC and Google Workload Identity Federation (WIF) with zero private keys.
6. **Preserved UI & Three Portals**:
   - Zero changes to the working Phase 1 homepage, styling, navigation, or login views (Student, Employee, Parent).
