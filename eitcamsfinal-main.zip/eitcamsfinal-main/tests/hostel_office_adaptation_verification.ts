/**
 * EIT CAMS — Hostel Office University Adaptation Verification Test Suite
 * Validates Stages A through H against all reference requirements and university adaptations.
 */

import { hostelRepository } from '../src/services/hostelService';
import { hostelLeaveService } from '../src/services/hostelLeaveService';
import { admissionRepository } from '../src/services/admissionService';
import { studentPortalService } from '../src/services/studentPortalService';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';

let totalTests = 0;
let passedTests = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`✅ [Test ${totalTests}] PASS: ${testName}${detail ? ` (${detail})` : ''}`);
  } else {
    console.error(`❌ [Test ${totalTests}] FAIL: ${testName}${detail ? ` (${detail})` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

async function runTestSuite() {
  console.log('================================================================');
  console.log('Starting EIT CAMS Hostel Office University Adaptation Verification');
  console.log('================================================================\n');

  // ---------------------------------------------------------------------------
  // STAGE A: Permanent Office & Navigation Identity
  // ---------------------------------------------------------------------------
  console.log('--- STAGE A: Office Identity & Workspace Structure ---');
  const hostelOfficeRecord = SIX_PERMANENT_OFFICES.find((o) => o.canonical_username === 'hosteloffice');
  assert(
    !!hostelOfficeRecord && hostelOfficeRecord.office_id === 'PO-006',
    'Canonical PO-006 Hostel Office account is registered',
    `Office ID: ${hostelOfficeRecord?.office_id}, Name: ${hostelOfficeRecord?.office_name}`
  );
  assert(
    hostelOfficeRecord?.office_key === 'HOSTEL',
    'Hostel office key is permanently mapped to HOSTEL',
    hostelOfficeRecord?.office_key
  );

  // Verification of single header & outer chrome suppression
  const fs = await import('fs');
  const appTsxContent = fs.readFileSync('src/App.tsx', 'utf-8');
  assert(
    appTsxContent.includes('isHostelOfficeActive') && appTsxContent.includes('suppressOuterChrome'),
    'App.tsx suppresses outer AppShell header and footer for Hostel Office'
  );

  const employeeDashboardContent = fs.readFileSync('src/views/EmployeeDashboardView.tsx', 'utf-8');
  assert(
    employeeDashboardContent.includes('const isHostelOffice =') &&
    employeeDashboardContent.includes('if (isHostelOffice) {\n    return <HostelOfficeSection onRefreshData={loadAllData} />;'),
    'EmployeeDashboardView applies early return suppression for Hostel Office, avoiding duplicate outer banner'
  );

  const hostelWorkspaceContent = fs.readFileSync('src/components/hostel/HostelWorkspace.tsx', 'utf-8');
  assert(
    hostelWorkspaceContent.includes('<HostelHeader') &&
    !hostelWorkspaceContent.includes('<Header'),
    'HostelWorkspace contains exactly one header component (HostelHeader)'
  );

  // ---------------------------------------------------------------------------
  // STAGE B: Dashboard Derived Metrics
  // ---------------------------------------------------------------------------
  console.log('\n--- STAGE B: Authoritative Dashboard Metrics Calculation ---');
  const initialMetrics = await hostelRepository.getDashboardMetrics();
  assert(initialMetrics.totalHostels >= 3, 'Total hostels count is derived dynamically', `${initialMetrics.totalHostels} hostels`);
  assert(initialMetrics.totalBlocks >= 5, 'Total blocks count is derived dynamically', `${initialMetrics.totalBlocks} blocks`);
  assert(initialMetrics.totalFloors >= 7, 'Total floors count is derived dynamically', `${initialMetrics.totalFloors} floors`);
  assert(initialMetrics.totalRooms >= 8, 'Total rooms count is derived dynamically', `${initialMetrics.totalRooms} rooms`);
  assert(initialMetrics.totalBeds >= 15, 'Total beds count is derived dynamically', `${initialMetrics.totalBeds} beds`);
  assert(initialMetrics.occupiedBeds >= 2, 'Occupied beds derived from active allotments', `${initialMetrics.occupiedBeds} occupied`);
  assert(initialMetrics.availableBeds >= 10, 'Available beds derived dynamically', `${initialMetrics.availableBeds} available`);
  assert(initialMetrics.blockedBeds >= 1, 'Blocked / maintenance beds derived dynamically', `${initialMetrics.blockedBeds} blocked`);
  assert(
    initialMetrics.occupancyPercentage === Math.round((initialMetrics.occupiedBeds / initialMetrics.totalBeds) * 100),
    'Occupancy percentage accurately calculated',
    `${initialMetrics.occupancyPercentage}%`
  );
  assert(
    initialMetrics.studentsCurrentlyAllotted === 2,
    'Students currently allotted matches active resident count',
    `${initialMetrics.studentsCurrentlyAllotted} students`
  );

  // ---------------------------------------------------------------------------
  // STAGE C: Hostel Management Hierarchy & CRUD Integrity
  // ---------------------------------------------------------------------------
  console.log('\n--- STAGE C: Hostel Management Hierarchy & University Constraints ---');
  // 1. Hostels
  const hostels = await hostelRepository.getAllHostels();
  const boysHostel = hostels.find((h) => h.hostelType === 'Boys');
  const girlsHostel = hostels.find((h) => h.hostelType === 'Girls');
  const coedHostel = hostels.find((h) => h.hostelType === 'Co-ed');
  assert(!!boysHostel, 'Boys hostel type supported and configured', boysHostel?.hostelName);
  assert(!!girlsHostel, 'Girls hostel type supported and configured', girlsHostel?.hostelName);
  assert(!!coedHostel, 'Co-ed university residence hall supported and configured', coedHostel?.hostelName);

  // Create new university hostel
  const newHostel = await hostelRepository.createHostel({
    hostelName: 'Tagore International Scholar Hall',
    hostelCode: 'EIT-HST-004',
    hostelType: 'Co-ed',
    category: 'Deluxe',
    address: 'West Campus Zone, Research Quad',
  });
  assert(newHostel.hostelCode === 'EIT-HST-004', 'New university hostel created with code', newHostel.id);

  // Toggle hostel status
  const toggled = await hostelRepository.toggleHostelStatus(newHostel.id);
  assert(toggled.status === 'inactive', 'Hostel status toggled to inactive');
  const toggledBack = await hostelRepository.toggleHostelStatus(newHostel.id);
  assert(toggledBack.status === 'active', 'Hostel status toggled back to active');

  // 2. Blocks belong to Hostels
  const newBlock = await hostelRepository.createBlock({
    hostelId: newHostel.id,
    blockName: 'Tagore North Wing',
    blockCode: 'BLK-TN',
    wardenName: 'Prof. S. Bose',
    totalFloors: 3,
  });
  assert(newBlock.hostelId === newHostel.id, 'Block belongs strictly to parent hostel', newBlock.id);

  // 3. Floors belong to Blocks
  const newFloor = await hostelRepository.createFloor({
    hostelId: newHostel.id,
    blockId: newBlock.id,
    floorNumber: 1,
    floorName: 'Ground Floor Innovation Wing',
  });
  assert(newFloor.blockId === newBlock.id, 'Floor belongs strictly to parent block', newFloor.id);

  // 4. Rooms belong to Floors
  const newRoom = await hostelRepository.createRoom({
    floorId: newFloor.id,
    roomNumber: '101',
    roomType: 'Double',
    capacity: 2,
    monthlyRent: 2000,
  });
  assert(newRoom.floorId === newFloor.id && newRoom.blockId === newBlock.id, 'Room belongs strictly to parent floor and block', newRoom.id);

  // Verify beds automatically created matching capacity
  const allBeds = await hostelRepository.getAllBeds();
  const roomBeds = allBeds.filter((b) => b.roomId === newRoom.id);
  assert(roomBeds.length === 2, 'Configured beds automatically match room capacity of 2', `${roomBeds.length} beds created`);

  // Capacity consistency: Adding bed beyond capacity must throw
  let capacityErrorCaught = false;
  try {
    await hostelRepository.createBed({
      roomId: newRoom.id,
      bedNumber: 'C',
    });
  } catch (err: any) {
    capacityErrorCaught = true;
    assert(err.message.includes('Room Capacity Reached'), 'Enforces capacity consistency: adding bed beyond room capacity throws error', err.message);
  }
  assert(capacityErrorCaught, 'Capacity limit enforced on bed configuration');

  // Blocked bed cannot be allocated
  const blockedBed = (await hostelRepository.getAllBeds()).find((b) => b.status === 'BLOCKED');
  assert(!!blockedBed, 'Blocked bed identified in inventory master', blockedBed?.id);
  let blockedAllocError = false;
  try {
    await hostelRepository.createAllotment({
      studentId: 'STU-003',
      studentRegistrationNumber: 'EIT-STU-2026-CSE-0003',
      studentName: 'Test Student',
      bedId: blockedBed!.id,
    });
  } catch (err: any) {
    blockedAllocError = true;
    assert(err.message.includes('blocked for maintenance'), 'Blocked beds cannot be allocated to students', err.message);
  }
  assert(blockedAllocError, 'Blocked bed allocation guard verified');

  // Prevent deletion of records referenced by active allotments
  let deleteActiveHostelError = false;
  try {
    await hostelRepository.deleteHostel('HST-001'); // HST-001 houses active student Arjun Kumar
  } catch (err: any) {
    deleteActiveHostelError = true;
    assert(err.message.includes('Integrity Violation'), 'Prevent deletion of hostel referenced by active student allotments', err.message);
  }
  assert(deleteActiveHostelError, 'Hostel active allotment deletion guard verified');

  let deleteOccupiedBedError = false;
  try {
    await hostelRepository.deleteBed('BED-A-101-A'); // Currently occupied by Arjun Kumar
  } catch (err: any) {
    deleteOccupiedBedError = true;
    assert(err.message.includes('occupied'), 'Prevent deletion of bed currently occupied by active resident', err.message);
  }
  assert(deleteOccupiedBedError, 'Occupied bed deletion guard verified');

  // ---------------------------------------------------------------------------
  // STAGE D: Student Hostel Allotments, Transfers & Vacating
  // ---------------------------------------------------------------------------
  console.log('\n--- STAGE D: Student Allotment, Transfer & Vacating Workflows ---');
  // Load real university students from admission repository
  const admittedStudents = await admissionRepository.getStudents();
  assert(admittedStudents.length >= 2, 'Admitted students retrieved from authoritative admission repository', `${admittedStudents.length} students`);
  const student1 = admittedStudents[0];
  assert(!!student1.registrationNumber, 'Student possesses official EIT registration number', student1.registrationNumber);

  // Check double allocation guard
  let doubleAllocError = false;
  try {
    const availableBed = (await hostelRepository.getAllBeds()).find((b) => b.status === 'AVAILABLE');
    await hostelRepository.createAllotment({
      studentId: student1.id,
      studentRegistrationNumber: student1.registrationNumber,
      studentName: student1.fullName,
      bedId: availableBed!.id,
    });
  } catch (err: any) {
    doubleAllocError = true;
    assert(err.message.includes('Duplicate Allotment Guard'), 'Double allocation strictly prevented for active resident student', err.message);
  }
  assert(doubleAllocError, 'Double allotment guard verified');

  // Find active allotment for transfer test
  const activeAllotments = await hostelRepository.getAllAllotments();
  const arjunAllotment = activeAllotments.find((a) => a.studentRegistrationNumber === 'EIT-STU-2026-CSE-0001' && a.status === 'Active');
  assert(!!arjunAllotment, 'Identified active allotment for Arjun Kumar', arjunAllotment?.id);

  // Transfer room workflow - requires reason
  let missingReasonTransferError = false;
  try {
    await hostelRepository.transferAllotment({
      allotmentId: arjunAllotment!.id,
      newBedId: roomBeds[0].id,
      reason: '',
    });
  } catch (err: any) {
    missingReasonTransferError = true;
    assert(err.message.includes('reason is required'), 'Transfer accommodation requires mandatory administrative reason', err.message);
  }
  assert(missingReasonTransferError, 'Transfer mandatory reason verified');

  // Perform valid transfer
  const transferred = await hostelRepository.transferAllotment({
    allotmentId: arjunAllotment!.id,
    newBedId: roomBeds[0].id,
    transferredBy: 'Chief Warden Office',
    reason: 'Upgraded to Deluxe Research Quad suite for conference preparation',
  });
  assert(transferred.bedId === roomBeds[0].id, 'Student successfully transferred to new bed', `New Bed: ${transferred.bedNumber}, Room: ${transferred.roomNumber}`);
  assert(transferred.transferReason?.includes('Upgraded'), 'Transfer reason recorded in allotment state');

  // Verify old bed was released
  const oldBed = (await hostelRepository.getAllBeds()).find((b) => b.id === 'BED-A-101-A');
  assert(oldBed?.status === 'AVAILABLE', 'Previous bed released and now AVAILABLE for new resident', oldBed?.id);

  // Verify new bed is OCCUPIED
  const transferredBed = (await hostelRepository.getAllBeds()).find((b) => b.id === roomBeds[0].id);
  assert(transferredBed?.status === 'OCCUPIED' && transferredBed?.currentRegistrationNumber === 'EIT-STU-2026-CSE-0001', 'Destination bed is now OCCUPIED by transferred student', transferredBed?.id);

  // Verify transfer history recorded
  const history = await hostelRepository.getAllotmentHistory();
  const transferLog = history.find((h) => h.allotmentId === arjunAllotment!.id && h.action === 'TRANSFER');
  assert(!!transferLog, 'Allotment movement history accurately preserved for TRANSFER', transferLog?.reason);

  // Vacate accommodation workflow - requires reason
  let missingReasonVacateError = false;
  try {
    await hostelRepository.vacateAllotment({
      allotmentId: arjunAllotment!.id,
      reason: '',
    });
  } catch (err: any) {
    missingReasonVacateError = true;
    assert(err.message.includes('reason is required'), 'Vacate accommodation requires mandatory clearance reason', err.message);
  }
  assert(missingReasonVacateError, 'Vacate mandatory reason verified');

  // Perform valid vacate
  const vacated = await hostelRepository.vacateAllotment({
    allotmentId: arjunAllotment!.id,
    vacatedBy: 'Hostel Administration Office',
    reason: 'Graduation semester completion and official room clearance',
  });
  assert(vacated.status === 'Vacated', 'Allotment marked as Vacated', vacated.status);

  // Verify bed released upon vacating
  const vacatedBed = (await hostelRepository.getAllBeds()).find((b) => b.id === roomBeds[0].id);
  assert(vacatedBed?.status === 'AVAILABLE', 'Bed successfully released to AVAILABLE upon student vacating', vacatedBed?.id);

  // Verify vacate history recorded
  const vacateLog = (await hostelRepository.getAllotmentHistory()).find((h) => h.allotmentId === arjunAllotment!.id && h.action === 'VACATE');
  assert(!!vacateLog, 'Allotment movement history accurately preserved for VACATE', vacateLog?.reason);

  // ---------------------------------------------------------------------------
  // STAGE E: Leave & Outing Approvals, Gate Movement & Slips
  // ---------------------------------------------------------------------------
  console.log('\n--- STAGE E: Leave & Outing Workflow, Slips & Security Gates ---');
  const leaveRequests = await hostelLeaveService.getAllRequests();
  assert(leaveRequests.length >= 2, 'Leave requests retrieved from authoritative store', `${leaveRequests.length} requests`);

  const pendingLeave = leaveRequests.find((r) => r.status === 'PENDING_HOSTEL');
  assert(!!pendingLeave, 'Identified pending leave request ready for Hostel Office approval', pendingLeave?.id);

  // Review approval action
  const approvedLeave = await hostelLeaveService.reviewRequestByHostel(
    pendingLeave!.id,
    'Dr. Vikram Seth (Chief Warden)',
    'EMP-003',
    'approve',
    'Academic conference participation endorsed. Gate out authorized.'
  );
  assert(approvedLeave.status === 'APPROVED', 'Leave request transitioned to APPROVED by Hostel Office', approvedLeave.status);
  assert(!!approvedLeave.slipNumber && approvedLeave.slipNumber.startsWith('SLIP-EIT-'), 'Official clearance slip number generated upon approval', approvedLeave.slipNumber);
  assert(approvedLeave.hostelActionBy === 'Dr. Vikram Seth (Chief Warden)', 'Hostel authorized reviewer recorded in slip dossier');

  // Record security gate movements
  const gateOutRecord = await hostelLeaveService.recordGateOut(
    approvedLeave.id,
    '09:15 AM',
    'Security Officer M. Pillai (Gate 1)'
  );
  assert(gateOutRecord.gateOutTime === '09:15 AM', 'Gate out time recorded at campus perimeter gate', gateOutRecord.gateOutTime);

  const gateInRecord = await hostelLeaveService.recordGateIn(
    approvedLeave.id,
    '05:45 PM',
    'Security Officer M. Pillai (Gate 1)'
  );
  assert(gateInRecord.gateInTime === '05:45 PM', 'Gate in time recorded upon student return', gateInRecord.gateInTime);

  // Verify Leave metrics calculation
  const leaveMetrics = await hostelLeaveService.getDashboardMetrics();
  assert(leaveMetrics.approvedToday >= 1, 'Approved today count reflects approved leave', `${leaveMetrics.approvedToday} approved`);
  assert(leaveMetrics.totalRequests >= 2, 'Total leave requests metric calculated accurately', `${leaveMetrics.totalRequests} total`);

  // Verify reflection in Student Portal
  const studentLeaves = await hostelLeaveService.getRequestsForStudent(pendingLeave!.studentRegistrationNumber);
  const updatedStudentReq = studentLeaves.find((r) => r.id === pendingLeave!.id);
  assert(updatedStudentReq?.status === 'APPROVED', 'Updated approval status reflects immediately in Student Portal history', updatedStudentReq?.status);
  assert(updatedStudentReq?.slipNumber === approvedLeave.slipNumber, 'Official slip number matches across Student Portal and Hostel Office');

  // ---------------------------------------------------------------------------
  // STAGE G: Student Portal Service Integration
  // ---------------------------------------------------------------------------
  console.log('\n--- STAGE G: Student Portal Services Compatibility ---');
  // Re-allot student for student portal query testing
  const freshAlloc = await hostelRepository.createAllotment({
    studentId: 'STU-001',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    studentName: 'Arjun Kumar',
    studentClass: 'B.Tech CSE',
    bedId: 'BED-A-101-A',
  });
  assert(freshAlloc.status === 'Active', 'Fresh allotment created for student portal compatibility');

  const studentAllotment = await hostelRepository.getActiveAllotmentForStudent('EIT-STU-2026-CSE-0001');
  assert(!!studentAllotment && studentAllotment.roomNumber === '101', 'getActiveAllotmentForStudent retrieves active room', `Room ${studentAllotment?.roomNumber}, Bed ${studentAllotment?.bedNumber}`);

  const hostelDetails = await hostelRepository.getHostelById(studentAllotment!.hostelId);
  assert(!!hostelDetails && hostelDetails.hostelName.includes('Nilgiri'), 'getHostelById retrieves residential hall particulars', hostelDetails?.hostelName);

  console.log('\n================================================================');
  console.log(`Hostel Office Adaptation Summary: ${passedTests} / ${totalTests} tests passed.`);
  console.log('🎉 ALL HOSTEL OFFICE UNIVERSITY ADAPTATION CRITERIA PASSED!');
  console.log('================================================================');
}

runTestSuite().catch((err) => {
  console.error('Test Suite Failed:', err);
  process.exit(1);
});
