import { examinationRepository } from '../src/services/examinationService';
import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  AuthRole,
  ExamType,
  ExamSessionStatus,
  ExamLifecycleStatus,
} from '../src/types/database';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runCoeRedesignVerification() {
  console.log('========================================================================');
  console.log('   EIT CAMS — Controller of Examinations (COE) Office Redesign Suite    ');
  console.log('========================================================================\n');

  try {
    // -------------------------------------------------------------------------
    // 1. Initial State & Repository Initialization
    // -------------------------------------------------------------------------
    console.log('--- 1. COE Repository Initialization & Data Ingestion ---');
    const exams = await examinationRepository.getExaminations();
    assert(Array.isArray(exams) && exams.length > 0, 'Exams repository loaded', `Count: ${exams.length}`);

    const schedules = await examinationRepository.getSchedules();
    assert(Array.isArray(schedules) && schedules.length > 0, 'Schedules loaded', `Count: ${schedules.length}`);

    const eligibilities = await examinationRepository.getEligibilities();
    assert(Array.isArray(eligibilities) && eligibilities.length > 0, 'Eligibilities loaded', `Count: ${eligibilities.length}`);

    const hallTickets = await examinationRepository.getHallTickets();
    assert(Array.isArray(hallTickets), 'Hall tickets repository initialized', `Count: ${hallTickets.length}`);

    // -------------------------------------------------------------------------
    // 2. Examination Session Management
    // -------------------------------------------------------------------------
    console.log('\n--- 2. University Examination Session Management ---');
    const newExamId = `EXAM-TEST-${Date.now()}`;
    const createdExam = await examinationRepository.createExamination(
      {
        id: newExamId,
        name: 'B.Tech Odd Semester End Examination 2026',
        academicSession: '2026-2027',
        termType: 'Semester 5 Regular Examination',
        semester: 5,
        startDate: '2026-11-20',
        endDate: '2026-12-05',
        status: 'UPCOMING',
        instructions: 'Standard Autonomous Examination Regulations apply. Calculators allowed for numerical papers.',
        registrationDeadline: '2026-11-15',
        department: 'CSE',
      },
      'coeoffice'
    );
    assert(createdExam.id === newExamId, 'New university examination session created', `ID: ${createdExam.id}`);
    assert(createdExam.termType === 'Semester 5 Regular Examination', 'Semester and category recorded correctly');

    // Update status to ACTIVE
    const updatedExam = await examinationRepository.updateExamination(
      newExamId,
      { status: 'ACTIVE' },
      'coeoffice'
    );
    assert(updatedExam.status === 'ACTIVE', 'Examination status transitioned to ACTIVE');

    // -------------------------------------------------------------------------
    // 3. Timetable & Schedule Paper Management
    // -------------------------------------------------------------------------
    console.log('\n--- 3. Timetable & Course Paper Scheduling ---');
    const newSchedId = `SCHED-TEST-${Date.now()}`;
    const createdSched = await examinationRepository.createSchedule(
      {
        id: newSchedId,
        examinationId: newExamId,
        examName: 'Design and Analysis of Algorithms',
        courseCode: 'CS301',
        programmeCode: 'BTECH-CSE',
        department: 'CSE',
        semester: 5,
        section: 'A',
        examDate: '2026-11-22',
        startTime: '09:30',
        endTime: '12:30',
        room: 'Exam Hall 302',
        maxMarks: 100,
        passingMarks: 40,
        examType: ExamType.END_SEMESTER,
      },
      'coeoffice'
    );
    assert(createdSched.id === newSchedId, 'Course paper schedule created', `Course: ${createdSched.courseCode}`);
    assert(createdSched.marksEntryStatus === 'LOCKED', 'Initial marks entry status is securely locked');

    // Update schedule timing
    const updatedSched = await examinationRepository.updateSchedule(
      newSchedId,
      { room: 'Exam Hall 305', maxMarks: 100 },
      'coeoffice'
    );
    assert(updatedSched.room === 'Exam Hall 305', 'Schedule room updated', `Room: ${updatedSched.room}`);

    // -------------------------------------------------------------------------
    // 4. Student Eligibility Rules & Compliance
    // -------------------------------------------------------------------------
    console.log('\n--- 4. University Student Eligibility & Compliance ---');
    // Sync eligibility for new exam
    const synced = await examinationRepository.syncEligibilityFromAdmission(newExamId, 'coeoffice');
    assert(Array.isArray(synced) && synced.length > 0, 'Eligibility records synced from student master data', `Count: ${synced.length}`);

    const candidateReg = synced[0].studentRegistrationNumber;
    // Debar candidate manually with reason
    await examinationRepository.updateStudentEligibility(
      newExamId,
      candidateReg,
      false,
      'Severe attendance shortage (<65%) and pending fee dues',
      'coeoffice'
    );

    const checkDebarred = await examinationRepository.getEligibilities(newExamId);
    const candidateRecord = checkDebarred.find((e) => e.studentRegistrationNumber === candidateReg);
    assert(candidateRecord?.isEligible === false, 'Student debarred from examination cell', `Candidate: ${candidateReg}`);
    assert(Boolean(candidateRecord?.ineligibilityReason), 'Debarment reason recorded in audit');

    // -------------------------------------------------------------------------
    // 5. Hall Ticket Generation & Ineligible Candidate Protection
    // -------------------------------------------------------------------------
    console.log('\n--- 5. Hall Ticket Generation & Ineligible Candidate Gate ---');
    // Ineligible student MUST BE BLOCKED from hall ticket generation
    let blockedAsExpected = false;
    try {
      await examinationRepository.generateHallTicket(newExamId, candidateReg, 'coeoffice');
    } catch (err: any) {
      blockedAsExpected = true;
      assert(true, 'Ineligible student blocked from hall ticket issuance', `Error message: ${err.message}`);
    }
    assert(blockedAsExpected, 'Security check passed: Ineligible student cannot receive Hall Ticket');

    // Reinstate candidate eligibility
    await examinationRepository.updateStudentEligibility(
      newExamId,
      candidateReg,
      true,
      'Medical condonation approved by Dean of Academics',
      'coeoffice'
    );

    // Now hall ticket generation MUST succeed
    const hallTicket = await examinationRepository.generateHallTicket(newExamId, candidateReg, 'coeoffice');
    assert(Boolean(hallTicket && hallTicket.hallTicketNumber), 'Hall ticket successfully generated for eligible candidate', `Ticket: ${hallTicket?.hallTicketNumber}`);
    assert(hallTicket.studentRegistrationNumber === candidateReg, 'Hall ticket linked to candidate registration number');

    // -------------------------------------------------------------------------
    // 6. Marks Entry Window Control & Reopen Audit Rules
    // -------------------------------------------------------------------------
    console.log('\n--- 6. Marks Entry Window Control & Audit Rules ---');
    // Open marks entry
    const openedSched = await examinationRepository.openMarkEntry(newSchedId, 'coeoffice');
    assert(openedSched.marksEntryStatus === 'OPEN', 'Marks entry window opened for faculty');

    // Close marks entry
    const closedSched = await examinationRepository.closeMarkEntry(newSchedId, 'coeoffice');
    assert(closedSched.marksEntryStatus === 'CLOSED', 'Marks entry window closed');

    // Reopening without reason MUST FAIL
    let rejectEmptyReason = false;
    try {
      await examinationRepository.reopenMarkEntry(newSchedId, '   ', 'coeoffice');
    } catch (err: any) {
      rejectEmptyReason = true;
      assert(true, 'Reopening marks window without reason was rejected', `Error: ${err.message}`);
    }
    assert(rejectEmptyReason, 'Mandatory audit justification enforced on reopen');

    // Reopen with valid justification
    const reopenedSched = await examinationRepository.reopenMarkEntry(
      newSchedId,
      'Approved request from HOD CSE due to server connectivity during evaluation',
      'coeoffice'
    );
    assert(reopenedSched.marksEntryStatus === 'REOPENED', 'Marks window reopened with formal audit record');

    // -------------------------------------------------------------------------
    // 7. Marks Verification & Moderation
    // -------------------------------------------------------------------------
    console.log('\n--- 7. Marks Verification, Return & Moderation ---');
    // Return for correction requires reason
    let rejectReturnEmpty = false;
    try {
      await examinationRepository.returnMarksForCorrection(newSchedId, '', 'coeoffice');
    } catch (err: any) {
      rejectReturnEmpty = true;
      assert(true, 'Returning marks without reason rejected', `Error: ${err.message}`);
    }
    assert(rejectReturnEmpty, 'Mandatory revision notes enforced when returning marks');

    // Return marks with valid instruction
    const returnedSched = await examinationRepository.returnMarksForCorrection(
      newSchedId,
      'Internal component discrepancies for Sec A students; please reconcile with continuous assessment registers',
      'coeoffice'
    );
    assert(returnedSched.marksEntryStatus === 'OPEN', 'Marks returned to faculty for correction');

    // Verify marks
    const verifiedSched = await examinationRepository.verifyMarks(
      newSchedId,
      'Audit verified against signed paper copies',
      'coeoffice'
    );
    assert(verifiedSched.isMarksVerified === true, 'Marks sealed and verified by COE');

    // -------------------------------------------------------------------------
    // 8. Results Calculation & Publication
    // -------------------------------------------------------------------------
    console.log('\n--- 8. University Results Processing & Transcript Publication ---');
    const calcResults = await examinationRepository.calculateResultsForExam(newExamId, 'coeoffice');
    assert(Array.isArray(calcResults), 'Result calculation executed for examination candidates', `Calculated: ${calcResults.length}`);

    // Publish results
    const pubResults = await examinationRepository.publishResults(newExamId, 'coeoffice');
    assert(Array.isArray(pubResults), 'Official results published to Student Portal', `Published: ${pubResults.length}`);

    const examAfterPublish = (await examinationRepository.getExaminations()).find((e) => e.id === newExamId);
    assert(examAfterPublish?.status === 'RESULTS_PUBLISHED', 'Exam session status transitioned to RESULTS_PUBLISHED');

    // -------------------------------------------------------------------------
    // 9. Audit Logs & Permanent Office Boundaries
    // -------------------------------------------------------------------------
    console.log('\n--- 9. Audit History & System Resilience ---');
    const logs = await examinationRepository.getAuditLogs();
    assert(Array.isArray(logs) && logs.length > 0, 'COE audit trail recorded multiple events', `Count: ${logs.length}`);

    const recentLog = logs.find((l) => l.examinationId === newExamId || l.performedBy === 'coeoffice');
    assert(Boolean(recentLog), 'Audit log contains entries performed by coeoffice', `Action: ${recentLog?.action}`);

    // Clean up test schedule
    await examinationRepository.deleteSchedule(newSchedId, 'coeoffice');
    const schedAfterDelete = (await examinationRepository.getSchedules()).find((s) => s.id === newSchedId);
    assert(!schedAfterDelete, 'Test schedule successfully cleaned up');

    // Summary
    console.log('\n========================================================================');
    const passedCount = results.filter((r) => r.passed).length;
    const failedCount = results.filter((r) => !r.passed).length;
    console.log(`TOTAL TESTS: ${results.length} | PASSED: ${passedCount} | FAILED: ${failedCount}`);
    console.log('========================================================================\n');

    if (failedCount > 0) {
      process.exit(1);
    }
  } catch (globalErr: any) {
    console.error('Fatal unhandled error during COE verification:', globalErr);
    process.exit(1);
  }
}

runCoeRedesignVerification();
