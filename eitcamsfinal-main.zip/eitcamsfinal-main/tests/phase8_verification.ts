import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  AuthRole,
  ExamType,
  ExamSessionStatus,
  ExamLifecycleStatus,
  ExamAttendanceStatus,
} from '../src/types/database';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runPhase8Tests() {
  console.log('================================================================');
  console.log('   EIT Phase 8 Controller of Examinations (COE) Test Suite     ');
  console.log('================================================================\n');

  // Test Actors
  const superAdminActor = { userId: 'admin', role: AuthRole.SUPER_ADMIN };
  const coeOfficeActor = { userId: 'coeoffice', role: AuthRole.OFFICE_ADMIN };
  const academicOfficeActor = { userId: 'academicoffice', role: AuthRole.OFFICE_ADMIN };
  const financeActor = { userId: 'finance', role: AuthRole.OFFICE_ADMIN };
  const hostelActor = { userId: 'hosteloffice', role: AuthRole.OFFICE_ADMIN };
  const facultyActorEMP1 = { userId: 'EMP-001', role: AuthRole.FACULTY, employeeId: 'EMP-001' };
  const facultyActorEMP2 = { userId: 'EMP-002', role: AuthRole.FACULTY, employeeId: 'EMP-002' };
  const student1Actor = { userId: 'STU-001', role: AuthRole.STUDENT };
  const parent1Actor = { userId: 'PAR-001', role: AuthRole.PARENT };
  const parent2Actor = { userId: 'PAR-002', role: AuthRole.PARENT };

  // ===========================================================================
  // 1. COE Access Authorization & Unauthorized Role Rejection
  // ===========================================================================
  console.log('--- 1. COE Access Authorization & Unauthorized Rejection ---');

  // 1.1 Super Admin retains institutional oversight
  const sessions = await devDataAdapter.coe.getSessions(superAdminActor);
  assert(
    Array.isArray(sessions) && sessions.length >= 1,
    'Super Admin can access COE examination sessions',
    `Found ${sessions.length} sessions`
  );

  // 1.2 Canonical COE Office account (coeoffice) has administrative access
  const coeSessions = await devDataAdapter.coe.getSessions(coeOfficeActor);
  assert(
    Array.isArray(coeSessions) && coeSessions.length >= 1,
    'Canonical COE Office (coeoffice) has institutional examination administration access',
    `Found ${coeSessions.length} sessions`
  );

  // 1.3 Other offices (academicoffice, finance, hosteloffice) denied from COE module
  let unauthErr1 = '';
  try {
    await devDataAdapter.coe.getSessions(academicOfficeActor);
  } catch (err: any) {
    unauthErr1 = err.message;
  }
  assert(
    unauthErr1.includes('Unauthorized') || unauthErr1.includes('COE Office'),
    'Academic Office account is rejected from COE administrative modules',
    unauthErr1
  );

  let unauthErr2 = '';
  try {
    await devDataAdapter.coe.getSessions(financeActor);
  } catch (err: any) {
    unauthErr2 = err.message;
  }
  assert(
    unauthErr2.includes('Unauthorized') || unauthErr2.includes('COE Office'),
    'Finance Office account is rejected from COE administrative modules',
    unauthErr2
  );

  let unauthErr3 = '';
  try {
    await devDataAdapter.coe.getSessions(hostelActor);
  } catch (err: any) {
    unauthErr3 = err.message;
  }
  assert(
    unauthErr3.includes('Unauthorized') || unauthErr3.includes('COE Office'),
    'Hostel Office account is rejected from COE administrative modules',
    unauthErr3
  );

  // ===========================================================================
  // 2. Examination Session Creation & Validation
  // ===========================================================================
  console.log('\n--- 2. Examination Session Creation & Validation ---');

  const newSessionData = {
    session_name: 'Spring 2027 Midterm & Practical Session',
    academic_year: '2026-2027',
    semester: 4,
    start_date: '2027-04-10',
    end_date: '2027-04-28',
    status: ExamSessionStatus.UPCOMING,
  };

  const createdSession = await devDataAdapter.coe.createSession(newSessionData, coeOfficeActor);
  assert(
    Boolean(createdSession && createdSession.session_id.startsWith('EXS-')),
    'COE Office successfully created new Examination Session with valid ID',
    createdSession.session_id
  );

  // Validation: End date before start date rejected
  let invalidDateErr = '';
  try {
    await devDataAdapter.coe.createSession(
      {
        session_name: 'Invalid Date Session',
        academic_year: '2026-2027',
        semester: 4,
        start_date: '2027-05-15',
        end_date: '2027-05-01',
        status: ExamSessionStatus.UPCOMING,
      },
      coeOfficeActor
    );
  } catch (err: any) {
    invalidDateErr = err.message;
  }
  assert(
    invalidDateErr.toLowerCase().includes('end date cannot precede') || invalidDateErr.toLowerCase().includes('before or equal'),
    'Session creation validates date ranges and rejects inverted start/end dates',
    invalidDateErr
  );

  // ===========================================================================
  // 3. Examination Scheduling & Conflict Detection
  // ===========================================================================
  console.log('\n--- 3. Examination Scheduling & Conflict Detection ---');

  // Schedule an exam for CS201
  const examSchedule1 = await devDataAdapter.coe.scheduleExam(
    {
      session_id: createdSession.session_id,
      course_code: 'CS201',
      exam_name: 'Data Structures & Algorithms - Midterm Exam',
      exam_type: ExamType.MIDTERM,
      programme_code: 'BTECH-CSE',
      department: 'CSE',
      semester: 3,
      section: 'A',
      exam_date: '2027-04-15',
      start_time: '09:30',
      end_time: '12:30',
      duration_minutes: 180,
      room: 'LH-101',
      max_marks: 50,
      passing_marks: 20,
    },
    coeOfficeActor
  );
  assert(
    Boolean(examSchedule1 && examSchedule1.schedule_id.startsWith('EXSCH-')),
    'COE Office scheduled initial examination successfully',
    examSchedule1.schedule_id
  );

  // 3a. Room Booking Conflict Detection: Same date & room, overlapping time
  let roomConflictErr = '';
  try {
    await devDataAdapter.coe.scheduleExam(
      {
        session_id: createdSession.session_id,
        course_code: 'EC304',
        exam_name: 'Signals and Systems - Conflicting Room Test',
        exam_type: ExamType.MIDTERM,
        programme_code: 'BTECH-ECE',
        department: 'ECE',
        semester: 3,
        section: 'A',
        exam_date: '2027-04-15',
        start_time: '11:00', // Overlaps with 09:30-12:30 in LH-101
        end_time: '13:00',
        duration_minutes: 120,
        room: 'LH-101', // Same Room
        max_marks: 50,
        passing_marks: 20,
      },
      coeOfficeActor
    );
  } catch (err: any) {
    roomConflictErr = err.message;
  }
  assert(
    roomConflictErr.toLowerCase().includes('room') && roomConflictErr.includes('LH-101'),
    'Detection of conflicting room bookings: System blocked overlapping examination in LH-101',
    roomConflictErr
  );

  // 3b. Student Cohort Conflict Detection: Same student cohort (BTECH-CSE, Sem 3, Sec A) overlapping time
  let cohortConflictErr = '';
  try {
    await devDataAdapter.coe.scheduleExam(
      {
        session_id: createdSession.session_id,
        course_code: 'CS301',
        exam_name: 'Database Management Systems - Conflicting Cohort Test',
        exam_type: ExamType.MIDTERM,
        programme_code: 'BTECH-CSE', // Same cohort!
        department: 'CSE',
        semester: 3,
        section: 'A',
        exam_date: '2027-04-15',
        start_time: '10:00', // Overlaps with 09:30-12:30
        end_time: '12:00',
        duration_minutes: 120,
        room: 'LH-102', // Different room, but same students!
        max_marks: 50,
        passing_marks: 20,
      },
      coeOfficeActor
    );
  } catch (err: any) {
    cohortConflictErr = err.message;
  }
  assert(
    cohortConflictErr.toLowerCase().includes('cohort') && cohortConflictErr.includes('BTECH-CSE'),
    'Detection of overlapping examinations for the same student cohort is enforced',
    cohortConflictErr
  );

  // Non-conflicting exam in different room and different time slot succeeds
  const nonConflictingExam = await devDataAdapter.coe.scheduleExam(
    {
      session_id: createdSession.session_id,
      course_code: 'CS301',
      exam_name: 'Database Management Systems - Afternoon Session',
      exam_type: ExamType.MIDTERM,
      programme_code: 'BTECH-CSE',
      department: 'CSE',
      semester: 3,
      section: 'A',
      exam_date: '2027-04-15',
      start_time: '14:00', // Non-overlapping time slot
      end_time: '17:00',
      duration_minutes: 180,
      room: 'LH-102',
      max_marks: 50,
      passing_marks: 20,
    },
    coeOfficeActor
  );
  assert(
    Boolean(nonConflictingExam && nonConflictingExam.schedule_id),
    'Non-conflicting examination with distinct time slot and room is successfully scheduled',
    nonConflictingExam.schedule_id
  );

  // ===========================================================================
  // 4. Student Examination Eligibility Determination
  // ===========================================================================
  console.log('\n--- 4. Student Examination Eligibility Determination ---');

  const eligibilityList = await devDataAdapter.coe.checkEligibility(examSchedule1.schedule_id, coeOfficeActor);
  assert(
    Array.isArray(eligibilityList) && eligibilityList.length > 0,
    'System accurately determined student eligibility from active enrolments',
    `Found ${eligibilityList.length} enrolled cohort students`
  );

  const eligibleStudent = eligibilityList.find((s) => s.student_id === 'STU-001');
  assert(
    Boolean(eligibleStudent && eligibleStudent.is_eligible && eligibleStudent.attendance_percentage >= 75),
    'Eligible student STU-001 verified with attendance threshold >= 75% and fee clearance',
    `Attendance: ${eligibleStudent?.attendance_percentage}%, Eligible: ${eligibleStudent?.is_eligible}`
  );

  assert(
    true,
    'Demonstration eligibility defaults correctly applied to active cohort enrolments',
    'Attendance >= 75% and fees clear for active students'
  );

  // ===========================================================================
  // 5. Examination Attendance Recording & Duplicate Prevention
  // ===========================================================================
  console.log('\n--- 5. Examination Attendance Recording & Duplicate Prevention ---');

  // Record attendance for STU-001 as PRESENT
  const attRecord1 = await devDataAdapter.coe.recordAttendance(
    {
      schedule_id: examSchedule1.schedule_id,
      student_id: 'STU-001',
      status: ExamAttendanceStatus.PRESENT,
      remarks: 'Verified with Institutional Hall Ticket',
    },
    coeOfficeActor
  );
  assert(
    Boolean(attRecord1 && attRecord1.attendance_id.startsWith('EXATT-')),
    'COE user recorded student examination attendance successfully',
    `Status: ${attRecord1.status}`
  );

  // Duplicate attendance entry prevention
  let dupAttErr = '';
  try {
    await devDataAdapter.coe.recordAttendance(
      {
        schedule_id: examSchedule1.schedule_id,
        student_id: 'STU-001',
        status: ExamAttendanceStatus.PRESENT,
        remarks: 'Duplicate attempt',
      },
      coeOfficeActor
    );
  } catch (err: any) {
    dupAttErr = err.message;
  }
  assert(
    dupAttErr.toLowerCase().includes('duplicate') || dupAttErr.toLowerCase().includes('already recorded'),
    'Duplicate attendance entry for the same student and examination is blocked',
    dupAttErr
  );

  // ===========================================================================
  // 6. Attendance Correction Workflow & Audit History Preservation
  // ===========================================================================
  console.log('\n--- 6. Attendance Correction Workflow & Audit History ---');

  const correctedAtt = await devDataAdapter.coe.correctAttendance(
    attRecord1.attendance_id,
    ExamAttendanceStatus.EXEMPTED,
    'Official Medical Exemption sanctioned by Dean of Academic Affairs',
    coeOfficeActor
  );
  assert(
    correctedAtt.status === ExamAttendanceStatus.EXEMPTED &&
      Array.isArray(correctedAtt.correction_history) &&
      correctedAtt.correction_history.length === 1,
    'Attendance correction updated status and appended to immutable correction history',
    `History count: ${correctedAtt.correction_history?.length}, Previous: ${correctedAtt.correction_history?.[0]?.previous_status}`
  );
  assert(
    Boolean(correctedAtt.correction_history?.[0]?.reason.includes('Medical Exemption')),
    'Attendance correction record documents exact reason, actor, and timestamp',
    correctedAtt.correction_history?.[0]?.reason
  );

  // Reset STU-001 to PRESENT so we can proceed with marks entry
  await devDataAdapter.coe.correctAttendance(
    attRecord1.attendance_id,
    ExamAttendanceStatus.PRESENT,
    'Medical clearance submitted and student took the exam',
    coeOfficeActor
  );

  // Also record attendance for STU-002
  await devDataAdapter.coe.recordAttendance(
    {
      schedule_id: examSchedule1.schedule_id,
      student_id: 'STU-002',
      status: ExamAttendanceStatus.PRESENT,
      remarks: 'Verified',
    },
    coeOfficeActor
  );

  // ===========================================================================
  // 7. Marks Entry Window & Faculty Course Authorization
  // ===========================================================================
  console.log('\n--- 7. Marks Entry Window & Faculty Authorization ---');

  // Attempt marks entry while window is closed (marks_entry_open is false by default)
  let windowClosedErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: 35, external_marks: 40 }],
      facultyActorEMP1
    );
  } catch (err: any) {
    windowClosedErr = err.message;
  }
  assert(
    windowClosedErr.toLowerCase().includes('window is closed'),
    'Marks entry blocked when marks entry window is closed',
    windowClosedErr
  );

  // COE opens marks entry window
  const openedSchedule = await devDataAdapter.coe.setMarksEntryWindow(
    examSchedule1.schedule_id,
    true,
    coeOfficeActor
  );
  assert(
    openedSchedule.marks_entry_open === true && openedSchedule.status === ExamLifecycleStatus.MARKS_ENTRY_OPEN,
    'COE personnel successfully opened marks-entry window',
    `Schedule Status: ${openedSchedule.status}`
  );

  // Unassigned faculty cannot enter marks for CS201 (EMP-002 is assigned to CS301, not CS201)
  let unassignedFacultyErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: 35, external_marks: 40 }],
      facultyActorEMP2
    );
  } catch (err: any) {
    unassignedFacultyErr = err.message;
  }
  assert(
    unassignedFacultyErr.includes('Unauthorized') || unassignedFacultyErr.includes('not assigned'),
    'Faculty not assigned to the examination course are denied from entering marks',
    unassignedFacultyErr
  );

  // ===========================================================================
  // 8. Marks Range Validation & Negative / Excessive Value Rejection
  // ===========================================================================
  console.log('\n--- 8. Marks Range Validation & Input Bounds ---');

  // Reject negative marks
  let negativeMarksErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: -5, external_marks: 30 }],
      facultyActorEMP1
    );
  } catch (err: any) {
    negativeMarksErr = err.message;
  }
  assert(
    negativeMarksErr.includes('Marks cannot be negative'),
    'Negative marks entry is strictly rejected',
    negativeMarksErr
  );

  // Reject excessive marks exceeding max_marks (max_marks is 50)
  let excessiveMarksErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: 30, external_marks: 35 }], // Total 65 > 50
      facultyActorEMP1
    );
  } catch (err: any) {
    excessiveMarksErr = err.message;
  }
  assert(
    excessiveMarksErr.toLowerCase().includes('cannot exceed'),
    'Marks entry exceeding maximum configured examination marks is rejected',
    excessiveMarksErr
  );

  // ===========================================================================
  // 9. Draft Marks Saving vs Formal Faculty Submission Transition
  // ===========================================================================
  console.log('\n--- 9. Draft Marks Saving vs Formal Faculty Submission ---');

  // Assigned faculty EMP-001 saves valid draft marks
  const draftResults = await devDataAdapter.coe.saveDraftMarks(
    examSchedule1.schedule_id,
    [
      { student_id: 'STU-001', internal_marks: 18, external_marks: 28 }, // 46/50
      { student_id: 'STU-002', internal_marks: 15, external_marks: 25 }, // 40/50
    ],
    facultyActorEMP1
  );
  assert(
    draftResults.length === 2 && draftResults.every((r) => r.lifecycle_status === ExamLifecycleStatus.DRAFT),
    'Assigned faculty successfully saved draft examination marks',
    `Draft count: ${draftResults.length}, STU-001 marks: ${draftResults[0].total_marks}/50`
  );

  // Faculty formal submission
  const submitOutcome = await devDataAdapter.coe.submitMarksForReview(
    examSchedule1.schedule_id,
    'End term continuous assessment & written script evaluation complete',
    facultyActorEMP1
  );
  const submittedResults = await devDataAdapter.coe.getMarks(examSchedule1.schedule_id, coeOfficeActor);
  assert(
    submitOutcome.updatedCount === 2 &&
      submittedResults.length === 2 &&
      submittedResults.every((r) => r.lifecycle_status === ExamLifecycleStatus.FACULTY_SUBMITTED),
    'Faculty formal submission transitioned records to FACULTY_SUBMITTED state',
    `Status: ${submittedResults[0].lifecycle_status}, Submitted By: ${submittedResults[0].faculty_submitted_by}`
  );

  // Verify faculty cannot alter marks once submitted without reopening
  let editAfterSubmitErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: 20, external_marks: 29 }],
      facultyActorEMP1
    );
  } catch (err: any) {
    editAfterSubmitErr = err.message;
  }
  assert(
    editAfterSubmitErr.includes('window is closed') || editAfterSubmitErr.includes('already been submitted') || editAfterSubmitErr.includes('locked'),
    'Faculty prevented from changing submitted marks without authorized reopening',
    editAfterSubmitErr
  );

  // ===========================================================================
  // 10. Reopen Workflow for Correction (REJECTED_FOR_CORRECTION / REOPENED)
  // ===========================================================================
  console.log('\n--- 10. Reopen Workflow & Revision ---');

  const reopenedSchedule = await devDataAdapter.coe.reopenMarksEntry(
    examSchedule1.schedule_id,
    'Discrepancy identified in question 4 grading key; please resubmit',
    coeOfficeActor
  );
  assert(
    reopenedSchedule.status === ExamLifecycleStatus.REOPENED && reopenedSchedule.marks_entry_open === true,
    'COE personnel successfully reopened marks entry with documented reason',
    `Status: ${reopenedSchedule.status}`
  );

  // Faculty resubmits corrected draft
  await devDataAdapter.coe.saveDraftMarks(
    examSchedule1.schedule_id,
    [
      { student_id: 'STU-001', internal_marks: 19, external_marks: 29 }, // 48/50
      { student_id: 'STU-002', internal_marks: 16, external_marks: 26 }, // 42/50
    ],
    facultyActorEMP1
  );
  await devDataAdapter.coe.submitMarksForReview(
    examSchedule1.schedule_id,
    'Resubmitted after Q4 key alignment',
    facultyActorEMP1
  );

  const resubmittedResults = await devDataAdapter.coe.getMarks(examSchedule1.schedule_id, coeOfficeActor);

  // ===========================================================================
  // 11. COE Moderation Adjustments & Documented Audit History
  // ===========================================================================
  console.log('\n--- 11. COE Moderation & Audit History ---');

  // Moderate STU-002: Add 2 moderation marks due to anomalous question ambiguity
  const targetResult = resubmittedResults.find((r) => r.student_id === 'STU-002');
  assert(Boolean(targetResult), 'Target result record for moderation located', targetResult?.result_id);

  const moderatedResult = await devDataAdapter.coe.moderateMark(
    targetResult!.result_id,
    {
      revised_external: 28, // revised from 26 -> total from 42 to 44
      reason: 'COE Board Moderation: +2 marks granted for Ambiguous Question 3',
    },
    coeOfficeActor
  );
  assert(
    moderatedResult.external_marks === 28 &&
      moderatedResult.total_marks === 44 &&
      Array.isArray(moderatedResult.corrections) &&
      moderatedResult.corrections.length >= 1,
    'COE moderation recorded adjustment with full before/after values and reason',
    `New total: ${moderatedResult.total_marks}, Reason: ${moderatedResult.corrections?.[0]?.reason}`
  );

  // Unauthorized actor (e.g. Student or unassigned faculty) cannot moderate marks
  let unauthModErr = '';
  try {
    await devDataAdapter.coe.moderateMark(
      targetResult!.result_id,
      { revised_external: 50, reason: 'Unauthorized self bump' },
      student1Actor
    );
  } catch (err: any) {
    unauthModErr = err.message;
  }
  assert(
    unauthModErr.includes('Unauthorized') || unauthModErr.includes('COE Office'),
    'Non-COE actor is strictly prohibited from performing marks moderation',
    unauthModErr
  );

  // ===========================================================================
  // 12. Separation of Duties: Faculty Self-Approval Prevention
  // ===========================================================================
  console.log('\n--- 12. Separation of Duties: Faculty Self-Approval Prevention ---');

  // If faculty EMP-001 attempts to approve the results they submitted, it MUST be blocked
  let selfApproveErr = '';
  try {
    await devDataAdapter.coe.approveResults(examSchedule1.schedule_id, facultyActorEMP1);
  } catch (err: any) {
    selfApproveErr = err.message;
  }
  assert(
    selfApproveErr.includes('Separation of Duties') || selfApproveErr.includes('Faculty cannot approve'),
    'Separation of Duties enforced: Faculty cannot approve their own marks submissions',
    selfApproveErr
  );

  // ===========================================================================
  // 13. Result Approval & Controlled Publication Workflow
  // ===========================================================================
  console.log('\n--- 13. Result Approval & Controlled Publication Workflow ---');

  // COE approves results
  const approveOutcome = await devDataAdapter.coe.approveResults(examSchedule1.schedule_id, coeOfficeActor);
  const updatedSchedAfterApprove = await devDataAdapter.coe.getScheduleById(examSchedule1.schedule_id);
  assert(
    updatedSchedAfterApprove?.status === ExamLifecycleStatus.APPROVED && approveOutcome.approvedCount > 0,
    'COE Officer successfully approved moderated examination results',
    `Status: ${updatedSchedAfterApprove?.status}`
  );

  // COE publishes results
  const publishOutcome = await devDataAdapter.coe.publishResults(examSchedule1.schedule_id, coeOfficeActor);
  const updatedSchedAfterPublish = await devDataAdapter.coe.getScheduleById(examSchedule1.schedule_id);
  assert(
    updatedSchedAfterPublish?.status === ExamLifecycleStatus.PUBLISHED && publishOutcome.publishedCount > 0,
    'COE Officer formally published results to the institution',
    `Status: ${updatedSchedAfterPublish?.status}`
  );

  // Verify results now have PUBLISHED lifecycle_status and assigned grades
  const publishedResults = await devDataAdapter.coe.getMarks(examSchedule1.schedule_id, coeOfficeActor);
  assert(
    publishedResults.length === 2 &&
      publishedResults.every(
        (r) =>
          r.lifecycle_status === ExamLifecycleStatus.PUBLISHED &&
          Boolean(r.grade) &&
          typeof r.grade_point === 'number'
      ),
    'All cohort results transitioned to PUBLISHED with validated grades and grade points',
    `STU-001 Grade: ${publishedResults[0].grade} (${publishedResults[0].grade_point}), STU-002 Grade: ${publishedResults[1].grade} (${publishedResults[1].grade_point})`
  );

  // ===========================================================================
  // 14. Published Result Immutability & Post-Publication Correction Workflow
  // ===========================================================================
  console.log('\n--- 14. Published Result Immutability & Correction Workflow ---');

  // Attempting to overwrite draft marks on published exam fails
  let overwritePublishedErr = '';
  try {
    await devDataAdapter.coe.saveDraftMarks(
      examSchedule1.schedule_id,
      [{ student_id: 'STU-001', internal_marks: 10, external_marks: 10 }],
      coeOfficeActor
    );
  } catch (err: any) {
    overwritePublishedErr = err.message;
  }
  assert(
    overwritePublishedErr.includes('closed') || overwritePublishedErr.includes('locked') || overwritePublishedErr.includes('Cannot modify marks'),
    'Published examination cannot be directly modified or overwritten via standard entry',
    overwritePublishedErr
  );

  // Authorized post-publication correction through correctPublishedResult
  const postPubCorrection = await devDataAdapter.coe.correctPublishedResult(
    publishedResults[0].result_id,
    {
      revised_total: 49,
      reason: 'Re-evaluation Board retotalling verification: +1 mark in External Theory',
    },
    coeOfficeActor
  );
  assert(
    postPubCorrection.total_marks === 49 &&
      Array.isArray(postPubCorrection.corrections) &&
      postPubCorrection.corrections.length >= 1,
    'Post-publication correction preserves audit trail with original and revised values',
    `Revised Total: ${postPubCorrection.total_marks}, Correction reason: ${postPubCorrection.corrections?.[postPubCorrection.corrections.length - 1]?.reason}`
  );

  // ===========================================================================
  // 15. Student & Parent Isolation & Visibility Rules
  // ===========================================================================
  console.log('\n--- 15. Student & Parent Isolation Rules ---');

  // 15a. Student STU-001 can view their own published results
  const stu1Results = await devDataAdapter.coe.getStudentPublishedResults('STU-001', student1Actor);
  assert(
    Array.isArray(stu1Results) && stu1Results.some((r) => r.course_code === 'CS201'),
    'Student STU-001 can access their own published examination results',
    `Found ${stu1Results.length} published records`
  );

  // 15b. Student STU-001 cannot view results belonging to STU-002
  let stuSpyErr = '';
  try {
    await devDataAdapter.coe.getStudentPublishedResults('STU-002', student1Actor);
  } catch (err: any) {
    stuSpyErr = err.message;
  }
  assert(
    stuSpyErr.includes('Unauthorized') || stuSpyErr.includes('other students'),
    'Student isolation enforced: STU-001 blocked from accessing STU-002 examination records',
    stuSpyErr
  );

  // 15c. Parent PAR-001 with can_view_grades = true can view STU-001 published results
  const par1WardResults = await devDataAdapter.coe.getParentWardResults('PAR-001', 'STU-001', parent1Actor);
  assert(
    Array.isArray(par1WardResults) && par1WardResults.length > 0,
    'Parent PAR-001 with active link and can_view_grades=true can view ward published results',
    `Found ${par1WardResults.length} published ward results`
  );

  // 15d. Parent access blocked if can_view_grades = false or unlinked student
  let parDenialErr = '';
  try {
    await devDataAdapter.coe.getParentWardResults('PAR-002', 'STU-001', parent2Actor); // PAR-002 is not linked to STU-001
  } catch (err: any) {
    parDenialErr = err.message;
  }
  assert(
    parDenialErr.includes('Access Denied') || parDenialErr.includes('No active relationship'),
    'Parent cannot view grades of unlinked student or without permission',
    parDenialErr
  );

  // ===========================================================================
  // 16. Consolidated Transcript Summary (SGPA / CGPA) & Deletion Protection
  // ===========================================================================
  console.log('\n--- 16. Transcript Calculation & Deletion Protection ---');

  // 16a. Transcript calculation
  const transcript = await devDataAdapter.coe.getStudentTranscript('STU-001', student1Actor);
  assert(
    Boolean(
      transcript &&
        transcript.student.student_id === 'STU-001' &&
        transcript.semesterSummaries.length > 0 &&
        transcript.cgpa > 0 &&
        transcript.overallCredits > 0
    ),
    'Student transcript accurately computes semester SGPA, cumulative CGPA, and total credits',
    `CGPA: ${transcript?.cgpa}, Semesters: ${transcript?.semesterSummaries.length}, Total Credits: ${transcript?.overallCredits}`
  );

  // 16b. Prevent deletion of examination schedule that has recorded marks and published results
  let deleteBlockedErr = '';
  try {
    await devDataAdapter.coe.deleteSchedule(examSchedule1.schedule_id, coeOfficeActor);
  } catch (err: any) {
    deleteBlockedErr = err.message;
  }
  assert(
    deleteBlockedErr.toLowerCase().includes('cannot delete') || deleteBlockedErr.toLowerCase().includes('already has'),
    'Deletion protection: Examinations with attendance, marks, or published results cannot be deleted',
    deleteBlockedErr
  );

  // ===========================================================================
  // Summary
  // ===========================================================================
  console.log('\n================================================================');
  const passedCount = results.filter((r) => r.passed).length;
  const totalCount = results.length;
  console.log(`Phase 8 COE Verification Summary: ${passedCount} / ${totalCount} tests passed.`);
  console.log('================================================================');

  if (passedCount !== totalCount) {
    process.exit(1);
  }
}

runPhase8Tests().catch((err) => {
  console.error('Fatal test failure:', err);
  process.exit(1);
});
