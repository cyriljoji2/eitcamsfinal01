import { devDataAdapter } from '../src/services/devDataAdapter';
import { EmployeeCategory, EmploymentStatus, OfficeAssignmentStatus, AuthRole } from '../src/types/database';
import { PortalType } from '../src/types/portal';
import { isReservedOfficeIdentifier } from '../src/config/permanentOffices';

interface TestResult {
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];

function assert(condition: boolean, title: string, details?: string) {
  if (condition) {
    results.push({ title, passed: true, details });
    console.log(`✅ PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ title, passed: false, details });
    console.error(`❌ FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runTests() {
  console.log('=====================================================');
  console.log('   EIT Phase 5 Administration Verification Tests     ');
  console.log('=====================================================\n');

  // Test 1: Teaching Faculty Registration
  console.log('--- Test 1: Teaching Faculty Registration & Allocation ---');
  const teachingEmp = await devDataAdapter.employees.create({
    registration_number: '',
    first_name: 'Maya',
    last_name: 'Angelou',
    institutional_email: 'maya.angelou@faculty.eit.edu',
    phone_number: '+1-555-0199',
    category: EmployeeCategory.TEACHING,
    primary_department: 'CSE',
    designation: 'Associate Professor',
    date_of_joining: '2026-09-01',
    employment_status: EmploymentStatus.ACTIVE,
  });

  assert(
    teachingEmp.registration_number === 'EIT-TCH-CSE-2026-002',
    'Teaching registration number follows EIT-TCH-{DEPT}-{YEAR}-{SEQ} format',
    teachingEmp.registration_number
  );
  assert(
    teachingEmp.category === EmployeeCategory.TEACHING,
    'Employee category is TEACHING'
  );
  assert(
    Boolean(teachingEmp.employee_id),
    'Employee ID is allocated',
    teachingEmp.employee_id
  );

  // Test 2: Teaching Login with Registration Number
  console.log('\n--- Test 2: Teaching Login with Registration Number ---');
  const teachingLogin = await devDataAdapter.auth.login(
    teachingEmp.registration_number,
    'dev_mock_hash_faculty',
    PortalType.Employee
  );
  assert(
    teachingLogin.success === true && teachingLogin.session?.role === AuthRole.FACULTY,
    'Teaching faculty can authenticate via Employee Login using registration number',
    `Role: ${teachingLogin.session?.role}, User: ${teachingLogin.session?.user.username}`
  );

  // Test 3: Non-Teaching Staff Registration & Allocation
  console.log('\n--- Test 3: Non-Teaching Staff Registration & Allocation ---');
  const nonTeachingEmp = await devDataAdapter.employees.create({
    registration_number: '',
    first_name: 'Robert',
    last_name: 'Frost',
    institutional_email: 'robert.frost@admin.eit.edu',
    phone_number: '+1-555-0288',
    category: EmployeeCategory.NON_TEACHING,
    primary_department: 'ADM',
    designation: 'Assistant Registrar',
    date_of_joining: '2026-09-01',
    employment_status: EmploymentStatus.ACTIVE,
  });

  assert(
    nonTeachingEmp.registration_number === 'EIT-NTC-ADM-2026-002',
    'Non-teaching registration number follows EIT-NTC-{DEPT}-{YEAR}-{SEQ} format',
    nonTeachingEmp.registration_number
  );
  assert(
    nonTeachingEmp.category === EmployeeCategory.NON_TEACHING,
    'Employee category is NON_TEACHING'
  );
  assert(
    Boolean(nonTeachingEmp.employee_id),
    'Non-teaching Employee ID is allocated',
    nonTeachingEmp.employee_id
  );

  // Test 4: Non-Teaching Login with Registration Number
  console.log('\n--- Test 4: Non-Teaching Login with Registration Number ---');
  const staffLogin = await devDataAdapter.auth.login(
    nonTeachingEmp.registration_number,
    'dev_mock_hash_staff',
    PortalType.Employee
  );
  assert(
    staffLogin.success === true && staffLogin.session?.role === AuthRole.NON_TEACHING_STAFF,
    'Non-teaching staff can authenticate via Employee Login using registration number',
    `Role: ${staffLogin.session?.role}, User: ${staffLogin.session?.user.username}`
  );

  // Test 5: Sequential ID Allocation Uniqueness
  console.log('\n--- Test 5: Sequential ID Allocation Uniqueness ---');
  const secondTeaching = await devDataAdapter.employees.create({
    registration_number: '',
    first_name: 'Grace',
    last_name: 'Hopper',
    institutional_email: 'grace.hopper@faculty.eit.edu',
    phone_number: '+1-555-0377',
    category: EmployeeCategory.TEACHING,
    primary_department: 'CSE',
    designation: 'Distinguished Professor',
    date_of_joining: '2026-09-01',
    employment_status: EmploymentStatus.ACTIVE,
  });
  assert(
    secondTeaching.registration_number === 'EIT-TCH-CSE-2026-003',
    'Subsequent CSE faculty allocated incremented sequential registration number',
    secondTeaching.registration_number
  );

  // Test 6: Duplicate Email Prevention
  console.log('\n--- Test 6: Duplicate Email Prevention ---');
  let duplicateEmailError = '';
  try {
    await devDataAdapter.employees.create({
      registration_number: '',
      first_name: 'Duplicate',
      last_name: 'User',
      institutional_email: 'maya.angelou@faculty.eit.edu',
      phone_number: '+1-555-9999',
      category: EmployeeCategory.TEACHING,
      primary_department: 'CSE',
      designation: 'Lecturer',
      date_of_joining: '2026-09-01',
      employment_status: EmploymentStatus.ACTIVE,
    });
  } catch (err: any) {
    duplicateEmailError = err.message;
  }
  assert(
    duplicateEmailError.includes('already registered'),
    'Duplicate employee email is blocked and returns a clear descriptive error',
    duplicateEmailError
  );

  // Test 7: Reserved Permanent Office Spoofing Prevention
  console.log('\n--- Test 7: Reserved Office Identifier Protection ---');
  assert(
    isReservedOfficeIdentifier('admin') &&
    isReservedOfficeIdentifier('PO-001') &&
    isReservedOfficeIdentifier('finance') &&
    isReservedOfficeIdentifier('Admissions Office'),
    'Reserved office identifiers are correctly recognized and protected'
  );

  // Test 8: Repeat-Safe Account Provisioning
  console.log('\n--- Test 8: Repeat-Safe Account Provisioning ---');
  const reProvisionResult = await devDataAdapter.employees.provisionAccount(teachingEmp.employee_id);
  assert(
    reProvisionResult.success === true && reProvisionResult.user?.username === teachingEmp.registration_number,
    'Re-provisioning existing employee returns existing account safely without duplication',
    `User ID: ${reProvisionResult.user?.user_id}`
  );

  // Test 9: Teaching vs Non-Teaching Separation (Office Assignment Restriction)
  console.log('\n--- Test 9: Teaching vs Non-Teaching Separation in Office Assignment ---');
  let teachingAssignError = '';
  try {
    await devDataAdapter.officeAssignments.assign({
      employee_id: teachingEmp.employee_id,
      office_id: 'PO-001',
      assigned_role_title: 'Special Assistant',
      assigned_by_employee_id: 'EMP-003',
      effective_from: '2026-09-01',
      assignment_status: OfficeAssignmentStatus.ACTIVE,
    });
  } catch (err: any) {
    teachingAssignError = err.message;
  }
  assert(
    teachingAssignError.includes('Teaching faculty cannot be assigned to administrative offices'),
    'Teaching faculty are strictly prevented from administrative office assignments',
    teachingAssignError
  );

  // Test 10: Non-Teaching Staff Office Assignment
  console.log('\n--- Test 10: Non-Teaching Staff Office Assignment ---');
  const assignment1 = await devDataAdapter.officeAssignments.assign({
    employee_id: nonTeachingEmp.employee_id,
    office_id: 'PO-002',
    assigned_role_title: 'Admissions Verification Officer',
    assigned_by_employee_id: 'EMP-003',
    effective_from: '2026-09-01',
    assignment_status: OfficeAssignmentStatus.ACTIVE,
  });
  assert(
    assignment1.assignment_status === OfficeAssignmentStatus.ACTIVE && assignment1.office_id === 'PO-002',
    'Non-teaching staff successfully assigned to Admissions Office (PO-002)',
    `Assignment ID: ${assignment1.assignment_id}`
  );

  // Test 11: Prevent Duplicate Active Assignment to Same Office
  console.log('\n--- Test 11: Prevent Duplicate Active Assignment to Same Office ---');
  let duplicateAssignError = '';
  try {
    await devDataAdapter.officeAssignments.assign({
      employee_id: nonTeachingEmp.employee_id,
      office_id: 'PO-002',
      assigned_role_title: 'Admissions Lead',
      assigned_by_employee_id: 'EMP-003',
      effective_from: '2026-09-01',
      assignment_status: OfficeAssignmentStatus.ACTIVE,
    });
  } catch (err: any) {
    duplicateAssignError = err.message;
  }
  assert(
    duplicateAssignError.includes('already has an active assignment in Admissions Office'),
    'Duplicate active office assignment to the same office is blocked',
    duplicateAssignError
  );

  // Test 12: Office Assignment Transfer
  console.log('\n--- Test 12: Office Assignment Transfer ---');
  const transferNewAssignment = await devDataAdapter.officeAssignments.transfer(
    assignment1.assignment_id,
    'PO-005',
    'Finance Accounts Officer'
  );
  const updatedAssignments = await devDataAdapter.officeAssignments.getByEmployee(nonTeachingEmp.employee_id);
  const oldAssignment = updatedAssignments.find((a) => a.assignment_id === assignment1.assignment_id);
  assert(
    oldAssignment?.assignment_status === OfficeAssignmentStatus.TRANSFERRED &&
    oldAssignment?.effective_to !== undefined &&
    transferNewAssignment.office_id === 'PO-005' &&
    transferNewAssignment.assignment_status === OfficeAssignmentStatus.ACTIVE,
    'Transfer marks previous assignment as TRANSFERRED and activates new office assignment',
    `Old: ${oldAssignment?.assignment_status}, New Office: ${transferNewAssignment.office_id}`
  );

  // Test 13: Office Assignment Revocation
  console.log('\n--- Test 13: Office Assignment Revocation ---');
  await devDataAdapter.officeAssignments.revoke(transferNewAssignment.assignment_id);
  const afterRevokeAssignments = await devDataAdapter.officeAssignments.getByEmployee(nonTeachingEmp.employee_id);
  const revokedAssignment = afterRevokeAssignments.find((a) => a.assignment_id === transferNewAssignment.assignment_id);
  assert(
    revokedAssignment?.assignment_status === OfficeAssignmentStatus.REVOKED &&
    revokedAssignment?.effective_to !== undefined,
    'Revocation marks office assignment as REVOKED with effective_to timestamp',
    `Status: ${revokedAssignment?.assignment_status}`
  );

  // Test 14: Employee Directory Filter & Search
  console.log('\n--- Test 14: Employee Directory Filter & Search ---');
  const allEmployees = await devDataAdapter.employees.getAll();
  const cseFaculty = allEmployees.filter(
    (e) => e.category === EmployeeCategory.TEACHING && e.primary_department === 'CSE'
  );
  assert(
    cseFaculty.length >= 2,
    'Directory allows filtering by category and department',
    `Found ${cseFaculty.length} CSE faculty members`
  );

  // Test 15: Edit Permitted Details & Update
  console.log('\n--- Test 15: Edit Permitted Details ---');
  const updatedEmp = await devDataAdapter.employees.update(nonTeachingEmp.employee_id, {
    phone_number: '+1-555-8899',
    designation: 'Senior Registrar Associate',
    primary_department: 'ADM',
    employment_status: EmploymentStatus.ACTIVE,
  });
  assert(
    updatedEmp.phone_number === '+1-555-8899' &&
    updatedEmp.designation === 'Senior Registrar Associate' &&
    updatedEmp.registration_number === nonTeachingEmp.registration_number &&
    updatedEmp.category === EmployeeCategory.NON_TEACHING,
    'Permitted details updated while immutable fields (registration_number, category) remain protected',
    `Designation: ${updatedEmp.designation}`
  );

  // Test 16: Employment Status Suspension Sync
  console.log('\n--- Test 16: Employment Status & Account Status Sync ---');
  await devDataAdapter.employees.update(nonTeachingEmp.employee_id, {
    employment_status: EmploymentStatus.TERMINATED,
  });
  const suspendedLogin = await devDataAdapter.auth.login(
    nonTeachingEmp.registration_number,
    'dev_mock_hash_staff',
    PortalType.Employee
  );
  assert(
    Boolean(suspendedLogin.success === false && suspendedLogin.error?.includes('currently SUSPENDED')),
    'Terminating employee automatically suspends linked AuthUserRecord and prevents login',
    suspendedLogin.error
  );

  // Summary
  console.log('\n=====================================================');
  const total = results.length;
  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log(`TOTAL TESTS: ${total} | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('=====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
