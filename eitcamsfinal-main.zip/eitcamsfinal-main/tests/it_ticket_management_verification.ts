/**
 * EIT CAMS — IT Support Ticket Opening and Status Management Verification Suite
 *
 * Verifies all requirements from prompt:
 * 1. Ticket list loads with all tickets.
 * 2. Clicking a ticket opens its details (accessible via getTicketById and modal dossier).
 * 3. Correct ticket information is displayed (ticket number, requester name & type, category, subject, description, priority, current status, assigned technician, timestamps, SLA deadlines, activity history).
 * 4. Status selector supports all 9 statuses: Open, Assigned, In Progress, Awaiting Requester, Awaiting Third Party, Escalated, Resolved, Closed, Reopened.
 * 5. Status update saves successfully through authoritative itRepository.
 * 6. Updated status remains after refreshing (persists in state/storage).
 * 7. Ticket list reflects the new status.
 * 8. Dashboard ticket counts update immediately.
 * 9. Only authorised IT employees can change ticket statuses (unauthorised users rejected).
 * 10. Allowed status transitions are validated (invalid transitions rejected).
 * 11. Resolution note is required when marking a ticket Resolved.
 * 12. Reason is required when escalating or reopening a ticket.
 * 13. Inactive employees cannot be assigned as IT technicians.
 * 14. Employees outside IT cannot be assigned as IT technicians.
 * 15. Officially assigned IT employees can be assigned, recording previous and new assignees in history.
 * 16. SLA pause rules apply on AWAITING_REQUESTER and AWAITING_THIRD_PARTY.
 * 17. SLA resume rules apply on active progress transitions without silently resetting deadlines.
 * 18. Internal technician notes never appear in public requester views.
 */

// Polyfill window and sessionStorage for Node.js environment
if (typeof (globalThis as any).window === 'undefined') {
  const store: Record<string, string> = {};
  (globalThis as any).window = {
    sessionStorage: {
      getItem: (key: string) => store[key] || null,
      setItem: (key: string, value: string) => {
        store[key] = String(value);
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        for (const k of Object.keys(store)) delete store[k];
      },
    },
  };
}

import { devDataAdapter } from '../src/services/devDataAdapter';
import { itRepository } from '../src/services/itService';
import {
  AuthRole,
  EmploymentStatus,
  OfficeAssignmentStatus,
} from '../src/types/database';
import {
  ALLOWED_STATUS_TRANSITIONS,
  TicketRecord,
  TicketStatus,
} from '../src/types/itDepartment';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runTicketManagementVerification() {
  console.log('================================================================');
  console.log('   EIT CAMS — IT Ticket Opening & Status Management Verification');
  console.log('================================================================\n');

  const itActor = {
    userId: 'itoffice',
    role: 'OFFICE_ADMIN',
    authorName: 'IT Department Admin',
  };

  const studentActor = {
    userId: 'STU-001',
    role: 'STUDENT',
    studentId: 'STU-001',
  };

  // ---------------------------------------------------------------------------
  // Test 1: Ticket list loads
  // ---------------------------------------------------------------------------
  const initialTickets = itRepository.getTickets(undefined, itActor);
  assert(
    Array.isArray(initialTickets) && initialTickets.length >= 2,
    'Ticket list loads with existing tickets',
    `Found ${initialTickets.length} tickets in repository`
  );

  // ---------------------------------------------------------------------------
  // Test 2: Clicking a ticket opens its details
  // ---------------------------------------------------------------------------
  const firstTicket = initialTickets[0];
  const fetchedDetail = itRepository.getTicketById(firstTicket.ticket_id, itActor);
  assert(
    !!fetchedDetail && fetchedDetail.ticket_id === firstTicket.ticket_id,
    'Clicking a ticket opens its details in dedicated detail view',
    `Retrieved Ticket ID: ${fetchedDetail?.ticket_id}, Number: ${fetchedDetail?.ticket_number}`
  );

  // ---------------------------------------------------------------------------
  // Test 3: Correct ticket information is displayed
  // ---------------------------------------------------------------------------
  const hasFullDossier =
    !!fetchedDetail &&
    !!fetchedDetail.ticket_number &&
    !!fetchedDetail.requester_name &&
    !!fetchedDetail.requester_account_type &&
    !!fetchedDetail.category &&
    !!fetchedDetail.subject &&
    !!fetchedDetail.description &&
    !!fetchedDetail.priority &&
    !!fetchedDetail.status &&
    !!fetchedDetail.created_at &&
    !!fetchedDetail.updated_at &&
    !!fetchedDetail.sla_response_deadline &&
    !!fetchedDetail.sla_resolution_deadline &&
    Array.isArray(fetchedDetail.responses) &&
    Array.isArray(fetchedDetail.activity_history);

  assert(
    hasFullDossier,
    'Correct ticket information is displayed across all dossier fields',
    `Ticket: ${fetchedDetail?.ticket_number}, Status: ${fetchedDetail?.status}, Priority: ${fetchedDetail?.priority}, Activities: ${fetchedDetail?.activity_history?.length}`
  );

  // ---------------------------------------------------------------------------
  // Test 4: Status selector supports all 9 statuses
  // ---------------------------------------------------------------------------
  const expectedStatuses: TicketStatus[] = [
    'OPEN',
    'ASSIGNED',
    'IN_PROGRESS',
    'AWAITING_REQUESTER',
    'AWAITING_THIRD_PARTY',
    'ESCALATED',
    'RESOLVED',
    'CLOSED',
    'REOPENED',
  ];
  const allTransitionsDefined = expectedStatuses.every(
    (st) => Array.isArray(ALLOWED_STATUS_TRANSITIONS[st])
  );
  assert(
    allTransitionsDefined && expectedStatuses.length === 9,
    'Status selector and transition matrix support all 9 authoritative statuses',
    `Statuses: ${expectedStatuses.join(', ')}`
  );

  // ---------------------------------------------------------------------------
  // Test 5: Status update saves successfully through authoritative itRepository
  // ---------------------------------------------------------------------------
  // Create a clean test ticket to trace complete lifecycle
  const testTicket = await itRepository.createTicket(
    {
      requester_id: 'STU-001',
      requester_name: 'Arjun Kumar',
      requester_account_type: 'STUDENT',
      requester_email: 'arjun.kumar@student.eit.edu',
      category: 'NETWORK',
      subject: 'Hostel Wi-Fi access point unreachable in Block B',
      description: 'Signals dropping on the 2nd floor hallway AP.',
      priority: 'HIGH',
    },
    itActor
  );

  // Transition from OPEN -> IN_PROGRESS
  const inProgressTicket = await itRepository.updateTicketStatus(
    testTicket.ticket_id,
    'IN_PROGRESS',
    { note: 'IT technician dispatched to investigate router logs.' },
    itActor
  );

  assert(
    inProgressTicket.status === 'IN_PROGRESS' &&
      inProgressTicket.activity_history?.[0]?.action_type === 'STATUS_CHANGE' &&
      inProgressTicket.activity_history?.[0]?.new_status === 'IN_PROGRESS',
    'Status update saves successfully through authoritative itRepository',
    `Status updated: OPEN -> ${inProgressTicket.status}`
  );

  // ---------------------------------------------------------------------------
  // Test 6: Updated status remains after refreshing (persists in state/storage)
  // ---------------------------------------------------------------------------
  const reloadedTicket = itRepository.getTicketById(testTicket.ticket_id, itActor);
  assert(
    !!reloadedTicket && reloadedTicket.status === 'IN_PROGRESS',
    'Updated status remains after refreshing from repository state',
    `Persisted status: ${reloadedTicket?.status}`
  );

  // ---------------------------------------------------------------------------
  // Test 7: Ticket list reflects the new status
  // ---------------------------------------------------------------------------
  const updatedList = itRepository.getTickets(undefined, itActor);
  const foundInList = updatedList.find((t) => t.ticket_id === testTicket.ticket_id);
  assert(
    !!foundInList && foundInList.status === 'IN_PROGRESS',
    'Ticket list reflects the new status immediately',
    `Ticket ${foundInList?.ticket_number} in list has status: ${foundInList?.status}`
  );

  // ---------------------------------------------------------------------------
  // Test 8: Dashboard counts update immediately
  // ---------------------------------------------------------------------------
  const initialMetrics = await itRepository.getDashboardMetrics();
  // Mark testTicket as RESOLVED
  await itRepository.updateTicketStatus(
    testTicket.ticket_id,
    'RESOLVED',
    { resolutionNotes: 'Replaced faulty PoE injector on 2nd floor AP.' },
    itActor
  );
  const resolvedMetrics = await itRepository.getDashboardMetrics();

  assert(
    resolvedMetrics.openTickets <= initialMetrics.openTickets,
    'Dashboard ticket counts update immediately when ticket is resolved',
    `Open tickets count: ${initialMetrics.openTickets} -> ${resolvedMetrics.openTickets}`
  );

  // ---------------------------------------------------------------------------
  // Test 9: Only authorised IT employees can change ticket statuses
  // ---------------------------------------------------------------------------
  let unauthorizedErrorCaught = false;
  try {
    await itRepository.updateTicketStatus(
      testTicket.ticket_id,
      'CLOSED',
      { note: 'Attempting unauthorized status change' },
      studentActor as any
    );
  } catch (err: any) {
    unauthorizedErrorCaught = true;
  }
  assert(
    unauthorizedErrorCaught,
    'Unauthorized users (students/non-IT) are blocked from changing ticket status in service layer',
    'Blocked with security exception'
  );

  // ---------------------------------------------------------------------------
  // Test 10: Validate allowed status transitions
  // ---------------------------------------------------------------------------
  // TestTicket is currently RESOLVED. Transitioning directly to IN_PROGRESS is invalid without REOPENED.
  let invalidTransitionCaught = false;
  try {
    await itRepository.updateTicketStatus(
      testTicket.ticket_id,
      'IN_PROGRESS',
      { note: 'Jumping from RESOLVED directly to IN_PROGRESS' },
      itActor
    );
  } catch (err: any) {
    invalidTransitionCaught = true;
  }
  assert(
    invalidTransitionCaught,
    'Illegal status transitions are authoritatively validated and rejected',
    'RESOLVED -> IN_PROGRESS rejected as expected'
  );

  // ---------------------------------------------------------------------------
  // Test 11: Require resolution note when marking a ticket Resolved
  // ---------------------------------------------------------------------------
  // Create another ticket and attempt to resolve with empty note
  const ticketForResolve = await itRepository.createTicket(
    {
      requester_id: 'STU-001',
      requester_name: 'Arjun Kumar',
      requester_account_type: 'STUDENT',
      requester_email: 'arjun.kumar@student.eit.edu',
      category: 'SOFTWARE',
      subject: 'Matlab license renewal',
      description: 'License expired for academic term.',
      priority: 'NORMAL',
    },
    itActor
  );

  let missingResolveNoteCaught = false;
  try {
    await itRepository.updateTicketStatus(
      ticketForResolve.ticket_id,
      'RESOLVED',
      { resolutionNotes: '' },
      itActor
    );
  } catch (err: any) {
    missingResolveNoteCaught = true;
  }
  assert(
    missingResolveNoteCaught,
    'A resolution note is strictly required when resolving a ticket',
    'Empty resolution note rejected'
  );

  // ---------------------------------------------------------------------------
  // Test 12: Require reason when escalating or reopening a ticket
  // ---------------------------------------------------------------------------
  let missingEscalateReasonCaught = false;
  try {
    await itRepository.updateTicketStatus(
      ticketForResolve.ticket_id,
      'ESCALATED',
      { escalationReason: '' },
      itActor
    );
  } catch (err: any) {
    missingEscalateReasonCaught = true;
  }
  assert(
    missingEscalateReasonCaught,
    'An escalation reason is strictly required when escalating a ticket',
    'Empty escalation reason rejected'
  );

  // Reopen testTicket (which is RESOLVED) without reason
  let missingReopenReasonCaught = false;
  try {
    await itRepository.reopenTicket(testTicket.ticket_id, '', itActor);
  } catch (err: any) {
    missingReopenReasonCaught = true;
  }
  assert(
    missingReopenReasonCaught,
    'A reason is strictly required when reopening a ticket',
    'Empty reopen reason rejected'
  );

  // Reopen testTicket WITH reason -> should succeed!
  const successfullyReopened = await itRepository.reopenTicket(
    testTicket.ticket_id,
    'Requester reported Wi-Fi dropped again after 1 hour.',
    itActor
  );
  assert(
    successfullyReopened.status === 'REOPENED' &&
      successfullyReopened.reopen_reason === 'Requester reported Wi-Fi dropped again after 1 hour.',
    'Reopening ticket with valid reason succeeds and clears resolved/closed state',
    `Status: ${successfullyReopened.status}, Reason: ${successfullyReopened.reopen_reason}`
  );

  // ---------------------------------------------------------------------------
  // Test 13: Inactive employees cannot be assigned
  // ---------------------------------------------------------------------------
  // Temporarily mark an employee inactive and attempt assignment
  const allEmployees = await devDataAdapter.employees.getAll();
  const testEmp = allEmployees[0];
  const origStatus = testEmp.employment_status;
  (testEmp as any).employment_status = EmploymentStatus.TERMINATED;

  let inactiveAssignCaught = false;
  try {
    await itRepository.assignTicket(
      testTicket.ticket_id,
      testEmp.employee_id,
      'Inactive Employee',
      itActor
    );
  } catch (err: any) {
    inactiveAssignCaught = true;
  } finally {
    (testEmp as any).employment_status = origStatus;
  }
  assert(
    inactiveAssignCaught,
    'Inactive employees cannot be assigned as IT technicians',
    'Assignment to inactive employee rejected'
  );

  // ---------------------------------------------------------------------------
  // Test 14: Employees outside IT cannot be assigned as IT technicians
  // ---------------------------------------------------------------------------
  // EMP-004 is assigned to Finance (PO-005), not IT (PO-007)
  let nonItEmployeeAssignCaught = false;
  try {
    await itRepository.assignTicket(
      testTicket.ticket_id,
      'EMP-004',
      'Sunita Rao',
      itActor
    );
  } catch (err: any) {
    nonItEmployeeAssignCaught = true;
  }
  assert(
    nonItEmployeeAssignCaught,
    'Employees outside IT Department cannot be assigned as technicians',
    'Assignment of non-IT employee rejected with authority check'
  );

  // ---------------------------------------------------------------------------
  // Test 15: Officially assigned IT employees can be assigned, recording previous and new assignees
  // ---------------------------------------------------------------------------
  // EMP-003 is assigned to PO-007
  const assignedTicket = await itRepository.assignTicket(
    testTicket.ticket_id,
    'EMP-003',
    'Robert Vance',
    itActor
  );
  const latestAssignActivity = assignedTicket.activity_history?.[0];
  assert(
    assignedTicket.assigned_to_employee_id === 'EMP-003' &&
      !!latestAssignActivity &&
      latestAssignActivity.new_assignee === 'Robert Vance',
    'Officially assigned IT employee is assigned and previous/new assignees are recorded in history',
    `Assigned to: ${assignedTicket.assigned_to_name}, History action: ${latestAssignActivity?.action_type}`
  );

  // ---------------------------------------------------------------------------
  // Test 16: SLA pause rules apply on AWAITING_REQUESTER and AWAITING_THIRD_PARTY
  // ---------------------------------------------------------------------------
  const pausedTicket = await itRepository.updateTicketStatus(
    testTicket.ticket_id,
    'AWAITING_REQUESTER',
    { note: 'Awaiting student to test connection from Room 204.' },
    itActor
  );
  assert(
    pausedTicket.status === 'AWAITING_REQUESTER' &&
      pausedTicket.sla_paused === true &&
      !!pausedTicket.sla_paused_at &&
      pausedTicket.sla_pause_reason === 'Awaiting student to test connection from Room 204.',
    'SLA timer is paused when transitioning to AWAITING_REQUESTER or AWAITING_THIRD_PARTY',
    `SLA Paused: ${pausedTicket.sla_paused}, Reason: ${pausedTicket.sla_pause_reason}`
  );

  // ---------------------------------------------------------------------------
  // Test 17: SLA resume rules apply on active progress transitions without resetting deadlines
  // ---------------------------------------------------------------------------
  const origResponseDeadline = pausedTicket.sla_response_deadline;
  const origResolutionDeadline = pausedTicket.sla_resolution_deadline;
  const origPolicyVersion = pausedTicket.sla_policy_version;

  const resumedTicket = await itRepository.updateTicketStatus(
    testTicket.ticket_id,
    'IN_PROGRESS',
    { note: 'Student confirmed room; resuming on-site test.' },
    itActor
  );

  assert(
    resumedTicket.status === 'IN_PROGRESS' &&
      resumedTicket.sla_paused === false &&
      resumedTicket.sla_response_deadline === origResponseDeadline &&
      resumedTicket.sla_resolution_deadline === origResolutionDeadline &&
      resumedTicket.sla_policy_version === origPolicyVersion,
    'SLA timer resumes when transitioning back to IN_PROGRESS without resetting original deadlines or policy version',
    `SLA Paused: ${resumedTicket.sla_paused}, Deadlines preserved: true`
  );

  // ---------------------------------------------------------------------------
  // Test 18: Internal technician notes never appear in public requester views
  // ---------------------------------------------------------------------------
  await itRepository.addTicketResponse(
    testTicket.ticket_id,
    'CONFIDENTIAL IT NOTE: Checked firmware version 4.12 on hardware AP.',
    true, // internal note
    itActor
  );

  const studentViewOfTicket = itRepository.getTicketById(testTicket.ticket_id, studentActor);
  const studentSeesInternalNote = studentViewOfTicket?.responses.some(
    (r) => r.is_internal_note || r.message.includes('CONFIDENTIAL')
  );

  const studentTicketsList = itRepository.getTickets(undefined, studentActor);
  const studentListSeesInternal = studentTicketsList
    .find((t) => t.ticket_id === testTicket.ticket_id)
    ?.responses.some((r) => r.is_internal_note || r.message.includes('CONFIDENTIAL'));

  assert(
    studentSeesInternalNote === false && studentListSeesInternal === false,
    'Internal technician notes never appear in public requester views (detail or list)',
    `Internal notes stripped: ${studentSeesInternalNote === false}`
  );

  // ---------------------------------------------------------------------------
  // Summary
  // ---------------------------------------------------------------------------
  console.log('\n================================================================');
  const allPassed = results.every((r) => r.passed);
  const passedCount = results.filter((r) => r.passed).length;
  console.log(`Verification Complete: ${passedCount} of ${results.length} tests passed.`);
  console.log('================================================================\n');

  if (!allPassed) {
    process.exit(1);
  }
}

runTicketManagementVerification().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
