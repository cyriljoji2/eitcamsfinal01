/**
 * EIT CAMS — IT Department Login & Freeze Fix Verification Suite
 *
 * Verifies the 11 targeted acceptance criteria:
 * 1. IT account exists in development data.
 * 2. IT account is ACTIVE.
 * 3. itoffice appears in Employee Login Quick-Fill.
 * 4. Quick-Fill populates the correct development credential.
 * 5. IT login succeeds with the development credentials.
 * 6. Successful login routes to the IT workspace.
 * 7. IT dashboard initial loading completes.
 * 8. Parent refresh does not cause an infinite render loop.
 * 9. Periodic refresh does not create overlapping requests.
 * 10. Logout returns to the landing page / clears session.
 * 11. Existing six permanent office logins remain functional.
 */

import fs from 'fs';
import path from 'path';
import { devDataAdapter } from '../src/services/devDataAdapter';
import { itRepository } from '../src/services/itService';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';
import { PortalType } from '../src/types/portal';
import { AccountStatus, AuthRole, PermanentOfficeKey } from '../src/types/database';

interface TestCase {
  id: number;
  description: string;
  run: () => Promise<{ passed: boolean; details?: string }>;
}

const tests: TestCase[] = [
  {
    id: 1,
    description: 'IT account exists in development data',
    run: async () => {
      const users = (devDataAdapter as any).state?.users || [];
      const itUser = users.find((u: any) => u.username === 'itoffice');
      if (!itUser) {
        return { passed: false, details: 'itoffice account missing from dev store' };
      }
      return {
        passed: itUser.user_id === 'USR-PO-007' && itUser.linked_record_id === 'PO-007',
        details: `User ID: ${itUser.user_id}, Linked: ${itUser.linked_record_id}`,
      };
    },
  },
  {
    id: 2,
    description: 'IT account is ACTIVE',
    run: async () => {
      const users = (devDataAdapter as any).state?.users || [];
      const itUser = users.find((u: any) => u.username === 'itoffice');
      const itOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id === 'PO-007');
      const isActive = itUser?.account_status === AccountStatus.ACTIVE && itOffice?.status === 'ACTIVE';
      return {
        passed: isActive,
        details: `User status: ${itUser?.account_status}, Office status: ${itOffice?.status}`,
      };
    },
  },
  {
    id: 3,
    description: 'itoffice appears in Employee Login Quick-Fill',
    run: async () => {
      const loginPagePath = path.resolve(process.cwd(), 'src/components/auth/LoginPage.tsx');
      const content = fs.readFileSync(loginPagePath, 'utf-8');
      const hasItofficeInQuickFill = content.includes("'itoffice'");
      return {
        passed: hasItofficeInQuickFill,
        details: hasItofficeInQuickFill ? 'itoffice button present in LoginPage' : 'itoffice missing in quick-fill list',
      };
    },
  },
  {
    id: 4,
    description: 'Quick-Fill populates the correct development credential',
    run: async () => {
      const loginPagePath = path.resolve(process.cwd(), 'src/components/auth/LoginPage.tsx');
      const content = fs.readFileSync(loginPagePath, 'utf-8');
      const hasDevPassword = content.includes("setPassword('dev_test_password')");
      // Test that the quick-fill password authenticates successfully
      const loginRes = await devDataAdapter.auth.login('itoffice', 'dev_test_password', PortalType.Employee);
      return {
        passed: hasDevPassword && loginRes.success,
        details: `Password configured correctly and auth check passed: ${loginRes.success}`,
      };
    },
  },
  {
    id: 5,
    description: 'IT login succeeds with the development credentials',
    run: async () => {
      const loginRes = await devDataAdapter.auth.login('itoffice', 'dev_test_password', PortalType.Employee);
      const isOk =
        loginRes.success &&
        loginRes.session?.user?.username === 'itoffice' &&
        loginRes.session?.role === AuthRole.OFFICE_ADMIN &&
        loginRes.session?.portalType === PortalType.Employee;
      return {
        passed: isOk,
        details: `User: ${loginRes.session?.username}, Role: ${loginRes.session?.role}`,
      };
    },
  },
  {
    id: 6,
    description: 'Successful login routes to the IT workspace',
    run: async () => {
      const loginRes = await devDataAdapter.auth.login('itoffice', 'dev_test_password', PortalType.Employee);
      const session = loginRes.session!;

      // Emulate routing checks from App.tsx and EmployeeDashboardView.tsx
      const isItOfficeActive =
        session.activeOfficeKey?.toLowerCase() === 'it' ||
        session.permanentOffice?.office_id === 'PO-007' ||
        session.permanentOffice?.office_key?.toLowerCase() === 'it' ||
        session.user?.username === 'itoffice';

      const isAdministrationOffice =
        session.user?.username === 'admin' ||
        session.permanentOffice?.office_id === 'PO-001';

      return {
        passed: isItOfficeActive && !isAdministrationOffice,
        details: `isItOffice: ${isItOfficeActive}, isAdministrationOffice: ${isAdministrationOffice}`,
      };
    },
  },
  {
    id: 7,
    description: 'IT dashboard initial loading completes',
    run: async () => {
      const metrics = await itRepository.getDashboardMetrics();
      const tickets = itRepository.getTickets();
      const idCards = itRepository.getAllIdCards();
      const isLoaded =
        metrics &&
        typeof metrics.totalItEmployees === 'number' &&
        Array.isArray(tickets) &&
        Array.isArray(idCards);
      return {
        passed: isLoaded,
        details: `Employees: ${metrics.totalItEmployees}, Tickets: ${tickets.length}, ID Cards: ${idCards.length}`,
      };
    },
  },
  {
    id: 8,
    description: 'Parent refresh does not cause an infinite render loop',
    run: async () => {
      // Verify ItOfficeSection uses useCallback and does not re-instantiate handleRefresh
      const itOfficeSectionPath = path.resolve(process.cwd(), 'src/components/ItOfficeSection.tsx');
      const itSectionContent = fs.readFileSync(itOfficeSectionPath, 'utf-8');
      const hasUseCallback =
        itSectionContent.includes('useCallback') &&
        itSectionContent.includes('handleRefresh = useCallback');

      // Verify ItWorkspace decouples onRefreshData and does not call it on initial mount
      const itWorkspacePath = path.resolve(process.cwd(), 'src/components/it/ItWorkspace.tsx');
      const itWorkspaceContent = fs.readFileSync(itWorkspacePath, 'utf-8');
      const decouplesOnRefreshData =
        itWorkspaceContent.includes('onRefreshDataRef = useRef') &&
        itWorkspaceContent.includes('loadInitialData = useCallback');

      let refreshCount = 0;
      const mockParentRefresh = async () => {
        refreshCount++;
      };

      // Simulating call through stabilized handler
      if (mockParentRefresh) {
        await mockParentRefresh();
      }

      return {
        passed: hasUseCallback && decouplesOnRefreshData && refreshCount === 1,
        details: `useCallback present: ${hasUseCallback}, onRefreshData decoupled: ${decouplesOnRefreshData}`,
      };
    },
  },
  {
    id: 9,
    description: 'Periodic refresh does not create overlapping requests',
    run: async () => {
      const itWorkspacePath = path.resolve(process.cwd(), 'src/components/it/ItWorkspace.tsx');
      const itWorkspaceContent = fs.readFileSync(itWorkspacePath, 'utf-8');
      const hasOverlappingGuard =
        itWorkspaceContent.includes('isRefreshingRef = useRef') &&
        itWorkspaceContent.includes('if (isRefreshingRef.current)');

      return {
        passed: hasOverlappingGuard,
        details: hasOverlappingGuard ? 'isRefreshingRef lock present and active' : 'Guard missing',
      };
    },
  },
  {
    id: 10,
    description: 'Logout returns to the landing page / clears session',
    run: async () => {
      if (typeof window === 'undefined') {
        const store = new Map<string, string>();
        (globalThis as any).window = {
          sessionStorage: {
            getItem: (k: string) => store.get(k) || null,
            setItem: (k: string, v: string) => store.set(k, v),
            removeItem: (k: string) => store.delete(k),
          },
        };
      }

      const loginRes = await devDataAdapter.auth.login('itoffice', 'dev_test_password', PortalType.Employee);
      const sessionBefore = await devDataAdapter.auth.getCurrentSession();
      await devDataAdapter.auth.logout();
      const sessionAfter = await devDataAdapter.auth.getCurrentSession();

      return {
        passed: loginRes.success && sessionBefore !== null && sessionAfter === null,
        details: `Session before: ${sessionBefore?.username || 'null'}, Session after: ${sessionAfter || 'null'}`,
      };
    },
  },
  {
    id: 11,
    description: 'Existing six permanent office logins remain functional',
    run: async () => {
      const offices = [
        { username: 'admin', expectedRole: AuthRole.SUPER_ADMIN },
        { username: 'admissionsoffice', expectedRole: AuthRole.OFFICE_ADMIN },
        { username: 'academicoffice', expectedRole: AuthRole.OFFICE_ADMIN },
        { username: 'coeoffice', expectedRole: AuthRole.OFFICE_ADMIN },
        { username: 'finance', expectedRole: AuthRole.OFFICE_ADMIN },
        { username: 'hosteloffice', expectedRole: AuthRole.OFFICE_ADMIN },
      ];

      for (const off of offices) {
        const res = await devDataAdapter.auth.login(off.username, 'dev_test_password', PortalType.Employee);
        if (!res.success) {
          return { passed: false, details: `Failed login for permanent office: ${off.username}` };
        }
        if (res.session?.role !== off.expectedRole) {
          return {
            passed: false,
            details: `Mismatched role for ${off.username}: expected ${off.expectedRole}, got ${res.session?.role}`,
          };
        }
      }

      return {
        passed: true,
        details: 'All 6 permanent offices authenticated with correct roles and credentials',
      };
    },
  },
];

async function run() {
  console.log('================================================================');
  console.log('   EIT CAMS — IT Department Login & Freeze Fix Verification Suite');
  console.log('================================================================\n');

  let passedCount = 0;
  for (const tc of tests) {
    try {
      const result = await tc.run();
      if (result.passed) {
        passedCount++;
        console.log(`✅ [Test ${tc.id}] PASS: ${tc.description}${result.details ? ` (${result.details})` : ''}`);
      } else {
        console.error(`❌ [Test ${tc.id}] FAIL: ${tc.description}${result.details ? ` (${result.details})` : ''}`);
      }
    } catch (e: any) {
      console.error(`❌ [Test ${tc.id}] EXCEPTION: ${tc.description} (${e?.message || e})`);
    }
  }

  console.log('\n================================================================');
  console.log(`Verification Complete: ${passedCount} of ${tests.length} tests passed.`);
  console.log('================================================================\n');

  if (passedCount !== tests.length) {
    process.exit(1);
  }
}

run();
