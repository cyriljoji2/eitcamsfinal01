import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  AuthRole,
  FacultyCourseRole,
  AttendanceStatus,
  ExamStatus,
} from '../src/types/database';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runPhase7Tests() {
  console.log('================================================================');
  console.log('   EIT Phase 7 Academic Office & Faculty Verification Tests     ');
  console.log('================================================================\n');

  // Actors
  const superAdminActor = { userId: 'admin', role: AuthRole.SUPER_ADMIN };
  const academicOfficeActor = { userId: 'academicoffice', role: AuthRole.OFFICE_ADMIN };
  const facultyActorEMP1 = { userId: 'EMP-001', role: AuthRole.FACULTY, employeeId: 'EMP-001' };
  const facultyActorEMP2 = { userId: 'EMP-002', role: AuthRole.FACULTY, employeeId: 'EMP-002' };
  const studentActor = { userId: 'STU-001', role: AuthRole.STUDENT };
  const parentActor = { userId: 'PAR-001', role: AuthRole.PARENT };
  const financeActor = { userId: 'finance', role: AuthRole.OFFICE_ADMIN };

  // ===========================================================================
  // 1. Academic Office Access & Unauthorized-Role Rejection
  // ===========================================================================
  console.log('--- 1. Academic Office Access & Unauthorized Rejection ---');
  
  // 1.1 Super Admin can access academic structure
  const depts = await devDataAdapter.academic.getDepartments();
  assert(
    Array.isArray(depts) && depts.length >= 4,
    'Super Admin can access academic structure and departments',
    `Found ${depts.length} departments`
  );

  // 1.2 Canonical Academic Office account (academicoffice) can manage courses
  const testCourseCode = `CS701`;
  const createdCourse = await devDataAdapter.academic.createCourse(
    {
      course_code: testCourseCode,
      course_title: 'Advanced Distributed Systems',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      semester: 5,
      credits: 4,
      course_type: 'THEORY',
      status: 'ACTIVE',
    },
    academicOfficeActor
  );
  assert(
    Boolean(createdCourse && createdCourse.course_code === testCourseCode),
    'Canonical Academic Office account (academicoffice) can create curriculum courses',
    createdCourse.course_code
  );

  // 1.3 Faculty role cannot perform administrative course creation
  let facultyErr = '';
  try {
    await devDataAdapter.academic.createCourse(
      {
        course_code: 'UNAUTH-101',
        course_title: 'Unauthorized Faculty Course',
        department: 'CSE',
        programme_code: 'BTECH-CSE',
        semester: 3,
        credits: 3,
        course_type: 'THEORY',
        status: 'ACTIVE',
      },
      facultyActorEMP1
    );
  } catch (err: any) {
    facultyErr = err.message;
  }
  assert(
    facultyErr.includes('Unauthorized') || facultyErr.includes('Academic Office'),
    'Teaching Faculty role rejected from creating curriculum courses',
    facultyErr
  );

  // 1.4 Student and Parent roles rejected
  let stuErr = '';
  try {
    await devDataAdapter.academic.createCourse(
      {
        course_code: 'STU-UNAUTH',
        course_title: 'Student Course',
        department: 'CSE',
        programme_code: 'BTECH-CSE',
        semester: 1,
        credits: 3,
        course_type: 'THEORY',
        status: 'ACTIVE',
      },
      studentActor
    );
  } catch (err: any) {
    stuErr = err.message;
  }
  assert(
    stuErr.includes('Unauthorized') || stuErr.includes('Academic Office'),
    'Student role rejected from Academic Office administration',
    stuErr
  );

  let parErr = '';
  try {
    await devDataAdapter.academic.createCourse(
      {
        course_code: 'PAR-UNAUTH',
        course_title: 'Parent Course',
        department: 'CSE',
        programme_code: 'BTECH-CSE',
        semester: 1,
        credits: 3,
        course_type: 'THEORY',
        status: 'ACTIVE',
      },
      parentActor
    );
  } catch (err: any) {
    parErr = err.message;
  }
  assert(
    parErr.includes('Unauthorized') || parErr.includes('Academic Office'),
    'Parent role rejected from Academic Office administration',
    parErr
  );

  // 1.5 Unrelated office employee without PO-003 delegation rejected
  let finErr = '';
  try {
    await devDataAdapter.academic.createCourse(
      {
        course_code: 'FIN-UNAUTH',
        course_title: 'Finance Office Unauth Course',
        department: 'CSE',
        programme_code: 'BTECH-CSE',
        semester: 1,
        credits: 3,
        course_type: 'THEORY',
        status: 'ACTIVE',
      },
      financeActor
    );
  } catch (err: any) {
    finErr = err.message;
  }
  assert(
    finErr.includes('Unauthorized') || finErr.includes('Academic Office'),
    'Unrelated office account (finance) rejected without Academic Office delegation',
    finErr
  );

  // ===========================================================================
  // 2. Academic Structure Management & Validation
  // ===========================================================================
  console.log('\n--- 2. Academic Structure Management & Validation ---');
  
  // 2.1 Academic Years and Semesters
  const ayList = await devDataAdapter.academic.getAcademicYears();
  const semList = await devDataAdapter.academic.getSemesters();
  assert(
    ayList.length >= 1 && semList.length >= 2,
    'Academic years and semesters accessible',
    `${ayList.length} AYs, ${semList.length} Semesters`
  );

  // 2.2 Duplicate course code prevention
  let dupCourseErr = '';
  try {
    await devDataAdapter.academic.createCourse(
      {
        course_code: testCourseCode, // duplicate
        course_title: 'Duplicate Attempt',
        department: 'CSE',
        programme_code: 'BTECH-CSE',
        semester: 5,
        credits: 4,
        course_type: 'THEORY',
        status: 'ACTIVE',
      },
      academicOfficeActor
    );
  } catch (err: any) {
    dupCourseErr = err.message;
  }
  assert(
    dupCourseErr.includes('already exists') || dupCourseErr.includes('unique'),
    'Duplicate course code strictly rejected with descriptive error',
    dupCourseErr
  );

  // 2.3 Section creation & academic association
  const createdSection = await devDataAdapter.academic.createSection(
    {
      section_name: 'C',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      max_capacity: 60,
      status: 'ACTIVE',
    },
    academicOfficeActor
  );
  assert(
    Boolean(createdSection && createdSection.section_name === 'C'),
    'Authorized user can create section associated with academic year and semester',
    `Section: ${createdSection.section_name} (${createdSection.section_id})`
  );

  // ===========================================================================
  // 3. Course Offering Creation & Duplicate Prevention
  // ===========================================================================
  console.log('\n--- 3. Course Offering Creation & Duplicate Prevention ---');
  
  const offering = await devDataAdapter.academic.createCourseOffering(
    {
      course_code: createdCourse.course_code,
      course_title: createdCourse.course_title,
      department: createdCourse.department,
      programme_code: createdCourse.programme_code,
      academic_year: '2026-2027',
      semester: 5,
      section: createdSection.section_name,
      status: 'ACTIVE',
    },
    academicOfficeActor
  );
  assert(
    Boolean(offering && offering.offering_id),
    'Course offering successfully links course, section, and semester',
    `Offering ID: ${offering.offering_id}`
  );

  // Duplicate offering prevention
  let dupOfferingErr = '';
  try {
    await devDataAdapter.academic.createCourseOffering(
      {
        course_code: createdCourse.course_code,
        course_title: createdCourse.course_title,
        department: createdCourse.department,
        programme_code: createdCourse.programme_code,
        academic_year: '2026-2027',
        semester: 5,
        section: createdSection.section_name,
        status: 'ACTIVE',
      },
      academicOfficeActor
    );
  } catch (err: any) {
    dupOfferingErr = err.message;
  }
  assert(
    dupOfferingErr.includes('already exists') || dupOfferingErr.includes('Duplicate'),
    'Duplicate course offering for same course and section rejected',
    dupOfferingErr
  );

  // ===========================================================================
  // 4. Faculty Course Assignments & Rejection of Non-Teaching Staff
  // ===========================================================================
  console.log('\n--- 4. Faculty Course Assignments & Non-Teaching Rejection ---');
  
  // 4.1 Assign valid teaching faculty
  const facultyAssign = await devDataAdapter.academic.assignFaculty(
    {
      offering_id: offering.offering_id,
      employee_id: 'EMP-001', // Dr. Alan Turing (TEACHING)
      role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
    },
    academicOfficeActor
  );
  assert(
    Boolean(facultyAssign && facultyAssign.faculty_assignment_id),
    'Academic Office assigns teaching faculty to course offering',
    `Assignment: ${facultyAssign.faculty_assignment_id}`
  );

  // 4.2 Rejection of non-teaching staff as faculty
  let nonTeachErr = '';
  try {
    await devDataAdapter.academic.assignFaculty(
      {
        offering_id: offering.offering_id,
        employee_id: 'EMP-003', // Margaret Hamilton (NON_TEACHING)
        role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
      },
      academicOfficeActor
    );
  } catch (err: any) {
    nonTeachErr = err.message;
  }
  assert(
    nonTeachErr.includes('TEACHING') || nonTeachErr.includes('non-teaching'),
    'Assigning non-teaching employee as faculty is blocked with validation error',
    nonTeachErr
  );

  // ===========================================================================
  // 5. Duplicate & Incompatible Faculty Assignment Prevention
  // ===========================================================================
  console.log('\n--- 5. Duplicate & Incompatible Assignment Prevention ---');
  
  // 5.1 Duplicate active assignment of same faculty to same offering
  let dupFacultyErr = '';
  try {
    await devDataAdapter.academic.assignFaculty(
      {
        offering_id: offering.offering_id,
        employee_id: 'EMP-001',
        role_in_course: FacultyCourseRole.CO_INSTRUCTOR,
      },
      academicOfficeActor
    );
  } catch (err: any) {
    dupFacultyErr = err.message;
  }
  assert(
    dupFacultyErr.toLowerCase().includes('already assigned') || dupFacultyErr.toLowerCase().includes('duplicate'),
    'Duplicate active faculty assignment to same offering is rejected',
    dupFacultyErr
  );

  // 5.2 Faculty self-allocation prevention
  let selfAllocErr = '';
  try {
    await devDataAdapter.academic.assignFaculty(
      {
        offering_id: offering.offering_id,
        employee_id: 'EMP-002',
        role_in_course: FacultyCourseRole.CO_INSTRUCTOR,
      },
      facultyActorEMP2 // Faculty calling directly
    );
  } catch (err: any) {
    selfAllocErr = err.message;
  }
  assert(
    selfAllocErr.includes('Unauthorized') || selfAllocErr.includes('Academic Office'),
    'Faculty cannot allocate themselves to courses via direct service call',
    selfAllocErr
  );

  // 5.3 Ending assignment with audit entry
  const endedAssignment = await devDataAdapter.academic.endFacultyAssignment(
    facultyAssign.faculty_assignment_id,
    'Curriculum realignment',
    academicOfficeActor
  );
  assert(
    endedAssignment.assignment_status === 'COMPLETED' && Boolean(endedAssignment.effective_to),
    'Authorized user can end faculty assignment with status COMPLETED and audit entry',
    `Status: ${endedAssignment.assignment_status}`
  );

  // Re-assign for subsequent workspace tests
  const activeFacultyAssign = await devDataAdapter.academic.assignFaculty(
    {
      offering_id: offering.offering_id,
      employee_id: 'EMP-001',
      role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
    },
    academicOfficeActor
  );

  // ===========================================================================
  // 6. Faculty Visibility Restricted to Assigned Courses
  // ===========================================================================
  console.log('\n--- 6. Faculty Visibility Restriction ---');
  
  const emp1Courses = await devDataAdapter.academic.getFacultyAssignedCourses('EMP-001');
  const emp2Courses = await devDataAdapter.academic.getFacultyAssignedCourses('EMP-002');
  
  assert(
    emp1Courses.some((c) => c.course_code === testCourseCode),
    'Faculty EMP-001 sees their assigned course',
    testCourseCode
  );
  assert(
    !emp2Courses.some((c) => c.course_code === testCourseCode),
    'Faculty EMP-002 does NOT see courses assigned exclusively to EMP-001',
    'Isolation confirmed'
  );

  // ===========================================================================
  // 7. Student Course Enrolment & Duplicate Prevention
  // ===========================================================================
  console.log('\n--- 7. Student Enrolment & Duplicate Prevention ---');
  
  // 7.1 Enrol student
  const enrolment1 = await devDataAdapter.academic.enrolStudent(
    {
      student_id: 'STU-001',
      offering_id: offering.offering_id,
      section: createdSection.section_name,
    },
    academicOfficeActor
  );
  assert(
    Boolean(enrolment1 && enrolment1.enrolment_id && enrolment1.enrolment_status === 'ACTIVE'),
    'Student successfully enrolled in course offering and section',
    `Enrolment: ${enrolment1.enrolment_id}`
  );

  // 7.2 Duplicate active enrolment prevention
  let dupEnrolErr = '';
  try {
    await devDataAdapter.academic.enrolStudent(
      {
        student_id: 'STU-001',
        offering_id: offering.offering_id,
        section: createdSection.section_name,
      },
      academicOfficeActor
    );
  } catch (err: any) {
    dupEnrolErr = err.message;
  }
  assert(
    dupEnrolErr.toLowerCase().includes('already') || dupEnrolErr.toLowerCase().includes('duplicate'),
    'Duplicate active student enrolment in same course offering is prevented',
    dupEnrolErr
  );

  // ===========================================================================
  // 8. Enrolment Transfer & Withdrawal Preserving History
  // ===========================================================================
  console.log('\n--- 8. Enrolment Transfer & Withdrawal Preserving History ---');
  
  // 8.1 Transfer section
  const transferredEnrolment = await devDataAdapter.academic.transferStudentSection(
    enrolment1.enrolment_id,
    'B',
    'Timetable conflict with lab elective',
    academicOfficeActor
  );
  const allEnrolmentsAfterTransfer = await devDataAdapter.academic.getEnrolments();
  const oldEnrolment = allEnrolmentsAfterTransfer.find((e) => e.enrolment_id === enrolment1.enrolment_id);

  assert(
    oldEnrolment?.enrolment_status === 'TRANSFERRED' &&
      oldEnrolment?.transfer_reason === 'Timetable conflict with lab elective' &&
      transferredEnrolment.enrolment_status === 'ACTIVE' &&
      transferredEnrolment.section === 'B',
    'Section transfer preserves historical record as TRANSFERRED and activates new section record',
    `Old: ${oldEnrolment?.enrolment_status}, New: ${transferredEnrolment.enrolment_status}`
  );

  // 8.2 Withdrawal preserving history
  const withdrawnRecord = await devDataAdapter.academic.withdrawStudent(
    transferredEnrolment.enrolment_id,
    'Medical leave of absence',
    academicOfficeActor
  );
  assert(
    withdrawnRecord.enrolment_status === 'WITHDRAWN' &&
      withdrawnRecord.withdrawal_reason === 'Medical leave of absence',
    'Student withdrawal marks status WITHDRAWN and preserves audit reason without deleting record',
    `Status: ${withdrawnRecord.enrolment_status}`
  );

  // Enrol STU-001 back into offering section C for Roster and Attendance testing
  const activeEnrolment = await devDataAdapter.academic.enrolStudent(
    {
      student_id: 'STU-001',
      offering_id: offering.offering_id,
      section: createdSection.section_name,
    },
    academicOfficeActor
  );

  // ===========================================================================
  // 9. Faculty Teaching Workspace & Roster Isolation
  // ===========================================================================
  console.log('\n--- 9. Faculty Teaching Workspace & Roster Isolation ---');
  
  // 9.1 Assigned faculty EMP-001 can view section roster
  const roster = await devDataAdapter.academic.getClassRoster(
    testCourseCode,
    createdSection.section_name,
    {
      userId: 'EMP-001',
      employeeId: 'EMP-001',
      role: AuthRole.FACULTY,
    }
  );
  assert(
    Array.isArray(roster) && roster.some((r) => r.student.student_id === 'STU-001'),
    'Assigned faculty can retrieve class roster containing student names & reg numbers',
    `Roster size: ${roster.length}`
  );

  // 9.2 Unassigned faculty EMP-002 rejected from viewing roster
  let unauthRosterErr = '';
  try {
    await devDataAdapter.academic.getClassRoster(
      testCourseCode,
      createdSection.section_name,
      {
        userId: 'EMP-002',
        employeeId: 'EMP-002',
        role: AuthRole.FACULTY,
      }
    );
  } catch (err: any) {
    unauthRosterErr = err.message;
  }
  assert(
    unauthRosterErr.includes('not assigned') || unauthRosterErr.includes('Unauthorized'),
    'Faculty cannot view class roster for unassigned course or section',
    unauthRosterErr
  );

  // ===========================================================================
  // 10. Attendance & Academic Records Limited to Assigned Sections
  // ===========================================================================
  console.log('\n--- 10. Attendance & Academic Records Enforcement ---');
  
  // 10.1 Assigned faculty records attendance
  const attRec = await devDataAdapter.attendance.record(
    {
      date: '2026-10-25',
      course_code: testCourseCode,
      session_slot: '10:00 - 11:00 AM',
      student_id: 'STU-001',
      registration_number: 'EIT-2026-CSE-001',
      status: AttendanceStatus.PRESENT,
      recorded_by_employee_id: 'EMP-001',
      remarks: 'Lab session',
    },
    {
      userId: 'EMP-001',
      employeeId: 'EMP-001',
      role: AuthRole.FACULTY,
    }
  );
  assert(
    Boolean(attRec && attRec.attendance_id),
    'Assigned faculty can record attendance for authorized assigned course',
    `Attendance ID: ${attRec.attendance_id}`
  );

  // 10.2 Unassigned faculty rejected from recording attendance
  let unauthAttErr = '';
  try {
    await devDataAdapter.attendance.record(
      {
        date: '2026-10-25',
        course_code: testCourseCode,
        session_slot: '10:00 - 11:00 AM',
        student_id: 'STU-001',
        registration_number: 'EIT-2026-CSE-001',
        status: AttendanceStatus.PRESENT,
        recorded_by_employee_id: 'EMP-002',
      },
      {
        userId: 'EMP-002',
        employeeId: 'EMP-002',
        role: AuthRole.FACULTY,
      }
    );
  } catch (err: any) {
    unauthAttErr = err.message;
  }
  assert(
    unauthAttErr.includes('not assigned') || unauthAttErr.includes('Unauthorized'),
    'Unassigned faculty cannot record attendance for course they do not teach',
    unauthAttErr
  );

  // 10.3 Assigned faculty records internal exam assessment
  const examRec = await devDataAdapter.examinations.recordOrUpdate!(
    {
      student_id: 'STU-001',
      course_code: testCourseCode,
      exam_session: 'FALL_2026_INTERNAL_1',
      hall_ticket_number: `HT-${testCourseCode}-001`,
      internal_marks: 38,
      external_marks: 0,
      total_marks: 38,
      max_marks: 100,
      exam_status: ExamStatus.APPEARED,
      evaluated_by_employee_id: 'EMP-001',
      moderated_by_office_id: 'PO-004',
    },
    {
      userId: 'EMP-001',
      employeeId: 'EMP-001',
      role: AuthRole.FACULTY,
    }
  );
  assert(
    Boolean(examRec && examRec.internal_marks === 38),
    'Assigned faculty can submit internal assessment marks for their course',
    `Marks: ${examRec.internal_marks}/40`
  );

  // 10.4 Unassigned faculty rejected from submitting exam marks
  let unauthExamErr = '';
  try {
    await devDataAdapter.examinations.recordOrUpdate!(
      {
        student_id: 'STU-001',
        course_code: testCourseCode,
        exam_session: 'FALL_2026_INTERNAL_1',
        hall_ticket_number: `HT-${testCourseCode}-001`,
        internal_marks: 35,
        external_marks: 0,
        total_marks: 35,
        max_marks: 100,
        exam_status: ExamStatus.APPEARED,
        evaluated_by_employee_id: 'EMP-002',
        moderated_by_office_id: 'PO-004',
      },
      {
        userId: 'EMP-002',
        employeeId: 'EMP-002',
        role: AuthRole.FACULTY,
      }
    );
  } catch (err: any) {
    unauthExamErr = err.message;
  }
  assert(
    unauthExamErr.includes('not assigned') || unauthExamErr.includes('Unauthorized'),
    'Unassigned faculty cannot submit exam marks for courses they do not teach',
    unauthExamErr
  );

  // ===========================================================================
  // 11. Timetable Scheduling & 3-Way Conflict Detection
  // ===========================================================================
  console.log('\n--- 11. Timetable Scheduling & Conflict Detection ---');
  
  // 11.1 Schedule clean slot on WEDNESDAY 14:00 - 15:00
  const slot1 = await devDataAdapter.academic.scheduleTimetableSlot(
    {
      academic_year: '2026-2027',
      semester: 3,
      department: 'CSE',
      day_of_week: 'WEDNESDAY',
      start_time: '14:00',
      end_time: '15:00',
      course_code: testCourseCode,
      course_title: createdCourse.course_title,
      section: createdSection.section_name,
      faculty_id: 'EMP-001',
      faculty_reg_number: 'EIT-TCH-CSE-2026-001',
      faculty_name: 'Dr. Alan Turing',
      room: 'CR-101',
    },
    academicOfficeActor
  );
  assert(
    Boolean(slot1 && slot1.slot_id),
    'Timetable slot scheduled successfully without conflicts',
    `Slot ID: ${slot1.slot_id} in ${slot1.room}`
  );

  // 11.2 Room conflict: Another course/section in same room CR-101 at 14:00 - 15:00
  let roomConflictErr = '';
  try {
    await devDataAdapter.academic.scheduleTimetableSlot(
      {
        academic_year: '2026-2027',
        semester: 3,
        department: 'CSE',
        day_of_week: 'WEDNESDAY',
        start_time: '14:00',
        end_time: '15:00',
        course_code: 'CS301',
        course_title: 'Database Systems',
        section: 'B',
        faculty_id: 'EMP-002',
        faculty_reg_number: 'EIT-TCH-CSE-2026-002',
        faculty_name: 'Dr. Grace Hopper',
        room: 'CR-101', // Same room!
      },
      academicOfficeActor
    );
  } catch (err: any) {
    roomConflictErr = err.message;
  }
  assert(
    roomConflictErr.includes('Room conflict') || roomConflictErr.includes('CR-101'),
    'Duplicate Room booking conflict detected and prevented',
    roomConflictErr
  );

  // 11.3 Faculty conflict: EMP-001 booked in different room at same time
  let facultyConflictErr = '';
  try {
    await devDataAdapter.academic.scheduleTimetableSlot(
      {
        academic_year: '2026-2027',
        semester: 3,
        department: 'CSE',
        day_of_week: 'WEDNESDAY',
        start_time: '14:00',
        end_time: '15:00',
        course_code: 'CS301',
        course_title: 'Database Systems',
        section: 'B',
        faculty_id: 'EMP-001', // Same faculty!
        faculty_reg_number: 'EIT-TCH-CSE-2026-001',
        faculty_name: 'Dr. Alan Turing',
        room: 'CR-205', // Different room
      },
      academicOfficeActor
    );
  } catch (err: any) {
    facultyConflictErr = err.message;
  }
  assert(
    facultyConflictErr.toLowerCase().includes('faculty') || facultyConflictErr.includes('EMP-001'),
    'Duplicate Faculty booking conflict detected and prevented',
    facultyConflictErr
  );

  // 11.4 Section conflict: Same section booked for two different courses at same time
  let sectionConflictErr = '';
  try {
    await devDataAdapter.academic.scheduleTimetableSlot(
      {
        academic_year: '2026-2027',
        semester: 3,
        department: 'CSE',
        day_of_week: 'WEDNESDAY',
        start_time: '14:00',
        end_time: '15:00',
        course_code: 'CS301',
        course_title: 'Database Systems',
        section: createdSection.section_name, // Same section C!
        faculty_id: 'EMP-002', // Different faculty
        faculty_reg_number: 'EIT-TCH-CSE-2026-002',
        faculty_name: 'Dr. Grace Hopper',
        room: 'CR-205', // Different room
      },
      academicOfficeActor
    );
  } catch (err: any) {
    sectionConflictErr = err.message;
  }
  assert(
    sectionConflictErr.toLowerCase().includes('section') || sectionConflictErr.includes(createdSection.section_name),
    'Duplicate Section booking conflict detected and prevented',
    sectionConflictErr
  );

  // 11.5 Timetable filter search
  const filteredSlots = await devDataAdapter.academic.getTimetable({
    department: 'CSE',
    semester: 3,
    faculty_id: 'EMP-001',
  });
  assert(
    filteredSlots.length >= 1 && filteredSlots.every((s) => s.faculty_id === 'EMP-001'),
    'Timetable search and filters by department, semester, and faculty return matching entries',
    `Matched ${filteredSlots.length} slots`
  );

  // ===========================================================================
  // 12. Institutional Metrics, Audit Trail & Phase 1–6 Preservation
  // ===========================================================================
  console.log('\n--- 12. Metrics, Audit Trail & Phase 1-6 Preservation ---');
  
  // 12.1 Academic metrics calculation
  const metrics = await devDataAdapter.academic.getAcademicDashboardMetrics();
  assert(
    metrics.activeProgrammesCount >= 3 &&
      metrics.activeCoursesCount >= 4 &&
      metrics.activeEnrolmentsCount >= 1 &&
      metrics.facultyAssignmentsCount >= 1,
    'Academic dashboard metrics accurately aggregate programmes, courses, and enrolments',
    `Progs: ${metrics.activeProgrammesCount}, Courses: ${metrics.activeCoursesCount}, Enrolments: ${metrics.activeEnrolmentsCount}`
  );

  // 12.2 Audit logs recorded
  const auditLogs = await devDataAdapter.audit.getRecent();
  const hasAcademicAudit = auditLogs.some(
    (l) => l.target_worksheet === 'CourseOfferings' || l.target_worksheet === 'CourseEnrolments' || l.target_worksheet === 'FacultyCourseAssignments'
  );
  assert(
    hasAcademicAudit,
    'Academic operations record immutable audit log entries with actor identity and timestamps',
    `Total logs: ${auditLogs.length}`
  );

  // 12.3 All 6 permanent offices intact
  const permanentOffices = await devDataAdapter.offices.getAllPermanent();
  assert(
    permanentOffices.length === 6 &&
      permanentOffices.some((o) => o.canonical_username === 'academicoffice') &&
      permanentOffices.some((o) => o.canonical_username === 'admissionsoffice') &&
      permanentOffices.some((o) => o.canonical_username === 'admin'),
    'All 6 Permanent Offices preserved without addition or removal',
    `Count: ${permanentOffices.length}`
  );

  // 12.4 Admissions student records and applicant intake preserved
  const allStudents = await devDataAdapter.students.getAll();
  const allApplicants = await devDataAdapter.applicants.getAll();
  assert(
    allStudents.length >= 2 && allApplicants.length >= 5,
    'Admissions applicant records and converted students preserved intact',
    `Students: ${allStudents.length}, Applicants: ${allApplicants.length}`
  );

  // ===========================================================================
  // Final Summary
  // ===========================================================================
  console.log('\n================================================================');
  console.log(`   Phase 7 Test Summary: ${results.filter((r) => r.passed).length} / ${results.length} PASSED`);
  console.log('================================================================');

  const failed = results.filter((r) => !r.passed);
  if (failed.length > 0) {
    console.error(`\nFAILED TESTS (${failed.length}):`);
    failed.forEach((f) => console.error(`  - Test ${f.number}: ${f.title} (${f.details})`));
    process.exit(1);
  } else {
    console.log('\n🎉 ALL PHASE 7 VERIFICATION CRITERIA SUCCESSFULLY PASSED!\n');
  }
}

runPhase7Tests().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
