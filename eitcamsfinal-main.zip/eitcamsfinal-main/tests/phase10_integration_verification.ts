import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  AuthRole,
  StudentStatus,
  EmploymentStatus,
  ApplicationStatus,
  ExamLifecycleStatus,
  ExamType,
  AttendanceStatus,
  ExamAttendanceStatus,
  InvoiceStatus,
  PaymentMethod,
  PaymentLedgerStatus,
  PaymentStatus,
  RoomOperationalStatus,
  BedOccupancyStatus,
  HostelAllocationLifecycleStatus,
  HostelChargeStatus,
  ParentRelationship,
  PermissionScope,
} from '../src/types/database';
import { PortalType } from '../src/types/portal';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';
import { PORTAL_GATEWAYS } from '../src/config/portals';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runPhase10Tests() {
  console.log('================================================================');
  console.log('   EIT Phase 10: Student & Parent Integration & E2E Test Suite  ');
  console.log('================================================================\n');

  // Define test actors
  const superAdminActor = { userId: 'admin', role: AuthRole.SUPER_ADMIN };
  const admissionsActor = { userId: 'admissionsoffice', role: AuthRole.OFFICE_ADMIN };
  const academicActor = { userId: 'academicoffice', role: AuthRole.OFFICE_ADMIN };
  const coeActor = { userId: 'coeoffice', role: AuthRole.OFFICE_ADMIN };
  const financeActor = { userId: 'finance', role: AuthRole.OFFICE_ADMIN };
  const hostelActor = { userId: 'hosteloffice', role: AuthRole.OFFICE_ADMIN };
  const facultyActor = { userId: 'EMP-001', role: AuthRole.FACULTY, employeeId: 'EMP-001' };

  const student1Actor = { userId: 'STU-001', role: AuthRole.STUDENT };
  const student2Actor = { userId: 'STU-002', role: AuthRole.STUDENT };
  const parent1Actor = { userId: 'PAR-001', role: AuthRole.PARENT };
  const parent2Actor = { userId: 'PAR-002', role: AuthRole.PARENT };
  const parent999Actor = { userId: 'PAR-999', role: AuthRole.PARENT };

  // ===========================================================================
  // 1. Student Portal Integration & Identity
  // ===========================================================================
  console.log('--- 1. Student Portal Integration & Identity ---');

  // 1.1 Student login
  const studentLoginRes = await devDataAdapter.auth.login(
    'EIT-STU-2026-CSE-0001',
    'dev_mock_hash_student',
    PortalType.Student
  );
  assert(
    studentLoginRes.success === true && !!studentLoginRes.session?.studentProfile,
    'Student STU-001 authenticates via student portal using registration number',
    `User: ${studentLoginRes.session?.username}, Name: ${studentLoginRes.session?.displayName}`
  );

  // 1.2 Student profile details
  const studentProfile = await devDataAdapter.students.getById('STU-001');
  assert(
    !!studentProfile && studentProfile.registration_number === 'EIT-STU-2026-CSE-0001' && studentProfile.enrollment_status === StudentStatus.ENROLLED,
    'Student profile loaded with valid registration number, programme, and ENROLLED status',
    `Reg: ${studentProfile?.registration_number}, Prog: ${studentProfile?.program_name}`
  );

  // 1.3 Active course enrolments
  const studentEnrolments = await devDataAdapter.academic.getEnrolments({ student_id: 'STU-001' }, student1Actor);
  assert(
    Array.isArray(studentEnrolments) && studentEnrolments.length >= 1,
    'Student STU-001 retrieves their active course enrolments',
    `Enrolments count: ${studentEnrolments.length}, Courses: ${studentEnrolments.map((e) => e.course_code).join(', ')}`
  );

  // 1.4 Student attendance history
  const studentAttendance = await devDataAdapter.attendance.getByStudent('STU-001', student1Actor);
  assert(
    Array.isArray(studentAttendance),
    'Student STU-001 retrieves their attendance records',
    `Attendance records count: ${studentAttendance.length}`
  );

  // 1.5 Published examination results
  const studentExams = await devDataAdapter.coe.getStudentPublishedResults('STU-001', student1Actor);
  assert(
    Array.isArray(studentExams) && studentExams.every((e) => e.lifecycle_status === ExamLifecycleStatus.PUBLISHED),
    'Student STU-001 retrieves only PUBLISHED examination results',
    `Published results count: ${studentExams.length}`
  );

  // 1.6 Student consolidated transcript
  const studentTranscript = await devDataAdapter.coe.getStudentTranscript('STU-001', student1Actor);
  assert(
    !!studentTranscript && studentTranscript.cgpa > 0 && studentTranscript.overallCredits > 0,
    'Student transcript accurately computes cumulative CGPA and total credits',
    `CGPA: ${studentTranscript?.cgpa}, Credits: ${studentTranscript?.overallCredits}`
  );

  // 1.7 Fee statement, ledger & receipts
  const studentStatement = await devDataAdapter.finance.getStudentFeeStatement('STU-001', student1Actor);
  const studentInvoices = await devDataAdapter.finance.getInvoices({ student_id: 'STU-001' }, student1Actor);
  assert(
    studentStatement.totalInvoiced >= 0 && Array.isArray(studentInvoices),
    'Student retrieves fee statement with invoices and outstanding ledger balance',
    `Invoiced: $${studentStatement.totalInvoiced}, Outstanding: $${studentStatement.totalOutstanding}`
  );

  // 1.8 Hostel allocation details
  const studentHostel = await devDataAdapter.hostel.getByStudent('STU-001', student1Actor);
  assert(
    studentHostel !== undefined,
    'Student retrieves current hostel room/bed allocation and details',
    studentHostel && studentHostel.currentAllocation
      ? `Room: ${studentHostel.room?.room_number || studentHostel.currentAllocation.room_number}, Allocation: ${studentHostel.currentAllocation.allocation_id}`
      : 'No allocation'
  );

  // 1.9 Fresh student empty state handling
  const freshStudent = await devDataAdapter.students.create({
    first_name: 'Priya',
    last_name: 'Nair',
    date_of_birth: '2006-03-15',
    gender: 'FEMALE',
    institutional_email: 'priya.nair@student.eit.edu',
    personal_phone: '+1 (555) 999-1122',
    program_name: 'B.Tech Electrical Engineering',
    department: 'EEE',
    admission_year: 2026,
    current_semester: 1,
    section: 'A',
    enrollment_status: StudentStatus.ENROLLED,
  });
  const freshActor = { userId: freshStudent.student_id, role: AuthRole.STUDENT };
  const freshEnrolments = await devDataAdapter.academic.getEnrolments({ student_id: freshStudent.student_id }, freshActor);
  const freshExams = await devDataAdapter.examinations.getByStudent(freshStudent.student_id, freshActor);
  const freshInvoices = await devDataAdapter.finance.getInvoices({ student_id: freshStudent.student_id }, freshActor);
  const freshHostel = await devDataAdapter.hostel.getByStudent(freshStudent.student_id, freshActor);
  assert(
    freshEnrolments.length === 0 && freshExams.length === 0 && freshInvoices.length === 0 && (freshHostel === null || freshHostel?.currentAllocation === null),
    'Freshly created student cleanly handles empty states across all academic, exam, finance, and hostel modules without error',
    `Student ID: ${freshStudent.student_id}`
  );

  // ===========================================================================
  // 2. Student Record Isolation & Authorization
  // ===========================================================================
  console.log('\n--- 2. Student Record Isolation & Strict Authorization ---');

  // 2.1 Student cannot view other student's enrolments
  let blockedEnrolment = false;
  try {
    await devDataAdapter.academic.getEnrolments({ student_id: 'STU-002' }, student1Actor);
  } catch (err: any) {
    blockedEnrolment = err.message.includes('Unauthorized') || err.message.includes('cannot view');
  }
  assert(blockedEnrolment, 'Student STU-001 is strictly blocked from querying course enrolments of STU-002');

  // 2.2 Student cannot view other student's coursework
  let blockedAcademics = false;
  try {
    await devDataAdapter.academics.getByStudent('STU-002', student1Actor);
  } catch (err: any) {
    blockedAcademics = err.message.includes('Unauthorized');
  }
  assert(blockedAcademics, 'Student STU-001 is strictly blocked from viewing academic coursework of STU-002');

  // 2.3 Student cannot view other student's attendance
  let blockedAttendance = false;
  try {
    await devDataAdapter.attendance.getByStudent('STU-002', student1Actor);
  } catch (err: any) {
    blockedAttendance = err.message.includes('Unauthorized');
  }
  assert(blockedAttendance, 'Student STU-001 is strictly blocked from viewing attendance records of STU-002');

  // 2.4 Student cannot view other student's exam results
  let blockedExams = false;
  try {
    await devDataAdapter.examinations.getByStudent('STU-002', student1Actor);
  } catch (err: any) {
    blockedExams = err.message.includes('Unauthorized');
  }
  assert(blockedExams, 'Student STU-001 is strictly blocked from viewing exam results of STU-002');

  // 2.5 Student cannot view other student's financial invoices
  let blockedFinance = false;
  try {
    await devDataAdapter.finance.getInvoices({ student_id: 'STU-002' }, student1Actor);
  } catch (err: any) {
    blockedFinance = err.message.includes('Unauthorized');
  }
  assert(blockedFinance, 'Student STU-001 is strictly blocked from viewing invoices belonging to STU-002');

  // 2.6 Student cannot view other student's hostel details
  let blockedHostel = false;
  try {
    await devDataAdapter.hostel.getByStudent('STU-002', student1Actor);
  } catch (err: any) {
    blockedHostel = err.message.includes('Unauthorized');
  }
  assert(blockedHostel, 'Student STU-001 is strictly blocked from accessing hostel allocation of STU-002');

  // 2.7 Student cannot record payments on another student's invoice
  let blockedCrossPayment = false;
  try {
    await devDataAdapter.finance.recordPayment(
      'INV-2026-003',
      200,
      'HACK-PAY-001',
      PaymentMethod.ONLINE_GATEWAY,
      student1Actor
    );
  } catch (err: any) {
    blockedCrossPayment = err.message.includes('Unauthorized');
  }
  assert(blockedCrossPayment, 'Student STU-001 is blocked from recording payment on STU-002 invoice');

  // ===========================================================================
  // 3. Parent/Guardian Portal Integration & Multi-Child Switching
  // ===========================================================================
  console.log('\n--- 3. Parent/Guardian Portal Integration & Multi-Child Switching ---');

  // 3.1 Parent login
  const parentLoginRes = await devDataAdapter.auth.login(
    'rajesh.kumar',
    'dev_mock_hash_parent',
    PortalType.Parent
  );
  assert(
    parentLoginRes.success === true && !!parentLoginRes.session?.parentProfile,
    'Parent PAR-001 authenticates via Parent Portal successfully',
    `Name: ${parentLoginRes.session?.parentProfile?.first_name} ${parentLoginRes.session?.parentProfile?.last_name}`
  );

  // 3.2 Own-child access via authenticated parent
  const initialWards = await devDataAdapter.parents.getLinkedStudents('PAR-001', parent1Actor);
  assert(
    Array.isArray(initialWards) && initialWards.length >= 1,
    'Parent PAR-001 retrieves own linked children when authenticated with parent1Actor',
    `Linked child: ${initialWards[0].student.first_name} ${initialWards[0].student.last_name} (${initialWards[0].student.registration_number})`
  );

  const directActorWards = await devDataAdapter.parents.getLinkedStudents(parent1Actor);
  assert(
    Array.isArray(directActorWards) && directActorWards.length >= 1,
    'getLinkedStudents derives permitted parent identity directly from authenticated actor context',
    `Resolved parent wards count: ${directActorWards.length}`
  );

  // 3.3 Security: Unauthenticated call rejection
  let unauthRejected = false;
  try {
    // Calling without actor parameter
    await (devDataAdapter.parents.getLinkedStudents as any)('PAR-001');
  } catch (err: any) {
    unauthRejected = err.message.includes('Unauthorized') || err.message.includes('Authentication required');
  }
  assert(unauthRejected, 'Unauthenticated call to parents.getLinkedStudents without actor is strictly rejected');

  // 3.4 Security: Non-parent access rejection
  let studentAccessRejected = false;
  try {
    await devDataAdapter.parents.getLinkedStudents('PAR-001', student1Actor);
  } catch (err: any) {
    studentAccessRejected = err.message.includes('Access Denied') && err.message.includes('STUDENT');
  }
  assert(studentAccessRejected, 'Student role STU-001 is denied access to parents.getLinkedStudents');

  let facultyAccessRejected = false;
  try {
    await devDataAdapter.parents.getLinkedStudents('PAR-001', facultyActor);
  } catch (err: any) {
    facultyAccessRejected = err.message.includes('Access Denied') && err.message.includes('FACULTY');
  }
  assert(facultyAccessRejected, 'Faculty role EMP-001 is denied access to parents.getLinkedStudents');

  // 3.5 Security: Cross-parent access denial
  let crossParentRejected = false;
  try {
    // Parent 1 (PAR-001) attempting to query Parent 2 (PAR-002)
    await devDataAdapter.parents.getLinkedStudents('PAR-002', parent1Actor);
  } catch (err: any) {
    crossParentRejected = err.message.includes('Cross-parent queries prohibited');
  }
  assert(crossParentRejected, 'Parent PAR-001 is denied access to query another parent (PAR-002) linked children');

  let reverseCrossParentRejected = false;
  try {
    // Parent 2 (PAR-002) attempting to query Parent 1 (PAR-001)
    await devDataAdapter.parents.getLinkedStudents('PAR-001', parent2Actor);
  } catch (err: any) {
    reverseCrossParentRejected = err.message.includes('Cross-parent queries prohibited');
  }
  assert(reverseCrossParentRejected, 'Parent PAR-002 is denied access to query Parent PAR-001 linked children');

  // 3.6 Security: Revoked link exclusion
  // Create a REVOKED link for PAR-001
  await devDataAdapter.parents.linkStudent({
    parent_id: 'PAR-001',
    student_id: 'STU-REVOKED-001',
    student_registration_number: 'EIT-STU-REVOKED',
    relationship: ParentRelationship.OTHER,
    is_primary_contact: false,
    can_view_grades: false,
    can_view_attendance: false,
    can_view_finance: false,
    emergency_priority: 9,
    status: 'REVOKED',
  });
  const wardsAfterRevocation = await devDataAdapter.parents.getLinkedStudents('PAR-001', parent1Actor);
  const containsRevoked = wardsAfterRevocation.some((w) => w.student.student_id === 'STU-REVOKED-001');
  assert(!containsRevoked, 'Revoked links (status: REVOKED) are strictly excluded from returned active student linkages');

  // 3.7 Multi-child linking for authenticated parent
  // Link second active ward (STU-002) to PAR-001 with custom permissions: grades=true, attendance=false, finance=false
  await devDataAdapter.parents.linkStudent({
    parent_id: 'PAR-001',
    student_id: 'STU-002',
    student_registration_number: 'EIT-STU-2026-ECE-0002',
    relationship: ParentRelationship.FATHER,
    is_primary_contact: false,
    can_view_grades: true,
    can_view_attendance: false,
    can_view_finance: false,
    emergency_priority: 2,
    status: 'ACTIVE',
  });

  const multiWards = await devDataAdapter.parents.getLinkedStudents('PAR-001', parent1Actor);
  assert(
    multiWards.length === 2,
    'Parent PAR-001 supports multiple linked children with independent relationship records',
    `Wards: ${multiWards.map((w) => w.student.first_name).join(', ')}`
  );

  // 3.8 Administrator authorized query
  const adminQueryWards = await devDataAdapter.parents.getLinkedStudents('PAR-001', superAdminActor);
  assert(
    Array.isArray(adminQueryWards) && adminQueryWards.length === 2,
    'Institutional administrator (SUPER_ADMIN) is authorized to query parent linked children',
    `Admin retrieved wards count: ${adminQueryWards.length}`
  );

  // 3.9 Unlinked parent empty state
  await devDataAdapter.parents.linkStudent({
    parent_id: 'PAR-999',
    student_id: 'NONE',
    student_registration_number: 'NONE',
    relationship: ParentRelationship.OTHER,
    is_primary_contact: false,
    can_view_grades: false,
    can_view_attendance: false,
    can_view_finance: false,
    emergency_priority: 9,
    status: 'REVOKED',
  });
  const unlinkedWards = await devDataAdapter.parents.getLinkedStudents('PAR-999', parent999Actor);
  assert(
    unlinkedWards.length === 0,
    'Parent with no active linked children receives empty array without data leakage',
    `Active links: ${unlinkedWards.length}`
  );

  // 3.10 Hostel isolation & parent-child validation
  let unauthHostelRejected = false;
  try {
    await (devDataAdapter.hostel.getStudentHostelDetails as any)('STU-001');
  } catch (err: any) {
    unauthHostelRejected = err.message.includes('Unauthorized') || err.message.includes('Authentication required');
  }
  assert(unauthHostelRejected, 'Unauthenticated call to hostel.getStudentHostelDetails is strictly rejected');

  const wardHostelDetails = await devDataAdapter.hostel.getStudentHostelDetails('STU-001', parent1Actor);
  assert(
    !!wardHostelDetails && wardHostelDetails.student.student_id === 'STU-001',
    'Parent PAR-001 successfully retrieves hostel details for authorized active ward STU-001'
  );

  let unlinkedHostelRejected = false;
  try {
    await devDataAdapter.hostel.getStudentHostelDetails('STU-999', parent1Actor);
  } catch (err: any) {
    unlinkedHostelRejected = err.message.includes('not exist') || err.message.includes('Access Denied');
  }
  assert(unlinkedHostelRejected, 'Parent is rejected when attempting to view hostel details for unlinked student');

  // 3.11 COE Parent-child isolation & cross-parent rejection
  let coeCrossParentRejected = false;
  try {
    await devDataAdapter.coe.getParentWardResults('PAR-002', 'STU-001', parent1Actor);
  } catch (err: any) {
    coeCrossParentRejected = err.message.includes('Cross-parent queries prohibited');
  }
  assert(coeCrossParentRejected, 'COE getParentWardResults blocks cross-parent examination results query');

  // ===========================================================================
  // 4. Parent Granular Permission Enforcement
  // ===========================================================================
  console.log('\n--- 4. Parent Granular Permission Enforcement ---');

  // Ward 1 (STU-001): can_view_grades=true, can_view_attendance=true, can_view_finance=true
  // Ward 2 (STU-002): can_view_grades=true, can_view_attendance=false, can_view_finance=false

  // 4.1 Ward 1: All permissions active
  const ward1Grades = await devDataAdapter.academics.getByStudent('STU-001', parent1Actor);
  const ward1Attendance = await devDataAdapter.attendance.getByStudent('STU-001', parent1Actor);
  const ward1Finance = await devDataAdapter.finance.getInvoices({ student_id: 'STU-001' }, parent1Actor);
  assert(
    Array.isArray(ward1Grades) && Array.isArray(ward1Attendance) && Array.isArray(ward1Finance),
    'Parent can view Grades, Attendance, and Finance for Ward 1 where all permissions are enabled'
  );

  // 4.2 Ward 2: can_view_grades=true allows exam results
  const ward2Grades = await devDataAdapter.examinations.getByStudent('STU-002', parent1Actor);
  assert(
    Array.isArray(ward2Grades),
    'Parent can view published grades for Ward 2 where can_view_grades is true',
    `Exam results: ${ward2Grades.length}`
  );

  // 4.3 Ward 2: can_view_attendance=false blocks attendance
  let ward2AttendanceBlocked = false;
  try {
    await devDataAdapter.attendance.getByStudent('STU-002', parent1Actor);
  } catch (err: any) {
    ward2AttendanceBlocked = err.message.includes('can_view_attendance is false');
  }
  assert(ward2AttendanceBlocked, 'Parent access to Ward 2 attendance is strictly blocked when can_view_attendance=false');

  // 4.4 Ward 2: can_view_finance=false blocks finance
  let ward2FinanceBlocked = false;
  try {
    await devDataAdapter.finance.getInvoices({ student_id: 'STU-002' }, parent1Actor);
  } catch (err: any) {
    ward2FinanceBlocked = err.message.includes('can_view_finance is false');
  }
  assert(ward2FinanceBlocked, 'Parent access to Ward 2 financial invoices is strictly blocked when can_view_finance=false');

  // 4.5 Parent access to completely unlinked student is rejected
  let unlinkedBlocked = false;
  try {
    await devDataAdapter.academics.getByStudent(freshStudent.student_id, parent1Actor);
  } catch (err: any) {
    unlinkedBlocked = err.message.includes('No active relationship link found');
  }
  assert(unlinkedBlocked, 'Parent is strictly rejected from querying completely unlinked student');

  // ===========================================================================
  // 5. Cross-Module Consistency Flow A: Admissions Approval to Student Login
  // ===========================================================================
  console.log('\n--- 5. Flow A: Admissions Approval to Student Login ---');

  // 5.1 Create and approve an applicant
  const newApplicant = await devDataAdapter.admissions.create(
    {
      first_name: 'Vikram',
      last_name: 'Mehta',
      email: `vikram.mehta.${Date.now()}@example.com`,
      phone_number: '+1 (555) 789-3344',
      date_of_birth: '2005-11-20',
      gender: 'MALE',
      intended_program: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      previous_qualification: 'Senior Secondary Certificate (XII)',
      marks_percentage: 92.5,
    },
    admissionsActor
  );

  const approvedApp = await devDataAdapter.admissions.updateApplicationStatus(
    newApplicant.application_id,
    ApplicationStatus.APPROVED,
    'Academic merit quota selection sanctioned by Admissions Board',
    admissionsActor
  );
  assert(
    approvedApp.application_status === ApplicationStatus.APPROVED,
    'Admissions Office approved applicant for college admission',
    `App ID: ${approvedApp.application_id}`
  );

  // 5.2 Convert applicant to student
  const conversionResult = await devDataAdapter.admissions.convertApprovedApplicantToStudent(
    newApplicant.application_id,
    admissionsActor
  );
  assert(
    conversionResult.success && !!conversionResult.student && !!conversionResult.account,
    'Applicant converted to student: StudentRecord and AuthUserRecord provisioned once',
    `Reg Number: ${conversionResult.student.registration_number}, Username: ${conversionResult.account?.username}`
  );

  // 5.3 Repeat conversion idempotency
  const repeatConversion = await devDataAdapter.admissions.convertApprovedApplicantToStudent(
    newApplicant.application_id,
    admissionsActor
  );
  assert(
    repeatConversion.success && repeatConversion.alreadyConverted === true && repeatConversion.student.student_id === conversionResult.student.student_id,
    'Repeat conversion returns existing student record idempotently without creating duplicate accounts',
    repeatConversion.message
  );

  // 5.4 Newly created student authenticates via portal
  const newStudentLogin = await devDataAdapter.auth.login(
    conversionResult.student.registration_number,
    'dev_mock_hash',
    PortalType.Student
  );
  assert(
    newStudentLogin.success === true && newStudentLogin.session?.userId === conversionResult.student.student_id,
    'Newly created student logs in successfully using assigned canonical registration number',
    `Student ID: ${newStudentLogin.session?.userId}`
  );

  // ===========================================================================
  // 6. Cross-Module Consistency Flow B: Academic Enrolment to Faculty Roster
  // ===========================================================================
  console.log('\n--- 6. Flow B: Academic Enrolment to Faculty Roster ---');

  const admittedStudentId = conversionResult.student.student_id;
  const admittedActor = { userId: admittedStudentId, role: AuthRole.STUDENT };

  // 6.1 Academic Office enrols student
  const enrolment = await devDataAdapter.academic.enrolStudent(
    {
      student_id: admittedStudentId,
      course_code: 'CS201',
      section: 'A',
      semester: 3,
      academic_year: '2026-2027',
    },
    academicActor
  );
  assert(
    enrolment.enrolment_status === 'ACTIVE' && enrolment.course_code === 'CS201',
    'Academic Office enrolled student into CS201 Section A',
    `Enrolment ID: ${enrolment.enrolment_id}`
  );

  // 6.2 Enrolled course visible in student's course list
  const admittedStudentEnrolments = await devDataAdapter.academic.getEnrolments(
    { student_id: admittedStudentId },
    admittedActor
  );
  assert(
    admittedStudentEnrolments.some((e) => e.enrolment_id === enrolment.enrolment_id),
    'Student view reflects new active enrolment in CS201'
  );

  // 6.3 Student appears in faculty class roster
  const facultyRoster = await devDataAdapter.academic.getClassRoster('CS201', 'A', facultyActor);
  assert(
    facultyRoster.some((r) => r.student.student_id === admittedStudentId),
    'Assigned faculty class roster reflects the newly enrolled student',
    `Roster size: ${facultyRoster.length}`
  );

  // 6.4 Duplicate active enrolment rejection
  let duplicateEnrolmentBlocked = false;
  try {
    await devDataAdapter.academic.enrolStudent(
      {
        student_id: admittedStudentId,
        course_code: 'CS201',
        section: 'A',
        semester: 3,
        academic_year: '2026-2027',
      },
      academicActor
    );
  } catch (err: any) {
    duplicateEnrolmentBlocked = err.message.includes('Duplicate Enrolment');
  }
  assert(duplicateEnrolmentBlocked, 'System prevents duplicate active enrolment for the same student and course');

  // ===========================================================================
  // 7. Cross-Module Consistency Flow C: Faculty Attendance Recording
  // ===========================================================================
  console.log('\n--- 7. Flow C: Faculty Attendance Recording & Consistency ---');

  const attendanceDate = '2026-10-26';
  const attendanceSlot = 'PERIOD_1';

  // 7.1 Faculty records attendance for student
  const recordedAttendance = await devDataAdapter.attendance.record(
    {
      student_id: admittedStudentId,
      course_code: 'CS201',
      date: attendanceDate,
      status: AttendanceStatus.PRESENT,
      session_slot: attendanceSlot,
      academic_year: '2026-2027',
      semester: 3,
    },
    facultyActor
  );
  assert(
    recordedAttendance.status === AttendanceStatus.PRESENT,
    'Assigned faculty recorded lecture attendance for enrolled student',
    `Attendance ID: ${recordedAttendance.attendance_id}`
  );

  // 7.2 Duplicate attendance entry rejected
  let duplicateAttendanceBlocked = false;
  try {
    await devDataAdapter.attendance.record(
      {
        student_id: admittedStudentId,
        course_code: 'CS201',
        date: attendanceDate,
        status: AttendanceStatus.ABSENT,
        session_slot: attendanceSlot,
        academic_year: '2026-2027',
        semester: 3,
      },
      facultyActor
    );
  } catch (err: any) {
    duplicateAttendanceBlocked = err.message.includes('Duplicate Attendance Entry');
  }
  assert(duplicateAttendanceBlocked, 'System prevents recording duplicate attendance for same student, course, date, and session slot');

  // 7.3 Student view reflects attendance
  const studentAttView = await devDataAdapter.attendance.getByStudent(admittedStudentId, admittedActor);
  assert(
    studentAttView.some((a) => a.attendance_id === recordedAttendance.attendance_id),
    'Student attendance view immediately reflects the recorded session'
  );

  // ===========================================================================
  // 8. Cross-Module Consistency Flow D: COE Lifecycle & Publication
  // ===========================================================================
  console.log('\n--- 8. Flow D: COE Lifecycle, Marks Submission & Controlled Publication ---');

  // 8.1 COE creates schedule
  const examSession = (await devDataAdapter.coe.getExamSessions(undefined, coeActor))[0];
  const examSchedule = await devDataAdapter.coe.scheduleExam(
    {
      session_id: examSession.session_id,
      exam_name: 'Advanced Programming Theory Examination',
      exam_type: ExamType.END_SEMESTER,
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      programme_code: 'BTECH-CSE',
      department: 'CSE',
      semester: 3,
      section: 'A',
      exam_date: '2026-12-15',
      start_time: '14:00',
      end_time: '17:00',
      duration_minutes: 180,
      room: 'Examination Hall 3',
      max_marks: 100,
      passing_marks: 40,
    },
    coeActor
  );
  assert(
    examSchedule.status === ExamLifecycleStatus.SCHEDULED,
    'COE Office scheduled examination for cohort',
    `Schedule ID: ${examSchedule.schedule_id}`
  );

  // 8.2 Open marks entry
  await devDataAdapter.coe.setMarksEntryWindow(examSchedule.schedule_id, true, coeActor);

  // Record examination attendance for the cohort
  const eligible = await devDataAdapter.coe.checkEligibility(examSchedule.schedule_id, coeActor);
  for (const s of eligible) {
    await devDataAdapter.coe.recordAttendance(
      {
        schedule_id: examSchedule.schedule_id,
        student_id: s.student_id,
        status: ExamAttendanceStatus.PRESENT,
      },
      coeActor
    );
  }

  // 8.3 Faculty submits marks
  const draftMarksEntries = eligible.map((s) => ({
    student_id: s.student_id,
    internal_marks: 45,
    external_marks: 48,
  }));
  await devDataAdapter.coe.saveDraftMarks(examSchedule.schedule_id, draftMarksEntries, facultyActor);
  await devDataAdapter.coe.submitMarksForReview(examSchedule.schedule_id, 'End semester final marks', facultyActor);

  // 8.4 Unpublished marks NOT visible to student
  const prePubExams = await devDataAdapter.coe.getStudentPublishedResults(admittedStudentId, admittedActor);
  assert(
    !prePubExams.some((e) => e.course_code === 'CS201' && e.session_id === examSession.session_id),
    'Unpublished examination marks are strictly hidden from student view before formal COE approval and publication'
  );

  // 8.5 COE approves and publishes results
  await devDataAdapter.coe.approveResults(examSchedule.schedule_id, coeActor);
  await devDataAdapter.coe.publishResults(examSchedule.schedule_id, coeActor);

  // 8.6 Published marks now visible to student
  const postPubExams = await devDataAdapter.coe.getStudentPublishedResults(admittedStudentId, admittedActor);
  const publishedCS201 = postPubExams.find((e) => e.course_code === 'CS201');
  assert(
    !!publishedCS201 && publishedCS201.lifecycle_status === ExamLifecycleStatus.PUBLISHED,
    'Published examination result is now visible in student dashboard with computed grade',
    `Grade: ${publishedCS201?.grade}, Points: ${publishedCS201?.grade_point}`
  );

  // ===========================================================================
  // 9. Cross-Module Consistency Flow E: Finance Invoices, Payments & Reversals
  // ===========================================================================
  console.log('\n--- 9. Flow E: Finance Invoices, Payments & Balance Consistency ---');

  // 9.1 Finance issues invoice for newly admitted student
  const newInvoice = await devDataAdapter.finance.createInvoice(
    {
      student_id: admittedStudentId,
      registration_number: conversionResult.student.registration_number,
      academic_year: '2026-2027',
      semester: 1,
      fee_category: 'TUITION' as any,
      line_items: [
        { item_code: 'TUI-01', description: 'Semester 1 Tuition', amount: 3000 },
        { item_code: 'LAB-01', description: 'Laboratory Fee', amount: 500 },
      ],
      due_date: '2026-11-30',
    },
    financeActor
  );
  assert(
    newInvoice.status === InvoiceStatus.ISSUED && newInvoice.outstanding_balance === 3500,
    'Finance Office issued tuition invoice for student',
    `Invoice: ${newInvoice.invoice_id}, Total: $${newInvoice.total_amount}`
  );

  // 9.2 Student checks balance
  const admittedBalance = await devDataAdapter.finance.getStudentFeeStatement(admittedStudentId, admittedActor);
  assert(
    admittedBalance.totalOutstanding === 3500,
    'Student fee statement reflects correct outstanding balance of $3500'
  );

  // 9.3 Student records payment of $2000
  const paymentRecord = await devDataAdapter.finance.recordPayment(
    newInvoice.invoice_id,
    2000,
    `PAY-GATEWAY-${Date.now()}`,
    PaymentMethod.ONLINE_GATEWAY,
    admittedActor
  );
  const updatedInv = (await devDataAdapter.finance.getInvoices({ invoice_id: newInvoice.invoice_id }, financeActor))[0];
  assert(
    updatedInv.outstanding_balance === 1500 && updatedInv.status === InvoiceStatus.PARTIALLY_PAID,
    'Payment of $2000 reduces invoice outstanding balance to $1500 and updates status to PARTIALLY_PAID',
    `Payment ID: ${paymentRecord.payment_id}`
  );

  // 9.4 Payment reversal restores balance
  await devDataAdapter.finance.reversePayment(
    paymentRecord.payment_id,
    'Bank ACH chargeback reconciliation',
    financeActor
  );
  const reversedInv = (await devDataAdapter.finance.getInvoices({ invoice_id: newInvoice.invoice_id }, financeActor))[0];
  assert(
    reversedInv.outstanding_balance === 3500 && reversedInv.status === InvoiceStatus.ISSUED,
    'Payment reversal restores invoice outstanding balance back to $3500'
  );

  // ===========================================================================
  // 10. Cross-Module Consistency Flow F & G: Hostel Allocation & Billing
  // ===========================================================================
  console.log('\n--- 10. Flow F & G: Hostel Allocation & Billing Reconciliation ---');

  // 10.1 Allocate hostel bed to newly admitted student
  const availableBeds = await devDataAdapter.hostel.getBedInventory(
    { status: BedOccupancyStatus.AVAILABLE },
    hostelActor
  );
  assert(availableBeds.length > 0, 'Hostel Office retrieved available bed inventory', `Available: ${availableBeds.length}`);

  const targetBed = availableBeds[0];
  const allocation = await devDataAdapter.hostel.allocateBed(
    {
      student_id: admittedStudentId,
      registration_number: conversionResult.student.registration_number,
      student_name: `${conversionResult.student.first_name} ${conversionResult.student.last_name}`,
      gender: conversionResult.student.gender as any,
      room_id: targetBed.room.room_id,
      bed_identifier: targetBed.bed.bed_identifier,
      academic_year: '2026-2027',
      start_date: '2026-11-01',
      emergency_contact_phone: '+1 (555) 789-3344',
    },
    hostelActor
  );
  assert(
    allocation.status === HostelAllocationLifecycleStatus.ALLOCATED,
    'Hostel Office allocated room/bed to student',
    `Allocation ID: ${allocation.allocation_id}, Room: ${targetBed.room.room_number}, Bed: ${targetBed.bed.bed_identifier}`
  );

  // 10.2 Student views allocation
  const studentHostelAllocation = await devDataAdapter.hostel.getByStudent(admittedStudentId, admittedActor);
  assert(
    studentHostelAllocation?.currentAllocation?.allocation_id === allocation.allocation_id,
    'Student dashboard immediately reflects current hostel allocation and room details'
  );

  // 10.3 Hostel initiates charge request
  const chargeRequest = await devDataAdapter.hostel.requestCharge(
    {
      allocation_id: allocation.allocation_id,
      billing_period: '2026-2027-SEM1',
      amount: 1200,
      description: 'Hostel Room & Boarding Fee - Sem 1',
    },
    hostelActor
  );
  assert(
    chargeRequest.status === HostelChargeStatus.REQUESTED,
    'Hostel Office created charge request of $1200',
    `Charge ID: ${chargeRequest.charge_request_id}`
  );

  // 10.4 Finance issues linked invoice
  const hostelInvoice = await devDataAdapter.finance.createInvoiceFromHostelCharge(
    chargeRequest.charge_request_id,
    financeActor
  );
  assert(
    hostelInvoice.invoice_id.startsWith('INV-') && hostelInvoice.fee_category === 'HOSTEL',
    'Finance Office issued invoice from hostel charge request',
    `Invoice: ${hostelInvoice.invoice_id}`
  );

  // 10.5 Duplicate invoice prevention for same hostel charge
  let duplicateHostelInvoiceBlocked = false;
  try {
    await devDataAdapter.finance.createInvoiceFromHostelCharge(
      chargeRequest.charge_request_id,
      financeActor
    );
  } catch (err: any) {
    duplicateHostelInvoiceBlocked = err.message.includes('already been invoiced');
  }
  assert(duplicateHostelInvoiceBlocked, 'System prevents duplicate invoice issuance for already invoiced hostel charge');

  // ===========================================================================
  // 11. Direct Service-Call Authorization & Separation of Duties Across Roles
  // ===========================================================================
  console.log('\n--- 11. Role Authorization & Strict Separation of Duties ---');

  // 11.1 Student cannot call Admissions write methods
  let studentAdmissionsBlocked = false;
  try {
    await devDataAdapter.admissions.updateApplicationStatus('APP-2026-0001', ApplicationStatus.APPROVED, 'Self approve', student1Actor);
  } catch (err: any) {
    studentAdmissionsBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted');
  }
  assert(studentAdmissionsBlocked, 'Student role cannot access Admissions administrative approval methods');

  // 11.2 Student cannot call Academic write methods
  let studentAcademicBlocked = false;
  try {
    await devDataAdapter.academic.enrolStudent({ student_id: 'STU-001', course_code: 'CS201' }, student1Actor);
  } catch (err: any) {
    studentAcademicBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted');
  }
  assert(studentAcademicBlocked, 'Student role cannot call Academic enrolment management methods');

  // 11.3 Student cannot call COE methods
  let studentCoeBlocked = false;
  try {
    await devDataAdapter.coe.approveResults('EXSCH-2026-CS201-4092', 'Self approve', student1Actor);
  } catch (err: any) {
    studentCoeBlocked = err.message.includes('Unauthorized') || err.message.includes('cannot access COE');
  }
  assert(studentCoeBlocked, 'Student role cannot call COE result approval methods');

  // 11.4 Student cannot call Finance invoice creation
  let studentFinanceBlocked = false;
  try {
    await devDataAdapter.finance.createInvoice({ student_id: 'STU-001', line_items: [], due_date: '2026-12-01' } as any, student1Actor);
  } catch (err: any) {
    studentFinanceBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted');
  }
  assert(studentFinanceBlocked, 'Student role cannot create Finance invoices');

  // 11.5 Student cannot call Hostel allocation methods
  let studentHostelBlocked = false;
  try {
    await devDataAdapter.hostel.allocateBed({ student_id: 'STU-001' } as any, student1Actor);
  } catch (err: any) {
    studentHostelBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted');
  }
  assert(studentHostelBlocked, 'Student role cannot perform Hostel allocations');

  // 11.6 Parent role cannot access administrative office operations
  let parentAdminBlocked = false;
  try {
    await devDataAdapter.hostel.createRoom({ block_id: 'HST-BLK-A', room_number: '999', room_type: 'SINGLE' as any, capacity: 1 }, parent1Actor);
  } catch (err: any) {
    parentAdminBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted');
  }
  assert(parentAdminBlocked, 'Parent role cannot execute administrative office operations');

  // 11.7 Faculty cannot access unassigned course roster
  let facultyUnassignedBlocked = false;
  try {
    // EMP-001 is assigned to CS201 Section A, not EC304 Section B
    await devDataAdapter.academic.getClassRoster('EC304', 'B', facultyActor);
  } catch (err: any) {
    facultyUnassignedBlocked = err.message.includes('Unauthorized') && err.message.includes('not assigned');
  }
  assert(facultyUnassignedBlocked, 'Faculty member cannot access class roster for course/section they are not assigned to');

  // 11.8 Finance and Hostel permissions remain strictly partitioned
  let financeAccessHostelBlocked = false;
  try {
    await devDataAdapter.hostel.createRoom({ block_id: 'HST-BLK-A', room_number: '888', room_type: 'SINGLE' as any, capacity: 1 }, financeActor);
  } catch (err: any) {
    financeAccessHostelBlocked = err.message.includes('Unauthorized') || err.message.includes('not permitted to access Hostel Office');
  }
  assert(financeAccessHostelBlocked, 'Finance Office account is strictly rejected from Hostel Office management');

  // ===========================================================================
  // 12. Account Lifecycle Security & Gateways
  // ===========================================================================
  console.log('\n--- 12. Account Lifecycle Security & Canonical Gateways ---');

  // 12.1 Terminated employee login blocked
  // Create terminated employee and test login
  const termEmp = await devDataAdapter.employees.create({
    registration_number: 'EIT-NTC-ADM-2026-999',
    category: 'NON_TEACHING' as any,
    first_name: 'Fired',
    last_name: 'Staff',
    institutional_email: 'fired.staff@eit.edu',
    phone_number: '+1 (555) 000-0000',
    primary_department: 'ADM',
    designation: 'Former Staff',
    employment_status: EmploymentStatus.TERMINATED,
    date_of_joining: '2020-01-01',
  });
  // Create auth user for termEmp
  const termUser = {
    user_id: `USR-${termEmp.employee_id}`,
    username: 'fired.staff',
    password_hash: 'dev_mock_hash_staff',
    portal_type: PortalType.Employee,
    role: AuthRole.NON_TEACHING_STAFF,
    linked_record_type: 'EMPLOYEE' as any,
    linked_record_id: termEmp.employee_id,
    account_status: 'ACTIVE' as any,
    failed_login_attempts: 0,
    password_updated_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  const currentState = devDataAdapter.getState();
  devDataAdapter.saveState({ ...currentState, users: [...currentState.users, termUser] });

  const termLogin = await devDataAdapter.auth.login('fired.staff', 'dev_mock_hash_staff', PortalType.Employee);
  assert(
    termLogin.success === false && termLogin.error?.includes('TERMINATED'),
    'Terminated employee is blocked from logging in with descriptive error',
    termLogin.error
  );

  // 12.2 Suspended student login blocked
  const suspStudent = await devDataAdapter.students.create({
    first_name: 'Suspended',
    last_name: 'Student',
    date_of_birth: '2005-01-01',
    gender: 'MALE',
    institutional_email: 'suspended.student@student.eit.edu',
    personal_phone: '+1 (555) 000-1111',
    program_name: 'B.Tech Computer Science',
    department: 'CSE',
    admission_year: 2026,
    current_semester: 2,
    section: 'A',
    enrollment_status: StudentStatus.SUSPENDED,
  });
  const suspLogin = await devDataAdapter.auth.login(suspStudent.registration_number, 'dev_mock_hash', PortalType.Student);
  assert(
    suspLogin.success === false && suspLogin.error?.includes('SUSPENDED'),
    'Suspended student is blocked from logging in with descriptive error',
    suspLogin.error
  );

  // 12.3 All 6 permanent canonical office accounts exist and retain designated privileges
  const canonicalOffices = ['admin', 'admissionsoffice', 'academicoffice', 'coeoffice', 'finance', 'hosteloffice'];
  const allOfficesPresent = canonicalOffices.every((u) => SIX_PERMANENT_OFFICES.some((po) => po.canonical_username === u));
  assert(
    allOfficesPresent && SIX_PERMANENT_OFFICES.length >= 6,
    'All six canonical permanent office accounts are preserved intact',
    `Offices: ${canonicalOffices.join(', ')}`
  );

  // 12.4 Exactly 3 public login gateways supported
  const gatewayPortals = PORTAL_GATEWAYS.map((g) => g.id);
  assert(
    gatewayPortals.length === 3 &&
      gatewayPortals.includes(PortalType.Student) &&
      gatewayPortals.includes(PortalType.Employee) &&
      gatewayPortals.includes(PortalType.Parent),
    'Exactly three public login gateways exist: Student, Employee, and Parent/Guardian',
    `Gateways: ${gatewayPortals.join(', ')}`
  );

  // ===========================================================================
  // Summary
  // ===========================================================================
  const total = results.length;
  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;

  console.log('\n================================================================');
  console.log(`Phase 10 E2E Verification Summary: ${passed} / ${total} tests passed.`);
  if (failed > 0) {
    console.error(`❌ ${failed} tests failed!`);
    process.exit(1);
  } else {
    console.log('🎉 ALL PHASE 10 VERIFICATION CRITERIA SUCCESSFULLY PASSED!');
    console.log('================================================================\n');
  }
}

runPhase10Tests().catch((err) => {
  console.error('Fatal error running Phase 10 verification:', err);
  process.exit(1);
});
