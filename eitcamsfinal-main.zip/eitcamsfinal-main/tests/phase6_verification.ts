import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  ApplicationStatus,
  DocumentSubmissionStatus,
  DocumentVerificationStatus,
  AuthRole,
  PermissionScope,
  OfficeAssignmentStatus,
  StudentStatus,
  EmployeeCategory,
  EmploymentStatus,
} from '../src/types/database';
import { PortalType } from '../src/types/portal';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runPhase6Tests() {
  console.log('================================================================');
  console.log('   EIT Phase 6 Admissions Office Verification Test Suite       ');
  console.log('================================================================\n');

  // Setup actors
  const superAdminActor = { userId: 'admin', role: AuthRole.SUPER_ADMIN };
  const admissionsOfficeActor = { userId: 'admissionsoffice', role: AuthRole.OFFICE_ADMIN };
  const facultyActor = { userId: 'EMP-001', role: AuthRole.FACULTY, employeeId: 'EMP-001' };
  const parentActor = { userId: 'PAR-001', role: AuthRole.PARENT };
  const studentActor = { userId: 'STU-001', role: AuthRole.STUDENT };

  // ===========================================================================
  // Requirement 1: Admissions Access & Unauthorized Access Rejection
  // ===========================================================================
  console.log('--- 1. Admissions Access & Unauthorized Rejection ---');
  // 1.1 Super Admin access
  const allAppsSuper = await devDataAdapter.applicants.getAll();
  assert(
    Array.isArray(allAppsSuper) && allAppsSuper.length >= 5,
    'Super Admin can access Admissions applicants',
    `Found ${allAppsSuper.length} seed applicants`
  );

  // 1.2 Permanent Admissions Office access
  const app1 = await devDataAdapter.applicants.getById('EIT-APP-2026-0001');
  assert(
    Boolean(app1 && app1.application_id === 'EIT-APP-2026-0001'),
    'Permanent Admissions Office account (admissionsoffice) can query applicant dossier',
    app1?.first_name + ' ' + app1?.last_name
  );

  // 1.3 Faculty direct access rejection
  let facultyAccessError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: 'Unauthorized',
        last_name: 'Applicant',
        date_of_birth: '2006-01-01',
        gender: 'MALE',
        email: 'unauth.faculty@example.com',
        phone_number: '+1-555-1111',
        address: 'Faculty Quarters',
        intended_program: 'B.Tech Computer Science & Engineering',
        department: 'CSE',
        admission_year: 2026,
        previous_qualification: 'XII',
        marks_percentage: 85,
        application_date: '2026-09-01',
        application_status: ApplicationStatus.SUBMITTED,
      },
      facultyActor
    );
  } catch (err: any) {
    facultyAccessError = err.message;
  }
  assert(
    facultyAccessError.includes('cannot access Admissions Office administration') || facultyAccessError.includes('Unauthorized'),
    'Faculty role cannot perform Admissions applicant management',
    facultyAccessError
  );

  // 1.4 Parent / Student access rejection
  let parentAccessError = '';
  try {
    await devDataAdapter.applicants.updateStatus(
      'EIT-APP-2026-0002',
      ApplicationStatus.APPROVED,
      'Parent trying to approve',
      parentActor
    );
  } catch (err: any) {
    parentAccessError = err.message;
  }
  assert(
    parentAccessError.includes('cannot access Admissions Office administration') || parentAccessError.includes('Unauthorized'),
    'Parent and Student roles are strictly rejected from Admissions decisions',
    parentAccessError
  );

  // ===========================================================================
  // Requirement 2: Applicant Creation and Required-Field Validation
  // ===========================================================================
  console.log('\n--- 2. Applicant Creation & Required-Field Validation ---');

  // 2.1 Name validation
  let missingNameError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: '',
        last_name: '',
        date_of_birth: '2006-01-01',
        gender: 'FEMALE',
        email: 'test@example.com',
        phone_number: '+1-555-2222',
        address: '123 Main St',
        intended_program: 'B.Tech CSE',
        department: 'CSE',
        admission_year: 2026,
        previous_qualification: 'XII',
        marks_percentage: 80,
        application_date: '2026-09-01',
        application_status: ApplicationStatus.SUBMITTED,
      },
      admissionsOfficeActor
    );
  } catch (err: any) {
    missingNameError = err.message;
  }
  assert(
    missingNameError.includes('First name is required'),
    'Missing applicant name triggers inline validation error',
    missingNameError
  );

  // 2.2 Email format validation
  let invalidEmailError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: 'John',
        last_name: 'Doe',
        date_of_birth: '2006-01-01',
        gender: 'MALE',
        email: 'not-an-email-address',
        phone_number: '+1-555-2222',
        address: '123 Main St',
        intended_program: 'B.Tech CSE',
        department: 'CSE',
        admission_year: 2026,
        previous_qualification: 'XII',
        marks_percentage: 80,
        application_date: '2026-09-01',
        application_status: ApplicationStatus.SUBMITTED,
      },
      admissionsOfficeActor
    );
  } catch (err: any) {
    invalidEmailError = err.message;
  }
  assert(
    invalidEmailError.includes('Invalid email address format'),
    'Malformed email address format triggers validation error',
    invalidEmailError
  );

  // 2.3 Marks range validation
  let invalidMarksError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: 'John',
        last_name: 'Doe',
        date_of_birth: '2006-01-01',
        gender: 'MALE',
        email: 'john.doe.marks@example.com',
        phone_number: '+1-555-2222',
        address: '123 Main St',
        intended_program: 'B.Tech CSE',
        department: 'CSE',
        admission_year: 2026,
        previous_qualification: 'XII',
        marks_percentage: 125, // Invalid > 100
        application_date: '2026-09-01',
        application_status: ApplicationStatus.SUBMITTED,
      },
      admissionsOfficeActor
    );
  } catch (err: any) {
    invalidMarksError = err.message;
  }
  assert(
    invalidMarksError.includes('Marks or percentage must be a valid number between 0 and 100'),
    'Out-of-range marks percentage (>100 or <0) triggers validation error',
    invalidMarksError
  );

  // 2.4 Age / Date of birth validation
  let underageError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: 'Toddler',
        last_name: 'Applicant',
        date_of_birth: '2023-01-01', // Too young for college
        gender: 'MALE',
        email: 'toddler@example.com',
        phone_number: '+1-555-2222',
        address: '123 Main St',
        intended_program: 'B.Tech CSE',
        department: 'CSE',
        admission_year: 2026,
        previous_qualification: 'Preschool',
        marks_percentage: 90,
        application_date: '2026-09-01',
        application_status: ApplicationStatus.SUBMITTED,
      },
      admissionsOfficeActor
    );
  } catch (err: any) {
    underageError = err.message;
  }
  assert(
    underageError.includes('Applicant must be at least 14 years of age'),
    'Underage applicant date of birth triggers minimum age threshold validation',
    underageError
  );

  // 2.5 Valid applicant creation with unique ID allocation
  const validApp = await devDataAdapter.applicants.create(
    {
      first_name: 'Meera',
      last_name: 'Nair',
      date_of_birth: '2006-06-15',
      gender: 'FEMALE',
      email: 'meera.nair@example.com',
      phone_number: '+1-555-4433',
      address: '77 Palm Meadows, Kochi',
      intended_program: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      previous_qualification: 'State Board Higher Secondary (91.2%)',
      marks_percentage: 91.2,
      application_date: '2026-09-02',
      application_status: ApplicationStatus.SUBMITTED,
    },
    admissionsOfficeActor
  );
  assert(
    validApp.application_id.startsWith('EIT-APP-2026-') &&
      validApp.documents.length === 5 &&
      validApp.application_status === ApplicationStatus.SUBMITTED,
    'Valid applicant created with standard EIT-APP-YYYY-SEQ identifier and document checklist',
    `ID: ${validApp.application_id}, Docs: ${validApp.documents.length}`
  );

  // ===========================================================================
  // Requirement 3: Duplicate-Application Prevention
  // ===========================================================================
  console.log('\n--- 3. Duplicate-Application Prevention ---');

  // 3.1 Duplicate email for same admission year rejected
  let duplicateEmailError = '';
  try {
    await devDataAdapter.applicants.create(
      {
        first_name: 'Meera',
        last_name: 'Nair Duplicate',
        date_of_birth: '2006-06-15',
        gender: 'FEMALE',
        email: 'meera.nair@example.com', // Duplicate email
        phone_number: '+1-555-9999',
        address: 'Different Address',
        intended_program: 'B.Tech ECE',
        department: 'ECE',
        admission_year: 2026,
        previous_qualification: 'State Board',
        marks_percentage: 88,
        application_date: '2026-09-02',
        application_status: ApplicationStatus.SUBMITTED,
      },
      admissionsOfficeActor
    );
  } catch (err: any) {
    duplicateEmailError = err.message;
  }
  assert(
    duplicateEmailError.includes('already exists for admission year 2026'),
    'Duplicate applicant email for same admission year is blocked',
    duplicateEmailError
  );

  // 3.2 Household members sharing contact phone number is PERMITTED
  const siblingApp = await devDataAdapter.applicants.create(
    {
      first_name: 'Madhav',
      last_name: 'Nair', // Sibling
      date_of_birth: '2005-02-10',
      gender: 'MALE',
      email: 'madhav.nair@example.com', // Unique email
      phone_number: '+1-555-4433', // Shared household phone with Meera Nair!
      address: '77 Palm Meadows, Kochi',
      intended_program: 'B.Tech Mechanical Engineering',
      department: 'MECH',
      admission_year: 2026,
      previous_qualification: 'CBSE Class XII',
      marks_percentage: 86.4,
      application_date: '2026-09-02',
      application_status: ApplicationStatus.SUBMITTED,
    },
    admissionsOfficeActor
  );
  assert(
    Boolean(siblingApp.application_id) && siblingApp.phone_number === '+1-555-4433',
    'Legitimate applicant sharing household contact phone number is correctly accepted',
    `Sibling App ID: ${siblingApp.application_id}`
  );

  // ===========================================================================
  // Requirement 4: Applicant Search & Filtering
  // ===========================================================================
  console.log('\n--- 4. Applicant Search and Filtering ---');
  const allCurrent = await devDataAdapter.applicants.getAll();
  const cseApplicants = allCurrent.filter((a) => a.department === 'CSE');
  const meeraSearch = allCurrent.filter((a) => a.email.toLowerCase().includes('meera.nair'));
  assert(
    cseApplicants.length >= 2 && meeraSearch.length === 1,
    'Applicant records filterable by department and searchable by applicant email/name',
    `Found ${cseApplicants.length} CSE applicants, Meera Nair located`
  );

  // ===========================================================================
  // Requirement 5: Valid and Invalid Status Transitions
  // ===========================================================================
  console.log('\n--- 5. Valid and Invalid Status Transitions ---');

  // 5.1 Invalid transition: DRAFT or SUBMITTED -> directly APPROVED without document verification
  let invalidTransitionError = '';
  try {
    await devDataAdapter.applicants.updateStatus(
      siblingApp.application_id,
      ApplicationStatus.APPROVED,
      'Skipping review directly to approved',
      admissionsOfficeActor
    );
  } catch (err: any) {
    invalidTransitionError = err.message;
  }
  assert(
    invalidTransitionError.includes('Invalid application status transition') ||
      invalidTransitionError.includes('mandatory document'),
    'Invalid direct status transition (SUBMITTED -> APPROVED) is blocked',
    invalidTransitionError
  );

  // 5.2 Valid transition: SUBMITTED -> UNDER_REVIEW
  const underReviewApp = await devDataAdapter.applicants.updateStatus(
    validApp.application_id,
    ApplicationStatus.UNDER_REVIEW,
    'Commenced credentials review by admissions officer',
    admissionsOfficeActor
  );
  assert(
    underReviewApp.application_status === ApplicationStatus.UNDER_REVIEW,
    'Valid status transition SUBMITTED -> UNDER_REVIEW succeeds',
    `Status: ${underReviewApp.application_status}`
  );

  // 5.3 Valid transition: UNDER_REVIEW -> DOCUMENTS_PENDING
  const docsPendingApp = await devDataAdapter.applicants.updateStatus(
    validApp.application_id,
    ApplicationStatus.DOCUMENTS_PENDING,
    'Awaiting school migration certificate verification',
    admissionsOfficeActor
  );
  assert(
    docsPendingApp.application_status === ApplicationStatus.DOCUMENTS_PENDING,
    'Valid status transition UNDER_REVIEW -> DOCUMENTS_PENDING succeeds',
    `Status: ${docsPendingApp.application_status}`
  );

  // 5.4 Valid transition: DOCUMENTS_PENDING -> UNDER_REVIEW
  const resumedReviewApp = await devDataAdapter.applicants.updateStatus(
    validApp.application_id,
    ApplicationStatus.UNDER_REVIEW,
    'Documents received; resuming scrutiny',
    admissionsOfficeActor
  );
  assert(
    resumedReviewApp.application_status === ApplicationStatus.UNDER_REVIEW,
    'Valid status transition DOCUMENTS_PENDING -> UNDER_REVIEW succeeds',
    `Status: ${resumedReviewApp.application_status}`
  );

  // ===========================================================================
  // Requirement 6: Document Checklist Status Updates
  // ===========================================================================
  console.log('\n--- 6. Document Checklist Status Updates ---');
  // Update all documents for Meera Nair to VERIFIED
  for (const doc of resumedReviewApp.documents) {
    await devDataAdapter.applicants.updateDocumentStatus(
      validApp.application_id,
      doc.document_id,
      {
        submission_status: DocumentSubmissionStatus.SUBMITTED,
        verification_status: DocumentVerificationStatus.VERIFIED,
        reviewer_notes: `Verified against official board database: ${doc.document_code}`,
      },
      admissionsOfficeActor
    );
  }

  const updatedMeera = await devDataAdapter.applicants.getById(validApp.application_id);
  const allVerified = updatedMeera?.documents.every(
    (d) => d.verification_status === DocumentVerificationStatus.VERIFIED
  );
  assert(
    Boolean(allVerified),
    'Document checklist records updated with SUBMITTED and VERIFIED statuses and reviewer notes',
    `All ${updatedMeera?.documents.length} documents verified`
  );

  // ===========================================================================
  // Requirement 7: Approval Permissions & Audit History
  // ===========================================================================
  console.log('\n--- 7. Approval Permissions and Audit History ---');
  const approvedMeera = await devDataAdapter.applicants.updateStatus(
    validApp.application_id,
    ApplicationStatus.APPROVED,
    'All mandatory documents verified and qualifying marks criteria satisfied.',
    admissionsOfficeActor
  );
  assert(
    approvedMeera.application_status === ApplicationStatus.APPROVED &&
      approvedMeera.status_history.length >= 4,
    'Authorized Admissions user approves application after mandatory document verification',
    `History entries: ${approvedMeera.status_history.length}`
  );

  // Check audit log
  const recentAudit = await devDataAdapter.audit.getRecent();
  const admissionAuditEntry = recentAudit.find(
    (a) => a.target_worksheet === 'Applicants' && a.target_record_id === validApp.application_id
  );
  assert(
    Boolean(admissionAuditEntry),
    'Admissions status change generates immutable audit record with actor and reason',
    admissionAuditEntry?.description
  );

  // Rejection check with decision reason on siblingApp
  await devDataAdapter.applicants.updateStatus(
    siblingApp.application_id,
    ApplicationStatus.UNDER_REVIEW,
    'Commencing review',
    admissionsOfficeActor
  );
  const rejectedSibling = await devDataAdapter.applicants.updateStatus(
    siblingApp.application_id,
    ApplicationStatus.REJECTED,
    'Mechanical engineering intake quota fulfilled for cohort 2026.',
    admissionsOfficeActor
  );
  assert(
    rejectedSibling.application_status === ApplicationStatus.REJECTED &&
      Boolean(rejectedSibling.decision_reason?.includes('quota fulfilled')),
    'Application rejection records official decision reason in applicant dossier',
    rejectedSibling.decision_reason
  );

  // ===========================================================================
  // Requirement 8: Conversion of Approved Applicant to Student
  // ===========================================================================
  console.log('\n--- 8. Conversion of Approved Applicant to Student ---');
  const convertResult = await devDataAdapter.applicants.convertApprovedApplicantToStudent(
    validApp.application_id,
    admissionsOfficeActor
  );
  assert(
    convertResult.success === true &&
      convertResult.student.registration_number.startsWith('EIT-STU-2026-CSE-') &&
      convertResult.account?.username === convertResult.student.registration_number &&
      convertResult.account?.role === AuthRole.STUDENT,
    'Approved applicant converted into student record with guaranteed unique EIT student registration number',
    `Reg Number: ${convertResult.student.registration_number}`
  );

  // Verify applicant record updated with link
  const reloadedMeera = await devDataAdapter.applicants.getById(validApp.application_id);
  assert(
    reloadedMeera?.converted_to_student === true &&
      reloadedMeera?.student_id === convertResult.student.student_id &&
      reloadedMeera?.student_registration_number === convertResult.student.registration_number,
    'Applicant record links directly to newly created student master record',
    `Linked Student ID: ${reloadedMeera?.student_id}`
  );

  // ===========================================================================
  // Requirement 9: Ineligible Application Conversion Prevention
  // ===========================================================================
  console.log('\n--- 9. Ineligible Application Conversion Prevention ---');
  let ineligibleConvertError = '';
  try {
    await devDataAdapter.applicants.convertApprovedApplicantToStudent(
      siblingApp.application_id, // Status is REJECTED
      admissionsOfficeActor
    );
  } catch (err: any) {
    ineligibleConvertError = err.message;
  }
  assert(
    ineligibleConvertError.includes('not eligible for student conversion') ||
      ineligibleConvertError.includes('Only APPROVED applications can be converted'),
    'Rejected or ineligible application is strictly blocked from student conversion',
    ineligibleConvertError
  );

  // ===========================================================================
  // Requirement 10: Idempotent & Repeat-Safe Student Conversion
  // ===========================================================================
  console.log('\n--- 10. Repeat-Safe & Idempotent Student Conversion ---');
  const studentsBeforeSecondConvert = await devDataAdapter.students.getAll();
  const retryResult = await devDataAdapter.applicants.convertApprovedApplicantToStudent(
    validApp.application_id, // Already converted!
    admissionsOfficeActor
  );
  const studentsAfterSecondConvert = await devDataAdapter.students.getAll();

  assert(
    retryResult.success === true &&
      retryResult.alreadyConverted === true &&
      retryResult.student.student_id === convertResult.student.student_id &&
      studentsBeforeSecondConvert.length === studentsAfterSecondConvert.length,
    'Repeated conversion calls are idempotent and return existing student without duplicates',
    `Student Count Unchanged: ${studentsAfterSecondConvert.length}`
  );

  // ===========================================================================
  // Requirement 11: Student Registration Number & Login Consistency
  // ===========================================================================
  console.log('\n--- 11. Student Registration Number & Login Consistency ---');
  const studentLoginResult = await devDataAdapter.auth.login(
    convertResult.student.registration_number,
    'dev_mock_hash_student',
    PortalType.Student
  );
  assert(
    studentLoginResult.success === true &&
      studentLoginResult.session?.role === AuthRole.STUDENT &&
      studentLoginResult.session?.portalType === PortalType.Student &&
      studentLoginResult.session?.studentProfile?.student_id === convertResult.student.student_id,
    'Newly converted student can authenticate at Student Login portal using registration number',
    `Logged in student: ${studentLoginResult.session?.displayName}`
  );

  // ===========================================================================
  // Requirement 12: Preservation of Phase 1-5 Flows
  // ===========================================================================
  console.log('\n--- 12. Preservation of Existing Phase 1-5 Flows ---');
  // 12.1 Six permanent offices remain intact
  assert(
    SIX_PERMANENT_OFFICES.length === 6 &&
      SIX_PERMANENT_OFFICES[1].canonical_username === 'admissionsoffice' &&
      SIX_PERMANENT_OFFICES[0].canonical_username === 'admin',
    'All six permanent institutional offices remain immutable fixtures',
    `Admissions Office: ${SIX_PERMANENT_OFFICES[1].office_name}`
  );

  // 12.2 Administration Super Admin authentication remains functional
  const adminLogin = await devDataAdapter.auth.login('admin', 'dev_mock_hash_admin', PortalType.Employee);
  assert(
    adminLogin.success === true && adminLogin.session?.role === AuthRole.SUPER_ADMIN,
    'Administration Super Admin authentication and session management intact',
    `Admin Role: ${adminLogin.session?.role}`
  );

  // 12.3 Employee allocation and faculty assignment intact
  const facultyList = await devDataAdapter.facultyAssignments.getAll();
  assert(
    facultyList.length > 0,
    'Teaching faculty course allocations and employee management continue operating smoothly',
    `Active Course Allocations: ${facultyList.length}`
  );

  // Summary
  console.log('\n================================================================');
  const total = results.length;
  const passed = results.filter((r) => r.passed).length;
  const failed = results.filter((r) => !r.passed).length;
  console.log(`PHASE 6 TEST RESULTS: TOTAL: ${total} | PASSED: ${passed} | FAILED: ${failed}`);
  console.log('================================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runPhase6Tests().catch((err) => {
  console.error('Fatal test execution error:', err);
  process.exit(1);
});
