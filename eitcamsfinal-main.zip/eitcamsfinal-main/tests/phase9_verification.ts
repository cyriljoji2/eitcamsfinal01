import { devDataAdapter } from '../src/services/devDataAdapter';
import {
  AuthRole,
  FeeCategory,
  InvoiceStatus,
  PaymentMethod,
  PaymentLedgerStatus,
  PaymentStatus,
  AdjustmentType,
  AdjustmentStatus,
  RoomType,
  RoomOperationalStatus,
  BedOccupancyStatus,
  HostelAllocationLifecycleStatus,
  HostelChargeStatus,
  HostelGenderType,
} from '../src/types/database';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runPhase9Tests() {
  console.log('================================================================');
  console.log('   EIT Phase 9 Finance Office & Hostel Office Test Suite        ');
  console.log('================================================================\n');

  // Test Actors
  const superAdminActor = { userId: 'admin', role: AuthRole.SUPER_ADMIN };
  const financeActor = { userId: 'finance', role: AuthRole.OFFICE_ADMIN };
  const financeActor2 = { userId: 'finance_officer_2', role: AuthRole.OFFICE_ADMIN, employeeId: 'EMP-005' };
  const hostelActor = { userId: 'hosteloffice', role: AuthRole.OFFICE_ADMIN };
  const academicOfficeActor = { userId: 'academicoffice', role: AuthRole.OFFICE_ADMIN };
  const coeOfficeActor = { userId: 'coeoffice', role: AuthRole.OFFICE_ADMIN };
  const admissionsOfficeActor = { userId: 'admissionsoffice', role: AuthRole.OFFICE_ADMIN };
  const facultyActor = { userId: 'EMP-001', role: AuthRole.FACULTY, employeeId: 'EMP-001' };
  const student1Actor = { userId: 'STU-001', role: AuthRole.STUDENT };
  const student2Actor = { userId: 'STU-002', role: AuthRole.STUDENT };
  const parent1Actor = { userId: 'PAR-001', role: AuthRole.PARENT }; // Linked to STU-001 with can_view_finance=true
  const parent2Actor = { userId: 'PAR-002', role: AuthRole.PARENT }; // Linked to STU-002 with can_view_finance=false

  // ===========================================================================
  // 1. Finance & Hostel Authorization & Role Rejections
  // ===========================================================================
  console.log('--- 1. Finance & Hostel Authorization & Unauthorized Rejection ---');

  // 1.1 Super Admin has universal institutional oversight of Finance
  const structures = await devDataAdapter.finance.getFeeStructures(undefined, superAdminActor);
  assert(
    Array.isArray(structures) && structures.length >= 1,
    'Super Admin can access Finance fee structures',
    `Found ${structures.length} fee structures`
  );

  // 1.2 Canonical Finance Office has access
  const financeInvoices = await devDataAdapter.finance.getInvoices(undefined, financeActor);
  assert(
    Array.isArray(financeInvoices) && financeInvoices.length >= 1,
    'Canonical Finance Office (finance) has institutional invoice administration access',
    `Found ${financeInvoices.length} invoices`
  );

  // 1.3 Other offices explicitly denied from Finance administration
  let unauthFin1 = '';
  try {
    await devDataAdapter.finance.getInvoices(undefined, academicOfficeActor);
  } catch (err: any) {
    unauthFin1 = err.message;
  }
  assert(
    unauthFin1.includes('Unauthorized') || unauthFin1.includes('Finance Office'),
    'Academic Office account is rejected from Finance Office administration',
    unauthFin1
  );

  let unauthFin2 = '';
  try {
    await devDataAdapter.finance.getInvoices(undefined, hostelActor);
  } catch (err: any) {
    unauthFin2 = err.message;
  }
  assert(
    unauthFin2.includes('Unauthorized') || unauthFin2.includes('Finance Office'),
    'Hostel Office account is rejected from Finance Office administration',
    unauthFin2
  );

  // 1.4 Super Admin and Canonical Hostel Office have Hostel access
  const blocks = await devDataAdapter.hostel.getBlocks(superAdminActor);
  assert(
    Array.isArray(blocks) && blocks.length >= 1,
    'Super Admin can access Hostel blocks',
    `Found ${blocks.length} blocks`
  );

  const rooms = await devDataAdapter.hostel.getRooms(undefined, hostelActor);
  assert(
    Array.isArray(rooms) && rooms.length >= 1,
    'Canonical Hostel Office (hosteloffice) has access to Hostel room inventory',
    `Found ${rooms.length} rooms`
  );

  // 1.5 Other offices denied from Hostel administration
  let unauthHostel1 = '';
  try {
    await devDataAdapter.hostel.getRooms(undefined, academicOfficeActor);
  } catch (err: any) {
    unauthHostel1 = err.message;
  }
  assert(
    unauthHostel1.includes('Unauthorized') || unauthHostel1.includes('Hostel Office'),
    'Academic Office account is rejected from Hostel Office administration',
    unauthHostel1
  );

  let unauthHostel2 = '';
  try {
    await devDataAdapter.hostel.getRooms(undefined, financeActor);
  } catch (err: any) {
    unauthHostel2 = err.message;
  }
  assert(
    unauthHostel2.includes('Unauthorized') || unauthHostel2.includes('Hostel Office'),
    'Finance Office account is rejected from Hostel Office administration',
    unauthHostel2
  );

  let unauthHostel3 = '';
  try {
    await devDataAdapter.hostel.createRoom(
      { block_id: 'HST-BLK-A', room_number: '999', floor: 4, room_type: RoomType.SINGLE, capacity: 1 },
      facultyActor
    );
  } catch (err: any) {
    unauthHostel3 = err.message;
  }
  assert(
    unauthHostel3.includes('Unauthorized') || unauthHostel3.includes('Hostel Office'),
    'Faculty role is rejected from Hostel inventory management',
    unauthHostel3
  );

  // ===========================================================================
  // 2. Fee Structure Management & Validations
  // ===========================================================================
  console.log('\n--- 2. Fee Structure Management & Validations ---');

  const newStructure = await devDataAdapter.finance.createFeeStructure(
    {
      academic_year: '2026-2027',
      semester: 4,
      programme_code: 'BTECH-CSE',
      fee_category: FeeCategory.LABORATORY,
      fee_name: 'Advanced Microcontroller & Embedded Systems Lab',
      amount: 450.5,
      currency: 'USD',
      due_date: '2027-01-31',
      applicability: 'B.Tech CSE Semester 4 Laboratory Infrastructure',
      status: 'ACTIVE',
    },
    financeActor
  );
  assert(
    newStructure.structure_id.includes('FST') && newStructure.amount === 450.5,
    'Finance Office created Fee Structure with safe currency rounding',
    `Structure ID: ${newStructure.structure_id}, Amount: $${newStructure.amount}`
  );

  // Validation: Missing or negative amount
  let invalidStructErr = '';
  try {
    await devDataAdapter.finance.createFeeStructure(
      {
        academic_year: '2026-2027',
        semester: 4,
        programme_code: 'BTECH-CSE',
        fee_category: FeeCategory.LABORATORY,
        fee_name: 'Invalid Lab',
        amount: -100,
        currency: 'USD',
        due_date: '2027-01-31',
        applicability: 'Invalid negative fee',
        status: 'ACTIVE',
      },
      financeActor
    );
  } catch (err: any) {
    invalidStructErr = err.message;
  }
  assert(
    invalidStructErr.includes('positive number') || invalidStructErr.includes('Validation Error'),
    'Validation blocks fee structure with negative or zero amount',
    invalidStructErr
  );

  // Duplicate active fee structure prevention
  let dupStructErr = '';
  try {
    await devDataAdapter.finance.createFeeStructure(
      {
        academic_year: '2026-2027',
        semester: 4,
        programme_code: 'BTECH-CSE',
        fee_category: FeeCategory.LABORATORY,
        fee_name: 'Duplicate Lab',
        amount: 500,
        currency: 'USD',
        due_date: '2027-01-31',
        applicability: 'Duplicate fee structure',
        status: 'ACTIVE',
      },
      financeActor
    );
  } catch (err: any) {
    dupStructErr = err.message;
  }
  assert(
    dupStructErr.includes('Duplicate Fee Structure'),
    'Validation blocks duplicate active fee structure for identical programme, semester, and category',
    dupStructErr
  );

  // Updating Fee Structure
  const updatedStructure = await devDataAdapter.finance.updateFeeStructure(
    newStructure.structure_id,
    { amount: 475.0 },
    financeActor
  );
  assert(
    updatedStructure.amount === 475.0,
    'Finance Office successfully updated fee structure details',
    `Updated Amount: $${updatedStructure.amount}`
  );

  // ===========================================================================
  // 3. Invoice Generation & Subtotal / Currency Calculation
  // ===========================================================================
  console.log('\n--- 3. Invoice Generation & Subtotal / Currency Precision ---');

  const generatedInvoice = await devDataAdapter.finance.generateInvoice(
    {
      student_id: 'STU-001',
      academic_year: '2026-2027',
      semester: 4,
      fee_category: 'TUITION',
      due_date: '2027-02-15',
      line_items: [
        { fee_structure_id: 'FST-2026-TUITION-CSE', category: 'TUITION', description: 'Semester 4 Tuition', amount: 3500.0 },
        { category: 'LABORATORY', description: 'Advanced Systems Lab', amount: 475.0 },
        { category: 'LIBRARY', description: 'Digital Library Services', amount: 125.0 },
      ],
      notes: 'Semester 4 Standard Academic Fees',
    },
    financeActor
  );

  assert(
    generatedInvoice.subtotal === 4100.0 &&
    generatedInvoice.total_amount === 4100.0 &&
    generatedInvoice.outstanding_balance === 4100.0 &&
    generatedInvoice.status === InvoiceStatus.ISSUED,
    'Invoice generated with accurate subtotal, total, and outstanding balances',
    `Invoice: ${generatedInvoice.invoice_id}, Total: $${generatedInvoice.total_amount}, Outstanding: $${generatedInvoice.outstanding_balance}`
  );

  // Duplicate Billing Prevention
  let dupBillingErr = '';
  try {
    await devDataAdapter.finance.generateInvoice(
      {
        student_id: 'STU-001',
        academic_year: '2026-2027',
        semester: 4,
        fee_category: 'TUITION',
        due_date: '2027-02-15',
        line_items: [{ category: 'TUITION', description: 'Duplicate Tuition', amount: 3500.0 }],
      },
      financeActor
    );
  } catch (err: any) {
    dupBillingErr = err.message;
  }
  assert(
    dupBillingErr.includes('Duplicate Billing'),
    'Duplicate billing prevention blocks creating duplicate active invoice for same student, term, and category',
    dupBillingErr
  );

  // ===========================================================================
  // 4. Payment Processing, Partial Payments & Overpayment Prevention
  // ===========================================================================
  console.log('\n--- 4. Payment Processing, Partial Payments & Overpayment Prevention ---');

  const partialRef1 = `TXN-BANK-P1-${Date.now().toString().slice(-4)}`;
  const payment1 = await devDataAdapter.finance.recordPayment(
    generatedInvoice.invoice_id,
    1500.0,
    PaymentMethod.BANK_TRANSFER,
    partialRef1,
    'First installment paid via bank transfer',
    financeActor
  );

  const invAfterPay1 = await devDataAdapter.finance.getInvoiceById(generatedInvoice.invoice_id, financeActor);
  assert(
    payment1.status === PaymentLedgerStatus.VERIFIED &&
    invAfterPay1?.amount_paid === 1500.0 &&
    invAfterPay1?.outstanding_balance === 2600.0 &&
    invAfterPay1?.status === InvoiceStatus.PARTIALLY_PAID &&
    invAfterPay1?.payment_status === PaymentStatus.PARTIAL,
    'Recorded partial payment: amount_paid is $1500, outstanding is $2600, status is PARTIALLY_PAID',
    `Status: ${invAfterPay1?.status}, Outstanding: $${invAfterPay1?.outstanding_balance}`
  );

  // Prevent duplicate transaction reference
  let dupTxnErr = '';
  try {
    await devDataAdapter.finance.recordPayment(
      generatedInvoice.invoice_id,
      500.0,
      PaymentMethod.CARD,
      partialRef1,
      'Duplicate ref test',
      financeActor
    );
  } catch (err: any) {
    dupTxnErr = err.message;
  }
  assert(
    dupTxnErr.includes('Duplicate Payment Reference'),
    'System strictly rejects duplicate payment transaction reference in the ledger',
    dupTxnErr
  );

  // Prevent overpayment beyond outstanding balance ($2600 remaining)
  let overpayErr = '';
  try {
    await devDataAdapter.finance.recordPayment(
      generatedInvoice.invoice_id,
      3000.0,
      PaymentMethod.CASH,
      `TXN-OVERPAY-${Date.now()}`,
      'Excess payment test',
      financeActor
    );
  } catch (err: any) {
    overpayErr = err.message;
  }
  assert(
    overpayErr.includes('cannot exceed outstanding invoice balance'),
    'Validation blocks payment amount exceeding outstanding invoice balance',
    overpayErr
  );

  // Record second payment to fully settle invoice ($2600)
  const partialRef2 = `TXN-CARD-P2-${Date.now().toString().slice(-4)}`;
  const payment2 = await devDataAdapter.finance.recordPayment(
    generatedInvoice.invoice_id,
    2600.0,
    PaymentMethod.CARD,
    partialRef2,
    'Final installment paid via debit card',
    financeActor
  );

  const invAfterPay2 = await devDataAdapter.finance.getInvoiceById(generatedInvoice.invoice_id, financeActor);
  assert(
    invAfterPay2?.amount_paid === 4100.0 &&
    invAfterPay2?.outstanding_balance === 0.0 &&
    invAfterPay2?.status === InvoiceStatus.PAID &&
    invAfterPay2?.payment_status === PaymentStatus.PAID,
    'Subsequent payment fully settles invoice: outstanding is $0, status transitions to PAID',
    `Invoice Status: ${invAfterPay2?.status}, Outstanding: $${invAfterPay2?.outstanding_balance}`
  );

  // ===========================================================================
  // 5. Reversals & Refunds Workflow
  // ===========================================================================
  console.log('\n--- 5. Payment Reversals & Refunds Workflow ---');

  // Reverse payment2 ($2600)
  const reversedPayment2 = await devDataAdapter.finance.reversePayment(
    payment2.payment_id,
    'Bank chargeback / transaction dispute notification',
    financeActor
  );
  const invAfterReversal = await devDataAdapter.finance.getInvoiceById(generatedInvoice.invoice_id, financeActor);
  assert(
    reversedPayment2.status === PaymentLedgerStatus.REVERSED &&
    invAfterReversal?.amount_paid === 1500.0 &&
    invAfterReversal?.outstanding_balance === 2600.0 &&
    invAfterReversal?.status === InvoiceStatus.PARTIALLY_PAID,
    'Payment reversal updates payment to REVERSED and accurately restores invoice balance and PARTIALLY_PAID status',
    `Reversed: ${reversedPayment2.payment_id}, Invoice Outstanding: $${invAfterReversal?.outstanding_balance}`
  );

  // Re-reversal blocked
  let reReverseErr = '';
  try {
    await devDataAdapter.finance.reversePayment(payment2.payment_id, 'Duplicate reversal attempt', financeActor);
  } catch (err: any) {
    reReverseErr = err.message;
  }
  assert(
    reReverseErr.includes('already been reversed'),
    'System blocks attempting to reverse an already reversed payment',
    reReverseErr
  );

  // Partial refund on payment1 ($1500 payment: refund $500)
  const refundedPayment1 = await devDataAdapter.finance.refundPayment(
    payment1.payment_id,
    500.0,
    'Approved administrative tuition concession refund',
    financeActor
  );
  const invAfterRefund = await devDataAdapter.finance.getInvoiceById(generatedInvoice.invoice_id, financeActor);
  assert(
    refundedPayment1.refund_amount === 500.0 &&
    refundedPayment1.status === PaymentLedgerStatus.VERIFIED &&
    invAfterRefund?.amount_paid === 1000.0 &&
    invAfterRefund?.outstanding_balance === 3100.0,
    'Partial refund of $500 adjusts payment refund_amount and updates invoice outstanding balance to $3100',
    `Payment Status: ${refundedPayment1.status}, Invoice Amount Paid: $${invAfterRefund?.amount_paid}`
  );

  // Excessive refund blocked (remaining refundable is $1000; attempt $1200)
  let excessRefundErr = '';
  try {
    await devDataAdapter.finance.refundPayment(
      payment1.payment_id,
      1200.0,
      'Excessive refund attempt',
      financeActor
    );
  } catch (err: any) {
    excessRefundErr = err.message;
  }
  assert(
    excessRefundErr.includes('cannot exceed remaining refundable'),
    'Validation blocks refund amount exceeding remaining refundable payment balance',
    excessRefundErr
  );

  // Full remainder refund of payment1 ($1000)
  const finalRefundPayment1 = await devDataAdapter.finance.refundPayment(
    payment1.payment_id,
    1000.0,
    'Full remainder fee refund',
    financeActor
  );
  assert(
    finalRefundPayment1.status === PaymentLedgerStatus.REFUNDED &&
    finalRefundPayment1.refund_amount === 1500.0,
    'Complete refund transitions payment status to REFUNDED with cumulative refund of $1500',
    `Status: ${finalRefundPayment1.status}, Total Refunded: $${finalRefundPayment1.refund_amount}`
  );

  // Re-refund of fully refunded payment blocked
  let alreadyRefundedErr = '';
  try {
    await devDataAdapter.finance.refundPayment(payment1.payment_id, 100.0, 'Over refund', financeActor);
  } catch (err: any) {
    alreadyRefundedErr = err.message;
  }
  assert(
    alreadyRefundedErr.includes('already been fully refunded'),
    'System blocks refunding an already fully refunded payment',
    alreadyRefundedErr
  );

  // ===========================================================================
  // 6. Discounts, Fee Adjustments & Separation of Duties
  // ===========================================================================
  console.log('\n--- 6. Discounts, Fee Adjustments & Separation of Duties ---');

  // Create fresh invoice for adjustment test
  const adjInvoice = await devDataAdapter.finance.generateInvoice(
    {
      student_id: 'STU-002',
      academic_year: '2026-2027',
      semester: 4,
      fee_category: 'TUITION',
      due_date: '2027-02-15',
      line_items: [{ category: 'TUITION', description: 'ECE Semester 4 Tuition', amount: 3500.0 }],
    },
    financeActor
  );

  // Request adjustment of $1000 (MERIT_DISCOUNT)
  const adjustmentReq = await devDataAdapter.finance.requestAdjustment(
    {
      invoice_id: adjInvoice.invoice_id,
      adjustment_type: AdjustmentType.MERIT_DISCOUNT,
      amount: 1000.0,
      reason: 'Dean Merit Scholarship for top 5% semester academic standing',
    },
    financeActor
  );
  assert(
    adjustmentReq.status === AdjustmentStatus.PENDING_APPROVAL && adjustmentReq.amount === 1000.0,
    'Finance staff requested Merit Discount of $1000 with PENDING_APPROVAL status',
    `Adjustment ID: ${adjustmentReq.adjustment_id}`
  );

  // Separation of duties: Creator cannot approve their own adjustment unless Super Admin
  let selfApproveErr = '';
  try {
    await devDataAdapter.finance.approveAdjustment(adjustmentReq.adjustment_id, financeActor);
  } catch (err: any) {
    selfApproveErr = err.message;
  }
  assert(
    selfApproveErr.includes('Separation of Duties Violation'),
    'Separation of Duties prevents requesting officer from approving their own financial adjustment',
    selfApproveErr
  );

  // Super Admin or separate authorized officer approves adjustment
  const approvedAdj = await devDataAdapter.finance.approveAdjustment(adjustmentReq.adjustment_id, superAdminActor);
  const invAfterAdj = await devDataAdapter.finance.getInvoiceById(adjInvoice.invoice_id, financeActor);
  assert(
    approvedAdj.status === AdjustmentStatus.APPROVED &&
    invAfterAdj?.adjustments_total === 1000.0 &&
    invAfterAdj?.total_amount === 2500.0 &&
    invAfterAdj?.outstanding_balance === 2500.0,
    'Authorized approval applies adjustment: invoice total_amount reduced from $3500 to $2500',
    `Adjustments: $${invAfterAdj?.adjustments_total}, Outstanding: $${invAfterAdj?.outstanding_balance}`
  );

  // 100% full fee waiver test
  const waiverInvoice = await devDataAdapter.finance.generateInvoice(
    {
      student_id: 'STU-002',
      academic_year: '2026-2027',
      semester: 4,
      fee_category: 'EXAMINATION',
      due_date: '2027-03-01',
      line_items: [{ category: 'EXAMINATION', description: 'Semester Exam Fee', amount: 200.0 }],
    },
    financeActor
  );
  const waiverReq = await devDataAdapter.finance.requestAdjustment(
    {
      invoice_id: waiverInvoice.invoice_id,
      adjustment_type: AdjustmentType.FEE_WAIVER,
      amount: 200.0,
      reason: 'Full institutional hardship fee waiver',
    },
    financeActor
  );
  await devDataAdapter.finance.approveAdjustment(waiverReq.adjustment_id, superAdminActor);
  const waiverInvAfter = await devDataAdapter.finance.getInvoiceById(waiverInvoice.invoice_id, financeActor);
  assert(
    waiverInvAfter?.total_amount === 0.0 &&
    waiverInvAfter?.outstanding_balance === 0.0 &&
    waiverInvAfter?.status === InvoiceStatus.PAID &&
    waiverInvAfter?.payment_status === PaymentStatus.PAID,
    '100% fee waiver reduces total and outstanding to $0 and marks invoice as PAID',
    `Invoice Status: ${waiverInvAfter?.status}, Payment Status: ${waiverInvAfter?.payment_status}`
  );

  // Rejection of adjustment with documented reason
  const rejectTestInvoice = await devDataAdapter.finance.generateInvoice(
    {
      student_id: 'STU-002',
      academic_year: '2026-2027',
      semester: 4,
      fee_category: 'LABORATORY',
      due_date: '2027-03-01',
      line_items: [{ category: 'LABORATORY', description: 'Specialized Hardware Lab Fee', amount: 300.0 }],
    },
    financeActor
  );
  const rejectAdjReq = await devDataAdapter.finance.requestAdjustment(
    {
      invoice_id: rejectTestInvoice.invoice_id,
      adjustment_type: AdjustmentType.CONCESSION,
      amount: 150.0,
      reason: 'Late concession request',
    },
    financeActor
  );
  const rejectedAdj = await devDataAdapter.finance.rejectAdjustment(
    rejectAdjReq.adjustment_id,
    'Concession application deadline passed for current academic term.',
    financeActor
  );
  assert(
    rejectedAdj.status === AdjustmentStatus.REJECTED &&
    Boolean(rejectedAdj.rejection_reason?.includes('deadline passed')),
    'Finance Officer rejected adjustment request with documented justification reason',
    `Status: ${rejectedAdj.status}`
  );

  // ===========================================================================
  // 7. Receipts, Fee Statements & Privacy Isolation
  // ===========================================================================
  console.log('\n--- 7. Receipts, Fee Statements & Privacy Isolation ---');

  // Receipt lookup
  const receiptDetail = await devDataAdapter.finance.getReceipt('PAY-2026-0001', financeActor);
  assert(
    receiptDetail !== null &&
    receiptDetail.payment.payment_id === 'PAY-2026-0001' &&
    receiptDetail.student.student_id === 'STU-001' &&
    receiptDetail.invoice.invoice_id === 'INV-2026-001',
    'Receipt lookup by ID returns linked payment, student profile, and invoice line items',
    `Receipt Number: ${receiptDetail?.payment.receipt_number}`
  );

  // Student can view their own fee statement
  const stu1Statement = await devDataAdapter.finance.getStudentFeeStatement('STU-001', student1Actor);
  assert(
    stu1Statement.student.student_id === 'STU-001' &&
    stu1Statement.invoices.length >= 1 &&
    typeof stu1Statement.totalOutstanding === 'number',
    'Student STU-001 can access their own fee statement and balance breakdown',
    `Total Invoiced: $${stu1Statement.totalInvoiced}, Total Outstanding: $${stu1Statement.totalOutstanding}`
  );

  // Student isolation: STU-001 blocked from STU-002 financial records
  let stuIsolationErr = '';
  try {
    await devDataAdapter.finance.getStudentFeeStatement('STU-002', student1Actor);
  } catch (err: any) {
    stuIsolationErr = err.message;
  }
  assert(
    stuIsolationErr.includes('Unauthorized') || stuIsolationErr.includes('other students'),
    'Student isolation strictly blocks STU-001 from viewing STU-002 fee statement',
    stuIsolationErr
  );

  // Student blocked from viewing other student receipt
  let stuReceiptErr = '';
  try {
    await devDataAdapter.finance.getReceipt('PAY-2026-0003', student1Actor); // STU-002 payment
  } catch (err: any) {
    stuReceiptErr = err.message;
  }
  assert(
    stuReceiptErr.includes('Unauthorized') || stuReceiptErr.includes('other students'),
    'Student isolation strictly blocks student from viewing receipt of another student',
    stuReceiptErr
  );

  // Parent PAR-001 has active link with can_view_finance=true -> permitted
  const parent1Statement = await devDataAdapter.finance.getStudentFeeStatement('STU-001', parent1Actor);
  assert(
    parent1Statement.student.student_id === 'STU-001',
    'Authorized parent PAR-001 with can_view_finance=true can view ward financial statement',
    `Ward: ${parent1Statement.student.first_name}`
  );

  // Parent PAR-002 has can_view_finance=false -> blocked
  let parent2FinErr = '';
  try {
    await devDataAdapter.finance.getStudentFeeStatement('STU-002', parent2Actor);
  } catch (err: any) {
    parent2FinErr = err.message;
  }
  assert(
    parent2FinErr.includes('Access Denied') || parent2FinErr.includes('can_view_finance is false'),
    'Parent PAR-002 without can_view_finance permission is denied access to ward fee statement',
    parent2FinErr
  );

  // Student self-payment online
  const studentPayRef = `TXN-STU-ONLINE-${Date.now().toString().slice(-4)}`;
  const stuSelfPay = await devDataAdapter.finance.recordPayment(
    adjInvoice.invoice_id,
    500.0,
    PaymentMethod.CARD,
    studentPayRef,
    'Online self payment by student',
    student2Actor
  );
  assert(
    stuSelfPay.amount === 500.0 && stuSelfPay.status === PaymentLedgerStatus.VERIFIED,
    'Student STU-002 successfully made online payment against their own invoice',
    `Payment ID: ${stuSelfPay.payment_id}`
  );

  // Student blocked from paying another student invoice
  let stuPayOtherErr = '';
  try {
    await devDataAdapter.finance.recordPayment(
      adjInvoice.invoice_id,
      100.0,
      PaymentMethod.CARD,
      `TXN-UNAUTH-${Date.now()}`,
      'Unauthorized student payment',
      student1Actor
    );
  } catch (err: any) {
    stuPayOtherErr = err.message;
  }
  assert(
    stuPayOtherErr.includes('Unauthorized') || stuPayOtherErr.includes('other students'),
    'Student STU-001 is blocked from recording payments on STU-002 invoice',
    stuPayOtherErr
  );

  // ===========================================================================
  // 8. Hostel Inventory, Rooms & Bed Management
  // ===========================================================================
  console.log('\n--- 8. Hostel Inventory, Rooms & Bed Management ---');

  // Create new Room in Block A
  const createdRoom = await devDataAdapter.hostel.createRoom(
    {
      block_id: 'HST-BLK-A',
      room_number: '401',
      floor: 4,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['Air Conditioning', 'High-Speed Wi-Fi', 'Study Desks'],
      bed_identifiers: ['A', 'B'],
    },
    hostelActor
  );
  assert(
    createdRoom.room_number === '401' && createdRoom.beds.length === 2 && createdRoom.status === RoomOperationalStatus.ACTIVE,
    'Hostel Office created room with 2 available beds in Block A',
    `Room ID: ${createdRoom.room_id}, Beds: ${createdRoom.beds.map((b) => b.bed_identifier).join(', ')}`
  );

  // Duplicate room prevention in same block
  let dupRoomErr = '';
  try {
    await devDataAdapter.hostel.createRoom(
      { block_id: 'HST-BLK-A', room_number: '401', floor: 4, room_type: RoomType.DOUBLE, capacity: 2 },
      hostelActor
    );
  } catch (err: any) {
    dupRoomErr = err.message;
  }
  assert(
    dupRoomErr.includes('Duplicate Room'),
    'Validation blocks creating duplicate room number within the same hostel block',
    dupRoomErr
  );

  // Bed inventory query
  const bedInv = await devDataAdapter.hostel.getBedInventory({ block_id: 'HST-BLK-A' }, hostelActor);
  assert(
    bedInv.length >= 2,
    'Queried bed inventory with block filtering',
    `Found ${bedInv.length} beds in Block A`
  );

  // Room status update to UNDER_MAINTENANCE updates beds to MAINTENANCE
  const maintRoom = await devDataAdapter.hostel.updateRoomStatus(
    createdRoom.room_id,
    RoomOperationalStatus.UNDER_MAINTENANCE,
    hostelActor
  );
  assert(
    maintRoom.status === RoomOperationalStatus.UNDER_MAINTENANCE &&
    maintRoom.beds.every((b) => b.status === BedOccupancyStatus.MAINTENANCE),
    'Setting room to UNDER_MAINTENANCE automatically transitions available beds to MAINTENANCE status',
    `Room Status: ${maintRoom.status}`
  );

  // Restore room status to ACTIVE
  const activeRoom = await devDataAdapter.hostel.updateRoomStatus(
    createdRoom.room_id,
    RoomOperationalStatus.ACTIVE,
    hostelActor
  );
  assert(
    activeRoom.status === RoomOperationalStatus.ACTIVE &&
    activeRoom.beds.every((b) => b.status === BedOccupancyStatus.AVAILABLE),
    'Restoring room to ACTIVE restores maintenance beds back to AVAILABLE status',
    `Room Status: ${activeRoom.status}`
  );

  // ===========================================================================
  // 9. Student Bed Allocation, Capacity & Gender Enforcement
  // ===========================================================================
  console.log('\n--- 9. Student Bed Allocation, Capacity & Gender Enforcement ---');

  // Create student STU-003 for allocation test
  const newStudent = await devDataAdapter.students.create({
    registration_number: 'EIT-STU-2026-CSE-0003',
    first_name: 'Dev',
    last_name: 'Patel',
    date_of_birth: '2005-11-15',
    gender: 'MALE',
    institutional_email: 'dev.patel@student.eit.edu',
    personal_phone: '+1 (555) 777-8899',
    program_name: 'B.Tech Computer Science & Engineering',
    department: 'CSE',
    admission_year: 2026,
    current_semester: 3,
    section: 'A',
    enrollment_status: 'ENROLLED' as any,
  });

  // Allocate bed A in room 401 to newStudent (Dev Patel)
  const targetBedId = createdRoom.beds[0].bed_id;
  const newAllocation = await devDataAdapter.hostel.allocateStudentBed(
    {
      student_id: newStudent.student_id,
      bed_id: targetBedId,
      academic_year: '2026-2027',
      semester: 4,
      start_date: '2027-01-10',
      emergency_contact_phone: '+1 (555) 999-1122',
    },
    hostelActor
  );
  assert(
    newAllocation.status === HostelAllocationLifecycleStatus.ALLOCATED &&
    newAllocation.room_number === '401' &&
    newAllocation.bed_identifier === 'A',
    'Hostel Office allocated available bed to student successfully',
    `Allocation ID: ${newAllocation.allocation_id}`
  );

  // Verify bed is now marked OCCUPIED in inventory
  const roomAfterAlloc = await devDataAdapter.hostel.getRoomById(createdRoom.room_id, hostelActor);
  const occupiedBed = roomAfterAlloc?.beds.find((b) => b.bed_id === targetBedId);
  assert(
    occupiedBed?.status === BedOccupancyStatus.OCCUPIED && occupiedBed.current_allocation_id === newAllocation.allocation_id,
    'Allocated bed transitioned to OCCUPIED status with current allocation reference',
    `Bed Status: ${occupiedBed?.status}`
  );

  // Cannot allocate already occupied bed
  let occBedErr = '';
  try {
    await devDataAdapter.hostel.allocateStudentBed(
      {
        student_id: 'STU-001',
        bed_id: targetBedId,
        academic_year: '2026-2027',
        start_date: '2027-01-10',
      },
      hostelActor
    );
  } catch (err: any) {
    occBedErr = err.message;
  }
  assert(
    occBedErr.includes('Bed Unavailable') || occBedErr.includes('OCCUPIED'),
    'Validation blocks allocating a bed that is currently OCCUPIED',
    occBedErr
  );

  // Duplicate active allocation prevention for same student
  const secondBedId = createdRoom.beds[1].bed_id;
  let dupStudentAllocErr = '';
  try {
    await devDataAdapter.hostel.allocateStudentBed(
      {
        student_id: newStudent.student_id,
        bed_id: secondBedId,
        academic_year: '2026-2027',
        start_date: '2027-01-10',
      },
      hostelActor
    );
  } catch (err: any) {
    dupStudentAllocErr = err.message;
  }
  assert(
    dupStudentAllocErr.includes('Duplicate Active Allocation'),
    'Validation blocks assigning duplicate active hostel allocation to the same student',
    dupStudentAllocErr
  );

  // Gender check: Female student into Boys block
  let genderErr = '';
  try {
    const femaleStudent = await devDataAdapter.students.create({
      registration_number: 'EIT-STU-2026-CSE-0004',
      first_name: 'Kavita',
      last_name: 'Sharma',
      date_of_birth: '2005-08-10',
      gender: 'FEMALE',
      institutional_email: 'kavita.sharma@student.eit.edu',
      personal_phone: '+1 (555) 777-6655',
      program_name: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      current_semester: 3,
      section: 'A',
      enrollment_status: 'ENROLLED' as any,
    });
    await devDataAdapter.hostel.allocateStudentBed(
      {
        student_id: femaleStudent.student_id,
        bed_id: secondBedId,
        academic_year: '2026-2027',
        start_date: '2027-01-10',
      },
      hostelActor
    );
  } catch (err: any) {
    genderErr = err.message;
  }
  assert(
    genderErr.includes('Gender Incompatibility'),
    'Gender compatibility enforced: Female student rejected from Boys hostel block',
    genderErr
  );

  // ===========================================================================
  // 10. Check-in, Transfer & Check-out Life Cycle
  // ===========================================================================
  console.log('\n--- 10. Check-in, Transfer & Check-out Life Cycle ---');

  // Check-in student
  const checkedInAlloc = await devDataAdapter.hostel.checkInStudent(newAllocation.allocation_id, hostelActor);
  assert(
    checkedInAlloc.status === HostelAllocationLifecycleStatus.CHECKED_IN &&
    Boolean(checkedInAlloc.checked_in_at),
    'Student check-in recorded successfully with status CHECKED_IN and timestamp',
    `Checked in at: ${checkedInAlloc.checked_in_at}`
  );

  // Transfer student to Bed B in Room 401
  const transferredAlloc = await devDataAdapter.hostel.transferStudentBed(
    newAllocation.allocation_id,
    secondBedId,
    'Roommate mutual convenience swap',
    '2027-01-20',
    hostelActor
  );
  assert(
    transferredAlloc.bed_identifier === 'B' &&
    transferredAlloc.status === HostelAllocationLifecycleStatus.TRANSFERRED &&
    transferredAlloc.transfer_history?.length === 1,
    'Student transferred to new bed: previous bed released and transfer history logged',
    `New Bed: ${transferredAlloc.bed_identifier}, History: ${transferredAlloc.transfer_history?.[0]?.reason}`
  );

  // Check that old bed is now AVAILABLE
  const roomAfterTransfer = await devDataAdapter.hostel.getRoomById(createdRoom.room_id, hostelActor);
  const oldBed = roomAfterTransfer?.beds.find((b) => b.bed_id === targetBedId);
  const newBed = roomAfterTransfer?.beds.find((b) => b.bed_id === secondBedId);
  assert(
    oldBed?.status === BedOccupancyStatus.AVAILABLE && newBed?.status === BedOccupancyStatus.OCCUPIED,
    'Bed inventory reflects transfer: old bed is AVAILABLE, new bed is OCCUPIED',
    `Old Bed: ${oldBed?.status}, New Bed: ${newBed?.status}`
  );

  // Student check-out
  const checkedOutAlloc = await devDataAdapter.hostel.checkOutStudent(
    newAllocation.allocation_id,
    'Academic term completion clearance',
    undefined,
    hostelActor
  );
  const roomAfterCheckout = await devDataAdapter.hostel.getRoomById(createdRoom.room_id, hostelActor);
  const vacatedBed = roomAfterCheckout?.beds.find((b) => b.bed_id === secondBedId);
  assert(
    checkedOutAlloc.status === HostelAllocationLifecycleStatus.CHECKED_OUT &&
    vacatedBed?.status === BedOccupancyStatus.AVAILABLE,
    'Student check-out transitions status to CHECKED_OUT and frees bed to AVAILABLE',
    `Allocation Status: ${checkedOutAlloc.status}, Bed Status: ${vacatedBed?.status}`
  );

  // ===========================================================================
  // 11. Hostel–Finance Integration & Billing Reconciliation
  // ===========================================================================
  console.log('\n--- 11. Hostel–Finance Integration & Billing Reconciliation ---');

  // Hostel Office creates a charge request for boarders
  const chargeRequest = await devDataAdapter.hostel.requestHostelCharge(
    {
      allocation_id: 'HST-2026-001',
      billing_period: '2026-2027-SEM4',
      amount: 1350.0,
      description: 'Spring 2027 Hostel Boarding & Electricity Charges',
    },
    hostelActor
  );
  assert(
    chargeRequest.status === HostelChargeStatus.REQUESTED && chargeRequest.amount === 1350.0,
    'Hostel Office initiated charge request for $1350 with status REQUESTED',
    `Charge ID: ${chargeRequest.charge_request_id}`
  );

  // Prevent duplicate charge request for same allocation and period
  let dupChargeErr = '';
  try {
    await devDataAdapter.hostel.requestHostelCharge(
      {
        allocation_id: 'HST-2026-001',
        billing_period: '2026-2027-SEM4',
        amount: 1350.0,
        description: 'Duplicate charge test',
      },
      hostelActor
    );
  } catch (err: any) {
    dupChargeErr = err.message;
  }
  assert(
    dupChargeErr.includes('Duplicate Charge Request'),
    'Validation blocks duplicate hostel charge requests for the same allocation and period',
    dupChargeErr
  );

  // Finance Office issues invoice for hostel charge request
  const hostelInvoice = await devDataAdapter.finance.issueInvoiceForHostelCharge(
    chargeRequest.charge_request_id,
    financeActor
  );
  const updatedChargeReq = (await devDataAdapter.hostel.getChargeRequests(
    { allocation_id: 'HST-2026-001' },
    hostelActor
  )).find((c) => c.charge_request_id === chargeRequest.charge_request_id);

  assert(
    hostelInvoice.fee_category === 'HOSTEL' &&
    hostelInvoice.total_amount === 1350.0 &&
    hostelInvoice.hostel_charge_id === chargeRequest.charge_request_id &&
    updatedChargeReq?.status === HostelChargeStatus.INVOICED &&
    updatedChargeReq?.invoice_id === hostelInvoice.invoice_id,
    'Finance Office issued invoice for hostel charge: charge request transitions to INVOICED with invoice reference',
    `Invoice ID: ${hostelInvoice.invoice_id}, Charge Status: ${updatedChargeReq?.status}`
  );

  // Prevent re-invoicing already invoiced charge request
  let reInvoiceErr = '';
  try {
    await devDataAdapter.finance.issueInvoiceForHostelCharge(chargeRequest.charge_request_id, financeActor);
  } catch (err: any) {
    reInvoiceErr = err.message;
  }
  assert(
    reInvoiceErr.includes('already been invoiced'),
    'Validation blocks issuing duplicate invoices for an already invoiced hostel charge request',
    reInvoiceErr
  );

  // Cancelling invoice reconciles and reverts charge request back to REQUESTED
  await devDataAdapter.finance.cancelInvoice(
    hostelInvoice.invoice_id,
    'Correction of boarding tariff calculation sanctioned by Warden',
    financeActor
  );
  const revertedCharge = (await devDataAdapter.hostel.getChargeRequests(
    { allocation_id: 'HST-2026-001' },
    hostelActor
  )).find((c) => c.charge_request_id === chargeRequest.charge_request_id);
  assert(
    revertedCharge?.status === HostelChargeStatus.REQUESTED &&
    revertedCharge.invoice_id === undefined,
    'Cancelling hostel invoice reverts linked charge request back to REQUESTED status',
    `Reverted Charge Status: ${revertedCharge?.status}`
  );

  // ===========================================================================
  // 12. Student & Parent Hostel Privacy Isolation
  // ===========================================================================
  console.log('\n--- 12. Student & Parent Hostel Privacy Isolation ---');

  // Student STU-001 views their own hostel details
  const stu1Hostel = await devDataAdapter.hostel.getStudentHostelDetails('STU-001', student1Actor);
  assert(
    stu1Hostel.student.student_id === 'STU-001' && stu1Hostel.currentAllocation !== null,
    'Student STU-001 can view their own hostel details, current allocation, and room info',
    `Current Room: ${stu1Hostel.currentAllocation?.room_number}`
  );

  // Student STU-001 blocked from STU-002 hostel details
  let stuHostelIsolationErr = '';
  try {
    await devDataAdapter.hostel.getStudentHostelDetails('STU-002', student1Actor);
  } catch (err: any) {
    stuHostelIsolationErr = err.message;
  }
  assert(
    stuHostelIsolationErr.includes('Unauthorized') || stuHostelIsolationErr.includes('other students'),
    'Student isolation strictly blocks STU-001 from viewing STU-002 hostel details',
    stuHostelIsolationErr
  );

  // Parent PAR-001 views ward STU-001 hostel details
  const parent1Hostel = await devDataAdapter.hostel.getStudentHostelDetails('STU-001', parent1Actor);
  assert(
    parent1Hostel.student.student_id === 'STU-001',
    'Linked parent PAR-001 can access ward hostel residency details',
    `Ward Room: ${parent1Hostel.currentAllocation?.room_number}`
  );

  // Unlinked parent blocked from viewing student hostel details
  let unlinkedParentHostelErr = '';
  try {
    await devDataAdapter.hostel.getStudentHostelDetails('STU-001', parent2Actor); // PAR-002 not linked to STU-001
  } catch (err: any) {
    unlinkedParentHostelErr = err.message;
  }
  assert(
    unlinkedParentHostelErr.includes('Access Denied') || unlinkedParentHostelErr.includes('No active relationship link'),
    'Unlinked parent PAR-002 is blocked from viewing STU-001 hostel details',
    unlinkedParentHostelErr
  );

  // ===========================================================================
  // 13. Dashboard Metrics Reconciliation
  // ===========================================================================
  console.log('\n--- 13. Dashboard Metrics Reconciliation ---');

  const finMetrics = await devDataAdapter.finance.getFinanceDashboardMetrics(financeActor);
  assert(
    typeof finMetrics.totalInvoiced === 'number' &&
    typeof finMetrics.totalCollected === 'number' &&
    typeof finMetrics.totalOutstanding === 'number' &&
    finMetrics.totalInvoiced >= finMetrics.totalCollected,
    'Finance dashboard metrics accurately reconcile totalInvoiced, totalCollected, and totalOutstanding',
    `Invoiced: $${finMetrics.totalInvoiced}, Collected: $${finMetrics.totalCollected}, Outstanding: $${finMetrics.totalOutstanding}`
  );

  const hstMetrics = await devDataAdapter.hostel.getHostelDashboardMetrics(hostelActor);
  assert(
    typeof hstMetrics.totalRoomsCount === 'number' &&
    typeof hstMetrics.totalBedsCount === 'number' &&
    typeof hstMetrics.occupancyRate === 'number' &&
    hstMetrics.totalBedsCount === hstMetrics.availableBedsCount + hstMetrics.occupiedBedsCount + (hstMetrics.roomsUnderMaintenanceCount > 0 ? 2 : 0),
    'Hostel dashboard metrics accurately compute total bed capacity, occupancy, and available inventory',
    `Rooms: ${hstMetrics.totalRoomsCount}, Beds: ${hstMetrics.totalBedsCount}, Occupancy: ${hstMetrics.occupancyRate}%`
  );

  // ===========================================================================
  // 14. Preservation of Phases 1–8
  // ===========================================================================
  console.log('\n--- 14. Preservation of Phases 1–8 Core Architecture ---');

  const permanentOffices = await devDataAdapter.offices.getAllPermanent();
  assert(
    permanentOffices.length === 6 && permanentOffices.some((o) => o.canonical_username === 'finance'),
    'Preserved all 6 immutable permanent office accounts intact',
    `Count: ${permanentOffices.length}`
  );

  const employees = await devDataAdapter.employees.getAll();
  assert(
    employees.length >= 4,
    'Preserved employee master directory (Phases 5-8)',
    `Employees: ${employees.length}`
  );

  const students = await devDataAdapter.students.getAll();
  assert(
    students.length >= 2,
    'Preserved student master directory (Phases 5-8)',
    `Students: ${students.length}`
  );

  const courses = await devDataAdapter.academic.getCourses();
  assert(
    courses.length >= 4,
    'Preserved academic curriculum and courses (Phase 7)',
    `Courses: ${courses.length}`
  );

  const examSessions = await devDataAdapter.coe.getSessions(superAdminActor);
  assert(
    examSessions.length >= 2,
    'Preserved COE examination sessions and schedules (Phase 8)',
    `Sessions: ${examSessions.length}`
  );

  const applicants = await devDataAdapter.applicants.getAll();
  assert(
    applicants.length >= 4,
    'Preserved admissions applicants directory (Phase 6)',
    `Applicants: ${applicants.length}`
  );

  console.log('\n================================================================');
  const passedCount = results.filter((r) => r.passed).length;
  console.log(`Phase 9 Verification Summary: ${passedCount} / ${results.length} tests passed.`);
  console.log('================================================================');

  if (passedCount !== results.length) {
    process.exit(1);
  }
}

runPhase9Tests().catch((err) => {
  console.error('Unhandled test failure:', err);
  process.exit(1);
});
