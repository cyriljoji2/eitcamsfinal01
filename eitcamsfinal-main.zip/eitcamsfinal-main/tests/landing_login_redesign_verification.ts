import fs from 'fs';
import path from 'path';
import { devDataAdapter } from '../src/services/devDataAdapter';
import { PortalType } from '../src/types/portal';
import { PORTAL_GATEWAYS, INSTITUTE_INFO } from '../src/config/portals';

function assert(condition: boolean, testName: string, detail?: string) {
  if (condition) {
    console.log(`✅ [PASS] ${testName}${detail ? ` (${detail})` : ''}`);
  } else {
    console.error(`❌ [FAIL] ${testName}${detail ? ` (${detail})` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
}

async function runLandingLoginRedesignTests() {
  console.log('========================================================================');
  console.log('   EIT CAMS — Main Landing Page & Portal Login Redesign Verification   ');
  console.log('========================================================================');

  // --- STAGE A & B: Reference Component Files & Structure ---
  console.log('\n--- 1. Reference Component Files Existence ---');
  const requiredFiles = [
    'src/components/landing/LandingPage.tsx',
    'src/components/landing/PortalCard.tsx',
    'src/components/auth/LoginPage.tsx',
    'src/components/layout/Header.tsx',
    'src/components/layout/Footer.tsx',
    'src/components/layout/DigitalClock.tsx',
    'src/components/ui/Card.tsx',
    'src/components/ui/Button.tsx',
    'src/components/ui/Input.tsx',
    'src/components/ui/Alert.tsx',
  ];

  for (const relPath of requiredFiles) {
    const fullPath = path.resolve(process.cwd(), relPath);
    assert(fs.existsSync(fullPath), `Required reference component exists: ${relPath}`);
  }

  // --- STAGE B: Three Portal Cards & Identifiers ---
  console.log('\n--- 2. Three Public Gateways & Card Identifiers ---');
  assert(PORTAL_GATEWAYS.length === 3, 'Exactly three public login gateways defined in config');
  const landingCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/landing/LandingPage.tsx'), 'utf-8');
  assert(landingCode.includes('student-portal-card'), 'LandingPage includes student-portal-card id');
  assert(landingCode.includes('employee-portal-card'), 'LandingPage includes employee-portal-card id');
  assert(landingCode.includes('parent-portal-card'), 'LandingPage includes parent-portal-card id');

  const portalCardCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/landing/PortalCard.tsx'), 'utf-8');
  assert(portalCardCode.includes('onSelect(portal)'), 'PortalCard triggers onSelect callback with portal type');
  assert(portalCardCode.includes('-login-btn'), 'PortalCard renders dedicated button with login-btn id');

  // --- STAGE C: Dedicated Login Screen Design & Elements ---
  console.log('\n--- 3. Dedicated Login Screen Design & Form Elements ---');
  const loginCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/auth/LoginPage.tsx'), 'utf-8');
  assert(loginCode.includes('login-title'), 'LoginPage defines login-title id');
  assert(loginCode.includes('login-desc'), 'LoginPage defines login-desc id');
  assert(loginCode.includes('identifier-input'), 'LoginPage defines identifier input id');
  assert(loginCode.includes('password-input'), 'LoginPage defines password input id');
  assert(loginCode.includes('submit-btn'), 'LoginPage defines submit-btn id');
  assert(loginCode.includes('login-back-button'), 'LoginPage defines login-back-button id');
  assert(loginCode.includes('isPassword'), 'LoginPage uses password visibility toggle control');

  // --- STAGE D: Authentication Integration & Routing ---
  console.log('\n--- 4. Real Institutional Authentication Verification ---');

  // Student authentication
  const studentLogin = await devDataAdapter.auth.login(
    'EIT-STU-2026-CSE-0001',
    'dev_test_password',
    PortalType.Student
  );
  assert(studentLogin.success, 'Student login succeeds with registration number', studentLogin.session?.displayName);
  assert(studentLogin.session?.portalType === PortalType.Student, 'Student session has student portal type');

  // Employee authentication (faculty)
  const facultyLogin = await devDataAdapter.auth.login(
    'dr.sharma',
    'dev_test_password',
    PortalType.Employee
  );
  assert(facultyLogin.success, 'Teaching faculty employee login succeeds', facultyLogin.session?.displayName);
  assert(facultyLogin.session?.portalType === PortalType.Employee, 'Faculty session has employee portal type');

  // Employee authentication (permanent office)
  const officeLogin = await devDataAdapter.auth.login(
    'academicoffice',
    'dev_test_password',
    PortalType.Employee
  );
  assert(officeLogin.success, 'Academic Office login succeeds via Employee gateway', officeLogin.session?.displayName);

  // Parent authentication
  const parentLogin = await devDataAdapter.auth.login(
    'rajesh.kumar',
    'dev_test_password',
    PortalType.Parent
  );
  assert(parentLogin.success, 'Parent login succeeds with guardian username', parentLogin.session?.displayName);
  assert(parentLogin.session?.portalType === PortalType.Parent, 'Parent session has parent portal type');

  // Mismatched portal authentication rejection
  const mismatchedPortalLogin = await devDataAdapter.auth.login(
    'EIT-STU-2026-CSE-0001',
    'dev_test_password',
    PortalType.Employee
  );
  assert(!mismatchedPortalLogin.success, 'Student credential strictly rejected from Employee portal');

  // --- STAGE E: Header, Clock & Institutional Branding ---
  console.log('\n--- 5. Header, Footer & Clock Branding ---');
  const headerCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/layout/Header.tsx'), 'utf-8');
  assert(headerCode.includes('school-portal-brand-btn'), 'Header contains school-portal-brand-btn');
  assert(headerCode.includes('header-back-home-btn'), 'Header contains header-back-home-btn on login view');
  assert(headerCode.includes('DigitalClock'), 'Header integrates live DigitalClock');

  const clockCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/layout/DigitalClock.tsx'), 'utf-8');
  assert(clockCode.includes('header-live-clock'), 'DigitalClock contains header-live-clock id');
  assert(clockCode.includes('setInterval'), 'DigitalClock runs live 1-second interval update');

  const footerCode = fs.readFileSync(path.resolve(process.cwd(), 'src/components/layout/Footer.tsx'), 'utf-8');
  assert(footerCode.includes('Electrix Institute of Technology (EIT)'), 'Footer displays official EIT institution name');
  assert(footerCode.includes('portal-support@electrix.edu'), 'Footer contains official support mail');

  console.log('\n========================================================================');
  console.log('🎉 ALL LANDING PAGE & PORTAL LOGIN REDESIGN VERIFICATION TESTS PASSED!');
  console.log('========================================================================');
}

runLandingLoginRedesignTests().catch((err) => {
  console.error('Redesign verification error:', err);
  process.exit(1);
});
