/**
 * EIT CAMS — Parent / Guardian Portal Redesign Verification Test Suite
 *
 * Comprehensive end-to-end and unit verification covering:
 * 1. Reference Component Architecture & Existence
 * 2. Exactly 9 Primary Navigation Destinations
 * 3. Single-Expansion Accordion Behavior in PortalSidebar
 * 4. Authoritative Parent-Ward Linking & Multiple Student Switching
 * 5. Data Clearing on Student Switch (Preventing Data Leakage)
 * 6. Cross-Student & Cross-Parent Security Enforcement
 * 7. University Data Adaptation (Profile, Academics, Attendance, Fees, Receipts, Exams, Hall Tickets, Results)
 * 8. Proctor & Hostel Welfare Integration (Omits Confidential Notes)
 * 9. Active Academic Year Integration via useActiveAcademicYear
 * 10. Granular Link Permissions (can_view_grades, can_view_attendance, can_view_finance)
 * 11. Interactive Element & Action Button Identifiers
 * 12. Regression Safety (No FFCS in Student Portal, No Unauthorized Office Access)
 */

import fs from 'fs';
import path from 'path';
import { devDataAdapter } from '../src/services/devDataAdapter';
import { PortalType, ParentRelationship } from '../src/types/database';
import {
  parentService,
  getLinkedWards,
  getProctorForStudent,
  getHostelDetailsForWard,
  getLeaveRequestsForWard,
  getDomainDatasets,
} from '../src/services/parentService';
import { PARENT_NAV_ITEMS } from '../src/components/parent/ParentWorkspace';

let passed = 0;
let total = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  total++;
  if (!condition) {
    console.error(`❌ FAIL: ${testName}${detail ? ` — ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
  passed++;
  console.log(`✅ [Test ${total}] PASS: ${testName}${detail ? ` (${detail})` : ''}`);
}

async function runParentPortalVerification() {
  console.log('========================================================================');
  console.log('    EIT CAMS — Parent / Guardian Portal Redesign Verification Suite     ');
  console.log('========================================================================\n');

  // --- 1. Reference Component Files Existence ---
  console.log('--- 1. Reference Component Files Existence ---');
  const requiredFiles = [
    'src/components/parent/ParentWorkspace.tsx',
    'src/components/parent/ParentOverview.tsx',
    'src/components/parent/ParentChildSelector.tsx',
    'src/components/parent/ParentProfileView.tsx',
    'src/components/parent/ParentAcademicsView.tsx',
    'src/components/parent/ParentAttendanceView.tsx',
    'src/components/parent/ParentFeesView.tsx',
    'src/components/parent/ParentReceiptsView.tsx',
    'src/components/parent/ParentExaminationsView.tsx',
    'src/components/parent/ParentHallTicketsView.tsx',
    'src/components/parent/ParentResultsView.tsx',
    'src/services/parentService.ts',
    'src/views/ParentDashboardView.tsx',
  ];

  for (const relPath of requiredFiles) {
    const fullPath = path.resolve(process.cwd(), relPath);
    assert(fs.existsSync(fullPath), `Required component exists: ${relPath}`);
  }

  // --- 2. Exactly Nine Primary Navigation Destinations ---
  console.log('\n--- 2. Exactly Nine Primary Navigation Destinations ---');
  const expectedNavIds = [
    'overview',
    'profile',
    'academics',
    'attendance',
    'fees',
    'receipts',
    'examinations',
    'hall-tickets',
    'results',
  ];

  assert(
    PARENT_NAV_ITEMS.length === 9,
    'Parent navigation contains exactly 9 primary destinations',
    `Count: ${PARENT_NAV_ITEMS.length}`
  );

  const actualNavIds = PARENT_NAV_ITEMS.map((item) => item.id);
  for (const expectedId of expectedNavIds) {
    assert(
      actualNavIds.includes(expectedId as any),
      `Navigation contains primary destination '${expectedId}'`
    );
  }

  const navLabelMap: Record<string, string> = {
    overview: 'Dashboard',
    profile: 'Student Profile',
    academics: 'Academics & Courses',
    attendance: 'Attendance',
    fees: 'Fee Statement',
    receipts: 'Payment Receipts',
    examinations: 'Exam Timetable',
    'hall-tickets': 'Hall Tickets',
    results: 'Report Cards',
  };

  for (const item of PARENT_NAV_ITEMS) {
    assert(
      item.label === navLabelMap[item.id],
      `Navigation label for '${item.id}' matches university specification '${navLabelMap[item.id]}'`
    );
  }

  // --- 3. Single-Expansion Accordion Behavior in Sidebar ---
  console.log('\n--- 3. Single-Expansion Accordion Behavior in Sidebar ---');
  const sidebarSource = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/common/PortalSidebar.tsx'),
    'utf-8'
  );

  assert(
    sidebarSource.includes('const [expandedMenuId, setExpandedMenuId] = useState<string | null>'),
    'PortalSidebar uses single shared expandedMenuId state'
  );
  assert(
    sidebarSource.includes('setExpandedMenuId((current) => (current === item.id ? null : item.id))'),
    'Opening an expandable group automatically closes previously expanded group'
  );

  // --- 4. Multiple Linked Students Under One Parent Account ---
  console.log('\n--- 4. Authoritative Parent-Ward Linking & Multiple Students ---');
  const parentLoginRes = await devDataAdapter.auth.login(
    'rajesh.kumar',
    'dev_mock_hash_parent',
    PortalType.Parent
  );
  assert(
    parentLoginRes.success && !!parentLoginRes.session?.parentProfile,
    'Parent authentication succeeds for rajesh.kumar'
  );
  assert(
    parentLoginRes.session?.role === 'parent' || parentLoginRes.session?.portalType === PortalType.Parent,
    'Authenticated session is strictly for parent portal'
  );

  const parentSession = parentLoginRes.session!;
  const parentUser = parentSession;

  // Ensure second linked student exists for multi-child testing
  const initialLinks = await devDataAdapter.parents.getLinkedStudents('PAR-001', {
    userId: 'PAR-001',
    role: 'PARENT',
  });
  if (initialLinks.length < 2) {
    await devDataAdapter.parents.linkStudent({
      parent_id: 'PAR-001',
      student_id: 'STU-002',
      student_registration_number: 'EIT-STU-2026-ECE-0002',
      relationship: ParentRelationship.FATHER,
      is_primary_contact: false,
      can_view_grades: true,
      can_view_attendance: false,
      can_view_finance: false,
      emergency_priority: 2,
      status: 'ACTIVE',
    });
  }

  const linkedWards = await getLinkedWards(parentSession);
  assert(
    linkedWards.length >= 2,
    `Parent has multiple linked students (Count: ${linkedWards.length})`,
    linkedWards.map((w) => `${w.student.fullName} (${w.student.registrationNumber})`).join(', ')
  );

  const ward1 = linkedWards[0];
  const ward2 = linkedWards[1];
  assert(ward1.student.id !== ward2.student.id, 'Linked students have distinct institutional IDs');
  assert(
    !!ward1.student.registrationNumber && !!ward2.student.registrationNumber,
    'Both wards have assigned canonical registration numbers'
  );

  // --- 5. Data Clearing & Switching Mechanism ---
  console.log('\n--- 5. Data Isolation & Switching Mechanism ---');
  const parentWorkspaceSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentWorkspace.tsx'),
    'utf-8'
  );

  assert(
    parentWorkspaceSrc.includes('const handleSelectStudent = (newStudent: Student) => {') &&
      parentWorkspaceSrc.includes('setWardProctor(null);') &&
      parentWorkspaceSrc.includes('setWardHostelDetails(null);') &&
      parentWorkspaceSrc.includes('setSelectedReceipt(null);') &&
      parentWorkspaceSrc.includes('setSelectedHallTicket(null);') &&
      parentWorkspaceSrc.includes('setSelectedResult(null);') &&
      parentWorkspaceSrc.includes('setSelectedStudent(newStudent);'),
    'ParentWorkspace clears previous student state (proctor, hostel, modals) during switch to prevent data leakage'
  );

  // --- 6. Cross-Student & Cross-Parent Security Enforcement ---
  console.log('\n--- 6. Cross-Student & Cross-Parent Security Enforcement ---');
  // Unauthenticated retrieval rejected
  try {
    await devDataAdapter.parents.getLinkedStudents(undefined, undefined);
    assert(false, 'Unauthenticated getLinkedStudents must throw');
  } catch (err: any) {
    assert(
      err.message.includes('Unauthorized') || err.message.includes('Authentication required'),
      'Unauthenticated parent queries are strictly rejected at repository boundary',
      err.message
    );
  }

  // Cross-parent query prohibited
  try {
    await devDataAdapter.parents.getLinkedStudents('OTHER_PARENT_ID', {
      userId: 'PAR-001',
      role: 'PARENT',
    });
    assert(false, 'Cross-parent queries must throw');
  } catch (err: any) {
    assert(
      err.message.includes('Cross-parent queries prohibited'),
      'Cross-parent query is rejected with explicit security policy',
      err.message
    );
  }

  // Non-parent role rejection
  try {
    await devDataAdapter.parents.getLinkedStudents({
      userId: 'STU-001',
      role: 'STUDENT',
    });
    assert(false, 'Student role calling parent linkages must throw');
  } catch (err: any) {
    assert(
      err.message.includes('not authorized'),
      'Non-parent roles are rejected from parent-child linkages',
      err.message
    );
  }

  // --- 7. University Data Adaptation for Wards ---
  console.log('\n--- 7. University Data Adaptation for Wards ---');
  const domainDatasets = await getDomainDatasets();
  assert(!!domainDatasets, 'Retrieved authoritative institutional datasets');
  assert(domainDatasets.sessions.length > 0, 'Academic sessions loaded');
  assert(domainDatasets.classes.length > 0, 'Curriculum classes loaded');
  assert(domainDatasets.subjects.length > 0, 'Course subjects loaded');
  assert(domainDatasets.attendance.length > 0, 'Attendance records loaded');
  assert(domainDatasets.feeAssignments.length > 0, 'Fee assignments loaded');
  assert(domainDatasets.receipts.length > 0, 'Fee receipts loaded');
  assert(domainDatasets.examinations.length > 0, 'Examinations loaded');
  assert(domainDatasets.hallTickets.length > 0, 'Hall tickets loaded');
  assert(domainDatasets.results.length > 0, 'Examination results loaded');

  // Verify Student Profile university fields
  const profileSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentProfileView.tsx'),
    'utf-8'
  );
  assert(profileSrc.includes('registrationNumber'), 'Profile view displays EIT registration number');
  assert(
    profileSrc.includes('Programme') || profileSrc.includes('program'),
    'Profile view displays university programme'
  );
  assert(
    profileSrc.includes('Department') || profileSrc.includes('department'),
    'Profile view displays academic department'
  );
  assert(
    profileSrc.includes('Academic Status') || profileSrc.includes('Officially Enrolled'),
    'Profile view displays academic standing'
  );

  // Verify Academics & Courses
  const academicsSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentAcademicsView.tsx'),
    'utf-8'
  );
  assert(academicsSrc.includes('subject.credits') || academicsSrc.includes('totalCredits'), 'Academics view displays course credits');
  assert(academicsSrc.includes('facultyAssignments') || academicsSrc.includes('facultyName'), 'Academics view displays course instructor');

  // Verify Attendance breakdown and 75% threshold
  const attendanceSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentAttendanceView.tsx'),
    'utf-8'
  );
  assert(attendanceSrc.includes('75'), 'Attendance view enforces and highlights 75% minimum threshold');
  assert(attendanceSrc.includes('percentage'), 'Attendance view computes percentage per course');

  // Verify Fee Statement & Receipts CSV Export
  const feesSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentFeesView.tsx'),
    'utf-8'
  );
  assert(feesSrc.includes('Total Tuition') || feesSrc.includes('totalBilled'), 'Fees view displays total assessed fee');
  assert(feesSrc.includes('Outstanding') || feesSrc.includes('totalOutstanding'), 'Fees view displays outstanding balance');

  const receiptsSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentReceiptsView.tsx'),
    'utf-8'
  );
  assert(receiptsSrc.includes('id="btn-export-receipts-csv"'), 'Receipts view includes btn-export-receipts-csv button');
  assert(
    receiptsSrc.includes('handleExportCsv') || receiptsSrc.includes('handleExportCSV'),
    'Receipts view implements CSV export handler'
  );

  // Verify Hall Tickets & Results
  const hallTicketsSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentHallTicketsView.tsx'),
    'utf-8'
  );
  assert(hallTicketsSrc.includes('btn-print-hall-ticket-'), 'Hall tickets view includes print button ids');

  const resultsSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentResultsView.tsx'),
    'utf-8'
  );
  assert(resultsSrc.includes('id="btn-print-official-transcript"'), 'Results view includes btn-print-official-transcript');
  assert(resultsSrc.includes('SGPA'), 'Results view renders SGPA');
  assert(resultsSrc.includes('overallGrade') || resultsSrc.includes('Grade'), 'Results view renders academic grades');

  // --- 8. Proctor & Hostel Welfare Information ---
  console.log('\n--- 8. Proctor & Hostel Welfare Information ---');
  const proctor = await getProctorForStudent(ward1.student.registrationNumber);
  assert(!!proctor, 'Ward has assigned academic Proctor', proctor?.name);
  assert(
    !('confidentialNotes' in (proctor || {})) && !('remarks' in (proctor || {})),
    'Proctor details strictly omit confidential notes and internal remarks'
  );

  const hostel = await getHostelDetailsForWard(ward1.student.id, parentUser);
  assert(
    hostel !== undefined,
    'Hostel details retrieval succeeds without error'
  );

  const leaveRequests = getLeaveRequestsForWard(ward1.student.registrationNumber);
  assert(
    Array.isArray(leaveRequests),
    'Permitted hostel leave requests retrieved as array'
  );

  // --- 9. Central Academic Year Synchronization ---
  console.log('\n--- 9. Central Academic Year Synchronization ---');
  const overviewSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentOverview.tsx'),
    'utf-8'
  );
  assert(
    overviewSrc.includes('useActiveAcademicYear()'),
    'ParentOverview integrates authoritative useActiveAcademicYear() hook'
  );
  assert(
    overviewSrc.includes('activeAcademicYear') && overviewSrc.includes('Academic Year'),
    'ParentOverview displays institution-wide active academic year label'
  );

  // --- 10. Granular Link Permissions Enforcement ---
  console.log('\n--- 10. Granular Link Permissions Enforcement ---');
  // Ward 1 has all permissions
  assert(ward1.permissions.can_view_grades === true, 'Ward 1 can_view_grades is true');
  assert(ward1.permissions.can_view_attendance === true, 'Ward 1 can_view_attendance is true');
  assert(ward1.permissions.can_view_finance === true, 'Ward 1 can_view_finance is true');

  // Ward 2 permissions in seed data: can_view_attendance=false, can_view_finance=false, can_view_grades=true
  assert(ward2.permissions.can_view_attendance === false, 'Ward 2 can_view_attendance is false');
  assert(ward2.permissions.can_view_finance === false, 'Ward 2 can_view_finance is false');
  assert(ward2.permissions.can_view_grades === true, 'Ward 2 can_view_grades is true');

  // Check that ParentWorkspace filters respect permissions
  assert(
    parentWorkspaceSrc.includes('if (!selectedStudent || !permissions.can_view_attendance) return [];'),
    'ParentWorkspace blocks attendance data when can_view_attendance is false'
  );
  assert(
    parentWorkspaceSrc.includes('if (!selectedStudent || !permissions.can_view_finance) return [];'),
    'ParentWorkspace blocks fee invoices and payments when can_view_finance is false'
  );
  assert(
    parentWorkspaceSrc.includes('if (!selectedStudent || !permissions.can_view_grades) return [];'),
    'ParentWorkspace blocks grades, hall tickets, and examination results when can_view_grades is false'
  );

  // Check view components display access restricted notices
  assert(
    attendanceSrc.includes('Attendance Records Restricted') || attendanceSrc.includes('canViewAttendance'),
    'Attendance view renders restricted access alert when permission disabled'
  );
  assert(
    feesSrc.includes('Financial Records Restricted') || feesSrc.includes('canViewFinance'),
    'Fees view renders restricted access alert when permission disabled'
  );
  assert(
    receiptsSrc.includes('Financial Receipts Restricted') || receiptsSrc.includes('canViewFinance'),
    'Receipts view renders restricted access alert when permission disabled'
  );

  // --- 11. Interactive Element & Action Button Identifiers ---
  console.log('\n--- 11. Interactive Element & Action Button Identifiers ---');
  const childSelectorSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentChildSelector.tsx'),
    'utf-8'
  );
  assert(
    childSelectorSrc.includes('id={`btn-select-child-${student.id}`}'),
    'ParentChildSelector includes btn-select-child-${student.id} action id'
  );
  assert(
    parentWorkspaceSrc.includes('id="btn-parent-logout"'),
    'ParentWorkspace top header includes btn-parent-logout button'
  );

  const examViewSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/parent/ParentExaminationsView.tsx'),
    'utf-8'
  );
  assert(
    examViewSrc.includes('id={`btn-exam-tab-${exam.id}`}'),
    'ParentExaminationsView includes btn-exam-tab-${exam.id} tab buttons'
  );

  assert(
    resultsSrc.includes('id={`btn-result-tab-${res.id}`}'),
    'ParentResultsView includes btn-result-tab-${res.id} tab buttons'
  );

  // --- 12. Regression Safety ---
  console.log('\n--- 12. Regression Safety ---');
  const studentWorkspaceSrc = fs.readFileSync(
    path.resolve(process.cwd(), 'src/components/student/StudentWorkspace.tsx'),
    'utf-8'
  );
  assert(
    !studentWorkspaceSrc.includes('ffcs-registration'),
    'Student Portal navigation strictly does not contain ffcs-registration'
  );

  const appSrc = fs.readFileSync(path.resolve(process.cwd(), 'src/App.tsx'), 'utf-8');
  assert(
    appSrc.includes('isParentPortal'),
    'App.tsx suppresses outer chrome for Parent Portal route'
  );

  console.log('\n========================================================================');
  console.log(`  PARENT PORTAL VERIFICATION SUMMARY: ${passed}/${total} PASSED (0 FAILED)`);
  console.log('========================================================================');
  console.log('🎉 ALL PARENT / GUARDIAN PORTAL VERIFICATION CRITERIA PASSED!');
}

runParentPortalVerification().catch((err) => {
  console.error(err);
  process.exit(1);
});
