/**
 * EIT CAMS — IT Department (PO-007) Comprehensive Verification Suite
 * Verifies all 30 Acceptance Criteria defined in Section 21.
 */

import { devDataAdapter } from '../src/services/devDataAdapter';
import { itRepository } from '../src/services/itService';
import {
  AuthRole,
  PermanentOfficeKey,
  EmployeeCategory,
  EmploymentStatus,
  OfficeAssignmentStatus,
  StudentRecord,
  EmployeeRecord,
} from '../src/types/database';
import { ItPermission, ItTab, SlaPolicyRecord } from '../src/types/itDepartment';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';
import { PORTAL_GATEWAYS } from '../src/config/portals';
import { PortalType } from '../src/types/portal';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runItDepartmentVerification() {
  console.log('================================================================');
  console.log('   EIT CAMS — Phase 10: IT Department (PO-007) Verification Suite');
  console.log('================================================================\n');

  // Test 1: PO-007 is registered and accessible via Employee Login
  const itOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id === 'PO-007');
  assert(
    !!itOffice && itOffice.canonical_username === 'itoffice' && itOffice.office_code === 'IT',
    'PO-007 is registered and configured with canonical username "itoffice"',
    itOffice ? `Office: ${itOffice.office_name} (${itOffice.office_id})` : 'Not found'
  );

  // Test 2: Public landing page retains exactly 3 gateways (Student, Employee, Parent)
  assert(
    PORTAL_GATEWAYS.length === 3,
    'Public landing page retains exactly three login gateways (Student, Employee, Parent)',
    `Gateways: ${PORTAL_GATEWAYS.map((g) => g.title).join(', ')}`
  );

  // Test 3: IT office account authenticates via Employee Portal with OFFICE_ADMIN role
  const itLoginRes = await devDataAdapter.auth.login(
    'itoffice',
    'dev_mock_hash_it',
    PortalType.Employee
  );
  assert(
    itLoginRes.success === true &&
      itLoginRes.session?.user?.username === 'itoffice' &&
      itLoginRes.session?.user?.role === AuthRole.OFFICE_ADMIN,
    'IT office account authenticates via Employee Portal with OFFICE_ADMIN role and secure hash',
    itLoginRes.session ? `User: ${itLoginRes.session.username}, Role: ${itLoginRes.session.role}` : 'Login failed'
  );

  // Test 4: Role-based authority isolation (non-IT staff has no IT permissions)
  const nonItPerms = await itRepository.getItPermissions('EMP-001');
  assert(
    Array.isArray(nonItPerms) && nonItPerms.length === 0,
    'Non-IT staff cannot access IT routes; permission list is empty',
    `Permissions count: ${nonItPerms.length}`
  );

  // Test 5: Administration assigns employee to IT -> IT can now manage their technical permissions
  // Find or create non-teaching employee and assign to IT
  const allEmployees = await devDataAdapter.employees.getAll();
  const nonTeachingEmp = allEmployees.find((e) => e.category === EmployeeCategory.NON_TEACHING) || allEmployees[0];
  
  // Ensure assignment exists
  const existingAssignments = await devDataAdapter.officeAssignments.getByOffice('PO-007');
  let itAssignedEmpId = nonTeachingEmp.employee_id;
  if (!existingAssignments.some((a) => a.employee_id === itAssignedEmpId && a.assignment_status === OfficeAssignmentStatus.ACTIVE)) {
    try {
      await devDataAdapter.officeAssignments.assign({
        office_id: 'PO-007',
        employee_id: itAssignedEmpId,
        assignment_status: OfficeAssignmentStatus.ACTIVE,
        assigned_at: new Date().toISOString(),
        assigned_by_user_id: 'admin',
      });
    } catch {
      // If assignment already existed under another employee
      if (existingAssignments.length > 0) {
        itAssignedEmpId = existingAssignments[0].employee_id;
      }
    }
  } else {
    itAssignedEmpId = existingAssignments[0].employee_id;
  }

  // IT now grants technical permission
  await itRepository.grantItPermission(
    itAssignedEmpId,
    ItPermission.IT_SYSTEM_MONITOR_VIEW,
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  const grantedPerms = await itRepository.getItPermissions(itAssignedEmpId);
  assert(
    grantedPerms.includes(ItPermission.IT_SYSTEM_MONITOR_VIEW),
    'Administration assigns employee to IT -> IT can now grant and manage technical permissions',
    `Permissions: ${grantedPerms.join(', ')}`
  );

  // Test 6: IT cannot create user accounts (authority boundary enforced)
  assert(
    typeof (itRepository as any).createUserAccount !== 'function' &&
      typeof (itRepository as any).createEmployee !== 'function',
    'IT Department service cannot create user accounts or employees (Admin authority preserved)'
  );

  // Test 7: IT cannot assign employees to IT Department
  assert(
    typeof (itRepository as any).assignEmployeeToOffice !== 'function',
    'IT Department service cannot assign employees to offices (Admin authority preserved)'
  );

  // Test 8: IT self-escalation rejected
  let selfEscalateError: string | null = null;
  try {
    await itRepository.grantItPermission(
      itAssignedEmpId,
      ItPermission.IT_PERMISSION_MANAGE,
      { userId: itAssignedEmpId, role: 'EMPLOYEE', employeeId: itAssignedEmpId } // Operator is same as target
    );
  } catch (err: any) {
    selfEscalateError = err.message;
  }
  assert(
    selfEscalateError !== null && selfEscalateError.includes('Self-escalation forbidden'),
    'IT operator self-granting permissions is strictly rejected',
    `Safeguard message: "${selfEscalateError}"`
  );

  // Test 9: Non-IT staff rejected from IT permissions
  let nonItError: string | null = null;
  try {
    await itRepository.grantItPermission(
      'EMP-UNASSIGNED-999',
      ItPermission.IT_DASHBOARD_VIEW,
      { userId: 'itoffice', role: 'OFFICE_ADMIN' }
    );
  } catch (err: any) {
    nonItError = err.message;
  }
  assert(
    nonItError !== null && nonItError.includes('officially assigned to the IT Department'),
    'Granting IT permissions to staff not assigned to IT by Administration is rejected',
    `Safeguard message: "${nonItError}"`
  );

  // Test 10: Password reset for valid username creates temporary credentials and audits action
  const resetRes = await itRepository.resetPassword(
    {
      usernameOrId: 'itoffice',
      reason: 'Routine institutional security verification',
    },
    { userId: 'itoffice', role: 'OFFICE_ADMIN', operatorName: 'IT Administrator' }
  );
  assert(
    resetRes.success === true && resetRes.tempPasswordToken.startsWith('EIT-RESET-'),
    'Password reset creates secure temporary credential and logs audit entry',
    `Message: ${resetRes.message}`
  );

  // Test 11: Password reset for non-existent username is authoritatively rejected
  let nonExistentResetError: string | null = null;
  try {
    await itRepository.resetPassword(
      {
        usernameOrId: 'ghost_user_99999',
        reason: 'Should fail',
      },
      { userId: 'itoffice', role: 'OFFICE_ADMIN' }
    );
  } catch (err: any) {
    nonExistentResetError = err.message;
  }
  assert(
    nonExistentResetError !== null && nonExistentResetError.includes('does not exist in authoritative records'),
    'Password reset for non-existent username is authoritatively rejected',
    `Safeguard message: "${nonExistentResetError}"`
  );

  // Test 12: Password reset for Super Admin rejected if operator is not Super Admin
  let adminResetError: string | null = null;
  try {
    await itRepository.resetPassword(
      {
        usernameOrId: 'admin',
        reason: 'Usurp attempt',
      },
      { userId: 'itoffice', role: 'OFFICE_ADMIN' }
    );
  } catch (err: any) {
    adminResetError = err.message;
  }
  assert(
    adminResetError !== null && adminResetError.includes('Only Super Administration may reset the central Admin account'),
    'Password reset for central Admin by non-Super Admin is rejected',
    `Safeguard message: "${adminResetError}"`
  );

  // Test 13: Student ID card generation with correct course, batch, expiration date
  const mockStudent: StudentRecord = {
    student_id: 'STU-TEST-999',
    registration_number: '2026/CSE/999',
    application_id: 'APP-999',
    first_name: 'Alexander',
    last_name: 'Hamilton',
    date_of_birth: '2005-01-11',
    gender: 'MALE' as any,
    blood_group: 'O+',
    primary_contact_number: '+1 (555) 019-2830',
    institutional_email: 'alexander.h@student.eit.edu',
    admitted_programme_id: 'PRG-CSE-BTECH',
    admission_batch_year: '2026',
    current_semester: 1,
    student_status: 'ACTIVE' as any,
    course_name: 'B.Tech Computer Science & Engineering',
    department: 'Computer Science & Engineering',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  const studentCard = await itRepository.autoGenerateStudentIdCard(mockStudent);
  assert(
    studentCard.card_type === 'STUDENT' &&
      studentCard.card_id.startsWith('IDC-STU-') &&
      studentCard.status === 'ACTIVE' &&
      studentCard.registration_number === '2026/CSE/999',
    'Student ID card auto-generated with correct registration number, course, and ACTIVE status',
    `Card ID: ${studentCard.card_id}, Valid Thru: ${studentCard.valid_until}`
  );

  // Test 14: Employee ID card auto-generation
  const mockEmployee: EmployeeRecord = {
    employee_id: 'EMP-TEST-999',
    registration_number: 'EMP-CSE-999',
    first_name: 'Elizabeth',
    last_name: 'Schuyler',
    institutional_email: 'e.schuyler@eit.edu',
    phone_number: '+1 (555) 019-2831',
    primary_department: 'Computer Science & Engineering',
    designation: 'Professor',
    category: EmployeeCategory.TEACHING,
    employment_status: EmploymentStatus.ACTIVE,
    date_of_joining: '2026-08-01',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  const employeeCard = await itRepository.autoGenerateEmployeeIdCard(mockEmployee);
  assert(
    employeeCard.card_type === 'EMPLOYEE' &&
      employeeCard.card_id.startsWith('IDC-EMP-') &&
      employeeCard.status === 'ACTIVE',
    'Employee ID card auto-generated with correct registration number and ACTIVE status',
    `Card ID: ${employeeCard.card_id}, Expiry: ${employeeCard.valid_until}`
  );

  // Test 15: Duplicate active ID card generation prevention (idempotent)
  const dupCard = await itRepository.autoGenerateStudentIdCard(mockStudent);
  assert(
    dupCard.card_id === studentCard.card_id,
    'Duplicate ID card generation for active holder returns existing card without creating duplicates',
    `Existing Card ID: ${dupCard.card_id}`
  );

  // Test 16: ID card reissue: previous marked REPLACED, new card ACTIVE
  const reissuedCard = await itRepository.reissueIdCard(
    studentCard.card_id,
    'Card damaged during laboratory session',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  const oldCard = itRepository.getAllIdCards().find((c) => c.card_id === studentCard.card_id);
  assert(
    reissuedCard.card_id !== studentCard.card_id &&
      reissuedCard.status === 'ACTIVE' &&
      oldCard?.status === 'REPLACED',
    'Reissuing ID card marks original card REPLACED and issues a new ACTIVE card',
    `Old Status: ${oldCard?.status}, New Card: ${reissuedCard.card_id}`
  );

  // Test 17: Student Portal retrieves active card by owner registration
  const foundCard = itRepository.getIdCardByOwner('2026/CSE/999');
  assert(
    !!foundCard && foundCard.status === 'ACTIVE' && foundCard.qr_code_payload.includes('2026%2FCSE%2F999'),
    'Active ID card is retrievable by registration number with valid verification QR payload',
    `Card ID: ${foundCard?.card_id}`
  );

  // Test 18: Test accounts toggle and session revocation
  const initialTestConfig = itRepository.getTestAccountConfig();
  const toggledConfig = await itRepository.setTestAccountEnabled(
    !initialTestConfig.is_enabled,
    'Routine automated verification test of test account isolation',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  assert(
    toggledConfig.is_enabled === !initialTestConfig.is_enabled,
    'Test account state toggles cleanly and logs operator audit entry',
    `Is Enabled: ${toggledConfig.is_enabled}, Last Operator: ${toggledConfig.last_operator_id}`
  );
  // Restore initial state
  await itRepository.setTestAccountEnabled(
    initialTestConfig.is_enabled,
    'Restore original state',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );

  // Test 19: Real accounts remain unaffected by test account toggle
  const adminLoginRes = await devDataAdapter.auth.login(
    'admin',
    'dev_mock_hash_admin',
    PortalType.Employee
  );
  assert(
    adminLoginRes.success === true,
    'Real institutional accounts remain accessible and unchanged regardless of test environment toggle',
    `Admin login: ${adminLoginRes.success}`
  );

  // Test 20: Ticket submission and SLA deadline calculation
  const newTicket = await itRepository.createTicket({
    category: 'TECHNICAL_ISSUE',
    priority: 'HIGH',
    subject: 'Laboratory projector HDMI port malfunctioning',
    description: 'Room 402 projector displays flickering artifacts during lectures',
    requester_id: 'EMP-001',
    requester_name: 'Dr. Faculty Member',
    requester_account_type: 'EMPLOYEE',
    requester_email: 'faculty@eit.edu',
  });
  assert(
    newTicket.ticket_number.startsWith('EIT-IT-') &&
      newTicket.status === 'OPEN' &&
      newTicket.sla_response_deadline > newTicket.created_at &&
      newTicket.sla_resolution_deadline > newTicket.sla_response_deadline,
    'New ticket generated with ticket number, OPEN status, and SLA deadlines computed',
    `Number: ${newTicket.ticket_number}, Resolution Deadline: ${newTicket.sla_resolution_deadline}`
  );

  // Test 21: Ticket internal notes are hidden from non-IT staff
  await itRepository.addTicketResponse(
    newTicket.ticket_id,
    'Technician dispatched to replace HDMI daughterboard',
    { id: 'itoffice', name: 'IT Admin', role: 'OFFICE_ADMIN' },
    true // isInternalNote
  );
  const ticketsForRequester = itRepository.getTickets(
    undefined,
    { userId: 'EMP-001', role: 'EMPLOYEE', employeeId: 'EMP-001' }
  );
  const myTicket = ticketsForRequester.find((t) => t.ticket_id === newTicket.ticket_id);
  const internalNotesVisible = myTicket?.responses.some((r) => r.is_internal_note);
  assert(
    internalNotesVisible === false,
    'Ticket internal technician notes are strictly hidden from requesters',
    `Internal notes visible to requester: ${internalNotesVisible}`
  );

  // Test 22: Ticket resolution lifecycle
  const resolvedTicket = await itRepository.resolveTicket(
    newTicket.ticket_id,
    'Replaced cable and tested 1080p output successfully',
    { userId: 'itoffice', role: 'OFFICE_ADMIN', operatorName: 'IT Admin' }
  );
  assert(
    resolvedTicket.status === 'RESOLVED' && !!resolvedTicket.resolved_at,
    'Ticket resolution marks status as RESOLVED and records resolution timestamp',
    `Status: ${resolvedTicket.status}, Resolved at: ${resolvedTicket.resolved_at}`
  );

  // Test 23: SLA Policy Engine & Versioning
  const activePolicy = itRepository.getActiveSlaPolicy();
  const newPolicy = await itRepository.updateSlaPolicy(
    {
      ...activePolicy,
      name: 'EIT Institutional SLA Policy v2',
    },
    'Policy review update',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  assert(
    newPolicy.version === activePolicy.version + 1 && newPolicy.is_active === true,
    'SLA policy update increments policy version and sets active flag',
    `Old Version: ${activePolicy.version}, New Version: ${newPolicy.version}`
  );

  // Test 24: Reactive Contact Settings Subscription
  let receivedUpdate = false;
  const unsubscribe = itRepository.subscribeContactSettings((settings) => {
    if (settings.primary_phone === '+1 (555) 999-0000') {
      receivedUpdate = true;
    }
  });
  const originalSettings = itRepository.getContactSettings();
  await itRepository.updateContactSettings(
    {
      primary_support_email: 'it-help@eit.edu',
      primary_phone: '+1 (555) 999-0000',
      helpdesk_hours: '7:30 AM – 6:00 PM EST',
      emergency_phone: '+1 (555) 999-9111',
      broadcast_banner_enabled: true,
      broadcast_message: 'Routine network maintenance scheduled for Saturday 2:00 AM.',
    },
    'Updated helpdesk hours and emergency line',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  unsubscribe();
  assert(
    receivedUpdate === true,
    'Contact settings update triggers real-time subscriber callback for all portals',
    `Received reactive update: ${receivedUpdate}`
  );
  // Restore original settings
  await itRepository.updateContactSettings(
    {
      primary_support_email: originalSettings.primary_support_email,
      primary_phone: originalSettings.primary_phone,
      helpdesk_hours: originalSettings.helpdesk_hours,
      broadcast_banner_enabled: false,
    },
    'Restore original settings',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );

  // Test 25: Manual Database Snapshot and Checksum
  const backup = await itRepository.triggerBackup(
    'STATE_SNAPSHOT',
    'Weekly institutional security audit snapshot',
    { userId: 'itoffice', role: 'OFFICE_ADMIN' }
  );
  assert(
    backup.status === 'SUCCESS' && backup.backup_id.startsWith('BKP-2026-'),
    'Manual backup triggers snapshot with status SUCCESS and retention period',
    `Backup ID: ${backup.backup_id}, Type: ${backup.backup_type}`
  );

  // Test 26: Security Audit Ledger is Immutable
  const auditLogs = await devDataAdapter.audit.getAll();
  assert(
    auditLogs.length > 0 && typeof (devDataAdapter.audit as any).delete !== 'function',
    'Security audit logs are append-only (WORM) with no deletion interface',
    `Total Audit Entries: ${auditLogs.length}`
  );

  // Test 27: All 17 IT Navigation Destinations Defined
  const expectedTabs: ItTab[] = [
    'overview',
    'system_health',
    'user_access',
    'password_reset',
    'id_cards',
    'test_accounts',
    'security_audit',
    'database',
    'infrastructure',
    'configuration',
    'integrations',
    'app_monitoring',
    'tickets',
    'backup',
    'contact_settings',
    'sla_policies',
    'reports',
  ];
  assert(
    expectedTabs.length === 17,
    'All 17 IT Department functional navigation destinations are defined',
    `Destinations: ${expectedTabs.join(', ')}`
  );

  // Test 28: System Health Metrics Available
  const healthMetrics = itRepository.getSystemHealthMetrics();
  const appCore = healthMetrics.find((m) => m.service_name.includes('Application Core'));
  const sheetsService = healthMetrics.find((m) => m.service_name.includes('Google Sheets'));
  assert(
    healthMetrics.length >= 4 &&
      appCore?.status === 'HEALTHY' &&
      appCore.uptime_percentage > 99 &&
      sheetsService?.status === 'NOT_CONFIGURED',
    'System health metrics provide live diagnostics; active services healthy, Sheets honestly NOT_CONFIGURED',
    `Monitored: ${healthMetrics.length} services (Core: ${appCore?.status}, Sheets: ${sheetsService?.status})`
  );

  // Test 29: Honest Readiness for Google Sheets (Phase 11) & Vercel (Phase 12)
  const dbReport = await itRepository.getDatabaseManagementReport();
  assert(
    dbReport.google_sheets_connected === false &&
      dbReport.current_adapter === 'DevDataAdapter',
    'Database and deployment report honestly reflects DevDataAdapter and planned Phase 11/12 states',
    `Sheets Connected: ${dbReport.google_sheets_connected}, Adapter: ${dbReport.current_adapter}`
  );

  // Test 30: Academic Year & Portals Unbroken
  const allStudents = await devDataAdapter.students.getAll();
  const allEmps = await devDataAdapter.employees.getAll();
  const allDepts = await devDataAdapter.academic.getDepartments();
  assert(
    allStudents.length > 0 &&
      allEmps.length > 0 &&
      allDepts.length > 0 &&
      SIX_PERMANENT_OFFICES.length >= 7,
    'All institutional entities, permanent offices, and existing services remain intact',
    `Students: ${allStudents.length}, Employees: ${allEmps.length}, Departments: ${allDepts.length}, Offices: ${SIX_PERMANENT_OFFICES.length}`
  );

  console.log('\n================================================================');
  console.log(`Verification Complete: ${results.filter((r) => r.passed).length} of ${results.length} tests passed.`);
  console.log('================================================================\n');

  if (results.some((r) => !r.passed)) {
    console.error('Some tests failed!');
    process.exit(1);
  }
}

runItDepartmentVerification().catch((err) => {
  console.error('Verification failed with exception:', err);
  process.exit(1);
});
