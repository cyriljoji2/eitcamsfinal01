/**
 * Sidebar Single-Expansion Accordion Verification Test Suite
 *
 * Validates:
 * 1. Student Portal getParentGroupForStudentTab mappings
 * 2. Strict single-expansion accordion state transitions (open one, auto-close previous, re-click closes)
 * 3. Preservation of activeTab across group collapses and expansions
 * 4. Verification that StudentWorkspace source code uses single shared expandedMenuId
 * 5. Verification that Faculty Portal PortalSidebar source code uses single shared expandedMenuId
 * 6. Non-existence of FFCS Registration in Student Portal navigation
 */

import fs from 'fs';
import path from 'path';
import { getParentGroupForStudentTab } from '../src/components/student/StudentWorkspace';

let passed = 0;
let total = 0;

function assert(condition: boolean, testName: string, detail?: string) {
  total++;
  if (!condition) {
    console.error(`❌ FAIL: ${testName}${detail ? ` — ${detail}` : ''}`);
    throw new Error(`Assertion failed: ${testName}`);
  }
  passed++;
  console.log(`✅ [Test ${total}] PASS: ${testName}${detail ? ` (${detail})` : ''}`);
}

async function runVerification() {
  console.log('========================================================================');
  console.log('  EIT CAMS — Student & Faculty Portal Accordion Verification Suite      ');
  console.log('========================================================================\n');

  // --- 1. Student Portal getParentGroupForStudentTab Tab Mappings ---
  console.log('--- 1. Student Portal Tab to Accordion Group Mapping ---');

  // My Info
  const myInfoTabs = ['my-info-profile', 'my-info-credentials', 'my-info-acknowledgement', 'my-info-bank-info', 'my-info-aapar', 'profile'];
  for (const tab of myInfoTabs) {
    assert(getParentGroupForStudentTab(tab) === 'my-info', `Tab ${tab} maps to group 'my-info'`);
  }

  // Info Corner
  const infoCornerTabs = ['info-faq', 'info-spotlight', 'info-general'];
  for (const tab of infoCornerTabs) {
    assert(getParentGroupForStudentTab(tab) === 'info-corner', `Tab ${tab} maps to group 'info-corner'`);
  }

  // Proctor
  const proctorTabs = ['proctor-details', 'proctor-messages'];
  for (const tab of proctorTabs) {
    assert(getParentGroupForStudentTab(tab) === 'proctor', `Tab ${tab} maps to group 'proctor'`);
  }

  // Academics
  const academicsTabs = [
    'academics', 'academics-faculty', 'academics-messages', 'academics-curriculum',
    'academics-timetable', 'academics-attendance', 'academics-course-page',
    'academics-qcm', 'academics-calendar', 'academics-withdraw', 'attendance'
  ];
  for (const tab of academicsTabs) {
    assert(getParentGroupForStudentTab(tab) === 'academics', `Tab ${tab} maps to group 'academics'`);
  }

  // Examination
  const examTabs = [
    'examinations', 'hall-tickets', 'results', 'exam-schedule', 'exam-online-schedule',
    'exam-offline-schedule', 'exam-marks', 'exam-grades', 'exam-paper-see-rev',
    'exam-grade-history', 'exam-arrears', 'exam-refat', 'exam-re-exam', 'exam-supplementary'
  ];
  for (const tab of examTabs) {
    assert(getParentGroupForStudentTab(tab) === 'examination', `Tab ${tab} maps to group 'examination'`);
  }

  // Services
  const servicesTabs = ['services-pat', 'services-transcript', 'services-late-hour', 'services-water', 'services-transport'];
  for (const tab of servicesTabs) {
    assert(getParentGroupForStudentTab(tab) === 'services', `Tab ${tab} maps to group 'services'`);
  }

  // Bonafide
  assert(getParentGroupForStudentTab('bonafide-apply') === 'bonafide', `Tab bonafide-apply maps to group 'bonafide'`);

  // Online Payments
  const paymentsTabs = [
    'payments', 'payments-receipts', 'payments-fees-intimation', 'payments-hostel-fees-intimation',
    'fees', 'receipts', 'finance', 'finance-fees', 'finance-payments', 'finance-receipts',
    'finance-fee-intimation', 'finance-hostel-fee-intimation'
  ];
  for (const tab of paymentsTabs) {
    assert(getParentGroupForStudentTab(tab) === 'online-payments', `Tab ${tab} maps to group 'online-payments'`);
  }

  // Convocation
  assert(getParentGroupForStudentTab('convocation-register') === 'convocation', `Tab convocation-register maps to group 'convocation'`);

  // Hostels
  const hostelsTabs = ['hostels-leave-request', 'hostels-leave-history', 'hostels-biometric', 'hostels-room-allotment', 'hostels-room-master'];
  for (const tab of hostelsTabs) {
    assert(getParentGroupForStudentTab(tab) === 'hostels', `Tab ${tab} maps to group 'hostels'`);
  }

  // My Account
  assert(getParentGroupForStudentTab('account-change-password') === 'my-account', `Tab account-change-password maps to group 'my-account'`);

  // --- 2. Strict Single-Expansion Accordion State Machine Simulation ---
  console.log('\n--- 2. Single-Expansion Accordion State Machine Logic ---');

  let expandedMenuId: string | null = getParentGroupForStudentTab('my-info-profile');
  let currentActiveTab = 'my-info-profile';

  function simulateToggle(groupId: string) {
    expandedMenuId = expandedMenuId === groupId ? null : groupId;
  }

  function simulateSelectTab(tabId: string) {
    currentActiveTab = tabId;
    const parent = getParentGroupForStudentTab(tabId);
    if (parent) expandedMenuId = parent;
  }

  // Initial state on page load with default tab 'my-info-profile'
  assert(expandedMenuId === 'my-info', 'Initial expanded group is my-info based on active tab');

  // Click Academics: opens Academics, automatically collapses my-info
  simulateToggle('academics');
  assert(expandedMenuId === 'academics', 'Expanding Academics sets expandedMenuId to academics');
  assert(expandedMenuId !== 'my-info', 'Previous group my-info is automatically closed');
  assert(currentActiveTab === 'my-info-profile', 'Collapsing previous group does not navigate away from active tab');

  // Click Examination: opens Examination, automatically collapses Academics
  simulateToggle('examination');
  assert(expandedMenuId === 'examination', 'Expanding Examination sets expandedMenuId to examination');
  assert(expandedMenuId !== 'academics', 'Academics is automatically collapsed');

  // Click Examination again: collapses Examination
  simulateToggle('examination');
  assert(expandedMenuId === null, 'Clicking currently expanded group collapses it to null');
  assert(currentActiveTab === 'my-info-profile', 'Active tab remains untouched when group is collapsed');

  // Select a tab from Online Payments
  simulateSelectTab('payments-receipts');
  assert(expandedMenuId === 'online-payments', 'Navigating to payments-receipts expands online-payments group');
  assert(currentActiveTab === 'payments-receipts', 'Active tab updated to payments-receipts');

  // Click Online Payments again: collapses
  simulateToggle('online-payments');
  assert(expandedMenuId === null, 'Clicking online-payments header collapses it');
  assert(currentActiveTab === 'payments-receipts', 'Active tab remains payments-receipts when collapsed');

  // Click Hostels: opens Hostels, everything else collapsed
  simulateToggle('hostels');
  assert(expandedMenuId === 'hostels', 'Opening hostels expands only hostels');

  // --- 3. Source Code Integrity Checks ---
  console.log('\n--- 3. Source Code Architecture & Cleanliness Checks ---');

  const studentWorkspacePath = path.resolve(process.cwd(), 'src/components/student/StudentWorkspace.tsx');
  const studentWorkspaceSrc = fs.readFileSync(studentWorkspacePath, 'utf-8');

  // Check that independent boolean states were replaced with shared expandedMenuId
  assert(
    studentWorkspaceSrc.includes('const [expandedMenuId, setExpandedMenuId] = useState<string | null>'),
    'StudentWorkspace uses shared expandedMenuId state'
  );

  assert(
    !studentWorkspaceSrc.includes('const [isMyInfoOpen, setIsMyInfoOpen] = useState(false)'),
    'Independent useState for isMyInfoOpen has been removed'
  );

  assert(
    !studentWorkspaceSrc.includes('const [isAcademicsOpen, setIsAcademicsOpen] = useState(false)'),
    'Independent useState for isAcademicsOpen has been removed'
  );

  assert(
    !studentWorkspaceSrc.includes('const [isExaminationOpen, setIsExaminationOpen] = useState(false)'),
    'Independent useState for isExaminationOpen has been removed'
  );

  // Check derived state matches expandedMenuId
  assert(
    studentWorkspaceSrc.includes("const isMyInfoOpen = expandedMenuId === 'my-info';"),
    'isMyInfoOpen is derived from expandedMenuId === "my-info"'
  );
  assert(
    studentWorkspaceSrc.includes("const isAcademicsOpen = expandedMenuId === 'academics';"),
    'isAcademicsOpen is derived from expandedMenuId === "academics"'
  );
  assert(
    studentWorkspaceSrc.includes("const isExaminationOpen = expandedMenuId === 'examination';"),
    'isExaminationOpen is derived from expandedMenuId === "examination"'
  );

  // Check all 11 toggle calls
  const allGroups = [
    'my-info', 'info-corner', 'proctor', 'academics', 'examination',
    'services', 'bonafide', 'online-payments', 'convocation', 'hostels', 'my-account'
  ];
  for (const g of allGroups) {
    assert(
      studentWorkspaceSrc.includes(`toggleGroup('${g}')`),
      `Group header '${g}' triggers toggleGroup('${g}')`
    );
  }

  // Verify NO FFCS in Student Portal
  assert(
    !studentWorkspaceSrc.includes('ffcs-registration'),
    'Student Portal navigation strictly does not contain ffcs-registration'
  );

  // --- 4. Faculty Portal Sidebar Integrity Check ---
  console.log('\n--- 4. Faculty Portal Sidebar Integrity Check ---');

  const facultySidebarPath = path.resolve(process.cwd(), 'src/components/common/PortalSidebar.tsx');
  const facultySidebarSrc = fs.readFileSync(facultySidebarPath, 'utf-8');

  assert(
    facultySidebarSrc.includes('const [expandedMenuId, setExpandedMenuId] = useState<string | null>'),
    'PortalSidebar uses single shared expandedMenuId state'
  );
  assert(
    facultySidebarSrc.includes('setExpandedMenuId((current) => (current === item.id ? null : item.id))'),
    'PortalSidebar strictly toggles single-expansion accordion'
  );

  console.log('\n========================================================================');
  console.log(`  ACCORDION VERIFICATION SUMMARY: ${passed}/${total} PASSED (0 FAILED)`);
  console.log('========================================================================');
  console.log('🎉 ALL SINGLE-EXPANSION ACCORDION REQUIREMENTS VERIFIED SUCCESSFULLY!');
}

runVerification().catch((err) => {
  console.error(err);
  process.exit(1);
});
