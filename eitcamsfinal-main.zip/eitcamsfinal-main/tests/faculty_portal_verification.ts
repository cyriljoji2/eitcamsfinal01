import { devDataAdapter } from '../src/services/devDataAdapter';
import { examinationRepository } from '../src/services/examinationService';
import { academicRepository } from '../src/services/academicService';
import { proctorRepository } from '../src/services/proctorService';
import { studentPortalService } from '../src/services/studentPortalService';
import {
  AuthRole,
  AttendanceStatus,
  ExamLifecycleStatus,
  PortalType,
} from '../src/types/database';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runFacultyPortalVerification() {
  console.log('========================================================================');
  console.log('   EIT CAMS — Faculty & Teaching Staff Portal Verification Suite        ');
  console.log('========================================================================\n');

  try {
    // -------------------------------------------------------------------------
    // 1. Authenticated Faculty Identity & Employee Gateway
    // -------------------------------------------------------------------------
    console.log('--- 1. Faculty Member Identity & Profile Resolution ---');
    const authResult = await devDataAdapter.auth.login('dr.sharma', 'any_valid_pwd', PortalType.Employee);
    assert(authResult.success && !!authResult.session, 'Faculty authentication via Employee Gateway succeeded');
    assert(authResult.session?.role === AuthRole.FACULTY, 'Faculty authenticated with role FACULTY', `Role: ${authResult.session?.role}`);
    
    const facultyEmpId = authResult.session?.employeeProfile?.employee_id || 'EMP-001';
    assert(facultyEmpId === 'EMP-001', 'Faculty resolved to correct Employee ID EMP-001');

    const facultyUser = authResult.session!.user;

    const facultyRecord = await devDataAdapter.employees.getById(facultyEmpId);
    assert(!!facultyRecord, 'Employee record found for faculty member');
    assert(facultyRecord?.first_name === 'Arvind' && facultyRecord?.last_name === 'Sharma', 'Faculty name verified as Dr. Arvind Sharma');
    assert(facultyRecord?.primary_department === 'CSE', 'Faculty department verified as Computer Science & Engineering (CSE)');
    assert(facultyRecord?.category === 'TEACHING', 'Faculty designated as category: TEACHING');

    // -------------------------------------------------------------------------
    // 2. Assigned Courses & Sections Isolation
    // -------------------------------------------------------------------------
    console.log('\n--- 2. Academic Office Course Assignments Isolation ---');
    const assignedCourses = await devDataAdapter.academic.getFacultyAssignedCourses(facultyEmpId);
    assert(Array.isArray(assignedCourses) && assignedCourses.length > 0, 'Assigned courses retrieved for faculty member', `Count: ${assignedCourses.length}`);
    
    // Must contain CS201 Section A
    const cs201Assignment = assignedCourses.find((a) => a.course_code === 'CS201');
    assert(!!cs201Assignment, 'Assigned courses contains Data Structures & Algorithms (CS201)');
    assert(cs201Assignment?.section === 'A', 'CS201 assigned section is Section A');

    // Cross-faculty isolation test: Verify an unassigned employee does not inherit Dr. Sharma's courses
    const dummyEmpCourses = await devDataAdapter.academic.getFacultyAssignedCourses('EMP-999-NONEXISTENT');
    assert(dummyEmpCourses.length === 0, 'Unassigned employee returns zero course assignments');

    // -------------------------------------------------------------------------
    // 3. Class Roster & Student Enrolment Scoping
    // -------------------------------------------------------------------------
    console.log('\n--- 3. Class Roster & Section Scoping ---');
    const roster = await devDataAdapter.academic.getClassRoster('CS201', 'A', {
      userId: facultyUser.username,
      role: facultyUser.role,
      employeeId: facultyEmpId,
    });
    assert(Array.isArray(roster) && roster.length > 0, 'Class roster retrieved for CS201 Section A', `Enrolled students: ${roster.length}`);
    
    const sampleStudent = roster[0];
    assert(!!sampleStudent.student && !!sampleStudent.enrolment, 'Roster items contain valid student and enrolment pair');
    assert(sampleStudent.enrolment.course_code === 'CS201', 'Enrolment record matches course_code CS201');
    assert(sampleStudent.enrolment.section === 'A', 'Enrolment record matches section A');

    // -------------------------------------------------------------------------
    // 4. Teaching Timetable Integration
    // -------------------------------------------------------------------------
    console.log('\n--- 4. Published Teaching Timetable Integration ---');
    const timetable = await devDataAdapter.academic.getTimetable({
      faculty_id: facultyEmpId,
    });
    assert(Array.isArray(timetable), 'Timetable slots retrieved for faculty member');
    const facultySlots = timetable.filter((s) => s.faculty_id === facultyEmpId || s.course_code === 'CS201');
    assert(facultySlots.length > 0, 'Faculty timetable contains published slots for CS201', `Slots found: ${facultySlots.length}`);

    // -------------------------------------------------------------------------
    // 5. Attendance Recording & Authorized Correction Workflow
    // -------------------------------------------------------------------------
    console.log('\n--- 5. Attendance Recording, Duplicate Prevention & Correction ---');
    const testDate = '2026-11-04';
    const testSlot = '10:00-11:00 AM';
    const testStudent = sampleStudent.student;

    // Record attendance
    const recordedAttendance = await devDataAdapter.attendance.record(
      {
        student_id: testStudent.student_id,
        registration_number: testStudent.registration_number,
        course_code: 'CS201',
        section: 'A',
        date: testDate,
        session_slot: testSlot,
        status: AttendanceStatus.PRESENT,
        recorded_by_employee_id: facultyEmpId,
        remarks: 'Regular lecture attendance',
      },
      {
        userId: facultyUser.username,
        role: facultyUser.role,
        employeeId: facultyEmpId,
      }
    );
    assert(!!recordedAttendance && recordedAttendance.attendance_id !== '', 'Attendance recorded successfully', `ID: ${recordedAttendance.attendance_id}`);
    assert(recordedAttendance.status === AttendanceStatus.PRESENT, 'Attendance status is PRESENT');
    assert(recordedAttendance.recorded_by_employee_id === facultyEmpId, 'Recorded by employee ID matches faculty EMP-001');

    // Duplicate session prevention test
    let duplicateCaught = false;
    try {
      await devDataAdapter.attendance.record(
        {
          student_id: testStudent.student_id,
          registration_number: testStudent.registration_number,
          course_code: 'CS201',
          section: 'A',
          date: testDate,
          session_slot: testSlot,
          status: AttendanceStatus.ABSENT,
          recorded_by_employee_id: facultyEmpId,
        },
        {
          userId: facultyUser.username,
          role: facultyUser.role,
          employeeId: facultyEmpId,
        }
      );
    } catch (err: any) {
      duplicateCaught = true;
    }
    assert(duplicateCaught, 'Duplicate attendance record rejected for same student, course, date and slot');

    // Authorized correction test with mandatory reason
    let emptyReasonCaught = false;
    try {
      await devDataAdapter.attendance.correctAttendance!(
        recordedAttendance.attendance_id,
        AttendanceStatus.LATE,
        '', // Empty reason should fail
        {
          userId: facultyUser.username,
          role: facultyUser.role,
          employeeId: facultyEmpId,
        }
      );
    } catch (err) {
      emptyReasonCaught = true;
    }
    assert(emptyReasonCaught, 'Attendance correction without reason is strictly rejected');

    const correctedAttendance = await devDataAdapter.attendance.correctAttendance!(
      recordedAttendance.attendance_id,
      AttendanceStatus.LATE,
      'Student arrived 10 minutes late due to inter-building lab transit',
      {
        userId: facultyUser.username,
        role: facultyUser.role,
        employeeId: facultyEmpId,
      }
    );
    assert(correctedAttendance.status === AttendanceStatus.LATE, 'Attendance corrected to LATE with valid reason');
    assert(correctedAttendance.remarks?.includes('transit'), 'Attendance correction audit remark recorded');

    // -------------------------------------------------------------------------
    // 6. Examination Marks Entry & Separation of Duties
    // -------------------------------------------------------------------------
    console.log('\n--- 6. Marks Entry, Draft Saving & COE Separation of Duties ---');
    const schedules = await examinationRepository.getSchedules();
    const cs201Schedule = schedules.find((s) => s.course_code === 'CS201') || schedules[0];
    assert(!!cs201Schedule, 'Exam schedule identified for marks entry', `Schedule: ${cs201Schedule.schedule_id} (${cs201Schedule.course_code})`);

    // Ensure marks entry is open for test schedule
    cs201Schedule.marks_entry_open = true;

    // Faculty saves marks as draft
    const draftMarks = await devDataAdapter.coe.saveDraftMarks(
      cs201Schedule.schedule_id,
      [
        {
          student_id: testStudent.student_id,
          internal_marks: 38,
          external_marks: 52,
          submission_notes: 'Draft marks saved by instructor',
        },
      ],
      {
        userId: facultyUser.username,
        role: facultyUser.role,
        employeeId: facultyEmpId,
      }
    );
    assert(draftMarks.length > 0, 'Marks saved as draft by faculty', `Count: ${draftMarks.length}`);
    
    // Verify status remains OPEN / SCHEDULED
    const scheduleAfterDraft = (await devDataAdapter.coe.getSchedules()).find((s) => s.schedule_id === cs201Schedule.schedule_id);
    assert(scheduleAfterDraft?.marks_entry_open === true, 'Schedule marks entry remains open during draft saving');

    // Faculty submits marks to COE
    await devDataAdapter.coe.submitMarksForReview(
      cs201Schedule.schedule_id,
      'Final submission from faculty instructor',
      {
        userId: facultyUser.username,
        role: facultyUser.role,
        employeeId: facultyEmpId,
      }
    );

    const scheduleAfterSubmit = (await devDataAdapter.coe.getSchedules()).find((s) => s.schedule_id === cs201Schedule.schedule_id);
    assert(scheduleAfterSubmit?.status === ExamLifecycleStatus.FACULTY_SUBMITTED, 'Schedule status transitioned to FACULTY_SUBMITTED');
    assert(scheduleAfterSubmit?.marks_entry_open === false, 'Marks entry locked after submission to COE');

    // Separation of Duties Check: Faculty CANNOT moderate or approve marks unilaterally
    let unauthorizedApprovalFailed = false;
    try {
      await devDataAdapter.coe.approveResults(
        cs201Schedule.schedule_id,
        {
          userId: facultyUser.username,
          role: facultyUser.role, // FACULTY role attempting COE moderation
          employeeId: facultyEmpId,
        }
      );
    } catch (err) {
      unauthorizedApprovalFailed = true;
    }
    assert(unauthorizedApprovalFailed, 'Separation of Duties enforced: Faculty cannot approve/moderate marks (Reserved for COE Office)');

    // COE moderates and approves marks
    const coeApprovalResult = await devDataAdapter.coe.approveResults(
      cs201Schedule.schedule_id,
      {
        userId: 'coeoffice',
        role: AuthRole.OFFICE_ADMIN,
      }
    );
    assert(coeApprovalResult.approvedCount > 0, 'COE Office successfully approved moderated marks');

    // -------------------------------------------------------------------------
    // 7. Proctor Mentorship Desk Operations & Authenticated Retrieval
    // -------------------------------------------------------------------------
    console.log('\n--- 7. Proctor Mentorship Desk Operations & Authenticated Retrieval ---');
    const facultyActor = {
      userId: facultyUser.username,
      role: facultyUser.role,
      employeeId: facultyEmpId,
    };

    const proctorAssignments = await proctorRepository.getActiveAssignmentsForFaculty(facultyEmpId, facultyActor);
    assert(Array.isArray(proctorAssignments), 'Active proctor assignments retrieved via service layer for faculty member', `Count: ${proctorAssignments.length}`);
    assert(proctorAssignments.every((a) => a.facultyId.toLowerCase() === facultyEmpId.toLowerCase()), 'All returned assignments match current faculty EMP-001');

    // Add mentorship remark on active proctee
    const remark = await proctorRepository.addRemark(
      {
        proctorId: facultyEmpId,
        studentId: testStudent.student_id,
        studentRegistrationNumber: testStudent.registration_number,
        studentName: `${testStudent.first_name} ${testStudent.last_name}`,
        category: 'academic',
        remark: 'Student advised on technical elective course selection for Semester 4.',
        actionRequired: false,
      },
      facultyActor
    );
    assert(!!remark && remark.id.startsWith('REM-'), 'Proctor confidential remark logged successfully', `Remark ID: ${remark.id}`);

    const retrievedRemarks = await proctorRepository.getRemarksByProctor(facultyEmpId, facultyActor);
    assert(retrievedRemarks.some((r) => r.id === remark.id), 'Retrieved remarks contains newly created entry');

    // Endorse leave request test
    const submittedLeave = studentPortalService.submitLeaveRequest({
      studentId: testStudent.student_id,
      studentRegistrationNumber: testStudent.registration_number,
      studentName: `${testStudent.first_name} ${testStudent.last_name}`,
      roomNumber: 'B-304',
      blockName: 'Nilgiri Hostel',
      requestType: 'leave' as const,
      fromDate: '2026-11-10',
      fromTime: '08:00',
      toDate: '2026-11-13',
      toTime: '20:00',
      reasonCategory: 'family' as const,
      reason: 'Attending sibling wedding ceremony in home town',
      destination: 'Bangalore',
      contactNumber: '9876543210',
      emergencyContact: '9876543211',
    });

    const endorsedReq = await proctorRepository.endorseLeaveOutingRequest(
      submittedLeave.id,
      facultyEmpId,
      'approve',
      'Endorsed. Spoke with parents on record; student academic progress is in good standing.',
      facultyActor
    );
    assert(endorsedReq.approvalStatus === 'APPROVED', 'Leave request approved by proctor');
    assert(endorsedReq.proctorRemarks?.includes('parent'), 'Leave request records proctor advisement remark');

    // -------------------------------------------------------------------------
    // 8. Cross-Proctor Access Denial & Confidentiality
    // -------------------------------------------------------------------------
    console.log('\n--- 8. Cross-Proctor Access Denial & Confidential Mentoring Scoping ---');
    
    // Cross-proctor assignments retrieval attempt
    let crossProctorQueryFailed = false;
    try {
      await proctorRepository.getActiveAssignmentsForFaculty('EMP-002', facultyActor);
    } catch (err: any) {
      crossProctorQueryFailed = err.message.includes('Cross-proctor access violation');
    }
    assert(crossProctorQueryFailed, 'Cross-proctor assignments access strictly denied at service layer');

    // Cross-proctor confidential remarks attempt
    let crossRemarksQueryFailed = false;
    try {
      await proctorRepository.getRemarksByProctor('EMP-002', facultyActor);
    } catch (err: any) {
      crossRemarksQueryFailed = err.message.includes('Cross-proctor access violation');
    }
    assert(crossRemarksQueryFailed, 'Cross-proctor confidential remarks access strictly denied');

    // Cross-proctor leave requests retrieval attempt
    let crossRequestsQueryFailed = false;
    try {
      await proctorRepository.getRequestsForProctor('EMP-002', facultyActor);
    } catch (err: any) {
      crossRequestsQueryFailed = err.message.includes('Cross-proctor access violation');
    }
    assert(crossRequestsQueryFailed, 'Cross-proctor leave requests access strictly denied');

    // Attempting to log remark on an unassigned student
    let unassignedRemarkFailed = false;
    try {
      await proctorRepository.addRemark(
        {
          proctorId: facultyEmpId,
          studentId: 'STU-002',
          studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
          category: 'conduct',
          remark: 'Unauthorized mentoring attempt on another proctors student',
        },
        facultyActor
      );
    } catch (err: any) {
      unassignedRemarkFailed = err.message.includes('not an active mentee in your proctor portfolio');
    }
    assert(unassignedRemarkFailed, 'Cannot log mentoring remarks for students outside active proctor portfolio');

    // -------------------------------------------------------------------------
    // 9. Faculty Inability to Modify Official Proctor Assignments
    // -------------------------------------------------------------------------
    console.log('\n--- 9. Proctor Assignment Governance (Faculty Authority Prohibited) ---');
    
    // Faculty cannot assign a proctee
    let facultyAssignFailed = false;
    try {
      await proctorRepository.assignProctor(
        {
          studentId: 'STU-002',
          studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
          studentName: 'Rohan Verma',
          facultyId: facultyEmpId,
          facultyName: 'Dr. Arvind Sharma',
          academicYear: '2026–2027',
        },
        facultyActor
      );
    } catch (err: any) {
      facultyAssignFailed = err.message.includes('Faculty members are not permitted to assign');
    }
    assert(facultyAssignFailed, 'Faculty member cannot create proctor assignments (Academic Office sole authority)');

    // Faculty cannot deactivate an assignment
    let facultyDeactivateFailed = false;
    try {
      await proctorRepository.deactivateAssignment('ASG-PRC-001', facultyActor);
    } catch (err: any) {
      facultyDeactivateFailed = err.message.includes('Faculty members are not permitted to assign');
    }
    assert(facultyDeactivateFailed, 'Faculty member cannot deactivate proctor assignments');

    // Faculty cannot bulk-assign proctees
    let facultyBulkFailed = false;
    try {
      await proctorRepository.bulkAssignProctors(
        [
          {
            studentId: 'STU-002',
            studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
            studentName: 'Rohan Verma',
            facultyId: facultyEmpId,
            facultyName: 'Dr. Arvind Sharma',
            academicYear: '2026–2027',
          },
        ],
        facultyActor
      );
    } catch (err: any) {
      facultyBulkFailed = err.message.includes('Faculty members are not permitted to assign');
    }
    assert(facultyBulkFailed, 'Faculty member cannot execute bulk proctor assignment');

    // -------------------------------------------------------------------------
    // 10. Academic Office Proctor Reassignment & Immediate Access Transition
    // -------------------------------------------------------------------------
    console.log('\n--- 10. Academic Office Proctor Reassignment & Immediate Transition ---');
    const academicActor = {
      userId: 'academicoffice',
      role: AuthRole.OFFICE_ADMIN,
    };

    // Initial state: STU-001 is assigned to EMP-001
    const initialAssignment = await proctorRepository.getActiveAssignmentForStudent('STU-001');
    assert(initialAssignment?.facultyId === 'EMP-001', 'STU-001 initially assigned to EMP-001');

    // Academic Office reassigns STU-001 to EMP-002 (Dr. Ramesh Sundaram)
    const reassigned = await proctorRepository.assignProctor(
      {
        studentId: 'STU-001',
        studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
        studentName: 'Arjun Kumar',
        facultyId: 'EMP-002',
        facultyName: 'Dr. Ramesh Sundaram',
        facultyEmail: 'r.sundaram@eit.edu',
        facultyPhone: '+91 94440 12345',
        facultyDepartment: 'Computer Science & Engineering',
        academicYear: '2026–2027',
      },
      academicActor
    );
    assert(!!reassigned && reassigned.facultyId === 'EMP-002', 'Academic Office successfully reassigned STU-001 to EMP-002');

    // Immediate access check: EMP-001 immediately loses STU-001
    const emp1AssignmentsAfter = await proctorRepository.getActiveAssignmentsForFaculty('EMP-001', facultyActor);
    assert(
      !emp1AssignmentsAfter.some((a) => a.studentId === 'STU-001'),
      'Former proctor EMP-001 immediately loses active access to STU-001'
    );

    // Immediate access check: EMP-002 now has STU-001
    const emp2Actor = { userId: 'dr.sundaram', role: AuthRole.FACULTY, employeeId: 'EMP-002' };
    const emp2AssignmentsAfter = await proctorRepository.getActiveAssignmentsForFaculty('EMP-002', emp2Actor);
    assert(
      emp2AssignmentsAfter.some((a) => a.studentId === 'STU-001'),
      'New proctor EMP-002 immediately gains active access to STU-001'
    );

    // Student Portal consistency check: STU-001 query returns new proctor immediately
    const studentPortalActiveProctor = await proctorRepository.getActiveAssignmentForStudent('STU-001');
    assert(studentPortalActiveProctor?.facultyId === 'EMP-002', 'Student Portal immediately reflects new proctor EMP-002');

    // Restore STU-001 assignment to EMP-001 for test suite state integrity
    await proctorRepository.assignProctor(
      {
        studentId: 'STU-001',
        studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
        studentName: 'Arjun Kumar',
        facultyId: 'EMP-001',
        facultyName: 'Dr. Arvind Sharma',
        facultyEmail: 'arvind.sharma@faculty.eit.edu',
        facultyPhone: '+91 94440 54321',
        facultyDepartment: 'Computer Science & Engineering',
        academicYear: '2026–2027',
      },
      academicActor
    );
    const restoredProctor = await proctorRepository.getActiveAssignmentForStudent('STU-001');
    assert(restoredProctor?.facultyId === 'EMP-001', 'STU-001 active proctor restored to EMP-001');

    // -------------------------------------------------------------------------
    // 11. Course & Section Access Restrictions (Unassigned Courses Denial)
    // -------------------------------------------------------------------------
    console.log('\n--- 11. Course & Section Access Restrictions ---');
    
    // Class Roster of unassigned course
    let unassignedRosterFailed = false;
    try {
      await devDataAdapter.academic.getClassRoster('EC201', 'A', facultyActor);
    } catch (err: any) {
      unassignedRosterFailed = err.message.includes('is not assigned to course');
    }
    assert(unassignedRosterFailed, 'Faculty access to unassigned course roster (EC201) strictly denied');

    // Exam marks access of unassigned course schedule
    let unassignedMarksQueryFailed = false;
    try {
      await devDataAdapter.coe.getMarks('EXSCH-2026-EC304', facultyActor);
    } catch (err: any) {
      unassignedMarksQueryFailed = err.message.includes('is not assigned to course');
    }
    assert(unassignedMarksQueryFailed, 'Faculty access to unassigned course examination marks strictly denied');

    // Exam eligibility access of unassigned course schedule
    let unassignedEligibilityFailed = false;
    try {
      await devDataAdapter.coe.checkEligibility('EXSCH-2026-EC304', facultyActor);
    } catch (err: any) {
      unassignedEligibilityFailed = err.message.includes('is not assigned to course');
    }
    assert(unassignedEligibilityFailed, 'Faculty access to unassigned course examination eligibility strictly denied');

    // -------------------------------------------------------------------------
    // 12. Student Academic Profile Access Scoping
    // -------------------------------------------------------------------------
    console.log('\n--- 12. Student Academic Profile Access Scoping ---');
    
    // Authorized: Student enrolled in CS201 Section A taught by faculty
    const authorizedProfile = await academicRepository.getStudentAcademicProfile(
      'EIT-STU-2026-CSE-0001',
      facultyActor
    );
    assert(!!authorizedProfile && authorizedProfile.registrationNumber === 'EIT-STU-2026-CSE-0001', 'Faculty can view academic profile of student enrolled in their course');

    // Unauthorized: Student not enrolled in faculty courses and not a proctee
    // Temporarily unassign STU-002 from proctoring if needed, STU-002 is assigned to EMP-002 and enrolled in CS201 Section B (unassigned)
    // Let's test with a simulated unrelated student registration or test student
    let unrelatedProfileFailed = false;
    try {
      // Create or test student without course enrolment with Dr. Sharma
      // We can test by calling with an actor who has no course or proctor link
      const unlinkedFacultyActor = {
        userId: 'prof.mech',
        role: AuthRole.FACULTY,
        employeeId: 'EMP-003',
      };
      await academicRepository.getStudentAcademicProfile('EIT-STU-2026-CSE-0001', unlinkedFacultyActor);
    } catch (err: any) {
      unrelatedProfileFailed = err.message.includes('is not authorized to access academic profile');
    }
    assert(unrelatedProfileFailed, 'Unrelated faculty member denied access to student academic profile');

    // -------------------------------------------------------------------------
    // 13. Faculty Marks Submission vs. COE Authority Separation
    // -------------------------------------------------------------------------
    console.log('\n--- 13. Faculty Marks Submission vs. COE Separation of Duties ---');
    
    // Faculty cannot moderate marks
    let facultyModerationFailed = false;
    try {
      const marks = await devDataAdapter.coe.getMarks(cs201Schedule.schedule_id);
      if (marks.length > 0) {
        await devDataAdapter.coe.moderateMark(
          marks[0].result_id,
          { revised_internal: 40, reason: 'Unauthorized faculty moderation attempt' },
          facultyActor
        );
      }
    } catch (err: any) {
      facultyModerationFailed = err.message.includes('cannot access COE Office administration') || err.message.includes('Unauthorized');
    }
    assert(facultyModerationFailed, 'Faculty cannot moderate examination marks (COE exclusive)');

    // Faculty cannot publish marks
    let facultyPublishFailed = false;
    try {
      await devDataAdapter.coe.publishResults(cs201Schedule.schedule_id, facultyActor);
    } catch (err: any) {
      facultyPublishFailed = err.message.includes('cannot access COE Office administration') || err.message.includes('Unauthorized');
    }
    assert(facultyPublishFailed, 'Faculty cannot publish examination results (COE exclusive)');

    // -------------------------------------------------------------------------
    // 14. Summary of Results
    // -------------------------------------------------------------------------
    console.log('\n========================================================================');
    const totalTests = results.length;
    const passedTests = results.filter((r) => r.passed).length;
    const failedTests = results.filter((r) => !r.passed).length;
    console.log(`   FACULTY PORTAL VERIFICATION SUMMARY: ${passedTests}/${totalTests} PASSED (${failedTests} FAILED)`);
    console.log('========================================================================\n');

    if (failedTests > 0) {
      console.error(`❌ VERIFICATION FAILED with ${failedTests} failures.`);
      process.exit(1);
    } else {
      console.log('🎉 ALL FACULTY PORTAL VERIFICATION CHECKS PASSED PERFECTLY!\n');
    }
  } catch (error) {
    console.error('Fatal unhandled error during verification:', error);
    process.exit(1);
  }
}

runFacultyPortalVerification();
