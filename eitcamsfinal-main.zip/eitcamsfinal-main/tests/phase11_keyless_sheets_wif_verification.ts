/**
 * EIT CAMS — Phase 11 Google Sheets Keyless WIF Integration Verification Suite
 *
 * Verifies the 7 targeted security & architecture criteria:
 * 1. Missing configuration is gracefully detected and reported without leaking credentials.
 * 2. Development adapter operations work 100% offline without Vercel OIDC or cloud access.
 * 3. Prohibited private keys & service-account JSON blobs are authoritatively rejected.
 * 4. Browser-side Google authentication execution is strictly blocked with security assertions.
 * 5. Server-only credential handling and error sanitization (redaction of JWTs, tokens, keys).
 * 6. Authentication failure handling, token lifetime, and STS grant rejection resilience.
 * 7. No fallback to insecure authentication or premature spreadsheet operations.
 */

import {
  validateEnvironmentConfiguration,
  createGoogleWorkloadIdentityClient,
  sanitizeAuthError,
  assertServerEnvironment,
  SHEETS_ENV_KEYS,
  PROHIBITED_PRIVATE_KEY_VARS,
} from '../api/sheetsAuth';
import handler, { ServerlessRequest, ServerlessResponse } from '../api/sheets';
import { devDataAdapter } from '../src/services/devDataAdapter';
import { itRepository } from '../src/services/itService';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';

interface TestCase {
  id: number;
  description: string;
  run: () => Promise<{ passed: boolean; details?: string }>;
}

function createMockResponse(): { res: ServerlessResponse; getResult: () => { statusCode: number; data: any; headers: Record<string, string> } } {
  let statusCode = 200;
  let data: any = null;
  const headers: Record<string, string> = {};

  const res: ServerlessResponse = {
    status: (code: number) => {
      statusCode = code;
      return res;
    },
    json: (d: any) => {
      data = d;
    },
    setHeader: (name: string, value: string) => {
      headers[name] = value;
    },
  };

  return {
    res,
    getResult: () => ({ statusCode, data, headers }),
  };
}

const tests: TestCase[] = [
  {
    id: 1,
    description: 'Missing configuration is safely reported with pending status and zero leaks',
    run: async () => {
      // Test validation with an empty environment
      const result = validateEnvironmentConfiguration({});
      const isPending = result.isPending && !result.isValid;
      const allMissing = result.missingVariables.length === 6;
      const hasContractVars =
        result.missingVariables.includes('GOOGLE_SERVICE_ACCOUNT_EMAIL') &&
        result.missingVariables.includes('GOOGLE_SHEETS_SPREADSHEET_ID') &&
        result.missingVariables.includes('GCP_PROJECT_ID') &&
        result.missingVariables.includes('GCP_PROJECT_NUMBER') &&
        result.missingVariables.includes('GCP_WORKLOAD_IDENTITY_POOL_ID') &&
        result.missingVariables.includes('GCP_WORKLOAD_IDENTITY_PROVIDER_ID');

      // Test API handler with empty env
      const { res, getResult } = createMockResponse();
      const req: ServerlessRequest = { method: 'GET' };
      await handler(req, res);
      const apiResult = getResult();

      const passed =
        isPending &&
        allMissing &&
        hasContractVars &&
        apiResult.statusCode === 200 &&
        apiResult.data.status === 'pending_configuration' &&
        apiResult.data.auth_mode === 'workload_identity_federation' &&
        apiResult.data.isPhase11Active === false;

      return {
        passed,
        details: `Missing vars detected: ${result.missingVariables.length}, API Status: ${apiResult.data.status}`,
      };
    },
  },
  {
    id: 2,
    description: 'Development adapter operates 100% offline without Vercel OIDC or cloud access',
    run: async () => {
      // Verify in-memory dev repository operates seamlessly
      const offices = await devDataAdapter.offices.getAllPermanent();
      const students = await devDataAdapter.students.getAll();
      const employees = await devDataAdapter.employees.getAll();
      const healthMetrics = itRepository.getSystemHealthMetrics();
      const integrations = itRepository.getIntegrationRegistry();

      const passed =
        offices.length >= 6 &&
        students.length >= 2 &&
        employees.length >= 4 &&
        healthMetrics.length >= 4 &&
        integrations.length >= 4;

      return {
        passed,
        details: `Dev Store verified: ${offices.length} offices, ${students.length} students, ${employees.length} employees, ${integrations.length} integrations`,
      };
    },
  },
  {
    id: 3,
    description: 'Prohibited private keys and service-account JSON blobs are authoritatively rejected',
    run: async () => {
      // 1. Env variable validation rejection
      const mockInsecureEnv: Record<string, string> = {
        [SHEETS_ENV_KEYS.GOOGLE_SERVICE_ACCOUNT_EMAIL]: 'test@example.com',
        [SHEETS_ENV_KEYS.GOOGLE_SHEETS_SPREADSHEET_ID]: 'test-sheet-id',
        [SHEETS_ENV_KEYS.GCP_PROJECT_ID]: 'test-project',
        [SHEETS_ENV_KEYS.GCP_PROJECT_NUMBER]: '123456789',
        [SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_POOL_ID]: 'test-pool',
        [SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_PROVIDER_ID]: 'test-provider',
        GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY: '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgk...\n-----END PRIVATE KEY-----',
      };

      const envResult = validateEnvironmentConfiguration(mockInsecureEnv);
      const envRejected =
        !envResult.isValid &&
        envResult.prohibitedVariablesFound.includes('GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY');

      // 2. HTTP payload rejection of private key in request body
      const { res, getResult } = createMockResponse();
      const req: ServerlessRequest = {
        method: 'POST',
        body: {
          action: 'verify_connection',
          private_key: '-----BEGIN RSA PRIVATE KEY-----...',
        },
      };
      await handler(req, res);
      const bodyResult = getResult();
      const payloadRejected =
        bodyResult.statusCode === 400 &&
        bodyResult.data.error === 'Security Policy Violation';

      return {
        passed: envRejected && payloadRejected,
        details: `Env rejected: ${envRejected}, Body rejected: ${payloadRejected} (${bodyResult.data.message})`,
      };
    },
  },
  {
    id: 4,
    description: 'Browser-side Google authentication execution is strictly blocked with security assertions',
    run: async () => {
      // Simulate browser execution context by mocking global window
      const originalWindow = (global as any).window;
      let browserBlocked = false;

      try {
        (global as any).window = {};
        assertServerEnvironment();
      } catch (err: any) {
        browserBlocked = err.message.includes('SECURITY VIOLATION') && err.message.includes('server-side');
      } finally {
        if (originalWindow === undefined) {
          delete (global as any).window;
        } else {
          (global as any).window = originalWindow;
        }
      }

      return {
        passed: browserBlocked,
        details: `Browser environment correctly triggered security violation: ${browserBlocked}`,
      };
    },
  },
  {
    id: 5,
    description: 'Server-only credential handling and error sanitization (redaction of JWTs, tokens, keys)',
    run: async () => {
      const sensitiveError =
        'Error exchanging token: eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c ' +
        'with bearer ya29.a0AfH6SMD_EXAMPLE_ACCESS_TOKEN and key -----BEGIN PRIVATE KEY-----\nMIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQg...\n-----END PRIVATE KEY-----';

      const sanitized = sanitizeAuthError(sensitiveError);

      const hasNoJwt = !sanitized.includes('eyJhbGci');
      const hasRedactedJwt = sanitized.includes('[REDACTED_JWT]');
      const hasNoAccessToken = !sanitized.includes('ya29.a0Af');
      const hasRedactedToken = sanitized.includes('[REDACTED_ACCESS_TOKEN]');
      const hasNoPrivateKey = !sanitized.includes('-----BEGIN PRIVATE KEY-----');
      const hasRedactedKey = sanitized.includes('[REDACTED_PRIVATE_KEY]');

      const passed =
        hasNoJwt &&
        hasRedactedJwt &&
        hasNoAccessToken &&
        hasRedactedToken &&
        hasNoPrivateKey &&
        hasRedactedKey;

      return {
        passed,
        details: `Sanitization result: JWT redacted=${hasRedactedJwt}, AccessToken redacted=${hasRedactedToken}, Key redacted=${hasRedactedKey}`,
      };
    },
  },
  {
    id: 6,
    description: 'Authentication failure handling, token lifetime, and STS grant rejection resilience',
    run: async () => {
      // Configure valid WIF configuration structure using EIT production parameters
      const validConfig = {
        serviceAccountEmail: 'eit-cams-service@eit-cams-production.iam.gserviceaccount.com',
        spreadsheetId: 'test-spreadsheet-id',
        projectId: 'eit-cams-production',
        projectNumber: '566038686982',
        poolId: 'eit-vercel-pool',
        providerId: 'vercel-oidc',
        providerResourceName:
          'projects/566038686982/locations/global/workloadIdentityPools/eit-vercel-pool/providers/vercel-oidc',
        stsAudience:
          '//iam.googleapis.com/projects/566038686982/locations/global/workloadIdentityPools/eit-vercel-pool/providers/vercel-oidc',
        vercelAudience:
          'https://iam.googleapis.com/projects/566038686982/locations/global/workloadIdentityPools/eit-vercel-pool/providers/vercel-oidc',
        impersonationUrl:
          'https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/eit-cams-service@eit-cams-production.iam.gserviceaccount.com:generateAccessToken',
      };

      const client = createGoogleWorkloadIdentityClient(validConfig);
      const isClientConstructed = Boolean(client);

      // Verify that calling getAccessToken without active Vercel OIDC context fails safely without unhandled crashes
      let safeErrorHandled = false;
      try {
        await client.getAccessToken();
      } catch (err: any) {
        const sanitized = sanitizeAuthError(err);
        safeErrorHandled = sanitized.length > 0 && !sanitized.includes('ya29.');
      }

      return {
        passed: isClientConstructed && safeErrorHandled,
        details: `IdentityPoolClient constructed: ${isClientConstructed}, STS invalid grant safely handled: ${safeErrorHandled}`,
      };
    },
  },
  {
    id: 7,
    description: 'No fallback to insecure authentication or premature spreadsheet operations',
    run: async () => {
      // Mock configured environment for WIF
      const originalEnv = { ...process.env };
      process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL = 'eit-cams-service@eit-cams-production.iam.gserviceaccount.com';
      process.env.GOOGLE_SHEETS_SPREADSHEET_ID = 'test-spreadsheet-id';
      process.env.GCP_PROJECT_ID = 'eit-cams-production';
      process.env.GCP_PROJECT_NUMBER = '566038686982';
      process.env.GCP_WORKLOAD_IDENTITY_POOL_ID = 'eit-vercel-pool';
      process.env.GCP_WORKLOAD_IDENTITY_PROVIDER_ID = 'vercel-oidc';
      delete process.env.PHASE_11_ACTIVE;

      try {
        const { res, getResult } = createMockResponse();
        const req: ServerlessRequest = {
          method: 'POST',
          body: {
            action: 'read_worksheet',
            worksheet: 'PermanentOffices',
          },
        };

        await handler(req, res);
        const result = getResult();

        // Must remain in standby mode because Phase 11 is not yet activated
        const isStandby =
          result.statusCode === 200 &&
          result.data.status === 'phase_11_standby' &&
          result.data.auth_mode === 'workload_identity_federation' &&
          result.data.message.includes('DevDataAdapter remains authoritative');

        return {
          passed: isStandby,
          details: `Phase 11 Standby status: ${result.data.status}, DevDataAdapter protected: ${isStandby}`,
        };
      } finally {
        process.env = originalEnv;
      }
    },
  },
];

async function runTestSuite() {
  console.log('================================================================');
  console.log('   EIT CAMS — Phase 11 Keyless Sheets WIF Verification Suite');
  console.log('================================================================');

  let passedCount = 0;

  for (const test of tests) {
    try {
      const outcome = await test.run();
      if (outcome.passed) {
        console.log(`✅ [Test ${test.id}] PASS: ${test.description}`);
        if (outcome.details) console.log(`   Details: ${outcome.details}`);
        passedCount++;
      } else {
        console.error(`❌ [Test ${test.id}] FAIL: ${test.description}`);
        if (outcome.details) console.error(`   Details: ${outcome.details}`);
      }
    } catch (err: any) {
      console.error(`💥 [Test ${test.id}] ERROR: ${test.description}`);
      console.error(`   Message: ${err?.message || err}`);
    }
  }

  console.log('================================================================');
  console.log(`Verification Complete: ${passedCount} of ${tests.length} tests passed.`);
  console.log('================================================================');

  if (passedCount !== tests.length) {
    process.exit(1);
  }
}

runTestSuite();
