/**
 * EIT CAMS — Administration Workspace & Global Academic Year Integration Test Suite
 * 
 * Verifies:
 * 1. Administration Login & Routing to AdminWorkspace (PO-001, SUPER_ADMIN)
 * 2. Four Admin Workspace Navigation Destinations (Overview, Employees, Bulk Import, Settings)
 * 3. Employee Directory, Registration, Role Assignment & Status Workflows
 * 4. Bulk Employee Import Processing & Credentials Generation
 * 5. Institutional Settings, Profile Management & Schema Architecture
 * 6. Academic Year Creation, Overlap Guards, Date Validation & Duplicate Prevention
 * 7. Strict Super Admin Authorization & Immutable Audit Logging
 * 8. Central Academic Year Synchronization & Real-Time Event Broadcast
 * 9. Historical Data Safety Verification (Marks, Attendance, Fees, Hostel, Student Batches)
 */

import { devDataAdapter } from '../src/services/devDataAdapter';
import { academicCalendarService, formatAcademicYear } from '../src/services/academicCalendarService';
import { employeeRepository, settingsRepository } from '../src/services/employeeService';
import {
  AuthRole,
  StudentStatus,
  EmploymentStatus,
  EmployeeCategory,
  PaymentStatus,
  AuditAction,
  AttendanceStatus,
} from '../src/types/database';
import { PortalType } from '../src/types/portal';
import { SIX_PERMANENT_OFFICES } from '../src/config/permanentOffices';

interface TestResult {
  number: number;
  title: string;
  passed: boolean;
  details?: string;
}

const results: TestResult[] = [];
let testIndex = 1;

function assert(condition: boolean, title: string, details?: string) {
  const currentNum = testIndex++;
  if (condition) {
    results.push({ number: currentNum, title, passed: true, details });
    console.log(`✅ [Test ${currentNum}] PASS: ${title}${details ? ` (${details})` : ''}`);
  } else {
    results.push({ number: currentNum, title, passed: false, details });
    console.error(`❌ [Test ${currentNum}] FAIL: ${title}${details ? ` (${details})` : ''}`);
  }
}

async function runAdminVerificationTests() {
  console.log('========================================================================');
  console.log('   EIT CAMS: Administration & Global Academic Year Verification Suite   ');
  console.log('========================================================================\n');

  // Setup mock window.sessionStorage for Node.js test environment if needed
  if (typeof (globalThis as any).window === 'undefined') {
    const store: Record<string, string> = {};
    (globalThis as any).window = {
      sessionStorage: {
        getItem: (k: string) => store[k] || null,
        setItem: (k: string, v: string) => { store[k] = v; },
        removeItem: (k: string) => { delete store[k]; },
        clear: () => { Object.keys(store).forEach((k) => delete store[k]); },
      },
    };
  }

  // ===========================================================================
  // 1. Administration Login & Office Routing (PO-001)
  // ===========================================================================
  console.log('--- 1. Administration Login & Identity (PO-001) ---');

  const adminLoginRes = await devDataAdapter.auth.login(
    'admin',
    'dev_mock_hash_admin',
    PortalType.Employee
  );

  assert(
    adminLoginRes.success === true && !!adminLoginRes.session,
    'Super Admin authenticates via Employee portal using permanent office credentials',
    `User: ${adminLoginRes.session?.username}, Role: ${adminLoginRes.session?.role}`
  );

  assert(
    adminLoginRes.session?.role === AuthRole.SUPER_ADMIN &&
    adminLoginRes.session?.permanentOffice?.office_id === 'PO-001' &&
    adminLoginRes.session?.permanentOffice?.office_key === 'ADMINISTRATION',
    'Administration session links to PO-001 permanent office with SUPER_ADMIN privileges',
    `Office: ${adminLoginRes.session?.permanentOffice?.office_name} (${adminLoginRes.session?.permanentOffice?.office_key})`
  );

  // Check permanent offices exist and are accessible
  const permanentOffices = await devDataAdapter.offices.getAllPermanent();
  assert(
    permanentOffices.length >= 6 &&
    permanentOffices.some((o) => o.office_key === 'ADMINISTRATION') &&
    permanentOffices.some((o) => o.office_key === 'ADMISSIONS') &&
    permanentOffices.some((o) => o.office_key === 'ACADEMIC') &&
    permanentOffices.some((o) => o.office_key === 'COE') &&
    permanentOffices.some((o) => o.office_key === 'FINANCE') &&
    permanentOffices.some((o) => o.office_key === 'HOSTEL'),
    'All six permanent office identities are preserved intact',
    `Found ${permanentOffices.length} permanent offices`
  );

  // ===========================================================================
  // 2. Employee Directory, Registration & Credentials
  // ===========================================================================
  console.log('\n--- 2. Employee Directory, Registration & Role Workflows ---');

  const initialEmployees = await employeeRepository.getAll();
  assert(
    Array.isArray(initialEmployees) && initialEmployees.length >= 4,
    'Employee directory retrieves preloaded institutional staff members',
    `Count: ${initialEmployees.length}`
  );

  // Create new faculty employee
  const uniqueSuffix = Date.now().toString().slice(-4);
  const newEmpData = {
    fullName: `Kavitha Ranganathan_${uniqueSuffix}`,
    firstName: 'Kavitha',
    lastName: `Ranganathan_${uniqueSuffix}`,
    dateOfBirth: '1988-04-12',
    gender: 'Female' as const,
    mobile: '+91 98401 23456',
    email: `kavitha.r_${uniqueSuffix}@eit.edu`,
    department: 'Computer Science & Engineering',
    designation: 'Associate Professor',
    category: 'TEACHING' as const,
    role: 'FACULTY',
    joiningDate: '2026-08-01',
    status: 'active' as const,
  };

  const createResult = await employeeRepository.create(newEmpData);
  assert(
    !!createResult.employee &&
    createResult.employee.firstName === 'Kavitha' &&
    !!createResult.employee.registrationNumber &&
    createResult.employee.registrationNumber.startsWith('EIT-'),
    'Employee registration assigns canonical registration number and generates temporary credentials',
    `Reg: ${createResult.employee.registrationNumber}, TempPass: ${createResult.temporaryPassword}`
  );

  // Status toggle
  const toggled = await employeeRepository.toggleStatus(createResult.employee.id);
  assert(
    toggled.status === 'inactive' || toggled.status === 'active' || toggled.status === 'INACTIVE' || toggled.status === 'ACTIVE',
    'Employee status toggling updates database record without breaking relationships',
    `New Status: ${toggled.status}`
  );

  // Reset password
  const resetRes = await employeeRepository.resetPassword(createResult.employee.id);
  assert(
    !!resetRes.temporaryPassword && resetRes.temporaryPassword.length >= 8,
    'Super Admin can securely reset employee password with fresh temporary token',
    `New TempPass: ${resetRes.temporaryPassword}`
  );

  // ===========================================================================
  // 3. Bulk Import Workflow
  // ===========================================================================
  console.log('\n--- 3. Bulk Employee Import Processing ---');

  const bulkImportPayload = [
    {
      fullName: `Anand Venkatesh_${uniqueSuffix}`,
      firstName: 'Anand',
      lastName: `Venkatesh_${uniqueSuffix}`,
      dateOfBirth: '1985-06-20',
      gender: 'Male' as const,
      mobile: '+91 98401 99991',
      email: `anand.v_${uniqueSuffix}@eit.edu`,
      department: 'Electrical & Electronics Engineering',
      designation: 'Assistant Professor',
      category: 'TEACHING' as const,
      role: 'FACULTY',
      joiningDate: '2026-08-15',
      status: 'active' as const,
    },
    {
      fullName: `Deepa Sundaram_${uniqueSuffix}`,
      firstName: 'Deepa',
      lastName: `Sundaram_${uniqueSuffix}`,
      dateOfBirth: '1992-09-15',
      gender: 'Female' as const,
      mobile: '+91 98401 99992',
      email: `deepa.s_${uniqueSuffix}@eit.edu`,
      department: 'Finance & Accounts Office',
      designation: 'Senior Accountant',
      category: 'NON_TEACHING' as const,
      role: 'OFFICE_STAFF',
      joiningDate: '2026-08-15',
      status: 'active' as const,
    },
  ];

  let bulkImportCount = 0;
  for (const emp of bulkImportPayload) {
    const res = await employeeRepository.create(emp);
    if (res.employee) bulkImportCount++;
  }

  assert(
    bulkImportCount === 2,
    'Bulk employee registration creates multiple employee accounts with individual credentials',
    `Imported: ${bulkImportCount} records`
  );

  // ===========================================================================
  // 4. Institutional Settings & Profile Management
  // ===========================================================================
  console.log('\n--- 4. Institutional Settings & Profile Configuration ---');

  const initialSettings = await settingsRepository.getSettings();
  assert(
    !!initialSettings && !!initialSettings.schoolName,
    'System settings repository returns institutional branding and profile',
    `Name: ${initialSettings.schoolName}`
  );

  const updatedSettings = await settingsRepository.updateSettings({
    schoolName: 'Electrix Institute of Technology (EIT)',
    schoolAddress: 'Technology Campus, Electrix Avenue, Chennai, Tamil Nadu 600025',
    contactNumber: '+91 44 2235 7004',
    email: 'admin@eit.edu',
    academicYear: '2026–2027',
  });

  assert(
    updatedSettings.schoolName === 'Electrix Institute of Technology (EIT)' &&
    updatedSettings.email === 'admin@eit.edu',
    'Institutional profile settings updated and saved with audit compliance',
    `Updated address: ${updatedSettings.schoolAddress}`
  );

  // ===========================================================================
  // 5. Academic Year Validation, Creation & Overlap Prevention
  // ===========================================================================
  console.log('\n--- 5. Academic Year Validation, Overlap Prevention & Creation ---');

  // 5.1 Test rejection of start >= end
  let dateOrderError = false;
  try {
    await academicCalendarService.createAcademicYear(
      {
        code: `2035-2036_${uniqueSuffix}`,
        name: `Academic Year 2035-2036`,
        startDate: '2035-12-31',
        endDate: '2035-01-01',
        status: 'UPCOMING',
      },
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
  } catch (err: any) {
    dateOrderError = true;
  }
  assert(
    dateOrderError,
    'Academic year creation rejects inverted date ranges (start date >= end date)'
  );

  // 5.2 Test rejection of empty code
  let emptyCodeError = false;
  try {
    await academicCalendarService.createAcademicYear(
      {
        code: '',
        name: 'Empty Code Year',
        startDate: '2030-01-01',
        endDate: '2030-12-31',
        status: 'UPCOMING',
      },
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
  } catch (err: any) {
    emptyCodeError = true;
  }
  assert(
    emptyCodeError,
    'Academic year creation rejects empty code/label'
  );

  // 5.3 Test rejection of overlapping dates with existing 2026-2027 (which is 2026-07-01 to 2027-06-30)
  let overlapError = false;
  try {
    await academicCalendarService.createAcademicYear(
      {
        code: `2026-OVERLAP_${uniqueSuffix}`,
        name: 'Overlapping Year',
        startDate: '2026-09-01',
        endDate: '2027-03-31',
        status: 'UPCOMING',
      },
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
  } catch (err: any) {
    overlapError = true;
  }
  assert(
    overlapError,
    'Academic year creation rejects date intervals overlapping with existing active academic years'
  );

  // Clean up any previous test year and ensure 2026-2027 is active
  try {
    await academicCalendarService.activateAcademicYear(
      'AY-2026-2027',
      'Baseline active academic year setup',
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
    await academicCalendarService.deleteAcademicYear('AY-2028-2029', { userId: 'admin', role: 'SUPER_ADMIN' });
  } catch {}

  const testYearCode = `2028-2029`;
  const createdYear = await academicCalendarService.createAcademicYear(
    {
      code: testYearCode,
      name: `Academic Year ${testYearCode}`,
      startDate: '2028-07-01',
      endDate: '2029-06-30',
      status: 'UPCOMING',
    },
    { userId: 'admin', role: 'SUPER_ADMIN' }
  );

  assert(
    !!createdYear && createdYear.code === testYearCode && createdYear.status === 'UPCOMING' && !createdYear.is_current,
    'Valid upcoming academic year created successfully in database as UPCOMING and not current',
    `Code: ${createdYear.code}, ID: ${createdYear.year_id}, Dates: ${createdYear.start_date} to ${createdYear.end_date}`
  );

  // 5.5 Duplicate code rejection
  let duplicateError = false;
  try {
    await academicCalendarService.createAcademicYear(
      {
        code: testYearCode,
        name: `Academic Year ${testYearCode} Duplicate`,
        startDate: '2032-07-01',
        endDate: '2033-06-30',
        status: 'UPCOMING',
      },
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
  } catch (err: any) {
    duplicateError = true;
  }
  assert(
    duplicateError,
    'Academic year creation rejects duplicate academic year code'
  );

  // ===========================================================================
  // 6. Super Admin-Only Activation & Mandatory Reason Enforcement
  // ===========================================================================
  console.log('\n--- 6. Super Admin-Only Activation & Audit Verification ---');

  // 6.1 Test rejection when reason is omitted
  let missingReasonError = false;
  try {
    await academicCalendarService.activateAcademicYear(
      createdYear.year_id,
      '',
      { userId: 'admin', role: 'SUPER_ADMIN' }
    );
  } catch (err: any) {
    missingReasonError = true;
  }
  assert(
    missingReasonError,
    'Academic year activation rejects request when institutional reason is omitted'
  );

  // 6.2 Test rejection when non-superadmin tries to activate
  let nonSuperAdminError = false;
  try {
    // Authoritative session storage simulation
    if (typeof (globalThis as any).window !== 'undefined') {
      (globalThis as any).window.sessionStorage.setItem(
        'eit_auth_session_v9',
        JSON.stringify({
          user: { username: 'EMP-001', user_id: 'USR-EMP-001' },
          role: AuthRole.FACULTY,
          displayName: 'Faculty Member',
        })
      );
    }
    await academicCalendarService.activateAcademicYear(
      createdYear.year_id,
      'Unauthorized faculty activation attempt',
      { userId: 'EMP-001', role: 'FACULTY' }
    );
  } catch (err: any) {
    nonSuperAdminError = true;
  } finally {
    // Restore Super Admin session
    if (typeof (globalThis as any).window !== 'undefined') {
      (globalThis as any).window.sessionStorage.setItem(
        'eit_auth_session_v9',
        JSON.stringify({
          user: { username: 'admin', user_id: 'USR-PO-001' },
          role: AuthRole.SUPER_ADMIN,
          displayName: 'Super Administrator',
        })
      );
    }
  }
  assert(
    nonSuperAdminError,
    'Academic year activation strictly rejects non-Super Admin actors (FACULTY/STUDENT/STAFF)'
  );

  // 6.3 Test live broadcast subscription listener
  let broadcastReceived: string | null = null;
  const unsubscribeBroadcast = academicCalendarService.subscribe((updatedYear) => {
    broadcastReceived = updatedYear.code;
  });

  // 6.4 Successful Super Admin activation with mandatory institutional reason
  const activationReason = 'Commencement of Board of Studies approved Academic Session 2028-2029';
  const activationResult = await academicCalendarService.activateAcademicYear(
    createdYear.year_id,
    activationReason,
    { userId: 'admin', role: 'SUPER_ADMIN', name: 'Super Administrator' }
  );

  assert(
    activationResult.success === true &&
    activationResult.activeYear.code === testYearCode &&
    activationResult.activeYear.is_current === true &&
    activationResult.activeYear.status === 'ACTIVE',
    'Super Admin successfully activates new academic year with active status flag set',
    `Activated: ${activationResult.activeYear.code}`
  );

  // Verify audit record was created with full metadata
  const transition = activationResult.transition;
  assert(
    !!transition &&
    (transition.previous_year_code === '2026-2027' || transition.previous_year_code.includes('2026')) &&
    transition.new_year_code === testYearCode &&
    (transition.activated_by_user_id === 'admin' || transition.activated_by_user_id === 'USR-PO-001') &&
    transition.reason === activationReason &&
    transition.status === 'SUCCESS',
    'Immutable audit log records transition with previous year, new year, actor identity, reason, and timestamp',
    `Transition ID: ${transition?.transition_id}, Actor: ${transition?.activated_by_user_id}, Prev: ${transition?.previous_year_code}, New: ${transition?.new_year_code}`
  );

  // Verify transition history contains the record
  const history = await academicCalendarService.getTransitionHistory();
  assert(
    history.some((h) => h.transition_id === transition.transition_id),
    'Transition audit history is queryable for administrative compliance reviews',
    `Audit log total entries: ${history.length}`
  );

  // Verify live subscriber was notified
  assert(
    broadcastReceived === testYearCode,
    'Central academic calendar service dispatches real-time broadcast to all subscribed workspaces',
    `Broadcast payload code: ${broadcastReceived}`
  );
  unsubscribeBroadcast();

  // ===========================================================================
  // 7. Central Academic Year Synchronization Across Portals
  // ===========================================================================
  console.log('\n--- 7. Central Academic Year Synchronization Across Portals ---');

  // Verify newly queried active academic year is the newly activated one
  const refreshedActiveYear = await academicCalendarService.getActiveAcademicYear();
  assert(
    refreshedActiveYear.code === testYearCode && refreshedActiveYear.is_current === true,
    'Newly queried active academic year returns the authoritative active year without stale cache',
    `Authoritative Active Code: ${refreshedActiveYear.code}`
  );

  // Verify formatAcademicYear utility ensures consistent en-dash typography
  const formatted = formatAcademicYear(refreshedActiveYear.code);
  assert(
    formatted === '2028–2029',
    'formatAcademicYear formats hyphens into standard institutional en-dashes',
    `Input: ${refreshedActiveYear.code} -> Output: ${formatted}`
  );

  // ===========================================================================
  // 8. Historical Data Safety Guarantee
  // ===========================================================================
  console.log('\n--- 8. Historical Data Safety Verification ---');

  const appState = devDataAdapter.getState();

  // 8.1 Published Marks and Results are untouched
  const sampleAcademic = appState.academics[0];
  assert(
    !!sampleAcademic && sampleAcademic.grade_point > 0 && sampleAcademic.academic_year === '2026-2027',
    'Published marks, grades, and GPA calculations remain unchanged after academic year transition',
    `Sample Academic Record: Student ${sampleAcademic?.student_id}, AY ${sampleAcademic?.academic_year}, Grade ${sampleAcademic?.letter_grade}`
  );

  // 8.2 Historical Attendance registers are untouched
  const sampleAttendance = appState.attendance[0];
  assert(
    sampleAttendance && !!sampleAttendance.date && sampleAttendance.status === AttendanceStatus.PRESENT,
    'Historical daily attendance registers and lecture records remain untouched',
    `Sample Attendance Date: ${sampleAttendance?.date}, Status: ${sampleAttendance?.status}`
  );

  // 8.3 Student Admission Batches and Registration Numbers are untouched
  const studentSTU1 = await devDataAdapter.students.getById('STU-001');
  assert(
    studentSTU1 &&
    studentSTU1.registration_number === 'EIT-STU-2026-CSE-0001' &&
    studentSTU1.admission_year === 2026,
    'Student admission year and batch records are strictly preserved and never mutated by AY change',
    `Student: ${studentSTU1?.registration_number}, Admission Year: ${studentSTU1?.admission_year}`
  );

  // 8.4 Fee Transactions & Receipts are untouched
  const sampleInvoice = appState.finance.find((i) => i.invoice_id === 'INV-2026-001');
  assert(
    sampleInvoice &&
    sampleInvoice.academic_year === '2026-2027' &&
    sampleInvoice.payment_status === PaymentStatus.PAID,
    'Historical fee transactions, invoices, and collected receipts preserve original academic year associations',
    `Invoice: ${sampleInvoice?.invoice_id}, AY: ${sampleInvoice?.academic_year}, Status: ${sampleInvoice?.payment_status}`
  );

  // 8.5 Hostel Allocations are untouched
  const sampleHostel = appState.hostelAllocations[0];
  assert(
    sampleHostel && sampleHostel.academic_year === '2026-2027',
    'Hostel room allotments and fee charges preserve their respective historical session periods',
    `Hostel Allocation AY: ${sampleHostel?.academic_year}, Bed: ${sampleHostel?.bed_id}`
  );

  // Revert back to 2026-2027 for ongoing testing integrity
  await academicCalendarService.activateAcademicYear(
    'AY-2026-2027',
    'Reset to baseline academic session 2026-2027 following integration suite completion',
    { userId: 'admin', role: 'SUPER_ADMIN' }
  );

  console.log('\n========================================================================');
  console.log(`   Verification Summary: ${results.filter((r) => r.passed).length} / ${results.length} Tests Passed`);
  console.log('========================================================================\n');

  const failed = results.filter((r) => !r.passed);
  if (failed.length > 0) {
    console.error(`💥 ${failed.length} test(s) failed!`);
    process.exit(1);
  } else {
    console.log('🎉 All Administration & Global Academic Year Integration Tests Passed Successfully!');
  }
}

runAdminVerificationTests().catch((err) => {
  console.error('Unhandled test suite error:', err);
  process.exit(1);
});
