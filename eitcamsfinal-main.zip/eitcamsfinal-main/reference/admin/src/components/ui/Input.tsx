import React, { forwardRef, useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  helperText?: string;
  errorMessage?: string;
  startIcon?: React.ReactNode;
  leftIcon?: React.ReactNode;
  isPassword?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      label,
      helperText,
      errorMessage,
      startIcon,
      leftIcon,
      isPassword = false,
      type = 'text',
      className = '',
      id,
      ...props
    },
    ref
  ) => {
    const [showPassword, setShowPassword] = useState(false);
    const inputId = id || (label ? label.toLowerCase().replace(/[^a-z0-9]/g, '-') : undefined);

    const actualType = isPassword ? (showPassword ? 'text' : 'password') : type;
    const icon = startIcon || leftIcon;

    return (
      <div className="w-full space-y-1.5 text-left">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-[13px] font-semibold text-[#1e293b]"
          >
            {label}
          </label>
        )}
        <div className="relative rounded-md">
          {icon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#64748b]">
              {icon}
            </div>
          )}
          <input
            ref={ref}
            id={inputId}
            type={actualType}
            className={`block w-full rounded-md border text-[#1e293b] placeholder:text-[#94a3b8] text-sm py-2.5 px-3 transition-colors outline-none focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] ${
              icon ? 'pl-10' : 'pl-3'
            } ${isPassword ? 'pr-10' : 'pr-3'} ${
              errorMessage
                ? 'border-rose-400 focus:border-rose-500 focus:ring-rose-500 bg-rose-50/20'
                : 'border-[#e2e8f0] bg-white hover:border-[#cbd5e1]'
            } ${className}`}
            {...props}
          />
          {isPassword && (
            <button
              type="button"
              id={inputId ? `${inputId}-toggle-pwd` : 'toggle-password-visibility'}
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#64748b] hover:text-[#1e293b] focus:outline-none"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              tabIndex={-1}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          )}
        </div>
        {errorMessage ? (
          <p className="text-xs text-rose-600 mt-1">{errorMessage}</p>
        ) : helperText ? (
          <p className="text-xs text-[#64748b] mt-1">{helperText}</p>
        ) : null}
      </div>
    );
  }
);

Input.displayName = 'Input';
