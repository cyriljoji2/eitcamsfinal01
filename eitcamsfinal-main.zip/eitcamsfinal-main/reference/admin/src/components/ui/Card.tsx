import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  id?: string;
  children?: React.ReactNode;
  className?: string;
  hoverable?: boolean;
  bordered?: boolean;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
}

export function Card({
  id,
  children,
  hoverable = false,
  bordered = true,
  padding = 'md',
  className = '',
  onClick,
  ...props
}: CardProps) {
  const paddingStyles = {
    none: 'p-0',
    sm: 'p-4',
    md: 'p-6 sm:p-8',
    lg: 'p-8 sm:p-10',
  };

  const hoverStyles = hoverable
    ? 'hover:border-[#1e3a8a] hover:shadow-md transition-all duration-200 cursor-pointer'
    : '';

  const borderStyles = bordered ? 'border border-[#e2e8f0]' : '';

  return (
    <div
      id={id}
      onClick={onClick}
      className={`bg-white rounded-xl ${borderStyles} ${paddingStyles[padding]} shadow-[0_4px_6px_-1px_rgba(0,0,0,0.06)] ${hoverStyles} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}
