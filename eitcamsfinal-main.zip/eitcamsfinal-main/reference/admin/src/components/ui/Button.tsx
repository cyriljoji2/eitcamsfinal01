import React, { forwardRef } from 'react';
import { Loader2 } from 'lucide-react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      variant = 'primary',
      size = 'md',
      isLoading = false,
      leftIcon,
      rightIcon,
      startIcon,
      endIcon,
      className = '',
      disabled,
      ...props
    },
    ref
  ) => {
    const leadIcon = leftIcon || startIcon;
    const trailIcon = rightIcon || endIcon;

    const baseStyles =
      'inline-flex items-center justify-center font-medium rounded-md transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap select-none cursor-pointer';

    const sizeStyles = {
      sm: 'px-3 py-1.5 text-xs sm:text-sm gap-1.5',
      md: 'px-4 py-2 text-sm gap-2',
      lg: 'px-5 py-2.5 text-sm sm:text-base font-semibold gap-2',
    };

    const variantStyles = {
      primary:
        'bg-[#1e3a8a] text-white hover:bg-[#1e40af] active:bg-[#172554] focus:ring-[#1e3a8a] shadow-xs',
      secondary:
        'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800 focus:ring-blue-600 shadow-xs',
      outline:
        'border border-[#e2e8f0] bg-white text-[#1e293b] hover:bg-[#f8fafc] hover:border-[#cbd5e1] active:bg-[#f1f5f9] focus:ring-[#1e3a8a]',
      ghost:
        'text-[#64748b] hover:bg-[#f1f5f9] hover:text-[#1e293b] active:bg-[#e2e8f0] focus:ring-slate-400',
      danger:
        'bg-[#fee2e2] text-[#991b1b] hover:bg-[#fecaca] active:bg-[#fca5a5] focus:ring-rose-400 border border-rose-200 shadow-2xs',
    };

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
        {...props}
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 animate-spin text-current" />
        ) : (
          leadIcon
        )}
        <span>{children}</span>
        {!isLoading && trailIcon}
      </button>
    );
  }
);

Button.displayName = 'Button';
