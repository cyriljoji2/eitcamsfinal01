import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

export interface AlertProps {
  type?: 'error' | 'success' | 'info';
  title?: string;
  message: string;
  onDismiss?: () => void;
  className?: string;
}

export function Alert({
  type = 'error',
  title,
  message,
  onDismiss,
  className = '',
}: AlertProps) {
  const styles = {
    error: {
      container: 'bg-[#fee2e2] border-[#fecaca] text-[#991b1b]',
      icon: <AlertCircle className="w-5 h-5 text-[#991b1b] shrink-0" />,
    },
    success: {
      container: 'bg-[#dcfce7] border-[#bbf7d0] text-[#166534]',
      icon: <CheckCircle2 className="w-5 h-5 text-[#166534] shrink-0" />,
    },
    info: {
      container: 'bg-[#eff6ff] border-[#dbeafe] text-[#1e3a8a]',
      icon: <Info className="w-5 h-5 text-[#1e3a8a] shrink-0" />,
    },
  };

  const currentStyle = styles[type];

  return (
    <div
      role="alert"
      className={`flex items-start gap-3 p-3.5 rounded-md border text-sm ${currentStyle.container} ${className}`}
    >
      {currentStyle.icon}
      <div className="flex-1 text-left">
        {title && <h4 className="font-semibold mb-0.5">{title}</h4>}
        <p className="leading-relaxed">{message}</p>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          className="opacity-70 hover:opacity-100 p-0.5 rounded transition-opacity focus:outline-none cursor-pointer"
          aria-label="Dismiss alert"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}
