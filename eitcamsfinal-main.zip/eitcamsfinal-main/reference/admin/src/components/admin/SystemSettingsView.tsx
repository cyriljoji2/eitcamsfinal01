import React, { useState, useEffect } from 'react';
import {
  Save,
  Building,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Database,
  CheckCircle2,
  FileSpreadsheet,
  Layers,
  Cloud,
  Check,
  Copy,
  ExternalLink,
  Code2,
  HelpCircle,
} from 'lucide-react';
import { SystemSettings } from '../../types/employee';
import { settingsRepository } from '../../services/employeeService';
import { googleSheetsService, GOOGLE_SHEETS_CONFIG } from '../../services/googleSheetsService';
import { APPS_SCRIPT_CODE_GS } from '../../services/appsScriptBackend';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';

export interface SystemSettingsViewProps {
  onSettingsUpdated?: (settings: SystemSettings) => void;
}

export function SystemSettingsView({ onSettingsUpdated }: SystemSettingsViewProps) {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [schoolName, setSchoolName] = useState('');
  const [schoolAddress, setSchoolAddress] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [academicYear, setAcademicYear] = useState('');
  const [sheetsUrl, setSheetsUrl] = useState('');

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [showScriptCode, setShowScriptCode] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const data = await settingsRepository.getSettings();
      setSettings(data);
      setSchoolName(data.schoolName);
      setSchoolAddress(data.schoolAddress);
      setContactNumber(data.contactNumber);
      setEmail(data.email);
      setAcademicYear(data.academicYear);

      const activeUrl = googleSheetsService.getApiUrl() || '';
      setSheetsUrl(activeUrl);
    } catch (err: any) {
      setErrorMessage('Failed to load system settings.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await googleSheetsService.testConnection(sheetsUrl.trim() || undefined);
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || 'Connection attempt failed.' });
    } finally {
      setIsTesting(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_CODE_GS);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    if (!schoolName.trim()) {
      setErrorMessage('School Name is required.');
      return;
    }

    setIsSaving(true);
    try {
      const updated = await settingsRepository.updateSettings({
        schoolName: schoolName.trim(),
        schoolAddress: schoolAddress.trim(),
        contactNumber: contactNumber.trim(),
        email: email.trim(),
        academicYear: academicYear.trim(),
      });

      // Save Sheets URL
      googleSheetsService.setApiUrl(sheetsUrl.trim() || null);

      setSettings(updated);
      setSuccessMessage('Institutional profile and Google Sheets configuration saved successfully.');
      if (onSettingsUpdated) {
        onSettingsUpdated(updated);
      }
    } catch (err: any) {
      setErrorMessage('Failed to save settings.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="py-16 text-center text-[#64748b]">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#1e3a8a] mb-2"></div>
        <p className="text-xs">Loading institutional settings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#e2e8f0]">
        <div>
          <h2 className="text-[20px] sm:text-[22px] font-bold text-[#1e293b] tracking-tight">
            Institutional Settings & Data Layer
          </h2>
          <p className="text-[13px] text-[#64748b] mt-0.5">
            Configure college profile, academic calendar, and Google Sheets Apps Script API integration.
          </p>
        </div>
      </div>

      {successMessage && (
        <Alert
          type="success"
          message={successMessage}
          onDismiss={() => setSuccessMessage(null)}
        />
      )}

      {errorMessage && (
        <Alert
          type="error"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="space-y-6">
        {/* School Profile Card */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <Building className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-[15px] font-bold text-[#1e293b]">Institutional Information</h3>
              <p className="text-xs text-[#64748b]">Appears across student, employee, and parent portal interfaces.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Input
                id="settings-school-name"
                label="Institution Name *"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="e.g. Electrix Institute of Technology (EIT)"
                required
              />
            </div>

            <div>
              <Input
                id="settings-academic-year"
                label="Active Academic Year *"
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                placeholder="e.g. 2026–2027"
                startIcon={<Calendar className="w-4 h-4" />}
                required
              />
            </div>

            <div>
              <Input
                id="settings-contact-phone"
                label="Official Contact Number"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="+1 (555) 019-2830"
                startIcon={<Phone className="w-4 h-4" />}
              />
            </div>

            <div>
              <Input
                id="settings-contact-email"
                label="Official Administration Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="administration@school.edu"
                startIcon={<Mail className="w-4 h-4" />}
              />
            </div>

            <div className="sm:col-span-2">
              <Input
                id="settings-address"
                label="Campus Physical Address"
                value={schoolAddress}
                onChange={(e) => setSchoolAddress(e.target.value)}
                placeholder="1000 Academic Parkway, Springfield, IL 62701"
                startIcon={<MapPin className="w-4 h-4" />}
              />
            </div>
          </div>
        </div>

        {/* Google Sheets Apps Script Integration Card */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#f1f5f9]">
            <div className="flex items-center gap-2">
              <Cloud className="w-5 h-5 text-[#1e3a8a]" />
              <div>
                <h3 className="text-[15px] font-bold text-[#1e293b]">Google Sheets Persistence Gateway</h3>
                <p className="text-xs text-[#64748b]">Synchronize institutional data securely via Google Apps Script Web App.</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowScriptCode(!showScriptCode)}
              className="text-xs font-semibold text-[#1e3a8a] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <Code2 className="w-4 h-4" />
              {showScriptCode ? 'Hide Code' : 'View Code.gs Script'}
            </button>
          </div>

          <div className="space-y-3">
            <Input
              id="settings-sheets-url"
              label="Google Apps Script Web App Deployment URL"
              value={sheetsUrl}
              onChange={(e) => setSheetsUrl(e.target.value)}
              placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
              startIcon={<FileSpreadsheet className="w-4 h-4 text-emerald-600" />}
              helperText="Paste your deployed Google Apps Script Web App URL to enable live Google Sheets synchronization."
            />

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={handleTestConnection}
                isLoading={isTesting}
                leftIcon={<Cloud className="w-4 h-4" />}
              >
                Test Endpoint Connection
              </Button>

              <button
                type="button"
                onClick={handleCopyCode}
                className="text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-md px-3 py-1.5 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedScript ? 'Code Copied!' : 'Copy Code.gs for Google Sheets'}
              </button>
            </div>

            {testResult && (
              <div className={`p-3 rounded-lg border text-xs flex items-center gap-2 ${testResult.success ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-red-50 text-red-800 border-red-200'}`}>
                {testResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <HelpCircle className="w-4 h-4 text-red-600 shrink-0" />}
                <span>{testResult.message}</span>
              </div>
            )}

            {showScriptCode && (
              <div className="mt-4 p-4 rounded-lg bg-slate-900 text-slate-100 text-xs font-mono overflow-x-auto max-h-72 border border-slate-800">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-slate-400">
                  <span>Google Apps Script — Code.gs</span>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="text-white hover:text-emerald-400 flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy
                  </button>
                </div>
                <pre>{APPS_SCRIPT_CODE_GS}</pre>
              </div>
            )}
          </div>
        </div>

        {/* 9 Standardized Sheets Schema Overview Card */}
        <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
            <Database className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-[15px] font-bold text-[#1e293b]">9 Normalized Google Sheets Tabs</h3>
              <p className="text-xs text-[#64748b]">Structured minimal schema architecture verified for high-concurrency operations.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            {Object.entries(GOOGLE_SHEETS_CONFIG.SHEET_NAMES).map(([key, name]) => (
              <div key={key} className="bg-white p-3 rounded-lg border border-[#e2e8f0] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1e293b] flex items-center gap-1.5">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                    {name}
                  </span>
                  <span className="bg-[#dcfce7] text-[#166534] font-semibold px-1.5 py-0.5 rounded text-[10px]">
                    Active
                  </span>
                </div>
                <p className="text-[11px] text-[#64748b]">
                  {key === 'SETTINGS' && 'System configuration & academic profile'}
                  {key === 'EMPLOYEES' && 'Employee accounts, roles & credentials'}
                  {key === 'STUDENTS' && 'Student admissions, parents & registrations'}
                  {key === 'ACADEMICS' && 'Classes, sections, subjects & course allocations'}
                  {key === 'ATTENDANCE' && 'Daily attendance logs by section'}
                  {key === 'FINANCE_STRUCTURES' && 'Fee heads, tiers & frequency master'}
                  {key === 'FINANCE_LEDGER' && 'Fee assignments, receipts & void records'}
                  {key === 'EXAMINATIONS' && 'Exam schedules & subject timetables'}
                  {key === 'MARKS_RESULTS' && 'Marks, verified results & hall tickets'}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button
            type="submit"
            variant="primary"
            size="md"
            isLoading={isSaving}
            leftIcon={<Save className="w-4 h-4" />}
          >
            Save Settings & Data Config
          </Button>
        </div>
      </form>
    </div>
  );
}

