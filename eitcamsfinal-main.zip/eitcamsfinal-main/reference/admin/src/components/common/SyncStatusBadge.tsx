import { useEffect, useState } from 'react';
import { Cloud, CloudUpload, AlertTriangle, CloudOff } from 'lucide-react';
import { googleSheetsService, SyncState } from '../../services/googleSheetsService';

export function SyncStatusBadge({ className = '' }: { className?: string }) {
  const [syncState, setSyncState] = useState<SyncState>(googleSheetsService.getSyncState());

  useEffect(() => {
    const unsubscribe = googleSheetsService.subscribe((state) => {
      setSyncState(state);
    });
    return unsubscribe;
  }, []);

  if (!syncState.isConfigured) {
    return null;
  }

  // Only display "Sheets Synced" when a live request has actually succeeded and returned a valid response!
  if (syncState.status === 'synced') {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/80 shadow-2xs ${className}`}
        title={`Google Sheets Connected & Synchronized. ${syncState.lastSyncedAt ? 'Last synced: ' + new Date(syncState.lastSyncedAt).toLocaleTimeString() : 'Verified'}`}
      >
        <Cloud className="w-3 h-3 text-emerald-600" />
        <span>Sheets Synced</span>
      </div>
    );
  }

  // Pending verification / in-progress sync
  if (syncState.status === 'pending') {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200/80 shadow-2xs ${className}`}
        title="Local save active. Google Sheets synchronization pending or awaiting verification."
      >
        <CloudUpload className="w-3 h-3 text-amber-600 animate-pulse" />
        <span>Sheets Pending</span>
      </div>
    );
  }

  // Backend unavailable (deployment function missing, access restricted, or network unreachable)
  if (syncState.status === 'unavailable') {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-red-50 text-red-700 border border-red-200/80 shadow-2xs ${className}`}
        title={syncState.errorMessage || 'Google Apps Script endpoint is unreachable.'}
      >
        <CloudOff className="w-3 h-3 text-red-600" />
        <span>Backend Unavailable</span>
      </div>
    );
  }

  // Synchronization failed (error returned from backend execution)
  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-rose-50 text-rose-700 border border-rose-200/80 shadow-2xs ${className}`}
      title={syncState.errorMessage || 'Google Sheets synchronization encountered an error.'}
    >
      <AlertTriangle className="w-3 h-3 text-rose-600" />
      <span>Sync Failed</span>
    </div>
  );
}

