import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  RotateCcw,
  Search,
  Filter,
  AlertCircle,
  Eye,
  FileCheck,
  ChevronDown,
  ChevronUp,
  User,
  BookOpen,
  Award,
} from 'lucide-react';
import {
  Examination,
  ExamSubjectSchedule,
  StudentMarkEntry,
} from '../../types/examination';
import { Button } from '../ui/Button';

interface MarksVerificationViewProps {
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  allMarks: StudentMarkEntry[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onVerifyMarks: (scheduleId: string, notes?: string) => Promise<void>;
  onOpenReturnModal: (schedule: ExamSubjectSchedule) => void;
}

export function MarksVerificationView({
  examinations,
  schedules,
  allMarks,
  selectedExamId,
  onSelectExamId,
  onVerifyMarks,
  onOpenReturnModal,
}: MarksVerificationViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [expandedScheduleId, setExpandedScheduleId] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || '';

  const examSchedules = schedules.filter((s) => s.examinationId === activeExamId);

  const filteredSchedules = examSchedules.filter((sch) => {
    const matchesStatus =
      statusFilter === 'All' || sch.markSubmissionStatus === statusFilter;
    const matchesSearch =
      sch.subjectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.subjectCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.assignedFacultyName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const submittedCount = examSchedules.filter(
    (s) => s.markSubmissionStatus === 'Submitted'
  ).length;
  const verifiedCount = examSchedules.filter(
    (s) => s.markSubmissionStatus === 'Verified'
  ).length;
  const returnedCount = examSchedules.filter(
    (s) => s.markSubmissionStatus === 'Returned'
  ).length;

  const handleVerify = async (scheduleId: string) => {
    if (
      window.confirm(
        'Confirm approval for this paper? Once verified, all student marks will be locked for official results processing.'
      )
    ) {
      setIsVerifying(true);
      try {
        await onVerifyMarks(scheduleId, 'Audited and verified by Controller of Examination');
      } finally {
        setIsVerifying(false);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Marks Audit & Verification Workspace
          </h1>
          <p className="text-xs text-[#64748b]">
            Review faculty submitted student evaluations, detect mark discrepancies, approve scores, or return papers for revision
          </p>
        </div>
      </div>

      {/* Verification KPI stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Pending COE Verification</div>
            <div className="text-xl font-black text-blue-700">{submittedCount}</div>
          </div>
          <div className="p-2 bg-blue-50 text-blue-700 rounded-lg">
            <FileCheck className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Verified & Approved</div>
            <div className="text-xl font-black text-emerald-700">{verifiedCount}</div>
          </div>
          <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Returned For Revision</div>
            <div className="text-xl font-black text-red-700">{returnedCount}</div>
          </div>
          <div className="p-2 bg-red-50 text-red-700 rounded-lg">
            <RotateCcw className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Active Examination
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Submission Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Submission States</option>
            <option value="Submitted">Submitted (Needs Review)</option>
            <option value="Verified">Verified & Finalized</option>
            <option value="Returned">Returned for Correction</option>
            <option value="Draft">Draft in Progress</option>
            <option value="Not Started">Not Started</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Paper / Faculty
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search subject, faculty name..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Schedules Verification List */}
      <div className="space-y-4">
        {filteredSchedules.map((sch) => {
          const paperMarks = allMarks.filter((m) => m.scheduleId === sch.id);
          const isExpanded = expandedScheduleId === sch.id;

          const totalEntered = paperMarks.filter((m) => m.marksObtained !== null).length;
          const passedCount = paperMarks.filter((m) => m.isPassed).length;
          const failedCount = paperMarks.filter(
            (m) => m.marksObtained !== null && !m.isPassed
          ).length;
          const absentCount = paperMarks.filter((m) => m.attendanceStatus === 'Absent').length;

          return (
            <div
              key={sch.id}
              className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs"
            >
              {/* Paper Summary Header */}
              <div className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#f8fafc] border-b border-[#e2e8f0]">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-[#1e293b]">
                      {sch.subjectName}
                    </span>
                    <span className="text-[10px] font-mono font-bold bg-blue-50 text-[#1e3a8a] px-2 py-0.5 rounded">
                      {sch.subjectCode}
                    </span>
                    <span className="text-xs text-[#64748b]">
                      • {sch.className} ({sch.section})
                    </span>
                  </div>
                  <div className="text-xs text-[#64748b] flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span>
                      Evaluator: <strong className="text-[#1e293b]">{sch.assignedFacultyName}</strong>
                    </span>
                    <span>•</span>
                    <span>Max Marks: <strong className="font-mono">{sch.maxMarks}</strong></span>
                    <span>•</span>
                    <span>Pass Marks: <strong className="font-mono">{sch.passMarks}</strong></span>
                  </div>
                </div>

                {/* Status and Action Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold uppercase ${
                      sch.markSubmissionStatus === 'Verified'
                        ? 'bg-emerald-100 text-emerald-800'
                        : sch.markSubmissionStatus === 'Submitted'
                        ? 'bg-blue-100 text-blue-800'
                        : sch.markSubmissionStatus === 'Returned'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-slate-100 text-[#64748b]'
                    }`}
                  >
                    {sch.markSubmissionStatus}
                  </span>

                  {sch.markSubmissionStatus === 'Submitted' && (
                    <>
                      <Button
                        size="sm"
                        onClick={() => handleVerify(sch.id)}
                        disabled={isVerifying}
                        className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs gap-1 py-1 px-3 h-auto"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Approve Marks</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onOpenReturnModal(sch)}
                        className="text-red-700 hover:bg-red-50 border-red-200 text-xs gap-1 py-1 px-3 h-auto"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Return...</span>
                      </Button>
                    </>
                  )}

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      setExpandedScheduleId(isExpanded ? null : sch.id)
                    }
                    className="text-xs gap-1 py-1 px-2.5 h-auto text-[#1e293b]"
                  >
                    <span>{isExpanded ? 'Hide Marks' : 'Review Marks'}</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </Button>
                </div>
              </div>

              {/* Stats Bar */}
              <div className="px-4 py-2 bg-slate-50 border-b border-[#e2e8f0] flex flex-wrap items-center gap-4 text-xs text-[#64748b]">
                <span>
                  Total Enrolled: <strong className="text-[#1e293b]">{paperMarks.length}</strong>
                </span>
                <span>•</span>
                <span>
                  Evaluated: <strong className="text-[#1e293b]">{totalEntered}</strong>
                </span>
                <span>•</span>
                <span className="text-emerald-700">
                  Passed: <strong className="font-mono">{passedCount}</strong>
                </span>
                <span>•</span>
                <span className="text-red-700">
                  Failed: <strong className="font-mono">{failedCount}</strong>
                </span>
                <span>•</span>
                <span>
                  Absent: <strong className="font-mono">{absentCount}</strong>
                </span>
              </div>

              {/* Expanded Student Marks Table */}
              {isExpanded && (
                <div className="p-4">
                  <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                        <tr>
                          <th className="py-2.5 px-3">Registration No</th>
                          <th className="py-2.5 px-3">Student Name</th>
                          <th className="py-2.5 px-3 text-center">Attendance</th>
                          <th className="py-2.5 px-3 text-right">Max Marks</th>
                          <th className="py-2.5 px-3 text-right">Marks Obtained</th>
                          <th className="py-2.5 px-3 text-center">Grade</th>
                          <th className="py-2.5 px-3 text-center">Outcome</th>
                          <th className="py-2.5 px-3">Faculty Remarks</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#e2e8f0]">
                        {paperMarks.map((entry) => (
                          <tr key={entry.id} className="hover:bg-slate-50">
                            <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">
                              {entry.studentRegistrationNumber}
                            </td>
                            <td className="py-2 px-3 font-medium text-[#1e293b]">
                              {entry.studentName}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                  entry.attendanceStatus === 'Present'
                                    ? 'bg-emerald-50 text-emerald-800'
                                    : 'bg-red-50 text-red-800'
                                }`}
                              >
                                {entry.attendanceStatus}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-right font-mono text-[#64748b]">
                              {entry.maxMarks}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-bold text-[#1e293b]">
                              {entry.attendanceStatus === 'Absent' ? (
                                <span className="text-red-600 font-bold">AB</span>
                              ) : entry.marksObtained !== null ? (
                                entry.marksObtained
                              ) : (
                                <span className="text-amber-600 italic">Pending</span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-center font-mono font-bold">
                              {entry.grade || '-'}
                            </td>
                            <td className="py-2 px-3 text-center font-bold">
                              {entry.isPassed ? (
                                <span className="text-emerald-700">Pass</span>
                              ) : (
                                <span className="text-red-700">Fail</span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-[#64748b] text-[11px]">
                              {entry.remarks || '-'}
                            </td>
                          </tr>
                        ))}
                        {paperMarks.length === 0 && (
                          <tr>
                            <td colSpan={8} className="py-6 text-center text-[#64748b]">
                              No student marks records entered yet for this paper.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {filteredSchedules.length === 0 && (
          <div className="p-8 text-center bg-white rounded-xl border border-[#cbd5e1] text-xs text-[#64748b]">
            No paper submissions found matching your filter criteria.
          </div>
        )}
      </div>
    </div>
  );
}
