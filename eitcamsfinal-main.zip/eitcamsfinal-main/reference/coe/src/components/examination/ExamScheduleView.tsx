import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Clock,
  MapPin,
  User,
  BookOpen,
  Download,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { Examination, ExamSubjectSchedule } from '../../types/examination';
import { AcademicClass } from '../../types/academic';
import { Button } from '../ui/Button';

interface ExamScheduleViewProps {
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  classes: AcademicClass[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenAddScheduleModal: () => void;
  onOpenEditScheduleModal: (schedule: ExamSubjectSchedule) => void;
  onDeleteSchedule: (id: string) => Promise<void>;
}

export function ExamScheduleView({
  examinations,
  schedules,
  classes,
  selectedExamId,
  onSelectExamId,
  onOpenAddScheduleModal,
  onOpenEditScheduleModal,
  onDeleteSchedule,
}: ExamScheduleViewProps) {
  const [classFilter, setClassFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSchedules = schedules.filter((sch) => {
    const matchesExam = !selectedExamId || selectedExamId === 'All' || sch.examinationId === selectedExamId;
    const matchesClass = classFilter === 'All' || sch.className === classFilter;
    const matchesSearch =
      sch.subjectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.subjectCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.assignedFacultyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.roomVenue.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesExam && matchesClass && matchesSearch;
  });

  const handleExportCSV = () => {
    const headers = [
      'Exam ID',
      'Class',
      'Section',
      'Subject Name',
      'Subject Code',
      'Max Marks',
      'Pass Marks',
      'Date',
      'Time',
      'Venue',
      'Assigned Faculty',
      'Mark Entry Status',
      'Submission Status',
    ];
    const rows = filteredSchedules.map((s) => [
      s.examinationId,
      s.className,
      s.section,
      `"${s.subjectName.replace(/"/g, '""')}"`,
      s.subjectCode,
      s.maxMarks,
      s.passMarks,
      s.examDate,
      `"${s.startTime} - ${s.endTime}"`,
      `"${s.roomVenue.replace(/"/g, '""')}"`,
      `"${s.assignedFacultyName.replace(/"/g, '""')}"`,
      s.markEntryStatus,
      s.markSubmissionStatus,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `exam_schedule_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Examination Timetable & Papers Schedule
          </h1>
          <p className="text-xs text-[#64748b]">
            Schedule subject examination slots, room venues, and assign faculty evaluators
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>Export Timetable</span>
          </Button>
          <Button size="sm" onClick={onOpenAddScheduleModal} className="text-xs gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            <span>Add Schedule Paper</span>
          </Button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Filter by Exam
          </label>
          <select
            value={selectedExamId || 'All'}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            <option value="All">All Examinations</option>
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Filter by Class
          </label>
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Classes</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.name}>
                {cls.name}
              </option>
            ))}
            {classes.length === 0 && (
              <>
                <option value="Class 8">Class 8</option>
                <option value="Class 9">Class 9</option>
                <option value="Class 10">Class 10</option>
                <option value="Class 11">Class 11</option>
                <option value="Class 12">Class 12</option>
              </>
            )}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Paper / Evaluator
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search subject, faculty, venue..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Schedule Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4">Exam & Class</th>
                <th className="py-3 px-4">Subject & Code</th>
                <th className="py-3 px-4">Marks (Max / Pass)</th>
                <th className="py-3 px-4">Date & Time Slot</th>
                <th className="py-3 px-4">Room / Venue</th>
                <th className="py-3 px-4">Assigned Evaluator</th>
                <th className="py-3 px-4 text-center">Mark Entry</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredSchedules.map((sch) => (
                <tr key={sch.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-bold text-[#1e293b]">{sch.className} ({sch.section})</div>
                    <div className="text-[10px] font-mono text-[#64748b]">{sch.examinationId}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#1e293b]">{sch.subjectName}</div>
                    <span className="text-[10px] font-mono bg-slate-100 text-[#475569] px-1.5 py-0.5 rounded">
                      {sch.subjectCode}
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-bold font-mono text-[#1e293b]">{sch.maxMarks}</span>
                    <span className="text-[#64748b] text-[11px]"> / min {sch.passMarks}</span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-bold text-[#1e293b] flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
                      {sch.examDate}
                    </div>
                    <div className="text-[11px] text-[#64748b] flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3" />
                      {sch.startTime} – {sch.endTime}
                    </div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-medium text-[#1e293b] flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#64748b]" />
                      {sch.roomVenue}
                    </div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-medium text-[#1e293b] flex items-center gap-1">
                      <User className="w-3.5 h-3.5 text-[#64748b]" />
                      {sch.assignedFacultyName}
                    </div>
                    <div className="text-[10px] font-mono text-[#64748b]">{sch.assignedFacultyId}</div>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        sch.markEntryStatus === 'Open'
                          ? 'bg-amber-100 text-amber-800'
                          : sch.markEntryStatus === 'Closed'
                          ? 'bg-slate-200 text-[#475569]'
                          : sch.markEntryStatus === 'Locked'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {sch.markEntryStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => onOpenEditScheduleModal(sch)}
                        className="p-1.5 text-[#64748b] hover:text-[#1e293b] rounded hover:bg-slate-100 transition-colors"
                        title="Edit Schedule Paper"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteSchedule(sch.id)}
                        className="p-1.5 text-red-500 hover:text-red-700 rounded hover:bg-red-50 transition-colors"
                        title="Delete Schedule"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredSchedules.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#64748b] text-xs">
                    No exam papers found matching your filter selection.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
