import React, { useState, useEffect } from 'react';
import { X, UserX, AlertCircle } from 'lucide-react';
import { StudentExamEligibility } from '../../types/examination';
import { Button } from '../ui/Button';

interface EligibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  eligibility: StudentExamEligibility | null;
  onSave: (examId: string, studentRegNo: string, isEligible: boolean, reason?: string) => Promise<void>;
}

export function EligibilityModal({
  isOpen,
  onClose,
  eligibility,
  onSave,
}: EligibilityModalProps) {
  const [isEligible, setIsEligible] = useState(true);
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (eligibility) {
      setIsEligible(eligibility.isEligible);
      setReason(eligibility.ineligibilityReason || '');
    }
    setError(null);
  }, [eligibility, isOpen]);

  if (!isOpen || !eligibility) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEligible && !reason.trim()) {
      setError('Please provide a specific justification when marking a student as Ineligible.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onSave(
        eligibility.examinationId,
        eligibility.studentRegistrationNumber,
        isEligible,
        isEligible ? undefined : reason.trim()
      );
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update student eligibility.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-xl border border-[#cbd5e1] w-full max-w-md overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#eff6ff] text-[#1e3a8a] rounded-lg">
              <UserX className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">Student Exam Eligibility</h2>
              <p className="text-xs text-[#64748b]">{eligibility.studentName} ({eligibility.studentRegistrationNumber})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-2">
              Eligibility Status
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setIsEligible(true)}
                className={`py-2.5 px-3 rounded-lg border text-xs font-bold transition-all ${
                  isEligible
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                    : 'border-[#cbd5e1] bg-white text-[#64748b] hover:bg-slate-50'
                }`}
              >
                Eligible for Exam
              </button>
              <button
                type="button"
                onClick={() => setIsEligible(false)}
                className={`py-2.5 px-3 rounded-lg border text-xs font-bold transition-all ${
                  !isEligible
                    ? 'border-red-600 bg-red-50 text-red-800'
                    : 'border-[#cbd5e1] bg-white text-[#64748b] hover:bg-slate-50'
                }`}
              >
                Ineligible / Excluded
              </button>
            </div>
          </div>

          {!isEligible && (
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Reason for Ineligibility <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Attendance below mandatory 75% threshold, fee dues clearance pending..."
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : 'Save Eligibility'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
