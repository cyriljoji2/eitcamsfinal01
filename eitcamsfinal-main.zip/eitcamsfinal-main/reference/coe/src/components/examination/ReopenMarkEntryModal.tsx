import React, { useState } from 'react';
import { X, Unlock, AlertTriangle } from 'lucide-react';
import { ExamSubjectSchedule } from '../../types/examination';
import { Button } from '../ui/Button';

interface ReopenMarkEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  schedule: ExamSubjectSchedule | null;
  onConfirmReopen: (scheduleId: string, reason: string) => Promise<void>;
  currentUserName: string;
}

export function ReopenMarkEntryModal({
  isOpen,
  onClose,
  schedule,
  onConfirmReopen,
  currentUserName,
}: ReopenMarkEntryModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !schedule) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('A specific, auditable reason is required to unlock and reopen mark entry.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmReopen(schedule.id, reason.trim());
      setReason('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to reopen mark entry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-xl border border-amber-200 w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-amber-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-100 text-amber-800 rounded-lg">
              <Unlock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">Reopen Mark Entry Window</h2>
              <p className="text-xs text-amber-800 font-medium">Explicit Controlled COE Override</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-amber-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>Audit Logging Notice</span>
            </div>
            <p>
              Reopening this window will permit assigned faculty{' '}
              <strong>{schedule.assignedFacultyName}</strong> to modify marks for{' '}
              <strong>
                {schedule.subjectName} ({schedule.className} - {schedule.section})
              </strong>
              . This action will be logged in the permanent audit trail.
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-1">
              Reason for Reopening <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Faculty requested correction for student REG20260002 question 4 re-evaluation..."
              className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
              required
            />
            <p className="text-[10px] text-[#64748b] mt-1">
              Authorized by: <strong>{currentUserName}</strong>
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-amber-600 hover:bg-amber-700 text-white border-amber-700"
            >
              {isSubmitting ? 'Reopening...' : 'Confirm Reopen'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
