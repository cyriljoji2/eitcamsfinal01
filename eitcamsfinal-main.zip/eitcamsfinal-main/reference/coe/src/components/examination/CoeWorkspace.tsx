import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Layers,
  FileCheck,
  CheckCircle2,
  Lock,
  Unlock,
  Printer,
  Award,
  Users,
  BarChart3,
  LogOut,
  ShieldCheck,
  Menu,
  X,
  FileText,
} from 'lucide-react';
import { User as AuthUser } from '../../types/auth';
import {
  Examination,
  ExamSubjectSchedule,
  StudentMarkEntry,
  StudentExamResult,
  HallTicket,
  StudentExamEligibility,
  ExamAuditLog,
  ExamStatus,
} from '../../types/examination';
import { AcademicClass, AcademicSection, AcademicSubject, FacultyAssignment } from '../../types/academic';
import { Employee } from '../../types/employee';
import { examinationRepository } from '../../services/examinationService';
import { academicRepository } from '../../services/academicService';
import { admissionRepository } from '../../services/admissionService';
import { employeeRepository } from '../../services/employeeService';

// Sub views
import { CoeOverview } from './CoeOverview';
import { ExamManagementView } from './ExamManagementView';
import { ExamScheduleView } from './ExamScheduleView';
import { StudentEligibilityView } from './StudentEligibilityView';
import { MarkEntryControlView } from './MarkEntryControlView';
import { MarksVerificationView } from './MarksVerificationView';
import { ResultsView } from './ResultsView';
import { HallTicketView } from './HallTicketView';
import { ExamReportsView } from './ExamReportsView';

// Modals
import { ExamFormModal } from './ExamFormModal';
import { ExamScheduleModal } from './ExamScheduleModal';
import { ReopenMarkEntryModal } from './ReopenMarkEntryModal';
import { ReturnMarksModal } from './ReturnMarksModal';
import { EligibilityModal } from './EligibilityModal';
import { HallTicketPrintModal } from './HallTicketPrintModal';
import { ResultTranscriptModal } from './ResultTranscriptModal';
import { Button } from '../ui/Button';

interface CoeWorkspaceProps {
  currentUser: AuthUser;
  onLogout: () => void;
}

export function CoeWorkspace({ currentUser, onLogout }: CoeWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Data states
  const [examinations, setExaminations] = useState<Examination[]>([]);
  const [schedules, setSchedules] = useState<ExamSubjectSchedule[]>([]);
  const [allMarks, setAllMarks] = useState<StudentMarkEntry[]>([]);
  const [results, setResults] = useState<StudentExamResult[]>([]);
  const [hallTickets, setHallTickets] = useState<HallTicket[]>([]);
  const [eligibilities, setEligibilities] = useState<StudentExamEligibility[]>([]);
  const [auditLogs, setAuditLogs] = useState<ExamAuditLog[]>([]);

  // Master academic / employee states
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyAssignment[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);

  // Selected Exam Filter
  const [selectedExamId, setSelectedExamId] = useState<string>('');

  // Modal States
  const [examModalOpen, setExamModalOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<Examination | null>(null);

  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<ExamSubjectSchedule | null>(null);

  const [reopenModalOpen, setReopenModalOpen] = useState(false);
  const [reopenTargetSchedule, setReopenTargetSchedule] = useState<ExamSubjectSchedule | null>(null);

  const [returnModalOpen, setReturnModalOpen] = useState(false);
  const [returnTargetSchedule, setReturnTargetSchedule] = useState<ExamSubjectSchedule | null>(null);

  const [eligibilityModalOpen, setEligibilityModalOpen] = useState(false);
  const [targetEligibility, setTargetEligibility] = useState<StudentExamEligibility | null>(null);

  const [hallTicketPrintModalOpen, setHallTicketPrintModalOpen] = useState(false);
  const [targetHallTicket, setTargetHallTicket] = useState<HallTicket | null>(null);

  const [transcriptModalOpen, setTranscriptModalOpen] = useState(false);
  const [targetResult, setTargetResult] = useState<StudentExamResult | null>(null);

  const isCoeUser = currentUser.role === 'examination' || currentUser.role === 'super_admin';

  const refreshAllData = async () => {
    try {
      const [
        examsData,
        schedulesData,
        marksData,
        resultsData,
        ticketsData,
        eligData,
        logsData,
        classesData,
        sectionsData,
        subjectsData,
        asgData,
        empData,
      ] = await Promise.all([
        examinationRepository.getExaminations(),
        examinationRepository.getSchedules(),
        examinationRepository.getAllMarks(),
        examinationRepository.getResults(),
        examinationRepository.getHallTickets(),
        examinationRepository.getEligibilities(),
        examinationRepository.getAuditLogs(),
        academicRepository.getClasses(),
        academicRepository.getSections(),
        academicRepository.getSubjects(),
        academicRepository.getFacultyAssignments(),
        employeeRepository.getEmployees(),
      ]);

      setExaminations(examsData);
      setSchedules(schedulesData);
      setAllMarks(marksData);
      setResults(resultsData);
      setHallTickets(ticketsData);
      setEligibilities(eligData);
      setAuditLogs(logsData);

      setClasses(classesData);
      setSections(sectionsData);
      setSubjects(subjectsData);
      setFacultyAssignments(asgData);
      setEmployees(empData);

      if (!selectedExamId && examsData.length > 0) {
        setSelectedExamId(examsData[0].id);
      }
    } catch (err) {
      console.error('Error refreshing COE data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Exam actions
  const handleSaveExam = async (data: Omit<Examination, 'createdAt' | 'updatedAt'>) => {
    if (editingExam) {
      await examinationRepository.updateExamination(editingExam.id, data);
    } else {
      await examinationRepository.createExamination(data);
    }
    await refreshAllData();
  };

  const handleUpdateExamStatus = async (examId: string, status: ExamStatus) => {
    await examinationRepository.updateExamination(examId, {
      status,
      updatedBy: currentUser.name,
    });
    await refreshAllData();
  };

  // Schedule actions
  const handleSaveSchedule = async (
    data: Omit<ExamSubjectSchedule, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    if (editingSchedule) {
      await examinationRepository.updateSchedule(editingSchedule.id, data);
    } else {
      await examinationRepository.createSchedule(data);
    }
    await refreshAllData();
  };

  const handleDeleteSchedule = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this exam schedule paper?')) {
      await examinationRepository.deleteSchedule(id);
      await refreshAllData();
    }
  };

  // Window control actions
  const handleOpenWindow = async (scheduleId: string) => {
    await examinationRepository.openMarkEntry(scheduleId, currentUser.id);
    await refreshAllData();
  };

  const handleCloseWindow = async (scheduleId: string) => {
    await examinationRepository.closeMarkEntry(scheduleId, currentUser.id);
    await refreshAllData();
  };

  const handleConfirmReopen = async (scheduleId: string, reason: string) => {
    await examinationRepository.reopenMarkEntry(scheduleId, reason, currentUser.name);
    await refreshAllData();
  };

  const handleBulkOpenWindows = async (examId: string) => {
    await examinationRepository.bulkOpenMarkEntry(examId, currentUser.id);
    await refreshAllData();
  };

  const handleBulkCloseWindows = async (examId: string) => {
    await examinationRepository.bulkCloseMarkEntry(examId, currentUser.id);
    await refreshAllData();
  };

  // Verification actions
  const handleVerifyMarks = async (scheduleId: string, notes?: string) => {
    await examinationRepository.verifyMarks(scheduleId, currentUser.name, notes);
    await refreshAllData();
  };

  const handleConfirmReturn = async (scheduleId: string, reason: string) => {
    await examinationRepository.returnMarksForCorrection(scheduleId, reason, currentUser.name);
    await refreshAllData();
  };

  // Eligibility actions
  const handleSyncEligibility = async (examId: string) => {
    const students = await admissionRepository.getStudents();
    await examinationRepository.syncEligibilityFromAdmission(
      examId,
      students.map((s) => ({
        registrationNumber: s.registrationNumber,
        studentName: s.fullName,
        className: s.admissionClass,
        section: s.section,
        fatherName: s.fatherName,
        motherName: s.motherName,
        dateOfBirth: s.dateOfBirth,
        status: s.admissionStatus,
      }))
    );
    await refreshAllData();
  };

  const handleUpdateEligibility = async (
    examId: string,
    studentRegNo: string,
    isEligible: boolean,
    reason?: string
  ) => {
    await examinationRepository.updateStudentEligibility(
      examId,
      studentRegNo,
      isEligible,
      reason,
      currentUser.name
    );
    await refreshAllData();
  };

  const handleBulkSetEligible = async (examId: string, className?: string) => {
    await examinationRepository.bulkSetEligibility(examId, true, className);
    await refreshAllData();
  };

  // Results calculation and publication
  const handleCalculateResults = async (examId: string) => {
    await examinationRepository.calculateResultsForExam(examId);
    await refreshAllData();
  };

  const handlePublishResults = async (examId: string) => {
    await examinationRepository.publishResults(examId, currentUser.name);
    await refreshAllData();
  };

  // Hall tickets actions
  const handleGenerateIndividualHallTicket = async (examId: string, regNo: string) => {
    const ticket = await examinationRepository.generateHallTicket(examId, regNo);
    await refreshAllData();
    return ticket;
  };

  const handleGenerateClassBatchHallTickets = async (examId: string, className: string) => {
    const batch = await examinationRepository.generateClassHallTickets(examId, className);
    await refreshAllData();
    return batch;
  };

  const handleGenerateExamBulkHallTickets = async (examId: string) => {
    const batch = await examinationRepository.generateAllHallTicketsForExam(examId);
    await refreshAllData();
    return batch;
  };

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'exams', label: 'Examinations', icon: Calendar },
    { id: 'schedule', label: 'Timetable & Papers', icon: Layers },
    { id: 'eligibility', label: 'Eligibility Registry', icon: Users },
    { id: 'mark-control', label: 'Mark Entry Control', icon: Lock },
    { id: 'verification', label: 'Marks Verification', icon: FileCheck },
    { id: 'results', label: 'Results & Publishing', icon: Award },
    { id: 'hall-tickets', label: 'Hall Tickets', icon: Printer },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Top Application Bar */}
      <header className="bg-white border-b border-[#cbd5e1] sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-[#64748b] hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-black text-base shadow-xs">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="font-black text-[#1e3a8a] text-base tracking-tight block leading-tight">
                  Examination Cell Portal
                </span>
                <span className="text-[10px] font-bold text-[#64748b] tracking-wider uppercase">
                  Electrix Institute of Technology (EIT)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-bold text-[#1e293b]">{currentUser.name}</span>
              <span className="text-[10px] text-[#64748b] uppercase font-bold tracking-wider">
                {currentUser.role === 'examination' ? 'Controller of Examinations / Examination Cell' : currentUser.role}
              </span>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={onLogout}
              className="text-xs gap-1 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6">
        {/* Navigation Sidebar (Desktop) */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="bg-white rounded-xl border border-[#cbd5e1] p-3 shadow-2xs sticky top-24 space-y-1">
            <div className="px-3 py-2 text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider">
              Examination Modules
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-bold transition-colors ${
                    isActive
                      ? 'bg-[#1e3a8a] text-white shadow-xs'
                      : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#64748b]'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs flex">
            <div className="w-64 bg-white h-full p-4 space-y-2 shadow-xl">
              <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
                <span className="text-xs font-bold text-[#1e3a8a] uppercase">Navigation</span>
                <button onClick={() => setMobileMenuOpen(false)}>
                  <X className="w-5 h-5 text-[#64748b]" />
                </button>
              </div>
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-bold ${
                      isActive ? 'bg-[#1e3a8a] text-white' : 'text-[#475569] hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
            <div className="flex-1" onClick={() => setMobileMenuOpen(false)} />
          </div>
        )}

        {/* Content Area */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="p-12 text-center text-xs text-[#64748b]">
              Loading Examination Workspace...
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <CoeOverview
                  examinations={examinations}
                  schedules={schedules}
                  results={results}
                  hallTickets={hallTickets}
                  auditLogs={auditLogs}
                  onNavigateTab={(tab) => setActiveTab(tab)}
                  onOpenCreateExamModal={() => {
                    setEditingExam(null);
                    setExamModalOpen(true);
                  }}
                />
              )}

              {activeTab === 'exams' && (
                <ExamManagementView
                  examinations={examinations}
                  onOpenCreateModal={() => {
                    setEditingExam(null);
                    setExamModalOpen(true);
                  }}
                  onOpenEditModal={(exam) => {
                    setEditingExam(exam);
                    setExamModalOpen(true);
                  }}
                  onUpdateStatus={handleUpdateExamStatus}
                  onViewSchedule={(examId) => {
                    setSelectedExamId(examId);
                    setActiveTab('schedule');
                  }}
                />
              )}

              {activeTab === 'schedule' && (
                <ExamScheduleView
                  examinations={examinations}
                  schedules={schedules}
                  classes={classes}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onOpenAddScheduleModal={() => {
                    setEditingSchedule(null);
                    setScheduleModalOpen(true);
                  }}
                  onOpenEditScheduleModal={(sch) => {
                    setEditingSchedule(sch);
                    setScheduleModalOpen(true);
                  }}
                  onDeleteSchedule={handleDeleteSchedule}
                />
              )}

              {activeTab === 'eligibility' && (
                <StudentEligibilityView
                  examinations={examinations}
                  eligibilities={eligibilities}
                  classes={classes}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onOpenEligibilityModal={(el) => {
                    setTargetEligibility(el);
                    setEligibilityModalOpen(true);
                  }}
                  onSyncEligibility={handleSyncEligibility}
                  onBulkSetEligible={handleBulkSetEligible}
                />
              )}

              {activeTab === 'mark-control' && (
                <MarkEntryControlView
                  examinations={examinations}
                  schedules={schedules}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onOpenWindow={handleOpenWindow}
                  onCloseWindow={handleCloseWindow}
                  onOpenReopenModal={(sch) => {
                    setReopenTargetSchedule(sch);
                    setReopenModalOpen(true);
                  }}
                  onBulkOpenWindows={handleBulkOpenWindows}
                  onBulkCloseWindows={handleBulkCloseWindows}
                />
              )}

              {activeTab === 'verification' && (
                <MarksVerificationView
                  examinations={examinations}
                  schedules={schedules}
                  allMarks={allMarks}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onVerifyMarks={handleVerifyMarks}
                  onOpenReturnModal={(sch) => {
                    setReturnTargetSchedule(sch);
                    setReturnModalOpen(true);
                  }}
                />
              )}

              {activeTab === 'results' && (
                <ResultsView
                  examinations={examinations}
                  results={results}
                  schedules={schedules}
                  classes={classes}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onCalculateResults={handleCalculateResults}
                  onPublishResults={handlePublishResults}
                  onOpenTranscriptModal={(res) => {
                    setTargetResult(res);
                    setTranscriptModalOpen(true);
                  }}
                  isCoeUser={isCoeUser}
                />
              )}

              {activeTab === 'hall-tickets' && (
                <HallTicketView
                  examinations={examinations}
                  hallTickets={hallTickets}
                  schedules={schedules}
                  eligibilities={eligibilities}
                  classes={classes}
                  selectedExamId={selectedExamId}
                  onSelectExamId={setSelectedExamId}
                  onGenerateIndividual={handleGenerateIndividualHallTicket}
                  onGenerateClassBatch={handleGenerateClassBatchHallTickets}
                  onGenerateExamBulk={handleGenerateExamBulkHallTickets}
                  onOpenPrintModal={(ticket) => {
                    setTargetHallTicket(ticket);
                    setHallTicketPrintModalOpen(true);
                  }}
                />
              )}

              {activeTab === 'reports' && (
                <ExamReportsView
                  examinations={examinations}
                  schedules={schedules}
                  results={results}
                  hallTickets={hallTickets}
                  eligibilities={eligibilities}
                  classes={classes}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Global Examination Modals */}
      <ExamFormModal
        isOpen={examModalOpen}
        onClose={() => {
          setExamModalOpen(false);
          setEditingExam(null);
        }}
        onSubmit={handleSaveExam}
        initialData={editingExam}
        currentAcademicSession="2026-27"
        currentUserName={currentUser.name}
      />

      <ExamScheduleModal
        isOpen={scheduleModalOpen}
        onClose={() => {
          setScheduleModalOpen(false);
          setEditingSchedule(null);
        }}
        onSubmit={handleSaveSchedule}
        initialData={editingSchedule}
        examinations={examinations}
        classes={classes}
        sections={sections}
        subjects={subjects}
        facultyAssignments={facultyAssignments}
        employees={employees}
        defaultExamId={selectedExamId}
      />

      <ReopenMarkEntryModal
        isOpen={reopenModalOpen}
        onClose={() => {
          setReopenModalOpen(false);
          setReopenTargetSchedule(null);
        }}
        schedule={reopenTargetSchedule}
        onConfirmReopen={handleConfirmReopen}
        currentUserName={currentUser.name}
      />

      <ReturnMarksModal
        isOpen={returnModalOpen}
        onClose={() => {
          setReturnModalOpen(false);
          setReturnTargetSchedule(null);
        }}
        schedule={returnTargetSchedule}
        onConfirmReturn={handleConfirmReturn}
        currentUserName={currentUser.name}
      />

      <EligibilityModal
        isOpen={eligibilityModalOpen}
        onClose={() => {
          setEligibilityModalOpen(false);
          setTargetEligibility(null);
        }}
        eligibility={targetEligibility}
        onSave={handleUpdateEligibility}
      />

      <HallTicketPrintModal
        isOpen={hallTicketPrintModalOpen}
        onClose={() => {
          setHallTicketPrintModalOpen(false);
          setTargetHallTicket(null);
        }}
        hallTicket={targetHallTicket}
      />

      <ResultTranscriptModal
        isOpen={transcriptModalOpen}
        onClose={() => {
          setTranscriptModalOpen(false);
          setTargetResult(null);
        }}
        result={targetResult}
      />
    </div>
  );
}
