import React from 'react';
import {
  FileText,
  Calendar,
  Lock,
  Unlock,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  Award,
  Users,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';
import {
  Examination,
  ExamSubjectSchedule,
  StudentExamResult,
  HallTicket,
  ExamAuditLog,
} from '../../types/examination';
import { Button } from '../ui/Button';

interface CoeOverviewProps {
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  results: StudentExamResult[];
  hallTickets: HallTicket[];
  auditLogs: ExamAuditLog[];
  onNavigateTab: (tab: string) => void;
  onOpenCreateExamModal: () => void;
}

export function CoeOverview({
  examinations,
  schedules,
  results,
  hallTickets,
  auditLogs,
  onNavigateTab,
  onOpenCreateExamModal,
}: CoeOverviewProps) {
  const activeExams = examinations.filter(
    (e) => e.status === 'Active' || e.status === 'Mark Entry Open' || e.status === 'Verification'
  );
  const markEntryOpenPapers = schedules.filter((s) => s.markEntryStatus === 'Open');
  const submittedPapers = schedules.filter((s) => s.markSubmissionStatus === 'Submitted');
  const verifiedPapers = schedules.filter((s) => s.markSubmissionStatus === 'Verified');
  const publishedExams = examinations.filter((e) => e.status === 'Published');

  const totalPapers = schedules.length;
  const completionRate =
    totalPapers > 0 ? Math.round((verifiedPapers.length / totalPapers) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Actions Banner */}
      <div className="bg-gradient-to-r from-[#1e3a8a] to-[#1e293b] rounded-xl p-6 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 text-xs font-semibold text-blue-200 mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
            Controller of Examination Authority Workspace
          </div>
          <h1 className="text-xl font-black tracking-tight">Examination Administration & Evaluation Control</h1>
          <p className="text-xs text-blue-100 mt-1 max-w-2xl">
            Authoritative hub for examination creation, schedule planning, mark entry window management, verification approval, hall tickets, and official result publication.
          </p>
        </div>
        <div className="flex items-center gap-2.5 shrink-0">
          <Button
            onClick={onOpenCreateExamModal}
            className="bg-white text-[#1e3a8a] hover:bg-blue-50 font-bold text-xs shadow-sm"
          >
            Create New Exam
          </Button>
          <Button
            variant="outline"
            onClick={() => onNavigateTab('results')}
            className="border-white/30 text-white hover:bg-white/10 text-xs"
          >
            Publish Results
          </Button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigateTab('exams')}
          className="bg-white p-4 rounded-xl border border-[#cbd5e1] hover:border-[#1e3a8a] transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-bold uppercase">Active Exams</span>
            <div className="p-2 bg-blue-50 text-[#1e3a8a] rounded-lg">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-[#1e293b]">{activeExams.length}</div>
          <div className="text-[11px] text-[#64748b] mt-1 flex items-center gap-1">
            <span>{examinations.length} total examinations</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('mark-control')}
          className="bg-white p-4 rounded-xl border border-[#cbd5e1] hover:border-amber-600 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-bold uppercase">Mark Entry Open</span>
            <div className="p-2 bg-amber-50 text-amber-700 rounded-lg">
              <Unlock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-700">{markEntryOpenPapers.length}</div>
          <div className="text-[11px] text-[#64748b] mt-1 flex items-center gap-1">
            <span>{schedules.filter((s) => s.markEntryStatus === 'Closed').length} windows locked</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('verification')}
          className="bg-white p-4 rounded-xl border border-[#cbd5e1] hover:border-emerald-600 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-bold uppercase">Awaiting Verification</span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700">{submittedPapers.length}</div>
          <div className="text-[11px] text-[#64748b] mt-1 flex items-center gap-1">
            <span>{verifiedPapers.length} papers approved</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('hall-tickets')}
          className="bg-white p-4 rounded-xl border border-[#cbd5e1] hover:border-indigo-600 transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center justify-between text-[#64748b] mb-2">
            <span className="text-xs font-bold uppercase">Hall Tickets</span>
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
              <Printer className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-[#1e293b]">{hallTickets.length}</div>
          <div className="text-[11px] text-[#64748b] mt-1 flex items-center gap-1">
            <span>Admit cards generated</span>
          </div>
        </div>
      </div>

      {/* Progress and Active Examinations Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Examination Pipelines */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-[#cbd5e1] p-5 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#1e293b]">Active Examinations Pipeline</h2>
              <p className="text-xs text-[#64748b]">Real-time status of scheduled assessments</p>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('exams')}
              className="text-xs gap-1"
            >
              <span>View All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          </div>

          <div className="space-y-3">
            {examinations.slice(0, 4).map((exam) => {
              const examSchedules = schedules.filter((s) => s.examinationId === exam.id);
              const openCount = examSchedules.filter((s) => s.markEntryStatus === 'Open').length;
              const verifiedCount = examSchedules.filter(
                (s) => s.markSubmissionStatus === 'Verified'
              ).length;
              const total = examSchedules.length;
              const percent = total > 0 ? Math.round((verifiedCount / total) * 100) : 0;

              return (
                <div
                  key={exam.id}
                  className="p-3.5 rounded-lg border border-[#e2e8f0] bg-slate-50/50 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#1e293b]">{exam.name}</span>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a]">
                          {exam.id}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#64748b] mt-0.5">
                        {exam.termType} • Session: {exam.academicSession} • {exam.startDate} to{' '}
                        {exam.endDate}
                      </div>
                    </div>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                        exam.status === 'Published'
                          ? 'bg-emerald-100 text-emerald-800'
                          : exam.status === 'Mark Entry Open'
                          ? 'bg-amber-100 text-amber-800'
                          : exam.status === 'Active'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-200 text-[#475569]'
                      }`}
                    >
                      {exam.status}
                    </span>
                  </div>

                  {/* Papers progress bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-[#64748b]">
                      <span>
                        Evaluation: {verifiedCount}/{total} papers verified ({openCount} open)
                      </span>
                      <span className="font-bold font-mono">{percent}%</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-[#1e3a8a] h-full rounded-full transition-all"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Audit & System Activity */}
        <div className="bg-white rounded-xl border border-[#cbd5e1] p-5 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#1e293b]">COE Audit Trail</h2>
              <p className="text-xs text-[#64748b]">Immutable event logging</p>
            </div>
            <div className="p-1 bg-slate-100 text-[#64748b] rounded">
              <Clock className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
            {auditLogs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="text-xs border-l-2 border-[#1e3a8a] pl-3 py-1 space-y-0.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1e293b]">{log.action}</span>
                  <span className="text-[10px] text-[#94a3b8]">
                    {new Date(log.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-[11px] text-[#64748b] leading-tight">{log.details}</p>
                <div className="text-[10px] text-[#94a3b8]">
                  By: <strong className="text-[#475569]">{log.performedByName || log.performedBy}</strong>
                </div>
              </div>
            ))}
            {auditLogs.length === 0 && (
              <div className="text-center py-8 text-xs text-[#64748b]">
                No recent activity logged.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
