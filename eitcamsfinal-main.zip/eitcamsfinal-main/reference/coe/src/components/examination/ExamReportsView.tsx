import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  CheckCircle2,
  Lock,
  Award,
  Users,
  Printer,
  BarChart3,
  Search,
} from 'lucide-react';
import {
  Examination,
  ExamSubjectSchedule,
  StudentExamResult,
  HallTicket,
  StudentExamEligibility,
} from '../../types/examination';
import { AcademicClass } from '../../types/academic';
import { Button } from '../ui/Button';

interface ExamReportsViewProps {
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  results: StudentExamResult[];
  hallTickets: HallTicket[];
  eligibilities: StudentExamEligibility[];
  classes: AcademicClass[];
}

export function ExamReportsView({
  examinations,
  schedules,
  results,
  hallTickets,
  eligibilities,
  classes,
}: ExamReportsViewProps) {
  const [selectedExamId, setSelectedExamId] = useState<string>(examinations[0]?.id || '');
  const [reportType, setReportType] = useState<
    'schedule' | 'mark_completion' | 'results_tabulation' | 'class_summary' | 'hall_tickets'
  >('results_tabulation');

  const activeExam = examinations.find((e) => e.id === selectedExamId);
  const examSchedules = schedules.filter((s) => s.examinationId === selectedExamId);
  const examResults = results.filter((r) => r.examinationId === selectedExamId);
  const examTickets = hallTickets.filter((t) => t.examinationId === selectedExamId);

  // Compute Class performance stats for Class Summary report
  const classStats = classes.map((cls) => {
    const classResults = examResults.filter((r) => r.className === cls.name);
    const total = classResults.length;
    const passed = classResults.filter((r) => r.resultStatus === 'Pass').length;
    const failed = total - passed;
    const avgScore =
      total > 0
        ? (
            classResults.reduce((acc, r) => acc + r.percentage, 0) / total
          ).toFixed(2)
        : '0.00';
    const passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : '0.0';

    return {
      className: cls.name,
      totalStudents: total,
      passed,
      failed,
      avgScore,
      passRate,
    };
  });

  const exportCurrentReportCSV = () => {
    let headers: string[] = [];
    let rows: any[][] = [];
    let filename = `report_${reportType}_${selectedExamId}.csv`;

    if (reportType === 'schedule') {
      headers = [
        'Class',
        'Section',
        'Subject Name',
        'Subject Code',
        'Max Marks',
        'Pass Marks',
        'Date',
        'Time Slot',
        'Venue',
        'Evaluator',
      ];
      rows = examSchedules.map((s) => [
        s.className,
        s.section,
        `"${s.subjectName.replace(/"/g, '""')}"`,
        s.subjectCode,
        s.maxMarks,
        s.passMarks,
        s.examDate,
        `"${s.startTime} - ${s.endTime}"`,
        `"${s.roomVenue.replace(/"/g, '""')}"`,
        `"${s.assignedFacultyName.replace(/"/g, '""')}"`,
      ]);
    } else if (reportType === 'mark_completion') {
      headers = [
        'Subject',
        'Code',
        'Class',
        'Section',
        'Evaluator',
        'Window Status',
        'Submission Status',
        'Verified By',
        'Verified At',
      ];
      rows = examSchedules.map((s) => [
        `"${s.subjectName.replace(/"/g, '""')}"`,
        s.subjectCode,
        s.className,
        s.section,
        `"${s.assignedFacultyName.replace(/"/g, '""')}"`,
        s.markEntryStatus,
        s.markSubmissionStatus,
        s.verifiedBy || '-',
        s.verifiedAt || '-',
      ]);
    } else if (reportType === 'results_tabulation') {
      headers = [
        'Rank',
        'Registration No',
        'Student Name',
        'Class',
        'Section',
        'Total Marks Obtained',
        'Max Marks',
        'Percentage',
        'Overall Grade',
        'Result Status',
      ];
      rows = examResults.map((r) => [
        r.classRank || '-',
        r.studentRegistrationNumber,
        `"${r.studentName.replace(/"/g, '""')}"`,
        r.className,
        r.section,
        r.totalMarksObtained,
        r.totalMaxMarks,
        r.percentage.toFixed(2),
        r.overallGrade,
        r.resultStatus,
      ]);
    } else if (reportType === 'class_summary') {
      headers = ['Class Name', 'Total Enrolled', 'Passed', 'Failed', 'Average Score %', 'Pass Rate %'];
      rows = classStats.map((c) => [
        c.className,
        c.totalStudents,
        c.passed,
        c.failed,
        c.avgScore,
        c.passRate,
      ]);
    } else if (reportType === 'hall_tickets') {
      headers = [
        'Hall Ticket No',
        'Registration No',
        'Student Name',
        'Class',
        'Section',
        'Issue Date',
      ];
      rows = examTickets.map((t) => [
        t.hallTicketNumber,
        t.studentRegistrationNumber,
        `"${t.studentName.replace(/"/g, '""')}"`,
        t.className,
        t.section,
        t.generatedAt,
      ]);
    }

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Institutional Examination Analytics & Reports
          </h1>
          <p className="text-xs text-[#64748b]">
            Generate official examination registers, mark completion statements, and grade distribution summaries
          </p>
        </div>
        <Button size="sm" onClick={exportCurrentReportCSV} className="text-xs gap-1.5 bg-[#1e3a8a]">
          <Download className="w-3.5 h-3.5" />
          <span>Export Current Report CSV</span>
        </Button>
      </div>

      {/* Selectors */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-2 gap-4 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Target Examination
          </label>
          <select
            value={selectedExamId}
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id}) — [{ex.status}]
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Report Type
          </label>
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value as any)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            <option value="results_tabulation">Official Results Tabulation Register</option>
            <option value="class_summary">Class Performance & Pass Rate Summary</option>
            <option value="mark_completion">Faculty Mark Entry & Verification Status</option>
            <option value="schedule">Complete Examination Schedule Timetable</option>
            <option value="hall_tickets">Issued Hall Tickets & Admit Cards Register</option>
          </select>
        </div>
      </div>

      {/* Report Table Display */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="px-5 py-3.5 bg-[#f8fafc] border-b border-[#cbd5e1] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-[#1e3a8a]" />
            <span className="text-xs font-bold text-[#1e293b]">
              {reportType === 'results_tabulation' && 'Official Student Marks & Results Tabulation Register'}
              {reportType === 'class_summary' && 'Class Performance & Pass Percentage Distribution'}
              {reportType === 'mark_completion' && 'Faculty Evaluation Completion & Verification Audit'}
              {reportType === 'schedule' && 'Examination Papers Timetable & Venue Schedule'}
              {reportType === 'hall_tickets' && 'Issued Hall Tickets & Admit Cards Registry'}
            </span>
          </div>
          <span className="text-[10px] font-mono font-bold text-[#64748b]">
            Exam: {selectedExamId}
          </span>
        </div>

        <div className="overflow-x-auto">
          {reportType === 'results_tabulation' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3 text-center">Rank</th>
                  <th className="py-2.5 px-3">Reg No</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Class</th>
                  <th className="py-2.5 px-3 text-right">Marks</th>
                  <th className="py-2.5 px-3 text-right">Percentage</th>
                  <th className="py-2.5 px-3 text-center">Grade</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {examResults.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 text-center font-mono font-bold text-[#64748b]">
                      {r.classRank ? `#${r.classRank}` : '-'}
                    </td>
                    <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">{r.studentRegistrationNumber}</td>
                    <td className="py-2 px-3 font-medium text-[#1e293b]">{r.studentName}</td>
                    <td className="py-2 px-3 text-[#64748b]">{r.className} ({r.section})</td>
                    <td className="py-2 px-3 text-right font-mono font-bold">
                      {r.totalMarksObtained} / {r.totalMaxMarks}
                    </td>
                    <td className="py-2 px-3 text-right font-mono text-[#1e3a8a] font-bold">
                      {r.percentage.toFixed(2)}%
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold">{r.overallGrade}</td>
                    <td className="py-2 px-3 text-center font-bold">
                      <span className={r.resultStatus === 'Pass' ? 'text-emerald-700' : 'text-red-700'}>
                        {r.resultStatus}
                      </span>
                    </td>
                  </tr>
                ))}
                {examResults.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-6 text-center text-[#64748b]">
                      No results computed for this examination yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}

          {reportType === 'class_summary' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3">Class Name</th>
                  <th className="py-2.5 px-3 text-right">Total Evaluated</th>
                  <th className="py-2.5 px-3 text-right">Passed</th>
                  <th className="py-2.5 px-3 text-right">Failed</th>
                  <th className="py-2.5 px-3 text-right">Average Score %</th>
                  <th className="py-2.5 px-3 text-right">Pass Rate %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {classStats.map((c) => (
                  <tr key={c.className} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-[#1e293b]">{c.className}</td>
                    <td className="py-2 px-3 text-right font-mono font-bold">{c.totalStudents}</td>
                    <td className="py-2 px-3 text-right font-mono text-emerald-700 font-bold">{c.passed}</td>
                    <td className="py-2 px-3 text-right font-mono text-red-700 font-bold">{c.failed}</td>
                    <td className="py-2 px-3 text-right font-mono text-[#1e3a8a]">{c.avgScore}%</td>
                    <td className="py-2 px-3 text-right font-mono font-black text-[#1e293b]">{c.passRate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'mark_completion' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3">Subject & Code</th>
                  <th className="py-2.5 px-3">Class</th>
                  <th className="py-2.5 px-3">Assigned Faculty</th>
                  <th className="py-2.5 px-3 text-center">Window</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3">Verified By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {examSchedules.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-[#1e293b]">
                      {s.subjectName} ({s.subjectCode})
                    </td>
                    <td className="py-2 px-3 text-[#64748b]">{s.className} - {s.section}</td>
                    <td className="py-2 px-3 text-[#1e293b] font-medium">{s.assignedFacultyName}</td>
                    <td className="py-2 px-3 text-center font-mono font-bold">{s.markEntryStatus}</td>
                    <td className="py-2 px-3 text-center font-bold text-[#1e3a8a]">{s.markSubmissionStatus}</td>
                    <td className="py-2 px-3 text-[#64748b]">{s.verifiedBy || 'Pending'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'schedule' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3">Subject & Code</th>
                  <th className="py-2.5 px-3">Class</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Time Slot</th>
                  <th className="py-2.5 px-3">Room / Venue</th>
                  <th className="py-2.5 px-3">Assigned Faculty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {examSchedules.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-bold text-[#1e293b]">
                      {s.subjectName} ({s.subjectCode})
                    </td>
                    <td className="py-2 px-3 text-[#64748b]">{s.className} ({s.section})</td>
                    <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">{s.examDate}</td>
                    <td className="py-2 px-3 font-mono text-[#64748b]">{s.startTime} - {s.endTime}</td>
                    <td className="py-2 px-3 text-[#1e293b]">{s.roomVenue}</td>
                    <td className="py-2 px-3 text-[#64748b]">{s.assignedFacultyName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'hall_tickets' && (
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3">Hall Ticket No</th>
                  <th className="py-2.5 px-3">Reg No</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Class</th>
                  <th className="py-2.5 px-3">Generated Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {examTickets.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">{t.hallTicketNumber}</td>
                    <td className="py-2 px-3 font-mono text-[#64748b]">{t.studentRegistrationNumber}</td>
                    <td className="py-2 px-3 font-bold text-[#1e293b]">{t.studentName}</td>
                    <td className="py-2 px-3 text-[#64748b]">{t.className} - {t.section}</td>
                    <td className="py-2 px-3 text-[#64748b]">{t.generatedAt}</td>
                  </tr>
                ))}
                {examTickets.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-[#64748b]">
                      No hall tickets generated for this examination yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
