import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, MapPin, User, BookOpen, AlertCircle } from 'lucide-react';
import { Examination, ExamSubjectSchedule } from '../../types/examination';
import { AcademicClass, AcademicSection, AcademicSubject, FacultyAssignment } from '../../types/academic';
import { Employee } from '../../types/employee';
import { Button } from '../ui/Button';

interface ExamScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<ExamSubjectSchedule, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  initialData?: ExamSubjectSchedule | null;
  examinations: Examination[];
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyAssignments: FacultyAssignment[];
  employees: Employee[];
  defaultExamId?: string;
}

export function ExamScheduleModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  examinations,
  classes,
  sections,
  subjects,
  facultyAssignments,
  employees,
  defaultExamId,
}: ExamScheduleModalProps) {
  const [examinationId, setExaminationId] = useState(defaultExamId || '');
  const [className, setClassName] = useState('');
  const [section, setSection] = useState('All');
  const [subjectName, setSubjectName] = useState('');
  const [subjectCode, setSubjectCode] = useState('');
  const [maxMarks, setMaxMarks] = useState(100);
  const [passMarks, setPassMarks] = useState(40);
  const [examDate, setExamDate] = useState('');
  const [startTime, setStartTime] = useState('09:30');
  const [endTime, setEndTime] = useState('12:30');
  const [roomVenue, setRoomVenue] = useState('Main Examination Hall A');
  const [assignedFacultyId, setAssignedFacultyId] = useState('');
  const [assignedFacultyName, setAssignedFacultyName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setExaminationId(initialData.examinationId);
      setClassName(initialData.className);
      setSection(initialData.section);
      setSubjectName(initialData.subjectName);
      setSubjectCode(initialData.subjectCode);
      setMaxMarks(initialData.maxMarks);
      setPassMarks(initialData.passMarks);
      setExamDate(initialData.examDate);
      setStartTime(initialData.startTime);
      setEndTime(initialData.endTime);
      setRoomVenue(initialData.roomVenue);
      setAssignedFacultyId(initialData.assignedFacultyId);
      setAssignedFacultyName(initialData.assignedFacultyName);
    } else {
      setExaminationId(defaultExamId || (examinations[0]?.id ?? ''));
      setClassName(classes[0]?.name || 'Class 10');
      setSection('A');
      setSubjectName(subjects[0]?.name || 'Mathematics');
      setSubjectCode(subjects[0]?.code || 'MATH-101');
      setMaxMarks(100);
      setPassMarks(40);
      setExamDate('');
      setStartTime('09:30');
      setEndTime('12:30');
      setRoomVenue('Main Examination Hall A');

      // Default to first faculty from employee or assignment
      const firstFaculty = employees.find((e) => e.role === 'faculty') || employees[0];
      setAssignedFacultyId(firstFaculty?.id || 'FAC-001');
      setAssignedFacultyName(firstFaculty?.fullName || 'Prof. S. Walker');
    }
    setErrorMessage(null);
  }, [initialData, defaultExamId, examinations, classes, subjects, employees, isOpen]);

  // When class changes, auto-suggest subjects and faculty assignments
  const handleClassChange = (newClassName: string) => {
    setClassName(newClassName);
    const classSubject = subjects.find(
      (s) => s.className.toLowerCase() === newClassName.toLowerCase()
    );
    if (classSubject) {
      setSubjectName(classSubject.name);
      setSubjectCode(classSubject.code);
    }

    // Suggest assigned faculty for this class
    const matchAsg = facultyAssignments.find(
      (a) => a.className.toLowerCase() === newClassName.toLowerCase()
    );
    if (matchAsg) {
      setAssignedFacultyId(matchAsg.employeeId);
      setAssignedFacultyName(matchAsg.facultyName);
    }
  };

  const handleSubjectChange = (newSubjectName: string) => {
    setSubjectName(newSubjectName);
    const sub = subjects.find((s) => s.name === newSubjectName);
    if (sub) {
      setSubjectCode(sub.code);
    }
    // Match faculty assignment if available
    const matchAsg = facultyAssignments.find(
      (a) => a.subjectName.toLowerCase() === newSubjectName.toLowerCase()
    );
    if (matchAsg) {
      setAssignedFacultyId(matchAsg.employeeId);
      setAssignedFacultyName(matchAsg.facultyName);
    }
  };

  const handleFacultyChange = (empId: string) => {
    setAssignedFacultyId(empId);
    const emp = employees.find((e) => e.id === empId);
    if (emp) {
      setAssignedFacultyName(emp.fullName);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!examinationId) {
      setErrorMessage('Please select an Examination.');
      return;
    }
    if (!className || !subjectName || !subjectCode) {
      setErrorMessage('Class and Subject details are required.');
      return;
    }
    if (!examDate) {
      setErrorMessage('Exam Date is required.');
      return;
    }
    if (passMarks > maxMarks) {
      setErrorMessage('Passing marks cannot exceed maximum marks.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        examinationId,
        className,
        section,
        subjectName,
        subjectCode,
        maxMarks: Number(maxMarks),
        passMarks: Number(passMarks),
        examDate,
        startTime,
        endTime,
        roomVenue,
        assignedFacultyId,
        assignedFacultyName,
        markEntryStatus: initialData?.markEntryStatus || 'Not Open',
        markSubmissionStatus: initialData?.markSubmissionStatus || 'Not Started',
        markEntryOpenedAt: initialData?.markEntryOpenedAt,
        markEntryOpenedBy: initialData?.markEntryOpenedBy,
        markEntryClosedAt: initialData?.markEntryClosedAt,
        markEntryClosedBy: initialData?.markEntryClosedBy,
        markEntryReopenReason: initialData?.markEntryReopenReason,
        markEntryReopenedBy: initialData?.markEntryReopenedBy,
        markEntryReopenedAt: initialData?.markEntryReopenedAt,
        verificationNotes: initialData?.verificationNotes,
        verifiedBy: initialData?.verifiedBy,
        verifiedAt: initialData?.verifiedAt,
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save exam schedule paper.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter subject options
  const availableSubjects = subjects.length > 0
    ? Array.from(new Set(subjects.map((s) => s.name)))
    : ['Mathematics', 'General Science', 'English Literature', 'Social Studies', 'Computer Science', 'Physics', 'Chemistry'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl shadow-xl border border-[#cbd5e1] w-full max-w-2xl overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#eff6ff] text-[#1e3a8a] rounded-lg">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">
                {initialData ? 'Edit Exam Schedule Paper' : 'Add Exam Schedule Paper'}
              </h2>
              <p className="text-xs text-[#64748b]">
                Configure class, subject, venue, timing, and assigned evaluator
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-1">
              Examination <span className="text-red-500">*</span>
            </label>
            <select
              value={examinationId}
              onChange={(e) => setExaminationId(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
              required
            >
              {examinations.map((ex) => (
                <option key={ex.id} value={ex.id}>
                  {ex.name} ({ex.id}) — [{ex.status}]
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Class / Grade <span className="text-red-500">*</span>
              </label>
              <select
                value={className}
                onChange={(e) => handleClassChange(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
                required
              >
                {classes.map((cls) => (
                  <option key={cls.id} value={cls.name}>
                    {cls.name}
                  </option>
                ))}
                {classes.length === 0 && (
                  <>
                    <option value="Class 8">Class 8</option>
                    <option value="Class 9">Class 9</option>
                    <option value="Class 10">Class 10</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 12">Class 12</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Section <span className="text-red-500">*</span>
              </label>
              <select
                value={section}
                onChange={(e) => setSection(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                <option value="All">All Sections</option>
                <option value="A">Section A</option>
                <option value="B">Section B</option>
                <option value="C">Section C</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Subject Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                list="subject-suggestions"
                value={subjectName}
                onChange={(e) => handleSubjectChange(e.target.value)}
                placeholder="e.g. Mathematics"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
              <datalist id="subject-suggestions">
                {availableSubjects.map((s) => (
                  <option key={s} value={s} />
                ))}
              </datalist>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Subject Code <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={subjectCode}
                onChange={(e) => setSubjectCode(e.target.value.toUpperCase())}
                placeholder="e.g. MATH-101"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono uppercase"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Maximum Marks <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="1"
                max="1000"
                value={maxMarks}
                onChange={(e) => setMaxMarks(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Passing Marks <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                max={maxMarks}
                value={passMarks}
                onChange={(e) => setPassMarks(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Exam Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Start Time <span className="text-red-500">*</span>
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                End Time <span className="text-red-500">*</span>
              </label>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Room / Venue <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={roomVenue}
                onChange={(e) => setRoomVenue(e.target.value)}
                placeholder="e.g. Examination Hall A, Room 204"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Assigned Faculty Evaluator <span className="text-red-500">*</span>
              </label>
              <select
                value={assignedFacultyId}
                onChange={(e) => handleFacultyChange(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
                required
              >
                {employees
                  .filter((emp) => emp.role === 'faculty' || emp.role === 'academic' || emp.role === 'super_admin')
                  .map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} ({emp.id}) — {emp.department}
                    </option>
                  ))}
                {employees.filter((emp) => emp.role === 'faculty' || emp.role === 'academic' || emp.role === 'super_admin').length === 0 && (
                  <option value="ADMIN-001">System Administrator (ADMIN-001)</option>
                )}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving Schedule...' : initialData ? 'Update Schedule' : 'Confirm Schedule'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
