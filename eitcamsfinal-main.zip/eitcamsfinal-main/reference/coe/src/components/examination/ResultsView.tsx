import React, { useState } from 'react';
import {
  Award,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Calculator,
  Eye,
  Download,
  AlertTriangle,
  Lock,
  Globe,
  School,
  ShieldCheck,
} from 'lucide-react';
import {
  Examination,
  StudentExamResult,
  ExamSubjectSchedule,
} from '../../types/examination';
import { AcademicClass } from '../../types/academic';
import { Button } from '../ui/Button';

interface ResultsViewProps {
  examinations: Examination[];
  results: StudentExamResult[];
  schedules: ExamSubjectSchedule[];
  classes: AcademicClass[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onCalculateResults: (examId: string) => Promise<void>;
  onPublishResults: (examId: string) => Promise<void>;
  onOpenTranscriptModal: (result: StudentExamResult) => void;
  isCoeUser: boolean;
}

export function ResultsView({
  examinations,
  results,
  schedules,
  classes,
  selectedExamId,
  onSelectExamId,
  onCalculateResults,
  onPublishResults,
  onOpenTranscriptModal,
  isCoeUser,
}: ResultsViewProps) {
  const [classFilter, setClassFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCalculating, setIsCalculating] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || '';
  const currentExam = examinations.find((e) => e.id === activeExamId);

  const examResults = results.filter((r) => r.examinationId === activeExamId);

  const filteredResults = examResults.filter((res) => {
    const matchesClass = classFilter === 'All' || res.className === classFilter;
    const matchesStatus =
      statusFilter === 'All' || res.resultStatus === statusFilter;
    const matchesSearch =
      res.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      res.studentRegistrationNumber.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesClass && matchesStatus && matchesSearch;
  });

  const totalCalculated = examResults.length;
  const passedStudents = examResults.filter((r) => r.resultStatus === 'Pass').length;
  const failedStudents = totalCalculated - passedStudents;
  const passRate =
    totalCalculated > 0 ? ((passedStudents / totalCalculated) * 100).toFixed(1) : '0.0';

  const isAlreadyPublished = currentExam?.status === 'Published';

  const handleCalculate = async () => {
    if (!activeExamId) return;
    setIsCalculating(true);
    try {
      await onCalculateResults(activeExamId);
    } finally {
      setIsCalculating(false);
    }
  };

  const handlePublish = async () => {
    if (!activeExamId) return;
    if (!isCoeUser) {
      alert('Security Exception: Only the Controller of Examination is authorized to publish results.');
      return;
    }

    if (
      window.confirm(
        `CONFIRM RESULT PUBLICATION: Are you sure you want to officially publish results for ${currentExam?.name} (${activeExamId})? This will make final grades immutable and accessible across the institution.`
      )
    ) {
      setIsPublishing(true);
      try {
        await onPublishResults(activeExamId);
      } finally {
        setIsPublishing(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Reg No',
      'Student Name',
      'Class',
      'Section',
      'Total Marks Obtained',
      'Max Marks',
      'Percentage',
      'Grade',
      'Result Status',
      'Class Rank',
    ];
    const rows = filteredResults.map((r) => [
      r.studentRegistrationNumber,
      `"${r.studentName.replace(/"/g, '""')}"`,
      r.className,
      r.section,
      r.totalMarksObtained,
      r.totalMaxMarks,
      r.percentage.toFixed(2),
      r.overallGrade,
      r.resultStatus,
      r.classRank || '-',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `tabulation_sheet_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Results Processing & Official Publication
          </h1>
          <p className="text-xs text-[#64748b]">
            Deterministic grade aggregation, class rank determination, individual transcripts, and formal COE publication
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCSV}
            className="text-xs gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Tabulation Sheet CSV</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleCalculate}
            disabled={isCalculating || !activeExamId}
            className="text-xs gap-1.5 text-[#1e3a8a] hover:bg-blue-50 border-blue-200"
          >
            <Calculator className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin' : ''}`} />
            <span>Compute / Refresh Results</span>
          </Button>

          {isAlreadyPublished ? (
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-300">
              <CheckCircle2 className="w-4 h-4" />
              <span>Officially Published</span>
            </div>
          ) : (
            <Button
              size="sm"
              onClick={handlePublish}
              disabled={isPublishing || !activeExamId || totalCalculated === 0}
              className="text-xs gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Publish Results</span>
            </Button>
          )}
        </div>
      </div>

      {/* Publication Notification Banner */}
      {isAlreadyPublished && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-4 text-xs text-emerald-900 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 text-emerald-800 rounded-lg shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm">
                Official Result Publication Notice
              </div>
              <p className="text-[11px] text-emerald-800 mt-0.5">
                Published by <strong>{currentExam?.publishedBy || 'Controller of Examination'}</strong> on{' '}
                <strong>{currentExam?.publishedAt || 'N/A'}</strong>. Student marksheets are officially certified.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-[#64748b]">Total Candidates Evaluated</div>
          <div className="text-xl font-black text-[#1e293b] mt-0.5">{totalCalculated}</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-[#64748b]">Passed Students</div>
          <div className="text-xl font-black text-emerald-700 mt-0.5">{passedStudents}</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-[#64748b]">Fail / Retest Count</div>
          <div className="text-xl font-black text-red-700 mt-0.5">{failedStudents}</div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-[#64748b]">Overall Pass Rate</div>
          <div className="text-xl font-black text-[#1e3a8a] mt-0.5">{passRate}%</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-4 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Active Examination
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Filter by Class
          </label>
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Classes</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.name}>
                {cls.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Result Classification
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Results</option>
            <option value="Pass">Pass Only</option>
            <option value="Fail">Fail / Retest Only</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Student
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student name or reg no..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Results Tabulation Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4 text-center">Rank</th>
                <th className="py-3 px-4">Registration No</th>
                <th className="py-3 px-4">Candidate Name</th>
                <th className="py-3 px-4">Class & Sec</th>
                <th className="py-3 px-4 text-right">Marks (Total / Max)</th>
                <th className="py-3 px-4 text-right">Percentage</th>
                <th className="py-3 px-4 text-center">Overall Grade</th>
                <th className="py-3 px-4 text-center">Result Status</th>
                <th className="py-3 px-4 text-right">Transcript</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredResults.map((res) => (
                <tr key={res.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 text-center font-mono font-bold text-[#64748b]">
                    {res.classRank ? (
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-[#1e293b]">
                        #{res.classRank}
                      </span>
                    ) : (
                      '-'
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a] whitespace-nowrap">
                    {res.studentRegistrationNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-[#1e293b]">
                    {res.studentName}
                  </td>
                  <td className="py-3 px-4 text-[#1e293b] whitespace-nowrap">
                    {res.className} — {res.section}
                  </td>
                  <td className="py-3 px-4 text-right font-mono whitespace-nowrap">
                    <span className="font-bold text-[#1e293b]">{res.totalMarksObtained}</span>
                    <span className="text-[#64748b] text-[11px]"> / {res.totalMaxMarks}</span>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-[#1e3a8a] whitespace-nowrap">
                    {res.percentage.toFixed(2)}%
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-bold">
                    <span className={`px-2 py-0.5 rounded text-[11px] ${
                      res.overallGrade === 'A+' || res.overallGrade === 'A'
                        ? 'bg-emerald-50 text-emerald-800'
                        : res.overallGrade === 'F'
                        ? 'bg-red-50 text-red-800'
                        : 'bg-blue-50 text-blue-800'
                    }`}>
                      {res.overallGrade}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        res.resultStatus === 'Pass'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {res.resultStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onOpenTranscriptModal(res)}
                      className="text-[11px] py-1 px-2.5 gap-1 h-auto"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Marksheet</span>
                    </Button>
                  </td>
                </tr>
              ))}
              {filteredResults.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#64748b] text-xs">
                    No results calculated yet for this examination. Click "Compute / Refresh Results" to calculate from verified paper marks.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
