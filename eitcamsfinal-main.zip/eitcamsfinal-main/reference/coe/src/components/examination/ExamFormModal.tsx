import React, { useState, useEffect } from 'react';
import { X, Calendar, Layers, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { Examination, ExamStatus, ExamTermType } from '../../types/examination';
import { Button } from '../ui/Button';

interface ExamFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Examination, 'createdAt' | 'updatedAt'>) => Promise<void>;
  initialData?: Examination | null;
  currentAcademicSession: string;
  currentUserName: string;
}

const TERM_TYPES: ExamTermType[] = [
  'Term 1',
  'Term 2',
  'Mid-Term',
  'Annual',
  'Unit Test',
  'Pre-Board',
  'Semester 1',
  'Semester 2',
  'Special Exam',
];

const STATUS_OPTIONS: ExamStatus[] = [
  'Draft',
  'Active',
  'Mark Entry Open',
  'Mark Entry Closed',
  'Verification',
  'Published',
  'Archived',
];

export function ExamFormModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  currentAcademicSession,
  currentUserName,
}: ExamFormModalProps) {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [academicSession, setAcademicSession] = useState(currentAcademicSession || '2026-27');
  const [termType, setTermType] = useState<ExamTermType>('Term 1');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [status, setStatus] = useState<ExamStatus>('Draft');
  const [instructions, setInstructions] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setId(initialData.id);
      setName(initialData.name);
      setAcademicSession(initialData.academicSession);
      setTermType(initialData.termType);
      setStartDate(initialData.startDate);
      setEndDate(initialData.endDate);
      setStatus(initialData.status);
      setInstructions(initialData.instructions || '');
    } else {
      const year = new Date().getFullYear();
      setId(`TERM-1-${year}`);
      setName(`First Term Examination ${year}`);
      setAcademicSession(currentAcademicSession || '2026-27');
      setTermType('Term 1');
      setStartDate('');
      setEndDate('');
      setStatus('Draft');
      setInstructions(
        'Candidates must carry valid Hall Tickets and Institutional ID cards to all sessions. Electronic gadgets and unauthorized materials are strictly prohibited.'
      );
    }
    setErrorMessage(null);
  }, [initialData, currentAcademicSession, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!id.trim()) {
      setErrorMessage('Examination ID is required (e.g. TERM-1-2026).');
      return;
    }
    if (!name.trim()) {
      setErrorMessage('Examination Name is required.');
      return;
    }
    if (!startDate || !endDate) {
      setErrorMessage('Please specify valid Start and End dates.');
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
      setErrorMessage('Start date cannot be after End date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        id: id.trim().toUpperCase(),
        name: name.trim(),
        academicSession: academicSession.trim(),
        termType,
        startDate,
        endDate,
        status,
        instructions: instructions.trim(),
        createdBy: initialData ? initialData.createdBy : currentUserName,
        updatedBy: currentUserName,
        publishedAt: initialData?.publishedAt,
        publishedBy: initialData?.publishedBy,
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save examination.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-xl shadow-xl border border-[#cbd5e1] w-full max-w-2xl overflow-hidden my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#eff6ff] text-[#1e3a8a] rounded-lg">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">
                {initialData ? 'Edit Examination' : 'Create New Examination'}
              </h2>
              <p className="text-xs text-[#64748b]">
                Configure institutional assessment parameters and scheduling details
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg flex items-start gap-2">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Examination ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                disabled={!!initialData && initialData.status !== 'Draft'}
                value={id}
                onChange={(e) => setId(e.target.value)}
                placeholder="e.g. TERM-1-2026"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] disabled:bg-slate-100 disabled:text-[#64748b] font-mono uppercase"
                required
              />
              <p className="text-[10px] text-[#64748b] mt-0.5">Unique institutional identifier</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Academic Session <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={academicSession}
                onChange={(e) => setAcademicSession(e.target.value)}
                placeholder="e.g. 2026-27"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-1">
              Examination Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. First Term Examination 2026-27"
              className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Term / Type <span className="text-red-500">*</span>
              </label>
              <select
                value={termType}
                onChange={(e) => setTermType(e.target.value as ExamTermType)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                {TERM_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Initial Status <span className="text-red-500">*</span>
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ExamStatus)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                {STATUS_OPTIONS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                Start Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] mb-1">
                End Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-1">
              Examination Instructions & Guidelines
            </label>
            <textarea
              rows={3}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Instructions printed on student hall tickets and communicated to invigilators..."
              className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : initialData ? 'Update Examination' : 'Create Examination'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
