import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  RotateCcw,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  BookOpen,
  Download,
  ShieldCheck,
} from 'lucide-react';
import { Examination, ExamSubjectSchedule, MarkEntryWindowStatus } from '../../types/examination';
import { Button } from '../ui/Button';

interface MarkEntryControlViewProps {
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenWindow: (scheduleId: string) => Promise<void>;
  onCloseWindow: (scheduleId: string) => Promise<void>;
  onOpenReopenModal: (schedule: ExamSubjectSchedule) => void;
  onBulkOpenWindows: (examId: string) => Promise<void>;
  onBulkCloseWindows: (examId: string) => Promise<void>;
}

export function MarkEntryControlView({
  examinations,
  schedules,
  selectedExamId,
  onSelectExamId,
  onOpenWindow,
  onCloseWindow,
  onOpenReopenModal,
  onBulkOpenWindows,
  onBulkCloseWindows,
}: MarkEntryControlViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || '';

  const examSchedules = schedules.filter((s) => s.examinationId === activeExamId);

  const filteredSchedules = examSchedules.filter((sch) => {
    const matchesStatus = statusFilter === 'All' || sch.markEntryStatus === statusFilter;
    const matchesSearch =
      sch.subjectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.subjectCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sch.assignedFacultyName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const openCount = examSchedules.filter((s) => s.markEntryStatus === 'Open').length;
  const closedCount = examSchedules.filter((s) => s.markEntryStatus === 'Closed' || s.markEntryStatus === 'Locked').length;
  const notOpenCount = examSchedules.filter((s) => s.markEntryStatus === 'Not Open').length;

  const handleBulkOpen = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to open Mark Entry for ALL ${examSchedules.length} papers in ${activeExamId}? Faculty evaluators will immediately gain write permissions.`
      )
    ) {
      setIsBulkProcessing(true);
      try {
        await onBulkOpenWindows(activeExamId);
      } finally {
        setIsBulkProcessing(false);
      }
    }
  };

  const handleBulkClose = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to CLOSE Mark Entry for ALL papers in ${activeExamId}? This will lock the mark-entry interface for faculty.`
      )
    ) {
      setIsBulkProcessing(true);
      try {
        await onBulkCloseWindows(activeExamId);
      } finally {
        setIsBulkProcessing(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Subject',
      'Code',
      'Class',
      'Section',
      'Assigned Faculty',
      'Mark Entry Window',
      'Submission Status',
      'Opened At',
      'Closed At',
      'Reopen Reason',
    ];
    const rows = filteredSchedules.map((s) => [
      `"${s.subjectName.replace(/"/g, '""')}"`,
      s.subjectCode,
      s.className,
      s.section,
      `"${s.assignedFacultyName.replace(/"/g, '""')}"`,
      s.markEntryStatus,
      s.markSubmissionStatus,
      s.markEntryOpenedAt || '-',
      s.markEntryClosedAt || '-',
      `"${(s.markEntryReopenReason || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `mark_entry_control_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Faculty Mark Entry Window Control Console
          </h1>
          <p className="text-xs text-[#64748b]">
            Enforce strict time-locked evaluator access: open, close, and auditably reopen subject mark entry windows
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>Export Status</span>
          </Button>
          <Button
            size="sm"
            onClick={handleBulkOpen}
            disabled={isBulkProcessing || !activeExamId}
            className="text-xs gap-1.5 bg-amber-600 hover:bg-amber-700 text-white"
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>Open All Windows</span>
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleBulkClose}
            disabled={isBulkProcessing || !activeExamId}
            className="text-xs gap-1.5 text-slate-700 hover:bg-slate-100"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Lock All Windows</span>
          </Button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Active Mark Entry Windows</div>
            <div className="text-xl font-black text-amber-700">{openCount}</div>
          </div>
          <div className="p-2 bg-amber-50 text-amber-700 rounded-lg">
            <Unlock className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Closed / Locked Windows</div>
            <div className="text-xl font-black text-[#1e293b]">{closedCount}</div>
          </div>
          <div className="p-2 bg-slate-100 text-slate-700 rounded-lg">
            <Lock className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Pending Assessment</div>
            <div className="text-xl font-black text-[#64748b]">{notOpenCount}</div>
          </div>
          <div className="p-2 bg-slate-50 text-[#64748b] rounded-lg">
            <Clock className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Selected Examination
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Window Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Window States</option>
            <option value="Open">Open (Faculty Can Edit)</option>
            <option value="Closed">Closed (Locked)</option>
            <option value="Not Open">Not Open</option>
            <option value="Locked">Locked (Finalized)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Paper / Faculty
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search subject, faculty name..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Mark Entry Window Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4">Subject & Paper</th>
                <th className="py-3 px-4">Class & Section</th>
                <th className="py-3 px-4">Assigned Faculty Evaluator</th>
                <th className="py-3 px-4 text-center">Window Status</th>
                <th className="py-3 px-4 text-center">Submission Status</th>
                <th className="py-3 px-4">Audit Window Info</th>
                <th className="py-3 px-4 text-right">Window Control Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredSchedules.map((sch) => (
                <tr key={sch.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#1e293b]">{sch.subjectName}</div>
                    <span className="text-[10px] font-mono text-[#64748b] bg-slate-100 px-1.5 py-0.5 rounded">
                      {sch.subjectCode} • Max: {sch.maxMarks}
                    </span>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap font-medium text-[#1e293b]">
                    {sch.className} ({sch.section})
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-bold text-[#1e293b] flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#64748b]" />
                      {sch.assignedFacultyName}
                    </div>
                    <span className="text-[10px] font-mono text-[#64748b]">{sch.assignedFacultyId}</span>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase ${
                        sch.markEntryStatus === 'Open'
                          ? 'bg-amber-100 text-amber-800'
                          : sch.markEntryStatus === 'Closed'
                          ? 'bg-slate-200 text-[#475569]'
                          : sch.markEntryStatus === 'Locked'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {sch.markEntryStatus === 'Open' ? (
                        <Unlock className="w-3 h-3" />
                      ) : (
                        <Lock className="w-3 h-3" />
                      )}
                      {sch.markEntryStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        sch.markSubmissionStatus === 'Verified'
                          ? 'bg-emerald-100 text-emerald-800'
                          : sch.markSubmissionStatus === 'Submitted'
                          ? 'bg-blue-100 text-blue-800'
                          : sch.markSubmissionStatus === 'Returned'
                          ? 'bg-red-100 text-red-800'
                          : sch.markSubmissionStatus === 'In Progress'
                          ? 'bg-amber-50 text-amber-700'
                          : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {sch.markSubmissionStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[11px] text-[#64748b]">
                    {sch.markEntryReopenReason ? (
                      <div className="text-amber-800 font-medium">
                        Reopened: {sch.markEntryReopenReason}
                      </div>
                    ) : sch.markEntryClosedAt ? (
                      <div>Locked on {sch.markEntryClosedAt}</div>
                    ) : sch.markEntryOpenedAt ? (
                      <div>Opened on {sch.markEntryOpenedAt}</div>
                    ) : (
                      <span className="text-[#94a3b8]">Not initialized</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      {sch.markEntryStatus !== 'Open' ? (
                        <Button
                          size="sm"
                          onClick={() => onOpenWindow(sch.id)}
                          className="text-[11px] py-1 px-2.5 bg-amber-600 hover:bg-amber-700 text-white h-auto"
                        >
                          Open Window
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onCloseWindow(sch.id)}
                          className="text-[11px] py-1 px-2.5 text-slate-700 hover:bg-slate-100 h-auto"
                        >
                          Lock Window
                        </Button>
                      )}

                      {sch.markEntryStatus === 'Closed' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onOpenReopenModal(sch)}
                          className="text-[11px] py-1 px-2 text-amber-700 hover:bg-amber-50 border-amber-300 h-auto"
                          title="Reopen mark entry with mandatory reason"
                        >
                          Reopen...
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredSchedules.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#64748b] text-xs">
                    No scheduled papers found for this examination.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
