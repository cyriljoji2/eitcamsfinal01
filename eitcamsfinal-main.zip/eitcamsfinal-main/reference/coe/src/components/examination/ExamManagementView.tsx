import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Edit2,
  Calendar,
  Layers,
  CheckCircle2,
  Lock,
  Unlock,
  Archive,
  Download,
  AlertCircle,
} from 'lucide-react';
import { Examination, ExamStatus, ExamTermType } from '../../types/examination';
import { Button } from '../ui/Button';

interface ExamManagementViewProps {
  examinations: Examination[];
  onOpenCreateModal: () => void;
  onOpenEditModal: (exam: Examination) => void;
  onUpdateStatus: (examId: string, status: ExamStatus) => Promise<void>;
  onViewSchedule: (examId: string) => void;
}

export function ExamManagementView({
  examinations,
  onOpenCreateModal,
  onOpenEditModal,
  onUpdateStatus,
  onViewSchedule,
}: ExamManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sessionFilter, setSessionFilter] = useState<string>('All');

  // Filter distinct academic sessions
  const sessions = Array.from(new Set(examinations.map((e) => e.academicSession)));

  const filteredExams = examinations.filter((exam) => {
    const matchesSearch =
      exam.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exam.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || exam.status === statusFilter;
    const matchesSession = sessionFilter === 'All' || exam.academicSession === sessionFilter;
    return matchesSearch && matchesStatus && matchesSession;
  });

  const handleExportCSV = () => {
    const headers = [
      'Exam ID',
      'Exam Name',
      'Academic Session',
      'Term Type',
      'Start Date',
      'End Date',
      'Status',
      'Created By',
    ];
    const rows = filteredExams.map((e) => [
      e.id,
      `"${e.name.replace(/"/g, '""')}"`,
      e.academicSession,
      e.termType,
      e.startDate,
      e.endDate,
      e.status,
      e.createdBy,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `examinations_list_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">Examinations Registry</h1>
          <p className="text-xs text-[#64748b]">
            Create, configure assessment windows, and manage examination lifecycle states
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </Button>
          <Button size="sm" onClick={onOpenCreateModal} className="text-xs gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            <span>New Examination</span>
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search exam by title or code..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Lifecycle Statuses</option>
            <option value="Draft">Draft</option>
            <option value="Active">Active</option>
            <option value="Mark Entry Open">Mark Entry Open</option>
            <option value="Mark Entry Closed">Mark Entry Closed</option>
            <option value="Verification">Verification</option>
            <option value="Published">Published</option>
            <option value="Archived">Archived</option>
          </select>
        </div>

        <div>
          <select
            value={sessionFilter}
            onChange={(e) => setSessionFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Academic Sessions</option>
            {sessions.map((s) => (
              <option key={s} value={s}>
                Session {s}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Examinations Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4">Exam ID</th>
                <th className="py-3 px-4">Name & Description</th>
                <th className="py-3 px-4">Session & Term</th>
                <th className="py-3 px-4">Exam Dates</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredExams.map((exam) => (
                <tr key={exam.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a] whitespace-nowrap">
                    {exam.id}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#1e293b]">{exam.name}</div>
                    {exam.instructions && (
                      <div className="text-[11px] text-[#64748b] truncate max-w-md mt-0.5">
                        {exam.instructions}
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-medium text-[#1e293b]">{exam.termType}</div>
                    <div className="text-[11px] text-[#64748b]">Session: {exam.academicSession}</div>
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="font-medium text-[#1e293b]">{exam.startDate}</div>
                    <div className="text-[11px] text-[#64748b]">to {exam.endDate}</div>
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase ${
                        exam.status === 'Published'
                          ? 'bg-emerald-100 text-emerald-800'
                          : exam.status === 'Mark Entry Open'
                          ? 'bg-amber-100 text-amber-800'
                          : exam.status === 'Verification'
                          ? 'bg-purple-100 text-purple-800'
                          : exam.status === 'Active'
                          ? 'bg-blue-100 text-blue-800'
                          : exam.status === 'Draft'
                          ? 'bg-slate-200 text-[#475569]'
                          : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {exam.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onViewSchedule(exam.id)}
                        className="text-[11px] py-1 px-2.5 h-auto"
                      >
                        Schedules
                      </Button>

                      {/* State transition triggers */}
                      {exam.status === 'Draft' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateStatus(exam.id, 'Active')}
                          className="text-[11px] py-1 px-2 text-blue-700 hover:bg-blue-50 border-blue-200 h-auto"
                        >
                          Activate
                        </Button>
                      )}

                      {exam.status === 'Active' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateStatus(exam.id, 'Mark Entry Open')}
                          className="text-[11px] py-1 px-2 text-amber-700 hover:bg-amber-50 border-amber-200 h-auto"
                        >
                          Open Marks
                        </Button>
                      )}

                      {exam.status === 'Mark Entry Open' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateStatus(exam.id, 'Mark Entry Closed')}
                          className="text-[11px] py-1 px-2 text-slate-700 hover:bg-slate-100 border-slate-300 h-auto"
                        >
                          Close Marks
                        </Button>
                      )}

                      <button
                        onClick={() => onOpenEditModal(exam)}
                        className="p-1.5 text-[#64748b] hover:text-[#1e293b] rounded hover:bg-slate-100 transition-colors"
                        title="Edit Examination"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredExams.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-[#64748b] text-xs">
                    No examinations found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
