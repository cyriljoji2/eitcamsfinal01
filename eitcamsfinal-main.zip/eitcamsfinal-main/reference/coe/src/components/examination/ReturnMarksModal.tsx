import React, { useState } from 'react';
import { X, RotateCcw, AlertOctagon } from 'lucide-react';
import { ExamSubjectSchedule } from '../../types/examination';
import { Button } from '../ui/Button';

interface ReturnMarksModalProps {
  isOpen: boolean;
  onClose: () => void;
  schedule: ExamSubjectSchedule | null;
  onConfirmReturn: (scheduleId: string, reason: string) => Promise<void>;
  currentUserName: string;
}

export function ReturnMarksModal({
  isOpen,
  onClose,
  schedule,
  onConfirmReturn,
  currentUserName,
}: ReturnMarksModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !schedule) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Please provide specific correction instructions or reason for rejection.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmReturn(schedule.id, reason.trim());
      setReason('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to return marks.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-xl border border-red-200 w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-red-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-red-100 text-red-700 rounded-lg">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">Return Marks For Correction</h2>
              <p className="text-xs text-red-700 font-medium">Rejects Submission & Re-enables Faculty Entry</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-red-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-red-50/70 border border-red-200 rounded-lg text-xs text-red-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertOctagon className="w-4 h-4 text-red-700 shrink-0" />
              <span>Correction Workflow Notice</span>
            </div>
            <p>
              This will return the mark submission for{' '}
              <strong>
                {schedule.subjectName} ({schedule.className} - {schedule.section})
              </strong>{' '}
              back to <strong>{schedule.assignedFacultyName}</strong> with status <em>Returned</em>. The
              mark-entry window will be unlocked for them to submit corrections.
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] mb-1">
              Correction Notes & Discrepancies <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Discrepancy observed in Section B total marks for 3 students. Please re-audit and resubmit..."
              className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              required
            />
            <p className="text-[10px] text-[#64748b] mt-1">
              Reviewed by: <strong>{currentUserName}</strong>
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-red-600 hover:bg-red-700 text-white border-red-700"
            >
              {isSubmitting ? 'Returning...' : 'Return Marks'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
