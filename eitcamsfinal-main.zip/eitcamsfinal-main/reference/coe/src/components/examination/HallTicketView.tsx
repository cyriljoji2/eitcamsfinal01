import React, { useState } from 'react';
import {
  Printer,
  Search,
  Filter,
  Users,
  Download,
  Eye,
  CheckCircle2,
  FileCheck,
  Calendar,
  Sparkles,
} from 'lucide-react';
import {
  Examination,
  HallTicket,
  ExamSubjectSchedule,
  StudentExamEligibility,
} from '../../types/examination';
import { AcademicClass } from '../../types/academic';
import { Button } from '../ui/Button';

interface HallTicketViewProps {
  examinations: Examination[];
  hallTickets: HallTicket[];
  schedules: ExamSubjectSchedule[];
  eligibilities: StudentExamEligibility[];
  classes: AcademicClass[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onGenerateIndividual: (examId: string, regNo: string) => Promise<HallTicket>;
  onGenerateClassBatch: (examId: string, className: string) => Promise<HallTicket[]>;
  onGenerateExamBulk: (examId: string) => Promise<HallTicket[]>;
  onOpenPrintModal: (ticket: HallTicket) => void;
}

export function HallTicketView({
  examinations,
  hallTickets,
  schedules,
  eligibilities,
  classes,
  selectedExamId,
  onSelectExamId,
  onGenerateIndividual,
  onGenerateClassBatch,
  onGenerateExamBulk,
  onOpenPrintModal,
}: HallTicketViewProps) {
  const [classFilter, setClassFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [individualRegNo, setIndividualRegNo] = useState('');
  const [targetBatchClass, setTargetBatchClass] = useState<string>('Class 10');
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const activeExamId = selectedExamId || examinations[0]?.id || '';

  const examTickets = hallTickets.filter((t) => t.examinationId === activeExamId);

  const filteredTickets = examTickets.filter((t) => {
    const matchesClass = classFilter === 'All' || t.className === classFilter;
    const matchesSearch =
      t.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.studentRegistrationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.hallTicketNumber.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesClass && matchesSearch;
  });

  const handleGenerateIndividual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!individualRegNo.trim() || !activeExamId) return;

    setIsGenerating(true);
    setStatusMessage(null);
    try {
      const ticket = await onGenerateIndividual(activeExamId, individualRegNo.trim());
      setIndividualRegNo('');
      setStatusMessage(`Successfully generated Hall Ticket ${ticket.hallTicketNumber} for ${ticket.studentName}.`);
      onOpenPrintModal(ticket);
    } catch (err: any) {
      alert(err.message || 'Failed to generate hall ticket.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateClassBatch = async () => {
    if (!activeExamId || !targetBatchClass) return;
    setIsGenerating(true);
    setStatusMessage(null);
    try {
      const batch = await onGenerateClassBatch(activeExamId, targetBatchClass);
      setStatusMessage(`Generated ${batch.length} Hall Tickets for ${targetBatchClass}.`);
    } catch (err: any) {
      alert(err.message || 'Failed to generate class batch hall tickets.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateAllExam = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to generate Hall Tickets for ALL eligible candidates across all classes for ${activeExamId}?`
      )
    ) {
      setIsGenerating(true);
      setStatusMessage(null);
      try {
        const batch = await onGenerateExamBulk(activeExamId);
        setStatusMessage(`Generated ${batch.length} Hall Tickets across all eligible classes.`);
      } catch (err: any) {
        alert(err.message || 'Failed to generate bulk hall tickets.');
      } finally {
        setIsGenerating(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Hall Ticket No',
      'Registration No',
      'Student Name',
      'Class',
      'Section',
      'Exam ID',
      'Papers Scheduled',
      'Issue Date',
    ];
    const rows = filteredTickets.map((t) => [
      t.hallTicketNumber,
      t.studentRegistrationNumber,
      `"${t.studentName.replace(/"/g, '""')}"`,
      t.className,
      t.section,
      t.examinationId,
      t.schedules.length,
      t.generatedAt,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `hall_tickets_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Hall Ticket & Admit Card Management
          </h1>
          <p className="text-xs text-[#64748b]">
            Batch generate, inspect, and issue authenticated examination entry passes with candidate timetables
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>Export Roster CSV</span>
          </Button>
          <Button
            size="sm"
            onClick={handleGenerateAllExam}
            disabled={isGenerating || !activeExamId}
            className="text-xs gap-1.5 bg-[#1e3a8a] hover:bg-blue-900"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Generate All Eligible</span>
          </Button>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* Generation Control Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Individual Generation Box */}
        <div className="bg-white p-4 rounded-xl border border-[#cbd5e1] space-y-3 shadow-2xs">
          <div className="flex items-center gap-2 text-xs font-bold text-[#1e293b]">
            <Printer className="w-4 h-4 text-[#1e3a8a]" />
            <span>Generate Single Candidate Hall Ticket</span>
          </div>
          <form onSubmit={handleGenerateIndividual} className="flex gap-2">
            <input
              type="text"
              value={individualRegNo}
              onChange={(e) => setIndividualRegNo(e.target.value)}
              placeholder="Enter Reg No (e.g. REG20260001)..."
              className="flex-1 px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono uppercase"
              required
            />
            <Button type="submit" size="sm" disabled={isGenerating}>
              Generate & View
            </Button>
          </form>
        </div>

        {/* Class Batch Generation Box */}
        <div className="bg-white p-4 rounded-xl border border-[#cbd5e1] space-y-3 shadow-2xs">
          <div className="flex items-center gap-2 text-xs font-bold text-[#1e293b]">
            <Users className="w-4 h-4 text-[#1e3a8a]" />
            <span>Generate Class Batch Hall Tickets</span>
          </div>
          <div className="flex gap-2">
            <select
              value={targetBatchClass}
              onChange={(e) => setTargetBatchClass(e.target.value)}
              className="flex-1 px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
            >
              {classes.map((cls) => (
                <option key={cls.id} value={cls.name}>
                  {cls.name}
                </option>
              ))}
              {classes.length === 0 && (
                <>
                  <option value="Class 8">Class 8</option>
                  <option value="Class 9">Class 9</option>
                  <option value="Class 10">Class 10</option>
                  <option value="Class 11">Class 11</option>
                  <option value="Class 12">Class 12</option>
                </>
              )}
            </select>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleGenerateClassBatch}
              disabled={isGenerating}
            >
              Batch Generate
            </Button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Active Examination
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Filter by Class
          </label>
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Classes</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.name}>
                {cls.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Hall Ticket / Candidate
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ticket no, student name, reg no..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Hall Tickets Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4">Hall Ticket No</th>
                <th className="py-3 px-4">Registration No</th>
                <th className="py-3 px-4">Candidate Name</th>
                <th className="py-3 px-4">Class & Section</th>
                <th className="py-3 px-4 text-center">Scheduled Papers</th>
                <th className="py-3 px-4">Issue Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredTickets.map((ticket) => (
                <tr key={ticket.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a] whitespace-nowrap">
                    {ticket.hallTicketNumber}
                  </td>
                  <td className="py-3 px-4 font-mono text-[#1e293b] whitespace-nowrap">
                    {ticket.studentRegistrationNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-[#1e293b]">
                    {ticket.studentName}
                  </td>
                  <td className="py-3 px-4 text-[#1e293b] whitespace-nowrap">
                    {ticket.className} — {ticket.section}
                  </td>
                  <td className="py-3 px-4 text-center font-mono font-bold text-[#1e293b]">
                    <span className="px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a]">
                      {ticket.schedules.length} papers
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[#64748b] text-[11px] whitespace-nowrap">
                    {ticket.generatedAt}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onOpenPrintModal(ticket)}
                      className="text-[11px] py-1 px-2.5 gap-1.5 h-auto"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Print Admit Card</span>
                    </Button>
                  </td>
                </tr>
              ))}
              {filteredTickets.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#64748b] text-xs">
                    No hall tickets generated for this examination yet. Use the generation tools above to issue admit cards.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
