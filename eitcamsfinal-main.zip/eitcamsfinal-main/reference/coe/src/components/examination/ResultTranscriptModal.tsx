import React from 'react';
import { X, Printer, Award, School, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { StudentExamResult } from '../../types/examination';
import { Button } from '../ui/Button';

interface ResultTranscriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: StudentExamResult | null;
}

export function ResultTranscriptModal({
  isOpen,
  onClose,
  result,
}: ResultTranscriptModalProps) {
  if (!isOpen || !result) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-3xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md">
              Academic Transcript / Marksheet
            </span>
            <span className="text-xs text-[#64748b] font-mono">
              {result.studentRegistrationNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Transcript</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Transcript */}
        <div className="p-8 space-y-6 text-[#1e293b] print:p-6">
          {/* Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex items-start justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-2xl shrink-0 shadow-xs">
                <School className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-lg font-black text-[#1e3a8a] tracking-tight uppercase">
                  ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)
                </h1>
                <p className="text-xs text-[#64748b]">1000 Academic Parkway, Springfield, IL 62701</p>
                <div className="mt-1 inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold rounded-md">
                  <Award className="w-3.5 h-3.5" />
                  OFFICIAL STATEMENT OF MARKS & GRADES
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-[#64748b] font-medium">Academic Session</div>
              <div className="text-sm font-bold text-[#1e293b]">{result.academicSession}</div>
              <div className="text-[10px] text-[#64748b] mt-1">
                Status: <span className="font-bold text-[#1e3a8a] uppercase">{result.verificationStatus}</span>
              </div>
            </div>
          </div>

          {/* Exam Name */}
          <div className="bg-[#f8fafc] border border-[#cbd5e1] rounded-lg p-3 text-center">
            <h2 className="text-sm font-black text-[#1e293b] uppercase tracking-wide">
              {result.examinationName}
            </h2>
          </div>

          {/* Student Info */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-50 border border-[#cbd5e1] rounded-lg text-xs">
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Student Name</span>
              <span className="font-bold text-[#1e293b] text-sm">{result.studentName}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Registration No</span>
              <span className="font-bold font-mono text-[#1e3a8a] text-sm">{result.studentRegistrationNumber}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Program & Section</span>
              <span className="font-bold text-[#1e293b]">{result.className} - {result.section}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Batch Rank</span>
              <span className="font-bold font-mono text-emerald-700">
                {result.classRank ? `#${result.classRank}` : 'N/A'}
              </span>
            </div>
          </div>

          {/* Marks Table */}
          <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0]">#</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Subject Name</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">Code</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-right">Max Marks</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-right">Pass Marks</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-right">Marks Obtained</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">Grade</th>
                  <th className="py-2.5 px-3 text-center">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {result.subjectMarks.map((sub, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-[#fcfdfe]'}>
                    <td className="py-2 px-3 text-center font-mono text-[#64748b] border-r border-[#e2e8f0]">
                      {idx + 1}
                    </td>
                    <td className="py-2 px-3 font-bold text-[#1e293b] border-r border-[#e2e8f0]">
                      {sub.subjectName}
                    </td>
                    <td className="py-2 px-3 font-mono text-center text-[#64748b] border-r border-[#e2e8f0]">
                      {sub.subjectCode}
                    </td>
                    <td className="py-2 px-3 text-right font-mono border-r border-[#e2e8f0]">
                      {sub.maxMarks}
                    </td>
                    <td className="py-2 px-3 text-right font-mono border-r border-[#e2e8f0] text-[#64748b]">
                      {sub.passMarks}
                    </td>
                    <td className="py-2 px-3 text-right font-mono font-bold border-r border-[#e2e8f0]">
                      {sub.attendanceStatus === 'Absent' ? (
                        <span className="text-red-600 font-bold">ABSENT</span>
                      ) : sub.marksObtained !== null ? (
                        sub.marksObtained
                      ) : (
                        <span className="text-amber-600">Pending</span>
                      )}
                    </td>
                    <td className="py-2 px-3 text-center font-bold font-mono border-r border-[#e2e8f0]">
                      <span className={`px-2 py-0.5 rounded text-[11px] ${
                        sub.grade === 'A+' || sub.grade === 'A'
                          ? 'bg-emerald-50 text-emerald-800'
                          : sub.grade === 'F'
                          ? 'bg-red-50 text-red-800'
                          : 'bg-blue-50 text-blue-800'
                      }`}>
                        {sub.grade || '-'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center font-bold">
                      {sub.isPassed ? (
                        <span className="text-emerald-700 inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Pass
                        </span>
                      ) : (
                        <span className="text-red-700 inline-flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" /> Fail
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-[#f8fafc] border-t-2 border-[#cbd5e1] font-bold text-xs">
                <tr>
                  <td colSpan={3} className="py-2.5 px-3 uppercase text-right border-r border-[#cbd5e1]">
                    Grand Total & Overall Performance
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono border-r border-[#cbd5e1]">
                    {result.totalMaxMarks}
                  </td>
                  <td className="py-2.5 px-3 border-r border-[#cbd5e1]"></td>
                  <td className="py-2.5 px-3 text-right font-mono font-black text-sm text-[#1e3a8a] border-r border-[#cbd5e1]">
                    {result.totalMarksObtained}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-black text-sm text-emerald-700 border-r border-[#cbd5e1]">
                    {result.overallGrade}
                  </td>
                  <td className="py-2.5 px-3 text-center font-black">
                    <span className={`px-2.5 py-1 rounded text-xs ${
                      result.resultStatus === 'Pass'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {result.resultStatus.toUpperCase()}
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Performance Summary Pill */}
          <div className="grid grid-cols-3 gap-3 text-center text-xs">
            <div className="p-3 bg-slate-50 border border-[#cbd5e1] rounded-lg">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Total Percentage</span>
              <span className="text-base font-black font-mono text-[#1e3a8a]">{result.percentage.toFixed(2)}%</span>
            </div>
            <div className="p-3 bg-slate-50 border border-[#cbd5e1] rounded-lg">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Overall Grade</span>
              <span className="text-base font-black font-mono text-emerald-700">{result.overallGrade}</span>
            </div>
            <div className="p-3 bg-slate-50 border border-[#cbd5e1] rounded-lg">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Final Classification</span>
              <span className={`text-base font-black uppercase ${
                result.resultStatus === 'Pass' ? 'text-emerald-700' : 'text-red-700'
              }`}>
                {result.resultStatus === 'Pass' ? 'PASSED & PROMOTED' : 'REQUIRES RETEST / FAIL'}
              </span>
            </div>
          </div>

          {/* Signatures */}
          <div className="pt-10 grid grid-cols-3 gap-6 text-center text-xs">
            <div>
              <div className="border-b border-[#94a3b8] h-10 mb-1 flex items-end justify-center">
                <span className="font-serif italic text-xs text-[#64748b]">System Evaluator</span>
              </div>
              <span className="text-[10px] font-bold text-[#64748b] uppercase">Course Faculty / Evaluator</span>
            </div>
            <div>
              <div className="border-b border-[#94a3b8] h-10 mb-1 flex items-end justify-center">
                <span className="font-serif italic font-bold text-xs text-[#1e3a8a]">Controller of Examinations</span>
              </div>
              <span className="text-[10px] font-bold text-[#64748b] uppercase block">Controller of Examinations / Examination Cell</span>
              <span className="text-[9px] text-[#94a3b8]">Office of Examination Cell</span>
            </div>
            <div>
              <div className="border-b border-[#94a3b8] h-10 mb-1 flex items-end justify-center">
                <span className="font-serif italic font-bold text-xs text-[#1e3a8a]">Principal</span>
              </div>
              <span className="text-[10px] font-bold text-[#64748b] uppercase block">Principal / Dean</span>
              <span className="text-[9px] text-[#94a3b8]">Head of Institution</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
