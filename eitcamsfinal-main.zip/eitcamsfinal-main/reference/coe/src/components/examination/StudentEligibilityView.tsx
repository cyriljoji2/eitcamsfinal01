import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  Download,
  ShieldAlert,
} from 'lucide-react';
import { Examination, StudentExamEligibility } from '../../types/examination';
import { AcademicClass } from '../../types/academic';
import { Button } from '../ui/Button';

interface StudentEligibilityViewProps {
  examinations: Examination[];
  eligibilities: StudentExamEligibility[];
  classes: AcademicClass[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenEligibilityModal: (eligibility: StudentExamEligibility) => void;
  onSyncEligibility: (examId: string) => Promise<void>;
  onBulkSetEligible: (examId: string, className?: string) => Promise<void>;
}

export function StudentEligibilityView({
  examinations,
  eligibilities,
  classes,
  selectedExamId,
  onSelectExamId,
  onOpenEligibilityModal,
  onSyncEligibility,
  onBulkSetEligible,
}: StudentEligibilityViewProps) {
  const [classFilter, setClassFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || '';

  const filteredList = eligibilities.filter((el) => {
    const matchesExam = el.examinationId === activeExamId;
    const matchesClass = classFilter === 'All' || el.className === classFilter;
    const matchesStatus =
      statusFilter === 'All' ||
      (statusFilter === 'Eligible' && el.isEligible) ||
      (statusFilter === 'Ineligible' && !el.isEligible);
    const matchesSearch =
      el.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      el.studentRegistrationNumber.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesExam && matchesClass && matchesStatus && matchesSearch;
  });

  const totalStudents = eligibilities.filter((e) => e.examinationId === activeExamId).length;
  const eligibleCount = eligibilities.filter(
    (e) => e.examinationId === activeExamId && e.isEligible
  ).length;
  const ineligibleCount = totalStudents - eligibleCount;

  const handleSync = async () => {
    if (!activeExamId) return;
    setIsSyncing(true);
    try {
      await onSyncEligibility(activeExamId);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleBulkApprove = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to mark all students in ${
          classFilter === 'All' ? 'all classes' : classFilter
        } as eligible for examination ${activeExamId}?`
      )
    ) {
      await onBulkSetEligible(activeExamId, classFilter === 'All' ? undefined : classFilter);
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Registration No',
      'Student Name',
      'Class',
      'Section',
      'Exam ID',
      'Eligible',
      'Ineligibility Reason',
    ];
    const rows = filteredList.map((e) => [
      e.studentRegistrationNumber,
      `"${e.studentName.replace(/"/g, '""')}"`,
      e.className,
      e.section,
      e.examinationId,
      e.isEligible ? 'YES' : 'NO',
      `"${(e.ineligibilityReason || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `eligibility_roster_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Student Examination Eligibility Registry
          </h1>
          <p className="text-xs text-[#64748b]">
            Verify candidate admission statuses, attendance thresholds, and manage examination access permissions
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSync}
            disabled={isSyncing || !activeExamId}
            className="text-xs gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>Sync Admission Students</span>
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5">
            <Download className="w-3.5 h-3.5" />
            <span>Export Roster</span>
          </Button>
          <Button size="sm" onClick={handleBulkApprove} className="text-xs gap-1.5 bg-emerald-700 hover:bg-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Mark All Eligible</span>
          </Button>
        </div>
      </div>

      {/* Summary KPI Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Total Enrolled Candidates</div>
            <div className="text-xl font-black text-[#1e293b]">{totalStudents}</div>
          </div>
          <div className="p-2 bg-blue-50 text-[#1e3a8a] rounded-lg">
            <Users className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Eligible for Hall Tickets</div>
            <div className="text-xl font-black text-emerald-700">{eligibleCount}</div>
          </div>
          <div className="p-2 bg-emerald-50 text-emerald-700 rounded-lg">
            <CheckCircle2 className="w-4 h-4" />
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-[#cbd5e1] flex items-center justify-between shadow-2xs">
          <div>
            <div className="text-[10px] uppercase font-bold text-[#64748b]">Ineligible / Excluded</div>
            <div className="text-xl font-black text-red-700">{ineligibleCount}</div>
          </div>
          <div className="p-2 bg-red-50 text-red-700 rounded-lg">
            <ShieldAlert className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] grid grid-cols-1 sm:grid-cols-4 gap-3 shadow-2xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Active Examination
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.id})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Filter by Class
          </label>
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Classes</option>
            {classes.map((cls) => (
              <option key={cls.id} value={cls.name}>
                {cls.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Eligibility Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
          >
            <option value="All">All Statuses</option>
            <option value="Eligible">Eligible Only</option>
            <option value="Ineligible">Ineligible / Excluded</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-[#64748b] mb-1">
            Search Candidate
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name or reg no..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>
        </div>
      </div>

      {/* Eligibility Table */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
              <tr>
                <th className="py-3 px-4">Registration No</th>
                <th className="py-3 px-4">Student Name</th>
                <th className="py-3 px-4">Class & Section</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4">Ineligibility Reason / Notes</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredList.map((el) => (
                <tr key={el.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                    {el.studentRegistrationNumber}
                  </td>
                  <td className="py-3 px-4 font-bold text-[#1e293b]">
                    {el.studentName}
                  </td>
                  <td className="py-3 px-4 text-[#1e293b]">
                    {el.className} — {el.section}
                  </td>
                  <td className="py-3 px-4 text-center whitespace-nowrap">
                    {el.isEligible ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                        <CheckCircle2 className="w-3 h-3" /> Eligible
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-red-100 text-red-800">
                        <XCircle className="w-3 h-3" /> Ineligible
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-[#64748b]">
                    {el.ineligibilityReason ? (
                      <span className="text-red-700 font-medium text-[11px]">
                        {el.ineligibilityReason}
                      </span>
                    ) : (
                      <span className="text-[#94a3b8] italic">Eligible for all papers</span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onOpenEligibilityModal(el)}
                      className="text-[11px] py-1 px-2.5 h-auto"
                    >
                      {el.isEligible ? 'Exclude' : 'Edit / Include'}
                    </Button>
                  </td>
                </tr>
              ))}
              {filteredList.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-[#64748b] text-xs">
                    No student eligibility records found for this examination. Click "Sync Admission Students" to populate.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
