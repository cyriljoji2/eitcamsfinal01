import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  variant?: 'neutral' | 'blue' | 'emerald' | 'amber' | 'purple' | 'rose' | 'slate' | 'secondary' | 'success' | 'default';
  size?: 'sm' | 'md';
  className?: string;
}

export function Badge({
  children,
  variant = 'neutral',
  size = 'md',
  className = '',
}: BadgeProps) {
  const variantStyles = {
    neutral: 'bg-[#f1f5f9] text-[#475569] border-[#e2e8f0]',
    slate: 'bg-[#f1f5f9] text-[#475569] border-[#e2e8f0]',
    secondary: 'bg-[#f1f5f9] text-[#475569] border-[#e2e8f0]',
    default: 'bg-[#f1f5f9] text-[#475569] border-[#e2e8f0]',
    blue: 'bg-[#eff6ff] text-[#1e3a8a] border-[#dbeafe]',
    emerald: 'bg-[#dcfce7] text-[#166534] border-[#bbf7d0]',
    success: 'bg-[#dcfce7] text-[#166534] border-[#bbf7d0]',
    amber: 'bg-[#fef3c7] text-[#92400e] border-[#fde68a]',
    purple: 'bg-[#f3e8ff] text-[#6b21a8] border-[#e9d5ff]',
    rose: 'bg-[#fee2e2] text-[#991b1b] border-[#fecaca]',
  };

  const sizeStyles = {
    sm: 'px-2.5 py-0.5 text-xs font-semibold',
    md: 'px-3 py-1 text-xs font-semibold',
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border whitespace-nowrap ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {children}
    </span>
  );
}
