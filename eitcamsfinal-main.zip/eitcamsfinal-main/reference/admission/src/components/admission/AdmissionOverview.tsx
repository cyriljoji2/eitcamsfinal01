import {
  Users,
  Clock,
  FileCheck2,
  CheckCircle2,
  XCircle,
  UserPlus,
  UploadCloud,
  ArrowRight,
  TrendingUp,
  GraduationCap,
  Eye,
} from 'lucide-react';
import { Student, AdmissionStatus } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { AdmissionTab } from './AdmissionWorkspace';

export interface AdmissionOverviewProps {
  students: Student[];
  onNavigateToTab: (tab: AdmissionTab) => void;
  onOpenNewAdmission: () => void;
  onSelectStudent: (student: Student) => void;
}

export function AdmissionOverview({
  students,
  onNavigateToTab,
  onOpenNewAdmission,
  onSelectStudent,
}: AdmissionOverviewProps) {
  const totalRecords = students.length;
  const approvedCount = students.filter((s) => s.admissionStatus === 'Approved').length;
  const pendingCount = students.filter(
    (s) =>
      s.admissionStatus === 'Application' ||
      s.admissionStatus === 'Documents Pending' ||
      s.admissionStatus === 'Documents Under Verification'
  ).length;
  const rejectedCount = students.filter((s) => s.admissionStatus === 'Rejected').length;

  // Documents Pending Verification across all students
  let docsPendingVerificationCount = 0;
  for (const s of students) {
    for (const d of s.documents) {
      if (d.status === 'Submitted' || d.status === 'Pending') {
        docsPendingVerificationCount++;
      }
    }
  }

  // Recent 6 admissions / applications
  const recentAdmissions = [...students]
    .sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime())
    .slice(0, 6);

  // Pipeline distribution counts
  const stageCounts: Record<AdmissionStatus, number> = {
    Application: students.filter((s) => s.admissionStatus === 'Application').length,
    'Documents Pending': students.filter((s) => s.admissionStatus === 'Documents Pending').length,
    'Documents Under Verification': students.filter(
      (s) => s.admissionStatus === 'Documents Under Verification'
    ).length,
    Approved: approvedCount,
    Rejected: rejectedCount,
  };

  const getStatusBadge = (status: AdmissionStatus) => {
    switch (status) {
      case 'Approved':
        return <Badge variant="emerald">Approved</Badge>;
      case 'Application':
        return <Badge variant="blue">Application</Badge>;
      case 'Documents Pending':
        return <Badge variant="amber">Docs Pending</Badge>;
      case 'Documents Under Verification':
        return <Badge variant="purple">Under Verification</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome with Quick Actions */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-[20px] font-bold text-[#1e293b]">Admission Office Control Center</h2>
            <Badge variant="blue">Intake 2026–2027</Badge>
          </div>
          <p className="text-xs text-[#64748b]">
            Manage student enrollment applications, verify documentation, and provision portal accounts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('import')}
            leftIcon={<UploadCloud className="w-4 h-4" />}
          >
            Bulk CSV Import
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenNewAdmission}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            New Admission
          </Button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Students/Admissions */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Total Admissions</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-[#1e293b]">{totalRecords}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Active applications & roster</span>
        </div>

        {/* Pending Applications */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Pending Pipeline</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-amber-900">{pendingCount}</div>
          <span className="text-[11px] text-amber-700 mt-1 block">Awaiting review / docs</span>
        </div>

        {/* Documents Pending Verification */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Docs For Review</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-purple-900">{docsPendingVerificationCount}</div>
          <span className="text-[11px] text-purple-700 mt-1 block">Pending validation</span>
        </div>

        {/* Approved Admissions */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Approved Students</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-900">{approvedCount}</div>
          <span className="text-[11px] text-emerald-700 mt-1 block">Provisioned with Reg No</span>
        </div>

        {/* Rejected Admissions */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Rejected</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-900">{rejectedCount}</div>
          <span className="text-[11px] text-rose-700 mt-1 block">Declined applications</span>
        </div>
      </div>

      {/* Admission Pipeline Funnel */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-[15px] font-bold text-[#1e293b]">Admission Pipeline Breakdown</h3>
            <p className="text-xs text-[#64748b]">Live distribution of applicants across admission stages</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('admissions')}
            rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
          >
            Manage Pipeline
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg">
            <span className="text-[#64748b] block font-medium mb-1">1. Application</span>
            <span className="text-lg font-bold text-[#1e293b]">{stageCounts.Application}</span>
          </div>

          <div className="bg-amber-50/50 border border-amber-200/60 p-3 rounded-lg">
            <span className="text-amber-800 block font-medium mb-1">2. Docs Pending</span>
            <span className="text-lg font-bold text-amber-950">{stageCounts['Documents Pending']}</span>
          </div>

          <div className="bg-purple-50/50 border border-purple-200/60 p-3 rounded-lg">
            <span className="text-purple-800 block font-medium mb-1">3. Verifying Docs</span>
            <span className="text-lg font-bold text-purple-950">{stageCounts['Documents Under Verification']}</span>
          </div>

          <div className="bg-emerald-50/50 border border-emerald-200/60 p-3 rounded-lg">
            <span className="text-emerald-800 block font-medium mb-1">4. Approved</span>
            <span className="text-lg font-bold text-emerald-950">{stageCounts.Approved}</span>
          </div>

          <div className="bg-rose-50/50 border border-rose-200/60 p-3 rounded-lg">
            <span className="text-rose-800 block font-medium mb-1">5. Rejected</span>
            <span className="text-lg font-bold text-rose-950">{stageCounts.Rejected}</span>
          </div>
        </div>
      </div>

      {/* Recent Admissions & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Admissions Table */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs lg:col-span-2 overflow-hidden">
          <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div>
              <h3 className="text-[15px] font-bold text-[#1e293b]">Recent Admissions & Applications</h3>
              <p className="text-xs text-[#64748b]">Latest recorded applicant submissions</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigateToTab('admissions')}
              rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
            >
              View All
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] font-semibold">
                <tr>
                  <th className="py-3 px-4">Student / Applicant</th>
                  <th className="py-3 px-4">Class & Sec</th>
                  <th className="py-3 px-4">Reg / Tracking ID</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {recentAdmissions.map((student) => (
                  <tr key={student.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">{student.fullName}</div>
                      <div className="text-[11px] text-[#64748b]">{student.mobile}</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-[#1e293b]">
                      {student.admissionClass} (Sec {student.section})
                    </td>
                    <td className="py-3 px-4 font-mono text-[#1e3a8a]">
                      {student.registrationNumber || student.id}
                    </td>
                    <td className="py-3 px-4">{getStatusBadge(student.admissionStatus)}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => onSelectStudent(student)}
                        className="text-[#1e3a8a] hover:underline font-semibold text-xs cursor-pointer inline-flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Navigation / Shortcuts */}
        <div className="space-y-4">
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3">
            <h4 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Admission Office Modules
            </h4>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => onNavigateToTab('admissions')}
                className="w-full flex items-center justify-between p-3 rounded-lg border border-[#e2e8f0] hover:border-[#1e3a8a] hover:bg-[#eff6ff]/30 transition-all text-left cursor-pointer"
              >
                <div>
                  <span className="font-bold text-xs text-[#1e293b] block">1. Admissions Pipeline</span>
                  <span className="text-[11px] text-[#64748b]">Review and approve incoming applications</span>
                </div>
                <ArrowRight className="w-4 h-4 text-[#64748b]" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateToTab('students')}
                className="w-full flex items-center justify-between p-3 rounded-lg border border-[#e2e8f0] hover:border-[#1e3a8a] hover:bg-[#eff6ff]/30 transition-all text-left cursor-pointer"
              >
                <div>
                  <span className="font-bold text-xs text-[#1e293b] block">2. Enrolled Students</span>
                  <span className="text-[11px] text-[#64748b]">Active roster, credentials, and class batches</span>
                </div>
                <ArrowRight className="w-4 h-4 text-[#64748b]" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateToTab('documents')}
                className="w-full flex items-center justify-between p-3 rounded-lg border border-[#e2e8f0] hover:border-[#1e3a8a] hover:bg-[#eff6ff]/30 transition-all text-left cursor-pointer"
              >
                <div>
                  <span className="font-bold text-xs text-[#1e293b] block">3. Document Verification</span>
                  <span className="text-[11px] text-[#64748b]">Validate birth certs, marksheet records</span>
                </div>
                <ArrowRight className="w-4 h-4 text-[#64748b]" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateToTab('import')}
                className="w-full flex items-center justify-between p-3 rounded-lg border border-[#e2e8f0] hover:border-[#1e3a8a] hover:bg-[#eff6ff]/30 transition-all text-left cursor-pointer"
              >
                <div>
                  <span className="font-bold text-xs text-[#1e293b] block">4. Bulk CSV Intake</span>
                  <span className="text-[11px] text-[#64748b]">Batch student account provisioning</span>
                </div>
                <ArrowRight className="w-4 h-4 text-[#64748b]" />
              </button>
            </div>
          </div>

          <div className="bg-[#eff6ff] border border-[#dbeafe] rounded-xl p-4 text-xs text-[#1e3a8a] space-y-1.5">
            <span className="font-bold block">Google Sheets Data Layer Readiness</span>
            <p className="text-[#3b82f6] leading-relaxed">
              All student profiles and admission document registers are abstracted via <code>IStudentRepository</code> & <code>IAdmissionRepository</code> for seamless future Google Sheets synchronization.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
