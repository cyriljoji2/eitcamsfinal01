import React, { useState } from 'react';
import {
  FileCheck2,
  X,
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar,
  User,
} from 'lucide-react';
import { StudentDocument, StudentDocumentStatus } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface DocumentVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: StudentDocument | null;
  studentName?: string;
  studentClass?: string;
  onUpdateStatus: (
    docId: string,
    status: StudentDocumentStatus,
    remarks: string
  ) => Promise<void>;
}

export function DocumentVerificationModal({
  isOpen,
  onClose,
  document,
  studentName = 'Student',
  studentClass,
  onUpdateStatus,
}: DocumentVerificationModalProps) {
  if (!isOpen || !document) return null;

  const [selectedStatus, setSelectedStatus] = useState<StudentDocumentStatus>(document.status);
  const [remarks, setRemarks] = useState<string>(document.remarks || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onUpdateStatus(document.id, selectedStatus, remarks);
      onClose();
    } catch (err) {
      console.error('Failed to update document status', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusBadge = (status: StudentDocumentStatus) => {
    switch (status) {
      case 'Verified':
        return <Badge variant="emerald">Verified</Badge>;
      case 'Submitted':
        return <Badge variant="blue">Submitted / Pending Review</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      case 'Pending':
      default:
        return <Badge variant="amber">Pending Upload</Badge>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-lg w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center border border-[#dbeafe]">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-[16px] font-bold text-[#1e293b]">Document Verification</h3>
              <p className="text-xs text-[#64748b]">Review and approve applicant submission</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Document Summary Card */}
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold text-[#94a3b8] uppercase tracking-wider block">
                  Document Type
                </span>
                <span className="text-[15px] font-bold text-[#1e293b]">
                  {document.documentType}
                </span>
              </div>
              {getStatusBadge(document.status)}
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-[#e2e8f0]">
              <div>
                <span className="text-[#64748b] block font-medium">Applicant</span>
                <span className="font-semibold text-[#1e293b] flex items-center gap-1 mt-0.5">
                  <User className="w-3.5 h-3.5 text-[#64748b]" />
                  {studentName} {studentClass ? `(${studentClass})` : ''}
                </span>
              </div>
              <div>
                <span className="text-[#64748b] block font-medium">File Attachment</span>
                <span className="font-medium text-[#1e3a8a] flex items-center gap-1 mt-0.5 truncate">
                  <FileText className="w-3.5 h-3.5 shrink-0" />
                  {document.fileName || 'document_scan.pdf'}
                </span>
              </div>
            </div>

            {document.uploadedDate && (
              <div className="text-xs text-[#64748b] flex items-center gap-1.5 pt-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>Uploaded on {document.uploadedDate}</span>
              </div>
            )}
          </div>

          {/* Status Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Verification Decision
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedStatus('Verified')}
                className={`flex flex-col items-center justify-center p-3 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
                  selectedStatus === 'Verified'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-[#f8fafc]'
                }`}
              >
                <CheckCircle2 className="w-5 h-5 text-emerald-600 mb-1" />
                <span>Verify & Pass</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus('Submitted')}
                className={`flex flex-col items-center justify-center p-3 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
                  selectedStatus === 'Submitted'
                    ? 'bg-blue-50 border-blue-500 text-blue-800 ring-2 ring-blue-500/20'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-[#f8fafc]'
                }`}
              >
                <Clock className="w-5 h-5 text-blue-600 mb-1" />
                <span>Under Review</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus('Rejected')}
                className={`flex flex-col items-center justify-center p-3 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
                  selectedStatus === 'Rejected'
                    ? 'bg-rose-50 border-rose-500 text-rose-800 ring-2 ring-rose-500/20'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-[#f8fafc]'
                }`}
              >
                <XCircle className="w-5 h-5 text-rose-600 mb-1" />
                <span>Reject / Resubmit</span>
              </button>
            </div>
          </div>

          {/* Remarks & Notes */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Verification Remarks / Instructions
            </label>
            <textarea
              rows={3}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Original birth certificate certified by registrar. or Please upload a clearer scan."
              className="w-full rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] text-sm p-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none placeholder:text-[#94a3b8]"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#e2e8f0]">
            <Button type="button" variant="outline" size="md" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="md" isLoading={isSubmitting}>
              Save Verification
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
