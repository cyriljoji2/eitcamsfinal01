import { useState, useMemo } from 'react';
import {
  Search,
  KeyRound,
  Eye,
  Edit2,
  Power,
  RotateCcw,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  UserPlus,
  AlertCircle,
  FileCheck2,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { Student, AdmissionStatus, StudentAccountStatus } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface StudentManagementViewProps {
  students: Student[];
  onOpenNewAdmission: () => void;
  onSelectStudent: (student: Student) => void;
  onResetPassword: (student: Student) => Promise<void>;
  onToggleAccountStatus: (student: Student) => Promise<void>;
}

export function StudentManagementView({
  students,
  onOpenNewAdmission,
  onSelectStudent,
  onResetPassword,
  onToggleAccountStatus,
}: StudentManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [sectionFilter, setSectionFilter] = useState('all');
  const [admissionStatusFilter, setAdmissionStatusFilter] = useState('all');
  const [accountStatusFilter, setAccountStatusFilter] = useState('all');

  const uniqueClasses = useMemo(() => {
    return Array.from(new Set(students.map((s) => s.admissionClass))).sort();
  }, [students]);

  const uniqueSections = useMemo(() => {
    return Array.from(new Set(students.map((s) => s.section))).sort();
  }, [students]);

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const searchMatch =
        s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (s.registrationNumber && s.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (s.email && s.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        s.mobile.includes(searchTerm);

      const classMatch = classFilter === 'all' || s.admissionClass === classFilter;
      const sectionMatch = sectionFilter === 'all' || s.section === sectionFilter;
      const admissionMatch =
        admissionStatusFilter === 'all' || s.admissionStatus === admissionStatusFilter;
      const accountMatch =
        accountStatusFilter === 'all' || s.accountStatus === accountStatusFilter;

      return searchMatch && classMatch && sectionMatch && admissionMatch && accountMatch;
    });
  }, [students, searchTerm, classFilter, sectionFilter, admissionStatusFilter, accountStatusFilter]);

  const getAdmissionStatusBadge = (status: AdmissionStatus) => {
    switch (status) {
      case 'Approved':
        return <Badge variant="emerald">Approved</Badge>;
      case 'Application':
        return <Badge variant="blue">Application</Badge>;
      case 'Documents Pending':
        return <Badge variant="amber">Docs Pending</Badge>;
      case 'Documents Under Verification':
        return <Badge variant="purple">Under Verification</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">Student Records & Account Management</h2>
          <p className="text-xs text-[#64748b]">
            Enrolled student roster, Registration Numbers, and Portal authentication credentials
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onOpenNewAdmission}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          Add Student
        </Button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by student name or Registration No..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Class Filter */}
          <div>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Classes</option>
              {uniqueClasses.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Section Filter */}
          <div>
            <select
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Sections</option>
              {uniqueSections.map((s) => (
                <option key={s} value={s}>
                  Section {s}
                </option>
              ))}
            </select>
          </div>

          {/* Account Status Filter */}
          <div>
            <select
              value={accountStatusFilter}
              onChange={(e) => setAccountStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Account States</option>
              <option value="active">Active Accounts</option>
              <option value="inactive">Inactive Accounts</option>
            </select>
          </div>
        </div>
      </div>

      {/* Student Management Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span>
            Displaying <strong className="text-[#1e293b]">{filteredStudents.length}</strong> of{' '}
            <strong className="text-[#1e293b]">{students.length}</strong> students
          </span>
        </div>

        {filteredStudents.length === 0 ? (
          <div className="p-12 text-center text-xs space-y-2">
            <AlertCircle className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <p className="font-semibold text-[#1e293b]">No students match the current criteria</p>
            <p className="text-[#64748b]">Clear the search filter or add a student to the directory.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] font-semibold">
                <tr>
                  <th className="py-3 px-4">Registration No</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Class & Section</th>
                  <th className="py-3 px-4">Admission Status</th>
                  <th className="py-3 px-4">Account Access</th>
                  <th className="py-3 px-4">Admission Date</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredStudents.map((student) => {
                  const regNo = student.registrationNumber || student.id;

                  return (
                    <tr key={student.id} className="hover:bg-[#f8fafc] transition-colors">
                      {/* Registration Number (Primary ID) */}
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-[#1e3a8a] text-xs bg-[#eff6ff] px-2 py-0.5 rounded border border-[#dbeafe]">
                          {regNo}
                        </span>
                      </td>

                      {/* Name & Guardian */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#1e293b] text-[13px]">{student.fullName}</div>
                        <div className="text-[11px] text-[#64748b]">
                          Guardian: {student.guardianName || student.fatherName || 'Parent'}
                        </div>
                      </td>

                      {/* Class & Section */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#1e293b]">
                          {student.admissionClass}
                        </div>
                        <div className="text-[11px] text-[#64748b]">Section {student.section}</div>
                      </td>

                      {/* Admission Status */}
                      <td className="py-3 px-4">
                        {getAdmissionStatusBadge(student.admissionStatus)}
                      </td>

                      {/* Account Status Toggle */}
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => onToggleAccountStatus(student)}
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold border cursor-pointer transition-colors ${
                            student.accountStatus === 'active'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                          }`}
                          title="Click to toggle account access"
                        >
                          <Power className="w-3 h-3" />
                          <span>{student.accountStatus === 'active' ? 'Active' : 'Inactive'}</span>
                        </button>
                      </td>

                      {/* Admission Date */}
                      <td className="py-3 px-4 text-[#64748b] font-medium">
                        {student.admissionDate}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onResetPassword(student)}
                            leftIcon={<KeyRound className="w-3.5 h-3.5" />}
                            title="Generate new temporary password"
                          >
                            Reset Password
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onSelectStudent(student)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                          >
                            View
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
