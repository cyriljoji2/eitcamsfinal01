import { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  ClipboardList,
  Users,
  FileCheck2,
  UploadCloud,
  LogOut,
  Menu,
  X,
  School,
  GraduationCap,
  Sparkles,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import {
  Student,
  StudentFormData,
  AdmissionStatus,
  StudentDocumentStatus,
} from '../../types/admission';
import { admissionRepository } from '../../services/admissionService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { SyncStatusBadge } from '../common/SyncStatusBadge';
import { AdmissionOverview } from './AdmissionOverview';
import { AdmissionApplicationsView } from './AdmissionApplicationsView';
import { StudentManagementView } from './StudentManagementView';
import { DocumentManagementView } from './DocumentManagementView';
import { BulkStudentImportView } from './BulkStudentImportView';
import { NewAdmissionModal } from './NewAdmissionModal';
import { StudentDetailModal } from './StudentDetailModal';
import { StudentCredentialsModal } from './StudentCredentialsModal';

export type AdmissionTab = 'overview' | 'admissions' | 'students' | 'documents' | 'import';

export interface AdmissionWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export function AdmissionWorkspace({ user, onLogout }: AdmissionWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<AdmissionTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [students, setStudents] = useState<Student[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modal States
  const [isNewAdmissionOpen, setIsNewAdmissionOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [credentialsModalState, setCredentialsModalState] = useState<{
    isOpen: boolean;
    title?: string;
    description?: string;
    items: Array<{ student: Student; temporaryPassword?: string }>;
  }>({
    isOpen: false,
    items: [],
  });

  // Load students from repository
  const loadStudents = async () => {
    setIsLoading(true);
    try {
      const data = await admissionRepository.getAllStudents();
      setStudents(data);
    } catch (err) {
      console.error('Failed to load admission students', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStudents();
    const unsubscribe = admissionRepository.subscribe?.((updatedStudents) => {
      setStudents(updatedStudents);
    });
    return () => {
      unsubscribe?.();
    };
  }, []);

  // Handle New Admission Submission
  const handleCreateAdmission = async (formData: StudentFormData) => {
    const created = await admissionRepository.createAdmission(formData);
    await loadStudents();

    // If approved, pop up credentials modal immediately
    if (created.admissionStatus === 'Approved' && created.temporaryPassword) {
      setCredentialsModalState({
        isOpen: true,
        title: 'New Student Admission & Credentials',
        description:
          'Admission approved. A sequential Registration Number and temporary password have been generated for portal access.',
        items: [
          {
            student: created,
            temporaryPassword: created.temporaryPassword,
          },
        ],
      });
    }
  };

  // Handle Quick Approve
  const handleApproveAdmission = async (student: Student) => {
    const approved = await admissionRepository.approveAdmission(student.id);
    await loadStudents();

    setCredentialsModalState({
      isOpen: true,
      title: 'Admission Approved & Account Provisioned',
      description:
        'Registration Number allocated. Please issue these credentials to the student or guardian for first login.',
      items: [
        {
          student: approved,
          temporaryPassword: approved.temporaryPassword || 'password123',
        },
      ],
    });
  };

  // Handle Status Update
  const handleUpdateAdmissionStatus = async (studentId: string, status: AdmissionStatus) => {
    await admissionRepository.updateAdmissionStatus(studentId, status);
    await loadStudents();
  };

  // Handle Student Update from Details modal
  const handleUpdateStudentDetails = async (id: string, updates: Partial<StudentFormData>) => {
    const updated = await admissionRepository.updateStudent(id, updates);
    await loadStudents();
    setSelectedStudent(updated);
    return updated;
  };

  // Handle Document Verification
  const handleVerifyDocument = async (
    docId: string,
    status: StudentDocumentStatus,
    remarks: string
  ) => {
    await admissionRepository.verifyDocument(docId, status, user.name || 'Admission Officer', remarks);
    await loadStudents();

    if (selectedStudent) {
      const refreshed = await admissionRepository.getStudentById(selectedStudent.id);
      if (refreshed) setSelectedStudent(refreshed);
    }
  };

  // Handle Account Status Toggle
  const handleToggleAccountStatus = async (student: Student) => {
    const nextStatus = student.accountStatus === 'active' ? 'inactive' : 'active';
    await admissionRepository.setAccountStatus(student.id, nextStatus);
    await loadStudents();

    if (selectedStudent && selectedStudent.id === student.id) {
      const refreshed = await admissionRepository.getStudentById(student.id);
      if (refreshed) setSelectedStudent(refreshed);
    }
  };

  // Handle Reset Password
  const handleResetPassword = async (student: Student) => {
    const result = await admissionRepository.resetPassword(student.id);
    await loadStudents();

    if (selectedStudent && selectedStudent.id === student.id) {
      setSelectedStudent(result.student);
    }

    setCredentialsModalState({
      isOpen: true,
      title: 'Student Password Reset Complete',
      description:
        'A new temporary password has been generated. The student must use this to sign in and update their password.',
      items: [
        {
          student: result.student,
          temporaryPassword: result.temporaryPassword,
        },
      ],
    });
  };

  // Handle Batch CSV Import
  const handleBatchImport = async (validItems: StudentFormData[]) => {
    const result = await admissionRepository.bulkCreateStudents(validItems);
    await loadStudents();

    // Launch credentials modal with all newly imported students!
    setCredentialsModalState({
      isOpen: true,
      title: 'Batch Student Intake - Account Credentials',
      description:
        'All imported students have been allocated sequential Registration Numbers and individual temporary passwords.',
      items: result.students.map((s) => ({
        student: s,
        temporaryPassword: result.temporaryPasswords[s.registrationNumber] || s.temporaryPassword || 'password123',
      })),
    });

    return result.students;
  };

  // Handle Delete Application
  const handleDeleteApplication = async (studentId: string) => {
    if (window.confirm('Are you sure you want to permanently delete this application record?')) {
      await admissionRepository.deleteStudent(studentId);
      await loadStudents();
      if (selectedStudent?.id === studentId) {
        setSelectedStudent(null);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
      {/* Top Navigation Bar */}
      <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & School Name */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
                <School className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-[15px] text-[#1e293b] block leading-tight">
                  Electrix Institute of Technology (EIT)
                </span>
                <span className="text-[11px] font-semibold text-[#1e3a8a] tracking-wide block">
                  ADMISSION OFFICE
                </span>
              </div>
            </div>
          </div>

          {/* Right Header items */}
          <div className="flex items-center gap-3">
            <SyncStatusBadge />
            <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 bg-[#eff6ff] rounded-md border border-[#dbeafe] text-xs font-semibold text-[#1e3a8a]">
              <span>Academic Session 2026–2027</span>
            </div>

            <div className="flex items-center gap-2.5 pl-2 border-l border-[#e2e8f0]">
              <div className="hidden md:block text-right">
                <span className="text-xs font-bold text-[#1e293b] block">{user.name}</span>
                <span className="text-[11px] text-[#64748b] block">{user.roleTitle}</span>
              </div>

              <div className="w-8 h-8 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center font-bold text-xs border border-[#dbeafe]">
                {user.name.charAt(0)}
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
                className="text-[#64748b] hover:text-rose-600 p-1.5"
                title="Sign out of Admission Office"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Body with Sidebar + View */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6">
        {/* Sidebar Navigation */}
        <aside
          className={`lg:w-64 shrink-0 space-y-6 ${
            mobileMenuOpen ? 'block' : 'hidden lg:block'
          }`}
        >
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-3 shadow-xs space-y-1">
            <button
              type="button"
              onClick={() => {
                setActiveTab('overview');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Overview</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('admissions');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'admissions'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
              }`}
            >
              <div className="flex items-center gap-3">
                <ClipboardList className="w-4 h-4" />
                <span>Admissions Pipeline</span>
              </div>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                  activeTab === 'admissions'
                    ? 'bg-blue-900 text-white'
                    : 'bg-[#f1f5f9] text-[#64748b]'
                }`}
              >
                {students.filter((s) => s.admissionStatus !== 'Approved').length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('students');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'students'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
              }`}
            >
              <div className="flex items-center gap-3">
                <Users className="w-4 h-4" />
                <span>Students Roster</span>
              </div>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                  activeTab === 'students'
                    ? 'bg-blue-900 text-white'
                    : 'bg-[#f1f5f9] text-[#64748b]'
                }`}
              >
                {students.filter((s) => s.admissionStatus === 'Approved').length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('documents');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'documents'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
              }`}
            >
              <FileCheck2 className="w-4 h-4" />
              <span>Document Verification</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('import');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'import'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
              }`}
            >
              <UploadCloud className="w-4 h-4" />
              <span>Bulk CSV Import</span>
            </button>
          </div>

          {/* Admission Officer Quick Profile Card */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs text-xs space-y-2.5">
            <span className="font-bold text-[#1e293b] block uppercase tracking-wider text-[10px] text-[#94a3b8]">
              Authorized Operator
            </span>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center font-bold text-xs">
                <UserCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-[#1e293b] block">{user.name}</span>
                <span className="text-[#64748b] text-[11px]">Admission Staff ID: {user.id}</span>
              </div>
            </div>
            <div className="pt-2 border-t border-[#e2e8f0] text-[11px] text-[#64748b]">
              Assigned Office: <strong>Admission & Registrar</strong>
            </div>
          </div>
        </aside>

        {/* View Content Area */}
        <main className="flex-1 min-w-0">
          {activeTab === 'overview' && (
            <AdmissionOverview
              students={students}
              onNavigateToTab={(tab) => setActiveTab(tab)}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectStudent={(s) => setSelectedStudent(s)}
            />
          )}

          {activeTab === 'admissions' && (
            <AdmissionApplicationsView
              students={students}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectStudent={(s) => setSelectedStudent(s)}
              onApproveAdmission={handleApproveAdmission}
              onUpdateStatus={handleUpdateAdmissionStatus}
              onDeleteApplication={handleDeleteApplication}
            />
          )}

          {activeTab === 'students' && (
            <StudentManagementView
              students={students}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectStudent={(s) => setSelectedStudent(s)}
              onResetPassword={handleResetPassword}
              onToggleAccountStatus={handleToggleAccountStatus}
            />
          )}

          {activeTab === 'documents' && (
            <DocumentManagementView
              students={students}
              onVerifyDocument={handleVerifyDocument}
              onSelectStudent={(s) => setSelectedStudent(s)}
            />
          )}

          {activeTab === 'import' && (
            <BulkStudentImportView
              existingStudents={students}
              onBatchImport={handleBatchImport}
            />
          )}
        </main>
      </div>

      {/* MODALS */}
      {/* 1. New Admission Modal */}
      <NewAdmissionModal
        isOpen={isNewAdmissionOpen}
        onClose={() => setIsNewAdmissionOpen(false)}
        onSubmit={handleCreateAdmission}
      />

      {/* 2. Student Detail & Edit Modal */}
      <StudentDetailModal
        isOpen={!!selectedStudent}
        student={selectedStudent}
        onClose={() => setSelectedStudent(null)}
        onUpdate={handleUpdateStudentDetails}
        onToggleAccountStatus={handleToggleAccountStatus}
        onResetPassword={handleResetPassword}
        onVerifyDocument={handleVerifyDocument}
      />

      {/* 3. Student Credentials Issuance Modal */}
      <StudentCredentialsModal
        isOpen={credentialsModalState.isOpen}
        onClose={() => setCredentialsModalState((prev) => ({ ...prev, isOpen: false }))}
        title={credentialsModalState.title}
        description={credentialsModalState.description}
        items={credentialsModalState.items}
      />
    </div>
  );
}
