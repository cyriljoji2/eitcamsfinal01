import { useState } from 'react';
import {
  X,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Building,
  User,
  Users,
  Shield,
  FileText,
  KeyRound,
  Edit2,
  CheckCircle2,
  AlertCircle,
  FileCheck2,
  RotateCcw,
  Power,
} from 'lucide-react';
import {
  Student,
  StudentFormData,
  AdmissionStatus,
  StudentAccountStatus,
  StudentDocument,
  StudentDocumentStatus,
} from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

export interface StudentDetailModalProps {
  isOpen: boolean;
  student: Student | null;
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<StudentFormData>) => Promise<Student>;
  onToggleAccountStatus: (student: Student) => Promise<void>;
  onResetPassword: (student: Student) => Promise<void>;
  onVerifyDocument: (docId: string, status: StudentDocumentStatus, remarks: string) => Promise<void>;
}

export function StudentDetailModal({
  isOpen,
  student,
  onClose,
  onUpdate,
  onToggleAccountStatus,
  onResetPassword,
  onVerifyDocument,
}: StudentDetailModalProps) {
  if (!isOpen || !student) return null;

  const [activeTab, setActiveTab] = useState<'profile' | 'family' | 'documents' | 'security'>(
    'profile'
  );
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Edit Form State
  const [editForm, setEditForm] = useState<Partial<StudentFormData>>({
    fullName: student.fullName,
    dateOfBirth: student.dateOfBirth,
    gender: student.gender,
    fatherName: student.fatherName,
    motherName: student.motherName,
    guardianName: student.guardianName,
    mobile: student.mobile,
    email: student.email,
    address: student.address,
    previousSchool: student.previousSchool,
    previousClass: student.previousClass,
    admissionClass: student.admissionClass,
    section: student.section,
    admissionType: student.admissionType,
    admissionStatus: student.admissionStatus,
  });

  const handleSaveEdit = async () => {
    setIsSaving(true);
    try {
      await onUpdate(student.id, editForm);
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to update student details', err);
    } finally {
      setIsSaving(false);
    }
  };

  const getStatusBadge = (status: AdmissionStatus) => {
    switch (status) {
      case 'Approved':
        return <Badge variant="emerald">Approved</Badge>;
      case 'Application':
        return <Badge variant="blue">Application</Badge>;
      case 'Documents Pending':
        return <Badge variant="amber">Docs Pending</Badge>;
      case 'Documents Under Verification':
        return <Badge variant="purple">Docs Under Verification</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  const getDocStatusBadge = (status: StudentDocumentStatus) => {
    switch (status) {
      case 'Verified':
        return <Badge variant="emerald" size="sm">Verified</Badge>;
      case 'Submitted':
        return <Badge variant="blue" size="sm">Submitted</Badge>;
      case 'Rejected':
        return <Badge variant="rose" size="sm">Rejected</Badge>;
      case 'Pending':
      default:
        return <Badge variant="amber" size="sm">Pending</Badge>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              {student.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[17px] font-bold text-[#1e293b]">{student.fullName}</h3>
                {getStatusBadge(student.admissionStatus)}
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                    student.accountStatus === 'active'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-slate-100 text-slate-600 border-slate-200'
                  }`}
                >
                  {student.accountStatus === 'active' ? 'Account Active' : 'Account Inactive'}
                </span>
              </div>
              <p className="text-xs text-[#64748b] flex items-center gap-2 mt-0.5">
                <span className="font-mono font-semibold text-[#1e3a8a]">
                  {student.registrationNumber || student.id}
                </span>
                <span>&bull;</span>
                <span>{student.admissionClass} (Sec {student.section})</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isEditing ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                leftIcon={<Edit2 className="w-3.5 h-3.5" />}
              >
                Edit
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(false)}
              >
                Cancel Edit
              </Button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white border-b border-[#e2e8f0] px-6 flex items-center gap-6 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`py-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'profile'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Academic & Profile
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('family')}
            className={`py-3 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'family'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Family & Guardians
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('documents')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Documents ({student.documents.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('security')}
            className={`py-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Account Security
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4 text-xs">
          {/* TAB 1: Profile & Academic */}
          {activeTab === 'profile' && (
            <div className="space-y-4">
              {isEditing ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <Input
                      label="Full Name"
                      value={editForm.fullName || ''}
                      onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                    />
                    <Input
                      type="date"
                      label="Date of Birth"
                      value={editForm.dateOfBirth || ''}
                      onChange={(e) => setEditForm({ ...editForm, dateOfBirth: e.target.value })}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[12px] font-semibold text-[#1e293b] mb-1">
                        Admission Class
                      </label>
                      <input
                        type="text"
                        value={editForm.admissionClass || ''}
                        onChange={(e) => setEditForm({ ...editForm, admissionClass: e.target.value })}
                        className="w-full rounded-md border border-[#e2e8f0] p-2 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[12px] font-semibold text-[#1e293b] mb-1">
                        Section
                      </label>
                      <input
                        type="text"
                        value={editForm.section || ''}
                        onChange={(e) => setEditForm({ ...editForm, section: e.target.value })}
                        className="w-full rounded-md border border-[#e2e8f0] p-2 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[12px] font-semibold text-[#1e293b] mb-1">
                        Admission Status
                      </label>
                      <select
                        value={editForm.admissionStatus}
                        onChange={(e) =>
                          setEditForm({ ...editForm, admissionStatus: e.target.value as AdmissionStatus })
                        }
                        className="w-full rounded-md border border-[#e2e8f0] p-2 text-xs font-semibold"
                      >
                        <option value="Application">Application</option>
                        <option value="Documents Pending">Documents Pending</option>
                        <option value="Documents Under Verification">Documents Under Verification</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <Input
                      label="Mobile Number"
                      value={editForm.mobile || ''}
                      onChange={(e) => setEditForm({ ...editForm, mobile: e.target.value })}
                    />
                    <Input
                      label="Email Address"
                      value={editForm.email || ''}
                      onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                    />
                  </div>

                  <Input
                    label="Address"
                    value={editForm.address || ''}
                    onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                  />

                  <div className="flex justify-end gap-2 pt-3">
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={handleSaveEdit}
                      isLoading={isSaving}
                    >
                      Save Changes
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-[#f8fafc] border border-[#e2e8f0] p-4 rounded-xl space-y-3">
                    <h4 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider pb-2 border-b border-[#e2e8f0]">
                      Academic Enrollment
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Registration No:</span>
                        <span className="font-mono font-bold text-[#1e3a8a]">
                          {student.registrationNumber || 'Not generated yet (Pending Approval)'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Allocated Class:</span>
                        <span className="font-semibold text-[#1e293b]">
                          {student.admissionClass} - Section {student.section}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Admission Date:</span>
                        <span className="font-medium text-[#1e293b]">{student.admissionDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Admission Type:</span>
                        <span className="font-medium text-[#1e293b]">{student.admissionType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Previous School:</span>
                        <span className="font-medium text-[#1e293b]">
                          {student.previousSchool || 'N/A'} {student.previousClass ? `(${student.previousClass})` : ''}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#f8fafc] border border-[#e2e8f0] p-4 rounded-xl space-y-3">
                    <h4 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider pb-2 border-b border-[#e2e8f0]">
                      Personal & Demographics
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Date of Birth:</span>
                        <span className="font-medium text-[#1e293b]">{student.dateOfBirth}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Gender:</span>
                        <span className="font-medium text-[#1e293b]">{student.gender}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Mobile:</span>
                        <span className="font-medium text-[#1e293b]">{student.mobile}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Email:</span>
                        <span className="font-medium text-[#1e293b] truncate max-w-[170px]">
                          {student.email}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#64748b]">Address:</span>
                        <span className="font-medium text-[#1e293b] text-right max-w-[170px]">
                          {student.address}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Family & Guardians */}
          {activeTab === 'family' && (
            <div className="bg-[#f8fafc] border border-[#e2e8f0] p-5 rounded-xl space-y-4">
              <h4 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider pb-2 border-b border-[#e2e8f0] flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#1e3a8a]" />
                Guardian & Parent Contact Records
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white p-3.5 rounded-lg border border-[#e2e8f0]">
                  <span className="text-[#64748b] block mb-1">Father's Name</span>
                  <span className="font-bold text-sm text-[#1e293b]">{student.fatherName || 'N/A'}</span>
                </div>

                <div className="bg-white p-3.5 rounded-lg border border-[#e2e8f0]">
                  <span className="text-[#64748b] block mb-1">Mother's Name</span>
                  <span className="font-bold text-sm text-[#1e293b]">{student.motherName || 'N/A'}</span>
                </div>
              </div>

              <div className="bg-white p-3.5 rounded-lg border border-[#e2e8f0]">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[#64748b]">Primary Authorized Guardian</span>
                  <Badge variant="blue" size="sm">Primary Point of Contact</Badge>
                </div>
                <span className="font-bold text-sm text-[#1e293b]">
                  {student.guardianName || student.fatherName || student.motherName || 'Parent'}
                </span>
                <span className="text-[#64748b] block mt-1">
                  Phone: {student.mobile} &bull; Address: {student.address}
                </span>
              </div>
            </div>
          )}

          {/* TAB 3: Documents */}
          {activeTab === 'documents' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#1e293b]">Document Verification Roster</span>
                <span className="text-[#64748b]">
                  {student.documents.filter((d) => d.status === 'Verified').length} / {student.documents.length} Verified
                </span>
              </div>

              <div className="space-y-2.5">
                {student.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="bg-[#f8fafc] border border-[#e2e8f0] p-3.5 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-[#1e3a8a]" />
                        <span className="font-bold text-[#1e293b]">{doc.documentType}</span>
                        {getDocStatusBadge(doc.status)}
                      </div>
                      <p className="text-[#64748b]">
                        File: {doc.fileName || 'document.pdf'} {doc.fileSize ? `(${doc.fileSize})` : ''} &bull; Uploaded: {doc.uploadedDate || 'N/A'}
                      </p>
                      {doc.remarks && (
                        <p className="text-slate-600 bg-white p-1.5 rounded border border-[#e2e8f0] mt-1 font-mono text-[11px]">
                          Note: {doc.remarks}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {doc.status !== 'Verified' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onVerifyDocument(doc.id, 'Verified', 'Verified by Admission Officer')}
                          leftIcon={<CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                        >
                          Verify
                        </Button>
                      )}
                      {doc.status !== 'Rejected' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onVerifyDocument(doc.id, 'Rejected', 'Document unreadable or invalid')}
                        >
                          Reject
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: Account Security & Credentials */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <div className="bg-[#eff6ff] border border-[#dbeafe] p-4 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-[#1e3a8a]">
                  <Shield className="w-4 h-4" />
                  <span className="font-bold">Credential Policy & First-Login Security</span>
                </div>
                <p className="text-[#3b82f6] leading-relaxed">
                  The initial temporary password is only visible upon account creation or administrator password reset. Once the student completes their first login and sets a personal password, staff cannot view the credential.
                </p>
              </div>

              <div className="bg-[#f8fafc] border border-[#e2e8f0] p-4 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#1e293b] block">Student Portal Login Username</span>
                    <span className="text-[#64748b]">Primary identifier for Student Portal authentication</span>
                  </div>
                  <span className="font-mono font-bold text-[#1e3a8a] text-sm bg-white px-3 py-1 rounded border border-[#e2e8f0]">
                    {student.username || student.registrationNumber || 'Pending'}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#e2e8f0]">
                  <div>
                    <span className="font-bold text-[#1e293b] block">Portal Account Access</span>
                    <span className="text-[#64748b]">
                      {student.accountStatus === 'active'
                        ? 'Student may access the portal'
                        : 'Student portal access is currently revoked'}
                    </span>
                  </div>
                  <Button
                    variant={student.accountStatus === 'active' ? 'danger' : 'outline'}
                    size="sm"
                    onClick={() => onToggleAccountStatus(student)}
                    leftIcon={<Power className="w-3.5 h-3.5" />}
                  >
                    {student.accountStatus === 'active' ? 'Deactivate Account' : 'Activate Account'}
                  </Button>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#e2e8f0]">
                  <div>
                    <span className="font-bold text-[#1e293b] block">Reset Temporary Password</span>
                    <span className="text-[#64748b]">
                      Generate a fresh high-entropy password for the student
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onResetPassword(student)}
                    leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
                  >
                    Reset Password
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#f8fafc] px-6 py-4 border-t border-[#e2e8f0] flex items-center justify-end">
          <Button variant="primary" size="md" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
