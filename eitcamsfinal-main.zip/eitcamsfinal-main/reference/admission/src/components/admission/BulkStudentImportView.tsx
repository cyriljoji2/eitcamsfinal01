import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Download,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Users,
  RefreshCw,
  Sparkles,
  KeyRound,
  Trash2,
} from 'lucide-react';
import {
  Student,
  StudentFormData,
  CsvStudentValidationResult,
} from '../../types/admission';
import {
  parseStudentCsvText,
  validateCsvStudentRows,
} from '../../services/admissionService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface BulkStudentImportViewProps {
  existingStudents: Student[];
  onBatchImport: (validItems: StudentFormData[]) => Promise<Student[]>;
}

export function BulkStudentImportView({
  existingStudents,
  onBatchImport,
}: BulkStudentImportViewProps) {
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [validationResult, setValidationResult] = useState<CsvStudentValidationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [importSuccessCount, setImportSuccessCount] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadTemplate = () => {
    const sampleHeaders = [
      'FullName',
      'DateOfBirth',
      'Gender',
      'FatherName',
      'MotherName',
      'GuardianName',
      'Mobile',
      'Email',
      'Address',
      'Program',
      'Batch',
      'AdmissionType',
      'PreviousInstitution',
    ];

    const sampleRows = [
      [
        'Lucas Vance',
        '2005-04-18',
        'Male',
        'Arthur Vance',
        'Elena Vance',
        'Arthur Vance',
        '+1 (555) 345-6789',
        'lucas.vance@eit.edu',
        '104 Maple Street, Springfield, IL',
        'B.Tech Computer Science & Engineering',
        'Batch 2026 - Group A',
        'Regular',
        'Westwood Senior Secondary High',
      ],
      [
        'Chloe Jenkins',
        '2004-09-22',
        'Female',
        'David Jenkins',
        'Sarah Jenkins',
        'David Jenkins',
        '+1 (555) 456-7890',
        'chloe.jenkins@eit.edu',
        '88 Willow Way, Springfield, IL',
        'B.Tech Electronics & Communication Engineering',
        'Batch 2026 - Group A',
        'Scholarship',
        'Lincoln Collegiate Institute',
      ],
      [
        'Ethan Cole',
        '2005-11-05',
        'Male',
        'Robert Cole',
        'Maria Cole',
        'Robert Cole',
        '+1 (555) 567-8901',
        'ethan.cole@eit.edu',
        '12 Birch Avenue, Springfield, IL',
        'B.Tech Information Technology',
        'Batch 2026 - Group A',
        'Transfer',
        'Oakridge Senior High School',
      ],
    ];

    const csvContent =
      sampleHeaders.join(',') +
      '\n' +
      sampleRows.map((r) => r.map((cell) => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'student_admission_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const processText = (text: string, name: string) => {
    setFileName(name);
    setCsvContent(text);
    setImportSuccessCount(null);

    const parsedRows = parseStudentCsvText(text);
    const result = validateCsvStudentRows(parsedRows, existingStudents);
    setValidationResult(result);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      processText(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        processText(text, file.name);
      };
      reader.readAsText(file);
    }
  };

  const handleClear = () => {
    setCsvContent('');
    setFileName('');
    setValidationResult(null);
    setImportSuccessCount(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const validItems = validationResult ? validationResult.items.filter((i) => i.isValid) : [];
  const validData = validItems
    .map((i) => i.parsedData)
    .filter((d): d is StudentFormData => Boolean(d));
  const invalidCount = validationResult ? validationResult.invalidCount : 0;

  const handleImportSubmit = async () => {
    if (validData.length === 0) return;
    setIsProcessing(true);
    try {
      const created = await onBatchImport(validData);
      setImportSuccessCount(created.length);
      setValidationResult(null);
      setCsvContent('');
      setFileName('');
    } catch (err) {
      console.error('Batch import failed', err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">Bulk Student Intake & CSV Import</h2>
          <p className="text-xs text-[#64748b]">
            Batch provision new student admissions, generate Registration Numbers, and issue initial credentials
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleDownloadTemplate}
          leftIcon={<Download className="w-4 h-4" />}
        >
          Download CSV Template
        </Button>
      </div>

      {/* Success Notification */}
      {importSuccessCount !== null && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between animate-in fade-in duration-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold text-sm text-emerald-900 block">
                Batch Import Completed Successfully
              </span>
              <span className="text-xs text-emerald-700">
                Created and allocated credentials for {importSuccessCount} students with sequential Registration Numbers.
              </span>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setImportSuccessCount(null)}>
            Dismiss
          </Button>
        </div>
      )}

      {/* Upload Box */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <input
          type="file"
          ref={fileInputRef}
          accept=".csv,text/csv,text/plain"
          onChange={handleFileChange}
          className="hidden"
        />

        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            isDragging
              ? 'border-[#1e3a8a] bg-[#eff6ff]/50'
              : 'border-[#cbd5e1] hover:border-[#1e3a8a] bg-[#f8fafc] hover:bg-[#f1f5f9]'
          }`}
        >
          <div className="w-12 h-12 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center mx-auto mb-3 border border-[#dbeafe]">
            <UploadCloud className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-[#1e293b] mb-1">
            {fileName ? fileName : 'Click to select or drag and drop a student CSV file'}
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto">
            Supports standardized CSV formats with student personal, guardian, and academic fields.
          </p>
        </div>

        {/* Action Buttons if file is loaded */}
        {validationResult && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#e2e8f0]">
            <div className="flex items-center gap-3 text-xs">
              <Badge variant="emerald">{validData.length} Valid Records</Badge>
              {invalidCount > 0 && (
                <Badge variant="rose">{invalidCount} Errors Detected</Badge>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={handleClear} leftIcon={<Trash2 className="w-3.5 h-3.5" />}>
                Clear
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleImportSubmit}
                disabled={validData.length === 0}
                isLoading={isProcessing}
                leftIcon={<Sparkles className="w-4 h-4" />}
              >
                Import {validData.length} Students & Issue Credentials
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Validation Table Preview */}
      {validationResult && validationResult.items.length > 0 && (
        <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
            <span className="font-semibold text-[#1e293b]">CSV Record Validation Preview</span>
            <span>
              {validData.length} ready for intake &bull; {invalidCount} require attention
            </span>
          </div>

          <div className="overflow-x-auto max-h-[400px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] font-semibold sticky top-0">
                <tr>
                  <th className="py-2.5 px-4">Row</th>
                  <th className="py-2.5 px-4">Student Name</th>
                  <th className="py-2.5 px-4">DOB & Gender</th>
                  <th className="py-2.5 px-4">Class & Sec</th>
                  <th className="py-2.5 px-4">Guardian & Mobile</th>
                  <th className="py-2.5 px-4">Validation Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {validationResult.items.map((item) => {
                  const name = item.parsedData?.fullName || item.raw['FullName'] || item.raw['Name'] || '<Missing Name>';
                  const email = item.parsedData?.email || item.raw['Email'] || '';
                  const dob = item.parsedData?.dateOfBirth || item.raw['DateOfBirth'] || item.raw['DOB'] || '-';
                  const gender = item.parsedData?.gender || item.raw['Gender'] || '-';
                  const cls = item.parsedData?.admissionClass || item.raw['AdmissionClass'] || item.raw['Class'] || '-';
                  const sec = item.parsedData?.section || item.raw['Section'] || '-';
                  const guardian = item.parsedData?.guardianName || item.raw['GuardianName'] || item.raw['FatherName'] || 'Parent';
                  const mobile = item.parsedData?.mobile || item.raw['Mobile'] || '';

                  return (
                    <tr
                      key={item.rowNumber}
                      className={item.isValid ? 'hover:bg-[#f8fafc]' : 'bg-rose-50/40 hover:bg-rose-50/60'}
                    >
                      <td className="py-2.5 px-4 font-mono text-[#64748b]">#{item.rowNumber}</td>
                      <td className="py-2.5 px-4 font-bold text-[#1e293b]">
                        {name}
                        <div className="text-[11px] text-[#64748b] font-normal">{email}</div>
                      </td>
                      <td className="py-2.5 px-4 text-[#1e293b]">
                        <div>{dob}</div>
                        <div className="text-[11px] text-[#64748b]">{gender}</div>
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-[#1e293b]">
                        {cls} ({sec})
                      </td>
                      <td className="py-2.5 px-4 text-[#1e293b]">
                        <div>{guardian}</div>
                        <div className="text-[11px] text-[#64748b]">{mobile}</div>
                      </td>
                      <td className="py-2.5 px-4">
                        {item.isValid ? (
                          <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Valid for Intake</span>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <div className="flex items-center gap-1 text-rose-700 font-semibold">
                              <XCircle className="w-4 h-4" />
                              <span>Invalid</span>
                            </div>
                            <ul className="text-[11px] text-rose-800 list-disc list-inside space-y-0.5">
                              {item.errors.map((err, idx) => (
                                <li key={idx}>{err}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

