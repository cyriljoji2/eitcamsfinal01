import { useState, useMemo } from 'react';
import {
  Search,
  FileCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  AlertCircle,
  Calendar,
  User,
  Filter,
  Check,
} from 'lucide-react';
import {
  Student,
  StudentDocument,
  StudentDocumentStatus,
  StudentDocumentType,
} from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DocumentVerificationModal } from './DocumentVerificationModal';

export interface DocumentManagementViewProps {
  students: Student[];
  onVerifyDocument: (
    docId: string,
    status: StudentDocumentStatus,
    remarks: string
  ) => Promise<void>;
  onSelectStudent: (student: Student) => void;
}

interface FlattenedDocItem {
  doc: StudentDocument;
  student: Student;
}

export function DocumentManagementView({
  students,
  onVerifyDocument,
  onSelectStudent,
}: DocumentManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [classFilter, setClassFilter] = useState<string>('all');

  // Modal State
  const [selectedDocItem, setSelectedDocItem] = useState<FlattenedDocItem | null>(null);

  // Flatten all documents
  const allDocItems = useMemo(() => {
    const items: FlattenedDocItem[] = [];
    for (const student of students) {
      for (const doc of student.documents) {
        items.push({ doc, student });
      }
    }
    return items;
  }, [students]);

  const uniqueClasses = useMemo(() => {
    return Array.from(new Set(students.map((s) => s.admissionClass))).sort();
  }, [students]);

  const filteredDocItems = useMemo(() => {
    return allDocItems.filter(({ doc, student }) => {
      const searchMatch =
        student.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student.registrationNumber &&
          student.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        doc.documentType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (doc.fileName && doc.fileName.toLowerCase().includes(searchTerm.toLowerCase()));

      const statusMatch = statusFilter === 'all' || doc.status === statusFilter;
      const typeMatch = typeFilter === 'all' || doc.documentType === typeFilter;
      const classMatch = classFilter === 'all' || student.admissionClass === classFilter;

      return searchMatch && statusMatch && typeMatch && classMatch;
    });
  }, [allDocItems, searchTerm, statusFilter, typeFilter, classFilter]);

  const getDocStatusBadge = (status: StudentDocumentStatus) => {
    switch (status) {
      case 'Verified':
        return <Badge variant="emerald">Verified</Badge>;
      case 'Submitted':
        return <Badge variant="blue">Submitted / Pending Review</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      case 'Pending':
      default:
        return <Badge variant="amber">Pending Upload</Badge>;
    }
  };

  const handleQuickVerify = async (docId: string) => {
    await onVerifyDocument(docId, 'Verified', 'Verified by Admission Officer');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">Document Verification Desk</h2>
          <p className="text-xs text-[#64748b]">
            Inspect applicant certificates, birth records, and academic marksheets
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="purple" size="md">
            {allDocItems.filter((i) => i.doc.status === 'Submitted').length} Pending Reviews
          </Badge>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by applicant name, Reg No, document..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Document Statuses</option>
              <option value="Submitted">Submitted (Awaiting Review)</option>
              <option value="Pending">Pending Upload</option>
              <option value="Verified">Verified & Validated</option>
              <option value="Rejected">Rejected / Resubmission</option>
            </select>
          </div>

          {/* Type Filter */}
          <div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Document Types</option>
              <option value="Birth Certificate">Birth Certificate</option>
              <option value="Previous Marksheet">Previous Marksheet</option>
              <option value="Previous School/Transfer Certificate">Transfer Certificate</option>
              <option value="Address/Residence Proof">Address / Residence Proof</option>
              <option value="Parent/Guardian ID">Parent / Guardian ID</option>
              <option value="Student Photograph">Student Photograph</option>
            </select>
          </div>

          {/* Class Filter */}
          <div>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Classes</option>
              {uniqueClasses.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Documents Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span>
            Showing <strong className="text-[#1e293b]">{filteredDocItems.length}</strong> of{' '}
            <strong className="text-[#1e293b]">{allDocItems.length}</strong> total document records
          </span>
        </div>

        {filteredDocItems.length === 0 ? (
          <div className="p-12 text-center text-xs space-y-2">
            <AlertCircle className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <p className="font-semibold text-[#1e293b]">No documents match the current filter</p>
            <p className="text-[#64748b]">Try resetting your search or status criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] font-semibold">
                <tr>
                  <th className="py-3 px-4">Student / Applicant</th>
                  <th className="py-3 px-4">Document Type</th>
                  <th className="py-3 px-4">File Attachment</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Verification Info</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredDocItems.map(({ doc, student }) => (
                  <tr key={doc.id} className="hover:bg-[#f8fafc] transition-colors">
                    {/* Student Name */}
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">{student.fullName}</div>
                      <div className="flex items-center gap-1 text-[11px] text-[#64748b]">
                        <span className="font-mono text-[#1e3a8a]">
                          {student.registrationNumber || student.id}
                        </span>
                        <span>&bull;</span>
                        <span>{student.admissionClass}</span>
                      </div>
                    </td>

                    {/* Document Type */}
                    <td className="py-3 px-4 font-semibold text-[#1e293b]">
                      <div className="flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        <span>{doc.documentType}</span>
                      </div>
                    </td>

                    {/* File Attachment */}
                    <td className="py-3 px-4">
                      <span className="text-[#1e3a8a] font-mono text-[11px] bg-[#f1f5f9] px-2 py-0.5 rounded border border-[#e2e8f0]">
                        {doc.fileName || 'document.pdf'}
                      </span>
                      {doc.uploadedDate && (
                        <span className="text-[10px] text-[#64748b] block mt-0.5">
                          Uploaded: {doc.uploadedDate}
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">{getDocStatusBadge(doc.status)}</td>

                    {/* Verification Info */}
                    <td className="py-3 px-4">
                      {doc.verifiedBy ? (
                        <div className="text-[11px] text-emerald-800">
                          <span className="font-medium">By: {doc.verifiedBy}</span>
                          <span className="block text-[10px] text-[#64748b]">
                            {doc.verificationDate}
                          </span>
                        </div>
                      ) : doc.remarks ? (
                        <span className="text-[11px] text-amber-800 font-mono italic">
                          {doc.remarks}
                        </span>
                      ) : (
                        <span className="text-[11px] text-[#94a3b8]">Awaiting officer review</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {doc.status !== 'Verified' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleQuickVerify(doc.id)}
                            leftIcon={<Check className="w-3.5 h-3.5 text-emerald-600" />}
                          >
                            Quick Verify
                          </Button>
                        )}

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedDocItem({ doc, student })}
                          leftIcon={<FileCheck2 className="w-3.5 h-3.5" />}
                        >
                          Review
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Review Modal */}
      {selectedDocItem && (
        <DocumentVerificationModal
          isOpen={!!selectedDocItem}
          onClose={() => setSelectedDocItem(null)}
          document={selectedDocItem.doc}
          studentName={selectedDocItem.student.fullName}
          studentClass={selectedDocItem.student.admissionClass}
          onUpdateStatus={onVerifyDocument}
        />
      )}
    </div>
  );
}
