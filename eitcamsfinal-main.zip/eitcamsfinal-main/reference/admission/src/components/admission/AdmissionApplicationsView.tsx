import { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  UserPlus,
  FileCheck2,
  CheckCircle2,
  XCircle,
  Eye,
  MoreVertical,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  RotateCcw,
  Check,
  AlertCircle,
  Trash2,
} from 'lucide-react';
import { Student, AdmissionStatus, AdmissionType } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

export interface AdmissionApplicationsViewProps {
  students: Student[];
  onOpenNewAdmission: () => void;
  onSelectStudent: (student: Student) => void;
  onApproveAdmission: (student: Student) => Promise<void>;
  onUpdateStatus: (studentId: string, status: AdmissionStatus) => Promise<void>;
  onDeleteApplication: (studentId: string) => Promise<void>;
}

export function AdmissionApplicationsView({
  students,
  onOpenNewAdmission,
  onSelectStudent,
  onApproveAdmission,
  onUpdateStatus,
  onDeleteApplication,
}: AdmissionApplicationsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [classFilter, setClassFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Filtered list
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      // Search
      const searchMatch =
        s.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (s.registrationNumber && s.registrationNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
        s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.mobile.includes(searchTerm) ||
        s.email.toLowerCase().includes(searchTerm.toLowerCase());

      // Status
      const statusMatch = statusFilter === 'all' || s.admissionStatus === statusFilter;

      // Class
      const classMatch = classFilter === 'all' || s.admissionClass === classFilter;

      // Type
      const typeMatch = typeFilter === 'all' || s.admissionType === typeFilter;

      return searchMatch && statusMatch && classMatch && typeMatch;
    });
  }, [students, searchTerm, statusFilter, classFilter, typeFilter]);

  const uniqueClasses = useMemo(() => {
    const set = new Set(students.map((s) => s.admissionClass));
    return Array.from(set).sort();
  }, [students]);

  const getStatusBadge = (status: AdmissionStatus) => {
    switch (status) {
      case 'Approved':
        return <Badge variant="emerald">Approved</Badge>;
      case 'Application':
        return <Badge variant="blue">Application</Badge>;
      case 'Documents Pending':
        return <Badge variant="amber">Docs Pending</Badge>;
      case 'Documents Under Verification':
        return <Badge variant="purple">Under Verification</Badge>;
      case 'Rejected':
        return <Badge variant="rose">Rejected</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & New Admission Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">Admissions Applications Pipeline</h2>
          <p className="text-xs text-[#64748b]">
            Track candidate intake, verify eligibility, and execute formal approvals
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onOpenNewAdmission}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          New Admission Application
        </Button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by student name, ID, mobile, email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Admission Statuses</option>
              <option value="Application">Application (Initial Stage)</option>
              <option value="Documents Pending">Documents Pending</option>
              <option value="Documents Under Verification">Documents Under Verification</option>
              <option value="Approved">Approved (Enrolled)</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          {/* Class Filter */}
          <div>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Classes / Grades</option>
              {uniqueClasses.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Admission Type Filter */}
          <div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="all">All Admission Types</option>
              <option value="Regular">Regular</option>
              <option value="Transfer">Transfer</option>
              <option value="Scholarship">Scholarship</option>
              <option value="Management">Management</option>
              <option value="Sports Quota">Sports Quota</option>
            </select>
          </div>
        </div>

        {/* Quick status tabs pills */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-[#e2e8f0] text-xs">
          <span className="text-[#64748b] text-[11px] font-semibold mr-1">Quick Filter:</span>
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-[#1e3a8a] text-white font-semibold shadow-xs'
                : 'bg-[#f1f5f9] text-[#64748b] hover:bg-[#e2e8f0]'
            }`}
          >
            All ({students.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('Application')}
            className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
              statusFilter === 'Application'
                ? 'bg-blue-600 text-white font-semibold shadow-xs'
                : 'bg-[#f1f5f9] text-[#64748b] hover:bg-[#e2e8f0]'
            }`}
          >
            Applications ({students.filter((s) => s.admissionStatus === 'Application').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('Documents Under Verification')}
            className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
              statusFilter === 'Documents Under Verification'
                ? 'bg-purple-600 text-white font-semibold shadow-xs'
                : 'bg-[#f1f5f9] text-[#64748b] hover:bg-[#e2e8f0]'
            }`}
          >
            Under Review ({students.filter((s) => s.admissionStatus === 'Documents Under Verification').length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('Approved')}
            className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
              statusFilter === 'Approved'
                ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                : 'bg-[#f1f5f9] text-[#64748b] hover:bg-[#e2e8f0]'
            }`}
          >
            Approved ({students.filter((s) => s.admissionStatus === 'Approved').length})
          </button>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span>
            Showing <strong className="text-[#1e293b]">{filteredStudents.length}</strong> of{' '}
            <strong className="text-[#1e293b]">{students.length}</strong> applicant records
          </span>
        </div>

        {filteredStudents.length === 0 ? (
          <div className="p-12 text-center text-xs space-y-2">
            <AlertCircle className="w-8 h-8 text-[#94a3b8] mx-auto" />
            <p className="font-semibold text-[#1e293b]">No admission applications found</p>
            <p className="text-[#64748b]">
              Try adjusting your search criteria or register a new applicant.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] font-semibold">
                <tr>
                  <th className="py-3 px-4">Applicant / Student</th>
                  <th className="py-3 px-4">Class & Type</th>
                  <th className="py-3 px-4">Guardian / Contacts</th>
                  <th className="py-3 px-4">Docs Status</th>
                  <th className="py-3 px-4">Admission Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredStudents.map((student) => {
                  const verifiedDocs = student.documents.filter((d) => d.status === 'Verified').length;
                  const totalDocs = student.documents.length;

                  return (
                    <tr key={student.id} className="hover:bg-[#f8fafc] transition-colors">
                      {/* Name & ID */}
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#1e293b] text-sm">{student.fullName}</div>
                        <div className="flex items-center gap-1.5 text-[11px] text-[#64748b] mt-0.5">
                          <span className="font-mono text-[#1e3a8a] font-semibold">
                            {student.registrationNumber || student.id}
                          </span>
                          <span>&bull;</span>
                          <span>DOB: {student.dateOfBirth}</span>
                        </div>
                      </td>

                      {/* Class & Type */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#1e293b]">
                          {student.admissionClass} (Sec {student.section})
                        </div>
                        <div className="text-[11px] text-[#64748b]">{student.admissionType} Intake</div>
                      </td>

                      {/* Guardian & Contact */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-[#1e293b]">
                          {student.guardianName || student.fatherName || 'Parent'}
                        </div>
                        <div className="text-[11px] text-[#64748b] flex items-center gap-2 mt-0.5">
                          <span>{student.mobile}</span>
                        </div>
                      </td>

                      {/* Docs */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <FileCheck2 className="w-3.5 h-3.5 text-[#1e3a8a]" />
                          <span className="font-medium text-[#1e293b]">
                            {verifiedDocs} / {totalDocs} Verified
                          </span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <div className="space-y-1">
                          {getStatusBadge(student.admissionStatus)}
                          {student.admissionStatus === 'Approved' && (
                            <span className="text-[10px] text-emerald-700 block font-medium">
                              Registration Issued
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {student.admissionStatus !== 'Approved' && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onApproveAdmission(student)}
                              leftIcon={<Check className="w-3.5 h-3.5 text-emerald-600" />}
                              className="text-emerald-700 hover:bg-emerald-50 border-emerald-300"
                            >
                              Approve
                            </Button>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onSelectStudent(student)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                          >
                            View
                          </Button>

                          {student.admissionStatus === 'Rejected' && (
                            <button
                              type="button"
                              onClick={() => onDeleteApplication(student.id)}
                              className="text-rose-600 hover:text-rose-800 p-1.5 rounded hover:bg-rose-50 cursor-pointer"
                              title="Delete application"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
