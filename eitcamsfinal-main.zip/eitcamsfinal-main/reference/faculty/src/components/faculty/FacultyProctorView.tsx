import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  Users,
  Calendar,
  Clock,
  MessageSquare,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Send,
  Search,
  Filter,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  ArrowRight,
  UserCheck,
  Plus,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student } from '../../types/admission';
import {
  ProctorAssignment,
  LeaveOutingRequest,
  ProctorMessage,
  ProctorRemark,
  ProctorRemarkCategory,
} from '../../types/proctor';
import { proctorRepository } from '../../services/proctorService';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyProctorViewProps {
  user: UserSession;
  assignments: ProctorAssignment[];
  students: Student[];
}

type ProctorSection = 'proctees' | 'leave' | 'outing' | 'messages' | 'remarks';

export function FacultyProctorView({
  user,
  assignments,
  students,
}: FacultyProctorViewProps) {
  const [activeSection, setActiveSection] = useState<ProctorSection>('proctees');
  const [requests, setRequests] = useState<LeaveOutingRequest[]>([]);
  const [messages, setMessages] = useState<ProctorMessage[]>([]);
  const [remarks, setRemarks] = useState<ProctorRemark[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Review Modal State
  const [reviewModalRequest, setReviewModalRequest] = useState<LeaveOutingRequest | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject'>('approve');
  const [reviewRemarksText, setReviewRemarksText] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);

  // New Message State
  const [isNewMessageOpen, setIsNewMessageOpen] = useState(false);
  const [msgTargetStudentId, setMsgTargetStudentId] = useState('ALL');
  const [msgTitle, setMsgTitle] = useState('');
  const [msgBody, setMsgBody] = useState('');
  const [msgPriority, setMsgPriority] = useState<'normal' | 'important' | 'urgent'>('normal');
  const [isSendingMsg, setIsSendingMsg] = useState(false);

  // New Remark State
  const [isNewRemarkOpen, setIsNewRemarkOpen] = useState(false);
  const [remarkTargetStudentId, setRemarkTargetStudentId] = useState('');
  const [remarkCategory, setRemarkCategory] = useState<ProctorRemarkCategory>('academic');
  const [remarkText, setRemarkText] = useState('');
  const [remarkActionRequired, setRemarkActionRequired] = useState(false);
  const [isSavingRemark, setIsSavingRemark] = useState(false);

  // Filters
  const [searchStudent, setSearchStudent] = useState('');
  const [requestFilter, setRequestFilter] = useState<'all' | 'pending' | 'endorsed' | 'rejected'>('pending');

  const facultyId = user.id;

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [reqs, msgs, rems] = await Promise.all([
        proctorRepository.getRequestsForProctor(facultyId),
        proctorRepository.getMessagesByProctor(facultyId),
        proctorRepository.getRemarksByProctor(facultyId),
      ]);
      setRequests(reqs);
      setMessages(msgs);
      setRemarks(rems);
    } catch (e) {
      console.error('Error loading faculty proctor data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = proctorRepository.subscribe(() => {
      loadData();
    });
    return unsub;
  }, [facultyId]);

  // My Proctees Student Objects
  const myProcteeStudents = useMemo(() => {
    return assignments.map((asg) => {
      const fullStudent = students.find(
        (s) =>
          s.id.toLowerCase() === asg.studentId.toLowerCase() ||
          s.registrationNumber.toLowerCase() === asg.studentRegistrationNumber.toLowerCase()
      );

      return {
        assignment: asg,
        details: fullStudent,
        name: asg.studentName || fullStudent?.fullName || 'Student',
        regNo: asg.studentRegistrationNumber || fullStudent?.registrationNumber || '—',
        class: asg.studentClass || fullStudent?.admissionClass || '—',
        section: asg.studentSection || fullStudent?.section || '—',
        phone: fullStudent?.mobile || '—',
        email: fullStudent?.email || '—',
        parentName: fullStudent?.fatherName || fullStudent?.motherName || fullStudent?.guardianName || 'Guardian',
        parentPhone: fullStudent?.mobile || '—',
      };
    });
  }, [assignments, students]);

  const filteredProctees = useMemo(() => {
    const q = searchStudent.toLowerCase().trim();
    if (!q) return myProcteeStudents;
    return myProcteeStudents.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.regNo.toLowerCase().includes(q) ||
        p.class.toLowerCase().includes(q) ||
        p.section.toLowerCase().includes(q)
    );
  }, [myProcteeStudents, searchStudent]);

  // Categorized Requests
  const leaveRequests = useMemo(() => {
    return requests.filter((r) => r.requestType === 'leave');
  }, [requests]);

  const outingRequests = useMemo(() => {
    return requests.filter((r) => r.requestType === 'outing');
  }, [requests]);

  const pendingLeaveCount = useMemo(() => {
    return leaveRequests.filter((r) => r.status === 'PENDING_PROCTOR').length;
  }, [leaveRequests]);

  const pendingOutingCount = useMemo(() => {
    return outingRequests.filter((r) => r.status === 'PENDING_PROCTOR').length;
  }, [outingRequests]);

  const filterRequestList = (list: LeaveOutingRequest[]) => {
    return list.filter((r) => {
      if (requestFilter === 'pending') return r.status === 'PENDING_PROCTOR';
      if (requestFilter === 'endorsed') return r.status === 'PENDING_HOSTEL' || r.status === 'APPROVED';
      if (requestFilter === 'rejected') return r.status === 'REJECTED_BY_PROCTOR' || r.status === 'REJECTED_BY_HOSTEL';
      return true;
    });
  };

  // Submit Review (Approve or Reject)
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalRequest) return;

    setIsReviewing(true);
    try {
      await proctorRepository.reviewRequestByProctor(
        reviewModalRequest.id,
        user.id,
        reviewAction,
        reviewRemarksText.trim() || undefined,
        user.name || user.username
      );
      setReviewModalRequest(null);
      setReviewRemarksText('');
      await loadData();
    } catch (err: any) {
      alert('Error updating request: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsReviewing(false);
    }
  };

  // Send Message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgTitle.trim() || !msgBody.trim()) return;

    setIsSendingMsg(true);
    try {
      let targetStudentName: string | undefined;
      let targetRegNo: string | undefined;
      let targetId: string | undefined;

      if (msgTargetStudentId !== 'ALL') {
        const target = myProcteeStudents.find((p) => p.assignment.studentId === msgTargetStudentId);
        if (target) {
          targetId = target.assignment.studentId;
          targetStudentName = target.name;
          targetRegNo = target.regNo;
        }
      }

      await proctorRepository.sendMessage({
        proctorId: user.id,
        proctorName: user.name || user.username,
        proctorDepartment: user.department,
        studentId: targetId,
        studentRegistrationNumber: targetRegNo,
        studentName: targetStudentName,
        title: msgTitle.trim(),
        message: msgBody.trim(),
        priority: msgPriority,
      });

      setIsNewMessageOpen(false);
      setMsgTitle('');
      setMsgBody('');
      setMsgPriority('normal');
      setMsgTargetStudentId('ALL');
      await loadData();
    } catch (err: any) {
      alert('Failed to send message: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSendingMsg(false);
    }
  };

  // Save Remark
  const handleSaveRemark = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!remarkTargetStudentId || !remarkText.trim()) return;

    const target = myProcteeStudents.find((p) => p.assignment.studentId === remarkTargetStudentId);
    if (!target) return;

    setIsSavingRemark(true);
    try {
      await proctorRepository.addRemark({
        proctorId: user.id,
        proctorName: user.name || user.username,
        studentId: target.assignment.studentId,
        studentRegistrationNumber: target.regNo,
        studentName: target.name,
        category: remarkCategory,
        remarks: remarkText.trim(),
        actionRequired: remarkActionRequired,
      });

      setIsNewRemarkOpen(false);
      setRemarkText('');
      setRemarkActionRequired(false);
      await loadData();
    } catch (err: any) {
      alert('Failed to add remark: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSavingRemark(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING_PROCTOR':
        return (
          <Badge variant="amber" size="sm" className="font-semibold">
            Pending Proctor Review
          </Badge>
        );
      case 'PENDING_HOSTEL':
        return (
          <Badge variant="blue" size="sm" className="font-semibold">
            Proctor Approved &bull; Pending Hostel
          </Badge>
        );
      case 'APPROVED':
        return (
          <Badge variant="emerald" size="sm" className="font-semibold">
            Fully Approved
          </Badge>
        );
      case 'REJECTED_BY_PROCTOR':
        return (
          <Badge variant="rose" size="sm" className="font-semibold">
            Rejected by Proctor
          </Badge>
        );
      case 'REJECTED_BY_HOSTEL':
        return (
          <Badge variant="rose" size="sm" className="font-semibold">
            Rejected by Hostel Office
          </Badge>
        );
      case 'CANCELLED':
        return (
          <Badge variant="neutral" size="sm" className="font-semibold">
            Cancelled by Student
          </Badge>
        );
      default:
        return <Badge variant="neutral" size="sm">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xl shrink-0 shadow-xs">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Proctor & Mentorship Desk</h1>
              <Badge variant="blue" size="sm">
                Active Proctor &bull; {assignments.length} Proctees
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Mentorship oversight, leave & outing request approvals, and academic pastoral care
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setActiveSection('messages');
              setIsNewMessageOpen(true);
            }}
            leftIcon={<MessageSquare className="w-4 h-4" />}
          >
            Post Notice
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => {
              setActiveSection('remarks');
              setIsNewRemarkOpen(true);
            }}
            leftIcon={<FileText className="w-4 h-4" />}
          >
            Log Remark
          </Button>
        </div>
      </div>

      {/* Proctor Navigation Tabs */}
      <div className="border-b border-[#e2e8f0] bg-white rounded-t-xl px-4 flex items-center gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveSection('proctees')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
            activeSection === 'proctees'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>My Proctees ({myProcteeStudents.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('leave')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
            activeSection === 'leave'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Leave Requests</span>
          {pendingLeaveCount > 0 && (
            <span className="bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {pendingLeaveCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('outing')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
            activeSection === 'outing'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Outing Requests</span>
          {pendingOutingCount > 0 && (
            <span className="bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {pendingOutingCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('messages')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
            activeSection === 'messages'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Proctor Messages ({messages.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('remarks')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-all cursor-pointer ${
            activeSection === 'remarks'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Proctor Remarks ({remarks.length})</span>
        </button>
      </div>

      {/* SECTION 1: MY PROCTEES */}
      {activeSection === 'proctees' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                placeholder="Search proctee by name, reg no, section..."
                className="w-full pl-9 pr-4 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:ring-2 focus:ring-[#1e3a8a]/20 bg-white"
              />
            </div>
            <div className="text-xs text-[#64748b]">
              Assigned Proctees: <strong className="text-[#1e293b]">{filteredProctees.length}</strong>
            </div>
          </div>

          {filteredProctees.length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              No proctees found matching your query.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProctees.map((p) => (
                <div
                  key={p.assignment.id}
                  className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex flex-col justify-between hover:border-[#1e3a8a]/40 transition-colors"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-sm font-bold text-[#1e293b]">{p.name}</h4>
                        <div className="text-[11px] font-mono text-[#64748b]">{p.regNo}</div>
                      </div>
                      <Badge variant="blue" size="sm">
                        {p.class} &bull; Sec {p.section}
                      </Badge>
                    </div>

                    <div className="space-y-1 pt-1 text-xs text-[#475569]">
                      <div className="flex items-center gap-2 text-[11px]">
                        <Phone className="w-3.5 h-3.5 text-[#94a3b8]" />
                        <span>Student: {p.phone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px]">
                        <Users className="w-3.5 h-3.5 text-[#94a3b8]" />
                        <span>Guardian: {p.parentName} ({p.parentPhone})</span>
                      </div>
                      {p.email && p.email !== '—' && (
                        <div className="flex items-center gap-2 text-[11px]">
                          <Mail className="w-3.5 h-3.5 text-[#94a3b8]" />
                          <span className="truncate">{p.email}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-3 mt-3 border-t border-[#e2e8f0] flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setRemarkTargetStudentId(p.assignment.studentId);
                        setActiveSection('remarks');
                        setIsNewRemarkOpen(true);
                      }}
                      className="text-[11px] font-semibold text-[#1e3a8a] hover:underline cursor-pointer"
                    >
                      + Add Remark
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setMsgTargetStudentId(p.assignment.studentId);
                        setActiveSection('messages');
                        setIsNewMessageOpen(true);
                      }}
                      className="text-[11px] font-semibold text-[#64748b] hover:text-[#1e293b] cursor-pointer"
                    >
                      Send Notice
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: LEAVE REQUESTS */}
      {activeSection === 'leave' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-[#f1f5f9] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Student Leave Applications</h3>
              <p className="text-xs text-[#64748b]">
                Proctor approval is the first mandatory gate before forwarding to the Hostel Office
              </p>
            </div>

            <div className="flex items-center gap-1 bg-[#f1f5f9] p-1 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => setRequestFilter('pending')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'pending'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                Pending Review ({pendingLeaveCount})
              </button>
              <button
                type="button"
                onClick={() => setRequestFilter('endorsed')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'endorsed'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                Endorsed
              </button>
              <button
                type="button"
                onClick={() => setRequestFilter('all')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'all'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                All Requests ({leaveRequests.length})
              </button>
            </div>
          </div>

          {filterRequestList(leaveRequests).length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              <CheckCircle2 className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              No leave requests currently found in this category.
            </div>
          ) : (
            <div className="space-y-3">
              {filterRequestList(leaveRequests).map((req) => (
                <div
                  key={req.id}
                  className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="font-mono text-xs font-bold text-[#1e3a8a]">{req.id}</span>
                      <span className="font-bold text-sm text-[#1e293b]">{req.studentName}</span>
                      <span className="text-xs font-mono text-[#64748b]">({req.studentRegistrationNumber})</span>
                      {getStatusBadge(req.status)}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs text-[#475569] pt-1">
                      <div>
                        <span className="text-[#94a3b8]">Duration: </span>
                        <strong className="text-[#1e293b]">{req.fromDate} to {req.toDate}</strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8]">Category: </span>
                        <strong className="capitalize text-[#1e293b]">{req.reasonCategory}</strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8]">Destination: </span>
                        <strong className="text-[#1e293b]">{req.destinationCity || req.destinationAddress || 'Home'}</strong>
                      </div>
                    </div>

                    <div className="text-xs text-[#1e293b] bg-white border border-[#e2e8f0] p-2.5 rounded-lg mt-1">
                      <span className="font-semibold text-[#64748b]">Purpose: </span>
                      {req.purpose}
                    </div>

                    {req.parentContactNumber && (
                      <div className="text-[11px] text-[#64748b]">
                        Parent Contact: <strong>{req.parentContactNumber}</strong> &bull; Emergency: <strong>{req.emergencyContact || '—'}</strong>
                      </div>
                    )}

                    {req.proctorRemarks && (
                      <div className="text-[11px] text-[#1e3a8a] bg-blue-50/60 p-2 rounded border border-blue-100">
                        <strong>Proctor Note:</strong> {req.proctorRemarks}
                      </div>
                    )}
                  </div>

                  {/* Actions for PENDING_PROCTOR */}
                  {req.status === 'PENDING_PROCTOR' && (
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => {
                          setReviewModalRequest(req);
                          setReviewAction('approve');
                          setReviewRemarksText('Leave approved. Forwarded to Hostel Office.');
                        }}
                        leftIcon={<CheckCircle2 className="w-4 h-4" />}
                      >
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setReviewModalRequest(req);
                          setReviewAction('reject');
                          setReviewRemarksText('');
                        }}
                        leftIcon={<XCircle className="w-4 h-4 text-rose-500" />}
                      >
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: OUTING REQUESTS */}
      {activeSection === 'outing' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-[#f1f5f9] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Student Day Outing Passes</h3>
              <p className="text-xs text-[#64748b]">
                Short daytime outing permits validated by the designated faculty proctor
              </p>
            </div>

            <div className="flex items-center gap-1 bg-[#f1f5f9] p-1 rounded-lg text-xs">
              <button
                type="button"
                onClick={() => setRequestFilter('pending')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'pending'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                Pending Review ({pendingOutingCount})
              </button>
              <button
                type="button"
                onClick={() => setRequestFilter('endorsed')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'endorsed'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                Endorsed
              </button>
              <button
                type="button"
                onClick={() => setRequestFilter('all')}
                className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer ${
                  requestFilter === 'all'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-[#64748b] hover:text-[#1e293b]'
                }`}
              >
                All Passes ({outingRequests.length})
              </button>
            </div>
          </div>

          {filterRequestList(outingRequests).length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              No outing passes found in this category.
            </div>
          ) : (
            <div className="space-y-3">
              {filterRequestList(outingRequests).map((req) => (
                <div
                  key={req.id}
                  className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="font-mono text-xs font-bold text-[#1e3a8a]">{req.id}</span>
                      <span className="font-bold text-sm text-[#1e293b]">{req.studentName}</span>
                      <span className="text-xs font-mono text-[#64748b]">({req.studentRegistrationNumber})</span>
                      {getStatusBadge(req.status)}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs text-[#475569] pt-1">
                      <div>
                        <span className="text-[#94a3b8]">Date: </span>
                        <strong className="text-[#1e293b]">{req.fromDate}</strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8]">Timings: </span>
                        <strong className="text-[#1e293b]">{req.fromTime || '09:00'} to {req.toTime || '18:00'}</strong>
                      </div>
                      <div>
                        <span className="text-[#94a3b8]">Destination: </span>
                        <strong className="text-[#1e293b]">{req.destinationAddress || 'Local Market'}</strong>
                      </div>
                    </div>

                    <div className="text-xs text-[#1e293b] bg-white border border-[#e2e8f0] p-2.5 rounded-lg mt-1">
                      <span className="font-semibold text-[#64748b]">Purpose: </span>
                      {req.purpose}
                    </div>

                    {req.proctorRemarks && (
                      <div className="text-[11px] text-[#1e3a8a] bg-blue-50/60 p-2 rounded border border-blue-100">
                        <strong>Proctor Note:</strong> {req.proctorRemarks}
                      </div>
                    )}
                  </div>

                  {req.status === 'PENDING_PROCTOR' && (
                    <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => {
                          setReviewModalRequest(req);
                          setReviewAction('approve');
                          setReviewRemarksText('Outing pass approved.');
                        }}
                        leftIcon={<CheckCircle2 className="w-4 h-4" />}
                      >
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setReviewModalRequest(req);
                          setReviewAction('reject');
                          setReviewRemarksText('');
                        }}
                        leftIcon={<XCircle className="w-4 h-4 text-rose-500" />}
                      >
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 4: PROCTOR MESSAGES */}
      {activeSection === 'messages' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Advisory & Mentorship Notices</h3>
              <p className="text-xs text-[#64748b]">
                Broadcast advisory notices or direct private guidance to your assigned proctees
              </p>
            </div>
            <Button
              size="sm"
              variant="primary"
              onClick={() => setIsNewMessageOpen(true)}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Compose Notice
            </Button>
          </div>

          {messages.length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              <MessageSquare className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              No notices published yet. Click "Compose Notice" to send your first advisory.
            </div>
          ) : (
            <div className="space-y-3">
              {messages.map((m) => (
                <div key={m.id} className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-[#1e293b]">{m.title}</h4>
                        <Badge
                          variant={
                            m.priority === 'urgent' ? 'rose' : m.priority === 'important' ? 'amber' : 'blue'
                          }
                          size="sm"
                          className="uppercase font-bold text-[10px]"
                        >
                          {m.priority}
                        </Badge>
                      </div>
                      <div className="text-[11px] text-[#64748b] mt-0.5">
                        Target: <strong>{m.studentName ? `${m.studentName} (${m.studentRegistrationNumber})` : 'All Assigned Proctees'}</strong> &bull; Sent on {m.createdAt.split('T')[0]}
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-[#334155] leading-relaxed whitespace-pre-wrap">{m.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 5: PROCTOR REMARKS */}
      {activeSection === 'remarks' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Student Mentorship Notes & Remarks</h3>
              <p className="text-xs text-[#64748b]">
                Confidential academic, behavioral, and pastoral progress logs recorded per proctee
              </p>
            </div>
            <Button
              size="sm"
              variant="primary"
              onClick={() => setIsNewRemarkOpen(true)}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Remark
            </Button>
          </div>

          {remarks.length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              No remarks logged yet. Use "Add Remark" to document student pastoral care notes.
            </div>
          ) : (
            <div className="space-y-3">
              {remarks.map((r) => (
                <div key={r.id} className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-[#1e293b]">{r.studentName}</h4>
                        <span className="font-mono text-xs text-[#64748b]">({r.studentRegistrationNumber})</span>
                        <Badge variant="neutral" size="sm" className="capitalize font-semibold text-[11px]">
                          {r.category}
                        </Badge>
                        {r.actionRequired && (
                          <Badge variant="rose" size="sm">
                            Action Required
                          </Badge>
                        )}
                      </div>
                      <div className="text-[11px] text-[#64748b] mt-0.5">
                        Recorded on {r.createdAt.split('T')[0]}
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-[#334155] leading-relaxed whitespace-pre-wrap">{r.remarks}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* APPROVE / REJECT MODAL */}
      {reviewModalRequest && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-[#e2e8f0] overflow-hidden">
            <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#1e293b]">
                {reviewAction === 'approve' ? 'Approve & Forward Request' : 'Reject Request'}
              </h3>
              <button
                type="button"
                onClick={() => setReviewModalRequest(null)}
                className="text-[#94a3b8] hover:text-[#1e293b] text-lg font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSubmitReview} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <div className="font-bold text-[#1e293b]">
                  {reviewModalRequest.studentName} ({reviewModalRequest.studentRegistrationNumber})
                </div>
                <div className="text-[#64748b]">
                  {reviewModalRequest.requestType.toUpperCase()} &bull; {reviewModalRequest.fromDate} to {reviewModalRequest.toDate}
                </div>
                <div className="text-[#475569] text-[11px] pt-1">
                  <strong>Reason:</strong> {reviewModalRequest.purpose}
                </div>
              </div>

              {reviewAction === 'approve' ? (
                <div className="text-[11px] text-[#1e3a8a] bg-blue-50/60 p-3 rounded-lg border border-blue-200 leading-relaxed">
                  <strong>Workflow Routing Notice:</strong> Approving this request marks it as <strong>PENDING_HOSTEL</strong>, endorsement is logged, and it forwards to the Hostel Office for gate clearance.
                </div>
              ) : (
                <div className="text-[11px] text-rose-800 bg-rose-50 p-3 rounded-lg border border-rose-200 leading-relaxed">
                  <strong>Rejection Notice:</strong> This request will be marked as <strong>REJECTED_BY_PROCTOR</strong> and returned to the student.
                </div>
              )}

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Proctor Remarks {reviewAction === 'reject' && <span className="text-rose-500">*</span>}
                </label>
                <textarea
                  value={reviewRemarksText}
                  onChange={(e) => setReviewRemarksText(e.target.value)}
                  required={reviewAction === 'reject'}
                  rows={3}
                  placeholder={
                    reviewAction === 'approve'
                      ? 'Optional endorsement remarks...'
                      : 'Please explain reason for rejection...'
                  }
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setReviewModalRequest(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant={reviewAction === 'approve' ? 'primary' : 'danger'}
                  size="sm"
                  disabled={isReviewing}
                >
                  {isReviewing
                    ? 'Processing...'
                    : reviewAction === 'approve'
                    ? 'Confirm Approval'
                    : 'Confirm Rejection'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COMPOSE NOTICE MODAL */}
      {isNewMessageOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full border border-[#e2e8f0] overflow-hidden">
            <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#1e293b]">Publish Proctor Notice</h3>
              <button
                type="button"
                onClick={() => setIsNewMessageOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b] text-lg font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSendMessage} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">Target Audience</label>
                <select
                  value={msgTargetStudentId}
                  onChange={(e) => setMsgTargetStudentId(e.target.value)}
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="ALL">Broadcast to All Proctees ({myProcteeStudents.length})</option>
                  {myProcteeStudents.map((p) => (
                    <option key={p.assignment.id} value={p.assignment.studentId}>
                      {p.name} ({p.regNo})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Notice Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={msgTitle}
                    onChange={(e) => setMsgTitle(e.target.value)}
                    required
                    placeholder="e.g. Mid-term Mentorship Review Meeting"
                    className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Priority</label>
                  <select
                    value={msgPriority}
                    onChange={(e) => setMsgPriority(e.target.value as any)}
                    className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                  >
                    <option value="normal">Normal</option>
                    <option value="important">Important</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Message Body <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={msgBody}
                  onChange={(e) => setMsgBody(e.target.value)}
                  required
                  rows={4}
                  placeholder="Enter notice details, instructions, or meeting venue..."
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsNewMessageOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" disabled={isSendingMsg}>
                  {isSendingMsg ? 'Sending...' : 'Send Notice'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LOG REMARK MODAL */}
      {isNewRemarkOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full border border-[#e2e8f0] overflow-hidden">
            <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#1e293b]">Log Mentorship Remark</h3>
              <button
                type="button"
                onClick={() => setIsNewRemarkOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b] text-lg font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleSaveRemark} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Student <span className="text-rose-500">*</span>
                </label>
                <select
                  value={remarkTargetStudentId}
                  onChange={(e) => setRemarkTargetStudentId(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Choose Proctee --</option>
                  {myProcteeStudents.map((p) => (
                    <option key={p.assignment.id} value={p.assignment.studentId}>
                      {p.name} ({p.regNo})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">Category</label>
                <select
                  value={remarkCategory}
                  onChange={(e) => setRemarkCategory(e.target.value as any)}
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="academic">Academic Performance</option>
                  <option value="attendance">Classroom Attendance</option>
                  <option value="discipline">Discipline & Conduct</option>
                  <option value="counseling">Pastoral Counseling</option>
                  <option value="general">General Observation</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Remarks / Notes <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={remarkText}
                  onChange={(e) => setRemarkText(e.target.value)}
                  required
                  rows={4}
                  placeholder="Record observations, action items, or counsel provided..."
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={remarkActionRequired}
                  onChange={(e) => setRemarkActionRequired(e.target.checked)}
                  className="rounded border-[#cbd5e1] text-[#1e3a8a] focus:ring-[#1e3a8a]"
                />
                <span className="font-semibold text-[#1e293b]">Follow-up Action Required</span>
              </label>

              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsNewRemarkOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" disabled={isSavingRemark}>
                  {isSavingRemark ? 'Saving...' : 'Save Remark'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
