import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  Save,
  Send,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  RotateCcw,
  BookOpen,
  Calendar,
  Clock,
  User,
  Search,
  Filter,
} from 'lucide-react';
import { User as AuthUser } from '../../types/auth';
import {
  Examination,
  ExamSubjectSchedule,
  StudentMarkEntry,
  MarkAttendanceStatus,
} from '../../types/examination';
import { examinationRepository } from '../../services/examinationService';
import { Button } from '../ui/Button';

interface FacultyMarkEntryViewProps {
  currentUser: AuthUser;
}

export function FacultyMarkEntryView({ currentUser }: FacultyMarkEntryViewProps) {
  const [schedules, setSchedules] = useState<ExamSubjectSchedule[]>([]);
  const [selectedScheduleId, setSelectedScheduleId] = useState<string>('');
  const [marks, setMarks] = useState<StudentMarkEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'warning';
    text: string;
  } | null>(null);

  // Load schedules assigned to this faculty member
  const loadFacultySchedules = async () => {
    setIsLoading(true);
    try {
      const allSchedules = await examinationRepository.getSchedules();
      // Match by assigned faculty ID or name or show all if admin/super_admin
      const userFacultySchedules = allSchedules.filter(
        (s) =>
          s.assignedFacultyId === currentUser.id ||
          s.assignedFacultyName.toLowerCase().includes(currentUser.name.toLowerCase()) ||
          currentUser.role === 'super_admin' ||
          currentUser.role === 'examination'
      );

      setSchedules(userFacultySchedules);
      if (userFacultySchedules.length > 0 && !selectedScheduleId) {
        setSelectedScheduleId(userFacultySchedules[0].id);
      }
    } catch (err) {
      console.error('Error loading faculty schedules:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadFacultySchedules();
  }, [currentUser]);

  // When selected schedule changes, load its marks
  useEffect(() => {
    if (!selectedScheduleId) {
      setMarks([]);
      return;
    }

    const loadMarksForSchedule = async () => {
      try {
        const marksList = await examinationRepository.getMarksBySchedule(selectedScheduleId);
        setMarks(marksList);
      } catch (err) {
        console.error('Error loading marks:', err);
      }
    };

    loadMarksForSchedule();
    setStatusMessage(null);
  }, [selectedScheduleId]);

  const activeSchedule = schedules.find((s) => s.id === selectedScheduleId);
  const isWindowOpen = activeSchedule?.markEntryStatus === 'Open';
  const isAlreadySubmitted = activeSchedule?.markSubmissionStatus === 'Submitted';
  const isVerified = activeSchedule?.markSubmissionStatus === 'Verified';
  const isReturned = activeSchedule?.markSubmissionStatus === 'Returned';

  // Local mark editing handler
  const handleMarkChange = (
    index: number,
    field: 'marksObtained' | 'attendanceStatus' | 'remarks',
    value: any
  ) => {
    if (!isWindowOpen) return;

    setMarks((prev) => {
      const copy = [...prev];
      const entry = { ...copy[index] };

      if (field === 'attendanceStatus') {
        entry.attendanceStatus = value as MarkAttendanceStatus;
        if (value === 'Absent') {
          entry.marksObtained = 0;
          entry.isPassed = false;
          entry.grade = 'F';
        }
      } else if (field === 'marksObtained') {
        const numVal = value === '' ? null : Number(value);
        if (numVal !== null && numVal > (activeSchedule?.maxMarks || 100)) {
          return prev; // don't exceed max marks
        }
        if (numVal !== null && numVal < 0) {
          return prev;
        }
        entry.marksObtained = numVal;

        if (numVal !== null && activeSchedule) {
          entry.isPassed = numVal >= activeSchedule.passMarks;
          const pct = (numVal / activeSchedule.maxMarks) * 100;
          entry.grade = examinationRepository.calculateGradeFromPercentage(pct);
        }
      } else if (field === 'remarks') {
        entry.remarks = value;
      }

      copy[index] = entry;
      return copy;
    });
  };

  const handleSaveDraft = async () => {
    if (!selectedScheduleId || !isWindowOpen) return;
    setIsSaving(true);
    setStatusMessage(null);
    try {
      await examinationRepository.saveMarks(
        selectedScheduleId,
        marks,
        currentUser.name,
        false // isFinalSubmit = false
      );
      setStatusMessage({
        type: 'success',
        text: 'Draft marks saved successfully. You can continue editing until you submit for COE verification.',
      });
      await loadFacultySchedules();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Failed to save marks.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmitFinal = async () => {
    if (!selectedScheduleId || !isWindowOpen) return;

    // Check if any present student has missing marks
    const missing = marks.some(
      (m) => m.attendanceStatus === 'Present' && (m.marksObtained === null || isNaN(m.marksObtained))
    );

    if (missing) {
      if (
        !window.confirm(
          'Warning: Some present students have missing mark entries. Are you sure you want to proceed with submission?'
        )
      ) {
        return;
      }
    } else {
      if (
        !window.confirm(
          'Confirm final submission: Submit this paper marksheet to the Controller of Examination for verification?'
        )
      ) {
        return;
      }
    }

    setIsSaving(true);
    setStatusMessage(null);
    try {
      await examinationRepository.saveMarks(
        selectedScheduleId,
        marks,
        currentUser.name,
        true // isFinalSubmit = true
      );
      setStatusMessage({
        type: 'success',
        text: 'Marks successfully submitted to the Controller of Examination for verification.',
      });
      await loadFacultySchedules();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: err.message || 'Failed to submit marks.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-[#1e293b] tracking-tight">
            Faculty Examination Mark Entry
          </h1>
          <p className="text-xs text-[#64748b]">
            Evaluate assigned examination papers, record student scores, and submit for COE verification
          </p>
        </div>
      </div>

      {/* Select Paper Bar */}
      <div className="p-4 bg-white rounded-xl border border-[#cbd5e1] space-y-3 shadow-2xs">
        <label className="block text-xs font-bold text-[#1e293b]">
          Select Assigned Examination Paper
        </label>
        <select
          value={selectedScheduleId}
          onChange={(e) => setSelectedScheduleId(e.target.value)}
          className="w-full px-3 py-2.5 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
        >
          {schedules.map((sch) => (
            <option key={sch.id} value={sch.id}>
              {sch.subjectName} ({sch.subjectCode}) — {sch.className} ({sch.section}) — [
              {sch.markEntryStatus === 'Open' ? 'WINDOW OPEN' : 'WINDOW LOCKED'}] — [
              {sch.markSubmissionStatus}]
            </option>
          ))}
          {schedules.length === 0 && (
            <option value="">No examination papers currently assigned to your account.</option>
          )}
        </select>
      </div>

      {activeSchedule && (
        <>
          {/* Paper Details Card */}
          <div className="bg-white rounded-xl border border-[#cbd5e1] p-5 shadow-2xs space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#e2e8f0] pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-black text-[#1e293b]">
                    {activeSchedule.subjectName}
                  </span>
                  <span className="text-xs font-mono font-bold bg-blue-50 text-[#1e3a8a] px-2 py-0.5 rounded">
                    {activeSchedule.subjectCode}
                  </span>
                </div>
                <div className="text-xs text-[#64748b] mt-1">
                  Class: <strong>{activeSchedule.className}</strong> (Section {activeSchedule.section}) • Exam ID: <strong>{activeSchedule.examinationId}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase ${
                    isWindowOpen
                      ? 'bg-amber-100 text-amber-800 border border-amber-300'
                      : 'bg-slate-200 text-[#475569] border border-slate-300'
                  }`}
                >
                  {isWindowOpen ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  {isWindowOpen ? 'Mark Entry Open' : 'Mark Entry Locked'}
                </span>

                <span
                  className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase ${
                    isVerified
                      ? 'bg-emerald-100 text-emerald-800'
                      : isAlreadySubmitted
                      ? 'bg-blue-100 text-blue-800'
                      : isReturned
                      ? 'bg-red-100 text-red-800'
                      : 'bg-slate-100 text-[#64748b]'
                  }`}
                >
                  {activeSchedule.markSubmissionStatus}
                </span>
              </div>
            </div>

            {/* Notification Banners */}
            {!isWindowOpen && (
              <div className="p-3.5 bg-slate-100 border border-slate-300 text-[#475569] rounded-lg text-xs flex items-start gap-2.5">
                <Lock className="w-4 h-4 text-[#64748b] mt-0.5 shrink-0" />
                <div>
                  <div className="font-bold text-[#1e293b]">Mark Entry Window is Closed / Locked</div>
                  <p className="text-[11px] mt-0.5">
                    The Controller of Examination has locked this paper. Modifications are prohibited. If an edit is necessary, contact the COE to request a formal window reopening with audit justification.
                  </p>
                </div>
              </div>
            )}

            {isReturned && (
              <div className="p-3.5 bg-red-50 border border-red-200 text-red-900 rounded-lg text-xs flex items-start gap-2.5">
                <RotateCcw className="w-4 h-4 text-red-700 mt-0.5 shrink-0" />
                <div>
                  <div className="font-bold text-red-800">
                    Returned for Revision by Controller of Examination
                  </div>
                  <p className="text-[11px] mt-0.5">
                    <strong>COE Notes:</strong> {activeSchedule.markEntryReopenReason || 'Please review entered student marks for discrepancies and resubmit.'}
                  </p>
                </div>
              </div>
            )}

            {statusMessage && (
              <div
                className={`p-3.5 rounded-lg text-xs flex items-center gap-2 border ${
                  statusMessage.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : statusMessage.type === 'error'
                    ? 'bg-red-50 border-red-200 text-red-800'
                    : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}
              >
                {statusMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{statusMessage.text}</span>
              </div>
            )}

            {/* Assessment Meta Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-[#e2e8f0]">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Maximum Marks</span>
                <span className="font-black font-mono text-sm text-[#1e293b]">{activeSchedule.maxMarks}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Passing Marks</span>
                <span className="font-black font-mono text-sm text-[#1e293b]">{activeSchedule.passMarks}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Exam Date</span>
                <span className="font-bold text-[#1e293b]">{activeSchedule.examDate}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Total Candidates</span>
                <span className="font-bold text-[#1e293b]">{marks.length} Students</span>
              </div>
            </div>

            {/* Marks Entry Table */}
            <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                    <tr>
                      <th className="py-2.5 px-3">#</th>
                      <th className="py-2.5 px-3">Reg No</th>
                      <th className="py-2.5 px-3">Student Name</th>
                      <th className="py-2.5 px-3 text-center">Attendance</th>
                      <th className="py-2.5 px-3 text-right">Max Marks</th>
                      <th className="py-2.5 px-3 text-right">Marks Obtained</th>
                      <th className="py-2.5 px-3 text-center">Grade</th>
                      <th className="py-2.5 px-3 text-center">Pass / Fail</th>
                      <th className="py-2.5 px-3">Remarks / Feedback</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#e2e8f0]">
                    {marks.map((entry, idx) => (
                      <tr key={entry.id} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-mono text-[#64748b] text-center">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-[#1e3a8a] whitespace-nowrap">
                          {entry.studentRegistrationNumber}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-[#1e293b] whitespace-nowrap">
                          {entry.studentName}
                        </td>
                        <td className="py-2.5 px-3 text-center whitespace-nowrap">
                          <select
                            disabled={!isWindowOpen}
                            value={entry.attendanceStatus}
                            onChange={(e) =>
                              handleMarkChange(idx, 'attendanceStatus', e.target.value)
                            }
                            className="px-2 py-1 text-xs border border-[#cbd5e1] rounded bg-white font-medium focus:outline-none focus:ring-1 focus:ring-[#1e3a8a] disabled:bg-slate-100"
                          >
                            <option value="Present">Present</option>
                            <option value="Absent">Absent</option>
                            <option value="Exempt">Exempt</option>
                          </select>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-[#64748b]">
                          {entry.maxMarks}
                        </td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          {entry.attendanceStatus === 'Absent' ? (
                            <span className="font-bold text-red-600 font-mono px-3 py-1 bg-red-50 rounded">
                              ABSENT
                            </span>
                          ) : (
                            <input
                              type="number"
                              disabled={!isWindowOpen}
                              min="0"
                              max={entry.maxMarks}
                              value={entry.marksObtained !== null ? entry.marksObtained : ''}
                              onChange={(e) =>
                                handleMarkChange(idx, 'marksObtained', e.target.value)
                              }
                              placeholder="Score"
                              className="w-20 px-2.5 py-1 text-right text-xs font-mono font-bold border border-[#cbd5e1] rounded focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] disabled:bg-slate-100"
                            />
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono font-bold">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] ${
                              entry.grade === 'A+' || entry.grade === 'A'
                                ? 'bg-emerald-50 text-emerald-800'
                                : entry.grade === 'F'
                                ? 'bg-red-50 text-red-800'
                                : 'bg-blue-50 text-blue-800'
                            }`}
                          >
                            {entry.grade || '-'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-center font-bold">
                          {entry.attendanceStatus === 'Absent' ? (
                            <span className="text-red-700">Fail (AB)</span>
                          ) : entry.marksObtained !== null ? (
                            entry.isPassed ? (
                              <span className="text-emerald-700">Pass</span>
                            ) : (
                              <span className="text-red-700">Fail</span>
                            )
                          ) : (
                            <span className="text-[#94a3b8] italic">-</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          <input
                            type="text"
                            disabled={!isWindowOpen}
                            value={entry.remarks || ''}
                            onChange={(e) =>
                              handleMarkChange(idx, 'remarks', e.target.value)
                            }
                            placeholder="Optional remark..."
                            className="w-full px-2 py-1 text-xs border border-[#cbd5e1] rounded focus:outline-none focus:ring-1 focus:ring-[#1e3a8a] disabled:bg-slate-100"
                          />
                        </td>
                      </tr>
                    ))}
                    {marks.length === 0 && (
                      <tr>
                        <td colSpan={9} className="py-8 text-center text-[#64748b]">
                          No students enrolled for this subject paper.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bottom Actions Bar */}
            {isWindowOpen && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-[#e2e8f0]">
                <div className="text-xs text-[#64748b]">
                  Evaluator: <strong>{currentUser.name}</strong> • All saves are tracked in audit history
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleSaveDraft}
                    disabled={isSaving}
                    className="text-xs gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Draft</span>
                  </Button>
                  <Button
                    type="button"
                    onClick={handleSubmitFinal}
                    disabled={isSaving}
                    className="text-xs gap-1.5 bg-[#1e3a8a] hover:bg-blue-900"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit for COE Verification</span>
                  </Button>
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
