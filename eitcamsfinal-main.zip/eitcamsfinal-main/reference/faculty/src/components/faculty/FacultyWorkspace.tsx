import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  FlaskConical,
  User,
  Users,
  Landmark,
  BookOpen,
  Award,
  Contact,
  Settings,
  Building2,
  ShieldAlert,
  ShieldCheck,
  CalendarCheck,
  Eye,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  AttendanceRecord,
  FacultyAssignment,
} from '../../types/academic';
import { Student } from '../../types/admission';
import { academicRepository } from '../../services/academicService';
import { admissionRepository } from '../../services/admissionService';
import { AcademicHeader } from '../academic/AcademicHeader';
import { AttendanceView } from '../academic/AttendanceView';
import { StudentAcademicProfileModal } from '../academic/StudentAcademicProfileModal';
import { FacultyMarkEntryView } from './FacultyMarkEntryView';
import { FacultyProctorView } from './FacultyProctorView';
import { proctorRepository } from '../../services/proctorService';
import { ProctorAssignment } from '../../types/proctor';
import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface FacultyWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

type FacultyTab =
  | 'dashboard'
  | 'classes'
  | 'attendance'
  | 'students'
  | 'student-mentees'
  | 'mark-entry'
  | 'proctor'
  | 'research'
  | 'profile-info'
  | 'admin'
  | 'courses-lms'
  | 'achievements'
  | 'people'
  | 'settings'
  | 'hostel'
  | 'security';

function FacultyModulePlaceholder({
  icon: Icon,
  title,
  description,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}) {
  return (
    <div className="bg-white border border-[#e2e8f0] rounded-xl p-8 sm:p-12 text-center shadow-xs max-w-2xl mx-auto space-y-4 my-8">
      <div className="w-12 h-12 rounded-full bg-slate-100 text-[#1e3a8a] flex items-center justify-center mx-auto">
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <div className="inline-block text-[11px] font-semibold text-[#64748b] bg-slate-100 px-2.5 py-0.5 rounded-full mb-2">
          Scheduled Module
        </div>
        <h3 className="text-base font-bold text-[#1e293b]">{title}</h3>
        <p className="text-xs text-[#64748b] mt-1.5 leading-relaxed max-w-md mx-auto">
          {description}
        </p>
      </div>
    </div>
  );
}

export function FacultyWorkspace({ user, onLogout }: FacultyWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<FacultyTab>('dashboard');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [assignments, setAssignments] = useState<FacultyAssignment[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [proctorAssignments, setProctorAssignments] = useState<ProctorAssignment[]>([]);

  const [selectedRegNo, setSelectedRegNo] = useState<string | null>(null);
  const [searchStudent, setSearchStudent] = useState('');

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [
        sessionsData,
        classesData,
        sectionsData,
        subjectsData,
        assignmentsData,
        attendanceData,
        studentsData,
        activeProctorData,
      ] = await Promise.all([
        academicRepository.getSessions(),
        academicRepository.getClasses(),
        academicRepository.getSections(),
        academicRepository.getSubjects(),
        academicRepository.getFacultyAssignments(),
        academicRepository.getAttendanceRecords(),
        admissionRepository.getAllStudents(),
        proctorRepository.getActiveAssignments(),
      ]);

      setSessions(sessionsData);
      setClasses(classesData);
      setSections(sectionsData);
      setSubjects(subjectsData);
      setAssignments(assignmentsData);
      setAttendanceRecords(attendanceData);
      setStudents(studentsData);

      // Filter active proctor assignments for this logged-in faculty user
      const myProctors = activeProctorData.filter(
        (a) =>
          a.facultyId.toLowerCase() === user.id.toLowerCase() ||
          a.facultyId.toLowerCase() === user.username.toLowerCase() ||
          (user.email && a.facultyEmail && a.facultyEmail.toLowerCase() === user.email.toLowerCase())
      );
      setProctorAssignments(myProctors);
    } catch (err) {
      console.error('Failed to load faculty workspace data', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
    const unsub = proctorRepository.subscribe(() => {
      proctorRepository.getActiveAssignments().then((active) => {
        const myProctors = active.filter(
          (a) =>
            a.facultyId.toLowerCase() === user.id.toLowerCase() ||
            a.facultyId.toLowerCase() === user.username.toLowerCase() ||
            (user.email && a.facultyEmail && a.facultyEmail.toLowerCase() === user.email.toLowerCase())
        );
        setProctorAssignments(myProctors);
      });
    });
    return unsub;
  }, [loadData, user]);

  const currentSession = sessions.find((s) => s.isCurrent) || sessions[0] || null;

  // Filter assignments strictly for this logged-in faculty user (by employeeId or email or username)
  const myAssignments = assignments.filter(
    (a) =>
      a.employeeId.toLowerCase() === user.id.toLowerCase() ||
      a.facultyEmail.toLowerCase() === (user.email || '').toLowerCase() ||
      a.employeeId.toLowerCase() === user.username.toLowerCase()
  );

  // My assigned classes and sections
  const myClassNames = Array.from(new Set(myAssignments.map((a) => a.className)));
  const myAssignedStudents = students.filter((s) =>
    myAssignments.some(
      (a) =>
        (a.className.toLowerCase() === s.admissionClass.toLowerCase() ||
          a.classId.toLowerCase() === s.admissionClass.toLowerCase()) &&
        a.sectionName.toLowerCase() === s.section.toLowerCase()
    )
  );

  const filteredMyStudents = myAssignedStudents.filter(
    (s) =>
      s.fullName.toLowerCase().includes(searchStudent.toLowerCase()) ||
      s.registrationNumber.toLowerCase().includes(searchStudent.toLowerCase())
  );

  // Handle Attendance Save for this faculty
  const handleSaveAttendance = async (
    records: Omit<AttendanceRecord, 'id' | 'recordedAt'>[]
  ) => {
    const res = await academicRepository.saveBatchAttendance(records);
    await loadData();
    return res;
  };

  // Top-Level Hierarchical Faculty Sidebar Structure
  const facultyNavItems: PortalSidebarItem[] = [
    // 🌙 Dashboard / Home (direct navigation item)
    {
      id: 'dashboard',
      label: 'Dashboard / Home',
      icon: LayoutDashboard,
    },
    // 🎓 Academics (expandable)
    {
      id: 'academics-group',
      label: 'Academics',
      icon: GraduationCap,
      subItems: [
        { id: 'classes', label: 'My Classes & Subjects', icon: BookOpen },
        { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
        { id: 'students', label: 'Student Rosters', icon: Users },
        { id: 'mark-entry', label: 'Exam Mark Entry', icon: GraduationCap },
      ],
    },
    // ⚛️ Research (expandable)
    {
      id: 'research-group',
      label: 'Research',
      icon: FlaskConical,
      subItems: [
        { id: 'research', label: 'Research & Publications', icon: FlaskConical },
      ],
    },
    // 👤 Profile / Faculty Info (expandable)
    {
      id: 'profile-group',
      label: 'Profile / Faculty Info',
      icon: User,
      subItems: [
        { id: 'profile-info', label: 'Faculty Profile & Workload', icon: User },
      ],
    },
    // 👥 Students / Proctoring (expandable)
    {
      id: 'students-proctor-group',
      label: 'Students / Proctoring',
      icon: Users,
      badge: proctorAssignments.length > 0 ? proctorAssignments.length : undefined,
      badgeVariant: 'emerald',
      subItems: [
        { id: 'student-mentees', label: 'Student Rosters / Mentees', icon: Users },
        ...(proctorAssignments.length > 0
          ? [
              {
                id: 'proctor',
                label: 'Proctor Mentorship Desk',
                icon: ShieldCheck,
                badge: proctorAssignments.length,
                badgeVariant: 'emerald' as const,
              },
            ]
          : []),
      ],
    },
    // 🏛️ Administration (expandable)
    {
      id: 'admin-group',
      label: 'Administration',
      icon: Landmark,
      subItems: [
        { id: 'admin', label: 'Departmental Administration', icon: Landmark },
      ],
    },
    // 📖 Courses / LMS (expandable)
    {
      id: 'courses-lms-group',
      label: 'Courses / LMS',
      icon: BookOpen,
      subItems: [
        { id: 'courses-lms', label: 'Course Materials & LMS', icon: BookOpen },
      ],
    },
    // 🏆 Achievements / Activities (expandable)
    {
      id: 'achievements-group',
      label: 'Achievements / Activities',
      icon: Award,
      subItems: [
        { id: 'achievements', label: 'Achievements & Recognition', icon: Award },
      ],
    },
    // 👤 People / Contacts (expandable)
    {
      id: 'people-group',
      label: 'People / Contacts',
      icon: Contact,
      subItems: [
        { id: 'people', label: 'Campus & Faculty Directory', icon: Contact },
      ],
    },
    // ⚙️ Settings / Configuration (expandable)
    {
      id: 'settings-group',
      label: 'Settings / Configuration',
      icon: Settings,
      subItems: [
        { id: 'settings', label: 'Preferences & Configuration', icon: Settings },
      ],
    },
    // 🏠 Hostel / Campus Services (expandable)
    {
      id: 'hostel-group',
      label: 'Hostel / Campus Services',
      icon: Building2,
      subItems: [
        { id: 'hostel', label: 'Hostel & Campus Services', icon: Building2 },
      ],
    },
    // 🛡️ Security / Approvals (expandable)
    {
      id: 'security-group',
      label: 'Security / Approvals',
      icon: ShieldAlert,
      subItems: [
        { id: 'security', label: 'Security & Approvals', icon: ShieldAlert },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Header */}
      <AcademicHeader
        user={user}
        currentSession={currentSession}
        onLogout={onLogout}
        isFacultyMode={true}
        customTitle="Faculty Academic Portal"
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* Main Workspace Layout (Sidebar + Content) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col lg:flex-row gap-6">
        {/* Left Navigation Sidebar */}
        <PortalSidebar
          items={facultyNavItems}
          activeTab={activeTab}
          onSelectTab={(tabId) => {
            setActiveTab(tabId as FacultyTab);
            setIsMobileMenuOpen(false);
          }}
          isOpenMobile={isMobileMenuOpen}
          idPrefix="faculty-nav"
          footerSlot={
            proctorAssignments.length > 0 ? (
              <div className="pt-2 mt-2 border-t border-[#f1f5f9] px-2">
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-700 bg-emerald-50/80 px-2.5 py-1.5 rounded-md border border-emerald-100 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                  <span>Active Proctor: {proctorAssignments.length} Students</span>
                </div>
              </div>
            ) : undefined
          }
        />

        {/* Main Canvas */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="py-20 text-center text-xs text-[#94a3b8]">
              Loading Faculty portal...
            </div>
          ) : (
            <>
            {/* 0. Dashboard / Home Tab */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                {/* Faculty Identity Banner */}
                <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-[#eff6ff] border border-blue-200 text-[#1e3a8a] font-bold text-base flex items-center justify-center">
                      {user.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-base font-bold text-[#1e293b]">{user.name}</h2>
                        <Badge variant="blue">{user.id}</Badge>
                      </div>
                      <p className="text-xs text-[#64748b]">
                        Department of Mathematics &bull; Term: <strong>{currentSession?.name || '2026-27'}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <div className="text-right">
                      <div className="text-[10px] text-[#64748b] uppercase">Active Courses</div>
                      <div className="font-bold text-[#1e293b] text-sm">
                        {myAssignments.length} Assigned Sections
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-[#64748b] uppercase">Students Taught</div>
                      <div className="font-bold text-[#1e3a8a] text-sm">
                        {myAssignedStudents.length} Students
                      </div>
                    </div>
                    {proctorAssignments.length > 0 && (
                      <div className="text-right">
                        <div className="text-[10px] text-emerald-700 uppercase font-semibold">Proctor Mentees</div>
                        <div className="font-bold text-emerald-700 text-sm">
                          {proctorAssignments.length} Students
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick Action Navigation Shortcuts */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('classes')}
                    className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 transition-all cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between">
                      <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                      <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-[#1e3a8a] transition-all" />
                    </div>
                    <div className="text-xs font-bold text-[#1e293b] mt-2">Teaching Duties</div>
                    <div className="text-[11px] text-[#64748b]">{myAssignments.length} Courses Allocated</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('attendance')}
                    className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 transition-all cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between">
                      <CalendarCheck className="w-4 h-4 text-[#1e3a8a]" />
                      <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-[#1e3a8a] transition-all" />
                    </div>
                    <div className="text-xs font-bold text-[#1e293b] mt-2">Class Roll-Call</div>
                    <div className="text-[11px] text-[#64748b]">Record Daily Attendance</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('students')}
                    className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 transition-all cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between">
                      <Users className="w-4 h-4 text-[#1e3a8a]" />
                      <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-[#1e3a8a] transition-all" />
                    </div>
                    <div className="text-xs font-bold text-[#1e293b] mt-2">Student Rosters</div>
                    <div className="text-[11px] text-[#64748b]">{myAssignedStudents.length} Active Students</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('mark-entry')}
                    className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 transition-all cursor-pointer shadow-2xs group"
                  >
                    <div className="flex items-center justify-between">
                      <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
                      <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-[#1e3a8a] transition-all" />
                    </div>
                    <div className="text-xs font-bold text-[#1e293b] mt-2">Exam Marks</div>
                    <div className="text-[11px] text-[#64748b]">Grade Entry & Sync</div>
                  </button>
                </div>

                {/* Assigned Courses Grid */}
                <div>
                  <h3 className="text-sm font-bold text-[#1e293b] mb-3 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                    <span>My Assigned Teaching Duties</span>
                  </h3>

                  {myAssignments.length === 0 ? (
                    <div className="bg-white border border-[#e2e8f0] p-10 rounded-xl text-center text-xs text-[#94a3b8]">
                      No teaching assignments currently allocated by the Academic Office.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {myAssignments.map((asg) => {
                        const classStudents = students.filter(
                          (s) =>
                            (s.admissionClass.toLowerCase() === asg.className.toLowerCase() ||
                              s.admissionClass.toLowerCase() === asg.classId.toLowerCase()) &&
                            s.section.toLowerCase() === asg.sectionName.toLowerCase()
                        );

                        return (
                          <div
                            key={asg.id}
                            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4 hover:border-[#cbd5e1] transition-all"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] inline-block px-2 py-0.5 rounded">
                                  {asg.subjectCode || 'CORE'}
                                </div>
                                <h4 className="text-sm font-bold text-[#1e293b] mt-1.5">
                                  {asg.subjectName}
                                </h4>
                                <div className="text-xs text-[#64748b]">
                                  {asg.className} &bull; Section {asg.sectionName}
                                </div>
                              </div>
                              <Badge variant="emerald">Active</Badge>
                            </div>

                            <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs text-[#64748b]">
                              <span>Class Strength:</span>
                              <strong className="text-[#1e293b]">
                                {classStudents.length} Enrolled Students
                              </strong>
                            </div>

                            <div className="flex items-center gap-2 pt-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setActiveTab('attendance')}
                                className="w-full text-xs"
                                leftIcon={<CalendarCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                              >
                                Roll-Call
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setActiveTab('students')}
                                className="w-full text-xs text-[#1e293b]"
                                leftIcon={<Users className="w-3.5 h-3.5" />}
                              >
                                View Roster
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 1. Classes & Subjects Tab */}
            {activeTab === 'classes' && (
              <div className="space-y-6">
                {/* Faculty Identity Banner */}
                <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-[#eff6ff] border border-blue-200 text-[#1e3a8a] font-bold text-base flex items-center justify-center">
                      {user.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-base font-bold text-[#1e293b]">{user.name}</h2>
                        <Badge variant="blue">{user.id}</Badge>
                      </div>
                      <p className="text-xs text-[#64748b]">
                        Department of Mathematics &bull; Term: <strong>{currentSession?.name || '2026-27'}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs">
                    <div className="text-right">
                      <div className="text-[10px] text-[#64748b] uppercase">Active Courses</div>
                      <div className="font-bold text-[#1e293b] text-sm">
                        {myAssignments.length} Assigned Sections
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-[#64748b] uppercase">Students Taught</div>
                      <div className="font-bold text-[#1e3a8a] text-sm">
                        {myAssignedStudents.length} Students
                      </div>
                    </div>
                  </div>
                </div>

                {/* Assigned Courses Grid */}
                <div>
                  <h3 className="text-sm font-bold text-[#1e293b] mb-3 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                    <span>My Assigned Teaching Duties</span>
                  </h3>

                  {myAssignments.length === 0 ? (
                    <div className="bg-white border border-[#e2e8f0] p-10 rounded-xl text-center text-xs text-[#94a3b8]">
                      No teaching assignments currently allocated by the Academic Office.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {myAssignments.map((asg) => {
                        const classStudents = students.filter(
                          (s) =>
                            (s.admissionClass.toLowerCase() === asg.className.toLowerCase() ||
                              s.admissionClass.toLowerCase() === asg.classId.toLowerCase()) &&
                            s.section.toLowerCase() === asg.sectionName.toLowerCase()
                        );

                        return (
                          <div
                            key={asg.id}
                            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4 hover:border-[#cbd5e1] transition-all"
                          >
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] inline-block px-2 py-0.5 rounded">
                                  {asg.subjectCode || 'CORE'}
                                </div>
                                <h4 className="text-sm font-bold text-[#1e293b] mt-1.5">
                                  {asg.subjectName}
                                </h4>
                                <div className="text-xs text-[#64748b]">
                                  {asg.className} &bull; Section {asg.sectionName}
                                </div>
                              </div>
                              <Badge variant="emerald">Active</Badge>
                            </div>

                            <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs text-[#64748b]">
                              <span>Class Strength:</span>
                              <strong className="text-[#1e293b]">
                                {classStudents.length} Enrolled Students
                              </strong>
                            </div>

                            <div className="flex items-center gap-2 pt-1">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setActiveTab('attendance')}
                                className="w-full text-xs"
                                leftIcon={<CalendarCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                              >
                                Roll-Call
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setActiveTab('students')}
                                className="w-full text-xs text-[#1e293b]"
                                leftIcon={<Users className="w-3.5 h-3.5" />}
                              >
                                View Roster
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. Attendance Tab (Restricted to Faculty's Classes) */}
            {activeTab === 'attendance' && (
              <AttendanceView
                user={user}
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                students={students}
                assignments={assignments}
                attendanceRecords={attendanceRecords}
                onSaveAttendance={handleSaveAttendance}
                isFacultyOnly={true}
              />
            )}

            {/* 3. Student Roster / Mentees Tab */}
            {(activeTab === 'students' || activeTab === 'student-mentees') && (
              <div className="space-y-4">
                <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-[#1e293b]">
                      {activeTab === 'student-mentees'
                        ? 'Student Rosters & Mentee Directory'
                        : 'Assigned Class Roster'}
                    </h3>
                    <p className="text-xs text-[#64748b]">
                      Showing students currently enrolled in your assigned teaching sections ({filteredMyStudents.length} Students).
                    </p>
                  </div>

                  <div className="w-full sm:w-72">
                    <Input
                      placeholder="Search student or Reg No..."
                      value={searchStudent}
                      onChange={(e) => setSearchStudent(e.target.value)}
                      className="h-8 text-xs"
                    />
                  </div>
                </div>

                <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                      <tr>
                        <th className="py-3 px-4 font-semibold">Reg No.</th>
                        <th className="py-3 px-4 font-semibold">Student Name</th>
                        <th className="py-3 px-4 font-semibold">Class & Sec</th>
                        <th className="py-3 px-4 font-semibold">Guardian / Contact</th>
                        <th className="py-3 px-4 font-semibold text-right">Academic Profile</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#f1f5f9]">
                      {filteredMyStudents.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-8 text-center text-[#94a3b8]">
                            No students found in your assigned courses.
                          </td>
                        </tr>
                      ) : (
                        filteredMyStudents.map((st) => (
                          <tr key={st.id} className="hover:bg-[#f8fafc]">
                            <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                              {st.registrationNumber}
                            </td>
                            <td className="py-3 px-4 font-bold text-[#1e293b]">{st.fullName}</td>
                            <td className="py-3 px-4">
                              <Badge variant="blue">{st.admissionClass} - {st.section}</Badge>
                            </td>
                            <td className="py-3 px-4 text-[#64748b]">
                              <div>{st.guardianName || st.fatherName || 'Parent'}</div>
                              <div className="text-[10px]">{st.mobile}</div>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setSelectedRegNo(st.registrationNumber)}
                                leftIcon={<Eye className="w-3.5 h-3.5" />}
                                className="h-7 text-xs"
                              >
                                View Record
                              </Button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 4. Examination Mark Entry Tab */}
            {activeTab === 'mark-entry' && (
              <FacultyMarkEntryView currentUser={user} />
            )}

            {/* 5. Proctor Mentorship Desk */}
            {activeTab === 'proctor' && proctorAssignments.length > 0 && (
              <FacultyProctorView
                user={user}
                assignments={proctorAssignments}
                students={students}
              />
            )}

            {/* 6. Profile / Faculty Info Tab */}
            {activeTab === 'profile-info' && (
              <div className="space-y-6 max-w-4xl mx-auto">
                <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-6">
                  <div className="flex items-center gap-4 border-b border-[#f1f5f9] pb-6">
                    <div className="w-16 h-16 rounded-full bg-[#eff6ff] border border-blue-200 text-[#1e3a8a] font-bold text-xl flex items-center justify-center">
                      {user.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)}
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-[#1e293b]">{user.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="blue">Faculty Member</Badge>
                        <span className="text-xs text-[#64748b]">ID: {user.id}</span>
                        {user.email && (
                          <span className="text-xs text-[#64748b]">&bull; {user.email}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="bg-[#f8fafc] p-4 rounded-lg border border-[#e2e8f0] space-y-2">
                      <div className="text-[11px] font-semibold text-[#64748b] uppercase">Department & Role</div>
                      <div className="font-bold text-[#1e293b] text-sm">Department of Mathematics</div>
                      <div className="text-[#64748b]">Academic Term: {currentSession?.name || '2026-27'}</div>
                    </div>

                    <div className="bg-[#f8fafc] p-4 rounded-lg border border-[#e2e8f0] space-y-2">
                      <div className="text-[11px] font-semibold text-[#64748b] uppercase">Mentorship Status</div>
                      <div className="font-bold text-[#1e293b] text-sm">
                        {proctorAssignments.length > 0 ? (
                          <span className="text-emerald-700">Active Proctor ({proctorAssignments.length} Mentees)</span>
                        ) : (
                          <span className="text-[#64748b]">No active proctor assignments</span>
                        )}
                      </div>
                      <div className="text-[#64748b]">Allocated by Academic Office</div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-[#1e293b] mb-3">Assigned Teaching Workload</h4>
                    <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                          <tr>
                            <th className="py-2.5 px-3.5 font-semibold">Subject Code</th>
                            <th className="py-2.5 px-3.5 font-semibold">Subject Name</th>
                            <th className="py-2.5 px-3.5 font-semibold">Class & Section</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#f1f5f9]">
                          {myAssignments.length === 0 ? (
                            <tr>
                              <td colSpan={3} className="py-6 text-center text-[#94a3b8]">
                                No active workload allocations.
                              </td>
                            </tr>
                          ) : (
                            myAssignments.map((a) => (
                              <tr key={a.id}>
                                <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                                  {a.subjectCode || 'CORE'}
                                </td>
                                <td className="py-2.5 px-3.5 font-medium text-[#1e293b]">{a.subjectName}</td>
                                <td className="py-2.5 px-3.5 text-[#64748b]">{a.className} - {a.sectionName}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 7. Research */}
            {activeTab === 'research' && (
              <FacultyModulePlaceholder
                icon={FlaskConical}
                title="Research & Publications Desk"
                description="Faculty research project disclosures, academic journal publication tracking, and patent submissions will be available in this module for the upcoming cycle."
              />
            )}

            {/* 8. Administration */}
            {activeTab === 'admin' && (
              <FacultyModulePlaceholder
                icon={Landmark}
                title="Departmental Administration"
                description="Departmental committee rosters, board of studies meeting schedules, and official institutional circulars will be published here."
              />
            )}

            {/* 9. Courses / LMS */}
            {activeTab === 'courses-lms' && (
              <FacultyModulePlaceholder
                icon={BookOpen}
                title="Courses & Learning Management System"
                description="Digital course syllabi, lecture presentation repositories, and classroom reading material distribution."
              />
            )}

            {/* 10. Achievements */}
            {activeTab === 'achievements' && (
              <FacultyModulePlaceholder
                icon={Award}
                title="Achievements & Activities"
                description="Faculty awards, conference presentations, research grants, and professional faculty development accreditations."
              />
            )}

            {/* 11. People / Contacts */}
            {activeTab === 'people' && (
              <FacultyModulePlaceholder
                icon={Contact}
                title="Campus & Faculty Directory"
                description="Institutional faculty directory, academic department contacts, and administrative office extensions."
              />
            )}

            {/* 12. Settings / Configuration */}
            {activeTab === 'settings' && (
              <FacultyModulePlaceholder
                icon={Settings}
                title="Preferences & Configuration"
                description="Faculty portal appearance preferences, communication alert toggles, and account credentials management."
              />
            )}

            {/* 13. Hostel / Campus Services */}
            {activeTab === 'hostel' && (
              <FacultyModulePlaceholder
                icon={Building2}
                title="Hostel & Campus Services"
                description="Faculty campus housing coordination, residential maintenance desks, and guest house booking requests."
              />
            )}

            {/* 14. Security / Approvals */}
            {activeTab === 'security' && (
              <FacultyModulePlaceholder
                icon={ShieldAlert}
                title="Security & Approvals"
                description="Official event clearances, laboratory permission requests, and digital endorsement workflows."
              />
            )}
          </>
        )}

        {/* Student Academic Profile Modal */}
        {selectedRegNo && (
          <StudentAcademicProfileModal
            registrationNumber={selectedRegNo}
            onClose={() => setSelectedRegNo(null)}
          />
        )}
        </main>
      </div>
    </div>
  );
}
