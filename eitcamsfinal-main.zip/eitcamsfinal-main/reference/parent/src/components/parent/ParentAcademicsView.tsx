import React from 'react';
import {
  BookOpen,
  GraduationCap,
  Users,
  Clock,
  Mail,
  Building,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import { Student } from '../../types/admission';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  FacultyAssignment,
  AcademicSession,
} from '../../types/academic';
import { Badge } from '../ui/Badge';

interface ParentAcademicsViewProps {
  student: Student;
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyAssignments: FacultyAssignment[];
}

export function ParentAcademicsView({
  student,
  currentSession,
  classes,
  sections,
  subjects,
  facultyAssignments,
}: ParentAcademicsViewProps) {
  // Find matching class
  const studentClass =
    classes.find(
      (c) =>
        c.name.toLowerCase() === student.admissionClass.toLowerCase() ||
        c.id.toLowerCase() === student.admissionClass.toLowerCase() ||
        c.name.toLowerCase().includes(student.admissionClass.toLowerCase())
    ) || null;

  // Filter subjects enrolled for this class
  const classSubjects = subjects.filter((s) => {
    if (studentClass && s.classId === studentClass.id) return true;
    return (
      s.className?.toLowerCase() === student.admissionClass.toLowerCase() ||
      s.classId?.toLowerCase() === student.admissionClass.toLowerCase()
    );
  });

  // Fallback to all subjects if none specific match class
  const displaySubjects = classSubjects.length > 0 ? classSubjects : subjects.slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Academic Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Classroom & Curriculum</h1>
                <Badge variant="blue" size="sm">
                  {student.admissionClass} - Section {student.section}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Academic Session: {currentSession?.name || '2026–2027'} • Student: {student.fullName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-[#64748b] font-medium bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
              {displaySubjects.length} Enrolled Courses
            </span>
          </div>
        </div>
      </div>

      {/* Enrolled Subjects & Faculty Grid */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Course Curriculum & Instructors</h2>
          </div>
          <span className="text-xs text-[#64748b]">Institutional Syllabus</span>
        </div>

        <div className="divide-y divide-[#f1f5f9]">
          {displaySubjects.length === 0 ? (
            <div className="p-8 text-center text-[#64748b]">
              <BookOpen className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
              <p className="text-xs">No subjects mapped to this class grade yet.</p>
            </div>
          ) : (
            displaySubjects.map((subject, idx) => {
              // Find assigned faculty for this subject
              const assignment = facultyAssignments.find(
                (a) =>
                  a.subjectId === subject.id ||
                  (a.subjectName && a.subjectName.toLowerCase() === subject.name.toLowerCase())
              );

              return (
                <div
                  key={subject.id || idx}
                  className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                >
                  {/* Left: Subject Info */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-[#1e293b]">{subject.name}</span>
                      <span className="text-xs font-mono font-semibold text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded border border-[#bfdbfe]">
                        {subject.code}
                      </span>
                      <Badge variant="neutral" size="sm">
                        {subject.type || 'Core Subject'}
                      </Badge>
                    </div>
                    <p className="text-xs text-[#64748b] leading-relaxed">
                      {subject.description || 'Comprehensive curriculum covering core foundational principles and evaluations.'}
                    </p>
                  </div>

                  {/* Right: Faculty Assignment */}
                  <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl shrink-0">
                    <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xs">
                      <Users className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <span className="text-[10px] text-[#64748b] font-medium block">Course Faculty</span>
                      <span className="text-xs font-bold text-[#1e293b]">
                        {assignment?.facultyName || 'Department Faculty'}
                      </span>
                      <span className="text-[10px] text-[#64748b] block">
                        {assignment?.department || 'Department of Instruction'}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
