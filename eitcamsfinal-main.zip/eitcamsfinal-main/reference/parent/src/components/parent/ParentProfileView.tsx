import React from 'react';
import {
  User,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  ShieldCheck,
  Building,
  Heart,
  Users,
  CheckCircle2,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { AcademicSession } from '../../types/academic';
import { Badge } from '../ui/Badge';

interface ParentProfileViewProps {
  student: Student;
  currentSession: AcademicSession | null;
}

export function ParentProfileView({ student, currentSession }: ParentProfileViewProps) {
  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-2xl font-bold shrink-0 shadow-xs">
              <User className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">{student.fullName}</h1>
                <Badge variant="blue" size="sm">
                  {student.admissionClass} - Section {student.section}
                </Badge>
                <Badge variant={student.accountStatus === 'active' ? 'emerald' : 'rose'} size="sm">
                  {student.accountStatus === 'active' ? 'Active Student' : 'Inactive'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] font-mono mt-1">
                Registration No: {student.registrationNumber || 'Pending Official Allotment'} • Session:{' '}
                {currentSession?.name || '2026–2027'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Academic & Institutional Details */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Academic Enrollment Details</h2>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Class / Grade</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.admissionClass}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Section</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">Section {student.section}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Admission Type</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.admissionType}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Admission Date</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.admissionDate}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Academic Session</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {currentSession?.name || '2026–2027'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Enrollment Status</span>
              <span className="font-semibold text-emerald-700 mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Officially Approved
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Personal Information */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <User className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Student Personal Details</h2>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Date of Birth</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.dateOfBirth}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Gender</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.gender}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Institutional Email</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block truncate">
                {student.email || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Primary Mobile</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.mobile || '—'}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Guardian & Family Contacts */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4 md:col-span-2">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <Users className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Guardian & Family Information on Record</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Father's Name</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.fatherName || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Mother's Name</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.motherName || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Authorized Guardian</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.guardianName || student.fatherName || '—'}
              </span>
            </div>
            <div className="sm:col-span-3">
              <span className="text-[#64748b] block">Residential Address</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.address || '—'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
