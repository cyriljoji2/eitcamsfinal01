import React from 'react';
import { User, ChevronDown, Check, GraduationCap } from 'lucide-react';
import { Student } from '../../types/admission';
import { Badge } from '../ui/Badge';

interface ParentChildSelectorProps {
  students: Student[];
  selectedStudent: Student | null;
  onSelectStudent: (student: Student) => void;
}

export function ParentChildSelector({
  students,
  selectedStudent,
  onSelectStudent,
}: ParentChildSelectorProps) {
  if (students.length <= 1) {
    if (!selectedStudent) return null;
    return (
      <div className="flex items-center gap-3 bg-[#eff6ff] border border-[#bfdbfe] px-3.5 py-2 rounded-xl text-left">
        <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
          <GraduationCap className="w-4 h-4" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#1e293b]">{selectedStudent.fullName}</span>
            <Badge variant="blue" size="sm">
              {selectedStudent.admissionClass} - {selectedStudent.section}
            </Badge>
          </div>
          <p className="text-[11px] text-[#64748b] font-mono mt-0.5">
            {selectedStudent.registrationNumber}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-[#e2e8f0] shadow-xs">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xs shrink-0">
          <User className="w-4 h-4" />
        </div>
        <div>
          <span className="text-xs font-semibold text-[#64748b] block">Active Student View</span>
          <span className="text-xs font-bold text-[#1e293b]">{selectedStudent?.fullName}</span>
        </div>
      </div>

      <div className="flex items-center gap-1.5 flex-wrap w-full sm:w-auto">
        <span className="text-xs text-[#64748b] mr-1 hidden sm:inline">Switch Child:</span>
        {students.map((student) => {
          const isSelected = selectedStudent?.id === student.id;
          return (
            <button
              key={student.id}
              id={`btn-select-child-${student.id}`}
              type="button"
              onClick={() => onSelectStudent(student)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'bg-slate-100 text-[#475569] hover:bg-slate-200 hover:text-[#1e293b]'
              }`}
            >
              {isSelected && <Check className="w-3.5 h-3.5" />}
              <span>{student.fullName}</span>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                  isSelected ? 'bg-blue-800 text-blue-100' : 'bg-slate-200 text-slate-600'
                }`}
              >
                {student.admissionClass}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
