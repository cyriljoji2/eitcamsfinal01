import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  ShieldCheck,
  CalendarCheck,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { AttendanceRecord } from '../../types/academic';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface ParentAttendanceViewProps {
  student: Student;
  attendanceRecords: AttendanceRecord[];
}

export function ParentAttendanceView({
  student,
  attendanceRecords,
}: ParentAttendanceViewProps) {
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchDate, setSearchDate] = useState<string>('');

  // Metrics
  const totalDays = attendanceRecords.length;
  const presentCount = attendanceRecords.filter((r) => r.status === 'Present').length;
  const absentCount = attendanceRecords.filter((r) => r.status === 'Absent').length;
  const lateCount = attendanceRecords.filter((r) => r.status === 'Late').length;
  const leaveCount = attendanceRecords.filter((r) => r.status === 'Leave').length;

  // Percentage calculation: (Present + Late) / Total
  const effectivePresent = presentCount + lateCount;
  const percentage = totalDays > 0 ? Math.round((effectivePresent / totalDays) * 100) : 100;

  // Filtered attendance records
  const filteredRecords = attendanceRecords.filter((rec) => {
    const statusMatch = filterStatus === 'All' || rec.status === filterStatus;
    const searchMatch =
      !searchDate ||
      rec.date.includes(searchDate) ||
      (rec.remarks && rec.remarks.toLowerCase().includes(searchDate.toLowerCase()));
    return statusMatch && searchMatch;
  });

  return (
    <div className="space-y-6">
      {/* Attendance Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <CalendarCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Attendance Record</h1>
                <Badge variant={percentage >= 85 ? 'emerald' : percentage >= 75 ? 'amber' : 'rose'} size="sm">
                  {percentage}% Overall Rate
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: {student.fullName} ({student.registrationNumber}) • Class: {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#64748b] bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Verified Classroom Registry</span>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Working Days */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <span className="text-xs text-[#64748b] font-medium block">Working Days</span>
          <span className="text-xl font-bold text-[#1e293b] mt-1 block">{totalDays}</span>
          <span className="text-[11px] text-[#64748b]">Total sessions</span>
        </div>

        {/* Present */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-700 font-semibold">Present</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-xl font-bold text-emerald-700 mt-1 block">{presentCount}</span>
          <span className="text-[11px] text-[#64748b]">
            {totalDays > 0 ? Math.round((presentCount / totalDays) * 100) : 0}% of days
          </span>
        </div>

        {/* Late */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-700 font-semibold">Late</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-xl font-bold text-amber-700 mt-1 block">{lateCount}</span>
          <span className="text-[11px] text-[#64748b]">Recorded late</span>
        </div>

        {/* Leave */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-700 font-semibold">Leave</span>
            <AlertCircle className="w-4 h-4 text-blue-600" />
          </div>
          <span className="text-xl font-bold text-blue-700 mt-1 block">{leaveCount}</span>
          <span className="text-[11px] text-[#64748b]">Approved leave</span>
        </div>

        {/* Absent */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-700 font-semibold">Absent</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <span className="text-xl font-bold text-rose-700 mt-1 block">{absentCount}</span>
          <span className="text-[11px] text-[#64748b]">Unexcused</span>
        </div>
      </div>

      {/* Progress Bar & Policy Status */}
      <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-[#1e293b]">Attendance Threshold Requirement</span>
          <span className="font-bold text-[#1e293b]">{percentage}% / 75% Minimum Required</span>
        </div>
        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              percentage >= 85 ? 'bg-emerald-600' : percentage >= 75 ? 'bg-amber-500' : 'bg-rose-600'
            }`}
            style={{ width: `${Math.min(100, percentage)}%` }}
          />
        </div>
        <p className="text-[11px] text-[#64748b]">
          {percentage >= 75
            ? 'Candidate satisfies the institutional 75% examination eligibility attendance criteria.'
            : 'Warning: Attendance is below the mandatory 75% threshold. Please consult with the academic advisor.'}
        </p>
      </div>

      {/* Attendance History Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        {/* Controls Bar */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Attendance Log History</h2>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full sm:w-auto">
            <div className="w-full sm:w-48">
              <Input
                placeholder="Search date..."
                value={searchDate}
                onChange={(e) => setSearchDate(e.target.value)}
                size="sm"
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              {['All', 'Present', 'Late', 'Leave', 'Absent'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    filterStatus === st
                      ? 'bg-white text-[#1e293b] shadow-2xs'
                      : 'text-[#64748b] hover:text-[#1e293b]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3.5">Date</th>
                <th className="px-5 py-3.5">Class / Grade</th>
                <th className="px-5 py-3.5">Section</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Recorded By</th>
                <th className="px-5 py-3.5">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-[#64748b]">
                    No attendance records match the selected criteria.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5 font-semibold text-[#1e293b] font-mono">
                      {record.date}
                    </td>
                    <td className="px-5 py-3.5 text-[#475569]">{record.className}</td>
                    <td className="px-5 py-3.5 text-[#475569]">Section {record.sectionName}</td>
                    <td className="px-5 py-3.5">
                      <Badge
                        variant={
                          record.status === 'Present'
                            ? 'emerald'
                            : record.status === 'Late'
                            ? 'amber'
                            : record.status === 'Leave'
                            ? 'blue'
                            : 'rose'
                        }
                        size="sm"
                      >
                        {record.status}
                      </Badge>
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b]">
                      {record.recordedBy || 'Faculty'}
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b]">
                      {record.remarks || 'Classroom session verified.'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
