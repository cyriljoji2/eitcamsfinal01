import React from 'react';
import {
  CalendarCheck,
  DollarSign,
  Award,
  User,
  GraduationCap,
  Clock,
  Receipt,
  ChevronRight,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student } from '../../types/admission';
import {
  AcademicSession,
  AttendanceRecord,
} from '../../types/academic';
import { FeeAssignment, FeeReceipt } from '../../types/finance';
import {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
} from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { ParentTab } from './ParentWorkspace';

interface ParentOverviewProps {
  parentUser: UserSession;
  student: Student;
  allLinkedStudents: Student[];
  currentSession: AcademicSession | null;
  attendance: AttendanceRecord[];
  feeAssignments: FeeAssignment[];
  receipts: FeeReceipt[];
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  hallTickets: HallTicket[];
  results: StudentExamResult[];
  onNavigateTab: (tab: ParentTab) => void;
  onSelectStudent: (student: Student) => void;
}

export function ParentOverview({
  parentUser,
  student,
  allLinkedStudents,
  currentSession,
  attendance,
  feeAssignments,
  receipts,
  examinations,
  schedules,
  hallTickets,
  results,
  onNavigateTab,
  onSelectStudent,
}: ParentOverviewProps) {
  // 1. Calculate Attendance Percentage
  const totalDays = attendance.length;
  const presentDays = attendance.filter((a) => a.status === 'Present').length;
  const lateDays = attendance.filter((a) => a.status === 'Late').length;
  const attendanceRate =
    totalDays > 0 ? Math.round(((presentDays + lateDays) / totalDays) * 100) : 100;

  // 2. Calculate Financial Summary
  const totalBilled = feeAssignments.reduce((sum, f) => sum + (f.amountDue || 0), 0);
  const totalPaid = feeAssignments.reduce((sum, f) => sum + (f.amountPaid || 0), 0);
  const totalWaived = feeAssignments.reduce((sum, f) => sum + (f.discountOrWaiver || 0), 0);
  const totalOutstanding = Math.max(0, totalBilled - totalPaid - totalWaived);

  // 3. Upcoming Examinations for this student's class
  const upcomingExams = examinations.filter(
    (e) => e.status === 'Active' || e.status === 'Draft' || e.status === 'Mark Entry Open'
  );

  // 4. Latest Published Result (strict COE published check)
  const publishedResults = results.filter((res) => {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
    );
    return parentExam?.status === 'Published' || res.verificationStatus === 'Published';
  });
  const latestPublishedResult = publishedResults[0] || null;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#1e3a8a] to-[#1e293b] text-white rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-200 bg-blue-900/60 px-2.5 py-1 rounded-md border border-blue-700/40">
                Guardian / Parent Portal
              </span>
              <span className="text-xs text-blue-200">
                Session {currentSession?.name || '2026–2027'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Welcome, {parentUser.name}
            </h1>
            <p className="text-sm text-blue-100/90 max-w-2xl leading-relaxed">
              Monitoring academic progress, classroom attendance, fee statements, and published results for{' '}
              <strong className="text-white font-semibold">{student.fullName}</strong>.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs border border-white/15 px-4 py-3 rounded-xl">
            <div className="w-10 h-10 rounded-lg bg-white text-[#1e3a8a] flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Active Student</span>
              <p className="text-sm font-bold text-white leading-tight">{student.fullName}</p>
              <p className="text-xs text-blue-200 font-mono mt-0.5">
                {student.admissionClass} • Section {student.section}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Student Switcher Bar (if more than 1 linked child) */}
      {allLinkedStudents.length > 1 && (
        <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-[#1e3a8a]" />
            <span className="text-xs font-bold text-[#1e293b]">
              Your Linked Children ({allLinkedStudents.length}):
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {allLinkedStudents.map((child) => (
              <button
                key={child.id}
                type="button"
                onClick={() => onSelectStudent(child)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  child.id === student.id
                    ? 'bg-[#1e3a8a] text-white shadow-xs'
                    : 'bg-slate-100 text-[#475569] hover:bg-slate-200 hover:text-[#1e293b]'
                }`}
              >
                {child.fullName} ({child.admissionClass})
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Attendance */}
        <div
          onClick={() => onNavigateTab('attendance')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Attendance Rate
            </span>
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#1e293b]">{attendanceRate}%</span>
            <Badge variant={attendanceRate >= 85 ? 'emerald' : attendanceRate >= 75 ? 'amber' : 'rose'} size="sm">
              {attendanceRate >= 85 ? 'Excellent' : attendanceRate >= 75 ? 'Moderate' : 'Low Warning'}
            </Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
            <span>{presentDays} Present • {lateDays} Late • {totalDays} Total</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
          </p>
        </div>

        {/* KPI 2: Fee Balance */}
        <div
          onClick={() => onNavigateTab('fees')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Fee Balance
            </span>
            <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center group-hover:scale-105 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#1e293b]">
              ${totalOutstanding.toLocaleString()}
            </span>
            <Badge variant={totalOutstanding === 0 ? 'emerald' : 'amber'} size="sm">
              {totalOutstanding === 0 ? 'Fully Cleared' : 'Payment Due'}
            </Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
            <span>Paid: ${totalPaid.toLocaleString()} / ${totalBilled.toLocaleString()}</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
          </p>
        </div>

        {/* KPI 3: Upcoming Examinations */}
        <div
          onClick={() => onNavigateTab('examinations')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Upcoming Exams
            </span>
            <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#1e293b]">{upcomingExams.length}</span>
            <span className="text-xs text-[#64748b] font-medium">Scheduled Terms</span>
          </div>
          <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
            <span>{hallTickets.length} Hall Tickets Issued</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
          </p>
        </div>

        {/* KPI 4: Latest Published Result */}
        <div
          onClick={() => onNavigateTab('results')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Latest Result
            </span>
            <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            {latestPublishedResult ? (
              <>
                <span className="text-2xl font-bold text-[#1e293b]">
                  {latestPublishedResult.percentage}%
                </span>
                <Badge
                  variant={latestPublishedResult.resultStatus === 'Pass' ? 'emerald' : 'rose'}
                  size="sm"
                >
                  {latestPublishedResult.resultStatus}
                </Badge>
              </>
            ) : (
              <span className="text-sm font-semibold text-[#64748b]">No Result Published</span>
            )}
          </div>
          <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
            <span>{latestPublishedResult?.examinationName || 'Pending COE release'}</span>
            <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
          </p>
        </div>
      </div>

      {/* Two-Column Detail Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Recent Attendance History */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarCheck className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Recent Attendance Record</h2>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('attendance')}
              className="text-xs"
            >
              Full Attendance Log
            </Button>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {attendance.length === 0 ? (
              <div className="p-8 text-center text-[#64748b]">
                <CalendarCheck className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
                <p className="text-xs">No attendance logs recorded for this session yet.</p>
              </div>
            ) : (
              attendance.slice(0, 5).map((att) => (
                <div key={att.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-md bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-mono font-bold text-[#475569]">
                      {att.date.split('-')[2] || '—'}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-[#1e293b]">{att.date}</p>
                      <p className="text-[11px] text-[#64748b]">
                        {att.className} • Section {att.sectionName}
                      </p>
                    </div>
                  </div>
                  <Badge
                    variant={
                      att.status === 'Present'
                        ? 'emerald'
                        : att.status === 'Late'
                        ? 'amber'
                        : att.status === 'Leave'
                        ? 'blue'
                        : 'rose'
                    }
                    size="sm"
                  >
                    {att.status}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Upcoming Examination Schedule & Hall Tickets */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-700" />
              <h2 className="text-sm font-bold text-[#1e293b]">Upcoming Exam Timetable</h2>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('examinations')}
              className="text-xs"
            >
              View All Schedules
            </Button>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {schedules.length === 0 ? (
              <div className="p-8 text-center text-[#64748b]">
                <Clock className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
                <p className="text-xs">No examination schedules announced for this class yet.</p>
              </div>
            ) : (
              schedules.slice(0, 5).map((sch) => (
                <div key={sch.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <p className="text-xs font-bold text-[#1e293b]">{sch.subjectName}</p>
                    <p className="text-[11px] text-[#64748b] mt-0.5">
                      {sch.examDate} • {sch.startTime} - {sch.endTime}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-mono font-semibold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                      {sch.roomVenue || 'Examination Hall'}
                    </span>
                    <span className="block text-[10px] text-[#64748b] mt-0.5">
                      Max: {sch.maxMarks} Marks
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Receipts Section */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-700" />
            <h2 className="text-sm font-bold text-[#1e293b]">Official Fee Receipts</h2>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onNavigateTab('receipts')}
            className="text-xs"
          >
            All Receipts ({receipts.length})
          </Button>
        </div>

        <div className="p-4 sm:p-5">
          {receipts.length === 0 ? (
            <div className="p-6 text-center text-[#64748b]">
              <Receipt className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
              <p className="text-xs">No fee receipts on record yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {receipts.slice(0, 3).map((rec) => (
                <div
                  key={rec.receiptNumber}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1e293b] font-mono">
                      {rec.receiptNumber}
                    </span>
                    <Badge variant="emerald" size="sm">
                      Paid
                    </Badge>
                  </div>
                  <p className="text-xs text-[#64748b]">{rec.feeTypeName}</p>
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200">
                    <span className="text-[#64748b]">{rec.receiptDate}</span>
                    <span className="font-bold text-[#1e293b]">${rec.amountPaid.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
