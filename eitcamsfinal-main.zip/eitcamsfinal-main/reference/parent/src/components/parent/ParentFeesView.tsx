import React from 'react';
import {
  DollarSign,
  Receipt,
  CheckCircle2,
  Clock,
  Info,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { FeeAssignment, PaymentRecord } from '../../types/finance';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface ParentFeesViewProps {
  student: Student;
  feeAssignments: FeeAssignment[];
  payments: PaymentRecord[];
  onViewReceipts: () => void;
}

export function ParentFeesView({
  student,
  feeAssignments,
  payments,
  onViewReceipts,
}: ParentFeesViewProps) {
  // Aggregate Financials
  const totalBilled = feeAssignments.reduce(
    (sum, item) => sum + (item.amountDue || 0),
    0
  );
  const totalPaid = feeAssignments.reduce((sum, item) => sum + (item.amountPaid || 0), 0);
  const totalWaived = feeAssignments.reduce((sum, item) => sum + (item.discountOrWaiver || 0), 0);
  const totalOutstanding = Math.max(0, totalBilled - totalPaid - totalWaived);

  return (
    <div className="space-y-6">
      {/* Fees Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <DollarSign className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Fee Statement</h1>
                <Badge variant={totalOutstanding === 0 ? 'emerald' : 'amber'} size="sm">
                  {totalOutstanding === 0 ? 'Account Cleared' : 'Dues Pending'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: {student.fullName} ({student.registrationNumber}) • Class: {student.admissionClass}
              </p>
            </div>
          </div>

          <Button
            id="btn-parent-view-receipts"
            size="sm"
            variant="outline"
            onClick={onViewReceipts}
            className="gap-1.5 text-xs"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>Official Receipts</span>
          </Button>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Billed */}
        <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs">
          <span className="text-xs text-[#64748b] font-medium block">Total Tuition & Billed</span>
          <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
            ${totalBilled.toLocaleString()}
          </span>
          <span className="text-[11px] text-[#64748b]">Scheduled institutional fees</span>
        </div>

        {/* Total Paid */}
        <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-700 font-semibold">Total Paid</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-2xl font-bold text-emerald-700 mt-1 block">
            ${totalPaid.toLocaleString()}
          </span>
          <span className="text-[11px] text-[#64748b]">Credited to Bursar account</span>
        </div>

        {/* Total Waived / Discount */}
        <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-purple-700 font-semibold">Waived / Concessions</span>
            <DollarSign className="w-4 h-4 text-purple-600" />
          </div>
          <span className="text-2xl font-bold text-purple-700 mt-1 block">
            ${totalWaived.toLocaleString()}
          </span>
          <span className="text-[11px] text-[#64748b]">Institutional scholarships & waivers</span>
        </div>

        {/* Outstanding Dues */}
        <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-700 font-semibold">Outstanding Dues</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-2xl font-bold text-amber-700 mt-1 block">
            ${totalOutstanding.toLocaleString()}
          </span>
          <span className="text-[11px] text-[#64748b]">
            {totalOutstanding === 0 ? 'No pending balance' : 'Payable by due date'}
          </span>
        </div>
      </div>

      {/* Fee Assignments Breakdown Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Fee Structure & Breakdown</h2>
          </div>
          <span className="text-xs text-[#64748b]">Term Fee Schedules</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3.5">Fee Category / Description</th>
                <th className="px-5 py-3.5">Academic Session</th>
                <th className="px-5 py-3.5">Due Date</th>
                <th className="px-5 py-3.5 text-right">Billed Amount</th>
                <th className="px-5 py-3.5 text-right">Paid Amount</th>
                <th className="px-5 py-3.5 text-right">Balance Due</th>
                <th className="px-5 py-3.5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {feeAssignments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-[#64748b]">
                    No fee assignments generated for this student account.
                  </td>
                </tr>
              ) : (
                feeAssignments.map((assignment) => {
                  const billed = assignment.amountDue || 0;
                  const paid = assignment.amountPaid || 0;
                  const balance = assignment.balance !== undefined ? assignment.balance : Math.max(0, billed - paid);

                  return (
                    <tr key={assignment.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                        {assignment.feeTypeName || 'Tuition Fee'}
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b]">
                        {assignment.academicSession || '2026–2027'}
                      </td>
                      <td className="px-5 py-3.5 font-mono text-[#475569]">
                        {assignment.dueDate || '2026-09-30'}
                      </td>
                      <td className="px-5 py-3.5 text-right font-semibold text-[#1e293b]">
                        ${billed.toLocaleString()}
                      </td>
                      <td className="px-5 py-3.5 text-right text-emerald-700 font-semibold">
                        ${paid.toLocaleString()}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold text-[#1e293b]">
                        ${balance.toLocaleString()}
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        <Badge
                          variant={
                            assignment.status === 'Paid'
                              ? 'emerald'
                              : assignment.status === 'Partially Paid'
                              ? 'amber'
                              : assignment.status === 'Waived'
                              ? 'purple'
                              : 'rose'
                          }
                          size="sm"
                        >
                          {assignment.status}
                        </Badge>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Institutional Payment Guidance Notice */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-start gap-3 text-xs text-[#475569]">
        <Info className="w-5 h-5 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold text-[#1e293b]">Institutional Payment Notice</p>
          <p className="leading-relaxed">
            Fee payments are processed directly by the Finance & Bursar Office. To remit pending dues or request fee receipts, please make payments via bank transfer or at the institutional Bursar counter quoting student registration number{' '}
            <strong className="font-mono text-[#1e293b]">{student.registrationNumber}</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}
