import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  MapPin,
  AlertCircle,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Examination, ExamSubjectSchedule } from '../../types/examination';
import { Badge } from '../ui/Badge';

interface ParentExaminationsViewProps {
  student: Student;
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
}

export function ParentExaminationsView({
  student,
  examinations,
  schedules,
}: ParentExaminationsViewProps) {
  const [selectedExamId, setSelectedExamId] = useState<string>(
    examinations[0]?.id || ''
  );

  const displayExams = examinations;
  const activeExam = displayExams.find((e) => e.id === selectedExamId) || displayExams[0] || null;

  // Schedules for selected examination
  const examSchedules = activeExam
    ? schedules.filter((s) => s.examinationId.toLowerCase() === activeExam.id.toLowerCase())
    : [];

  return (
    <div className="space-y-6">
      {/* Examinations Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Clock className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Examination Timetables & Schedules</h1>
                <Badge variant="blue" size="sm">
                  {displayExams.length} Examination Terms
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: {student.fullName} ({student.registrationNumber}) • Class: {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Examination Selector Tabs */}
      {displayExams.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {displayExams.map((exam) => {
            const isSelected = (activeExam?.id === exam.id) || (selectedExamId === exam.id);
            return (
              <button
                key={exam.id}
                id={`btn-exam-tab-${exam.id}`}
                type="button"
                onClick={() => setSelectedExamId(exam.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-[#1e3a8a] text-white shadow-xs'
                    : 'bg-white text-[#475569] border border-[#e2e8f0] hover:bg-slate-50'
                }`}
              >
                <span>{exam.name}</span>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full ${
                    isSelected ? 'bg-blue-800 text-blue-100' : 'bg-slate-100 text-[#64748b]'
                  }`}
                >
                  {exam.status}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Active Examination Details */}
      {activeExam ? (
        <div className="space-y-6">
          {/* Exam Summary Header */}
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h2 className="text-lg font-bold text-[#1e293b]">{activeExam.name}</h2>
                  <Badge variant={activeExam.status === 'Published' ? 'emerald' : 'blue'} size="sm">
                    {activeExam.status}
                  </Badge>
                </div>
                <p className="text-xs text-[#64748b] mt-1">
                  Term: {activeExam.termType} • Session: {activeExam.academicSession} • Duration:{' '}
                  {activeExam.startDate} to {activeExam.endDate}
                </p>
              </div>

              <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3.5 py-2 rounded-xl text-xs">
                <span className="font-semibold text-[#1e293b]">{examSchedules.length}</span>
                <span className="text-[#64748b]">Subject Schedules</span>
              </div>
            </div>

            {activeExam.instructions && (
              <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-[#1e3a8a] flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-[#1e3a8a]" />
                <p className="leading-relaxed">{activeExam.instructions}</p>
              </div>
            )}
          </div>

          {/* Timetable Table Card */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Subject Examination Schedule</h3>
              </div>
              <span className="text-xs text-[#64748b]">Class {student.admissionClass}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-5 py-3.5">Date</th>
                    <th className="px-5 py-3.5">Subject & Code</th>
                    <th className="px-5 py-3.5">Time Window</th>
                    <th className="px-5 py-3.5">Venue / Hall</th>
                    <th className="px-5 py-3.5 text-right">Max Marks</th>
                    <th className="px-5 py-3.5 text-right">Pass Marks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {examSchedules.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-8 text-center text-[#64748b]">
                        No subject timetables published for this examination yet.
                      </td>
                    </tr>
                  ) : (
                    examSchedules.map((sch) => (
                      <tr key={sch.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-5 py-3.5 font-bold text-[#1e293b] font-mono">
                          {sch.examDate}
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="font-semibold text-[#1e293b]">{sch.subjectName}</div>
                          <div className="text-[11px] text-[#64748b] font-mono">{sch.subjectCode}</div>
                        </td>
                        <td className="px-5 py-3.5 text-[#475569] font-mono">
                          {sch.startTime} - {sch.endTime}
                        </td>
                        <td className="px-5 py-3.5">
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            <MapPin className="w-3 h-3" />
                            {sch.roomVenue || 'Examination Hall'}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-right font-bold text-[#1e293b]">
                          {sch.maxMarks}
                        </td>
                        <td className="px-5 py-3.5 text-right text-[#64748b]">
                          {sch.passMarks}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs text-[#64748b]">
          <Clock className="w-12 h-12 mx-auto text-[#cbd5e1] mb-3" />
          <h3 className="text-base font-bold text-[#1e293b]">No Examinations Scheduled</h3>
          <p className="text-xs mt-1">There are no upcoming examination timetables for this academic class.</p>
        </div>
      )}
    </div>
  );
}
