import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  LayoutDashboard,
  User,
  BookOpen,
  CalendarCheck,
  DollarSign,
  Receipt,
  Award,
  FileText,
  LogOut,
  Menu,
  X,
  ShieldCheck,
  GraduationCap,
  Clock,
  ChevronDown,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student } from '../../types/admission';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  AttendanceRecord,
  FacultyAssignment,
} from '../../types/academic';
import { FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
} from '../../types/examination';
import { admissionRepository } from '../../services/admissionService';
import { academicRepository } from '../../services/academicService';
import { financeRepository } from '../../services/financeService';
import { examinationRepository } from '../../services/examinationService';
import { parentService } from '../../services/parentService';

import { ParentOverview } from './ParentOverview';
import { ParentProfileView } from './ParentProfileView';
import { ParentAcademicsView } from './ParentAcademicsView';
import { ParentAttendanceView } from './ParentAttendanceView';
import { ParentFeesView } from './ParentFeesView';
import { ParentReceiptsView } from './ParentReceiptsView';
import { ParentExaminationsView } from './ParentExaminationsView';
import { ParentHallTicketsView } from './ParentHallTicketsView';
import { ParentResultsView } from './ParentResultsView';
import { ParentChildSelector } from './ParentChildSelector';

import { ReceiptPreviewModal } from '../finance/ReceiptPreviewModal';
import { HallTicketPrintModal } from '../examination/HallTicketPrintModal';
import { ResultTranscriptModal } from '../examination/ResultTranscriptModal';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ParentWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export type ParentTab =
  | 'overview'
  | 'profile'
  | 'academics'
  | 'attendance'
  | 'fees'
  | 'receipts'
  | 'examinations'
  | 'hall-tickets'
  | 'results';

export function ParentWorkspace({ user, onLogout }: ParentWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<ParentTab>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Authenticated Parent's Linked Students
  const [linkedStudents, setLinkedStudents] = useState<Student[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Academic data
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyAssignment[]>([]);

  // Raw database collections
  const [allAttendanceRecords, setAllAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [allFeeAssignments, setAllFeeAssignments] = useState<FeeAssignment[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRecord[]>([]);
  const [allReceipts, setAllReceipts] = useState<FeeReceipt[]>([]);
  const [allExaminations, setAllExaminations] = useState<Examination[]>([]);
  const [allSchedules, setAllSchedules] = useState<ExamSubjectSchedule[]>([]);
  const [allHallTickets, setAllHallTickets] = useState<HallTicket[]>([]);
  const [allResults, setAllResults] = useState<StudentExamResult[]>([]);

  // Modals state
  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceipt | null>(null);
  const [selectedHallTicket, setSelectedHallTicket] = useState<HallTicket | null>(null);
  const [selectedResult, setSelectedResult] = useState<StudentExamResult | null>(null);

  // Load parent student links and all domain repositories
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      // 1. Resolve linked students strictly for this parent
      const matchedStudents = await parentService.getLinkedStudents(user);
      setLinkedStudents(matchedStudents);

      const initialStudent = matchedStudents[0] || null;
      setSelectedStudent(initialStudent);

      // 2. Fetch domain datasets in parallel
      const [
        sessionsData,
        classesData,
        sectionsData,
        subjectsData,
        assignmentsData,
        attendanceData,
        feesData,
        paymentsData,
        receiptsData,
        examsData,
        schedulesData,
        hallTicketsData,
        resultsData,
      ] = await Promise.all([
        academicRepository.getSessions(),
        academicRepository.getClasses(),
        academicRepository.getSections(),
        academicRepository.getSubjects(),
        academicRepository.getFacultyAssignments(),
        academicRepository.getAttendanceRecords(),
        financeRepository.getFeeAssignments(),
        financeRepository.getPayments(),
        financeRepository.getReceipts(),
        examinationRepository.getExaminations(),
        examinationRepository.getSchedules(),
        examinationRepository.getHallTickets(),
        examinationRepository.getResults(),
      ]);

      setSessions(sessionsData);
      setClasses(classesData);
      setSections(sectionsData);
      setSubjects(subjectsData);
      setFacultyAssignments(assignmentsData);
      setAllAttendanceRecords(attendanceData);
      setAllFeeAssignments(feesData);
      setAllPayments(paymentsData);
      setAllReceipts(receiptsData);
      setAllExaminations(examsData);
      setAllSchedules(schedulesData);
      setAllHallTickets(hallTicketsData);
      setAllResults(resultsData);
    } catch (err) {
      console.error('Failed to load parent portal data', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Derived filtered data for the currently selected student
  const studentRegNorm = (selectedStudent?.registrationNumber || '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase();

  const studentAttendance = selectedStudent
    ? allAttendanceRecords.filter((a) => {
        const aReg = (a.registrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          aReg === studentRegNorm ||
          a.registrationNumber === selectedStudent.registrationNumber ||
          (a.studentId && a.studentId === selectedStudent.id)
        );
      })
    : [];

  const studentFees = selectedStudent
    ? allFeeAssignments.filter((f) => {
        const fReg = (f.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          fReg === studentRegNorm ||
          f.studentRegistrationNumber === selectedStudent.registrationNumber ||
          (f.studentId && f.studentId === selectedStudent.id)
        );
      })
    : [];

  const studentPayments = selectedStudent
    ? allPayments.filter((p) => {
        const pReg = (p.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          pReg === studentRegNorm ||
          p.studentRegistrationNumber === selectedStudent.registrationNumber ||
          (p.studentId && p.studentId === selectedStudent.id)
        );
      })
    : [];

  const studentReceipts = selectedStudent
    ? allReceipts.filter((r) => {
        const rReg = (r.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          rReg === studentRegNorm ||
          r.studentRegistrationNumber === selectedStudent.registrationNumber ||
          (r.studentId && r.studentId === selectedStudent.id)
        );
      })
    : [];

  const studentHallTickets = selectedStudent
    ? allHallTickets.filter((ht) => {
        const htReg = (ht.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          htReg === studentRegNorm ||
          ht.studentRegistrationNumber === selectedStudent.registrationNumber ||
          (ht.studentId && ht.studentId === selectedStudent.id)
        );
      })
    : [];

  const studentResults = selectedStudent
    ? allResults.filter((res) => {
        const resReg = (res.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        return (
          resReg === studentRegNorm ||
          res.studentRegistrationNumber === selectedStudent.registrationNumber ||
          (res.studentId && res.studentId === selectedStudent.id)
        );
      })
    : [];

  const currentSession = sessions.find((s) => s.isCurrent) || sessions[0] || null;

  const navigationItems = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'profile', label: 'Student Profile', icon: User },
    { id: 'academics', label: 'Academics & Courses', icon: BookOpen },
    { id: 'attendance', label: 'Attendance', icon: CalendarCheck, count: studentAttendance.length },
    { id: 'fees', label: 'Fee Statement', icon: DollarSign },
    { id: 'receipts', label: 'Payment Receipts', icon: Receipt, count: studentReceipts.length },
    { id: 'examinations', label: 'Exam Timetable', icon: Clock, count: allExaminations.length },
    { id: 'hall-tickets', label: 'Hall Tickets', icon: Award, count: studentHallTickets.length },
    { id: 'results', label: 'Report Cards', icon: FileText, count: studentResults.length },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-md animate-pulse">
          <Users className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold text-[#1e293b] mt-4">Loading Parent Portal...</p>
        <p className="text-xs text-[#64748b] mt-1">Retrieving family records and student profiles</p>
      </div>
    );
  }

  // Handle case with no linked students
  if (!selectedStudent || linkedStudents.length === 0) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center mb-4">
          <Users className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#1e293b]">No Linked Student Account Found</h2>
        <p className="text-xs text-[#64748b] max-w-md mt-2 leading-relaxed">
          There are currently no active student enrollments associated with your parent credentials ({user.email || user.name}).
          Please contact the school Admission Office to link your child's student record.
        </p>
        <div className="mt-6 flex items-center gap-3">
          <Button variant="outline" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-1.5" />
            <span>Sign Out</span>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Top Application Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Brand & Portal Badge */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                    Parent Portal
                  </span>
                  <span className="hidden sm:inline-block text-[11px] font-semibold text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded border border-[#bfdbfe]">
                    Guardian Gateway
                  </span>
                </div>
                <span className="text-[11px] text-[#64748b] font-medium hidden md:inline">
                  Student Progress, Attendance & Official Transcripts
                </span>
              </div>
            </div>

            {/* Right: Parent Profile & Logout */}
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-[#e2e8f0]">
                <div className="w-7 h-7 rounded-full bg-[#f1f5f9] border border-[#e2e8f0] flex items-center justify-center text-[#1e293b]">
                  <User className="w-3.5 h-3.5" />
                </div>
                <div className="text-left leading-none">
                  <p className="text-[13px] font-semibold text-[#1e293b]">{user.name}</p>
                  <p className="text-[11px] text-[#64748b] font-mono mt-0.5">{user.username || 'Guardian'}</p>
                </div>
              </div>

              <Badge variant="purple" size="sm" className="hidden md:inline-flex capitalize">
                Parent
              </Badge>

              <Button
                id="btn-parent-logout"
                variant="outline"
                size="sm"
                onClick={onLogout}
                className="gap-1.5 text-xs text-[#64748b] hover:text-[#1e293b]"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </Button>

              {/* Mobile Menu Toggle */}
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-lg text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-[#e2e8f0] bg-white px-4 pt-2 pb-4 space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id as ParentTab);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold ${
                    isActive
                      ? 'bg-[#1e3a8a] text-white'
                      : 'text-[#475569] hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        isActive ? 'bg-blue-800 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* Main Workspace Layout */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {/* Left Navigation Sidebar */}
          <aside className="hidden md:block md:col-span-1 lg:col-span-1 space-y-4">
            {/* Child Selector Card in Sidebar */}
            <ParentChildSelector
              students={linkedStudents}
              selectedStudent={selectedStudent}
              onSelectStudent={(s) => setSelectedStudent(s)}
            />

            {/* Navigation Tabs */}
            <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden p-2 space-y-1">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`btn-parent-tab-${item.id}`}
                    type="button"
                    onClick={() => setActiveTab(item.id as ParentTab)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-[#1e3a8a] text-white shadow-2xs'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </div>
                    {item.count !== undefined && item.count > 0 && (
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded-md ${
                          isActive ? 'bg-blue-800 text-blue-100' : 'bg-slate-100 text-[#64748b]'
                        }`}
                      >
                        {item.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Institutional Security Notice */}
            <div className="bg-[#eff6ff]/70 border border-[#bfdbfe]/60 rounded-xl p-3.5 text-xs text-[#1e3a8a] space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
                <span>Verified Read Access</span>
              </div>
              <p className="text-[11px] text-[#475569] leading-relaxed">
                Parent access provides real-time read-only academic and financial tracking for enrolled dependents.
              </p>
            </div>
          </aside>

          {/* Right Main Content Area */}
          <main className="md:col-span-3 lg:col-span-4">
            {activeTab === 'overview' && (
              <ParentOverview
                parentUser={user}
                student={selectedStudent}
                allLinkedStudents={linkedStudents}
                currentSession={currentSession}
                attendance={studentAttendance}
                feeAssignments={studentFees}
                receipts={studentReceipts}
                examinations={allExaminations}
                schedules={allSchedules}
                hallTickets={studentHallTickets}
                results={studentResults}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onSelectStudent={(s) => setSelectedStudent(s)}
              />
            )}

            {activeTab === 'profile' && (
              <ParentProfileView student={selectedStudent} currentSession={currentSession} />
            )}

            {activeTab === 'academics' && (
              <ParentAcademicsView
                student={selectedStudent}
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                subjects={subjects}
                facultyAssignments={facultyAssignments}
              />
            )}

            {activeTab === 'attendance' && (
              <ParentAttendanceView student={selectedStudent} attendanceRecords={studentAttendance} />
            )}

            {activeTab === 'fees' && (
              <ParentFeesView
                student={selectedStudent}
                feeAssignments={studentFees}
                payments={studentPayments}
                onViewReceipts={() => setActiveTab('receipts')}
              />
            )}

            {activeTab === 'receipts' && (
              <ParentReceiptsView
                student={selectedStudent}
                receipts={studentReceipts}
                onViewReceipt={(receipt) => setSelectedReceipt(receipt)}
              />
            )}

            {activeTab === 'examinations' && (
              <ParentExaminationsView
                student={selectedStudent}
                examinations={allExaminations}
                schedules={allSchedules}
              />
            )}

            {activeTab === 'hall-tickets' && (
              <ParentHallTicketsView
                student={selectedStudent}
                hallTickets={studentHallTickets}
                onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
              />
            )}

            {activeTab === 'results' && (
              <ParentResultsView
                student={selectedStudent}
                examinations={allExaminations}
                results={studentResults}
                onViewTranscript={(res) => setSelectedResult(res)}
              />
            )}
          </main>
        </div>
      </div>

      {/* Modals for Read-Only Inspection and Printing */}
      <ReceiptPreviewModal
        isOpen={!!selectedReceipt}
        onClose={() => setSelectedReceipt(null)}
        receipt={selectedReceipt}
      />

      <HallTicketPrintModal
        isOpen={!!selectedHallTicket}
        onClose={() => setSelectedHallTicket(null)}
        hallTicket={selectedHallTicket}
      />

      <ResultTranscriptModal
        isOpen={!!selectedResult}
        onClose={() => setSelectedResult(null)}
        result={selectedResult}
      />
    </div>
  );
}
