import { GraduationCap, Briefcase, Users, School } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { PortalCard } from './PortalCard';
import { PortalType } from '../../types/auth';

export function LandingPage() {
  const { navigateToLogin } = useAuth();

  const portalCards = [
    {
      id: 'student-portal-card',
      portal: 'student' as PortalType,
      title: 'Student',
      tagline: 'Learner Access',
      description:
        'Access your grades, attendance records, coursework, and learning materials.',
      icon: GraduationCap,
      badgeText: 'Students',
      badgeColor: 'blue' as const,
    },
    {
      id: 'employee-portal-card',
      portal: 'employee' as PortalType,
      title: 'Employee',
      tagline: 'Staff & Faculty Access',
      description:
        'Manage academics, student admissions, finance records, or administrative tasks.',
      icon: Briefcase,
      badgeText: 'Staff & Faculty',
      badgeColor: 'purple' as const,
    },
    {
      id: 'parent-portal-card',
      portal: 'parent' as PortalType,
      title: 'Parent/Guardian',
      tagline: 'Family & Guardian Access',
      description:
        'Monitor your child’s academic progress, attendance reports, and institute updates.',
      icon: Users,
      badgeText: 'Parents & Guardians',
      badgeColor: 'emerald' as const,
    },
  ];

  return (
    <div className="w-full max-w-[960px] mx-auto px-4 sm:px-6 py-10 sm:py-16 flex flex-col items-center justify-center">
      {/* Hero Welcome Section */}
      <div className="text-center max-w-xl mx-auto mb-10 sm:mb-12">
        {/* School Logo & Title */}
        <div className="inline-flex items-center justify-center w-12 h-12 mb-4 bg-[#1e3a8a] text-white rounded-lg shadow-xs">
          <School className="w-6 h-6" />
        </div>

        <h1 className="text-2xl sm:text-[32px] font-bold text-[#1e293b] tracking-tight leading-snug mb-2">
          Welcome to Electrix Institute of Technology (EIT)
        </h1>

        {/* Welcome Message */}
        <p className="text-[15px] sm:text-[16px] text-[#64748b] leading-relaxed">
          Please select your gateway to continue into your academic space.
        </p>
      </div>

      {/* Three Prominent Login Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-[900px]">
        {portalCards.map((card) => (
          <PortalCard
            key={card.portal}
            id={card.id}
            portal={card.portal}
            title={card.title}
            tagline={card.tagline}
            description={card.description}
            icon={card.icon}
            badgeText={card.badgeText}
            badgeColor={card.badgeColor}
            onSelect={navigateToLogin}
          />
        ))}
      </div>
    </div>
  );
}
