import React from 'react';
import { ArrowRight, LucideIcon } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { PortalType } from '../../types/auth';

export interface PortalCardProps {
  id: string;
  portal: PortalType;
  title: string;
  tagline: string;
  description: string;
  icon: LucideIcon;
  badgeText: string;
  badgeColor: 'blue' | 'emerald' | 'purple';
  onSelect: (portal: PortalType) => void;
  key?: React.Key;
}

export function PortalCard({
  id,
  portal,
  title,
  description,
  icon: Icon,
  onSelect,
}: PortalCardProps) {
  return (
    <Card
      id={id}
      hoverable
      padding="none"
      onClick={() => onSelect(portal)}
      className="group flex flex-col items-center text-center p-8 bg-white border border-[#e2e8f0] rounded-xl hover:border-[#1e3a8a] shadow-[0_4px_6px_-1px_rgba(0,0,0,0.06)] hover:shadow-md transition-all duration-200 cursor-pointer"
    >
      {/* Clean Minimalism Circular Icon */}
      <div className="w-14 h-14 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center mb-4 group-hover:scale-105 transition-transform duration-200">
        <Icon className="w-6 h-6" />
      </div>

      {/* Card Title */}
      <h3 className="text-[18px] font-semibold text-[#1e293b] mb-2 tracking-tight group-hover:text-[#1e3a8a] transition-colors">
        {title}
      </h3>

      {/* Card Description */}
      <p className="text-[14px] text-[#64748b] leading-relaxed mb-6 flex-1 max-w-xs">
        {description}
      </p>

      {/* Action Button */}
      <Button
        id={`${id}-login-btn`}
        variant="primary"
        size="md"
        onClick={(e) => {
          e.stopPropagation();
          onSelect(portal);
        }}
        rightIcon={<ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />}
        className="w-full"
      >
        {title} Login
      </Button>
    </Card>
  );
}
