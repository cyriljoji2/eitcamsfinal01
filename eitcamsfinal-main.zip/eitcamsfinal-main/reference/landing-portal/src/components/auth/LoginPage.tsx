import React, { useState } from 'react';
import {
  GraduationCap,
  Briefcase,
  Users,
  Lock,
  User,
  ArrowLeft,
  KeyRound,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { PortalType } from '../../types/auth';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';

interface LoginPageProps {
  portal: PortalType;
}

export function LoginPage({ portal }: LoginPageProps) {
  const { login, navigateToLanding, isLoading } = useAuth();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Portal-specific metadata
  const portalMeta = {
    student: {
      title: 'Student Login',
      subtitle: 'Enter your student credentials to access your portal.',
      icon: GraduationCap,
      identifierLabel: 'Username / Student ID',
      identifierPlaceholder: 'Enter your username or Student ID',
    },
    employee: {
      title: 'Employee Login',
      subtitle: 'Enter your Employee ID or institutional username.',
      icon: Briefcase,
      identifierLabel: 'Username / Employee ID',
      identifierPlaceholder: 'Enter your username or Employee ID',
    },
    parent: {
      title: 'Parent/Guardian Login',
      subtitle: 'Enter your registered guardian credentials.',
      icon: Users,
      identifierLabel: 'Username / Guardian ID',
      identifierPlaceholder: 'Enter your username or Guardian ID',
    },
  }[portal];

  const Icon = portalMeta.icon;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const result = await login({
      identifier,
      password,
      portalType: portal,
    });

    if (!result.success && result.errorMessage) {
      setErrorMessage(result.errorMessage);
    }
  };

  return (
    <div className="w-full max-w-[420px] mx-auto px-4 py-8 sm:py-12 flex flex-col items-center">
      {/* Clean Minimalism Login Box */}
      <div className="w-full bg-white border border-[#e2e8f0] rounded-xl p-8 sm:p-10 shadow-[0_4px_6px_-1px_rgba(0,0,0,0.08)]">
        {/* Header with Circular Icon and Clean Headings */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#eff6ff] text-[#1e3a8a] mb-3">
            <Icon className="w-7 h-7" />
          </div>

          <span className="text-[11px] font-bold text-[#1e3a8a] tracking-wider uppercase block mb-1">
            Electrix Institute of Technology (EIT)
          </span>

          <h2 id="login-title" className="text-[22px] sm:text-[24px] font-bold text-[#1e293b] tracking-tight mb-1">
            {portalMeta.title}
          </h2>

          <p id="login-desc" className="text-[13px] sm:text-[14px] text-[#64748b]">
            {portalMeta.subtitle}
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-5">
            <Alert
              type="error"
              message={errorMessage}
              onDismiss={() => setErrorMessage(null)}
            />
          </div>
        )}

        {/* Login Form */}
        <form id={`${portal}-login-form`} onSubmit={handleSubmit} className="space-y-4">
          <Input
            id={`${portal}-identifier-input`}
            label={portalMeta.identifierLabel}
            placeholder={portalMeta.identifierPlaceholder}
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            disabled={isLoading}
            required
            startIcon={<User className="w-4 h-4" />}
            autoFocus
          />

          <Input
            id={`${portal}-password-input`}
            label="Password"
            placeholder="Enter password"
            type="password"
            isPassword
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={isLoading}
            required
            startIcon={<Lock className="w-4 h-4" />}
          />

          <div className="pt-2">
            <Button
              id={`${portal}-submit-btn`}
              type="submit"
              variant="primary"
              size="lg"
              isLoading={isLoading}
              className="w-full"
              rightIcon={<KeyRound className="w-4 h-4" />}
            >
              Sign In
            </Button>
          </div>
        </form>

        {/* Back Link */}
        <div className="mt-5 text-center">
          <button
            id="login-back-button"
            type="button"
            onClick={navigateToLanding}
            className="inline-flex items-center gap-1.5 text-[13px] text-[#64748b] hover:text-[#1e293b] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to selection</span>
          </button>
        </div>
      </div>
    </div>
  );
}
