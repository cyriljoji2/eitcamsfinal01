import { GraduationCap, LogOut, ArrowLeft, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DigitalClock } from './DigitalClock';

export function Header() {
  const { user, viewState, navigateToLanding, logout, isLoading } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="flex items-center justify-between h-16">
          {/* Logo & School Name */}
          <button
            id="school-portal-brand-btn"
            onClick={navigateToLanding}
            className="flex items-center gap-3 text-left group focus:outline-none rounded-md p-1 transition-opacity hover:opacity-90 cursor-pointer"
            aria-label="Electrix Institute of Technology (EIT) Home"
          >
            {/* Clean Minimalism Logo Box */}
            <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-[16px] sm:text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                  Electrix Institute of Technology (EIT)
                </span>
                <span className="hidden sm:inline-block text-[11px] font-medium text-[#64748b] bg-[#f8fafc] px-2 py-0.5 rounded border border-[#e2e8f0]">
                  ERP
                </span>
              </div>
              <span className="text-[11px] text-[#64748b] font-medium hidden md:inline">
                College Academic & Administrative Management Gateway
              </span>
            </div>
          </button>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            {viewState.type === 'login' && (
              <Button
                id="header-back-home-btn"
                variant="ghost"
                size="sm"
                onClick={navigateToLanding}
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                Back to Selection
              </Button>
            )}

            {viewState.type === 'dashboard' && user && (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-[#e2e8f0]">
                  <div className="w-7 h-7 rounded-full bg-[#f1f5f9] border border-[#e2e8f0] flex items-center justify-center text-[#1e293b]">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-left leading-none">
                    <p className="text-[13px] font-semibold text-[#1e293b]">{user.name}</p>
                    <p className="text-[11px] text-[#64748b] mt-0.5">{user.roleTitle}</p>
                  </div>
                </div>

                <Badge variant="blue" size="sm" className="hidden md:inline-flex capitalize">
                  {user.portalType}
                </Badge>

                <Button
                  id="header-logout-btn"
                  variant="danger"
                  size="sm"
                  onClick={logout}
                  isLoading={isLoading}
                  leftIcon={<LogOut className="w-3.5 h-3.5" />}
                >
                  Logout
                </Button>
              </div>
            )}

            {/* Live Digital Clock with Date */}
            <DigitalClock />
          </div>
        </div>
      </div>
    </header>
  );
}
