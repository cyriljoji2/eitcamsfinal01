import { HelpCircle, Mail, Phone } from 'lucide-react';

export function Footer() {
  return (
    <footer className="mt-auto bg-white border-t border-[#e2e8f0] py-6 text-[#64748b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-[#64748b]">
            <span className="font-semibold text-[#1e293b]">Electrix Institute of Technology (EIT)</span>
            <span>&bull;</span>
            <span>College Academic & Information Gateway</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-[#64748b]">
            <div className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#64748b]" />
              <span>portal-support@electrix.edu</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#64748b]" />
              <span>+1 (555) 019-2830</span>
            </div>
            <div className="flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#64748b]" />
              <span>IT Support (8:00 AM – 5:00 PM)</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-[#f1f5f9] flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-[#94a3b8]">
          <p>© {new Date().getFullYear()} Electrix Institute of Technology (EIT). All rights reserved.</p>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="text-[#64748b] font-medium">Phase 1 Foundation &bull; Clean Minimalism</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
