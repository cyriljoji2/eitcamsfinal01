import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

export function DigitalClock({ className = '' }: { className?: string }) {
  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Format time as HH:MM:SS AM/PM (e.g. 02:30:45 PM)
  const formatTime = (date: Date): string => {
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // Hour '0' is '12'
    const strHours = hours < 10 ? `0${hours}` : `${hours}`;
    const strMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const strSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${strHours}:${strMinutes}:${strSeconds} ${ampm}`;
  };

  // Format date as 'Mon, 1 Sep 2026'
  const formatDate = (date: Date): string => {
    const weekday = date.toLocaleDateString('en-US', { weekday: 'short' });
    const day = date.getDate();
    const month = date.toLocaleDateString('en-US', { month: 'short' });
    const year = date.getFullYear();
    return `${weekday}, ${day} ${month} ${year}`;
  };

  const timeString = formatTime(currentTime);
  const dateString = formatDate(currentTime);

  return (
    <div
      id="header-live-clock"
      className={`flex items-center gap-2 sm:gap-2.5 pl-2.5 sm:pl-3.5 border-l border-[#e2e8f0] select-none ${className}`}
      aria-label={`Current time: ${timeString}, ${dateString}`}
    >
      <div className="hidden xs:flex sm:flex w-7 h-7 rounded-md bg-[#eff6ff] text-[#1e3a8a] items-center justify-center shrink-0 border border-[#dbeafe]">
        <Clock className="w-3.5 h-3.5" />
      </div>

      <div className="flex flex-col text-right xs:text-left leading-none">
        <div className="flex items-center gap-1.5 justify-end xs:justify-start">
          <Clock className="w-3 h-3 text-[#1e3a8a] xs:hidden shrink-0" />
          <span className="text-[12px] sm:text-[14px] font-bold text-[#1e293b] tracking-tight tabular-nums font-mono">
            {timeString}
          </span>
        </div>
        <span className="text-[10px] sm:text-[11px] font-medium text-[#64748b] mt-0.5 whitespace-nowrap">
          {dateString}
        </span>
      </div>
    </div>
  );
}
