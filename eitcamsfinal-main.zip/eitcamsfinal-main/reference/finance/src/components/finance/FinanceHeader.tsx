import React from 'react';
import {
  DollarSign,
  Search,
  Bell,
  LogOut,
  User,
  Shield,
  CreditCard,
  Building2,
  Calendar,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Button } from '../ui/Button';

interface FinanceHeaderProps {
  user: UserSession;
  onLogout: () => void;
  onOpenPaymentEntry: () => void;
}

export function FinanceHeader({ user, onLogout, onOpenPaymentEntry }: FinanceHeaderProps) {
  const todayStr = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Left: Brand / Section Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-black shadow-xs">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black text-[#1e293b] tracking-tight">
                  Finance & Accounts Division
                </h1>
                <span className="text-[10px] font-bold bg-blue-50 text-[#1e3a8a] px-2 py-0.5 rounded-full border border-blue-200">
                  Phase 5
                </span>
              </div>
              <p className="text-[11px] text-[#64748b] hidden sm:block">
                Academic Session 2026–2027 &bull; {todayStr}
              </p>
            </div>
          </div>

          {/* Right: Quick Action + User Menu */}
          <div className="flex items-center gap-3">
            <Button
              variant="primary"
              size="sm"
              onClick={onOpenPaymentEntry}
              leftIcon={<CreditCard className="w-3.5 h-3.5" />}
              className="text-xs bg-emerald-700 hover:bg-emerald-800 hidden sm:flex"
            >
              Record Payment
            </Button>

            <div className="h-6 w-px bg-[#e2e8f0] hidden sm:block" />

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-100 border border-[#cbd5e1] text-[#1e3a8a] flex items-center justify-center font-bold text-xs">
                {user.name ? user.name.charAt(0) : 'F'}
              </div>
              <div className="text-left hidden md:block">
                <span className="text-xs font-bold text-[#1e293b] block leading-tight">
                  {user.name || user.username}
                </span>
                <span className="text-[10px] text-[#64748b] font-medium capitalize">
                  Finance Officer
                </span>
              </div>
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              leftIcon={<LogOut className="w-4 h-4" />}
              className="text-xs text-[#64748b] hover:text-red-600"
              title="Sign Out"
            >
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
