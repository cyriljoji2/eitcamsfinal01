import React, { useState } from 'react';
import {
  AlertTriangle,
  Search,
  Filter,
  Download,
  DollarSign,
  Calendar,
  Clock,
  Send,
  CheckCircle2,
  BellRing,
  Eye,
} from 'lucide-react';
import { FeeAssignment } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface OutstandingFeesViewProps {
  assignments: FeeAssignment[];
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function OutstandingFeesView({
  assignments,
  onOpenPaymentModal,
  onViewStudentProfile,
}: OutstandingFeesViewProps) {
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [reminderStatus, setReminderStatus] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Only consider assignments that have a positive balance
  const outstandingList = assignments.filter((a) => a.balance > 0);

  const uniqueClasses = Array.from(new Set(outstandingList.map((a) => a.className))).sort();

  const filtered = outstandingList.filter((a) => {
    const matchesSearch =
      a.studentName.toLowerCase().includes(search.toLowerCase()) ||
      a.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      a.feeTypeName.toLowerCase().includes(search.toLowerCase());

    const matchesClass = classFilter === 'all' || a.className === classFilter;
    const isOverdue = a.dueDate < todayStr;
    const matchesOverdue = !overdueOnly || isOverdue;

    return matchesSearch && matchesClass && matchesOverdue;
  });

  const totalOutstandingSum = filtered.reduce((acc, a) => acc + a.balance, 0);
  const totalOverdueCount = filtered.filter((a) => a.dueDate < todayStr).length;
  const totalOverdueSum = filtered
    .filter((a) => a.dueDate < todayStr)
    .reduce((acc, a) => acc + a.balance, 0);

  const handleExportCsv = () => {
    const headers = [
      'Assignment ID',
      'Registration Number',
      'Student Full Name',
      'Class',
      'Section',
      'Fee Head',
      'Total Amount Due ($)',
      'Amount Paid ($)',
      'Outstanding Balance ($)',
      'Due Date',
      'Is Overdue',
    ];

    const rows = filtered.map((a) => [
      a.id,
      a.studentRegistrationNumber,
      a.studentName,
      a.className,
      a.section,
      a.feeTypeName,
      a.amountDue.toFixed(2),
      a.amountPaid.toFixed(2),
      a.balance.toFixed(2),
      a.dueDate,
      a.dueDate < todayStr ? 'YES (OVERDUE)' : 'NO',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Outstanding_Defaulters_Report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleSendReminder = (studentName: string) => {
    setReminderStatus(`Fee reminder notification logged and dispatched to ${studentName}.`);
    setTimeout(() => setReminderStatus(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Outstanding Fees & Dues Defaulters</h2>
            <span className="bg-red-50 text-red-800 text-xs font-bold px-2 py-0.5 rounded-full border border-red-200">
              {filtered.length} Outstanding Accounts
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Identify overdue accounts, track pending receivables, and initiate recovery workflows.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleExportCsv}
          leftIcon={<Download className="w-3.5 h-3.5" />}
          className="text-xs"
        >
          Export Defaulters CSV
        </Button>
      </div>

      {reminderStatus && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-[#1e3a8a] flex items-center gap-2 animate-in fade-in duration-150">
          <BellRing className="w-4 h-4 text-[#1e3a8a] shrink-0" />
          <span>{reminderStatus}</span>
        </div>
      )}

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-[#64748b] uppercase tracking-wider block">
            Total Outstanding Balance
          </span>
          <span className="text-xl font-black font-mono text-red-700">
            ${totalOutstandingSum.toFixed(2)}
          </span>
          <span className="text-[11px] text-[#64748b] mt-0.5 block">
            Across {filtered.length} fee line items
          </span>
        </div>

        <div className="p-4 bg-amber-50/60 border border-amber-200 rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
            Past-Due / Overdue Dues
          </span>
          <span className="text-xl font-black font-mono text-amber-800">
            ${totalOverdueSum.toFixed(2)}
          </span>
          <span className="text-[11px] text-amber-700 mt-0.5 block">
            {totalOverdueCount} accounts past due date
          </span>
        </div>

        <div className="p-4 bg-blue-50/60 border border-blue-200 rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-[#1e3a8a] uppercase tracking-wider block">
            Average Due per Student
          </span>
          <span className="text-xl font-black font-mono text-[#1e3a8a]">
            ${filtered.length > 0 ? (totalOutstandingSum / filtered.length).toFixed(2) : '0.00'}
          </span>
          <span className="text-[11px] text-[#64748b] mt-0.5 block">
            Filtered subset average
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by student name, Reg No, or fee head..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
          />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Filter className="w-3.5 h-3.5 text-[#64748b]" />
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Classes</option>
            {uniqueClasses.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-1.5 text-xs text-[#1e293b] cursor-pointer">
            <input
              type="checkbox"
              checked={overdueOnly}
              onChange={(e) => setOverdueOnly(e.target.checked)}
              className="rounded text-red-600 focus:ring-red-500"
            />
            <span className="font-semibold text-red-700">Show Past-Due Only</span>
          </label>
        </div>
      </div>

      {/* Defaulters Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Student (Reg No)</th>
                <th className="py-3 px-4">Class</th>
                <th className="py-3 px-4">Fee Head Particular</th>
                <th className="py-3 px-4 text-right">Total Billed</th>
                <th className="py-3 px-4 text-right">Paid So Far</th>
                <th className="py-3 px-4 text-right">Balance Due</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4 text-center">Overdue Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-[#94a3b8]">
                    No outstanding fee balances match the search criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((a) => {
                  const isOverdue = a.dueDate < todayStr;
                  return (
                    <tr key={a.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                          className="hover:text-[#1e3a8a] text-left cursor-pointer"
                        >
                          <div className="font-bold text-[#1e293b]">{a.studentName}</div>
                          <div className="font-mono text-[11px] text-[#1e3a8a] bg-blue-50 px-1 py-0.2 rounded inline-block">
                            {a.studentRegistrationNumber}
                          </div>
                        </button>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-[#475569]">
                        {a.className} &bull; {a.section}
                      </td>

                      <td className="py-3.5 px-4 font-semibold text-[#1e293b]">{a.feeTypeName}</td>

                      <td className="py-3.5 px-4 text-right font-mono text-[#475569]">
                        ${a.amountDue.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-medium text-emerald-700">
                        ${a.amountPaid.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-black text-sm text-red-700">
                        ${a.balance.toFixed(2)}
                      </td>

                      <td className="py-3.5 px-4 text-[#475569] text-[11px] whitespace-nowrap">
                        {a.dueDate}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        {isOverdue ? (
                          <Badge variant="rose" size="sm">
                            Past Due
                          </Badge>
                        ) : (
                          <Badge variant="amber" size="sm">
                            Upcoming Due
                          </Badge>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => onOpenPaymentModal(a.studentRegistrationNumber, a.id)}
                            leftIcon={<DollarSign className="w-3 h-3" />}
                            className="text-[11px] py-1 px-2"
                          >
                            Collect
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleSendReminder(a.studentName)}
                            leftIcon={<Send className="w-3 h-3" />}
                            className="text-[11px] py-1 px-2 text-[#475569]"
                            title="Send notice to student / parent"
                          >
                            Notice
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
