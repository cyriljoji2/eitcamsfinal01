import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Layers,
  Users,
  CreditCard,
  Receipt,
  AlertCircle,
  BarChart3,
  FileText,
  DollarSign,
  Search,
  BookOpen,
  ArrowLeft,
  Filter,
  Plus,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student } from '../../types/admission';
import {
  FeeStructureItem,
  FeeAssignment,
  PaymentRecord,
  FeeReceipt,
  StudentFeeSummary,
  FinanceDashboardMetrics,
} from '../../types/finance';
import { admissionRepository } from '../../services/admissionService';
import { financeRepository } from '../../services/financeService';
import { FinanceHeader } from './FinanceHeader';
import { FinanceOverview } from './FinanceOverview';
import { FeeStructureView } from './FeeStructureView';
import { FeeAssignmentsView } from './FeeAssignmentsView';
import { StudentFeeLedgerView } from './StudentFeeLedgerView';
import { PaymentsView } from './PaymentsView';
import { ReceiptsView } from './ReceiptsView';
import { OutstandingFeesView } from './OutstandingFeesView';
import { FinancialReportsView } from './FinancialReportsView';
import { PaymentEntryModal } from './PaymentEntryModal';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { StudentFeeProfileModal } from './StudentFeeProfileModal';
import { VoidPaymentModal } from './VoidPaymentModal';
import { FeeStructureModal } from './FeeStructureModal';

interface FinanceWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
  onNavigateToAdmin?: () => void;
}

type FinanceTab =
  | 'overview'
  | 'structure'
  | 'assignments'
  | 'student-fees'
  | 'payments'
  | 'receipts'
  | 'outstanding'
  | 'reports';

export function FinanceWorkspace({ user, onLogout, onNavigateToAdmin }: FinanceWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<FinanceTab>('overview');

  // Core Data States
  const [students, setStudents] = useState<Student[]>([]);
  const [feeStructures, setFeeStructures] = useState<FeeStructureItem[]>([]);
  const [assignments, setAssignments] = useState<FeeAssignment[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [receipts, setReceipts] = useState<FeeReceipt[]>([]);
  const [summaries, setSummaries] = useState<StudentFeeSummary[]>([]);
  const [metrics, setMetrics] = useState<FinanceDashboardMetrics>({
    totalFeesAssigned: 0,
    totalAmountCollected: 0,
    totalOutstanding: 0,
    totalWaived: 0,
    studentsWithOutstandingCount: 0,
    totalStudentsAssignedCount: 0,
    todayCollection: 0,
    recentPayments: [],
    recentReceipts: [],
    categoryCollectionBreakdown: [],
    paymentModeBreakdown: [],
  });

  const [isLoading, setIsLoading] = useState(true);

  // Modal States
  const [paymentModalState, setPaymentModalState] = useState<{
    isOpen: boolean;
    studentRegNo?: string;
    assignmentId?: string;
  }>({
    isOpen: false,
  });

  const [receiptModalState, setReceiptModalState] = useState<{
    isOpen: boolean;
    receipt: FeeReceipt | null;
  }>({
    isOpen: false,
    receipt: null,
  });

  const [studentProfileModalState, setStudentProfileModalState] = useState<{
    isOpen: boolean;
    summary: StudentFeeSummary | null;
  }>({
    isOpen: false,
    summary: null,
  });

  const [voidModalState, setVoidModalState] = useState<{
    isOpen: boolean;
    payment: PaymentRecord | null;
  }>({
    isOpen: false,
    payment: null,
  });

  const [feeStructureModalState, setFeeStructureModalState] = useState<{
    isOpen: boolean;
    item: FeeStructureItem | null;
  }>({
    isOpen: false,
    item: null,
  });

  const [preselectedFeeStructureId, setPreselectedFeeStructureId] = useState<string | undefined>(
    undefined
  );

  // Load all finance and student data
  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [
        loadedStudents,
        loadedStructures,
        loadedAssignments,
        loadedPayments,
        loadedReceipts,
        loadedSummaries,
        loadedMetrics,
      ] = await Promise.all([
        admissionRepository.getAllStudents(),
        financeRepository.getFeeStructures(),
        financeRepository.getFeeAssignments(),
        financeRepository.getPayments(),
        financeRepository.getReceipts(),
        financeRepository.getAllStudentSummaries(),
        financeRepository.getDashboardMetrics(),
      ]);

      setStudents(loadedStudents);
      setFeeStructures(loadedStructures);
      setAssignments(loadedAssignments);
      setPayments(loadedPayments);
      setReceipts(loadedReceipts);
      setSummaries(loadedSummaries);
      setMetrics(loadedMetrics);

      // If a student profile modal is open, refresh its data
      if (studentProfileModalState.isOpen && studentProfileModalState.summary) {
        const updatedSummary = loadedSummaries.find(
          (s) =>
            s.studentRegistrationNumber.toLowerCase() ===
            studentProfileModalState.summary?.studentRegistrationNumber.toLowerCase()
        );
        if (updatedSummary) {
          setStudentProfileModalState((prev) => ({ ...prev, summary: updatedSummary }));
        }
      }
    } catch (error) {
      console.error('Error loading finance workspace data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [studentProfileModalState.isOpen, studentProfileModalState.summary]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Payment Submission Handler
  const handleRecordPayment = async (data: any) => {
    const result = await financeRepository.recordPayment(data);
    await loadData();
    return result;
  };

  // Void Payment Handler
  const handleVoidPayment = async (paymentId: string, reason: string, voidedBy: string) => {
    await financeRepository.voidPayment(paymentId, reason, voidedBy);
    await loadData();
  };

  // Fee Waiver Handler
  const handleWaiveFee = async (assignmentId: string, waiverAmount: number, reason: string) => {
    await financeRepository.waiveFee(
      assignmentId,
      waiverAmount,
      reason,
      user.name || user.username
    );
    await loadData();
  };

  // Fee Structure Handlers
  const handleCreateFeeStructure = async (data: any) => {
    await financeRepository.createFeeStructure(data);
    await loadData();
  };

  const handleUpdateFeeStructure = async (id: string, data: any) => {
    await financeRepository.updateFeeStructure(id, data);
    await loadData();
  };

  const handleToggleFeeStructureStatus = async (id: string) => {
    await financeRepository.toggleFeeStructureStatus(id);
    await loadData();
  };

  const handleDeleteFeeStructure = async (id: string) => {
    await financeRepository.deleteFeeStructure(id);
    await loadData();
  };

  // Fee Assignment Handlers
  const handleAssignFeeToClass = async (params: {
    feeStructureId: string;
    className: string;
    section?: string;
    dueDate?: string;
    remarks?: string;
  }) => {
    const result = await financeRepository.assignToClass(
      params.className,
      params.section || 'All',
      params.feeStructureId,
      user.name || user.username,
      params.dueDate
    );
    await loadData();
    return { count: result.created.length, skippedCount: result.skippedCount };
  };

  const handleAssignFeeToStudent = async (params: {
    feeStructureId: string;
    studentRegistrationNumber: string;
    customAmount?: number;
    discountOrWaiver?: number;
    waiverReason?: string;
    dueDate?: string;
    remarks?: string;
  }) => {
    const result = await financeRepository.assignToStudent(
      params.studentRegistrationNumber,
      params.feeStructureId,
      user.name || user.username,
      params.customAmount,
      params.dueDate
    );
    await loadData();
    return result;
  };

  // Open Student Fee Ledger Profile by Registration Number
  const handleViewStudentProfile = async (regNo: string) => {
    const summary = await financeRepository.getStudentFeeSummary(regNo);
    if (summary) {
      setStudentProfileModalState({
        isOpen: true,
        summary,
      });
    }
  };

  const navItems: { id: FinanceTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'overview', label: 'Finance Dashboard', icon: LayoutDashboard },
    { id: 'structure', label: 'Fee Structure', icon: Layers },
    { id: 'assignments', label: 'Fee Assignments', icon: Users },
    { id: 'student-fees', label: 'Student Fee Ledger', icon: DollarSign },
    { id: 'payments', label: 'Payments & Collections', icon: CreditCard },
    { id: 'receipts', label: 'Receipts Registry', icon: Receipt },
    { id: 'outstanding', label: 'Outstanding & Defaulters', icon: AlertCircle },
    { id: 'reports', label: 'Financial Reports', icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-[#1e293b] flex flex-col font-sans">
      {/* Top Header */}
      <FinanceHeader
        user={user}
        onLogout={onLogout}
        onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Navigation Tab Pills Bar */}
        <div className="bg-white rounded-2xl p-2 border border-[#e2e8f0] shadow-xs mb-6 overflow-x-auto">
          <div className="flex items-center gap-1.5 min-w-max">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#1e3a8a] text-white shadow-xs'
                      : 'text-[#64748b] hover:bg-[#f1f5f9] hover:text-[#1e293b]'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* View Router */}
        {isLoading ? (
          <div className="py-24 text-center space-y-3">
            <div className="w-8 h-8 border-3 border-[#1e3a8a] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-[#64748b] font-medium">Loading finance records...</p>
          </div>
        ) : (
          <>
            {activeTab === 'overview' && (
              <FinanceOverview
                metrics={metrics}
                recentPayments={payments}
                receipts={receipts}
                onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
                onOpenFeeStructureModal={() =>
                  setFeeStructureModalState({ isOpen: true, item: null })
                }
                onNavigateTab={(tab) => setActiveTab(tab)}
                onOpenReceiptModal={(receipt) => setReceiptModalState({ isOpen: true, receipt })}
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'structure' && (
              <FeeStructureView
                feeStructures={feeStructures}
                onCreateFeeStructure={handleCreateFeeStructure}
                onUpdateFeeStructure={handleUpdateFeeStructure}
                onToggleStatus={handleToggleFeeStructureStatus}
                onDeleteFeeStructure={handleDeleteFeeStructure}
                onNavigateToAssign={(feeId) => {
                  setPreselectedFeeStructureId(feeId);
                  setActiveTab('assignments');
                }}
              />
            )}

            {activeTab === 'assignments' && (
              <FeeAssignmentsView
                students={students}
                feeStructures={feeStructures}
                assignments={assignments}
                initialPreselectedFeeId={preselectedFeeStructureId}
                onAssignFeeToClass={handleAssignFeeToClass}
                onAssignFeeToStudent={handleAssignFeeToStudent}
                onOpenPaymentModal={(regNo, assignmentId) =>
                  setPaymentModalState({ isOpen: true, studentRegNo: regNo, assignmentId })
                }
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'student-fees' && (
              <StudentFeeLedgerView
                summaries={summaries}
                onOpenPaymentModal={(regNo) =>
                  setPaymentModalState({ isOpen: true, studentRegNo: regNo })
                }
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'payments' && (
              <PaymentsView
                payments={payments}
                receipts={receipts}
                onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
                onOpenReceiptModal={(receipt) => setReceiptModalState({ isOpen: true, receipt })}
                onOpenVoidModal={(payment) => setVoidModalState({ isOpen: true, payment })}
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'receipts' && (
              <ReceiptsView
                receipts={receipts}
                onOpenReceiptModal={(receipt) => setReceiptModalState({ isOpen: true, receipt })}
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'outstanding' && (
              <OutstandingFeesView
                assignments={assignments}
                onOpenPaymentModal={(regNo, assignmentId) =>
                  setPaymentModalState({ isOpen: true, studentRegNo: regNo, assignmentId })
                }
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}

            {activeTab === 'reports' && (
              <FinancialReportsView
                payments={payments}
                assignments={assignments}
                receipts={receipts}
                summaries={summaries}
                onViewStudentProfile={handleViewStudentProfile}
              />
            )}
          </>
        )}
      </div>

      {/* MODAL 1: RECORD PAYMENT */}
      <PaymentEntryModal
        isOpen={paymentModalState.isOpen}
        onClose={() => setPaymentModalState({ isOpen: false })}
        students={students}
        assignments={assignments}
        initialStudentRegNo={paymentModalState.studentRegNo}
        initialAssignmentId={paymentModalState.assignmentId}
        currentUserFullName={user.name || user.username}
        onSubmitPayment={handleRecordPayment}
        onPaymentSuccess={(receipt) => {
          setReceiptModalState({ isOpen: true, receipt });
        }}
      />

      {/* MODAL 2: RECEIPT PREVIEW & PRINT */}
      <ReceiptPreviewModal
        isOpen={receiptModalState.isOpen}
        onClose={() => setReceiptModalState({ isOpen: false, receipt: null })}
        receipt={receiptModalState.receipt}
      />

      {/* MODAL 3: STUDENT FEE PROFILE & BREAKDOWN */}
      <StudentFeeProfileModal
        isOpen={studentProfileModalState.isOpen}
        onClose={() => setStudentProfileModalState({ isOpen: false, summary: null })}
        summary={studentProfileModalState.summary}
        onOpenPaymentModal={(regNo, assignmentId) =>
          setPaymentModalState({ isOpen: true, studentRegNo: regNo, assignmentId })
        }
        onOpenReceiptModal={(receipt) => setReceiptModalState({ isOpen: true, receipt })}
        onOpenVoidModal={(payment) => setVoidModalState({ isOpen: true, payment })}
        onWaiveFee={handleWaiveFee}
      />

      {/* MODAL 4: VOID PAYMENT TRANSACTION */}
      <VoidPaymentModal
        isOpen={voidModalState.isOpen}
        onClose={() => setVoidModalState({ isOpen: false, payment: null })}
        payment={voidModalState.payment}
        currentUserName={user.name || user.username}
        onConfirmVoid={handleVoidPayment}
      />

      {/* MODAL 5: FEE STRUCTURE CREATE / EDIT */}
      <FeeStructureModal
        isOpen={feeStructureModalState.isOpen}
        onClose={() => setFeeStructureModalState({ isOpen: false, item: null })}
        item={feeStructureModalState.item}
        onSubmit={async (data) => {
          if (feeStructureModalState.item) {
            await handleUpdateFeeStructure(feeStructureModalState.item.id, data);
          } else {
            await handleCreateFeeStructure(data);
          }
        }}
      />
    </div>
  );
}
