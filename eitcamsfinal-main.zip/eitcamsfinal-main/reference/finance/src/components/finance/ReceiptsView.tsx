import React, { useState } from 'react';
import {
  Receipt,
  Search,
  Filter,
  Printer,
  Download,
  Calendar,
  CreditCard,
  Building2,
  FileText,
  User,
} from 'lucide-react';
import { FeeReceipt } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ReceiptsViewProps {
  receipts: FeeReceipt[];
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function ReceiptsView({
  receipts,
  onOpenReceiptModal,
  onViewStudentProfile,
}: ReceiptsViewProps) {
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'voided'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredReceipts = receipts.filter((r) => {
    const matchesSearch =
      r.receiptNumber.toLowerCase().includes(search.toLowerCase()) ||
      r.studentName.toLowerCase().includes(search.toLowerCase()) ||
      r.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      r.feeTypeName.toLowerCase().includes(search.toLowerCase());

    const matchesMode = modeFilter === 'all' || r.paymentMode === modeFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'valid'
        ? !r.isVoided
        : r.isVoided;

    const matchesStart = !startDate || r.receiptDate >= startDate;
    const matchesEnd = !endDate || r.receiptDate <= endDate;

    return matchesSearch && matchesMode && matchesStatus && matchesStart && matchesEnd;
  });

  const validReceipts = filteredReceipts.filter((r) => !r.isVoided);
  const totalAmount = validReceipts.reduce((acc, r) => acc + r.amountPaid, 0);

  const handleExportCsv = () => {
    const headers = [
      'Receipt Number',
      'Payment ID',
      'Date',
      'Student Reg No',
      'Student Name',
      'Class',
      'Section',
      'Fee Head',
      'Amount Paid ($)',
      'Payment Mode',
      'Transaction Ref',
      'Received By',
      'Balance After Payment ($)',
      'Status',
    ];

    const rows = filteredReceipts.map((r) => [
      r.receiptNumber,
      r.paymentId,
      r.receiptDate,
      r.studentRegistrationNumber,
      r.studentName,
      r.className,
      r.section,
      r.feeTypeName,
      r.amountPaid.toFixed(2),
      r.paymentMode,
      r.transactionReference || 'N/A',
      r.receivedBy,
      r.outstandingBalanceAfterPayment.toFixed(2),
      r.isVoided ? 'VOIDED' : 'VALID',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Fee_Receipts_Registry_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Fee Receipts Registry</h2>
            <span className="bg-blue-50 text-[#1e3a8a] text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
              {receipts.length} Total Issued
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Sequential, unique receipt serials with print formatting and audit verification.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleExportCsv}
          leftIcon={<Download className="w-3.5 h-3.5" />}
          className="text-xs"
        >
          Export Receipts CSV
        </Button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by Receipt # (e.g. REC-2026-0001), student name, or Reg No..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={modeFilter}
            onChange={(e) => setModeFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Payment Modes</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cheque">Cheque</option>
            <option value="Other">Other</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Receipts</option>
            <option value="valid">Official Valid Only</option>
            <option value="voided">Voided / Cancelled Only</option>
          </select>

          <div className="flex items-center gap-1 text-xs text-[#64748b]">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2 py-1 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
              title="From date"
            />
            <span>to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2 py-1 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
              title="To date"
            />
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Receipt #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Student Name & Reg #</th>
                <th className="py-3 px-4">Class</th>
                <th className="py-3 px-4">Fee Head</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4 text-right">Amount Paid</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-[#94a3b8]">
                    No receipts found matching search and filter criteria.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((r) => (
                  <tr
                    key={r.receiptNumber}
                    className={`hover:bg-[#f8fafc] transition-colors ${
                      r.isVoided ? 'bg-red-50/20 opacity-75' : ''
                    }`}
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">
                      {r.receiptNumber}
                    </td>

                    <td className="py-3.5 px-4 text-[#475569] whitespace-nowrap">
                      {r.receiptDate}
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        type="button"
                        onClick={() => onViewStudentProfile(r.studentRegistrationNumber)}
                        className="hover:text-[#1e3a8a] text-left cursor-pointer"
                      >
                        <div className="font-bold text-[#1e293b]">{r.studentName}</div>
                        <div className="font-mono text-[11px] text-[#64748b]">
                          {r.studentRegistrationNumber}
                        </div>
                      </button>
                    </td>

                    <td className="py-3.5 px-4 font-medium text-[#475569]">
                      {r.className} - {r.section}
                    </td>

                    <td className="py-3.5 px-4 font-semibold text-[#1e293b]">
                      {r.feeTypeName}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-medium text-[#475569] flex items-center gap-1">
                        <CreditCard className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        {r.paymentMode}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold text-sm text-[#1e293b]">
                      ${r.amountPaid.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {r.isVoided ? (
                        <Badge variant="rose" size="sm">
                          Voided
                        </Badge>
                      ) : (
                        <Badge variant="emerald" size="sm">
                          Valid
                        </Badge>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => onOpenReceiptModal(r)}
                        leftIcon={<Printer className="w-3.5 h-3.5" />}
                        className="text-[11px] py-1 px-2.5"
                      >
                        Print / View
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
