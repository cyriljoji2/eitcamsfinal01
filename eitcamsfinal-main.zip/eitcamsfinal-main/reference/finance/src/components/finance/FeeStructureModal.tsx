import React, { useState, useEffect } from 'react';
import { Layers, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { FeeCategory, FeeStructureItem } from '../../types/finance';
import { Button } from '../ui/Button';

interface FeeStructureModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: FeeStructureItem | null;
  onSubmit: (data: Omit<FeeStructureItem, 'id' | 'createdAt'>) => Promise<any>;
}

const CATEGORIES: FeeCategory[] = [
  'Tuition Fee',
  'Admission Fee',
  'Examination Fee',
  'Transport Fee',
  'Activity Fee',
  'Laboratory Fee',
  'Library Fee',
  'Hostel Fee',
  'Other Fee',
];

const AVAILABLE_CLASSES = [
  'All',
  'B.Tech Computer Science & Engineering',
  'B.Tech Electronics & Communication Engineering',
  'B.Tech Mechanical Engineering',
  'B.Tech Information Technology',
  'M.Tech Computer Science',
];

export function FeeStructureModal({ isOpen, onClose, item, onSubmit }: FeeStructureModalProps) {
  const [name, setName] = useState('');
  const [feeCategory, setFeeCategory] = useState<FeeCategory>('Tuition Fee');
  const [amount, setAmount] = useState('');
  const [academicSession, setAcademicSession] = useState('2026–2027');
  const [selectedClasses, setSelectedClasses] = useState<string[]>(['All']);
  const [dueDate, setDueDate] = useState('2026-09-15');
  const [frequency, setFrequency] = useState<FeeStructureItem['frequency']>('Term-Wise');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setIsSubmitting(false);
      if (item) {
        setName(item.name);
        setFeeCategory(item.feeCategory);
        setAmount(String(item.amount));
        setAcademicSession(item.academicSession);
        setSelectedClasses(item.applicableClassNames || ['All']);
        setDueDate(item.dueDate);
        setFrequency(item.frequency);
        setDescription(item.description || '');
        setStatus(item.status);
      } else {
        setName('');
        setFeeCategory('Tuition Fee');
        setAmount('');
        setAcademicSession('2026–2027');
        setSelectedClasses(['All']);
        setDueDate('2026-09-15');
        setFrequency('Term-Wise');
        setDescription('');
        setStatus('active');
      }
    }
  }, [isOpen, item]);

  if (!isOpen) return null;

  const toggleClass = (className: string) => {
    if (className === 'All') {
      setSelectedClasses(['All']);
      return;
    }

    let next = selectedClasses.filter((c) => c !== 'All');
    if (next.includes(className)) {
      next = next.filter((c) => c !== className);
      if (next.length === 0) next = ['All'];
    } else {
      next.push(className);
    }
    setSelectedClasses(next);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please enter a valid amount greater than 0.');
      return;
    }

    if (!name.trim()) {
      setError('Fee name is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        name: name.trim(),
        feeCategory,
        amount: parsedAmount,
        academicSession,
        applicableClassNames: selectedClasses,
        dueDate,
        frequency,
        description: description.trim() || undefined,
        status,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save fee structure.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">
                {item ? 'Edit Fee Structure' : 'Create New Fee Head'}
              </h3>
              <p className="text-xs text-[#64748b]">Configure amounts, classes, and due dates.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94a3b8] hover:text-[#1e293b] hover:bg-[#f1f5f9] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Fee Head Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Term 1 Tuition Fee - Senior Secondary"
              className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Fee Category <span className="text-red-500">*</span>
              </label>
              <select
                value={feeCategory}
                onChange={(e) => setFeeCategory(e.target.value as FeeCategory)}
                className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-white"
                required
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Amount ($) <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Academic Session
              </label>
              <input
                type="text"
                value={academicSession}
                onChange={(e) => setAcademicSession(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Billing Frequency
              </label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-white"
              >
                <option value="Term-Wise">Term-Wise</option>
                <option value="Annual">Annual</option>
                <option value="Monthly">Monthly</option>
                <option value="One-Time">One-Time</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Default Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-white"
                required
              />
            </div>
          </div>

          {/* Applicable Academic Programs */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Applicable Academic Programs
            </label>
            <div className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
              {AVAILABLE_CLASSES.map((cls) => {
                const isSelected = selectedClasses.includes(cls);
                return (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => toggleClass(cls)}
                    className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#1e3a8a] text-white shadow-xs'
                        : 'bg-white text-[#64748b] border border-[#cbd5e1] hover:bg-[#f1f5f9]'
                    }`}
                  >
                    {cls}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Description / Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Includes laboratory supplies and computing resources."
              className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Status
            </label>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-1.5 text-xs text-[#1e293b] cursor-pointer">
                <input
                  type="radio"
                  name="feeStatus"
                  value="active"
                  checked={status === 'active'}
                  onChange={() => setStatus('active')}
                  className="text-[#1e3a8a] focus:ring-[#1e3a8a]"
                />
                Active (Available for Assignment)
              </label>
              <label className="flex items-center gap-1.5 text-xs text-[#64748b] cursor-pointer">
                <input
                  type="radio"
                  name="feeStatus"
                  value="inactive"
                  checked={status === 'inactive'}
                  onChange={() => setStatus('inactive')}
                  className="text-[#1e3a8a] focus:ring-[#1e3a8a]"
                />
                Inactive / Draft
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-[#e2e8f0] flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              isLoading={isSubmitting}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
            >
              {item ? 'Save Changes' : 'Create Fee Head'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
