import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  X,
  Search,
  CheckCircle2,
  AlertCircle,
  DollarSign,
  Calendar,
  FileText,
  User,
  Info,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { FeeAssignment, FeeReceipt, PaymentMode, PaymentRecord } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface PaymentEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  assignments: FeeAssignment[];
  initialStudentRegNo?: string;
  initialAssignmentId?: string;
  currentUserFullName?: string;
  onSubmitPayment: (data: {
    studentRegistrationNumber: string;
    feeAssignmentId?: string;
    feeTypeName: string;
    amountPaid: number;
    paymentDate: string;
    paymentMode: PaymentMode;
    transactionReference?: string;
    remarks?: string;
    receivedBy: string;
    academicSession?: string;
  }) => Promise<{ payment: PaymentRecord; receipt: FeeReceipt }>;
  onPaymentSuccess?: (receipt: FeeReceipt) => void;
}

export function PaymentEntryModal({
  isOpen,
  onClose,
  students,
  assignments,
  initialStudentRegNo,
  initialAssignmentId,
  currentUserFullName = 'Finance Officer',
  onSubmitPayment,
  onPaymentSuccess,
}: PaymentEntryModalProps) {
  const [selectedRegNo, setSelectedRegNo] = useState<string>('');
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>('');
  const [feeTypeName, setFeeTypeName] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('Cash');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [receivedBy, setReceivedBy] = useState<string>(currentUserFullName);
  const [allowAdvance, setAllowAdvance] = useState<boolean>(false);

  // Student search in dropdown
  const [studentSearch, setStudentSearch] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Reset or preset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
      setIsSubmitting(false);
      setPaymentDate(new Date().toISOString().split('T')[0]);

      if (initialStudentRegNo) {
        setSelectedRegNo(initialStudentRegNo);
      } else if (students.length > 0) {
        setSelectedRegNo(students[0].registrationNumber);
      }

      if (initialAssignmentId) {
        setSelectedAssignmentId(initialAssignmentId);
        const match = assignments.find((a) => a.id === initialAssignmentId);
        if (match) {
          setFeeTypeName(match.feeTypeName);
          setAmountPaid(String(match.balance));
        }
      } else {
        setSelectedAssignmentId('');
        setAmountPaid('');
        setFeeTypeName('');
      }
    }
  }, [isOpen, initialStudentRegNo, initialAssignmentId, students, assignments]);

  // When selected student changes, update the assignments list
  const studentAssignments = assignments.filter(
    (a) => a.studentRegistrationNumber.toLowerCase() === selectedRegNo.toLowerCase()
  );

  const selectedStudent = students.find(
    (s) => s.registrationNumber.toLowerCase() === selectedRegNo.toLowerCase()
  );

  const selectedAssignment = assignments.find((a) => a.id === selectedAssignmentId);

  // When assignment selection changes
  const handleAssignmentChange = (assignmentId: string) => {
    setSelectedAssignmentId(assignmentId);
    if (assignmentId === 'custom') {
      setFeeTypeName('Miscellaneous College Fee');
      setAmountPaid('');
    } else {
      const matched = assignments.find((a) => a.id === assignmentId);
      if (matched) {
        setFeeTypeName(matched.feeTypeName);
        setAmountPaid(String(matched.balance));
      }
    }
  };

  if (!isOpen) return null;

  const filteredStudents = students.filter(
    (s) =>
      s.fullName.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.registrationNumber.toLowerCase().includes(studentSearch.toLowerCase()) ||
      s.admissionClass.toLowerCase().includes(studentSearch.toLowerCase())
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const parsedAmount = parseFloat(amountPaid);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMessage('Please enter a valid payment amount greater than zero.');
      return;
    }

    if (!selectedRegNo) {
      setErrorMessage('Please select a student.');
      return;
    }

    if (!feeTypeName.trim()) {
      setErrorMessage('Please select or specify a fee type.');
      return;
    }

    if (selectedAssignment && !allowAdvance && parsedAmount > selectedAssignment.balance) {
      setErrorMessage(
        `Payment amount ($${parsedAmount}) exceeds the current outstanding balance ($${selectedAssignment.balance}) for this fee assignment.`
      );
      return;
    }

    if (paymentMode !== 'Cash' && !transactionRef.trim()) {
      setErrorMessage(`Please provide a Transaction / Reference / Cheque number for ${paymentMode} payment.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await onSubmitPayment({
        studentRegistrationNumber: selectedRegNo,
        feeAssignmentId: selectedAssignmentId === 'custom' ? undefined : selectedAssignmentId || undefined,
        feeTypeName,
        amountPaid: parsedAmount,
        paymentDate,
        paymentMode,
        transactionReference: transactionRef.trim() || undefined,
        remarks: remarks.trim() || undefined,
        receivedBy: receivedBy.trim() || currentUserFullName,
        academicSession: selectedAssignment?.academicSession || '2026–2027',
      });

      onClose();
      if (onPaymentSuccess) {
        onPaymentSuccess(result.receipt);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to record payment transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Header */}
        <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">Record Fee Payment</h3>
              <p className="text-xs text-[#64748b]">
                Collect student dues & instantly generate an official receipt.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#94a3b8] hover:text-[#1e293b] hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Student Selector */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Select Student (Registration Number) <span className="text-red-500">*</span>
            </label>
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-[#94a3b8]" />
                <input
                  type="text"
                  placeholder="Filter student list by name or Reg No..."
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  className="w-full pl-8.5 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent outline-hidden bg-[#f8fafc]"
                />
              </div>

              <select
                value={selectedRegNo}
                onChange={(e) => {
                  setSelectedRegNo(e.target.value);
                  setSelectedAssignmentId('');
                  setAmountPaid('');
                  setFeeTypeName('');
                }}
                className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent outline-hidden bg-white"
                required
              >
                <option value="" disabled>
                  -- Choose an approved student --
                </option>
                {filteredStudents.map((s) => (
                  <option key={s.registrationNumber} value={s.registrationNumber}>
                    {s.registrationNumber} — {s.fullName} ({s.admissionClass} - Sec {s.section})
                  </option>
                ))}
              </select>
            </div>

            {selectedStudent && (
              <div className="mt-2 p-2.5 bg-blue-50/50 border border-blue-100 rounded-lg text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold text-[#1e293b]">{selectedStudent.fullName}</span>
                  <span className="text-[#64748b] ml-2 font-mono">({selectedStudent.registrationNumber})</span>
                </div>
                <span className="text-[#1e3a8a] font-semibold">
                  {selectedStudent.admissionClass} &bull; Section {selectedStudent.section}
                </span>
              </div>
            )}
          </div>

          {/* Fee Assignment / Fee Type Selector */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Fee Head / Particular <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedAssignmentId}
              onChange={(e) => handleAssignmentChange(e.target.value)}
              className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] focus:border-transparent outline-hidden bg-white"
              required
            >
              <option value="" disabled>
                -- Select Fee Item to Clear --
              </option>
              {studentAssignments.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.feeTypeName} (Due: ${a.amountDue} | Balance: ${a.balance} | Status: {a.status})
                </option>
              ))}
              <option value="custom">+ General / Other Custom Fee Payment</option>
            </select>
          </div>

          {selectedAssignmentId === 'custom' && (
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Custom Fee Type Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={feeTypeName}
                onChange={(e) => setFeeTypeName(e.target.value)}
                placeholder="e.g. Lost ID Replacement, Duplicate Certificate, Late Fine"
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
                required
              />
            </div>
          )}

          {/* Selected Fee Outstanding Information Card */}
          {selectedAssignment && (
            <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl text-xs flex items-center justify-between">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Original Amount Due
                </span>
                <span className="font-bold text-[#1e293b] font-mono text-sm">
                  ${selectedAssignment.amountDue.toFixed(2)}
                </span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Amount Already Paid
                </span>
                <span className="font-semibold text-emerald-700 font-mono">
                  ${selectedAssignment.amountPaid.toFixed(2)}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Current Outstanding
                </span>
                <span className="font-black text-red-700 font-mono text-base">
                  ${selectedAssignment.balance.toFixed(2)}
                </span>
              </div>
            </div>
          )}

          {/* Payment Amount & Payment Date Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Amount Being Paid ($) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-[#94a3b8] font-bold text-sm">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-7 pr-3 py-2 text-sm font-bold font-mono rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden text-[#1e293b]"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Payment Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-white"
                required
              />
            </div>
          </div>

          {/* Payment Mode & Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Payment Mode <span className="text-red-500">*</span>
              </label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-white"
                required
              >
                <option value="Cash">Cash (Counter Deposit)</option>
                <option value="UPI">UPI (GooglePay / PhonePe / Paytm / QR)</option>
                <option value="Bank Transfer">Bank Transfer (NEFT / RTGS / IMPS / Wire)</option>
                <option value="Cheque">Cheque (Bank Draft / Cheque)</option>
                <option value="Other">Other Mode</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
                Transaction / Reference / Cheque #{' '}
                {paymentMode !== 'Cash' ? <span className="text-red-500">*</span> : <span className="text-[#94a3b8]">(Optional)</span>}
              </label>
              <input
                type="text"
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder={
                  paymentMode === 'Cash'
                    ? 'Receipt scroll note'
                    : paymentMode === 'Cheque'
                    ? 'Cheque # & Issuing Bank'
                    : 'UPI Ref ID / UTR Number'
                }
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
                required={paymentMode !== 'Cash'}
              />
            </div>
          </div>

          {/* Cashier / Received By & Remarks */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Received & Verified By
              </label>
              <input
                type="text"
                value={receivedBy}
                onChange={(e) => setReceivedBy(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Remarks / Notes (Optional)
              </label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="e.g. 1st installment paid in cash"
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
              />
            </div>
          </div>

          {/* Advance payment override toggle */}
          {selectedAssignment && parseFloat(amountPaid) > selectedAssignment.balance && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
              <input
                type="checkbox"
                id="allowAdvance"
                checked={allowAdvance}
                onChange={(e) => setAllowAdvance(e.target.checked)}
                className="mt-0.5 rounded text-[#1e3a8a] focus:ring-[#1e3a8a]"
              />
              <label htmlFor="allowAdvance" className="text-xs text-amber-900 cursor-pointer">
                <strong>Allow Advance Payment:</strong> The entered amount (${amountPaid}) exceeds the outstanding balance (${selectedAssignment.balance}). Check this box to proceed with an advance credit.
              </label>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-4 border-t border-[#e2e8f0] flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              isLoading={isSubmitting}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
            >
              Confirm & Generate Receipt
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
