import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  DollarSign,
  AlertCircle,
  Download,
  Info,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { FeeAssignment, FeeStructureItem } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface FeeAssignmentsViewProps {
  students: Student[];
  feeStructures: FeeStructureItem[];
  assignments: FeeAssignment[];
  initialPreselectedFeeId?: string;
  onAssignFeeToClass: (params: {
    feeStructureId: string;
    className: string;
    section?: string;
    dueDate?: string;
    remarks?: string;
  }) => Promise<{ count: number; skippedCount: number }>;
  onAssignFeeToStudent: (params: {
    feeStructureId: string;
    studentRegistrationNumber: string;
    customAmount?: number;
    discountOrWaiver?: number;
    waiverReason?: string;
    dueDate?: string;
    remarks?: string;
  }) => Promise<FeeAssignment>;
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function FeeAssignmentsView({
  students,
  feeStructures,
  assignments,
  initialPreselectedFeeId,
  onAssignFeeToClass,
  onAssignFeeToStudent,
  onOpenPaymentModal,
  onViewStudentProfile,
}: FeeAssignmentsViewProps) {
  const [activeTab, setActiveTab] = useState<'class-assign' | 'student-assign' | 'list'>('list');

  // Assignment to Class Form State
  const [selectedFeeId, setSelectedFeeId] = useState<string>(
    initialPreselectedFeeId || (feeStructures[0]?.id ?? '')
  );
  const [targetClass, setTargetClass] = useState<string>('All');
  const [targetSection, setTargetSection] = useState<string>('All');
  const [dueDateOverride, setDueDateOverride] = useState<string>('');
  const [classRemarks, setClassRemarks] = useState<string>('');
  const [isSubmittingClass, setIsSubmittingClass] = useState(false);
  const [classMessage, setClassMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Assignment to Individual Student Form State
  const [indFeeId, setIndFeeId] = useState<string>(
    initialPreselectedFeeId || (feeStructures[0]?.id ?? '')
  );
  const [indStudentRegNo, setIndStudentRegNo] = useState<string>(
    students[0]?.registrationNumber ?? ''
  );
  const [indStudentSearch, setIndStudentSearch] = useState<string>('');
  const [indCustomAmount, setIndCustomAmount] = useState<string>('');
  const [indWaiverAmount, setIndWaiverAmount] = useState<string>('0');
  const [indWaiverReason, setIndWaiverReason] = useState<string>('');
  const [indDueDate, setIndDueDate] = useState<string>('');
  const [indRemarks, setIndRemarks] = useState<string>('');
  const [isSubmittingInd, setIsSubmittingInd] = useState(false);
  const [indMessage, setIndMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Assignments List Filter State
  const [listSearch, setListSearch] = useState('');
  const [listClassFilter, setListClassFilter] = useState('all');
  const [listStatusFilter, setListStatusFilter] = useState('all');

  const uniqueClasses = Array.from(new Set(students.map((s) => s.admissionClass))).sort();

  // Selected fee item for class assign
  const activeFeeStructure = feeStructures.find((f) => f.id === selectedFeeId);
  const indActiveFeeStructure = feeStructures.find((f) => f.id === indFeeId);

  // Eligible students for class assignment preview
  const previewMatchingStudents = students.filter((s) => {
    const classMatch = targetClass === 'All' || s.admissionClass === targetClass;
    const sectionMatch = targetSection === 'All' || s.section === targetSection;
    return classMatch && sectionMatch;
  });

  const handleClassAssignmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFeeId) {
      setClassMessage({ type: 'error', text: 'Please select a fee structure.' });
      return;
    }

    setIsSubmittingClass(true);
    setClassMessage(null);
    try {
      const result = await onAssignFeeToClass({
        feeStructureId: selectedFeeId,
        className: targetClass,
        section: targetSection === 'All' ? undefined : targetSection,
        dueDate: dueDateOverride || undefined,
        remarks: classRemarks.trim() || undefined,
      });

      setClassMessage({
        type: 'success',
        text: `Successfully assigned to ${result.count} student(s). (${result.skippedCount} already had this fee assigned).`,
      });
      setActiveTab('list');
    } catch (err: any) {
      setClassMessage({ type: 'error', text: err.message || 'Failed to assign fee.' });
    } finally {
      setIsSubmittingClass(false);
    }
  };

  const handleStudentAssignmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!indFeeId || !indStudentRegNo) {
      setIndMessage({ type: 'error', text: 'Please select fee structure and student.' });
      return;
    }

    setIsSubmittingInd(true);
    setIndMessage(null);
    try {
      await onAssignFeeToStudent({
        feeStructureId: indFeeId,
        studentRegistrationNumber: indStudentRegNo,
        customAmount: indCustomAmount ? parseFloat(indCustomAmount) : undefined,
        discountOrWaiver: indWaiverAmount ? parseFloat(indWaiverAmount) : undefined,
        waiverReason: indWaiverReason.trim() || undefined,
        dueDate: indDueDate || undefined,
        remarks: indRemarks.trim() || undefined,
      });

      setIndMessage({
        type: 'success',
        text: `Successfully assigned fee head to student ${indStudentRegNo}.`,
      });
      setActiveTab('list');
    } catch (err: any) {
      setIndMessage({ type: 'error', text: err.message || 'Failed to assign fee.' });
    } finally {
      setIsSubmittingInd(false);
    }
  };

  // Filter assignments table
  const filteredAssignments = assignments.filter((a) => {
    const matchesSearch =
      a.studentName.toLowerCase().includes(listSearch.toLowerCase()) ||
      a.studentRegistrationNumber.toLowerCase().includes(listSearch.toLowerCase()) ||
      a.feeTypeName.toLowerCase().includes(listSearch.toLowerCase());

    const matchesClass = listClassFilter === 'all' || a.className === listClassFilter;
    const matchesStatus = listStatusFilter === 'all' || a.status === listStatusFilter;

    return matchesSearch && matchesClass && matchesStatus;
  });

  const handleExportCsv = () => {
    const headers = [
      'Assignment ID',
      'Student Reg No',
      'Student Name',
      'Class',
      'Section',
      'Fee Head',
      'Amount Due',
      'Waived',
      'Paid',
      'Balance',
      'Due Date',
      'Status',
    ];

    const rows = filteredAssignments.map((a) => [
      a.id,
      a.studentRegistrationNumber,
      a.studentName,
      a.className,
      a.section,
      a.feeTypeName,
      a.amountDue.toFixed(2),
      a.discountOrWaiver.toFixed(2),
      a.amountPaid.toFixed(2),
      a.balance.toFixed(2),
      a.dueDate,
      a.status,
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Fee_Assignments_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const filteredStudentList = students.filter(
    (s) =>
      s.fullName.toLowerCase().includes(indStudentSearch.toLowerCase()) ||
      s.registrationNumber.toLowerCase().includes(indStudentSearch.toLowerCase()) ||
      s.admissionClass.toLowerCase().includes(indStudentSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Fee Assignments & Ledger Roll</h2>
            <span className="bg-blue-50 text-[#1e3a8a] text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
              {assignments.length} Total Assignments
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Assign configured fee structures to entire cohorts, classes, or individual students.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant={activeTab === 'list' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('list')}
            className="text-xs"
          >
            Assigned List
          </Button>
          <Button
            variant={activeTab === 'class-assign' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('class-assign')}
            leftIcon={<Users className="w-3.5 h-3.5" />}
            className="text-xs"
          >
            Assign by Class
          </Button>
          <Button
            variant={activeTab === 'student-assign' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('student-assign')}
            leftIcon={<Layers className="w-3.5 h-3.5" />}
            className="text-xs"
          >
            Individual Assign
          </Button>
        </div>
      </div>

      {/* TAB 1: ASSIGN TO CLASS / SECTION */}
      {activeTab === 'class-assign' && (
        <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs max-w-3xl space-y-5">
          <div className="border-b border-[#e2e8f0] pb-3">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Users className="w-4 h-4 text-[#1e3a8a]" />
              Cohort / Class Fee Assignment Tool
            </h3>
            <p className="text-xs text-[#64748b] mt-0.5">
              Select a fee head and target class. The system will create individual ledger entries for every student in the cohort.
            </p>
          </div>

          {classMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2 ${
                classMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-red-50 text-red-800 border border-red-200'
              }`}
            >
              {classMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{classMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleClassAssignmentSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                Select Fee Structure Head <span className="text-red-500">*</span>
              </label>
              <select
                value={selectedFeeId}
                onChange={(e) => {
                  setSelectedFeeId(e.target.value);
                  const found = feeStructures.find((f) => f.id === e.target.value);
                  if (found) setDueDateOverride(found.dueDate);
                }}
                className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                required
              >
                <option value="" disabled>
                  -- Choose Fee Head --
                </option>
                {feeStructures.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} — ${f.amount.toFixed(2)} ({f.feeCategory} &bull; Due: {f.dueDate})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Target Class <span className="text-red-500">*</span>
                </label>
                <select
                  value={targetClass}
                  onChange={(e) => setTargetClass(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                  required
                >
                  <option value="All">All Approved Enrolled Classes ({students.length} students)</option>
                  {uniqueClasses.map((cls) => (
                    <option key={cls} value={cls}>
                      {cls} ({students.filter((s) => s.admissionClass === cls).length} students)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Target Section
                </label>
                <select
                  value={targetSection}
                  onChange={(e) => setTargetSection(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                >
                  <option value="All">All Sections (A, B, C...)</option>
                  <option value="A">Section A</option>
                  <option value="B">Section B</option>
                  <option value="C">Section C</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Override Due Date (Optional)
                </label>
                <input
                  type="date"
                  value={dueDateOverride || activeFeeStructure?.dueDate || ''}
                  onChange={(e) => setDueDateOverride(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Assignment Notes / Circular Ref (Optional)
                </label>
                <input
                  type="text"
                  value={classRemarks}
                  onChange={(e) => setClassRemarks(e.target.value)}
                  placeholder="e.g. Approved under Board circular 2026/04"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                />
              </div>
            </div>

            {/* Impact Preview Box */}
            <div className="p-4 bg-blue-50/40 border border-blue-100 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-[#1e293b] flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-[#1e3a8a]" />
                  Batch Assignment Preview
                </span>
                <span className="font-bold text-[#1e3a8a] bg-white px-2 py-0.5 rounded border border-blue-200">
                  {previewMatchingStudents.length} Students Selected
                </span>
              </div>
              <p className="text-[11px] text-[#64748b]">
                Targeting: <strong>{targetClass}</strong> {targetSection !== 'All' && `(Section ${targetSection})`} &bull; Unit Fee: <strong>${activeFeeStructure?.amount.toFixed(2) || '0.00'}</strong> &bull; Total Projected Revenue:{' '}
                <strong>
                  ${((activeFeeStructure?.amount || 0) * previewMatchingStudents.length).toFixed(2)}
                </strong>
              </p>
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <Button
                variant="outline"
                size="sm"
                type="button"
                onClick={() => setActiveTab('list')}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                type="submit"
                isLoading={isSubmittingClass}
                leftIcon={<ArrowRight className="w-4 h-4" />}
              >
                Execute Batch Class Assignment
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: ASSIGN TO INDIVIDUAL STUDENT */}
      {activeTab === 'student-assign' && (
        <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs max-w-3xl space-y-5">
          <div className="border-b border-[#e2e8f0] pb-3">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#1e3a8a]" />
              Individual Student Custom Fee Assignment
            </h3>
            <p className="text-xs text-[#64748b] mt-0.5">
              Assign a specialized fee head, custom concession/scholarship, or custom installment to a single student.
            </p>
          </div>

          {indMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2 ${
                indMessage.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-red-50 text-red-800 border border-red-200'
              }`}
            >
              {indMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{indMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleStudentAssignmentSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                Select Student <span className="text-red-500">*</span>
              </label>
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Filter student list..."
                  value={indStudentSearch}
                  onChange={(e) => setIndStudentSearch(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] outline-hidden bg-[#f8fafc]"
                />
                <select
                  value={indStudentRegNo}
                  onChange={(e) => setIndStudentRegNo(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                  required
                >
                  <option value="" disabled>
                    -- Choose student --
                  </option>
                  {filteredStudentList.map((s) => (
                    <option key={s.registrationNumber} value={s.registrationNumber}>
                      {s.registrationNumber} — {s.fullName} ({s.admissionClass} - {s.section})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                Fee Structure Item <span className="text-red-500">*</span>
              </label>
              <select
                value={indFeeId}
                onChange={(e) => {
                  setIndFeeId(e.target.value);
                  const f = feeStructures.find((item) => item.id === e.target.value);
                  if (f) {
                    setIndCustomAmount(String(f.amount));
                    setIndDueDate(f.dueDate);
                  }
                }}
                className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] bg-white outline-hidden"
                required
              >
                <option value="" disabled>
                  -- Select Fee Item --
                </option>
                {feeStructures.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} — Standard: ${f.amount.toFixed(2)} ({f.feeCategory})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Custom Amount ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={indCustomAmount || indActiveFeeStructure?.amount || ''}
                  onChange={(e) => setIndCustomAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] font-mono font-bold outline-hidden"
                  placeholder="Leave empty for default"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Initial Waiver ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={indWaiverAmount}
                  onChange={(e) => setIndWaiverAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] font-mono outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Due Date
                </label>
                <input
                  type="date"
                  value={indDueDate || indActiveFeeStructure?.dueDate || ''}
                  onChange={(e) => setIndDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] outline-hidden bg-white"
                />
              </div>
            </div>

            {parseFloat(indWaiverAmount) > 0 && (
              <div>
                <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                  Waiver / Scholarship Reason <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={indWaiverReason}
                  onChange={(e) => setIndWaiverReason(e.target.value)}
                  placeholder="e.g. Sibling discount / Sports quota scholarship"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
                  required
                />
              </div>
            )}

            <div>
              <label className="block font-bold text-[#1e293b] mb-1.5 uppercase tracking-wider text-[11px]">
                Remarks / Notes (Optional)
              </label>
              <input
                type="text"
                value={indRemarks}
                onChange={(e) => setIndRemarks(e.target.value)}
                placeholder="e.g. Approved special installment plan"
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
              />
            </div>

            <div className="pt-2 flex justify-end gap-3">
              <Button
                variant="outline"
                size="sm"
                type="button"
                onClick={() => setActiveTab('list')}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                type="submit"
                isLoading={isSubmittingInd}
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
              >
                Save Student Fee Assignment
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: LIST OF ALL ASSIGNMENTS */}
      {activeTab === 'list' && (
        <div className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
            <div className="flex-1 min-w-[220px] relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
              <input
                type="text"
                placeholder="Search by student name, Reg No, or fee head..."
                value={listSearch}
                onChange={(e) => setListSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-[#64748b]" />
              <select
                value={listClassFilter}
                onChange={(e) => setListClassFilter(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
              >
                <option value="all">All Classes</option>
                {uniqueClasses.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              <select
                value={listStatusFilter}
                onChange={(e) => setListStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
              >
                <option value="all">All Statuses</option>
                <option value="Unpaid">Unpaid</option>
                <option value="Partially Paid">Partially Paid</option>
                <option value="Paid">Paid</option>
                <option value="Waived">Waived</option>
              </select>

              <Button
                variant="outline"
                size="sm"
                onClick={handleExportCsv}
                leftIcon={<Download className="w-3.5 h-3.5" />}
                className="text-xs"
              >
                Export CSV
              </Button>
            </div>
          </div>

          {/* Assignments Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Student (Reg No)</th>
                    <th className="py-3 px-4">Class</th>
                    <th className="py-3 px-4">Fee Particular</th>
                    <th className="py-3 px-4 text-right">Amount Due</th>
                    <th className="py-3 px-4 text-right">Paid</th>
                    <th className="py-3 px-4 text-right">Balance</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {filteredAssignments.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-10 text-center text-[#94a3b8]">
                        No fee assignments found matching filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredAssignments.map((a) => (
                      <tr key={a.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                            className="text-left font-bold text-[#1e293b] hover:text-[#1e3a8a] transition-colors cursor-pointer"
                          >
                            <div>{a.studentName}</div>
                            <span className="font-mono text-[11px] text-[#1e3a8a] bg-blue-50 px-1 py-0.2 rounded">
                              {a.studentRegistrationNumber}
                            </span>
                          </button>
                        </td>

                        <td className="py-3 px-4 font-medium text-[#475569]">
                          {a.className} - {a.section}
                        </td>

                        <td className="py-3 px-4 font-semibold text-[#1e293b]">
                          {a.feeTypeName}
                        </td>

                        <td className="py-3 px-4 text-right font-mono text-[#475569]">
                          ${a.amountDue.toFixed(2)}
                        </td>

                        <td className="py-3 px-4 text-right font-mono font-semibold text-emerald-700">
                          ${a.amountPaid.toFixed(2)}
                        </td>

                        <td className="py-3 px-4 text-right font-mono font-bold">
                          <span
                            className={a.balance > 0 ? 'text-red-700' : 'text-emerald-700'}
                          >
                            ${a.balance.toFixed(2)}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-[#64748b] text-[11px]">
                          {a.dueDate}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {a.status === 'Paid' && <Badge variant="emerald" size="sm">Paid</Badge>}
                          {a.status === 'Partially Paid' && <Badge variant="amber" size="sm">Partially Paid</Badge>}
                          {a.status === 'Unpaid' && <Badge variant="rose" size="sm">Unpaid</Badge>}
                          {a.status === 'Waived' && <Badge variant="purple" size="sm">Waived</Badge>}
                        </td>

                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {a.balance > 0 && (
                              <Button
                                variant="primary"
                                size="sm"
                                onClick={() => onOpenPaymentModal(a.studentRegistrationNumber, a.id)}
                                leftIcon={<DollarSign className="w-3 h-3" />}
                                className="text-[11px] py-1 px-2"
                              >
                                Pay
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                              className="text-[11px] py-1 px-2"
                            >
                              Ledger
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
