import React from 'react';
import {
  DollarSign,
  TrendingUp,
  Receipt,
  AlertCircle,
  CreditCard,
  Plus,
  Users,
  Layers,
  ArrowRight,
  CheckCircle2,
  Clock,
  Calendar,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { FinanceDashboardMetrics, PaymentRecord, FeeReceipt, FeeAssignment } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface FinanceOverviewProps {
  metrics: FinanceDashboardMetrics;
  recentPayments: PaymentRecord[];
  receipts: FeeReceipt[];
  onOpenPaymentEntry: () => void;
  onOpenFeeStructureModal: () => void;
  onNavigateTab: (tab: 'structure' | 'assignments' | 'student-fees' | 'payments' | 'receipts' | 'outstanding' | 'reports') => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function FinanceOverview({
  metrics,
  recentPayments,
  receipts,
  onOpenPaymentEntry,
  onOpenFeeStructureModal,
  onNavigateTab,
  onOpenReceiptModal,
  onViewStudentProfile,
}: FinanceOverviewProps) {
  const collectionRate =
    metrics.totalFeesAssigned > 0
      ? (metrics.totalAmountCollected / metrics.totalFeesAssigned) * 100
      : 0;

  return (
    <div className="space-y-6">
      {/* Welcome Banner with Quick Actions */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h2 className="text-xl font-bold text-[#1e293b]">Finance Office Operations Center</h2>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Real-time student fee ledgers, revenue tracking, payment vouchers, and dues reconciliation.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenFeeStructureModal}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs"
          >
            New Fee Head
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('assignments')}
            leftIcon={<Users className="w-4 h-4" />}
            className="text-xs"
          >
            Assign Fees
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={onOpenPaymentEntry}
            leftIcon={<CreditCard className="w-4 h-4" />}
            className="text-xs bg-emerald-700 hover:bg-emerald-800"
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* 4 Primary Key Performance Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Fees Assigned */}
        <div className="p-5 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#64748b]">
              Total Billed Fees
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black font-mono text-[#1e293b]">
            ${metrics.totalFeesAssigned.toFixed(2)}
          </div>
          <div className="text-[11px] text-[#64748b] flex items-center justify-between pt-1 border-t border-[#f1f5f9]">
            <span>Active Academic Session</span>
            <span className="font-semibold text-[#1e3a8a]">2026–2027</span>
          </div>
        </div>

        {/* Card 2: Total Collected */}
        <div className="p-5 bg-white border border-emerald-100 rounded-2xl shadow-xs space-y-2 bg-gradient-to-b from-emerald-50/20 to-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
              Total Collections
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black font-mono text-emerald-700">
            ${metrics.totalAmountCollected.toFixed(2)}
          </div>
          <div className="text-[11px] text-emerald-700 flex items-center justify-between pt-1 border-t border-emerald-100">
            <span>Recovery Rate</span>
            <span className="font-bold">{collectionRate.toFixed(1)}% Realized</span>
          </div>
        </div>

        {/* Card 3: Today's Collection */}
        <div className="p-5 bg-white border border-blue-100 rounded-2xl shadow-xs space-y-2 bg-gradient-to-b from-blue-50/20 to-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#1e3a8a]">
              Today's Inflow
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#1e3a8a] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black font-mono text-[#1e3a8a]">
            ${metrics.todayCollection.toFixed(2)}
          </div>
          <div className="text-[11px] text-[#64748b] flex items-center justify-between pt-1 border-t border-blue-100">
            <span>Recent Inflows</span>
            <button
              type="button"
              onClick={() => onNavigateTab('payments')}
              className="text-[#1e3a8a] font-semibold hover:underline cursor-pointer"
            >
              View Daily Scroll
            </button>
          </div>
        </div>

        {/* Card 4: Total Outstanding Dues */}
        <div className="p-5 bg-white border border-red-100 rounded-2xl shadow-xs space-y-2 bg-gradient-to-b from-red-50/20 to-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-red-800">
              Outstanding Dues
            </span>
            <div className="w-8 h-8 rounded-lg bg-red-100 text-red-700 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black font-mono text-red-700">
            ${metrics.totalOutstanding.toFixed(2)}
          </div>
          <div className="text-[11px] text-red-700 flex items-center justify-between pt-1 border-t border-red-100">
            <span>{metrics.studentsWithOutstandingCount} Accounts Due</span>
            <button
              type="button"
              onClick={() => onNavigateTab('outstanding')}
              className="font-bold hover:underline cursor-pointer"
            >
              View Defaulters
            </button>
          </div>
        </div>
      </div>

      {/* Two Columns: Recent Transactions & Channel Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Recent Transactions */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#1e3a8a]" />
              <h3 className="text-sm font-bold text-[#1e293b]">Recent Fee Payments & Receipts</h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('payments')}
              className="text-xs text-[#1e3a8a] font-bold flex items-center gap-1 hover:underline cursor-pointer"
            >
              <span>View All Transactions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3">Receipt & ID</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Fee Particular</th>
                  <th className="py-2.5 px-3">Mode</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3 text-right">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {recentPayments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-[#94a3b8]">
                      No payments recorded yet. Click "Record Payment" to get started.
                    </td>
                  </tr>
                ) : (
                  recentPayments.slice(0, 6).map((p) => {
                    const r = receipts.find((rec) => rec.paymentId === p.id);
                    return (
                      <tr key={p.id} className="hover:bg-[#f8fafc]">
                        <td className="py-3 px-3">
                          <span className="font-mono font-bold text-[#1e3a8a] block">
                            {p.receiptNumber}
                          </span>
                          <span className="font-mono text-[10px] text-[#64748b]">{p.id}</span>
                        </td>
                        <td className="py-3 px-3">
                          <button
                            type="button"
                            onClick={() => onViewStudentProfile(p.studentRegistrationNumber)}
                            className="font-bold text-[#1e293b] hover:text-[#1e3a8a] text-left cursor-pointer"
                          >
                            {p.studentName}
                          </button>
                          <span className="text-[10px] text-[#64748b] block font-mono">
                            {p.studentRegistrationNumber} ({p.className})
                          </span>
                        </td>
                        <td className="py-3 px-3 font-medium text-[#1e293b]">{p.feeTypeName}</td>
                        <td className="py-3 px-3">
                          <span className="font-medium text-[#475569]">{p.paymentMode}</span>
                        </td>
                        <td className="py-3 px-3 text-right font-mono font-bold text-emerald-700">
                          ${p.amountPaid.toFixed(2)}
                        </td>
                        <td className="py-3 px-3 text-right">
                          {r && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onOpenReceiptModal(r)}
                              className="text-[10px] py-0.5 px-2 text-[#1e3a8a]"
                            >
                              Receipt
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Payment Channel Distribution & Shortcuts */}
        <div className="space-y-6">
          {/* Payment Mode Analytics Card */}
          <div className="bg-white rounded-2xl border border-[#e2e8f0] p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#1e3a8a]" />
              Collections by Payment Mode
            </h3>

            <div className="space-y-3 text-xs">
              {metrics.paymentModeBreakdown.map((modeData) => (
                <div key={modeData.mode} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#1e293b]">{modeData.mode}</span>
                    <span className="font-mono font-bold text-[#1e293b]">
                      ${modeData.amount.toFixed(2)}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-[#1e3a8a] h-full rounded-full"
                      style={{ width: `${modeData.percentage}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-[#64748b] flex justify-between">
                    <span>{modeData.count} transactions</span>
                    <span>{modeData.percentage.toFixed(1)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Operations Guide */}
          <div className="bg-blue-50/50 rounded-2xl border border-blue-100 p-5 shadow-xs space-y-3 text-xs">
            <h4 className="font-bold text-[#1e3a8a] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              Standard Audit Protocols
            </h4>
            <ul className="space-y-1.5 text-[#475569] text-[11px] list-disc list-inside">
              <li>Receipts are sequentially numbered and non-reusable.</li>
              <li>Cancelled transactions preserve an audit void stamp.</li>
              <li>Bank Transfer & Cheque payments require reference IDs.</li>
              <li>Student ledgers auto-reconcile on each approved payment.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
