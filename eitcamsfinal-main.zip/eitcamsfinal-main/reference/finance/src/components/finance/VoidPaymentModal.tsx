import React, { useState } from 'react';
import { AlertTriangle, X, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { PaymentRecord } from '../../types/finance';
import { Button } from '../ui/Button';

interface VoidPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentRecord | null;
  currentUserName: string;
  onConfirmVoid: (paymentId: string, reason: string, voidedBy: string) => Promise<any>;
}

export function VoidPaymentModal({
  isOpen,
  onClose,
  payment,
  currentUserName,
  onConfirmVoid,
}: VoidPaymentModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !payment) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Please provide an explicit reason for cancelling this payment.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmVoid(payment.id, reason.trim(), currentUserName);
      setReason('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to void payment transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-red-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 bg-red-50 border-b border-red-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-red-950">Void / Cancel Payment</h3>
              <p className="text-xs text-red-700">Audit-safe reversal of recorded transaction.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-red-400 hover:text-red-700 hover:bg-red-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-100 border border-red-300 rounded-xl text-xs text-red-800">
              {error}
            </div>
          )}

          <div className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-[#64748b]">Transaction ID:</span>
              <span className="font-mono font-bold text-[#1e293b]">{payment.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Receipt Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{payment.receiptNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Student:</span>
              <span className="font-bold text-[#1e293b]">
                {payment.studentName} ({payment.studentRegistrationNumber})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Fee Item:</span>
              <span className="font-medium text-[#1e293b]">{payment.feeTypeName}</span>
            </div>
            <div className="flex justify-between border-t border-[#e2e8f0] pt-1 mt-1">
              <span className="text-[#64748b] font-bold">Amount to Revert:</span>
              <span className="font-mono font-black text-red-700 text-sm">
                ${payment.amountPaid.toFixed(2)} ({payment.paymentMode})
              </span>
            </div>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong>Audit Safety Note:</strong> Financial records are never deleted silently. This transaction and its receipt will be permanently stamped as <em>CANCELLED / VOIDED</em>, and the student's ledger balance will be automatically restored.
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1.5">
              Cancellation / Reversal Reason <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Cheque returned unpaid by bank / Duplicate entry error by cashier"
              className="w-full px-3 py-2 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-red-500 outline-hidden"
              required
            />
          </div>

          <div className="text-[11px] text-[#64748b]">
            Action will be recorded under: <strong className="text-[#1e293b]">{currentUserName}</strong>
          </div>

          <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Keep Transaction
            </Button>
            <Button
              variant="danger"
              size="sm"
              type="submit"
              isLoading={isSubmitting}
              leftIcon={<ShieldAlert className="w-4 h-4" />}
            >
              Confirm Void & Revert Ledger
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
