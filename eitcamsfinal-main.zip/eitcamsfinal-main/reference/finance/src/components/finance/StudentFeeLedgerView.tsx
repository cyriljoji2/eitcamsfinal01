import React, { useState } from 'react';
import {
  Search,
  Filter,
  DollarSign,
  CreditCard,
  Download,
  Eye,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  Layers,
} from 'lucide-react';
import { StudentFeeSummary } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentFeeLedgerViewProps {
  summaries: StudentFeeSummary[];
  onOpenPaymentModal: (studentRegNo: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function StudentFeeLedgerView({
  summaries,
  onOpenPaymentModal,
  onViewStudentProfile,
}: StudentFeeLedgerViewProps) {
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'outstanding' | 'cleared'>('all');

  const uniqueClasses = Array.from(new Set(summaries.map((s) => s.className))).sort();

  const filteredSummaries = summaries.filter((s) => {
    const matchesSearch =
      s.studentName.toLowerCase().includes(search.toLowerCase()) ||
      s.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      s.className.toLowerCase().includes(search.toLowerCase());

    const matchesClass = classFilter === 'all' || s.className === classFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'outstanding'
        ? s.totalOutstanding > 0
        : s.totalOutstanding === 0;

    return matchesSearch && matchesClass && matchesStatus;
  });

  const totalBilled = summaries.reduce((acc, s) => acc + s.totalDue, 0);
  const totalCollected = summaries.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalOutstanding = summaries.reduce((acc, s) => acc + s.totalOutstanding, 0);
  const totalWaived = summaries.reduce((acc, s) => acc + s.totalWaived, 0);

  const handleExportCsv = () => {
    const headers = [
      'Registration Number',
      'Student Name',
      'Class',
      'Section',
      'Session',
      'Total Fees Assigned ($)',
      'Total Paid ($)',
      'Total Waived ($)',
      'Net Outstanding ($)',
      'Status',
    ];

    const rows = filteredSummaries.map((s) => [
      s.studentRegistrationNumber,
      s.studentName,
      s.className,
      s.section,
      s.academicSession,
      s.totalDue.toFixed(2),
      s.totalPaid.toFixed(2),
      s.totalWaived.toFixed(2),
      s.totalOutstanding.toFixed(2),
      s.totalOutstanding === 0 ? 'CLEARED' : 'OUTSTANDING DUES',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Student_Fee_Ledger_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Student Fee Ledger Directory</h2>
            <span className="bg-blue-50 text-[#1e3a8a] text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
              {summaries.length} Student Accounts
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Individual student balances, dues clearance status, and ledger drilldowns.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleExportCsv}
          leftIcon={<Download className="w-3.5 h-3.5" />}
          className="text-xs"
        >
          Export Ledger CSV
        </Button>
      </div>

      {/* Aggregate Metric Mini-Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-[#64748b] uppercase tracking-wider block">
            Total Billed Fees
          </span>
          <span className="text-xl font-black font-mono text-[#1e293b]">
            ${totalBilled.toFixed(2)}
          </span>
        </div>

        <div className="p-4 bg-emerald-50/60 border border-emerald-100 rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
            Total Collected
          </span>
          <span className="text-xl font-black font-mono text-emerald-700">
            ${totalCollected.toFixed(2)}
          </span>
        </div>

        <div className="p-4 bg-purple-50/60 border border-purple-100 rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-purple-800 uppercase tracking-wider block">
            Waivers / Concessions
          </span>
          <span className="text-xl font-black font-mono text-purple-700">
            ${totalWaived.toFixed(2)}
          </span>
        </div>

        <div className="p-4 bg-red-50/60 border border-red-100 rounded-xl shadow-xs">
          <span className="text-[10px] font-bold text-red-800 uppercase tracking-wider block">
            Total Outstanding
          </span>
          <span className="text-xl font-black font-mono text-red-700">
            ${totalOutstanding.toFixed(2)}
          </span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by student name or Registration Number (e.g. REG-2026-0001)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-[#64748b]" />
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Classes</option>
            {uniqueClasses.map((cls) => (
              <option key={cls} value={cls}>
                {cls}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Accounts</option>
            <option value="outstanding">With Outstanding Dues</option>
            <option value="cleared">Zero Dues / Cleared</option>
          </select>
        </div>
      </div>

      {/* Student Ledger Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Registration #</th>
                <th className="py-3 px-4">Student Full Name</th>
                <th className="py-3 px-4">Class & Sec</th>
                <th className="py-3 px-4 text-right">Total Assigned</th>
                <th className="py-3 px-4 text-right">Total Paid</th>
                <th className="py-3 px-4 text-right">Waived</th>
                <th className="py-3 px-4 text-right">Net Outstanding</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredSummaries.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-[#94a3b8]">
                    No students match the search filter.
                  </td>
                </tr>
              ) : (
                filteredSummaries.map((s) => (
                  <tr key={s.studentRegistrationNumber} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">
                      {s.studentRegistrationNumber}
                    </td>

                    <td className="py-3.5 px-4 font-bold text-[#1e293b]">
                      <button
                        type="button"
                        onClick={() => onViewStudentProfile(s.studentRegistrationNumber)}
                        className="hover:text-[#1e3a8a] text-left cursor-pointer"
                      >
                        {s.studentName}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 font-medium text-[#475569]">
                      {s.className} &bull; {s.section}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-medium text-[#1e293b]">
                      ${s.totalDue.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-emerald-700">
                      ${s.totalPaid.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono text-purple-700">
                      ${s.totalWaived.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-right font-mono font-bold">
                      <span
                        className={s.totalOutstanding > 0 ? 'text-red-700' : 'text-emerald-700'}
                      >
                        ${s.totalOutstanding.toFixed(2)}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      {s.totalOutstanding === 0 ? (
                        <Badge variant="emerald" size="sm">
                          Cleared
                        </Badge>
                      ) : (
                        <Badge variant="rose" size="sm">
                          Dues Pending
                        </Badge>
                      )}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {s.totalOutstanding > 0 && (
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => onOpenPaymentModal(s.studentRegistrationNumber)}
                            leftIcon={<DollarSign className="w-3 h-3" />}
                            className="text-[11px] py-1 px-2"
                          >
                            Pay Dues
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onViewStudentProfile(s.studentRegistrationNumber)}
                          leftIcon={<Eye className="w-3 h-3" />}
                          className="text-[11px] py-1 px-2 text-[#1e3a8a]"
                        >
                          View Ledger
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
