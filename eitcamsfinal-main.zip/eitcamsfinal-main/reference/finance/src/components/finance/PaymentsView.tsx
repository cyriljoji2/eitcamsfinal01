import React, { useState } from 'react';
import {
  CreditCard,
  Search,
  Filter,
  Plus,
  Receipt,
  Download,
  Calendar,
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  Hash,
} from 'lucide-react';
import { PaymentRecord, FeeReceipt, PaymentMode } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface PaymentsViewProps {
  payments: PaymentRecord[];
  receipts: FeeReceipt[];
  onOpenPaymentEntry: () => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onOpenVoidModal: (payment: PaymentRecord) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function PaymentsView({
  payments,
  receipts,
  onOpenPaymentEntry,
  onOpenReceiptModal,
  onOpenVoidModal,
  onViewStudentProfile,
}: PaymentsViewProps) {
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'voided'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredPayments = payments.filter((p) => {
    const matchesSearch =
      p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.receiptNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.studentName.toLowerCase().includes(search.toLowerCase()) ||
      p.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.feeTypeName.toLowerCase().includes(search.toLowerCase()) ||
      (p.transactionReference && p.transactionReference.toLowerCase().includes(search.toLowerCase()));

    const matchesMode = modeFilter === 'all' || p.paymentMode === modeFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'valid'
        ? !p.isVoided
        : p.isVoided;

    const matchesStart = !startDate || p.paymentDate >= startDate;
    const matchesEnd = !endDate || p.paymentDate <= endDate;

    return matchesSearch && matchesMode && matchesStatus && matchesStart && matchesEnd;
  });

  const validPayments = filteredPayments.filter((p) => !p.isVoided);
  const totalCollectedFiltered = validPayments.reduce((acc, p) => acc + p.amountPaid, 0);

  const handleExportCsv = () => {
    const headers = [
      'Payment ID',
      'Receipt Number',
      'Date',
      'Student Reg No',
      'Student Name',
      'Class',
      'Section',
      'Fee Type',
      'Amount Paid ($)',
      'Payment Mode',
      'Transaction Ref',
      'Received By',
      'Status',
      'Void Reason',
    ];

    const rows = filteredPayments.map((p) => [
      p.id,
      p.receiptNumber,
      p.paymentDate,
      p.studentRegistrationNumber,
      p.studentName,
      p.className,
      p.section,
      p.feeTypeName,
      p.amountPaid.toFixed(2),
      p.paymentMode,
      p.transactionReference || 'N/A',
      p.receivedBy,
      p.isVoided ? 'VOIDED' : 'VALID',
      p.voidReason || '',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Payments_Audit_Log_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Fee Payment Ledger & Transactions</h2>
            <span className="bg-emerald-50 text-emerald-800 text-xs font-bold px-2 py-0.5 rounded-full border border-emerald-200">
              ${totalCollectedFiltered.toFixed(2)} Total Filtered
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Audit-grade collection records, transaction receipts, and reversible payment operations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="text-xs"
          >
            Export CSV
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenPaymentEntry}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs bg-emerald-700 hover:bg-emerald-800"
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by Payment ID, Receipt #, Reg No, or student name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={modeFilter}
            onChange={(e) => setModeFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Payment Modes</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cheque">Cheque</option>
            <option value="Other">Other</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Transactions</option>
            <option value="valid">Valid / Settled Only</option>
            <option value="voided">Voided / Cancelled Only</option>
          </select>

          <div className="flex items-center gap-1 text-xs text-[#64748b]">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2 py-1 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
              title="Filter from date"
            />
            <span>to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2 py-1 text-xs rounded-lg border border-[#cbd5e1] outline-hidden"
              title="Filter to date"
            />
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Payment & Receipt ID</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Student (Reg No)</th>
                <th className="py-3 px-4">Fee Head</th>
                <th className="py-3 px-4">Mode & Ref</th>
                <th className="py-3 px-4 text-right">Amount Paid</th>
                <th className="py-3 px-4">Cashier</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-[#94a3b8]">
                    No payment transactions found matching search and filter criteria.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((p) => {
                  const receipt = receipts.find((r) => r.paymentId === p.id);
                  return (
                    <tr
                      key={p.id}
                      className={`hover:bg-[#f8fafc] transition-colors ${
                        p.isVoided ? 'bg-red-50/20 opacity-75' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex flex-col">
                          <span className="font-mono font-bold text-[#1e293b] text-xs">{p.id}</span>
                          <span className="font-mono text-[11px] text-[#1e3a8a] font-semibold">
                            {p.receiptNumber}
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-[#475569] font-medium whitespace-nowrap">
                        {p.paymentDate}
                      </td>

                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(p.studentRegistrationNumber)}
                          className="hover:text-[#1e3a8a] text-left cursor-pointer"
                        >
                          <div className="font-bold text-[#1e293b]">{p.studentName}</div>
                          <div className="font-mono text-[11px] text-[#64748b]">
                            {p.studentRegistrationNumber} ({p.className} - {p.section})
                          </div>
                        </button>
                      </td>

                      <td className="py-3.5 px-4 font-semibold text-[#1e293b]">{p.feeTypeName}</td>

                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-[#475569] flex items-center gap-1">
                          <CreditCard className="w-3.5 h-3.5 text-[#1e3a8a]" />
                          {p.paymentMode}
                        </div>
                        {p.transactionReference && (
                          <div className="font-mono text-[10px] text-[#64748b] truncate max-w-[120px]">
                            {p.transactionReference}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-sm">
                        <span className={p.isVoided ? 'line-through text-red-600' : 'text-emerald-700'}>
                          ${p.amountPaid.toFixed(2)}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-[#64748b] text-[11px]">{p.receivedBy}</td>

                      <td className="py-3.5 px-4 text-center">
                        {p.isVoided ? (
                          <Badge variant="rose" size="sm">
                            Voided
                          </Badge>
                        ) : (
                          <Badge variant="emerald" size="sm">
                            Valid
                          </Badge>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {receipt && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => onOpenReceiptModal(receipt)}
                              leftIcon={<Receipt className="w-3.5 h-3.5" />}
                              className="text-[11px] py-1 px-2 text-[#1e3a8a]"
                            >
                              Receipt
                            </Button>
                          )}

                          {!p.isVoided && (
                            <button
                              type="button"
                              onClick={() => onOpenVoidModal(p)}
                              className="p-1 text-[#94a3b8] hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                              title="Void Transaction"
                            >
                              <ShieldAlert className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
