import React, { useRef } from 'react';
import {
  Receipt,
  Printer,
  Download,
  X,
  CheckCircle2,
  AlertCircle,
  Building2,
  Calendar,
  CreditCard,
  Hash,
  User,
  ShieldCheck,
} from 'lucide-react';
import { FeeReceipt } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ReceiptPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: FeeReceipt | null;
}

export function ReceiptPreviewModal({ isOpen, onClose, receipt }: ReceiptPreviewModalProps) {
  const printContainerRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCsv = () => {
    const csvContent = [
      ['FIELD', 'VALUE'],
      ['Receipt Number', receipt.receiptNumber],
      ['Payment Reference ID', receipt.paymentId],
      ['Receipt Date', receipt.receiptDate],
      ['Student Registration Number', receipt.studentRegistrationNumber],
      ['Student Full Name', receipt.studentName],
      ['Class & Section', `${receipt.className} - Section ${receipt.section}`],
      ['Academic Session', receipt.academicSession],
      ['Fee Type Description', receipt.feeTypeName],
      ['Amount Paid (USD)', receipt.amountPaid.toFixed(2)],
      ['Amount in Words', receipt.amountInWords],
      ['Payment Mode', receipt.paymentMode],
      ['Transaction Reference', receipt.transactionReference || 'N/A'],
      ['Outstanding Balance After Payment', receipt.outstandingBalanceAfterPayment.toFixed(2)],
      ['Cashier / Received By', receipt.receivedBy],
      ['Receipt Status', receipt.isVoided ? `CANCELLED / VOIDED (${receipt.voidReason})` : 'OFFICIAL VALID'],
      ['Institution Name', receipt.schoolDetails.name],
      ['Institution Address', receipt.schoolDetails.address],
    ]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Receipt_${receipt.receiptNumber}_${receipt.studentRegistrationNumber}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Modal Controls Bar */}
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                <span>Fee Receipt Preview</span>
                <span className="font-mono text-xs bg-blue-100 text-[#1e3a8a] px-2 py-0.5 rounded font-bold">
                  {receipt.receiptNumber}
                </span>
                {receipt.isVoided && (
                  <Badge variant="rose" size="sm">
                    VOIDED / CANCELLED
                  </Badge>
                )}
              </h3>
              <p className="text-[11px] text-[#64748b]">
                Official institutional fee receipt with audit metadata.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadCsv}
              leftIcon={<Download className="w-3.5 h-3.5" />}
              className="text-xs"
            >
              Export CSV
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handlePrint}
              leftIcon={<Printer className="w-3.5 h-3.5" />}
              className="text-xs"
            >
              Print Receipt
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#94a3b8] hover:text-[#1e293b] hover:bg-[#f1f5f9] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Receipt Area */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto print:max-h-none print:p-0" ref={printContainerRef}>
          <div
            className={`border rounded-xl p-6 sm:p-8 relative bg-white ${
              receipt.isVoided ? 'border-red-300 bg-red-50/10' : 'border-[#cbd5e1] shadow-xs'
            }`}
          >
            {/* Void Watermark if cancelled */}
            {receipt.isVoided && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-15">
                <span className="text-red-700 font-black text-6xl tracking-widest uppercase rotate-[-25deg] border-4 border-red-700 p-4 rounded-xl">
                  CANCELLED / VOID
                </span>
              </div>
            )}

            {/* School Header */}
            <div className="text-center pb-5 border-b-2 border-[#1e3a8a]/20 space-y-1">
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-10 h-10 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-lg shadow-xs">
                  <Building2 className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h1 className="text-lg font-black text-[#1e293b] tracking-tight uppercase">
                    {receipt.schoolDetails.name}
                  </h1>
                  <p className="text-[11px] text-[#64748b]">
                    {receipt.schoolDetails.address} &bull; Tel: {receipt.schoolDetails.phone}
                  </p>
                </div>
              </div>
              <div className="flex items-center justify-center gap-4 text-[10px] text-[#64748b]">
                <span>Email: {receipt.schoolDetails.email}</span>
                {receipt.schoolDetails.affiliationNo && (
                  <span>Affiliation No: {receipt.schoolDetails.affiliationNo}</span>
                )}
              </div>
              <div className="pt-2">
                <span className="inline-block bg-[#1e3a8a] text-white text-xs font-bold uppercase tracking-widest px-4 py-1 rounded-full shadow-xs">
                  Official Student Fee Receipt
                </span>
              </div>
            </div>

            {/* Receipt Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 py-4 text-xs border-b border-[#e2e8f0]">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Receipt Number
                </span>
                <span className="font-mono font-bold text-[#1e3a8a] text-sm">
                  {receipt.receiptNumber}
                </span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Payment Reference
                </span>
                <span className="font-mono font-medium text-[#1e293b]">
                  {receipt.paymentId}
                </span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Receipt Date
                </span>
                <span className="font-semibold text-[#1e293b]">{receipt.receiptDate}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Academic Session
                </span>
                <span className="font-medium text-[#1e293b]">{receipt.academicSession}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Payment Mode
                </span>
                <span className="font-semibold text-[#1e293b] flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5 text-[#1e3a8a]" />
                  {receipt.paymentMode}
                </span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Transaction / Ref #
                </span>
                <span className="font-mono text-[#1e293b] font-medium">
                  {receipt.transactionReference || 'Cash Counter Transaction'}
                </span>
              </div>
            </div>

            {/* Student Details Box */}
            <div className="my-4 p-3.5 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[#64748b] font-medium">Student Registration Number:</span>
                <span className="font-mono font-bold text-[#1e3a8a] bg-white px-2.5 py-0.5 rounded border border-[#cbd5e1]">
                  {receipt.studentRegistrationNumber}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#64748b] font-medium">Student Full Name:</span>
                <span className="font-bold text-[#1e293b] text-sm">{receipt.studentName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#64748b] font-medium">Class & Section:</span>
                <span className="font-semibold text-[#1e293b]">
                  {receipt.className} &bull; Section {receipt.section}
                </span>
              </div>
            </div>

            {/* Fee Itemization Table */}
            <div className="border border-[#e2e8f0] rounded-xl overflow-hidden mb-4 text-xs">
              <table className="w-full text-left">
                <thead className="bg-[#f1f5f9] text-[#475569] font-bold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="py-2.5 px-3">#</th>
                    <th className="py-2.5 px-3">Fee Particulars / Description</th>
                    <th className="py-2.5 px-3 text-right">Amount Received</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  <tr>
                    <td className="py-3 px-3 font-mono text-[#64748b]">1</td>
                    <td className="py-3 px-3 font-semibold text-[#1e293b]">
                      {receipt.feeTypeName}
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-[#1e293b] font-mono text-sm">
                      ${receipt.amountPaid.toFixed(2)}
                    </td>
                  </tr>
                </tbody>
                <tfoot className="bg-[#f8fafc] border-t-2 border-[#1e293b]/10 font-bold text-xs">
                  <tr>
                    <td colSpan={2} className="py-2.5 px-3 text-right text-[#475569]">
                      TOTAL AMOUNT PAID:
                    </td>
                    <td className="py-2.5 px-3 text-right text-base text-[#1e3a8a] font-black font-mono">
                      ${receipt.totalAmount.toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Amount in Words */}
            <div className="p-3 bg-blue-50/40 border border-blue-100 rounded-lg text-xs space-y-1 mb-4">
              <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                Amount Chargeable (In Words):
              </span>
              <p className="font-bold text-[#1e3a8a] italic">
                {receipt.amountInWords}
              </p>
            </div>

            {/* Balances & Audit */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-[#e2e8f0] mb-8">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Net Outstanding Balance (All Accounts):
                </span>
                <span
                  className={`font-mono font-bold text-sm ${
                    receipt.outstandingBalanceAfterPayment > 0 ? 'text-amber-700' : 'text-emerald-700'
                  }`}
                >
                  ${receipt.outstandingBalanceAfterPayment.toFixed(2)}
                  {receipt.outstandingBalanceAfterPayment === 0 && ' (Dues Clear)'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-semibold">
                  Received & Certified By:
                </span>
                <span className="font-semibold text-[#1e293b]">{receipt.receivedBy}</span>
              </div>
            </div>

            {/* Signature & Seal Row */}
            <div className="grid grid-cols-2 gap-8 pt-8 border-t border-dashed border-[#cbd5e1] text-center text-xs">
              <div>
                <div className="h-12 border-b border-[#cbd5e1] flex items-end justify-center pb-1 font-mono text-[10px] text-[#94a3b8]">
                  [System Generated Digital Token]
                </div>
                <span className="text-[11px] font-semibold text-[#64748b] mt-1 block">
                  Student / Depositor Signature
                </span>
              </div>

              <div>
                <div className="h-12 border-b border-[#cbd5e1] flex items-end justify-center pb-1">
                  <span className="text-xs font-bold text-[#1e3a8a] flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Authorized Finance Signatory
                  </span>
                </div>
                <span className="text-[11px] font-semibold text-[#64748b] mt-1 block">
                  Accounts & Bursar Division
                </span>
              </div>
            </div>

            {/* Cancellation Notice if Voided */}
            {receipt.isVoided && (
              <div className="mt-6 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-800 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-red-900">
                  <AlertCircle className="w-4 h-4" />
                  <span>TRANSACTION VOIDED & CANCELLED</span>
                </div>
                <p>
                  <strong>Reason:</strong> {receipt.voidReason}
                </p>
                <p className="text-[10px] text-red-600">
                  Voided by {receipt.voidedBy || 'Finance Staff'} on {receipt.voidedAt || 'N/A'}. This receipt is invalid for accounting or audit verification.
                </p>
              </div>
            )}

            {/* Footer Notice */}
            <div className="mt-6 text-center text-[10px] text-[#94a3b8] border-t border-[#f1f5f9] pt-3">
              This is a computer-generated fee receipt issued by {receipt.schoolDetails.name}. Receipt numbers are strictly unique and non-transferable.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
