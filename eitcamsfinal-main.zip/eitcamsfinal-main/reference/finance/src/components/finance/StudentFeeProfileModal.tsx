import React, { useState } from 'react';
import {
  User,
  CreditCard,
  X,
  Receipt,
  DollarSign,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  Printer,
  FileText,
  ShieldCheck,
  Tag,
  ShieldAlert,
  Percent,
} from 'lucide-react';
import { StudentFeeSummary, FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentFeeProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: StudentFeeSummary | null;
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onOpenVoidModal: (payment: PaymentRecord) => void;
  onWaiveFee: (assignmentId: string, waiverAmount: number, reason: string) => Promise<any>;
}

export function StudentFeeProfileModal({
  isOpen,
  onClose,
  summary,
  onOpenPaymentModal,
  onOpenReceiptModal,
  onOpenVoidModal,
  onWaiveFee,
}: StudentFeeProfileModalProps) {
  const [activeTab, setActiveTab] = useState<'breakdown' | 'payments' | 'receipts'>('breakdown');
  const [waiverModalState, setWaiverModalState] = useState<{
    isOpen: boolean;
    assignment: FeeAssignment | null;
    amount: string;
    reason: string;
    isSubmitting: boolean;
    error: string | null;
  }>({
    isOpen: false,
    assignment: null,
    amount: '',
    reason: '',
    isSubmitting: false,
    error: null,
  });

  if (!isOpen || !summary) return null;

  const handleOpenWaiver = (assignment: FeeAssignment) => {
    setWaiverModalState({
      isOpen: true,
      assignment,
      amount: String(assignment.balance),
      reason: 'Merit scholarship / Administrative fee waiver',
      isSubmitting: false,
      error: null,
    });
  };

  const handleConfirmWaiver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!waiverModalState.assignment) return;

    const amt = parseFloat(waiverModalState.amount);
    if (isNaN(amt) || amt <= 0) {
      setWaiverModalState((prev) => ({ ...prev, error: 'Waiver amount must be greater than 0.' }));
      return;
    }
    if (amt > waiverModalState.assignment.balance) {
      setWaiverModalState((prev) => ({
        ...prev,
        error: `Waiver cannot exceed outstanding balance of $${waiverModalState.assignment?.balance}.`,
      }));
      return;
    }
    if (!waiverModalState.reason.trim()) {
      setWaiverModalState((prev) => ({ ...prev, error: 'Please enter an authorization reason.' }));
      return;
    }

    setWaiverModalState((prev) => ({ ...prev, isSubmitting: true, error: null }));
    try {
      await onWaiveFee(waiverModalState.assignment.id, amt, waiverModalState.reason.trim());
      setWaiverModalState({
        isOpen: false,
        assignment: null,
        amount: '',
        reason: '',
        isSubmitting: false,
        error: null,
      });
    } catch (err: any) {
      setWaiverModalState((prev) => ({
        ...prev,
        isSubmitting: false,
        error: err.message || 'Failed to apply fee waiver.',
      }));
    }
  };

  const getStatusBadge = (status: FeeAssignment['status']) => {
    switch (status) {
      case 'Paid':
        return <Badge variant="emerald">Paid</Badge>;
      case 'Partially Paid':
        return <Badge variant="amber">Partially Paid</Badge>;
      case 'Waived':
        return <Badge variant="purple">Waived</Badge>;
      default:
        return <Badge variant="rose">Unpaid</Badge>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Header */}
        <div className="p-6 border-b border-[#e2e8f0] bg-[#f8fafc] flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-lg shadow-xs">
              {summary.studentName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-[#1e293b]">{summary.studentName}</h2>
                <span className="font-mono text-xs font-bold bg-blue-100 text-[#1e3a8a] px-2 py-0.5 rounded border border-blue-200">
                  {summary.studentRegistrationNumber}
                </span>
                <span className="text-xs bg-slate-100 text-[#475569] font-medium px-2 py-0.5 rounded">
                  {summary.className} &bull; Sec {summary.section}
                </span>
              </div>
              <p className="text-xs text-[#64748b] mt-0.5">
                Academic Session: {summary.academicSession} &bull; Comprehensive Student Financial Ledger
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {summary.totalOutstanding > 0 && (
              <Button
                variant="primary"
                size="sm"
                onClick={() => onOpenPaymentModal(summary.studentRegistrationNumber)}
                leftIcon={<CreditCard className="w-3.5 h-3.5" />}
                className="text-xs"
              >
                Collect Payment
              </Button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#94a3b8] hover:text-[#1e293b] hover:bg-[#f1f5f9] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Summary Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-6 bg-white border-b border-[#e2e8f0]">
          <div className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl">
            <span className="text-[10px] uppercase font-bold text-[#64748b] tracking-wider block">
              Total Fees Assigned
            </span>
            <span className="text-lg font-black text-[#1e293b] font-mono">
              ${summary.totalDue.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-emerald-50/60 border border-emerald-100 rounded-xl">
            <span className="text-[10px] uppercase font-bold text-emerald-800 tracking-wider block">
              Total Collected
            </span>
            <span className="text-lg font-black text-emerald-700 font-mono">
              ${summary.totalPaid.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-purple-50/60 border border-purple-100 rounded-xl">
            <span className="text-[10px] uppercase font-bold text-purple-800 tracking-wider block">
              Waivers / Discounts
            </span>
            <span className="text-lg font-black text-purple-700 font-mono">
              ${summary.totalWaived.toFixed(2)}
            </span>
          </div>

          <div
            className={`p-3 rounded-xl border ${
              summary.totalOutstanding > 0
                ? 'bg-red-50/60 border-red-200'
                : 'bg-emerald-50/60 border-emerald-200'
            }`}
          >
            <span
              className={`text-[10px] uppercase font-bold tracking-wider block ${
                summary.totalOutstanding > 0 ? 'text-red-800' : 'text-emerald-800'
              }`}
            >
              Current Outstanding
            </span>
            <span
              className={`text-lg font-black font-mono ${
                summary.totalOutstanding > 0 ? 'text-red-700' : 'text-emerald-700'
              }`}
            >
              ${summary.totalOutstanding.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-[#e2e8f0] flex items-center gap-4 bg-[#f8fafc]">
          <button
            type="button"
            onClick={() => setActiveTab('breakdown')}
            className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'breakdown'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Fee Heads Breakdown ({summary.assignments.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('payments')}
            className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'payments'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Payment Transactions ({summary.payments.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('receipts')}
            className={`py-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'receipts'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Issued Receipts ({summary.receipts.length})
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 max-h-[50vh] overflow-y-auto">
          {activeTab === 'breakdown' && (
            <div className="space-y-3">
              {summary.assignments.map((assignment) => (
                <div
                  key={assignment.id}
                  className="p-4 border border-[#e2e8f0] rounded-xl hover:border-[#cbd5e1] transition-all bg-white shadow-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-[#1e293b]">{assignment.feeTypeName}</h4>
                        {getStatusBadge(assignment.status)}
                      </div>
                      <p className="text-[11px] text-[#64748b] mt-0.5 flex items-center gap-3">
                        <span>Due Date: {assignment.dueDate}</span>
                        <span>Assigned: {assignment.assignedDate}</span>
                        {assignment.remarks && <span className="italic">Note: {assignment.remarks}</span>}
                      </p>
                      {assignment.waiverReason && (
                        <p className="text-[11px] text-purple-700 bg-purple-50 px-2 py-0.5 rounded mt-1.5 inline-block">
                          Waiver Reason: {assignment.waiverReason}
                        </p>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs text-[#64748b] block">Balance / Due</span>
                      <span
                        className={`text-base font-black font-mono ${
                          assignment.balance > 0 ? 'text-red-700' : 'text-emerald-700'
                        }`}
                      >
                        ${assignment.balance.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-[#64748b] block">
                        of ${assignment.amountDue.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-[#f1f5f9] flex items-center justify-between">
                    <div className="flex items-center gap-4 text-xs text-[#475569]">
                      <span>
                        Paid: <strong className="text-emerald-700 font-mono">${assignment.amountPaid.toFixed(2)}</strong>
                      </span>
                      {assignment.discountOrWaiver > 0 && (
                        <span>
                          Waived: <strong className="text-purple-700 font-mono">${assignment.discountOrWaiver.toFixed(2)}</strong>
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {assignment.balance > 0 && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenWaiver(assignment)}
                            leftIcon={<Percent className="w-3 h-3" />}
                            className="text-xs py-1 px-2.5 text-purple-700 hover:bg-purple-50"
                          >
                            Apply Waiver
                          </Button>
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() =>
                              onOpenPaymentModal(summary.studentRegistrationNumber, assignment.id)
                            }
                            leftIcon={<DollarSign className="w-3 h-3" />}
                            className="text-xs py-1 px-2.5"
                          >
                            Pay Dues
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'payments' && (
            <div className="space-y-3">
              {summary.payments.length === 0 ? (
                <div className="p-8 text-center text-[#94a3b8] text-xs">
                  No payment transactions recorded for this student yet.
                </div>
              ) : (
                summary.payments.map((p) => (
                  <div
                    key={p.id}
                    className={`p-3.5 border rounded-xl flex items-center justify-between text-xs ${
                      p.isVoided ? 'bg-red-50/20 border-red-200' : 'bg-white border-[#e2e8f0]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#1e293b]">{p.id}</span>
                        <span className="font-mono text-[11px] bg-blue-50 text-[#1e3a8a] px-1.5 py-0.5 rounded font-bold">
                          {p.receiptNumber}
                        </span>
                        {p.isVoided ? (
                          <Badge variant="rose" size="sm">
                            CANCELLED
                          </Badge>
                        ) : (
                          <Badge variant="emerald" size="sm">
                            SUCCESS
                          </Badge>
                        )}
                      </div>
                      <p className="font-medium text-[#1e293b] mt-1">{p.feeTypeName}</p>
                      <p className="text-[11px] text-[#64748b]">
                        Date: {p.paymentDate} &bull; Mode: {p.paymentMode}{' '}
                        {p.transactionReference && `(${p.transactionReference})`}
                      </p>
                      {p.isVoided && (
                        <p className="text-[11px] text-red-700 mt-1">
                          <strong>Cancellation Reason:</strong> {p.voidReason} (by {p.voidedBy})
                        </p>
                      )}
                    </div>

                    <div className="text-right space-y-1.5">
                      <span className="font-mono font-black text-sm text-[#1e293b] block">
                        ${p.amountPaid.toFixed(2)}
                      </span>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            const r = summary.receipts.find((rec) => rec.paymentId === p.id);
                            if (r) onOpenReceiptModal(r);
                          }}
                          className="p-1 text-[#1e3a8a] hover:bg-blue-50 rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                          Receipt
                        </button>
                        {!p.isVoided && (
                          <button
                            type="button"
                            onClick={() => onOpenVoidModal(p)}
                            className="p-1 text-red-600 hover:bg-red-50 rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                          >
                            <ShieldAlert className="w-3.5 h-3.5" />
                            Void
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'receipts' && (
            <div className="space-y-3">
              {summary.receipts.length === 0 ? (
                <div className="p-8 text-center text-[#94a3b8] text-xs">
                  No receipts issued yet.
                </div>
              ) : (
                summary.receipts.map((r) => (
                  <div
                    key={r.receiptNumber}
                    className="p-3.5 bg-white border border-[#e2e8f0] rounded-xl flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#1e3a8a]">{r.receiptNumber}</span>
                        {r.isVoided && (
                          <Badge variant="rose" size="sm">
                            VOIDED
                          </Badge>
                        )}
                      </div>
                      <p className="font-medium text-[#1e293b] mt-0.5">{r.feeTypeName}</p>
                      <p className="text-[11px] text-[#64748b]">
                        Issued: {r.receiptDate} &bull; Mode: {r.paymentMode} &bull; Received by {r.receivedBy}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono font-black text-sm text-[#1e293b]">
                        ${r.amountPaid.toFixed(2)}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onOpenReceiptModal(r)}
                        leftIcon={<Printer className="w-3.5 h-3.5" />}
                        className="text-xs"
                      >
                        View / Print
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* Internal Modal for Applying Fee Waiver */}
      {waiverModalState.isOpen && waiverModalState.assignment && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 border border-purple-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-purple-950 flex items-center gap-2">
                <Percent className="w-4 h-4 text-purple-700" />
                Apply Student Fee Waiver / Scholarship
              </h3>
              <button
                type="button"
                onClick={() => setWaiverModalState({ ...waiverModalState, isOpen: false })}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmWaiver} className="space-y-4 text-xs">
              {waiverModalState.error && (
                <div className="p-2.5 bg-red-50 text-red-700 rounded-lg border border-red-200">
                  {waiverModalState.error}
                </div>
              )}

              <div className="p-3 bg-[#f8fafc] rounded-lg space-y-1">
                <div>
                  <strong>Fee Item:</strong> {waiverModalState.assignment.feeTypeName}
                </div>
                <div>
                  <strong>Current Balance:</strong> ${waiverModalState.assignment.balance.toFixed(2)}
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1">
                  Waiver / Discount Amount ($) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={waiverModalState.assignment.balance}
                  value={waiverModalState.amount}
                  onChange={(e) =>
                    setWaiverModalState({ ...waiverModalState, amount: e.target.value })
                  }
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-[#1e293b] mb-1">
                  Waiver Authorization Reason *
                </label>
                <input
                  type="text"
                  value={waiverModalState.reason}
                  onChange={(e) =>
                    setWaiverModalState({ ...waiverModalState, reason: e.target.value })
                  }
                  placeholder="e.g. Merit scholarship approval ref #9921"
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  required
                />
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  type="button"
                  onClick={() => setWaiverModalState({ ...waiverModalState, isOpen: false })}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  type="submit"
                  isLoading={waiverModalState.isSubmitting}
                  className="bg-purple-700 hover:bg-purple-800"
                >
                  Confirm Waiver
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
