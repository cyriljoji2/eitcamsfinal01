import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  CreditCard,
  Layers,
  Users,
  Search,
  Filter,
  DollarSign,
  TrendingUp,
  FileText,
  Building2,
  PieChart,
} from 'lucide-react';
import { PaymentRecord, FeeAssignment, FeeReceipt, StudentFeeSummary } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface FinancialReportsViewProps {
  payments: PaymentRecord[];
  assignments: FeeAssignment[];
  receipts: FeeReceipt[];
  summaries: StudentFeeSummary[];
  onViewStudentProfile: (studentRegNo: string) => void;
}

type ReportType =
  | 'daily-collection'
  | 'category-breakdown'
  | 'mode-breakdown'
  | 'class-receivables'
  | 'student-statement';

export function FinancialReportsView({
  payments,
  assignments,
  receipts,
  summaries,
  onViewStudentProfile,
}: FinancialReportsViewProps) {
  const [reportType, setReportType] = useState<ReportType>('daily-collection');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [startDate, setStartDate] = useState('2026-08-01');
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedStudentReg, setSelectedStudentReg] = useState(summaries[0]?.studentRegistrationNumber || '');
  const [statementSearch, setStatementSearch] = useState('');

  // Valid non-voided payments
  const validPayments = payments.filter((p) => !p.isVoided);

  // 1. Daily Collection Data
  const dailyPayments = validPayments.filter((p) => p.paymentDate === selectedDate);
  const dailyTotal = dailyPayments.reduce((acc, p) => acc + p.amountPaid, 0);

  // 2. Date Range Filtered Payments
  const dateRangePayments = validPayments.filter(
    (p) => (!startDate || p.paymentDate >= startDate) && (!endDate || p.paymentDate <= endDate)
  );
  const dateRangeTotal = dateRangePayments.reduce((acc, p) => acc + p.amountPaid, 0);

  // 3. Category Breakdown Data
  const categoryMap: { [cat: string]: { count: number; total: number } } = {};
  dateRangePayments.forEach((p) => {
    const feeHead = p.feeTypeName;
    if (!categoryMap[feeHead]) {
      categoryMap[feeHead] = { count: 0, total: 0 };
    }
    categoryMap[feeHead].count += 1;
    categoryMap[feeHead].total += p.amountPaid;
  });
  const categoryList = Object.entries(categoryMap).map(([name, data]) => ({
    name,
    ...data,
    percentage: dateRangeTotal > 0 ? (data.total / dateRangeTotal) * 100 : 0,
  }));

  // 4. Payment Mode Breakdown Data
  const modeMap: { [mode: string]: { count: number; total: number } } = {};
  dateRangePayments.forEach((p) => {
    const mode = p.paymentMode;
    if (!modeMap[mode]) {
      modeMap[mode] = { count: 0, total: 0 };
    }
    modeMap[mode].count += 1;
    modeMap[mode].total += p.amountPaid;
  });
  const modeList = Object.entries(modeMap).map(([name, data]) => ({
    name,
    ...data,
    percentage: dateRangeTotal > 0 ? (data.total / dateRangeTotal) * 100 : 0,
  }));

  // 5. Class Receivables Summary
  const classMap: { [className: string]: { totalDue: number; totalPaid: number; balance: number; studentCount: number } } = {};
  assignments.forEach((a) => {
    if (!classMap[a.className]) {
      classMap[a.className] = { totalDue: 0, totalPaid: 0, balance: 0, studentCount: 0 };
    }
    classMap[a.className].totalDue += a.amountDue;
    classMap[a.className].totalPaid += a.amountPaid;
    classMap[a.className].balance += a.balance;
  });
  // Calculate unique students per class
  Object.keys(classMap).forEach((cls) => {
    classMap[cls].studentCount = new Set(
      assignments.filter((a) => a.className === cls).map((a) => a.studentRegistrationNumber)
    ).size;
  });
  const classList = Object.entries(classMap).map(([className, data]) => ({
    className,
    ...data,
    collectionRate: data.totalDue > 0 ? (data.totalPaid / data.totalDue) * 100 : 100,
  }));

  // 6. Selected Student Statement
  const selectedStudentSummary = summaries.find(
    (s) => s.studentRegistrationNumber.toLowerCase() === selectedStudentReg.toLowerCase()
  );

  // CSV Exporters for each report
  const exportCurrentReport = () => {
    let headers: string[] = [];
    let rows: (string | number)[][] = [];
    let filename = `Report_${reportType}_${new Date().toISOString().split('T')[0]}.csv`;

    if (reportType === 'daily-collection') {
      headers = ['Payment ID', 'Receipt #', 'Date', 'Reg No', 'Student Name', 'Class', 'Fee Head', 'Mode', 'Amount ($)'];
      rows = dailyPayments.map((p) => [
        p.id,
        p.receiptNumber,
        p.paymentDate,
        p.studentRegistrationNumber,
        p.studentName,
        p.className,
        p.feeTypeName,
        p.paymentMode,
        p.amountPaid.toFixed(2),
      ]);
      filename = `Daily_Collection_${selectedDate}.csv`;
    } else if (reportType === 'category-breakdown') {
      headers = ['Fee Particular / Head', 'Transactions Count', 'Total Collection ($)', 'Share of Revenue (%)'];
      rows = categoryList.map((c) => [c.name, c.count, c.total.toFixed(2), c.percentage.toFixed(1) + '%']);
      filename = `Fee_Category_Collection_${startDate}_to_${endDate}.csv`;
    } else if (reportType === 'mode-breakdown') {
      headers = ['Payment Mode', 'Transactions Count', 'Total Amount ($)', 'Percentage of Total (%)'];
      rows = modeList.map((m) => [m.name, m.count, m.total.toFixed(2), m.percentage.toFixed(1) + '%']);
      filename = `Payment_Mode_Summary_${startDate}_to_${endDate}.csv`;
    } else if (reportType === 'class-receivables') {
      headers = ['Class', 'Students Count', 'Total Billed ($)', 'Total Collected ($)', 'Outstanding Balance ($)', 'Collection Rate (%)'];
      rows = classList.map((c) => [
        c.className,
        c.studentCount,
        c.totalDue.toFixed(2),
        c.totalPaid.toFixed(2),
        c.balance.toFixed(2),
        c.collectionRate.toFixed(1) + '%',
      ]);
      filename = `Class_Receivables_Summary.csv`;
    } else if (reportType === 'student-statement' && selectedStudentSummary) {
      headers = ['Date / Ref', 'Transaction / Item', 'Billed ($)', 'Paid ($)', 'Balance ($)'];
      rows = [
        ...selectedStudentSummary.assignments.map((a) => [
          a.assignedDate,
          `Fee: ${a.feeTypeName}`,
          a.amountDue.toFixed(2),
          a.amountPaid.toFixed(2),
          a.balance.toFixed(2),
        ]),
        ...selectedStudentSummary.payments.map((p) => [
          p.paymentDate,
          `Payment: ${p.id} (${p.paymentMode})`,
          '0.00',
          p.amountPaid.toFixed(2),
          '-',
        ]),
      ];
      filename = `Account_Statement_${selectedStudentSummary.studentRegistrationNumber}.csv`;
    }

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const filteredStatementStudents = summaries.filter(
    (s) =>
      s.studentName.toLowerCase().includes(statementSearch.toLowerCase()) ||
      s.studentRegistrationNumber.toLowerCase().includes(statementSearch.toLowerCase()) ||
      s.className.toLowerCase().includes(statementSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Financial Intelligence & Reports</h2>
            <span className="bg-blue-50 text-[#1e3a8a] text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
              Audit Grade Reports
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Export daily scrolls, fee-head breakdowns, payment channel analytics, and student financial statements.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={exportCurrentReport}
          leftIcon={<Download className="w-3.5 h-3.5" />}
          className="text-xs"
        >
          Export Current Report CSV
        </Button>
      </div>

      {/* Report Navigation Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-white p-2 rounded-xl border border-[#e2e8f0] shadow-xs">
        <button
          type="button"
          onClick={() => setReportType('daily-collection')}
          className={`px-3 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            reportType === 'daily-collection'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Daily Scroll</span>
        </button>

        <button
          type="button"
          onClick={() => setReportType('category-breakdown')}
          className={`px-3 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            reportType === 'category-breakdown'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Fee Head Split</span>
        </button>

        <button
          type="button"
          onClick={() => setReportType('mode-breakdown')}
          className={`px-3 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            reportType === 'mode-breakdown'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Payment Channels</span>
        </button>

        <button
          type="button"
          onClick={() => setReportType('class-receivables')}
          className={`px-3 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            reportType === 'class-receivables'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Class Receivables</span>
        </button>

        <button
          type="button"
          onClick={() => setReportType('student-statement')}
          className={`px-3 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            reportType === 'student-statement'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Student Statement</span>
        </button>
      </div>

      {/* REPORT 1: DAILY COLLECTION SCROLL */}
      {reportType === 'daily-collection' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                Select Collection Date:
              </span>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden bg-[#f8fafc]"
              />
            </div>
            <div className="text-right">
              <span className="text-[11px] text-[#64748b] block">Day's Total Inflow</span>
              <span className="text-lg font-black font-mono text-emerald-700">
                ${dailyTotal.toFixed(2)} ({dailyPayments.length} transactions)
              </span>
            </div>
          </div>

          <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Receipt # & Payment ID</th>
                  <th className="py-3 px-4">Student Name (Reg #)</th>
                  <th className="py-3 px-4">Class</th>
                  <th className="py-3 px-4">Fee Head</th>
                  <th className="py-3 px-4">Payment Mode</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4">Cashier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {dailyPayments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-[#94a3b8]">
                      No fee payments recorded on {selectedDate}.
                    </td>
                  </tr>
                ) : (
                  dailyPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-[#f8fafc]">
                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-[#1e3a8a] block">
                          {p.receiptNumber}
                        </span>
                        <span className="font-mono text-[10px] text-[#64748b]">{p.id}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-[#1e293b]">{p.studentName}</span>
                        <span className="text-[10px] text-[#64748b] block font-mono">
                          {p.studentRegistrationNumber}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-[#475569]">
                        {p.className} - {p.section}
                      </td>
                      <td className="py-3 px-4 font-medium text-[#1e293b]">{p.feeTypeName}</td>
                      <td className="py-3 px-4 font-semibold text-[#475569]">{p.paymentMode}</td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700">
                        ${p.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-[#64748b] text-[11px]">{p.receivedBy}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 2: FEE CATEGORY / HEAD BREAKDOWN */}
      {reportType === 'category-breakdown' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex items-center justify-between shadow-xs flex-wrap gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-[#1e293b]">Date Range:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="px-2 py-1 rounded-lg border border-[#cbd5e1] outline-hidden text-xs"
              />
              <span>to</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="px-2 py-1 rounded-lg border border-[#cbd5e1] outline-hidden text-xs"
              />
            </div>
            <div className="text-right">
              <span className="text-[11px] text-[#64748b] block">Total Collected in Period</span>
              <span className="text-lg font-black font-mono text-emerald-700">
                ${dateRangeTotal.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Fee Head / Particular</th>
                  <th className="py-3 px-4 text-center">Txn Count</th>
                  <th className="py-3 px-4 text-right">Total Inflow ($)</th>
                  <th className="py-3 px-4">Revenue Contribution</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {categoryList.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-10 text-center text-[#94a3b8]">
                      No collection data available in this date range.
                    </td>
                  </tr>
                ) : (
                  categoryList.map((cat) => (
                    <tr key={cat.name} className="hover:bg-[#f8fafc]">
                      <td className="py-3.5 px-4 font-bold text-[#1e293b]">{cat.name}</td>
                      <td className="py-3.5 px-4 text-center font-mono text-[#475569]">{cat.count}</td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-sm text-[#1e293b]">
                        ${cat.total.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-100 h-2 rounded-full overflow-hidden">
                            <div
                              className="bg-[#1e3a8a] h-full rounded-full"
                              style={{ width: `${cat.percentage}%` }}
                            />
                          </div>
                          <span className="font-mono text-[11px] font-bold text-[#64748b] w-12 text-right">
                            {cat.percentage.toFixed(1)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 3: PAYMENT CHANNELS & MODES */}
      {reportType === 'mode-breakdown' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex items-center justify-between shadow-xs flex-wrap gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className="font-bold text-[#1e293b]">Period:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="px-2 py-1 rounded-lg border border-[#cbd5e1] outline-hidden text-xs"
              />
              <span>to</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="px-2 py-1 rounded-lg border border-[#cbd5e1] outline-hidden text-xs"
              />
            </div>
            <div className="text-right">
              <span className="text-[11px] text-[#64748b] block">Total Collections</span>
              <span className="text-lg font-black font-mono text-emerald-700">
                ${dateRangeTotal.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {modeList.map((m) => (
              <div
                key={m.name}
                className="p-5 bg-white border border-[#e2e8f0] rounded-xl shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-[#1e293b] flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-[#1e3a8a]" />
                    {m.name}
                  </span>
                  <Badge variant="blue" size="sm">
                    {m.count} Deposits
                  </Badge>
                </div>
                <div className="flex items-baseline justify-between">
                  <span className="text-2xl font-black font-mono text-[#1e293b]">
                    ${m.total.toFixed(2)}
                  </span>
                  <span className="font-mono text-xs font-bold text-emerald-700">
                    {m.percentage.toFixed(1)}% of total
                  </span>
                </div>
                <div className="bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full"
                    style={{ width: `${m.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* REPORT 4: CLASS RECEIVABLES SUMMARY */}
      {reportType === 'class-receivables' && (
        <div className="space-y-4">
          <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Class / Cohort</th>
                  <th className="py-3 px-4 text-center">Enrolled Students</th>
                  <th className="py-3 px-4 text-right">Total Billed ($)</th>
                  <th className="py-3 px-4 text-right">Total Collected ($)</th>
                  <th className="py-3 px-4 text-right">Outstanding ($)</th>
                  <th className="py-3 px-4">Recovery Efficiency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {classList.map((c) => (
                  <tr key={c.className} className="hover:bg-[#f8fafc]">
                    <td className="py-3.5 px-4 font-bold text-[#1e293b]">{c.className}</td>
                    <td className="py-3.5 px-4 text-center font-mono text-[#475569]">{c.studentCount}</td>
                    <td className="py-3.5 px-4 text-right font-mono text-[#475569]">
                      ${c.totalDue.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-semibold text-emerald-700">
                      ${c.totalPaid.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-red-700">
                      ${c.balance.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              c.collectionRate >= 75 ? 'bg-emerald-600' : 'bg-amber-500'
                            }`}
                            style={{ width: `${Math.min(c.collectionRate, 100)}%` }}
                          />
                        </div>
                        <span className="font-mono text-[11px] font-bold text-[#64748b] w-12 text-right">
                          {c.collectionRate.toFixed(1)}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 5: STUDENT STATEMENT */}
      {reportType === 'student-statement' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs space-y-3">
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Select Student to Generate Account Statement:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Filter student list..."
                value={statementSearch}
                onChange={(e) => setStatementSearch(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] outline-hidden bg-[#f8fafc]"
              />
              <select
                value={selectedStudentReg}
                onChange={(e) => setSelectedStudentReg(e.target.value)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg border border-[#cbd5e1] bg-white outline-hidden"
              >
                {filteredStatementStudents.map((s) => (
                  <option key={s.studentRegistrationNumber} value={s.studentRegistrationNumber}>
                    {s.studentRegistrationNumber} — {s.studentName} ({s.className})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedStudentSummary && (
            <div className="p-6 bg-white border border-[#e2e8f0] rounded-xl shadow-xs space-y-5">
              <div className="flex items-start justify-between border-b border-[#e2e8f0] pb-4">
                <div>
                  <h3 className="text-base font-bold text-[#1e293b]">
                    Student Statement of Account
                  </h3>
                  <p className="text-xs text-[#64748b] mt-0.5">
                    {selectedStudentSummary.studentName} &bull; Reg No: {selectedStudentSummary.studentRegistrationNumber} &bull; Class: {selectedStudentSummary.className}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] uppercase font-bold text-[#64748b] block">
                    Outstanding Balance
                  </span>
                  <span
                    className={`text-xl font-black font-mono ${
                      selectedStudentSummary.totalOutstanding > 0 ? 'text-red-700' : 'text-emerald-700'
                    }`}
                  >
                    ${selectedStudentSummary.totalOutstanding.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Transactions Ledger */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-[#475569] uppercase tracking-wider">
                  Assigned Dues & Collections Timeline
                </h4>
                <div className="border border-[#e2e8f0] rounded-lg overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                      <tr>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Transaction Description</th>
                        <th className="py-2.5 px-3 text-right">Debit / Billed</th>
                        <th className="py-2.5 px-3 text-right">Credit / Paid</th>
                        <th className="py-2.5 px-3 text-right">Remaining Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#f1f5f9]">
                      {selectedStudentSummary.assignments.map((a) => (
                        <tr key={a.id}>
                          <td className="py-2.5 px-3 text-[#64748b]">{a.assignedDate}</td>
                          <td className="py-2.5 px-3 font-semibold text-[#1e293b]">
                            {a.feeTypeName} (Due: {a.dueDate})
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-[#1e293b]">
                            ${a.amountDue.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-emerald-700">
                            ${a.amountPaid.toFixed(2)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-bold text-red-700">
                            ${a.balance.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
