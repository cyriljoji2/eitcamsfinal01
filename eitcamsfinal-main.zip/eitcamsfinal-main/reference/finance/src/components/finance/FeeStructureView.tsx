import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
  Calendar,
  DollarSign,
  Tag,
  Download,
  AlertCircle,
} from 'lucide-react';
import { FeeStructureItem, FeeCategory } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { FeeStructureModal } from './FeeStructureModal';

interface FeeStructureViewProps {
  feeStructures: FeeStructureItem[];
  onCreateFeeStructure: (data: Omit<FeeStructureItem, 'id' | 'createdAt'>) => Promise<any>;
  onUpdateFeeStructure: (id: string, data: Partial<FeeStructureItem>) => Promise<any>;
  onToggleStatus: (id: string) => Promise<any>;
  onDeleteFeeStructure: (id: string) => Promise<any>;
  onNavigateToAssign: (feeStructureId: string) => void;
}

export function FeeStructureView({
  feeStructures,
  onCreateFeeStructure,
  onUpdateFeeStructure,
  onToggleStatus,
  onDeleteFeeStructure,
  onNavigateToAssign,
}: FeeStructureViewProps) {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    item: FeeStructureItem | null;
  }>({
    isOpen: false,
    item: null,
  });

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredItems = feeStructures.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.id.toLowerCase().includes(search.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(search.toLowerCase()));

    const matchesCategory = categoryFilter === 'all' || item.feeCategory === categoryFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleExportCsv = () => {
    const headers = [
      'Fee ID',
      'Fee Head Name',
      'Category',
      'Amount (USD)',
      'Academic Session',
      'Applicable Classes',
      'Frequency',
      'Due Date',
      'Status',
    ];

    const rows = filteredItems.map((item) => [
      item.id,
      item.name,
      item.feeCategory,
      item.amount.toFixed(2),
      item.academicSession,
      item.applicableClassNames.join('; '),
      item.frequency,
      item.dueDate,
      item.status.toUpperCase(),
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Fee_Structures_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const categories = Array.from(new Set(feeStructures.map((f) => f.feeCategory)));

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-[#1e293b]">Fee Structure Management</h2>
            <span className="bg-blue-50 text-[#1e3a8a] text-xs font-bold px-2 py-0.5 rounded-full border border-blue-100">
              {feeStructures.length} Configured Heads
            </span>
          </div>
          <p className="text-xs text-[#64748b] mt-0.5">
            Define tuition, admission, exam, transport, and lab fee tiers for academic sessions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="text-xs"
          >
            Export CSV
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => setModalState({ isOpen: true, item: null })}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs"
          >
            Create Fee Head
          </Button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] flex flex-wrap items-center gap-3 shadow-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by fee name, ID, or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a] outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-[#64748b]" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Fee Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs rounded-lg border border-[#cbd5e1] bg-white text-[#475569] font-medium outline-hidden"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive / Draft</option>
          </select>
        </div>
      </div>

      {/* Table of Fee Structures */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Fee ID & Head</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Applicable Classes</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Frequency</th>
                <th className="py-3 px-4">Default Due Date</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-[#94a3b8]">
                    No fee structures found matching the filter criteria.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#1e3a8a] text-[11px] bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                          {item.id}
                        </span>
                        <div>
                          <span className="font-bold text-[#1e293b] block">{item.name}</span>
                          <span className="text-[10px] text-[#64748b]">
                            Session: {item.academicSession}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center gap-1 font-medium text-[#475569]">
                        <Tag className="w-3 h-3 text-[#94a3b8]" />
                        {item.feeCategory}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex flex-wrap gap-1 max-w-[180px]">
                        {item.applicableClassNames.slice(0, 3).map((cls) => (
                          <span
                            key={cls}
                            className="bg-slate-100 text-[#475569] text-[10px] px-1.5 py-0.5 rounded font-medium"
                          >
                            {cls}
                          </span>
                        ))}
                        {item.applicableClassNames.length > 3 && (
                          <span className="text-[10px] text-[#64748b]">
                            +{item.applicableClassNames.length - 3} more
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-sm text-[#1e293b]">
                      ${item.amount.toFixed(2)}
                    </td>

                    <td className="py-3.5 px-4 text-[#475569]">{item.frequency}</td>

                    <td className="py-3.5 px-4 text-[#475569]">
                      <div className="flex items-center gap-1 text-[11px]">
                        <Calendar className="w-3 h-3 text-[#94a3b8]" />
                        {item.dueDate}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => onToggleStatus(item.id)}
                        className="cursor-pointer"
                        title="Click to toggle status"
                      >
                        {item.status === 'active' ? (
                          <Badge variant="emerald" size="sm">
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="slate" size="sm">
                            Inactive
                          </Badge>
                        )}
                      </button>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onNavigateToAssign(item.id)}
                          className="text-[11px] py-1 px-2 text-[#1e3a8a]"
                        >
                          Assign
                        </Button>

                        <button
                          type="button"
                          onClick={() => setModalState({ isOpen: true, item })}
                          className="p-1 text-[#64748b] hover:text-[#1e3a8a] hover:bg-blue-50 rounded transition-colors cursor-pointer"
                          title="Edit Fee Head"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteConfirmId(item.id)}
                          className="p-1 text-[#64748b] hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer"
                          title="Delete Fee Head"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-5 border border-[#e2e8f0] text-xs">
            <h4 className="font-bold text-sm text-[#1e293b] mb-2 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-red-600" />
              Confirm Delete Fee Structure
            </h4>
            <p className="text-[#64748b] mb-4">
              Are you sure you want to remove this fee head definition? Existing recorded payments will remain preserved in historical audit logs.
            </p>
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDeleteConfirmId(null)}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={async () => {
                  await onDeleteFeeStructure(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Fee Structure Create/Edit Modal */}
      <FeeStructureModal
        isOpen={modalState.isOpen}
        onClose={() => setModalState({ isOpen: false, item: null })}
        item={modalState.item}
        onSubmit={async (data) => {
          if (modalState.item) {
            await onUpdateFeeStructure(modalState.item.id, data);
          } else {
            await onCreateFeeStructure(data);
          }
        }}
      />
    </div>
  );
}
