import React from 'react';
import {
  X,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Building,
  Calendar,
  Clock,
  MapPin,
  Phone,
  User,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { LeaveOutingRequest } from '../../types/hostel';
import { Button } from '../ui/Button';

interface LeaveOutingSlipModalProps {
  isOpen: boolean;
  onClose: () => void;
  request: LeaveOutingRequest | null;
}

export function LeaveOutingSlipModal({
  isOpen,
  onClose,
  request,
}: LeaveOutingSlipModalProps) {
  if (!isOpen || !request) return null;

  // STRICT REQUIREMENT: There must NEVER be an official slip for non-approved statuses
  if (request.status !== 'APPROVED') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-2xs">
        <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">Official Slip Unavailable</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Official Leave/Outing Slips are generated strictly after final approval by the Hostel Office.
            This request is currently in status <strong className="font-mono text-slate-800">{request.status}</strong>.
          </p>
          <Button variant="outline" size="sm" onClick={onClose} className="w-full">
            Close
          </Button>
        </div>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const isOuting = request.requestType === 'outing';
  const slipTitle = isOuting ? 'OFFICIAL DAY OUTING SLIP' : 'OFFICIAL HOSTEL LEAVE SLIP';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-3xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Modal Action Bar (Hidden in Print) */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#1e3a8a] bg-[#eff6ff] px-2.5 py-1 rounded-md flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Official Gate Clearance Slip
            </span>
            <span className="text-xs text-[#64748b] font-mono">
              {request.slipNumber || request.id}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="primary" onClick={handlePrint} className="gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Download Slip</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Slip Content */}
        <div className="p-8 sm:p-10 space-y-6 print:p-6 text-slate-800">
          {/* Institution Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-[10px] font-bold tracking-widest text-[#1e3a8a] uppercase">
                Hostel Administration Office
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-[#0f172a] tracking-tight">
                ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Deemed to be University &bull; Directorate of Student Affairs & Campus Hostels
              </p>
            </div>

            <div className="text-right sm:border-l sm:pl-5 border-slate-200 shrink-0">
              <span className="inline-block px-3 py-1 text-xs font-black tracking-wider uppercase rounded-md bg-emerald-50 text-emerald-800 border border-emerald-300">
                {slipTitle}
              </span>
              <div className="text-xs font-mono font-bold text-slate-700 mt-1">
                Slip No: {request.slipNumber || 'SLIP-EIT-2026'}
              </div>
              <div className="text-[10px] font-mono text-slate-500">
                Req ID: {request.requestNumber || request.id}
              </div>
            </div>
          </div>

          {/* Verification Watermark & Official Approved Stamp */}
          <div className="bg-emerald-50/50 border border-emerald-200 rounded-lg p-3.5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-emerald-950 uppercase tracking-wide">
                  Official Gate Clearance Approved
                </div>
                <div className="text-[11px] text-emerald-800">
                  Approved by Hostel Office on{' '}
                  <strong>
                    {request.hostelActionDate
                      ? new Date(request.hostelActionDate).toLocaleString('en-IN', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })
                      : 'Verified'}
                  </strong>
                </div>
              </div>
            </div>

            <div className="text-right border-2 border-emerald-700 rounded px-2.5 py-1 rotate-[-2deg] bg-white/80 shrink-0 shadow-2xs">
              <div className="text-[9px] font-black tracking-widest text-emerald-800 uppercase">
                EIT HOSTEL OFFICE
              </div>
              <div className="text-xs font-black text-emerald-700 tracking-wider">
                VERIFIED &bull; PASS ISSUED
              </div>
            </div>
          </div>

          {/* Student & Allotment Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Student Profile */}
            <div className="border border-slate-200 rounded-lg p-4 space-y-2 bg-slate-50/50">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-slate-200">
                <User className="w-3.5 h-3.5 text-[#1e3a8a]" />
                Student Particulars
              </div>
              <div className="grid grid-cols-3 gap-1 text-xs">
                <span className="text-slate-500 font-medium">Student Name:</span>
                <span className="col-span-2 font-bold text-slate-900">{request.studentName}</span>

                <span className="text-slate-500 font-medium">Reg. Number:</span>
                <span className="col-span-2 font-mono font-bold text-[#1e3a8a]">
                  {request.studentRegistrationNumber}
                </span>

                <span className="text-slate-500 font-medium">Program / Branch:</span>
                <span className="col-span-2 font-medium text-slate-800">
                  {request.program || request.studentClass}
                </span>

                <span className="text-slate-500 font-medium">Batch / Session:</span>
                <span className="col-span-2 font-medium text-slate-800">
                  {request.batch || '2023-2027'} (Sec: {request.studentSection})
                </span>

                <span className="text-slate-500 font-medium">Student Contact:</span>
                <span className="col-span-2 font-mono text-slate-800">
                  {request.contactNumber || request.parentContactNumber || 'Not provided'}
                </span>
              </div>
            </div>

            {/* Hostel Details */}
            <div className="border border-slate-200 rounded-lg p-4 space-y-2 bg-slate-50/50">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-slate-200">
                <Building className="w-3.5 h-3.5 text-[#1e3a8a]" />
                Hostel Residence Details
              </div>
              <div className="grid grid-cols-3 gap-1 text-xs">
                <span className="text-slate-500 font-medium">Hostel:</span>
                <span className="col-span-2 font-bold text-slate-900">
                  {request.hostelName || 'Campus Men’s / Women’s Hostel'}
                </span>

                <span className="text-slate-500 font-medium">Block & Floor:</span>
                <span className="col-span-2 font-medium text-slate-800">
                  {request.blockName || request.hostelBlock || 'Main Block'}
                  {request.floorName ? ` &bull; ${request.floorName}` : ''}
                </span>

                <span className="text-slate-500 font-medium">Room & Bed:</span>
                <span className="col-span-2 font-mono font-bold text-slate-900">
                  Room {request.roomNumber || '-'} &bull; Bed {request.bedNumber || '-'}
                </span>

                <span className="text-slate-500 font-medium">Emergency Phone:</span>
                <span className="col-span-2 font-mono text-slate-800">
                  {request.emergencyContact || request.parentContactNumber || 'Not provided'}
                </span>

                <span className="text-slate-500 font-medium">Allotment Ref:</span>
                <span className="col-span-2 font-mono text-[11px] text-slate-600 truncate">
                  {request.hostelAllotmentId || 'Active Hostel Allotment'}
                </span>
              </div>
            </div>
          </div>

          {/* Schedule & Movement Specifications */}
          <div className="border border-slate-200 rounded-lg p-4 space-y-3 bg-white">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5 pb-1 border-b border-slate-200">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Leave / Outing Schedule & Destination
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-1">
                <div className="text-slate-500 text-[11px] font-semibold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  Departure from Hostel (Out-Time)
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {request.fromDate} at {request.fromTime || '09:00 AM'}
                </div>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-md space-y-1">
                <div className="text-slate-500 text-[11px] font-semibold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  Expected Return to Hostel (In-Time)
                </div>
                <div className="text-sm font-bold text-slate-900">
                  {request.toDate} at {request.toTime || '06:00 PM'}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
              <div>
                <span className="text-slate-500 font-medium block">Destination / Place of Visit:</span>
                <span className="font-bold text-slate-900 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  {request.destination || request.destinationAddress || 'Local City Area'}
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-500 font-medium block">Declared Reason & Purpose:</span>
                <span className="text-slate-800 font-medium mt-0.5 block bg-slate-50 p-2 rounded border border-slate-200">
                  {request.reason || request.purpose}
                </span>
              </div>
            </div>
          </div>

          {/* Multi-Stage Official Approval Log */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Stage 1: Proctor Approval */}
            <div className="border border-blue-200 bg-blue-50/40 rounded-lg p-3.5 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider">
                  Stage 1: Proctor Mentorship Approval
                </span>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded">
                  ENDORSED
                </span>
              </div>
              <div className="text-slate-900 font-semibold">{request.proctorName}</div>
              <div className="text-[11px] text-slate-600">
                Endorsed on:{' '}
                <strong>
                  {request.proctorActionDate
                    ? new Date(request.proctorActionDate).toLocaleString('en-IN', {
                        dateStyle: 'short',
                        timeStyle: 'short',
                      })
                    : 'Recorded'}
                </strong>
              </div>
              {request.proctorRemarks && (
                <div className="text-[11px] text-slate-700 italic border-t border-blue-200/60 pt-1">
                  &ldquo;{request.proctorRemarks}&rdquo;
                </div>
              )}
            </div>

            {/* Stage 2: Hostel Office Approval */}
            <div className="border border-emerald-200 bg-emerald-50/40 rounded-lg p-3.5 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-900 text-[11px] uppercase tracking-wider">
                  Stage 2: Hostel Office Gate Clearance
                </span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                  APPROVED
                </span>
              </div>
              <div className="text-slate-900 font-semibold">
                {request.hostelActionBy || 'Hostel Office Authority'}
              </div>
              <div className="text-[11px] text-slate-600">
                Approval Time:{' '}
                <strong>
                  {request.hostelActionDate
                    ? new Date(request.hostelActionDate).toLocaleString('en-IN', {
                        dateStyle: 'short',
                        timeStyle: 'short',
                      })
                    : 'Recorded'}
                </strong>
              </div>
              {request.hostelRemarks && (
                <div className="text-[11px] text-slate-700 italic border-t border-emerald-200/60 pt-1">
                  &ldquo;{request.hostelRemarks}&rdquo;
                </div>
              )}
            </div>
          </div>

          {/* Security Gate In / Out Recording Section (Crucial for campus security) */}
          <div className="border-2 border-dashed border-slate-300 rounded-lg p-3.5 space-y-2 text-xs">
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              Campus Main Gate Security In/Out Verification Log (For Security Desk Use Only)
            </div>
            <div className="grid grid-cols-2 gap-4 text-[11px]">
              <div className="border border-slate-200 p-2 rounded bg-white">
                <span className="font-bold text-slate-700 block">GATE OUT TIME:</span>
                <div className="h-6 border-b border-slate-300 mt-2"></div>
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>Actual Time</span>
                  <span>Security Signature</span>
                </div>
              </div>
              <div className="border border-slate-200 p-2 rounded bg-white">
                <span className="font-bold text-slate-700 block">GATE IN TIME:</span>
                <div className="h-6 border-b border-slate-300 mt-2"></div>
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>Actual Time</span>
                  <span>Security Signature</span>
                </div>
              </div>
            </div>
          </div>

          {/* Official Signatures Row */}
          <div className="pt-6 border-t border-slate-200 grid grid-cols-3 gap-4 text-center text-xs">
            <div>
              <div className="h-10"></div>
              <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
                Student Signature
              </div>
            </div>

            <div>
              <div className="h-10 flex items-end justify-center">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">
                  [DIGITALLY ENDORSED]
                </span>
              </div>
              <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
                Faculty Proctor
              </div>
            </div>

            <div>
              <div className="h-10 flex items-end justify-center">
                <span className="text-[10px] font-mono text-emerald-600 font-bold uppercase tracking-widest">
                  [OFFICIALLY APPROVED]
                </span>
              </div>
              <div className="border-t border-slate-400 pt-1 font-semibold text-slate-800">
                Hostel Warden / Administration
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="text-[10px] text-slate-400 text-center pt-2">
            This document is generated by the EIT Campus Management ERP. Valid only with official digital authorization stamps.
            Must be produced before campus security upon departure and return.
          </div>
        </div>
      </div>
    </div>
  );
}
