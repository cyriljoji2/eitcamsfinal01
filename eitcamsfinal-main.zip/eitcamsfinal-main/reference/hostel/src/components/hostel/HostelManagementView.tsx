import React, { useState } from 'react';
import {
  Building2,
  Layers,
  DoorOpen,
  BedDouble,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Filter,
  Search,
  ChevronRight,
  ShieldAlert,
  Sparkles,
  X,
} from 'lucide-react';
import {
  Hostel,
  HostelBlock,
  HostelFloor,
  HostelRoom,
  HostelBed,
  HostelType,
  HostelCategory,
  HostelStatus,
  RoomType,
  RoomStatus,
  BedStatus,
} from '../../types/hostel';
import { hostelRepository } from '../../services/hostelService';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';

interface HostelManagementViewProps {
  hostels: Hostel[];
  blocks: HostelBlock[];
  floors: HostelFloor[];
  rooms: HostelRoom[];
  beds: HostelBed[];
  onRefresh: () => Promise<void>;
}

type ManagementSubTab = 'hostels' | 'blocks' | 'floors' | 'rooms' | 'beds';

export function HostelManagementView({
  hostels,
  blocks,
  floors,
  rooms,
  beds,
  onRefresh,
}: HostelManagementViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<ManagementSubTab>('hostels');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHostelFilter, setSelectedHostelFilter] = useState<string>('ALL');
  const [selectedBlockFilter, setSelectedBlockFilter] = useState<string>('ALL');
  const [selectedFloorFilter, setSelectedFloorFilter] = useState<string>('ALL');
  const [selectedRoomFilter, setSelectedRoomFilter] = useState<string>('ALL');

  // Modals state
  const [isHostelModalOpen, setIsHostelModalOpen] = useState(false);
  const [editingHostel, setEditingHostel] = useState<Hostel | null>(null);

  const [isBlockModalOpen, setIsBlockModalOpen] = useState(false);
  const [editingBlock, setEditingBlock] = useState<HostelBlock | null>(null);

  const [isFloorModalOpen, setIsFloorModalOpen] = useState(false);
  const [editingFloor, setEditingFloor] = useState<HostelFloor | null>(null);

  const [isRoomModalOpen, setIsRoomModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<HostelRoom | null>(null);

  const [isBedModalOpen, setIsBedModalOpen] = useState(false);
  const [editingBed, setEditingBed] = useState<HostelBed | null>(null);

  // Form states
  const [hostelForm, setHostelForm] = useState({
    hostelName: '',
    hostelCode: '',
    hostelType: 'Boys' as HostelType,
    category: 'Standard' as HostelCategory,
    status: 'active' as HostelStatus,
    address: '',
    description: '',
    wardenName: '',
    wardenContact: '',
  });

  const [blockForm, setBlockForm] = useState({
    hostelId: '',
    blockName: '',
    blockCode: '',
    status: 'active' as HostelStatus,
    description: '',
  });

  const [floorForm, setFloorForm] = useState({
    blockId: '',
    floorNumber: '1',
    floorName: '',
    status: 'active' as HostelStatus,
    description: '',
  });

  const [roomForm, setRoomForm] = useState({
    hostelId: '',
    blockId: '',
    floorId: '',
    roomNumber: '',
    roomType: 'Double' as RoomType,
    capacity: 2,
    status: 'active' as RoomStatus,
    description: '',
  });

  const [bedForm, setBedForm] = useState({
    roomId: '',
    bedNumber: '',
    status: 'AVAILABLE' as BedStatus,
  });

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const clearMessages = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  // ---------------- HOSTEL HANDLERS ----------------
  const openNewHostelModal = () => {
    clearMessages();
    setEditingHostel(null);
    setHostelForm({
      hostelName: '',
      hostelCode: '',
      hostelType: 'Boys',
      category: 'Standard',
      status: 'active',
      address: '',
      description: '',
      wardenName: '',
      wardenContact: '',
    });
    setIsHostelModalOpen(true);
  };

  const openEditHostelModal = (hostel: Hostel) => {
    clearMessages();
    setEditingHostel(hostel);
    setHostelForm({
      hostelName: hostel.hostelName,
      hostelCode: hostel.hostelCode,
      hostelType: hostel.hostelType,
      category: hostel.category,
      status: hostel.status,
      address: hostel.address || '',
      description: hostel.description || '',
      wardenName: hostel.wardenName || '',
      wardenContact: hostel.wardenContact || '',
    });
    setIsHostelModalOpen(true);
  };

  const handleSaveHostel = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!hostelForm.hostelName.trim() || !hostelForm.hostelCode.trim()) {
      setErrorMessage('Please fill in required fields: Hostel Name and Code.');
      return;
    }

    try {
      if (editingHostel) {
        await hostelRepository.updateHostel(editingHostel.id, hostelForm);
        setSuccessMessage(`Hostel ${hostelForm.hostelName} updated successfully.`);
      } else {
        await hostelRepository.createHostel(hostelForm);
        setSuccessMessage(`Hostel ${hostelForm.hostelName} created successfully.`);
      }
      setIsHostelModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save hostel.');
    }
  };

  const handleToggleHostelStatus = async (hostel: Hostel) => {
    clearMessages();
    try {
      await hostelRepository.toggleHostelStatus(hostel.id);
      await onRefresh();
      setSuccessMessage(`Hostel status toggled.`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to toggle status.');
    }
  };

  // ---------------- BLOCK HANDLERS ----------------
  const openNewBlockModal = () => {
    clearMessages();
    setEditingBlock(null);
    setBlockForm({
      hostelId: hostels[0]?.id || '',
      blockName: '',
      blockCode: '',
      status: 'active',
      description: '',
    });
    setIsBlockModalOpen(true);
  };

  const openEditBlockModal = (block: HostelBlock) => {
    clearMessages();
    setEditingBlock(block);
    setBlockForm({
      hostelId: block.hostelId,
      blockName: block.blockName,
      blockCode: block.blockCode,
      status: block.status,
      description: block.description || '',
    });
    setIsBlockModalOpen(true);
  };

  const handleSaveBlock = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!blockForm.hostelId || !blockForm.blockName.trim() || !blockForm.blockCode.trim()) {
      setErrorMessage('Please select a valid parent Hostel, Block Name, and Code.');
      return;
    }

    try {
      if (editingBlock) {
        await hostelRepository.updateBlock(editingBlock.id, blockForm);
        setSuccessMessage(`Block ${blockForm.blockName} updated.`);
      } else {
        await hostelRepository.createBlock(blockForm);
        setSuccessMessage(`Block ${blockForm.blockName} created.`);
      }
      setIsBlockModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save block.');
    }
  };

  const handleDeleteBlock = async (blockId: string) => {
    if (!confirm('Are you sure you want to delete this block? This is only allowed if no floors exist under it.')) return;
    clearMessages();
    try {
      await hostelRepository.deleteBlock(blockId);
      setSuccessMessage('Block deleted successfully.');
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete block.');
    }
  };

  // ---------------- FLOOR HANDLERS ----------------
  const openNewFloorModal = () => {
    clearMessages();
    setEditingFloor(null);
    const defaultBlock = blocks[0]?.id || '';
    setFloorForm({
      blockId: defaultBlock,
      floorNumber: '1',
      floorName: 'First Floor',
      status: 'active',
      description: '',
    });
    setIsFloorModalOpen(true);
  };

  const openEditFloorModal = (floor: HostelFloor) => {
    clearMessages();
    setEditingFloor(floor);
    setFloorForm({
      blockId: floor.blockId,
      floorNumber: String(floor.floorNumber),
      floorName: floor.floorName,
      status: floor.status,
      description: floor.description || '',
    });
    setIsFloorModalOpen(true);
  };

  const handleSaveFloor = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!floorForm.blockId || !floorForm.floorName.trim()) {
      setErrorMessage('Please select a parent Block and Floor Name.');
      return;
    }

    try {
      const parentBlock = blocks.find((b) => b.id === floorForm.blockId);
      if (!parentBlock) {
        setErrorMessage('Parent block not found.');
        return;
      }
      if (editingFloor) {
        await hostelRepository.updateFloor(editingFloor.id, {
          ...floorForm,
          floorNumber: String(floorForm.floorNumber),
        });
        setSuccessMessage(`Floor ${floorForm.floorName} updated.`);
      } else {
        await hostelRepository.createFloor({
          ...floorForm,
          hostelId: parentBlock.hostelId,
          floorNumber: String(floorForm.floorNumber),
        });
        setSuccessMessage(`Floor ${floorForm.floorName} created.`);
      }
      setIsFloorModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save floor.');
    }
  };

  const handleDeleteFloor = async (floorId: string) => {
    if (!confirm('Are you sure you want to delete this floor? Only allowed if no rooms exist.')) return;
    clearMessages();
    try {
      await hostelRepository.deleteFloor(floorId);
      setSuccessMessage('Floor deleted successfully.');
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete floor.');
    }
  };

  // ---------------- ROOM HANDLERS ----------------
  const openNewRoomModal = () => {
    clearMessages();
    setEditingRoom(null);
    const defaultHostel = hostels[0]?.id || '';
    const relevantBlocks = blocks.filter((b) => b.hostelId === defaultHostel);
    const defaultBlock = relevantBlocks[0]?.id || blocks[0]?.id || '';
    const relevantFloors = floors.filter((f) => f.blockId === defaultBlock);
    const defaultFloor = relevantFloors[0]?.id || floors[0]?.id || '';

    setRoomForm({
      hostelId: defaultHostel,
      blockId: defaultBlock,
      floorId: defaultFloor,
      roomNumber: '',
      roomType: 'Double',
      capacity: 2,
      status: 'active',
      description: '',
    });
    setIsRoomModalOpen(true);
  };

  const openEditRoomModal = (room: HostelRoom) => {
    clearMessages();
    setEditingRoom(room);
    setRoomForm({
      hostelId: room.hostelId,
      blockId: room.blockId,
      floorId: room.floorId,
      roomNumber: room.roomNumber,
      roomType: room.roomType,
      capacity: room.capacity,
      status: room.status,
      description: room.description || '',
    });
    setIsRoomModalOpen(true);
  };

  const handleSaveRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!roomForm.floorId || !roomForm.roomNumber.trim()) {
      setErrorMessage('Please specify Floor and Room Number.');
      return;
    }
    if (roomForm.capacity <= 0) {
      setErrorMessage('Room capacity must be greater than 0.');
      return;
    }

    try {
      if (editingRoom) {
        await hostelRepository.updateRoom(editingRoom.id, {
          roomNumber: roomForm.roomNumber,
          roomType: roomForm.roomType,
          capacity: Number(roomForm.capacity),
          status: roomForm.status,
          description: roomForm.description,
        });
        setSuccessMessage(`Room ${roomForm.roomNumber} updated.`);
      } else {
        await hostelRepository.createRoom({
          hostelId: roomForm.hostelId,
          blockId: roomForm.blockId,
          floorId: roomForm.floorId,
          roomNumber: roomForm.roomNumber,
          roomType: roomForm.roomType,
          capacity: Number(roomForm.capacity),
          status: roomForm.status,
          description: roomForm.description,
        });
        setSuccessMessage(`Room ${roomForm.roomNumber} created.`);
      }
      setIsRoomModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save room.');
    }
  };

  const handleDeleteRoom = async (roomId: string) => {
    if (!confirm('Are you sure you want to delete this room? Only allowed if no beds or active allotments exist.')) return;
    clearMessages();
    try {
      await hostelRepository.deleteRoom(roomId);
      setSuccessMessage('Room deleted successfully.');
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete room.');
    }
  };

  // ---------------- BED HANDLERS ----------------
  const openNewBedModal = (defaultRoomId?: string) => {
    clearMessages();
    setEditingBed(null);
    setBedForm({
      roomId: defaultRoomId || rooms[0]?.id || '',
      bedNumber: '',
      status: 'AVAILABLE',
    });
    setIsBedModalOpen(true);
  };

  const handleSaveBed = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!bedForm.roomId || !bedForm.bedNumber.trim()) {
      setErrorMessage('Please select a Room and enter a Bed Identifier.');
      return;
    }

    try {
      if (editingBed) {
        await hostelRepository.updateBed(editingBed.id, {
          bedNumber: bedForm.bedNumber,
          status: bedForm.status,
        });
        setSuccessMessage(`Bed ${bedForm.bedNumber} updated.`);
      } else {
        await hostelRepository.createBed({
          roomId: bedForm.roomId,
          bedNumber: bedForm.bedNumber,
          status: bedForm.status,
        });
        setSuccessMessage(`Bed ${bedForm.bedNumber} created.`);
      }
      setIsBedModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save bed.');
    }
  };

  const handleToggleBedBlocked = async (bed: HostelBed) => {
    clearMessages();
    if (bed.status === 'OCCUPIED') {
      setErrorMessage('Cannot block an occupied bed. Vacate or transfer the student first.');
      return;
    }
    const nextStatus: BedStatus = bed.status === 'BLOCKED' ? 'AVAILABLE' : 'BLOCKED';
    try {
      await hostelRepository.updateBed(bed.id, { status: nextStatus });
      setSuccessMessage(`Bed ${bed.bedNumber} is now ${nextStatus.toLowerCase()}.`);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to toggle bed status.');
    }
  };

  const handleDeleteBed = async (bedId: string) => {
    if (!confirm('Are you sure you want to delete this bed? Only allowed if not occupied.')) return;
    clearMessages();
    try {
      await hostelRepository.deleteBed(bedId);
      setSuccessMessage('Bed deleted successfully.');
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete bed.');
    }
  };

  // Helper Lookups
  const getHostelName = (id: string) => hostels.find((h) => h.id === id)?.hostelName || id;
  const getBlockName = (id: string) => blocks.find((b) => b.id === id)?.blockName || id;
  const getFloorName = (id: string) => {
    const f = floors.find((fl) => fl.id === id);
    return f ? `${f.floorName} (Fl ${f.floorNumber})` : id;
  };
  const getRoomNumber = (id: string) => rooms.find((r) => r.id === id)?.roomNumber || id;

  // Filtered lists
  const filteredHostels = hostels.filter(
    (h) =>
      h.hostelName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.hostelCode.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredBlocks = blocks.filter((b) => {
    const matchesHostel = selectedHostelFilter === 'ALL' || b.hostelId === selectedHostelFilter;
    const matchesQuery =
      b.blockName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.blockCode.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesHostel && matchesQuery;
  });

  const filteredFloors = floors.filter((f) => {
    const parentBlock = blocks.find((b) => b.id === f.blockId);
    const matchesHostel =
      selectedHostelFilter === 'ALL' || parentBlock?.hostelId === selectedHostelFilter;
    const matchesBlock = selectedBlockFilter === 'ALL' || f.blockId === selectedBlockFilter;
    const matchesQuery =
      f.floorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(f.floorNumber).includes(searchQuery);
    return matchesHostel && matchesBlock && matchesQuery;
  });

  const filteredRooms = rooms.filter((r) => {
    const matchesHostel = selectedHostelFilter === 'ALL' || r.hostelId === selectedHostelFilter;
    const matchesBlock = selectedBlockFilter === 'ALL' || r.blockId === selectedBlockFilter;
    const matchesFloor = selectedFloorFilter === 'ALL' || r.floorId === selectedFloorFilter;
    const matchesQuery = r.roomNumber.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesHostel && matchesBlock && matchesFloor && matchesQuery;
  });

  const filteredBeds = beds.filter((b) => {
    const room = rooms.find((r) => r.id === b.roomId);
    const matchesHostel = selectedHostelFilter === 'ALL' || room?.hostelId === selectedHostelFilter;
    const matchesBlock = selectedBlockFilter === 'ALL' || room?.blockId === selectedBlockFilter;
    const matchesFloor = selectedFloorFilter === 'ALL' || room?.floorId === selectedFloorFilter;
    const matchesRoom = selectedRoomFilter === 'ALL' || b.roomId === selectedRoomFilter;
    const matchesQuery =
      b.bedNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (room?.roomNumber || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesHostel && matchesBlock && matchesFloor && matchesRoom && matchesQuery;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Tab Controls */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-[#1e293b]">
              Hostel Infrastructure & Room Hierarchy
            </h2>
            <p className="text-xs text-[#64748b] mt-0.5">
              Configure Residential Halls, Wings/Blocks, Floor Plans, Dorm Rooms, and Bed Inventories.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {activeSubTab === 'hostels' && (
              <Button
                variant="primary"
                size="sm"
                onClick={openNewHostelModal}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Add Hostel
              </Button>
            )}
            {activeSubTab === 'blocks' && (
              <Button
                variant="primary"
                size="sm"
                onClick={openNewBlockModal}
                disabled={hostels.length === 0}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Add Block
              </Button>
            )}
            {activeSubTab === 'floors' && (
              <Button
                variant="primary"
                size="sm"
                onClick={openNewFloorModal}
                disabled={blocks.length === 0}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Add Floor
              </Button>
            )}
            {activeSubTab === 'rooms' && (
              <Button
                variant="primary"
                size="sm"
                onClick={openNewRoomModal}
                disabled={floors.length === 0}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Add Room
              </Button>
            )}
            {activeSubTab === 'beds' && (
              <Button
                variant="primary"
                size="sm"
                onClick={() => openNewBedModal()}
                disabled={rooms.length === 0}
                leftIcon={<Plus className="w-4 h-4" />}
              >
                Add Bed / Seat
              </Button>
            )}
          </div>
        </div>

        {/* Sub-tab Pill Navigation */}
        <div className="flex items-center gap-2 border-t border-[#e2e8f0] mt-5 pt-4 overflow-x-auto">
          <button
            onClick={() => setActiveSubTab('hostels')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'hostels'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'bg-[#f8fafc] text-[#64748b] hover:bg-[#f1f5f9]'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Hostels ({hostels.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('blocks')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'blocks'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'bg-[#f8fafc] text-[#64748b] hover:bg-[#f1f5f9]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Blocks ({blocks.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('floors')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'floors'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'bg-[#f8fafc] text-[#64748b] hover:bg-[#f1f5f9]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Floors ({floors.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('rooms')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'rooms'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'bg-[#f8fafc] text-[#64748b] hover:bg-[#f1f5f9]'
            }`}
          >
            <DoorOpen className="w-3.5 h-3.5" />
            <span>Rooms ({rooms.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('beds')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'beds'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'bg-[#f8fafc] text-[#64748b] hover:bg-[#f1f5f9]'
            }`}
          >
            <BedDouble className="w-3.5 h-3.5" />
            <span>Beds / Seats ({beds.length})</span>
          </button>
        </div>
      </div>

      {/* Status Messages */}
      {errorMessage && (
        <Alert
          type="error"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}
      {successMessage && (
        <Alert
          type="success"
          message={successMessage}
          onDismiss={() => setSuccessMessage(null)}
        />
      )}

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={`Search ${activeSubTab}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto">
          {activeSubTab !== 'hostels' && (
            <select
              value={selectedHostelFilter}
              onChange={(e) => {
                setSelectedHostelFilter(e.target.value);
                setSelectedBlockFilter('ALL');
                setSelectedFloorFilter('ALL');
                setSelectedRoomFilter('ALL');
              }}
              className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
            >
              <option value="ALL">All Hostels</option>
              {hostels.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.hostelName} ({h.hostelCode})
                </option>
              ))}
            </select>
          )}

          {(activeSubTab === 'floors' || activeSubTab === 'rooms' || activeSubTab === 'beds') && (
            <select
              value={selectedBlockFilter}
              onChange={(e) => {
                setSelectedBlockFilter(e.target.value);
                setSelectedFloorFilter('ALL');
                setSelectedRoomFilter('ALL');
              }}
              className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
            >
              <option value="ALL">All Blocks</option>
              {blocks
                .filter(
                  (b) => selectedHostelFilter === 'ALL' || b.hostelId === selectedHostelFilter
                )
                .map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.blockName} ({b.blockCode})
                  </option>
                ))}
            </select>
          )}

          {(activeSubTab === 'rooms' || activeSubTab === 'beds') && (
            <select
              value={selectedFloorFilter}
              onChange={(e) => {
                setSelectedFloorFilter(e.target.value);
                setSelectedRoomFilter('ALL');
              }}
              className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
            >
              <option value="ALL">All Floors</option>
              {floors
                .filter((f) => {
                  const b = blocks.find((blk) => blk.id === f.blockId);
                  const matchesH = selectedHostelFilter === 'ALL' || b?.hostelId === selectedHostelFilter;
                  const matchesB = selectedBlockFilter === 'ALL' || f.blockId === selectedBlockFilter;
                  return matchesH && matchesB;
                })
                .map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.floorName} (Floor {f.floorNumber})
                  </option>
                ))}
            </select>
          )}

          {activeSubTab === 'beds' && (
            <select
              value={selectedRoomFilter}
              onChange={(e) => setSelectedRoomFilter(e.target.value)}
              className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
            >
              <option value="ALL">All Rooms</option>
              {rooms
                .filter((r) => {
                  const matchesH = selectedHostelFilter === 'ALL' || r.hostelId === selectedHostelFilter;
                  const matchesB = selectedBlockFilter === 'ALL' || r.blockId === selectedBlockFilter;
                  const matchesF = selectedFloorFilter === 'ALL' || r.floorId === selectedFloorFilter;
                  return matchesH && matchesB && matchesF;
                })
                .map((r) => (
                  <option key={r.id} value={r.id}>
                    Room {r.roomNumber}
                  </option>
                ))}
            </select>
          )}
        </div>
      </div>

      {/* ----------------- SUB-TAB: HOSTELS ----------------- */}
      {activeSubTab === 'hostels' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Hostel Code & Name</th>
                  <th className="py-3 px-4 font-semibold">Category & Type</th>
                  <th className="py-3 px-4 font-semibold">Chief Warden</th>
                  <th className="py-3 px-4 font-semibold">Contact / Address</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredHostels.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#64748b]">
                      No hostels found. Click &quot;Add Hostel&quot; to configure your first hall.
                    </td>
                  </tr>
                ) : (
                  filteredHostels.map((h) => (
                    <tr key={h.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-[#1e293b]">{h.hostelName}</span>
                          <span className="text-[10px] text-[#64748b] font-mono">{h.hostelCode}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <Badge
                            variant={
                              h.hostelType === 'Boys' ? 'blue' : h.hostelType === 'Girls' ? 'purple' : 'neutral'
                            }
                            size="sm"
                          >
                            {h.hostelType}
                          </Badge>
                          <span className="text-[11px] text-[#475569] font-medium capitalize">
                            {h.category}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-[#334155]">{h.wardenName || '—'}</td>
                      <td className="py-3 px-4 text-[#64748b]">
                        <div className="text-[11px]">
                          <div>{h.wardenContact || '—'}</div>
                          {h.address && (
                            <div className="text-[10px] text-[#94a3b8] truncate max-w-xs">
                              {h.address}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={h.status === 'active' ? 'emerald' : 'rose'} size="sm">
                          {h.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditHostelModal(h)}
                            leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleHostelStatus(h)}
                          >
                            {h.status === 'active' ? 'Deactivate' : 'Activate'}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- SUB-TAB: BLOCKS ----------------- */}
      {activeSubTab === 'blocks' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Block Code & Name</th>
                  <th className="py-3 px-4 font-semibold">Parent Hostel</th>
                  <th className="py-3 px-4 font-semibold">Description</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredBlocks.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#64748b]">
                      No blocks found. Click &quot;Add Block&quot; to define building wings.
                    </td>
                  </tr>
                ) : (
                  filteredBlocks.map((b) => (
                    <tr key={b.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-[#1e293b]">{b.blockName}</span>
                          <span className="text-[10px] text-[#64748b] font-mono">{b.blockCode}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-medium text-[#1e3a8a]">
                        {getHostelName(b.hostelId)}
                      </td>
                      <td className="py-3 px-4 text-[#64748b]">{b.description || '—'}</td>
                      <td className="py-3 px-4">
                        <Badge variant={b.status === 'active' ? 'emerald' : 'rose'} size="sm">
                          {b.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditBlockModal(b)}
                            leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => handleDeleteBlock(b.id)}
                            leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                          >
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- SUB-TAB: FLOORS ----------------- */}
      {activeSubTab === 'floors' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Floor Designation</th>
                  <th className="py-3 px-4 font-semibold">Floor Number</th>
                  <th className="py-3 px-4 font-semibold">Parent Block & Hostel</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredFloors.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#64748b]">
                      No floors found. Click &quot;Add Floor&quot; to configure floor levels.
                    </td>
                  </tr>
                ) : (
                  filteredFloors.map((f) => {
                    const blk = blocks.find((b) => b.id === f.blockId);
                    return (
                      <tr key={f.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4 font-bold text-[#1e293b]">{f.floorName}</td>
                        <td className="py-3 px-4 font-mono text-[#334155]">Level {f.floorNumber}</td>
                        <td className="py-3 px-4">
                          <span className="font-medium text-[#1e3a8a]">{blk?.blockName || f.blockId}</span>{' '}
                          <span className="text-[#94a3b8]">in</span>{' '}
                          <span className="text-[#475569]">
                            {blk ? getHostelName(blk.hostelId) : ''}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={f.status === 'active' ? 'emerald' : 'rose'} size="sm">
                            {f.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditFloorModal(f)}
                              leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => handleDeleteFloor(f.id)}
                              leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                            >
                              Delete
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- SUB-TAB: ROOMS ----------------- */}
      {activeSubTab === 'rooms' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Room Number</th>
                  <th className="py-3 px-4 font-semibold">Location</th>
                  <th className="py-3 px-4 font-semibold">Type</th>
                  <th className="py-3 px-4 font-semibold">Capacity & Beds</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredRooms.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#64748b]">
                      No rooms found. Click &quot;Add Room&quot; to configure dorm units.
                    </td>
                  </tr>
                ) : (
                  filteredRooms.map((r) => {
                    const roomBeds = beds.filter((b) => b.roomId === r.id);
                    const occupiedBeds = roomBeds.filter((b) => b.status === 'OCCUPIED');
                    return (
                      <tr key={r.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4">
                          <span className="font-bold text-[#1e293b] text-sm">{r.roomNumber}</span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-[11px] text-[#475569]">
                            <div>{getHostelName(r.hostelId)}</div>
                            <div className="text-[10px] text-[#64748b]">
                              {getBlockName(r.blockId)} &bull; {getFloorName(r.floorId)}
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-medium text-[#334155]">{r.roomType}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#1e293b]">
                              {roomBeds.length} / {r.capacity} Beds
                            </span>
                            <Badge
                              variant={
                                occupiedBeds.length >= r.capacity
                                  ? 'rose'
                                  : occupiedBeds.length > 0
                                  ? 'amber'
                                  : 'emerald'
                              }
                              size="sm"
                            >
                              {occupiedBeds.length} Occ
                            </Badge>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={r.status === 'active' ? 'emerald' : 'rose'} size="sm">
                            {r.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setActiveSubTab('beds');
                                setSelectedRoomFilter(r.id);
                              }}
                            >
                              Manage Beds
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditRoomModal(r)}
                              leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => handleDeleteRoom(r.id)}
                              leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                            >
                              Delete
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- SUB-TAB: BEDS ----------------- */}
      {activeSubTab === 'beds' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Bed / Seat</th>
                  <th className="py-3 px-4 font-semibold">Room & Floor</th>
                  <th className="py-3 px-4 font-semibold">Block & Hostel</th>
                  <th className="py-3 px-4 font-semibold">Current Bed Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredBeds.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#64748b]">
                      No beds found. Click &quot;Add Bed / Seat&quot; to assign beds to rooms.
                    </td>
                  </tr>
                ) : (
                  filteredBeds.map((b) => {
                    const room = rooms.find((r) => r.id === b.roomId);
                    return (
                      <tr key={b.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4">
                          <span className="font-bold text-[#1e293b] text-sm">Bed {b.bedNumber}</span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-semibold text-[#1e3a8a]">
                            Room {room ? room.roomNumber : b.roomId}
                          </span>
                          <span className="text-[#64748b] text-[10px] block">
                            {room ? getFloorName(room.floorId) : ''}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-[#475569]">
                            {room ? getHostelName(room.hostelId) : ''}
                          </span>
                          <span className="text-[#94a3b8] text-[10px] block">
                            {room ? getBlockName(room.blockId) : ''}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge
                            variant={
                              b.status === 'AVAILABLE'
                                ? 'blue'
                                : b.status === 'OCCUPIED'
                                ? 'emerald'
                                : 'amber'
                            }
                            size="sm"
                          >
                            {b.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {b.status !== 'OCCUPIED' && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleToggleBedBlocked(b)}
                              >
                                {b.status === 'BLOCKED' ? 'Unblock' : 'Block Bed'}
                              </Button>
                            )}
                            <Button
                              variant="danger"
                              size="sm"
                              disabled={b.status === 'OCCUPIED'}
                              onClick={() => handleDeleteBed(b.id)}
                              leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                            >
                              Delete
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- HOSTEL MODAL ----------------- */}
      {isHostelModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                {editingHostel ? 'Edit Residential Hostel' : 'Add New Residential Hostel'}
              </h3>
              <button
                onClick={() => setIsHostelModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveHostel} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Hostel Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramanujan Hall"
                    value={hostelForm.hostelName}
                    onChange={(e) => setHostelForm({ ...hostelForm, hostelName: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Hostel Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. H-01"
                    value={hostelForm.hostelCode}
                    onChange={(e) => setHostelForm({ ...hostelForm, hostelCode: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Hostel Type</label>
                  <select
                    value={hostelForm.hostelType}
                    onChange={(e) =>
                      setHostelForm({ ...hostelForm, hostelType: e.target.value as HostelType })
                    }
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    <option value="Boys">Boys Hostel</option>
                    <option value="Girls">Girls Hostel</option>
                    <option value="Co-ed">Co-ed Residence</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Category</label>
                  <select
                    value={hostelForm.category}
                    onChange={(e) =>
                      setHostelForm({ ...hostelForm, category: e.target.value as HostelCategory })
                    }
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    <option value="Standard">Standard</option>
                    <option value="Deluxe">Deluxe</option>
                    <option value="AC">Air Conditioned (AC)</option>
                    <option value="Premium">Premium Executive</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Chief Warden Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Dr. A. Sharma"
                    value={hostelForm.wardenName}
                    onChange={(e) => setHostelForm({ ...hostelForm, wardenName: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Warden Contact</label>
                  <input
                    type="text"
                    placeholder="Phone or extension"
                    value={hostelForm.wardenContact}
                    onChange={(e) => setHostelForm({ ...hostelForm, wardenContact: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">Campus Address / Location</label>
                <input
                  type="text"
                  placeholder="e.g. North Campus Sector 2"
                  value={hostelForm.address}
                  onChange={(e) => setHostelForm({ ...hostelForm, address: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsHostelModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  {editingHostel ? 'Update Hostel' : 'Create Hostel'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- BLOCK MODAL ----------------- */}
      {isBlockModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                {editingBlock ? 'Edit Building Block' : 'Add New Building Block'}
              </h3>
              <button
                onClick={() => setIsBlockModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBlock} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-[#475569] mb-1">Parent Hostel *</label>
                <select
                  value={blockForm.hostelId}
                  onChange={(e) => setBlockForm({ ...blockForm, hostelId: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                >
                  {hostels.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.hostelName} ({h.hostelCode})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Block Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Block A"
                    value={blockForm.blockName}
                    onChange={(e) => setBlockForm({ ...blockForm, blockName: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Block Code *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. BLK-A"
                    value={blockForm.blockCode}
                    onChange={(e) => setBlockForm({ ...blockForm, blockCode: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">Description / Notes</label>
                <input
                  type="text"
                  placeholder="e.g. East Wing facing garden"
                  value={blockForm.description}
                  onChange={(e) => setBlockForm({ ...blockForm, description: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsBlockModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  {editingBlock ? 'Update Block' : 'Create Block'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- FLOOR MODAL ----------------- */}
      {isFloorModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                {editingFloor ? 'Edit Floor' : 'Add New Floor'}
              </h3>
              <button
                onClick={() => setIsFloorModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFloor} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-[#475569] mb-1">Parent Block *</label>
                <select
                  value={floorForm.blockId}
                  onChange={(e) => setFloorForm({ ...floorForm, blockId: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                >
                  {blocks.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.blockName} ({getHostelName(b.hostelId)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Floor Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 1, 2, G"
                    value={floorForm.floorNumber}
                    onChange={(e) =>
                      setFloorForm({ ...floorForm, floorNumber: e.target.value })
                    }
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Floor Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ground Floor, 1st Floor"
                    value={floorForm.floorName}
                    onChange={(e) => setFloorForm({ ...floorForm, floorName: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsFloorModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  {editingFloor ? 'Update Floor' : 'Create Floor'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- ROOM MODAL ----------------- */}
      {isRoomModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                {editingRoom ? 'Edit Room Configuration' : 'Add New Dorm Room'}
              </h3>
              <button
                onClick={() => setIsRoomModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveRoom} className="space-y-4 text-xs">
              {!editingRoom && (
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block font-medium text-[#475569] mb-1">Hostel *</label>
                    <select
                      value={roomForm.hostelId}
                      onChange={(e) => {
                        const hId = e.target.value;
                        const blks = blocks.filter((b) => b.hostelId === hId);
                        const bId = blks[0]?.id || '';
                        const flrs = floors.filter((f) => f.blockId === bId);
                        setRoomForm({
                          ...roomForm,
                          hostelId: hId,
                          blockId: bId,
                          floorId: flrs[0]?.id || '',
                        });
                      }}
                      className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                    >
                      {hostels.map((h) => (
                        <option key={h.id} value={h.id}>
                          {h.hostelName}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-[#475569] mb-1">Block *</label>
                    <select
                      value={roomForm.blockId}
                      onChange={(e) => {
                        const bId = e.target.value;
                        const flrs = floors.filter((f) => f.blockId === bId);
                        setRoomForm({
                          ...roomForm,
                          blockId: bId,
                          floorId: flrs[0]?.id || '',
                        });
                      }}
                      className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                    >
                      {blocks
                        .filter((b) => b.hostelId === roomForm.hostelId)
                        .map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.blockName}
                          </option>
                        ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-[#475569] mb-1">Floor *</label>
                    <select
                      value={roomForm.floorId}
                      onChange={(e) => setRoomForm({ ...roomForm, floorId: e.target.value })}
                      className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                    >
                      {floors
                        .filter((f) => f.blockId === roomForm.blockId)
                        .map((f) => (
                          <option key={f.id} value={f.id}>
                            {f.floorName}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Room Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 101"
                    value={roomForm.roomNumber}
                    onChange={(e) => setRoomForm({ ...roomForm, roomNumber: e.target.value })}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">Room Type</label>
                  <select
                    value={roomForm.roomType}
                    onChange={(e) =>
                      setRoomForm({ ...roomForm, roomType: e.target.value as RoomType })
                    }
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    <option value="Single">Single (1 Bed)</option>
                    <option value="Double">Double (2 Beds)</option>
                    <option value="Triple">Triple (3 Beds)</option>
                    <option value="Four Bed">Four Bed (4 Beds)</option>
                    <option value="Dormitory">Dormitory</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">
                    Configured Capacity *
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    required
                    value={roomForm.capacity}
                    onChange={(e) =>
                      setRoomForm({ ...roomForm, capacity: parseInt(e.target.value) || 1 })
                    }
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">Description / Amenities</label>
                <input
                  type="text"
                  placeholder="e.g. Balcony attached, corner room"
                  value={roomForm.description}
                  onChange={(e) => setRoomForm({ ...roomForm, description: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsRoomModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  {editingRoom ? 'Update Room' : 'Create Room'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- BED MODAL ----------------- */}
      {isBedModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                {editingBed ? 'Edit Bed' : 'Add Bed / Seat to Room'}
              </h3>
              <button
                onClick={() => setIsBedModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBed} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-[#475569] mb-1">Target Room *</label>
                <select
                  value={bedForm.roomId}
                  onChange={(e) => setBedForm({ ...bedForm, roomId: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                >
                  {rooms.map((r) => {
                    const existingCount = beds.filter((b) => b.roomId === r.id).length;
                    return (
                      <option key={r.id} value={r.id}>
                        Room {r.roomNumber} ({getHostelName(r.hostelId)}) — {existingCount}/
                        {r.capacity} beds
                      </option>
                    );
                  })}
                </select>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">
                  Bed Identifier / Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bed-A, Bed-1, Upper-Left"
                  value={bedForm.bedNumber}
                  onChange={(e) => setBedForm({ ...bedForm, bedNumber: e.target.value })}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">Initial Status</label>
                <select
                  value={bedForm.status}
                  onChange={(e) =>
                    setBedForm({ ...bedForm, status: e.target.value as BedStatus })
                  }
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                >
                  <option value="AVAILABLE">AVAILABLE (Ready for allotment)</option>
                  <option value="BLOCKED">BLOCKED (Maintenance / Reservation)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsBedModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  {editingBed ? 'Update Bed' : 'Create Bed'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
