import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Building2,
  Users,
  FileText,
  DoorOpen,
  BedDouble,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import {
  Hostel,
  HostelBlock,
  HostelFloor,
  HostelRoom,
  HostelBed,
  HostelAllotment,
  HostelAllotmentHistory,
  HostelDashboardMetrics,
} from '../../types/hostel';
import { Student } from '../../types/admission';
import { hostelRepository } from '../../services/hostelService';
import { admissionRepository } from '../../services/admissionService';

import { HostelHeader } from './HostelHeader';
import { HostelDashboardView } from './HostelDashboardView';
import { HostelManagementView } from './HostelManagementView';
import { StudentHostelDirectoryView } from './StudentHostelDirectoryView';
import { HostelReportsView } from './HostelReportsView';
import { HostelLeaveOutingView } from './HostelLeaveOutingView';

interface HostelWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export type HostelTab = 'dashboard' | 'management' | 'students' | 'leave-outing' | 'reports';

export function HostelWorkspace({ user, onLogout }: HostelWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<HostelTab>('dashboard');
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  // Hostel Domain State
  const [hostels, setHostels] = useState<Hostel[]>([]);
  const [blocks, setBlocks] = useState<HostelBlock[]>([]);
  const [floors, setFloors] = useState<HostelFloor[]>([]);
  const [rooms, setRooms] = useState<HostelRoom[]>([]);
  const [beds, setBeds] = useState<HostelBed[]>([]);
  const [allotments, setAllotments] = useState<HostelAllotment[]>([]);
  const [allotmentHistory, setAllotmentHistory] = useState<HostelAllotmentHistory[]>([]);
  const [metrics, setMetrics] = useState<HostelDashboardMetrics>({
    totalHostels: 0,
    totalBlocks: 0,
    totalFloors: 0,
    totalRooms: 0,
    totalBeds: 0,
    occupiedBeds: 0,
    availableBeds: 0,
    blockedBeds: 0,
    occupancyPercentage: 0,
    studentsCurrentlyAllotted: 0,
  });

  // Students from Admission Repository
  const [students, setStudents] = useState<Student[]>([]);

  // Load all data
  const loadData = useCallback(async () => {
    try {
      const [hList, bList, fList, rList, bedList, altList, histList, metricData, studentList] =
        await Promise.all([
          hostelRepository.getAllHostels(),
          hostelRepository.getAllBlocks(),
          hostelRepository.getAllFloors(),
          hostelRepository.getAllRooms(),
          hostelRepository.getAllBeds(),
          hostelRepository.getAllAllotments(),
          hostelRepository.getAllotmentHistory(),
          hostelRepository.getDashboardMetrics(),
          admissionRepository.getStudents(),
        ]);

      setHostels(hList);
      setBlocks(bList);
      setFloors(fList);
      setRooms(rList);
      setBeds(bedList);
      setAllotments(altList);
      setAllotmentHistory(histList);
      setMetrics(metricData);
      setStudents(studentList);
    } catch (err) {
      console.error('Failed to load hostel workspace data:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load and subscription
  useEffect(() => {
    loadData();

    // Subscribe to real-time changes
    const unsubscribe = hostelRepository.subscribe(() => {
      loadData();
    });

    return () => {
      unsubscribe();
    };
  }, [loadData]);

  // Explicit sync handler
  const handleSync = async () => {
    setIsSyncing(true);
    try {
      await hostelRepository.sync();
      await loadData();
    } finally {
      setIsSyncing(false);
    }
  };

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Occupancy overview & real-time analytics',
    },
    {
      id: 'management',
      label: 'Hostel Management',
      icon: Building2,
      description: 'Hostels, blocks, floors, rooms & beds',
    },
    {
      id: 'students',
      label: 'Student Hostel',
      icon: Users,
      description: 'Student directory, allotments & transfers',
    },
    {
      id: 'leave-outing',
      label: 'Leave & Outing',
      icon: DoorOpen,
      description: 'Leave requests, proctor endorsements & gate clearance',
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: FileText,
      description: 'Occupancy registers, logs & exports',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-[#1e293b] font-sans antialiased">
      {/* Workspace Header */}
      <HostelHeader
        user={user}
        onLogout={onLogout}
        onRefresh={handleSync}
        isSyncing={isSyncing}
      />

      {/* Main Container */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-1.5 flex items-center gap-1 overflow-x-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`hostel-nav-${item.id}`}
                onClick={() => setActiveTab(item.id as HostelTab)}
                className={`flex-1 min-w-[140px] py-2.5 px-3.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#1e3a8a] text-white shadow-xs'
                    : 'text-[#64748b] hover:bg-[#f1f5f9] hover:text-[#1e293b]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#64748b]'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Rendering */}
        {isLoading ? (
          <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-3">
            <div className="w-8 h-8 border-2 border-[#1e3a8a] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-[#64748b]">Loading Hostel Office Workspace...</p>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <HostelDashboardView
                metrics={metrics}
                hostels={hostels}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'management' && (
              <HostelManagementView
                hostels={hostels}
                blocks={blocks}
                floors={floors}
                rooms={rooms}
                beds={beds}
                onRefresh={loadData}
              />
            )}

            {activeTab === 'students' && (
              <StudentHostelDirectoryView
                students={students}
                hostels={hostels}
                blocks={blocks}
                floors={floors}
                rooms={rooms}
                beds={beds}
                allotments={allotments}
                allotmentHistory={allotmentHistory}
                currentUser={{ name: user.name, username: user.username }}
                onRefresh={loadData}
              />
            )}

            {activeTab === 'leave-outing' && (
              <HostelLeaveOutingView
                currentUser={{ id: user.id, name: user.name, username: user.username }}
              />
            )}

            {activeTab === 'reports' && (
              <HostelReportsView
                hostels={hostels}
                blocks={blocks}
                floors={floors}
                rooms={rooms}
                beds={beds}
                allotments={allotments}
                allotmentHistory={allotmentHistory}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
}
