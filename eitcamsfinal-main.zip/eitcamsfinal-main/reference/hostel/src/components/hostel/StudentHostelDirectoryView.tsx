import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Home,
  BedDouble,
  ArrowRightLeft,
  LogOut,
  History,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  Building2,
  DoorOpen,
  X,
  ShieldAlert,
} from 'lucide-react';
import { Student } from '../../types/admission';
import {
  Hostel,
  HostelBlock,
  HostelFloor,
  HostelRoom,
  HostelBed,
  HostelAllotment,
  HostelAllotmentHistory,
} from '../../types/hostel';
import { hostelRepository } from '../../services/hostelService';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';

interface StudentHostelDirectoryViewProps {
  students: Student[];
  hostels: Hostel[];
  blocks: HostelBlock[];
  floors: HostelFloor[];
  rooms: HostelRoom[];
  beds: HostelBed[];
  allotments: HostelAllotment[];
  allotmentHistory: HostelAllotmentHistory[];
  currentUser: { name: string; username: string };
  onRefresh: () => Promise<void>;
}

type AllotmentFilter = 'ALL' | 'ALLOTTED' | 'NOT_ALLOTTED';

export function StudentHostelDirectoryView({
  students,
  hostels,
  blocks,
  floors,
  rooms,
  beds,
  allotments,
  allotmentHistory,
  currentUser,
  onRefresh,
}: StudentHostelDirectoryViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [allotmentFilter, setAllotmentFilter] = useState<AllotmentFilter>('ALL');
  const [hostelFilter, setHostelFilter] = useState<string>('ALL');
  const [programFilter, setProgramFilter] = useState<string>('ALL');

  // Modal States
  const [isAllotModalOpen, setIsAllotModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isVacateModalOpen, setIsVacateModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);

  // Selected Student
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [activeAllotmentForSelected, setActiveAllotmentForSelected] =
    useState<HostelAllotment | null>(null);

  // Allotment Form State
  const [selectedHostelId, setSelectedHostelId] = useState<string>('');
  const [selectedBlockId, setSelectedBlockId] = useState<string>('');
  const [selectedFloorId, setSelectedFloorId] = useState<string>('');
  const [selectedRoomId, setSelectedRoomId] = useState<string>('');
  const [selectedBedId, setSelectedBedId] = useState<string>('');
  const [academicSession, setAcademicSession] = useState('2026–2027');
  const [actionReason, setActionReason] = useState('');

  // Status message
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const clearMessages = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  // Map of active allotments by studentId (or registrationNumber)
  const activeAllotmentsMap = useMemo(() => {
    const map = new Map<string, HostelAllotment>();
    for (const alt of allotments) {
      if (alt.status === 'active') {
        map.set(alt.studentId, alt);
        if (alt.studentRegistrationNumber) {
          map.set(alt.studentRegistrationNumber, alt);
        }
      }
    }
    return map;
  }, [allotments]);

  // Unique programs for filter dropdown
  const uniquePrograms = useMemo(() => {
    const set = new Set<string>();
    for (const s of students) {
      const prog = s.program || s.admissionClass;
      if (prog) set.add(prog);
    }
    return Array.from(set).sort();
  }, [students]);

  // Filtered Students list
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const activeAlt =
        activeAllotmentsMap.get(s.id) || activeAllotmentsMap.get(s.registrationNumber);
      const isAllotted = !!activeAlt;

      if (allotmentFilter === 'ALLOTTED' && !isAllotted) return false;
      if (allotmentFilter === 'NOT_ALLOTTED' && isAllotted) return false;

      if (hostelFilter !== 'ALL') {
        if (!activeAlt || activeAlt.hostelId !== hostelFilter) return false;
      }

      const prog = s.program || s.admissionClass;
      if (programFilter !== 'ALL' && prog !== programFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = (s.fullName || '').toLowerCase().includes(q);
        const matchesReg = (s.registrationNumber || '').toLowerCase().includes(q);
        const matchesId = (s.id || '').toLowerCase().includes(q);
        const matchesProg = (prog || '').toLowerCase().includes(q);
        const matchesRoom = activeAlt?.roomNumber?.toLowerCase().includes(q);
        const matchesBed = activeAlt?.bedNumber?.toLowerCase().includes(q);
        return matchesName || matchesReg || matchesId || matchesProg || matchesRoom || matchesBed;
      }

      return true;
    });
  }, [students, activeAllotmentsMap, allotmentFilter, hostelFilter, programFilter, searchQuery]);

  // Open Allot Bed Modal
  const handleOpenAllotModal = (student: Student) => {
    clearMessages();
    setSelectedStudent(student);
    const existing =
      activeAllotmentsMap.get(student.id) || activeAllotmentsMap.get(student.registrationNumber);
    if (existing) {
      setErrorMessage(
        `Student ${student.fullName} already has an active allotment in Room ${existing.roomNumber}, Bed ${existing.bedNumber}. Use Transfer instead.`
      );
      return;
    }

    // Default to first hostel or gender-matched hostel
    const matchedHostel =
      hostels.find(
        (h) =>
          (student.gender === 'Male' && h.hostelType === 'Boys') ||
          (student.gender === 'Female' && h.hostelType === 'Girls')
      ) ||
      hostels[0] ||
      null;

    const hId = matchedHostel?.id || '';
    const relevantBlocks = blocks.filter((b) => b.hostelId === hId);
    const bId = relevantBlocks[0]?.id || '';
    const relevantFloors = floors.filter((f) => f.blockId === bId);
    const fId = relevantFloors[0]?.id || '';
    const relevantRooms = rooms.filter((r) => r.floorId === fId);
    const rId = relevantRooms[0]?.id || '';
    const availableBeds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

    setSelectedHostelId(hId);
    setSelectedBlockId(bId);
    setSelectedFloorId(fId);
    setSelectedRoomId(rId);
    setSelectedBedId(availableBeds[0]?.id || '');
    setActionReason('');
    setIsAllotModalOpen(true);
  };

  // Submit Allotment
  const handleConfirmAllotment = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!selectedStudent || !selectedBedId) {
      setErrorMessage('Please select a valid available Bed.');
      return;
    }

    try {
      await hostelRepository.createAllotment({
        studentId: selectedStudent.id,
        studentRegistrationNumber: selectedStudent.registrationNumber,
        studentName: selectedStudent.fullName,
        studentClass: selectedStudent.program || selectedStudent.admissionClass || 'B.Tech',
        studentSection: selectedStudent.section || 'A',
        studentGender: selectedStudent.gender,
        bedId: selectedBedId,
        academicSession,
        allottedBy: currentUser.name || currentUser.username,
        remarks: actionReason || 'Standard Hostel Admission Allotment',
      });

      setSuccessMessage(
        `Bed successfully allocated to ${selectedStudent.fullName} (${selectedStudent.registrationNumber}).`
      );
      setIsAllotModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to allot room.');
    }
  };

  // Open Transfer Modal
  const handleOpenTransferModal = (student: Student, allotment: HostelAllotment) => {
    clearMessages();
    setSelectedStudent(student);
    setActiveAllotmentForSelected(allotment);

    // Initial default target: current hostel or next
    const hId = allotment.hostelId;
    const relevantBlocks = blocks.filter((b) => b.hostelId === hId);
    const bId = relevantBlocks[0]?.id || '';
    const relevantFloors = floors.filter((f) => f.blockId === bId);
    const fId = relevantFloors[0]?.id || '';
    const relevantRooms = rooms.filter((r) => r.floorId === fId);
    const rId = relevantRooms[0]?.id || '';
    const availableBeds = beds.filter(
      (b) => b.roomId === rId && b.status === 'AVAILABLE' && b.id !== allotment.bedId
    );

    setSelectedHostelId(hId);
    setSelectedBlockId(bId);
    setSelectedFloorId(fId);
    setSelectedRoomId(rId);
    setSelectedBedId(availableBeds[0]?.id || '');
    setActionReason('');
    setIsTransferModalOpen(true);
  };

  // Submit Transfer
  const handleConfirmTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!activeAllotmentForSelected || !selectedBedId) {
      setErrorMessage('Please select a destination available bed.');
      return;
    }

    if (!actionReason.trim()) {
      setErrorMessage('Please provide an administrative reason for the room/bed transfer.');
      return;
    }

    try {
      await hostelRepository.transferAllotment({
        allotmentId: activeAllotmentForSelected.id,
        newBedId: selectedBedId,
        transferredBy: currentUser.name || currentUser.username,
        reason: actionReason,
      });

      setSuccessMessage(`Student successfully transferred to new bed.`);
      setIsTransferModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to transfer bed.');
    }
  };

  // Open Vacate Modal
  const handleOpenVacateModal = (student: Student, allotment: HostelAllotment) => {
    clearMessages();
    setSelectedStudent(student);
    setActiveAllotmentForSelected(allotment);
    setActionReason('');
    setIsVacateModalOpen(true);
  };

  // Submit Vacate
  const handleConfirmVacate = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!activeAllotmentForSelected) return;

    try {
      await hostelRepository.vacateAllotment({
        allotmentId: activeAllotmentForSelected.id,
        vacatedBy: currentUser.name || currentUser.username,
        reason: actionReason || 'Graduation / Semester Completion / Student Request',
      });

      setSuccessMessage(`Hostel bed vacated and marked available.`);
      setIsVacateModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to vacate bed.');
    }
  };

  // Open History Modal
  const handleOpenHistoryModal = (student: Student) => {
    clearMessages();
    setSelectedStudent(student);
    setIsHistoryModalOpen(true);
  };

  // Dynamic lists for modal selections
  const modalAvailableBlocks = blocks.filter((b) => b.hostelId === selectedHostelId);
  const modalAvailableFloors = floors.filter((f) => f.blockId === selectedBlockId);
  const modalAvailableRooms = rooms.filter((r) => r.floorId === selectedFloorId);
  const modalAvailableBeds = beds.filter(
    (b) => b.roomId === selectedRoomId && b.status === 'AVAILABLE'
  );

  // Student history items
  const studentHistory = useMemo(() => {
    if (!selectedStudent) return [];
    return allotmentHistory
      .filter(
        (h) =>
          h.studentId === selectedStudent.id ||
          h.studentRegistrationNumber === selectedStudent.registrationNumber
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [allotmentHistory, selectedStudent]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">
            Student Hostel Allotment Directory
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Institutional directory of enrolled students, active residential hall assignments, room transfers, and vacation history.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-lg px-3 py-1.5 text-xs text-[#334155]">
            <span className="font-bold text-[#1e3a8a]">
              {allotments.filter((a) => a.status === 'active').length}
            </span>{' '}
            <span>Active Residents</span> &bull;{' '}
            <span className="font-bold text-[#64748b]">{students.length}</span>{' '}
            <span>Total Enrolled</span>
          </div>
        </div>
      </div>

      {/* Status Alerts */}
      {errorMessage && (
        <Alert
          type="error"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}
      {successMessage && (
        <Alert
          type="success"
          message={successMessage}
          onDismiss={() => setSuccessMessage(null)}
        />
      )}

      {/* Search & Filter Bar */}
      <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs flex flex-col lg:flex-row items-center justify-between gap-3">
        <div className="relative w-full lg:w-80">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student, reg no, room..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto">
          {/* Status Filter */}
          <div className="flex items-center bg-[#f1f5f9] p-1 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setAllotmentFilter('ALL')}
              className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                allotmentFilter === 'ALL'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-[#64748b] hover:text-[#1e293b]'
              }`}
            >
              All Students
            </button>
            <button
              onClick={() => setAllotmentFilter('ALLOTTED')}
              className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                allotmentFilter === 'ALLOTTED'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-[#64748b] hover:text-[#1e293b]'
              }`}
            >
              Allotted Only
            </button>
            <button
              onClick={() => setAllotmentFilter('NOT_ALLOTTED')}
              className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                allotmentFilter === 'NOT_ALLOTTED'
                  ? 'bg-white text-slate-700 shadow-xs'
                  : 'text-[#64748b] hover:text-[#1e293b]'
              }`}
            >
              Unallotted
            </button>
          </div>

          {/* Hostel Filter */}
          <select
            value={hostelFilter}
            onChange={(e) => setHostelFilter(e.target.value)}
            className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
          >
            <option value="ALL">All Hostels</option>
            {hostels.map((h) => (
              <option key={h.id} value={h.id}>
                {h.hostelName} ({h.hostelCode})
              </option>
            ))}
          </select>

          {/* Program Filter */}
          <select
            value={programFilter}
            onChange={(e) => setProgramFilter(e.target.value)}
            className="text-xs py-1.5 px-2.5 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
          >
            <option value="ALL">All Programs</option>
            {uniquePrograms.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Students Allotment Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                <th className="py-3 px-4 font-semibold">Student Identity</th>
                <th className="py-3 px-4 font-semibold">Program & Batch</th>
                <th className="py-3 px-4 font-semibold">Gender</th>
                <th className="py-3 px-4 font-semibold">Residential Allotment</th>
                <th className="py-3 px-4 font-semibold">Allotment Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-[#64748b]">
                    No students match the selected filter criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => {
                  const activeAlt =
                    activeAllotmentsMap.get(s.id) ||
                    activeAllotmentsMap.get(s.registrationNumber);
                  const isAllotted = !!activeAlt;

                  return (
                    <tr key={s.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-[#1e293b]">{s.fullName}</span>
                          <span className="text-[10px] text-[#64748b] font-mono">
                            {s.registrationNumber} &bull; ID: {s.id}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-[#334155]">
                        <div>{s.program || s.admissionClass}</div>
                        <div className="text-[10px] text-[#64748b]">
                          Batch {s.batch || '2026'} &bull; Sem {s.currentSemester || '1'}
                        </div>
                      </td>
                      <td className="py-3 px-4 capitalize text-[#475569]">
                        <span className="font-medium">{s.gender || '—'}</span>
                      </td>
                      <td className="py-3 px-4">
                        {isAllotted && activeAlt ? (
                          <div className="text-[11px] text-[#1e293b]">
                            <div className="font-semibold text-[#1e3a8a]">
                              {activeAlt.hostelName}
                            </div>
                            <div className="text-[10px] text-[#64748b]">
                              {activeAlt.blockName} &bull; {activeAlt.floorName} &bull;{' '}
                              <strong className="text-[#334155]">Room {activeAlt.roomNumber}</strong>{' '}
                              &bull; <strong className="text-[#166534]">Bed {activeAlt.bedNumber}</strong>
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-[#94a3b8] italic">No active room allotment</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant={isAllotted ? 'emerald' : 'neutral'} size="sm">
                          {isAllotted ? 'Allotted' : 'Not Allotted'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {!isAllotted ? (
                            <Button
                              variant="primary"
                              size="sm"
                              onClick={() => handleOpenAllotModal(s)}
                              leftIcon={<Home className="w-3.5 h-3.5" />}
                            >
                              Allot Bed
                            </Button>
                          ) : (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenTransferModal(s, activeAlt!)}
                                leftIcon={<ArrowRightLeft className="w-3.5 h-3.5" />}
                              >
                                Transfer
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleOpenVacateModal(s, activeAlt!)}
                                leftIcon={<LogOut className="w-3.5 h-3.5" />}
                              >
                                Vacate
                              </Button>
                            </>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleOpenHistoryModal(s)}
                            leftIcon={<History className="w-3.5 h-3.5" />}
                          >
                            History
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ----------------- ALLOT BED MODAL ----------------- */}
      {isAllotModalOpen && selectedStudent && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <div>
                <h3 className="font-bold text-base text-[#1e293b]">
                  Allocate Hostel Room & Bed
                </h3>
                <p className="text-[11px] text-[#64748b]">
                  Student: <strong>{selectedStudent.fullName}</strong> ({selectedStudent.registrationNumber}) &bull;{' '}
                  <span className="capitalize">{selectedStudent.gender}</span>
                </p>
              </div>
              <button
                onClick={() => setIsAllotModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmAllotment} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Hostel *</label>
                  <select
                    value={selectedHostelId}
                    onChange={(e) => {
                      const hId = e.target.value;
                      const blks = blocks.filter((b) => b.hostelId === hId);
                      const bId = blks[0]?.id || '';
                      const flrs = floors.filter((f) => f.blockId === bId);
                      const fId = flrs[0]?.id || '';
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedHostelId(hId);
                      setSelectedBlockId(bId);
                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {hostels.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.hostelName} ({h.hostelType})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">Block / Wing *</label>
                  <select
                    value={selectedBlockId}
                    onChange={(e) => {
                      const bId = e.target.value;
                      const flrs = floors.filter((f) => f.blockId === bId);
                      const fId = flrs[0]?.id || '';
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedBlockId(bId);
                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableBlocks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.blockName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Floor *</label>
                  <select
                    value={selectedFloorId}
                    onChange={(e) => {
                      const fId = e.target.value;
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableFloors.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.floorName} (Fl {f.floorNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">Room *</label>
                  <select
                    value={selectedRoomId}
                    onChange={(e) => {
                      const rId = e.target.value;
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableRooms.map((r) => {
                      const avail = beds.filter((b) => b.roomId === r.id && b.status === 'AVAILABLE').length;
                      return (
                        <option key={r.id} value={r.id}>
                          Room {r.roomNumber} ({r.roomType}, {avail} beds free)
                        </option>
                      );
                    })}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">
                  Target Bed / Seat (Only Available Beds Shown) *
                </label>
                {modalAvailableBeds.length === 0 ? (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs">
                    No available beds in the selected room. Please choose another room or floor.
                  </div>
                ) : (
                  <select
                    value={selectedBedId}
                    onChange={(e) => setSelectedBedId(e.target.value)}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableBeds.map((b) => (
                      <option key={b.id} value={b.id}>
                        Bed {b.bedNumber} (Status: Available)
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Academic Session</label>
                  <input
                    type="text"
                    value={academicSession}
                    onChange={(e) => setAcademicSession(e.target.value)}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
                <div>
                  <label className="block font-medium text-[#475569] mb-1">Allotment Remarks</label>
                  <input
                    type="text"
                    placeholder="e.g. Verified residential fee"
                    value={actionReason}
                    onChange={(e) => setActionReason(e.target.value)}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  />
                </div>
              </div>

              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-blue-800 text-[11px] leading-relaxed">
                <strong>Enforced ERP Integrity:</strong> Once confirmed, the student will have exactly ONE active allotment. The assigned bed will be marked OCCUPIED in real-time, and room/hostel occupancy statistics will recalculate immediately.
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsAllotModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={!selectedBedId || modalAvailableBeds.length === 0}
                >
                  Confirm Bed Allotment
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- TRANSFER BED MODAL ----------------- */}
      {isTransferModalOpen && selectedStudent && activeAllotmentForSelected && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <div>
                <h3 className="font-bold text-base text-[#1e293b]">
                  Transfer Student Bed / Room
                </h3>
                <p className="text-[11px] text-[#64748b]">
                  Student: <strong>{selectedStudent.fullName}</strong> ({selectedStudent.registrationNumber})
                </p>
              </div>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900 space-y-1">
              <span className="font-bold block">Current Active Placement:</span>
              <div>
                {activeAllotmentForSelected.hostelName} &bull; {activeAllotmentForSelected.blockName} &bull;{' '}
                Room {activeAllotmentForSelected.roomNumber} &bull; Bed {activeAllotmentForSelected.bedNumber}
              </div>
              <span className="text-[10px] text-amber-700">
                This old bed will be automatically released to AVAILABLE status upon transfer.
              </span>
            </div>

            <form onSubmit={handleConfirmTransfer} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">New Hostel *</label>
                  <select
                    value={selectedHostelId}
                    onChange={(e) => {
                      const hId = e.target.value;
                      const blks = blocks.filter((b) => b.hostelId === hId);
                      const bId = blks[0]?.id || '';
                      const flrs = floors.filter((f) => f.blockId === bId);
                      const fId = flrs[0]?.id || '';
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedHostelId(hId);
                      setSelectedBlockId(bId);
                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {hostels.map((h) => (
                      <option key={h.id} value={h.id}>
                        {h.hostelName} ({h.hostelType})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">New Block *</label>
                  <select
                    value={selectedBlockId}
                    onChange={(e) => {
                      const bId = e.target.value;
                      const flrs = floors.filter((f) => f.blockId === bId);
                      const fId = flrs[0]?.id || '';
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedBlockId(bId);
                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableBlocks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.blockName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-[#475569] mb-1">New Floor *</label>
                  <select
                    value={selectedFloorId}
                    onChange={(e) => {
                      const fId = e.target.value;
                      const rms = rooms.filter((r) => r.floorId === fId);
                      const rId = rms[0]?.id || '';
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');

                      setSelectedFloorId(fId);
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableFloors.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.floorName} (Fl {f.floorNumber})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-[#475569] mb-1">New Room *</label>
                  <select
                    value={selectedRoomId}
                    onChange={(e) => {
                      const rId = e.target.value;
                      const bds = beds.filter((b) => b.roomId === rId && b.status === 'AVAILABLE');
                      setSelectedRoomId(rId);
                      setSelectedBedId(bds[0]?.id || '');
                    }}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableRooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        Room {r.roomNumber} ({r.roomType})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">
                  Destination Available Bed *
                </label>
                {modalAvailableBeds.length === 0 ? (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs">
                    No free beds available in the destination room.
                  </div>
                ) : (
                  <select
                    value={selectedBedId}
                    onChange={(e) => setSelectedBedId(e.target.value)}
                    className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                  >
                    {modalAvailableBeds.map((b) => (
                      <option key={b.id} value={b.id}>
                        Bed {b.bedNumber} (Status: Available)
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="block font-medium text-[#475569] mb-1">Transfer Reason *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mutual room exchange, medical relocation, student request"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsTransferModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={!selectedBedId || modalAvailableBeds.length === 0}
                >
                  Execute Bed Transfer
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- VACATE BED MODAL ----------------- */}
      {isVacateModalOpen && selectedStudent && activeAllotmentForSelected && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 border border-[#e2e8f0]">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <h3 className="font-bold text-base text-[#1e293b]">
                Vacate Hostel Bed Allotment
              </h3>
              <button
                onClick={() => setIsVacateModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-900 space-y-1">
              <div className="font-bold">Confirmation Warning:</div>
              <div>
                Are you sure you want to vacate bed <strong>{activeAllotmentForSelected.bedNumber}</strong> in{' '}
                <strong>Room {activeAllotmentForSelected.roomNumber}</strong> ({activeAllotmentForSelected.hostelName}) for{' '}
                <strong>{selectedStudent.fullName}</strong>?
              </div>
              <div className="text-[10px] text-rose-700">
                The bed will immediately become AVAILABLE for reallocation.
              </div>
            </div>

            <form onSubmit={handleConfirmVacate} className="space-y-4 text-xs">
              <div>
                <label className="block font-medium text-[#475569] mb-1">Vacation Reason</label>
                <input
                  type="text"
                  placeholder="e.g. End of academic session, withdrawing from hostel"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  className="w-full p-2 border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#e2e8f0]">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsVacateModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="danger" size="sm">
                  Confirm Vacation
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- HISTORY MODAL ----------------- */}
      {isHistoryModalOpen && selectedStudent && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-xl w-full p-6 space-y-4 border border-[#e2e8f0] max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#e2e8f0] pb-3">
              <div>
                <h3 className="font-bold text-base text-[#1e293b]">
                  Residential History & Movement Audit
                </h3>
                <p className="text-[11px] text-[#64748b]">
                  Student: <strong>{selectedStudent.fullName}</strong> ({selectedStudent.registrationNumber})
                </p>
              </div>
              <button
                onClick={() => setIsHistoryModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto flex-1 space-y-3 pr-1 text-xs">
              {studentHistory.length === 0 ? (
                <div className="py-8 text-center text-[#64748b]">
                  No historical hostel records found for this student.
                </div>
              ) : (
                studentHistory.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-lg space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={
                            item.action === 'ALLOTMENT'
                              ? 'emerald'
                              : item.action === 'TRANSFER'
                              ? 'blue'
                              : item.action === 'VACATE'
                              ? 'amber'
                              : 'rose'
                          }
                          size="sm"
                        >
                          {item.action}
                        </Badge>
                        <span className="font-mono text-[10px] text-[#64748b]">
                          {new Date(item.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <span className="text-[10px] text-[#475569] font-medium">
                        Actor: {item.actor}
                      </span>
                    </div>

                    <div className="text-[11px] text-[#1e293b]">
                      {item.previousRoomNumber && (
                        <div>
                          <span className="text-[#64748b]">From: </span>
                          <span className="font-mono">
                            {item.previousHostelName} &bull; Room {item.previousRoomNumber} &bull; Bed {item.previousBedNumber}
                          </span>
                        </div>
                      )}
                      {item.newRoomNumber && (
                        <div>
                          <span className="text-[#64748b]">To / At: </span>
                          <span className="font-mono font-bold text-[#1e3a8a]">
                            {item.newHostelName} &bull; Room {item.newRoomNumber} &bull; Bed {item.newBedNumber}
                          </span>
                        </div>
                      )}
                    </div>

                    {item.reason && (
                      <div className="text-[11px] text-[#475569] italic pt-0.5">
                        &quot;{item.reason}&quot;
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            <div className="pt-3 border-t border-[#e2e8f0] flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsHistoryModalOpen(false)}
              >
                Close Audit Log
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
