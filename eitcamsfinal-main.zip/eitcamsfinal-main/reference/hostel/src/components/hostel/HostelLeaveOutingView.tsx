import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertCircle,
  Filter,
  Search,
  Calendar,
  Building,
  User,
  Phone,
  MapPin,
  FileText,
  Printer,
  ChevronRight,
  RefreshCw,
  Ban,
  ArrowRight,
  Info,
  Check,
  Eye,
} from 'lucide-react';
import { LeaveOutingRequest, LeaveOutingStatus, HostelLeaveMetrics, Hostel, HostelBlock } from '../../types/hostel';
import { hostelLeaveService } from '../../services/hostelLeaveService';
import { hostelRepository } from '../../services/hostelService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { LeaveOutingSlipModal } from './LeaveOutingSlipModal';

interface HostelLeaveOutingViewProps {
  currentUser?: {
    id?: string;
    name?: string;
    username?: string;
  } | null;
}

export function HostelLeaveOutingView({ currentUser }: HostelLeaveOutingViewProps) {
  const [requests, setRequests] = useState<LeaveOutingRequest[]>([]);
  const [metrics, setMetrics] = useState<HostelLeaveMetrics>({
    pendingHostel: 0,
    approvedToday: 0,
    rejected: 0,
    activeLeaveOuting: 0,
    totalRequests: 0,
  });
  const [hostels, setHostels] = useState<Hostel[]>([]);
  const [blocks, setBlocks] = useState<HostelBlock[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters state
  const [statusFilter, setStatusFilter] = useState<string>('PENDING_HOSTEL'); // Default to pending hostel
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [hostelFilter, setHostelFilter] = useState<string>('all');
  const [blockFilter, setBlockFilter] = useState<string>('all');
  const [roomQuery, setRoomQuery] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [fromDateFilter, setFromDateFilter] = useState<string>('');
  const [toDateFilter, setToDateFilter] = useState<string>('');

  // Modal states
  const [selectedRequest, setSelectedRequest] = useState<LeaveOutingRequest | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject'>('approve');
  const [hostelRemarksText, setHostelRemarksText] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  // Slip modal state
  const [slipModalRequest, setSlipModalRequest] = useState<LeaveOutingRequest | null>(null);
  const [isSlipModalOpen, setIsSlipModalOpen] = useState(false);

  // Load data
  const loadData = async () => {
    try {
      setIsLoading(true);
      const [allReqs, allMetrics, allHostels, allBlocks] = await Promise.all([
        hostelLeaveService.getAllRequests(),
        hostelLeaveService.getDashboardMetrics(),
        hostelRepository.getAllHostels(),
        hostelRepository.getAllBlocks(),
      ]);
      setRequests(allReqs);
      setMetrics(allMetrics);
      setHostels(allHostels);
      setBlocks(allBlocks);
    } catch (err) {
      console.error('Failed to load hostel leave requests:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    const unsubLeave = hostelLeaveService.subscribe(() => {
      loadData();
    });

    return () => {
      unsubLeave();
    };
  }, []);

  // Filtered requests list
  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      if (statusFilter !== 'all' && req.status !== statusFilter) return false;
      if (typeFilter !== 'all' && req.requestType !== typeFilter) return false;
      if (hostelFilter !== 'all' && req.hostelId !== hostelFilter) return false;
      if (blockFilter !== 'all' && req.blockId !== blockFilter) return false;

      if (roomQuery.trim()) {
        const q = roomQuery.trim().toLowerCase();
        if (!(req.roomNumber || '').toLowerCase().includes(q)) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const matchesName = req.studentName.toLowerCase().includes(q);
        const matchesReg = req.studentRegistrationNumber.toLowerCase().includes(q);
        const matchesId = req.id.toLowerCase().includes(q);
        const matchesSlip = req.slipNumber?.toLowerCase().includes(q);
        if (!matchesName && !matchesReg && !matchesId && !matchesSlip) return false;
      }

      if (fromDateFilter && req.fromDate < fromDateFilter) return false;
      if (toDateFilter && req.toDate > toDateFilter) return false;

      return true;
    });
  }, [
    requests,
    statusFilter,
    typeFilter,
    hostelFilter,
    blockFilter,
    roomQuery,
    searchQuery,
    fromDateFilter,
    toDateFilter,
  ]);

  const handleOpenReview = (req: LeaveOutingRequest, defaultAction: 'approve' | 'reject' = 'approve') => {
    setSelectedRequest(req);
    setReviewAction(defaultAction);
    setHostelRemarksText(defaultAction === 'approve' ? 'Hostel gate clearance approved.' : '');
    setReviewError(null);
    setIsReviewModalOpen(true);
  };

  const handleOpenSlip = (req: LeaveOutingRequest) => {
    if (req.status !== 'APPROVED') return;
    setSlipModalRequest(req);
    setIsSlipModalOpen(true);
  };

  const handleSubmitHostelReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest) return;

    if (reviewAction === 'reject' && !hostelRemarksText.trim()) {
      setReviewError('A detailed reason is mandatory when rejecting a request.');
      return;
    }

    try {
      setIsSubmittingReview(true);
      setReviewError(null);

      const employeeName = currentUser?.name || currentUser?.username || 'Hostel Office Authority';
      const employeeId = currentUser?.id || 'HOSTEL_OFFICE';

      const updated = await hostelLeaveService.reviewRequestByHostel(
        selectedRequest.id,
        employeeName,
        employeeId,
        reviewAction,
        hostelRemarksText.trim()
      );

      setIsReviewModalOpen(false);
      setSelectedRequest(null);
      await loadData();

      // If approved, prompt or offer slip view
      if (updated.status === 'APPROVED') {
        setSlipModalRequest(updated);
        setIsSlipModalOpen(true);
      }
    } catch (err: any) {
      setReviewError(err.message || 'Failed to submit review');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const resetFilters = () => {
    setStatusFilter('all');
    setTypeFilter('all');
    setHostelFilter('all');
    setBlockFilter('all');
    setRoomQuery('');
    setSearchQuery('');
    setFromDateFilter('');
    setToDateFilter('');
  };

  // Status visual badge helper with accessible icons
  const renderStatusBadge = (status: LeaveOutingStatus) => {
    switch (status) {
      case 'PENDING_HOSTEL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
            Pending Hostel
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Approved
          </span>
        );
      case 'REJECTED_BY_HOSTEL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Rejected by Hostel
          </span>
        );
      case 'PENDING_PROCTOR':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-300">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            Pending Proctor
          </span>
        );
      case 'APPROVED_BY_PROCTOR':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-800 border border-indigo-300">
            <Check className="w-3.5 h-3.5 text-indigo-600" />
            Proctor Approved
          </span>
        );
      case 'REJECTED_BY_PROCTOR':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
            <XCircle className="w-3.5 h-3.5 text-slate-500" />
            Rejected by Proctor
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-300">
            <Ban className="w-3.5 h-3.5 text-slate-400" />
            Cancelled
          </span>
        );
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="bg-white border border-[#cbd5e1] rounded-xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-[#eff6ff] text-[#1e3a8a]">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <h2 className="text-lg font-bold text-[#0f172a]">
              Hostel Leave & Outing Management
            </h2>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Review proctor-endorsed student requests, verify hostel allotment residency, and authorize official gate clearance slips.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={loadData}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Dashboard Metrics (5 Cards) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {/* Card 1: Pending Hostel Approval */}
        <div
          onClick={() => setStatusFilter('PENDING_HOSTEL')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'PENDING_HOSTEL'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-400/30'
              : 'bg-white border-[#e2e8f0] hover:border-amber-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Pending Hostel</span>
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
          </div>
          <div className="text-2xl font-black text-amber-900 mt-2">
            {metrics.pendingHostel}
          </div>
          <div className="text-[11px] text-amber-700 font-medium mt-0.5">
            Requires your approval
          </div>
        </div>

        {/* Card 2: Approved Today */}
        <div
          onClick={() => setStatusFilter('APPROVED')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'APPROVED'
              ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-400/30'
              : 'bg-white border-[#e2e8f0] hover:border-emerald-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Approved Today</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-900 mt-2">
            {metrics.approvedToday}
          </div>
          <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
            Slips issued today
          </div>
        </div>

        {/* Card 3: Rejected by Hostel */}
        <div
          onClick={() => setStatusFilter('REJECTED_BY_HOSTEL')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'REJECTED_BY_HOSTEL'
              ? 'bg-rose-50/80 border-rose-300 ring-2 ring-rose-400/30'
              : 'bg-white border-[#e2e8f0] hover:border-rose-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Hostel Rejected</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-900 mt-2">
            {metrics.rejected}
          </div>
          <div className="text-[11px] text-rose-700 font-medium mt-0.5">
            Declined requests
          </div>
        </div>

        {/* Card 4: Active Movement */}
        <div
          onClick={() => setStatusFilter('APPROVED')}
          className="p-4 rounded-xl border bg-white border-[#e2e8f0] transition-all cursor-pointer hover:border-indigo-200"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Active Leaves</span>
            <Calendar className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-indigo-900 mt-2">
            {metrics.activeLeaveOuting}
          </div>
          <div className="text-[11px] text-indigo-700 font-medium mt-0.5">
            Currently away
          </div>
        </div>

        {/* Card 5: Total Requests */}
        <div
          onClick={() => setStatusFilter('all')}
          className={`p-4 rounded-xl border transition-all cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-slate-50 border-slate-300 ring-2 ring-slate-400/30'
              : 'bg-white border-[#e2e8f0] hover:border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Total Requests</span>
            <FileText className="w-4 h-4 text-slate-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">
            {metrics.totalRequests}
          </div>
          <div className="text-[11px] text-slate-500 font-medium mt-0.5">
            All logged requests
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white border border-[#cbd5e1] rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Filter className="w-4 h-4 text-[#1e3a8a]" />
            <span>Filter Requests ({filteredRequests.length} matching)</span>
          </div>
          <button
            type="button"
            onClick={resetFilters}
            className="text-xs text-[#1e3a8a] hover:underline font-semibold cursor-pointer"
          >
            Clear All Filters
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
          {/* Status Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            >
              <option value="all">All Statuses</option>
              <option value="PENDING_HOSTEL">Pending Hostel Approval</option>
              <option value="APPROVED">Approved (Gate Slip Issued)</option>
              <option value="REJECTED_BY_HOSTEL">Rejected by Hostel</option>
              <option value="PENDING_PROCTOR">Pending Proctor</option>
              <option value="REJECTED_BY_PROCTOR">Rejected by Proctor</option>
              <option value="CANCELLED">Cancelled</option>
            </select>
          </div>

          {/* Type Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Request Type</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            >
              <option value="all">All Types (Leave & Outing)</option>
              <option value="leave">Overnight Leave</option>
              <option value="outing">Day Outing Pass</option>
            </select>
          </div>

          {/* Hostel Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Hostel</label>
            <select
              value={hostelFilter}
              onChange={(e) => {
                setHostelFilter(e.target.value);
                setBlockFilter('all');
              }}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            >
              <option value="all">All Hostels</option>
              {hostels.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.hostelName}
                </option>
              ))}
            </select>
          </div>

          {/* Block Filter */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Block</label>
            <select
              value={blockFilter}
              onChange={(e) => setBlockFilter(e.target.value)}
              disabled={hostelFilter === 'all'}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20 disabled:bg-slate-50 disabled:text-slate-400"
            >
              <option value="all">All Blocks</option>
              {blocks
                .filter((b) => hostelFilter === 'all' || b.hostelId === hostelFilter)
                .map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.blockName}
                  </option>
                ))}
            </select>
          </div>

          {/* Room Query */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Room No.</label>
            <input
              type="text"
              placeholder="e.g. 101, 204..."
              value={roomQuery}
              onChange={(e) => setRoomQuery(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            />
          </div>

          {/* Student Search */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Search Student</label>
            <div className="relative">
              <input
                type="text"
                placeholder="Name or Reg Number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* From Date */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Departure On/After</label>
            <input
              type="date"
              value={fromDateFilter}
              onChange={(e) => setFromDateFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            />
          </div>

          {/* To Date */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Return On/Before</label>
            <input
              type="date"
              value={toDateFilter}
              onChange={(e) => setToDateFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 border border-[#cbd5e1] rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
            />
          </div>
        </div>
      </div>

      {/* Requests Table / List */}
      <div className="bg-white border border-[#cbd5e1] rounded-xl shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-[#e2e8f0] flex items-center justify-between bg-slate-50/50">
          <div className="text-xs font-bold text-slate-800">
            Request Log ({filteredRequests.length})
          </div>
          <div className="text-[11px] text-slate-500">
            {statusFilter === 'PENDING_HOSTEL' && (
              <span className="text-amber-700 font-semibold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Showing requests awaiting your clearance
              </span>
            )}
          </div>
        </div>

        {filteredRequests.length === 0 ? (
          <div className="py-12 text-center text-slate-500 space-y-2">
            <FileText className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-semibold">No requests match the selected filters.</p>
            <p className="text-xs text-slate-400">
              Try switching status filters or clearing search terms.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[#cbd5e1] bg-[#f8fafc] text-[#475569] font-bold text-[11px] uppercase tracking-wider">
                  <th className="py-3 px-4">Req # & Type</th>
                  <th className="py-3 px-4">Student Particulars</th>
                  <th className="py-3 px-4">Hostel / Room / Bed</th>
                  <th className="py-3 px-4">Movement Dates</th>
                  <th className="py-3 px-4">Proctor Endorsement</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredRequests.map((req) => {
                  const isPendingHostel = req.status === 'PENDING_HOSTEL';
                  const isApproved = req.status === 'APPROVED';

                  return (
                    <tr
                      key={req.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isPendingHostel ? 'bg-amber-50/20' : ''
                      }`}
                    >
                      {/* Req # & Type */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-mono font-bold text-[#1e3a8a]">{req.id}</div>
                        <div className="mt-1">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              req.requestType === 'outing'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {req.requestType === 'outing' ? 'Day Outing' : 'Hostel Leave'}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 mt-1">
                          {req.createdAt ? new Date(req.createdAt).toLocaleDateString() : ''}
                        </div>
                      </td>

                      {/* Student Particulars */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-bold text-slate-900">{req.studentName}</div>
                        <div className="font-mono text-slate-500 text-[11px]">
                          {req.studentRegistrationNumber}
                        </div>
                        <div className="text-[11px] text-slate-600">
                          {req.program || req.studentClass} ({req.batch || 'Batch'})
                        </div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {req.contactNumber || req.parentContactNumber || 'No phone'}
                        </div>
                      </td>

                      {/* Hostel / Room / Bed */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-semibold text-slate-800">
                          {req.hostelName || 'Hostel'}
                        </div>
                        <div className="text-[11px] text-slate-600">
                          {req.blockName || req.hostelBlock || 'Block'} &bull; Rm {req.roomNumber || '-'}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          Bed: {req.bedNumber || '-'}
                        </div>
                      </td>

                      {/* Movement Dates */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-0.5">
                          <div className="text-slate-800 font-semibold">
                            {req.fromDate}{' '}
                            <span className="text-[11px] font-normal text-slate-500">
                              ({req.fromTime || '09:00'})
                            </span>
                          </div>
                          <div className="text-slate-400 text-[10px] pl-1">&darr; to</div>
                          <div className="text-slate-800 font-semibold">
                            {req.toDate}{' '}
                            <span className="text-[11px] font-normal text-slate-500">
                              ({req.toTime || '18:00'})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-600 truncate max-w-xs mt-1">
                            <span className="font-semibold text-slate-500">Dest:</span> {req.destination || req.destinationAddress || 'Local'}
                          </div>
                        </div>
                      </td>

                      {/* Proctor Endorsement */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="font-semibold text-slate-800">{req.proctorName}</div>
                        <div className="text-[10px] text-slate-500">
                          {req.proctorActionDate
                            ? `Endorsed ${new Date(req.proctorActionDate).toLocaleDateString()}`
                            : 'Pending review'}
                        </div>
                        {req.proctorRemarks && (
                          <div className="text-[10px] text-slate-600 italic bg-slate-50 p-1 rounded border border-slate-200 mt-1 max-w-xs truncate">
                            &ldquo;{req.proctorRemarks}&rdquo;
                          </div>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 align-top">
                        {renderStatusBadge(req.status)}
                        {req.slipNumber && (
                          <div className="text-[10px] font-mono text-emerald-700 font-bold mt-1">
                            {req.slipNumber}
                          </div>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 align-top text-right space-y-1.5">
                        {isPendingHostel ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              size="sm"
                              variant="primary"
                              onClick={() => handleOpenReview(req, 'approve')}
                              className="text-xs"
                            >
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOpenReview(req, 'reject')}
                              className="text-xs text-rose-600 hover:text-rose-700"
                            >
                              Reject
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedRequest(req);
                                setIsReviewModalOpen(true);
                              }}
                              className="text-xs"
                              leftIcon={<Eye className="w-3.5 h-3.5" />}
                            >
                              Details
                            </Button>

                            {isApproved && (
                              <Button
                                size="sm"
                                variant="primary"
                                onClick={() => handleOpenSlip(req)}
                                className="text-xs gap-1 bg-emerald-700 hover:bg-emerald-800"
                                leftIcon={<Printer className="w-3.5 h-3.5" />}
                              >
                                Slip
                              </Button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Review & Details Modal */}
      {isReviewModalOpen && selectedRequest && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-300 overflow-hidden my-6">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-lg bg-[#eff6ff] text-[#1e3a8a]">
                  <ShieldCheck className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Hostel Gate Clearance Review
                  </h3>
                  <div className="text-xs text-slate-500 font-mono">
                    {selectedRequest.id} &bull; {selectedRequest.requestType.toUpperCase()}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsReviewModalOpen(false);
                  setSelectedRequest(null);
                }}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-6 space-y-5 text-xs max-h-[75vh] overflow-y-auto">
              {/* Student & Hostel Overview */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Student Particulars */}
                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/60 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-[#1e3a8a]" /> Student Information
                  </div>
                  <div className="text-sm font-bold text-slate-900">
                    {selectedRequest.studentName}
                  </div>
                  <div className="font-mono text-slate-600 font-semibold">
                    {selectedRequest.studentRegistrationNumber}
                  </div>
                  <div className="text-slate-600">
                    {selectedRequest.program || selectedRequest.studentClass} ({selectedRequest.batch || 'Batch'})
                  </div>
                  <div className="text-slate-500 pt-1 border-t border-slate-200 flex justify-between">
                    <span>Student Mobile:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {selectedRequest.contactNumber || 'Not specified'}
                    </span>
                  </div>
                  <div className="text-slate-500 flex justify-between">
                    <span>Emergency / Parent:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {selectedRequest.emergencyContact || selectedRequest.parentContactNumber || 'Not specified'}
                    </span>
                  </div>
                </div>

                {/* Hostel Allotment Record */}
                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50/60 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-[#1e3a8a]" /> Verified Hostel Allotment
                  </div>
                  <div className="text-sm font-bold text-slate-900">
                    {selectedRequest.hostelName || 'Campus Hostel'}
                  </div>
                  <div className="text-slate-600">
                    Block: <strong>{selectedRequest.blockName || selectedRequest.hostelBlock || 'Block'}</strong>
                    {selectedRequest.floorName ? ` &bull; ${selectedRequest.floorName}` : ''}
                  </div>
                  <div className="text-slate-700 font-mono">
                    Room: <strong>{selectedRequest.roomNumber || '-'}</strong> &bull; Bed: <strong>{selectedRequest.bedNumber || '-'}</strong>
                  </div>
                  <div className="text-[11px] text-emerald-700 font-semibold pt-1 border-t border-slate-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Verified Active Resident
                  </div>
                </div>
              </div>

              {/* Movement & Destination */}
              <div className="p-3.5 rounded-lg border border-slate-200 bg-white space-y-2">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  Outing & Leave Timings
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                    <span className="text-slate-400 block text-[10px] font-semibold">FROM / DEPARTURE</span>
                    <span className="font-bold text-slate-800">
                      {selectedRequest.fromDate} at {selectedRequest.fromTime || '09:00'}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                    <span className="text-slate-400 block text-[10px] font-semibold">TO / RETURN</span>
                    <span className="font-bold text-slate-800">
                      {selectedRequest.toDate} at {selectedRequest.toTime || '18:00'}
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <span className="text-slate-500 font-semibold">Destination: </span>
                  <strong className="text-slate-800">
                    {selectedRequest.destination || selectedRequest.destinationAddress || 'Local area'}
                  </strong>
                </div>

                <div>
                  <span className="text-slate-500 font-semibold">Reason: </span>
                  <span className="text-slate-800 bg-slate-50 p-2 rounded block mt-0.5 border border-slate-200">
                    {selectedRequest.reason || selectedRequest.purpose}
                  </span>
                </div>
              </div>

              {/* Stage 1: Proctor Endorsement Record */}
              <div className="p-3.5 rounded-lg border border-blue-200 bg-blue-50/50 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#1e3a8a] uppercase tracking-wider">
                    Stage 1: Faculty Proctor Endorsement
                  </span>
                  <span className="text-[10px] bg-blue-100 text-blue-900 font-bold px-2 py-0.5 rounded">
                    ENDORSED
                  </span>
                </div>
                <div className="text-slate-800 font-semibold">
                  {selectedRequest.proctorName} (ID: {selectedRequest.proctorId})
                </div>
                <div className="text-[11px] text-slate-600">
                  Action Date:{' '}
                  {selectedRequest.proctorActionDate
                    ? new Date(selectedRequest.proctorActionDate).toLocaleString()
                    : 'Endorsed'}
                </div>
                {selectedRequest.proctorRemarks && (
                  <div className="text-slate-700 italic border-t border-blue-200/80 pt-1 text-[11px]">
                    &ldquo;{selectedRequest.proctorRemarks}&rdquo;
                  </div>
                )}
              </div>

              {/* Complete Audit Trail */}
              {selectedRequest.auditTrail && selectedRequest.auditTrail.length > 0 && (
                <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-2">
                  <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    Workflow Audit Trail
                  </div>
                  <div className="space-y-1.5">
                    {selectedRequest.auditTrail.map((entry) => (
                      <div
                        key={entry.id}
                        className="text-[11px] flex items-start justify-between gap-2 p-1.5 bg-white rounded border border-slate-200"
                      >
                        <div>
                          <span className="font-bold text-slate-800">{entry.action}</span>
                          <span className="text-slate-500 ml-1">
                            by {entry.actor} ({entry.actorRole})
                          </span>
                          {entry.remarks && (
                            <div className="text-slate-600 italic mt-0.5">
                              {entry.remarks}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 shrink-0">
                          {new Date(entry.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Review Form (ONLY if status === PENDING_HOSTEL) */}
              {selectedRequest.status === 'PENDING_HOSTEL' ? (
                <form onSubmit={handleSubmitHostelReview} className="p-4 border border-amber-300 rounded-lg bg-amber-50/40 space-y-3">
                  <div className="text-xs font-bold text-slate-900">
                    Hostel Authority Decision
                  </div>

                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="reviewAction"
                        checked={reviewAction === 'approve'}
                        onChange={() => {
                          setReviewAction('approve');
                          setHostelRemarksText('Hostel gate clearance approved.');
                          setReviewError(null);
                        }}
                        className="text-[#1e3a8a] focus:ring-[#1e3a8a]"
                      />
                      <span className="font-bold text-emerald-800">Approve & Issue Gate Slip</span>
                    </label>

                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="reviewAction"
                        checked={reviewAction === 'reject'}
                        onChange={() => {
                          setReviewAction('reject');
                          setHostelRemarksText('');
                          setReviewError(null);
                        }}
                        className="text-rose-600 focus:ring-rose-500"
                      />
                      <span className="font-bold text-rose-800">Reject Request</span>
                    </label>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Hostel Remarks / Instructions {reviewAction === 'reject' && <span className="text-rose-500">* (Mandatory)</span>}
                    </label>
                    <textarea
                      value={hostelRemarksText}
                      onChange={(e) => setHostelRemarksText(e.target.value)}
                      required={reviewAction === 'reject'}
                      rows={2}
                      placeholder={
                        reviewAction === 'approve'
                          ? 'Optional clearance notes or curfew reminders...'
                          : 'Provide specific reason for rejection (required)...'
                      }
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20 text-xs"
                    />
                  </div>

                  {reviewError && (
                    <div className="p-2.5 bg-rose-50 border border-rose-200 rounded text-rose-700 text-xs flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{reviewError}</span>
                    </div>
                  )}

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setIsReviewModalOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      variant={reviewAction === 'approve' ? 'primary' : 'danger'}
                      size="sm"
                      disabled={isSubmittingReview}
                    >
                      {isSubmittingReview
                        ? 'Processing...'
                        : reviewAction === 'approve'
                        ? 'Confirm Approval & Generate Slip'
                        : 'Confirm Rejection'}
                    </Button>
                  </div>
                </form>
              ) : (
                <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                  <div className="text-xs text-slate-500">
                    Status: {renderStatusBadge(selectedRequest.status)}
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedRequest.status === 'APPROVED' && (
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => {
                          setIsReviewModalOpen(false);
                          handleOpenSlip(selectedRequest);
                        }}
                        leftIcon={<Printer className="w-3.5 h-3.5" />}
                      >
                        Print Official Slip
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setIsReviewModalOpen(false);
                        setSelectedRequest(null);
                      }}
                    >
                      Close
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Official Leave/Outing Slip Modal */}
      {isSlipModalOpen && slipModalRequest && (
        <LeaveOutingSlipModal
          isOpen={isSlipModalOpen}
          onClose={() => {
            setIsSlipModalOpen(false);
            setSlipModalRequest(null);
          }}
          request={slipModalRequest}
        />
      )}
    </div>
  );
}
