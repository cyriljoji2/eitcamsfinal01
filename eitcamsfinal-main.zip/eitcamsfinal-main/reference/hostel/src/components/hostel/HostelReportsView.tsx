import React, { useState, useMemo } from 'react';
import {
  Building2,
  Users,
  Search,
  Download,
  History,
} from 'lucide-react';
import {
  Hostel,
  HostelBlock,
  HostelFloor,
  HostelRoom,
  HostelBed,
  HostelAllotment,
  HostelAllotmentHistory,
} from '../../types/hostel';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface HostelReportsViewProps {
  hostels: Hostel[];
  blocks: HostelBlock[];
  floors: HostelFloor[];
  rooms: HostelRoom[];
  beds: HostelBed[];
  allotments: HostelAllotment[];
  allotmentHistory: HostelAllotmentHistory[];
}

type ReportType = 'occupancy' | 'allotment_register' | 'audit_log';

export function HostelReportsView({
  hostels,
  blocks,
  floors,
  rooms,
  beds,
  allotments,
  allotmentHistory,
}: HostelReportsViewProps) {
  const [activeReport, setActiveReport] = useState<ReportType>('occupancy');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHostelFilter, setSelectedHostelFilter] = useState('ALL');

  // Helper Lookups
  const getHostelName = (id: string) => hostels.find((h) => h.id === id)?.hostelName || id;
  const getBlockName = (id: string) => blocks.find((b) => b.id === id)?.blockName || id;
  const getFloorName = (id: string) => {
    const f = floors.find((fl) => fl.id === id);
    return f ? `${f.floorName} (Fl ${f.floorNumber})` : id;
  };

  // Occupancy Report Data Rows
  const occupancyRows = useMemo(() => {
    return rooms.map((room) => {
      const roomBeds = beds.filter((b) => b.roomId === room.id);
      const occupiedCount = roomBeds.filter((b) => b.status === 'OCCUPIED').length;
      const availableCount = roomBeds.filter((b) => b.status === 'AVAILABLE').length;
      const blockedCount = roomBeds.filter((b) => b.status === 'BLOCKED').length;
      const occupancyRate =
        room.capacity > 0 ? Math.round((occupiedCount / room.capacity) * 100) : 0;

      return {
        room,
        hostelName: getHostelName(room.hostelId),
        blockName: getBlockName(room.blockId),
        floorName: getFloorName(room.floorId),
        totalBeds: roomBeds.length,
        capacity: room.capacity,
        occupiedCount,
        availableCount,
        blockedCount,
        occupancyRate,
      };
    });
  }, [rooms, beds, hostels, blocks, floors]);

  // Filtered Occupancy Rows
  const filteredOccupancyRows = useMemo(() => {
    return occupancyRows.filter((row) => {
      if (selectedHostelFilter !== 'ALL' && row.room.hostelId !== selectedHostelFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          row.room.roomNumber.toLowerCase().includes(q) ||
          row.hostelName.toLowerCase().includes(q) ||
          row.blockName.toLowerCase().includes(q) ||
          row.floorName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [occupancyRows, selectedHostelFilter, searchQuery]);

  // Active Allotments for Register
  const activeAllotments = useMemo(() => {
    return allotments
      .filter((a) => a.status === 'active')
      .filter((a) => {
        if (selectedHostelFilter !== 'ALL' && a.hostelId !== selectedHostelFilter) {
          return false;
        }
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return (
            a.studentName.toLowerCase().includes(q) ||
            a.studentRegistrationNumber.toLowerCase().includes(q) ||
            a.roomNumber.toLowerCase().includes(q) ||
            a.hostelName.toLowerCase().includes(q)
          );
        }
        return true;
      });
  }, [allotments, selectedHostelFilter, searchQuery]);

  // Filtered Audit Log
  const filteredAuditLog = useMemo(() => {
    return allotmentHistory
      .slice()
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .map((item) => {
        const previousLocation = item.previousRoomNumber
          ? `${item.previousHostelName || ''} - Rm ${item.previousRoomNumber} (Bed ${item.previousBedNumber})`
          : '—';
        const newLocation = item.newRoomNumber
          ? `${item.newHostelName || ''} - Rm ${item.newRoomNumber} (Bed ${item.newBedNumber})`
          : '—';
        return {
          ...item,
          previousLocation,
          newLocation,
        };
      })
      .filter((item) => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          return (
            (item.studentName || '').toLowerCase().includes(q) ||
            item.studentId.toLowerCase().includes(q) ||
            item.action.toLowerCase().includes(q) ||
            item.newLocation.toLowerCase().includes(q) ||
            item.previousLocation.toLowerCase().includes(q) ||
            (item.reason || '').toLowerCase().includes(q)
          );
        }
        return true;
      });
  }, [allotmentHistory, searchQuery]);

  // Export CSV Handler
  const handleExportCSV = () => {
    let csvContent = '';
    let filename = 'hostel_report.csv';

    if (activeReport === 'occupancy') {
      csvContent =
        'Hostel,Block,Floor,Room,Type,Capacity,Configured Beds,Occupied,Available,Blocked,Occupancy Rate (%)\n';
      occupancyRows.forEach((r) => {
        csvContent += `"${r.hostelName}","${r.blockName}","${r.floorName}","${r.room.roomNumber}","${r.room.roomType}",${r.capacity},${r.totalBeds},${r.occupiedCount},${r.availableCount},${r.blockedCount},${r.occupancyRate}\n`;
      });
      filename = 'hostel_occupancy_report.csv';
    } else if (activeReport === 'allotment_register') {
      csvContent =
        'Registration No,Student Name,Hostel,Block,Floor,Room,Bed,Session,Allotment Date,Allotted By\n';
      activeAllotments.forEach((a) => {
        csvContent += `"${a.studentRegistrationNumber}","${a.studentName}","${a.hostelName}","${a.blockName}","${a.floorName}","${a.roomNumber}","${a.bedNumber}","${a.academicSession}","${a.allotmentDate}","${a.allottedBy}"\n`;
      });
      filename = 'student_hostel_allotment_register.csv';
    } else {
      csvContent =
        'Timestamp,Action,Student ID,Student Name,Previous Location,New Location,Actor,Reason\n';
      filteredAuditLog.forEach((item) => {
        csvContent += `"${item.timestamp}","${item.action}","${item.studentId}","${item.studentName || ''}","${item.previousLocation}","${item.newLocation}","${item.actor}","${item.reason || ''}"\n`;
      });
      filename = 'hostel_allotment_audit_log.csv';
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Report Switcher */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">
            Hostel Residential Reports & Analytics
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Institutional occupancy matrices, authorized student resident registers, and complete historical audit trails.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCSV}
            leftIcon={<Download className="w-4 h-4" />}
          >
            Export to CSV
          </Button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="flex items-center gap-2 border-b border-[#e2e8f0] pb-3 overflow-x-auto">
        <button
          onClick={() => setActiveReport('occupancy')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
            activeReport === 'occupancy'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'bg-white text-[#64748b] border border-[#e2e8f0] hover:bg-[#f8fafc]'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Room & Bed Occupancy Report</span>
        </button>

        <button
          onClick={() => setActiveReport('allotment_register')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
            activeReport === 'allotment_register'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'bg-white text-[#64748b] border border-[#e2e8f0] hover:bg-[#f8fafc]'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Student Allotment Register ({activeAllotments.length})</span>
        </button>

        <button
          onClick={() => setActiveReport('audit_log')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1.5 ${
            activeReport === 'audit_log'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'bg-white text-[#64748b] border border-[#e2e8f0] hover:bg-[#f8fafc]'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Allotment Audit & Movement Log ({filteredAuditLog.length})</span>
        </button>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search report entries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
          />
        </div>

        {activeReport !== 'audit_log' && (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedHostelFilter}
              onChange={(e) => setSelectedHostelFilter(e.target.value)}
              className="text-xs py-1.5 px-3 bg-[#f8fafc] border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
            >
              <option value="ALL">All Hostels</option>
              {hostels.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.hostelName} ({h.hostelCode})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* REPORT 1: OCCUPANCY REPORT */}
      {activeReport === 'occupancy' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Hostel & Block</th>
                  <th className="py-3 px-4 font-semibold">Floor & Room</th>
                  <th className="py-3 px-4 font-semibold">Room Type</th>
                  <th className="py-3 px-4 font-semibold text-center">Capacity</th>
                  <th className="py-3 px-4 font-semibold text-center">Occupied</th>
                  <th className="py-3 px-4 font-semibold text-center">Available</th>
                  <th className="py-3 px-4 font-semibold text-center">Blocked</th>
                  <th className="py-3 px-4 font-semibold">Occupancy Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredOccupancyRows.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-[#64748b]">
                      No rooms found matching the criteria.
                    </td>
                  </tr>
                ) : (
                  filteredOccupancyRows.map((row) => (
                    <tr key={row.room.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#1e293b]">{row.hostelName}</div>
                        <div className="text-[10px] text-[#64748b]">{row.blockName}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#1e3a8a]">Room {row.room.roomNumber}</div>
                        <div className="text-[10px] text-[#64748b]">{row.floorName}</div>
                      </td>
                      <td className="py-3 px-4 text-[#334155]">{row.room.roomType}</td>
                      <td className="py-3 px-4 text-center font-semibold text-[#1e293b]">
                        {row.capacity}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-bold text-emerald-700">{row.occupiedCount}</span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-bold text-blue-700">{row.availableCount}</span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-bold text-amber-700">{row.blockedCount}</span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <div className="w-20 bg-[#f1f5f9] h-2 rounded-full overflow-hidden">
                            <div
                              className="bg-[#10b981] h-full"
                              style={{ width: `${Math.min(row.occupancyRate, 100)}%` }}
                            />
                          </div>
                          <span className="font-semibold text-[11px] text-[#1e293b]">
                            {row.occupancyRate}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 2: ALLOTMENT REGISTER */}
      {activeReport === 'allotment_register' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Student Name & Reg No</th>
                  <th className="py-3 px-4 font-semibold">Hostel & Block</th>
                  <th className="py-3 px-4 font-semibold">Room & Bed</th>
                  <th className="py-3 px-4 font-semibold">Session</th>
                  <th className="py-3 px-4 font-semibold">Allotment Date</th>
                  <th className="py-3 px-4 font-semibold">Allotted By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {activeAllotments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#64748b]">
                      No active student allotments found matching the filter.
                    </td>
                  </tr>
                ) : (
                  activeAllotments.map((alt) => (
                    <tr key={alt.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-[#1e293b]">{alt.studentName}</div>
                        <div className="text-[10px] text-[#64748b] font-mono">
                          {alt.studentRegistrationNumber}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#1e3a8a]">{alt.hostelName}</div>
                        <div className="text-[10px] text-[#64748b]">{alt.blockName}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-[#334155]">Room {alt.roomNumber}</span>{' '}
                        &bull; <span className="font-bold text-[#166534]">Bed {alt.bedNumber}</span>
                        <div className="text-[10px] text-[#64748b]">{alt.floorName}</div>
                      </td>
                      <td className="py-3 px-4 text-[#475569]">{alt.academicSession}</td>
                      <td className="py-3 px-4 font-mono text-[#64748b]">
                        {new Date(alt.allotmentDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-[#334155]">{alt.allottedBy}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 3: AUDIT & MOVEMENT LOG */}
      {activeReport === 'audit_log' && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Timestamp</th>
                  <th className="py-3 px-4 font-semibold">Action</th>
                  <th className="py-3 px-4 font-semibold">Student</th>
                  <th className="py-3 px-4 font-semibold">Previous Location</th>
                  <th className="py-3 px-4 font-semibold">New Location</th>
                  <th className="py-3 px-4 font-semibold">Authorized Actor</th>
                  <th className="py-3 px-4 font-semibold">Reason</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {filteredAuditLog.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-[#64748b]">
                      No audit history log records found.
                    </td>
                  </tr>
                ) : (
                  filteredAuditLog.map((log) => (
                    <tr key={log.id} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="py-3 px-4 font-mono text-[10px] text-[#64748b] whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <Badge
                          variant={
                            log.action === 'ALLOTMENT'
                              ? 'emerald'
                              : log.action === 'TRANSFER'
                              ? 'blue'
                              : log.action === 'VACATE'
                              ? 'amber'
                              : 'rose'
                          }
                          size="sm"
                        >
                          {log.action}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-bold text-[#1e293b]">
                        {log.studentName || log.studentId}
                      </td>
                      <td className="py-3 px-4 text-[#64748b]">
                        {log.previousLocation}
                      </td>
                      <td className="py-3 px-4 font-semibold text-[#1e3a8a]">
                        {log.newLocation}
                      </td>
                      <td className="py-3 px-4 text-[#334155]">{log.actor}</td>
                      <td className="py-3 px-4 text-[#475569] italic">
                        {log.reason || '—'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
