import React from 'react';
import {
  Building2,
  Layers,
  DoorOpen,
  BedDouble,
  Users,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Percent,
  PlusCircle,
  UserPlus,
} from 'lucide-react';
import { HostelDashboardMetrics, Hostel } from '../../types/hostel';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface HostelDashboardViewProps {
  metrics: HostelDashboardMetrics;
  hostels: Hostel[];
  onNavigateTab: (tab: 'dashboard' | 'management' | 'students' | 'reports') => void;
  onOpenNewHostelModal?: () => void;
}

export function HostelDashboardView({
  metrics,
  hostels,
  onNavigateTab,
}: HostelDashboardViewProps) {
  const statCards = [
    {
      id: 'metric-hostels',
      label: 'Total Hostels',
      value: metrics.totalHostels,
      subtext: 'Campus residential buildings',
      icon: Building2,
      color: 'blue' as const,
      textColor: 'text-blue-700',
      bgColor: 'bg-blue-50',
    },
    {
      id: 'metric-blocks',
      label: 'Total Blocks',
      value: metrics.totalBlocks,
      subtext: 'Wings & building sections',
      icon: Layers,
      color: 'purple' as const,
      textColor: 'text-purple-700',
      bgColor: 'bg-purple-50',
    },
    {
      id: 'metric-rooms',
      label: 'Total Rooms',
      value: metrics.totalRooms,
      subtext: 'Configured dorm units',
      icon: DoorOpen,
      color: 'neutral' as const,
      textColor: 'text-slate-700',
      bgColor: 'bg-slate-50',
    },
    {
      id: 'metric-beds',
      label: 'Total Beds / Seats',
      value: metrics.totalBeds,
      subtext: 'Authorized inventory capacity',
      icon: BedDouble,
      color: 'emerald' as const,
      textColor: 'text-emerald-700',
      bgColor: 'bg-emerald-50',
    },
  ];

  const occupancyCards = [
    {
      id: 'metric-occupied',
      label: 'Occupied Beds',
      value: metrics.occupiedBeds,
      subtext: 'Active residents currently housed',
      icon: Users,
      badge: 'Occupied',
      badgeVariant: 'emerald' as const,
    },
    {
      id: 'metric-available',
      label: 'Available Beds',
      value: metrics.availableBeds,
      subtext: 'Ready for student allotment',
      icon: CheckCircle2,
      badge: 'Available',
      badgeVariant: 'blue' as const,
    },
    {
      id: 'metric-blocked',
      label: 'Blocked / Maintenance',
      value: metrics.blockedBeds,
      subtext: 'Temporarily unavailable beds',
      icon: AlertCircle,
      badge: 'Blocked',
      badgeVariant: 'amber' as const,
    },
    {
      id: 'metric-rate',
      label: 'Occupancy Rate',
      value: `${metrics.occupancyPercentage}%`,
      subtext: `${metrics.studentsCurrentlyAllotted} verified student residents`,
      icon: Percent,
      badge: metrics.occupancyPercentage > 90 ? 'High' : 'Normal',
      badgeVariant: metrics.occupancyPercentage > 90 ? ('rose' as const) : ('secondary' as const),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Action Bar */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#1e293b]">
            Hostel Residential Administration
          </h1>
          <p className="text-xs sm:text-sm text-[#64748b] mt-0.5">
            Real-time residential occupancy, room inventory hierarchy, and student bed allocation status.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('management')}
            leftIcon={<Building2 className="w-4 h-4" />}
          >
            Manage Hostels
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={() => onNavigateTab('students')}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Allot Student Bed
          </Button>
        </div>
      </div>

      {/* Primary Infrastructure Metric Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              id={card.id}
              className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
                  {card.label}
                </span>
                <div className={`p-2 rounded-lg ${card.bgColor} ${card.textColor}`}>
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div>
                <span className="text-2xl sm:text-3xl font-bold text-[#1e293b]">
                  {card.value}
                </span>
                <p className="text-[11px] text-[#94a3b8] mt-1 truncate">
                  {card.subtext}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Secondary Occupancy Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {occupancyCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.id}
              id={card.id}
              className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-[#64748b]">
                  {card.label}
                </span>
                <Badge variant={card.badgeVariant} size="sm">
                  {card.badge}
                </Badge>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-[#1e293b]">
                  {card.value}
                </span>
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1 truncate">
                {card.subtext}
              </p>
            </div>
          );
        })}
      </div>

      {/* Occupancy Progress Bar */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">
              Campus Residential Utilization
            </h2>
          </div>
          <span className="text-xs font-semibold text-[#1e3a8a]">
            {metrics.occupiedBeds} / {metrics.totalBeds} Beds Filled ({metrics.occupancyPercentage}%)
          </span>
        </div>

        <div className="w-full bg-[#f1f5f9] h-3 rounded-full overflow-hidden flex">
          <div
            className="bg-[#10b981] h-full transition-all duration-500"
            style={{ width: `${Math.min(metrics.occupancyPercentage, 100)}%` }}
            title={`Occupied: ${metrics.occupiedBeds}`}
          />
          <div
            className="bg-[#f59e0b] h-full transition-all duration-500"
            style={{
              width: `${metrics.totalBeds > 0 ? (metrics.blockedBeds / metrics.totalBeds) * 100 : 0}%`,
            }}
            title={`Blocked: ${metrics.blockedBeds}`}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-[#64748b] pt-1">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]" />
              <span>Occupied ({metrics.occupiedBeds})</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]" />
              <span>Available ({metrics.availableBeds})</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />
              <span>Blocked ({metrics.blockedBeds})</span>
            </span>
          </div>
          <span>Total Capacity: {metrics.totalBeds}</span>
        </div>
      </div>

      {/* Hostel-wise Quick Overview Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-[#1e293b]">
              Hostel Residential Units Overview
            </h3>
            <p className="text-xs text-[#64748b] mt-0.5">
              Breakdown of registered campus halls, warden supervision, and operational status.
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('management')}
          >
            View Full Inventory
          </Button>
        </div>

        {hostels.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#64748b]">
            <Building2 className="w-8 h-8 text-[#94a3b8] mx-auto mb-2 opacity-50" />
            <p className="font-semibold text-sm text-[#1e293b]">No Hostels Configured Yet</p>
            <p className="mt-1">Go to Hostel Management to add your first campus residential hall.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0]">
                  <th className="py-3 px-4 font-semibold">Hostel Code & Name</th>
                  <th className="py-3 px-4 font-semibold">Type</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Chief Warden</th>
                  <th className="py-3 px-4 font-semibold">Contact</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {hostels.map((h) => (
                  <tr key={h.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-bold text-[#1e293b]">{h.hostelName}</span>
                        <span className="text-[10px] text-[#64748b] font-mono">{h.hostelCode}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 capitalize">
                      <Badge
                        variant={
                          h.hostelType === 'Boys'
                            ? 'blue'
                            : h.hostelType === 'Girls'
                            ? 'purple'
                            : 'neutral'
                        }
                        size="sm"
                      >
                        {h.hostelType}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <span className="capitalize font-medium text-[#334155]">{h.category}</span>
                    </td>
                    <td className="py-3 px-4 text-[#334155]">
                      {h.wardenName || 'Not Assigned'}
                    </td>
                    <td className="py-3 px-4 text-[#64748b] font-mono text-[11px]">
                      {h.wardenContact || '—'}
                    </td>
                    <td className="py-3 px-4">
                      <Badge
                        variant={h.status === 'active' ? 'emerald' : 'rose'}
                        size="sm"
                      >
                        {h.status === 'active' ? 'Active' : 'Inactive'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
