import React from 'react';
import { Home, LogOut, User, Building2, RefreshCw } from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface HostelHeaderProps {
  user: UserSession;
  onLogout: () => void;
  onRefresh?: () => void;
  isSyncing?: boolean;
}

export function HostelHeader({
  user,
  onLogout,
  onRefresh,
  isSyncing = false,
}: HostelHeaderProps) {
  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Portal Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-[#1e293b] text-base tracking-tight">
                  Electrix Institute of Technology (EIT)
                </span>
                <span className="text-xs text-[#94a3b8]">&bull;</span>
                <Badge variant="blue">Hostel Office</Badge>
              </div>
              <p className="text-xs text-[#64748b] hidden sm:block">
                Residential Hall & Hostel Administration &bull; Room & Bed Allocation
              </p>
            </div>
          </div>

          {/* User Controls & Logout */}
          <div className="flex items-center gap-3">
            {onRefresh && (
              <Button
                variant="outline"
                size="sm"
                onClick={onRefresh}
                disabled={isSyncing}
                leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-[#1e3a8a]' : ''}`} />}
              >
                <span className="hidden sm:inline">Refresh Sync</span>
              </Button>
            )}

            <div className="flex items-center gap-2 bg-[#f8fafc] border border-[#e2e8f0] rounded-lg px-3 py-1.5 text-xs text-[#475569]">
              <User className="w-3.5 h-3.5 text-[#64748b]" />
              <div className="flex flex-col text-left">
                <span className="font-semibold text-[#1e293b] leading-tight">
                  {user.name}
                </span>
                <span className="text-[10px] text-[#64748b] uppercase font-mono">
                  {user.username} &bull; {user.roleTitle || 'Hostel Office'}
                </span>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={onLogout}
              leftIcon={<LogOut className="w-4 h-4" />}
            >
              <span className="hidden sm:inline">Sign Out</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
