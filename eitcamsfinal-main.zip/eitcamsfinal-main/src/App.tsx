import { useCallback, useEffect, useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomeGatewayView } from './views/HomeGatewayView';
import { PortalLoginView } from './views/PortalLoginView';
import { StudentDashboardView } from './views/StudentDashboardView';
import { EmployeeDashboardView } from './views/EmployeeDashboardView';
import { ParentDashboardView } from './views/ParentDashboardView';
import { ActiveRoute, PortalType } from './types/portal';
import { getPortalConfig, INSTITUTE_INFO } from './config/portals';
import { AuthProvider, useAuth } from './context/AuthContext';

function parseRouteFromHash(hash: string): ActiveRoute {
  const normalized = hash.replace(/^#\/?/, '').trim().toLowerCase();

  // Dashboard routes
  if (normalized === 'dashboard/student') {
    return { view: 'dashboard', portal: PortalType.Student };
  }
  if (normalized === 'dashboard/employee') {
    return { view: 'dashboard', portal: PortalType.Employee };
  }
  if (normalized === 'dashboard/parent') {
    return { view: 'dashboard', portal: PortalType.Parent };
  }

  // Login routes
  if (normalized === 'login/student' || normalized === 'student') {
    return { view: 'login', portal: PortalType.Student };
  }
  if (normalized === 'login/employee' || normalized === 'employee') {
    return { view: 'login', portal: PortalType.Employee };
  }
  if (normalized === 'login/parent' || normalized === 'parent') {
    return { view: 'login', portal: PortalType.Parent };
  }

  return { view: 'home' };
}

function MainAppShell() {
  const [route, setRoute] = useState<ActiveRoute>(() =>
    parseRouteFromHash(window.location.hash)
  );

  const { isAuthenticated, session, activeOfficeKey } = useAuth();

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(parseRouteFromHash(window.location.hash));
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  // Route Guard enforcement
  useEffect(() => {
    if (route.view === 'dashboard' && !isAuthenticated) {
      // Unauthenticated access to dashboard redirects to respective login portal
      const targetHash = `#/login/${route.portal}`;
      window.location.hash = targetHash;
      setRoute({ view: 'login', portal: route.portal });
    } else if (route.view === 'dashboard' && isAuthenticated && session) {
      // Guard against mismatched portals (e.g., student accessing employee dashboard)
      if (session.portalType !== route.portal) {
        const authorizedHash = `#/dashboard/${session.portalType}`;
        window.location.hash = authorizedHash;
        setRoute({ view: 'dashboard', portal: session.portalType });
      }
    }
  }, [route, isAuthenticated, session]);

  // Update document title dynamically
  useEffect(() => {
    if (route.view === 'home') {
      document.title = `${INSTITUTE_INFO.name} — Academic & Administrative Gateway`;
    } else if (route.view === 'login') {
      const portalConfig = getPortalConfig(route.portal);
      document.title = `${portalConfig.loginHeading} — ${INSTITUTE_INFO.name}`;
    } else if (route.view === 'dashboard') {
      const portalName = route.portal.charAt(0).toUpperCase() + route.portal.slice(1);
      document.title = `${portalName} Dashboard — ${INSTITUTE_INFO.name}`;
    }
  }, [route]);

  const navigateToPortal = useCallback((portal: PortalType) => {
    const targetHash = `#/login/${portal}`;
    if (window.location.hash !== targetHash) {
      window.location.hash = targetHash;
    }
    setRoute({ view: 'login', portal });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const navigateToHome = useCallback(() => {
    if (window.location.hash) {
      window.history.pushState(null, '', window.location.pathname + window.location.search);
    }
    setRoute({ view: 'home' });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const handleLoginSuccess = useCallback((portalType: PortalType) => {
    const targetHash = `#/dashboard/${portalType}`;
    window.location.hash = targetHash;
    setRoute({ view: 'dashboard', portal: portalType });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const isAcademicOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'academic' ||
      session?.activeOfficeKey?.toLowerCase() === 'academic' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'academic' ||
      session?.user?.username === 'academicoffice');

  const isAdmissionsOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'admissions' ||
      session?.activeOfficeKey?.toLowerCase() === 'admissions' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'admissions' ||
      session?.user?.username === 'admissionsoffice');

  const isCoeOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'coe' ||
      session?.activeOfficeKey?.toLowerCase() === 'coe' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'coe' ||
      session?.user?.username === 'coeoffice');

  const isFinanceOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'finance' ||
      session?.activeOfficeKey?.toLowerCase() === 'finance' ||
      session?.permanentOffice?.office_id === 'PO-005' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'finance' ||
      session?.user?.username === 'finance' ||
      session?.user?.username === 'financeoffice');

  const isHostelOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'hostel' ||
      session?.activeOfficeKey?.toLowerCase() === 'hostel' ||
      session?.permanentOffice?.office_id === 'PO-006' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'hostel' ||
      session?.user?.username === 'hostel' ||
      session?.user?.username === 'hosteloffice');

  const isItOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (activeOfficeKey?.toLowerCase() === 'it' ||
      session?.activeOfficeKey?.toLowerCase() === 'it' ||
      session?.permanentOffice?.office_id === 'PO-007' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'it' ||
      session?.user?.username === 'itoffice');

  const isStudentPortal =
    route.view === 'dashboard' && isAuthenticated && route.portal === PortalType.Student;

  const isParentPortal =
    route.view === 'dashboard' && isAuthenticated && route.portal === PortalType.Parent;

  const isFacultyActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    (session?.role === 'FACULTY' ||
      session?.employeeProfile?.category === 'TEACHING' ||
      session?.user?.role === 'FACULTY' ||
      session?.user?.username?.toLowerCase().startsWith('dr.'));

  const isAdministrationOfficeActive =
    route.view === 'dashboard' &&
    isAuthenticated &&
    route.portal === PortalType.Employee &&
    !isFacultyActive &&
    (activeOfficeKey?.toLowerCase() === 'administration' ||
      (!activeOfficeKey && (
        session?.permanentOffice?.office_id === 'PO-001' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'administration' ||
        session?.role === 'SUPER_ADMIN' ||
        session?.user?.username === 'admin'
      )));

  const suppressOuterChrome =
    isStudentPortal ||
    isParentPortal ||
    isAcademicOfficeActive ||
    isAdmissionsOfficeActive ||
    isCoeOfficeActive ||
    isFinanceOfficeActive ||
    isHostelOfficeActive ||
    isItOfficeActive ||
    isFacultyActive ||
    isAdministrationOfficeActive;


  return (
    <div className="min-h-screen flex flex-col bg-[#F6F8FB] text-slate-900">
      {!suppressOuterChrome && (
        <Header onNavigateHome={navigateToHome} isHome={route.view === 'home'} />
      )}

      <main className={`flex-1 flex flex-col ${suppressOuterChrome ? '' : 'justify-center'}`}>
        {route.view === 'home' && (
          <HomeGatewayView onSelectPortal={navigateToPortal} />
        )}

        {route.view === 'login' && (
          <PortalLoginView
            portalId={route.portal}
            onBackToHome={navigateToHome}
            onLoginSuccess={handleLoginSuccess}
          />
        )}

        {route.view === 'dashboard' && isAuthenticated && (
          <>
            {route.portal === PortalType.Student && <StudentDashboardView />}
            {route.portal === PortalType.Employee && <EmployeeDashboardView />}
            {route.portal === PortalType.Parent && <ParentDashboardView />}
          </>
        )}
      </main>

      {!suppressOuterChrome && <Footer />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppShell />
    </AuthProvider>
  );
}
