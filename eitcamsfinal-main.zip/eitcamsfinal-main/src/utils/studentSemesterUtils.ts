/**
 * Semester Utility Functions for Student Portal Modules
 */

import { Student, Examination, StudentExamResult } from '../types/studentPortalTypes';

export interface GetAvailableSemestersParams {
  student?: Student | null;
  examinations?: Examination[];
  results?: StudentExamResult[];
  marks?: any[];
  attendanceRecords?: any[];
  registrations?: any[];
}

export function getStudentAvailableSemesters(params: GetAvailableSemestersParams): string[] {
  const semesterSet = new Set<string>();

  // 1. From student enrolled semester
  if (params.student?.currentSemester) {
    const curr = params.student.currentSemester.trim();
    semesterSet.add(curr);
    // Parse numeric semester like "Semester 3" -> add previous semesters as well
    const match = curr.match(/(\d+)/);
    if (match) {
      const num = parseInt(match[1], 10);
      for (let i = 1; i <= Math.max(num, 3); i++) {
        semesterSet.add(`Semester ${i}`);
      }
    }
  }

  // 2. From results
  if (params.results && params.results.length > 0) {
    params.results.forEach((r) => {
      if (r.semester) semesterSet.add(r.semester);
    });
  }

  // 3. From examinations
  if (params.examinations && params.examinations.length > 0) {
    params.examinations.forEach((e) => {
      if (e.academicSession) semesterSet.add(e.academicSession);
      if (e.session) semesterSet.add(e.session);
    });
  }

  // 4. Default fallback if empty
  if (semesterSet.size === 0) {
    semesterSet.add('Semester 1');
    semesterSet.add('Semester 2');
    semesterSet.add('Semester 3');
  }

  return Array.from(semesterSet).sort();
}

export function doesExamMatchSemester(exam: Examination, selectedSemester: string): boolean {
  if (!selectedSemester || selectedSemester === 'All') return true;
  const target = selectedSemester.trim().toLowerCase();
  const session = (exam.session || '').trim().toLowerCase();
  const academicSession = (exam.academicSession || '').trim().toLowerCase();
  const name = (exam.name || '').trim().toLowerCase();

  return (
    session === target ||
    academicSession === target ||
    name.includes(target) ||
    session.includes(target)
  );
}

export function doesResultMatchSemester(
  result: StudentExamResult,
  selectedSemester: string,
  examinations?: Examination[]
): boolean {
  if (!selectedSemester || selectedSemester === 'All') return true;
  const target = selectedSemester.trim().toLowerCase();

  if (result.semester && result.semester.trim().toLowerCase() === target) {
    return true;
  }

  if (examinations && result.examinationId) {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === result.examinationId.toLowerCase()
    );
    if (parentExam && doesExamMatchSemester(parentExam, selectedSemester)) {
      return true;
    }
  }

  return false;
}
