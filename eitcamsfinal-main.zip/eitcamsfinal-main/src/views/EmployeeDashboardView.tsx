import { FormEvent, useEffect, useMemo, useState, useCallback } from 'react';
import {
  AlertCircle,
  ArrowRightLeft,
  Award,
  BookOpen,
  Building2,
  Calendar,
  CalendarCheck,
  Check,
  CheckCircle2,
  ChevronDown,
  Copy,
  CreditCard,
  DollarSign,
  Edit3,
  ExternalLink,
  Eye,
  FileCheck2,
  Filter,
  Home,
  Info,
  KeyRound,
  Layers,
  LayoutGrid,
  Lock,
  Mail,
  Phone,
  PlusCircle,
  RefreshCw,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Sparkles,
  Trash2,
  UploadCloud,
  UserCheck2,
  UserPlus,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  AttendanceRecord,
  AttendanceStatus,
  AuthRole,
  EmployeeCategory,
  EmployeeRecord,
  EmploymentStatus,
  ExaminationRecord,
  ExamStatus,
  FacultyCourseAssignmentRecord,
  FacultyCourseRole,
  FinanceRecord,
  HostelAllocationStatus,
  HostelRecord,
  OfficeAssignmentRecord,
  OfficeAssignmentStatus,
  OfficePermissionRecord,
  PaymentStatus,
  PermanentOfficeKey,
  PermanentOfficeRecord,
  PermissionScope,
  StudentRecord,
  StudentStatus,
  CourseEnrolmentRecord,
  DepartmentRecord,
} from '../types/database';
import { SIX_PERMANENT_OFFICES } from '../config/permanentOffices';
import { allocateNextEmployeeRegistrationNumber, allocateNextStudentRegistrationNumber } from '../services/regNumberGenerator';
import { AdmissionsOfficeSection } from '../components/AdmissionsOfficeSection';
import { AcademicOfficeSection } from '../components/AcademicOfficeSection';
import { CoeOfficeSection } from '../components/CoeOfficeSection';
import { FinanceOfficeSection } from '../components/FinanceOfficeSection';
import { HostelOfficeSection } from '../components/HostelOfficeSection';
import { ItOfficeSection } from '../components/ItOfficeSection';
import { AdministrationOverviewSection } from '../components/AdministrationOverviewSection';
import { AdministrationBulkImportSection } from '../components/AdministrationBulkImportSection';
import { AdministrationSettingsSection } from '../components/AdministrationSettingsSection';
import { AddEmployeeModal } from '../components/AddEmployeeModal';
import { FacultyWorkspace } from '../components/faculty/FacultyWorkspace';
import { AdminWorkspace } from '../components/admin/AdminWorkspace';
import { useActiveAcademicYear } from '../services/academicCalendarService';

export function EmployeeDashboardView() {
  const { session, dataAdapter, activeOfficeKey, switchActiveOffice } = useAuth();
  const { activeAcademicYear } = useActiveAcademicYear();

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [empSubTab, setEmpSubTab] = useState<'directory' | 'assignments' | 'permissions' | 'offices'>('directory');
  const [isAddEmployeeModalOpen, setIsAddEmployeeModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Primary state
  const [offices, setOffices] = useState<PermanentOfficeRecord[]>([]);
  const [employees, setEmployees] = useState<EmployeeRecord[]>([]);
  const [departments, setDepartments] = useState<DepartmentRecord[]>([]);
  const [officeAssignments, setOfficeAssignments] = useState<OfficeAssignmentRecord[]>([]);
  const [officePermissions, setOfficePermissions] = useState<OfficePermissionRecord[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyCourseAssignmentRecord[]>([]);
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [invoices, setInvoices] = useState<FinanceRecord[]>([]);
  const [hostelAllocations, setHostelAllocations] = useState<any[]>([]);
  const [examinations, setExaminations] = useState<ExaminationRecord[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Success / Notice message banners
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Forms: 1. Add Employee (Administration Super Admin)
  const [newEmpCategory, setNewEmpCategory] = useState<EmployeeCategory>(EmployeeCategory.TEACHING);
  const [newEmpDept, setNewEmpDept] = useState('CSE');
  const [newEmpFirstName, setNewEmpFirstName] = useState('');
  const [newEmpLastName, setNewEmpLastName] = useState('');
  const [newEmpPhone, setNewEmpPhone] = useState('+1 (555) 234-5678');
  const [newEmpEmail, setNewEmpEmail] = useState('');
  const [newEmpDesignation, setNewEmpDesignation] = useState('Assistant Professor');
  const [newEmpDateOfJoining, setNewEmpDateOfJoining] = useState(() => new Date().toISOString().split('T')[0]);
  const [newEmpStatus, setNewEmpStatus] = useState<EmploymentStatus>(EmploymentStatus.ACTIVE);
  const [isSubmittingEmp, setIsSubmittingEmp] = useState(false);
  const [empFormError, setEmpFormError] = useState<string | null>(null);

  // Directory Filters
  const [empCategoryFilter, setEmpCategoryFilter] = useState<'ALL' | EmployeeCategory>('ALL');
  const [empStatusFilter, setEmpStatusFilter] = useState<'ALL' | EmploymentStatus>('ALL');
  const [empDeptFilter, setEmpDeptFilter] = useState<string>('ALL');

  // Inspection & Editing Modals
  const [inspectingEmployee, setInspectingEmployee] = useState<EmployeeRecord | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<EmployeeRecord | null>(null);
  const [editPhone, setEditPhone] = useState('');
  const [editDept, setEditDept] = useState('');
  const [editDesignation, setEditDesignation] = useState('');
  const [editStatus, setEditStatus] = useState<EmploymentStatus>(EmploymentStatus.ACTIVE);
  const [editEmail, setEditEmail] = useState('');
  const [isSubmittingEdit, setIsSubmittingEdit] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Forms: 2. Assign Non-Teaching Staff (Administration Super Admin)
  const [selectedStaffId, setSelectedStaffId] = useState('');
  const [selectedTargetOfficeId, setSelectedTargetOfficeId] = useState('PO-005');
  const [assignRoleTitle, setAssignRoleTitle] = useState('');
  const [assignEffectiveFrom, setAssignEffectiveFrom] = useState(() => new Date().toISOString().split('T')[0]);
  const [isSubmittingAssign, setIsSubmittingAssign] = useState(false);

  // Transfer & Revoke State
  const [transferringAssignment, setTransferringAssignment] = useState<OfficeAssignmentRecord | null>(null);
  const [transferTargetOfficeId, setTransferTargetOfficeId] = useState('PO-005');
  const [transferRoleTitle, setTransferRoleTitle] = useState('');
  const [isSubmittingTransfer, setIsSubmittingTransfer] = useState(false);
  const [transferError, setTransferError] = useState<string | null>(null);

  // Confirmation Modal
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    confirmLabel: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  } | null>(null);

  // Forms: 3. Grant Office Permission (Super Admin)
  const [permStaffId, setPermStaffId] = useState('');
  const [permOfficeId, setPermOfficeId] = useState('PO-005');
  const [permModule, setPermModule] = useState('FeeCollections');
  const [permScope, setPermScope] = useState<PermissionScope>(PermissionScope.WRITE);

  // Forms: 4. Student Intake Registration (Admissions Office)
  const [newStuFirstName, setNewStuFirstName] = useState('');
  const [newStuLastName, setNewStuLastName] = useState('');
  const [newStuDept, setNewStuDept] = useState('CSE');
  const [newStuProgram, setNewStuProgram] = useState('B.Tech Computer Science & Engineering');

  // Forms: 5. Assign Faculty to Course (Academic Office)
  const [fcaFacultyId, setFcaFacultyId] = useState('');
  const [fcaCourseCode, setFcaCourseCode] = useState('CS301');
  const [fcaCourseTitle, setFcaCourseTitle] = useState('Database Management Systems');
  const [fcaDept, setFcaDept] = useState('CSE');
  const [fcaSemester, setFcaSemester] = useState(3);
  const [fcaSection, setFcaSection] = useState('A');
  const [fcaRole, setFcaRole] = useState<FacultyCourseRole>(FacultyCourseRole.PRIMARY_INSTRUCTOR);

  // Forms: 6. Record/Moderate Examination Marks (COE Office)
  const [examStudentId, setExamStudentId] = useState('STU-001');
  const [examCourseCode, setExamCourseCode] = useState('CS201');
  const [examSessionName, setExamSessionName] = useState('FALL_2026_END_SEM');
  const [examHallTicket, setExamHallTicket] = useState('HT-FALL26-0042');
  const [examInternal, setExamInternal] = useState(36);
  const [examExternal, setExamExternal] = useState(52);
  const [examStatusVal, setExamStatusVal] = useState<ExamStatus>(ExamStatus.DECLARED);

  // Forms: 7. Generate Fee Invoice (Finance Office)
  const [finStudentId, setFinStudentId] = useState('STU-001');
  const [finCategory, setFinCategory] = useState('TUITION');
  const [finAmount, setFinAmount] = useState(3500);
  const [finSemester, setFinSemester] = useState(3);

  // Forms: 8. Allocate Hostel Room (Hostel Office)
  const [hstStudentId, setHstStudentId] = useState('STU-001');
  const [hstBlock, setHstBlock] = useState('Block A - Aryabhata Hall');
  const [hstRoom, setHstRoom] = useState('305');
  const [hstBed, setHstBed] = useState('A');
  const [hstEmergencyPhone, setHstEmergencyPhone] = useState('+1 (555) 901-2345');

  // Forms: 9. Mark Attendance (Faculty Dashboard)
  const [attCourseCode, setAttCourseCode] = useState('CS201');
  const [attStudentId, setAttStudentId] = useState('STU-001');
  const [attStatusVal, setAttStatusVal] = useState<AttendanceStatus>(AttendanceStatus.PRESENT);
  const [attRemarksVal, setAttRemarksVal] = useState('');

  // Teaching Faculty Workspace state
  const [viewingRosterAssignment, setViewingRosterAssignment] = useState<FacultyCourseAssignmentRecord | null>(null);
  const [rosterStudents, setRosterStudents] = useState<{ enrolment: CourseEnrolmentRecord; student: StudentRecord }[]>([]);
  const [isLoadingRoster, setIsLoadingRoster] = useState(false);
  const [rosterError, setRosterError] = useState<string | null>(null);

  // Faculty Attendance Roster state
  const [attRoster, setAttRoster] = useState<{ enrolment: CourseEnrolmentRecord; student: StudentRecord }[]>([]);
  const [isLoadingAttRoster, setIsLoadingAttRoster] = useState(false);

  // Faculty Internal Assessment Grading state
  const [facGradeCourse, setFacGradeCourse] = useState('');
  const [facGradeStudentId, setFacGradeStudentId] = useState('');
  const [facGradeSession, setFacGradeSession] = useState('FALL_2026_INTERNAL_1');
  const [facGradeInternalMarks, setFacGradeInternalMarks] = useState(32);
  const [facGradeRoster, setFacGradeRoster] = useState<{ enrolment: CourseEnrolmentRecord; student: StudentRecord }[]>([]);
  const [isLoadingGradeRoster, setIsLoadingGradeRoster] = useState(false);
  const [isSubmittingGrade, setIsSubmittingGrade] = useState(false);

  // Initial Data Fetch
  const loadAllData = useCallback(async () => {
    try {
      const [
        offs,
        emps,
        oAssigns,
        fAssigns,
        stus,
        invs,
        hsts,
        allExams,
        allAttendance,
        deptsList,
      ] = await Promise.all([
        dataAdapter.offices.getAllPermanent(),
        dataAdapter.employees.getAll(),
        dataAdapter.officeAssignments.getAll(),
        dataAdapter.facultyAssignments.getAll(),
        dataAdapter.students.getAll(),
        dataAdapter.finance.getAllInvoices(),
        dataAdapter.hostel.getAllAllocations(),
        dataAdapter.examinations.getAll ? dataAdapter.examinations.getAll() : Promise.resolve([]),
        dataAdapter.attendance.getAll ? dataAdapter.attendance.getAll() : Promise.resolve([]),
        dataAdapter.academic?.getDepartments ? dataAdapter.academic.getDepartments() : Promise.resolve([]),
      ]);

      setOffices(offs);
      setEmployees(emps);
      setOfficeAssignments(oAssigns);
      setFacultyAssignments(fAssigns);
      setStudents(stus);
      setInvoices(invs);
      setHostelAllocations(hsts);
      setExaminations(allExams);
      setAttendanceRecords(allAttendance);
      setDepartments(deptsList || []);

      const nonTeaching = emps.filter((e) => e.category === EmployeeCategory.NON_TEACHING);
      if (nonTeaching.length > 0) {
        setSelectedStaffId((prev) => prev || nonTeaching[0].employee_id);
        setPermStaffId((prev) => prev || nonTeaching[0].employee_id);
      }

      const teaching = emps.filter((e) => e.category === EmployeeCategory.TEACHING);
      if (teaching.length > 0) {
        setFcaFacultyId((prev) => prev || teaching[0].employee_id);
      }

      if (stus.length > 0) {
        setExamStudentId((prev) => prev || stus[0].student_id);
        setFinStudentId((prev) => prev || stus[0].student_id);
        setHstStudentId((prev) => prev || stus[0].student_id);
        setAttStudentId((prev) => prev || stus[0].student_id);
      }
    } finally {
      setIsLoading(false);
    }
  }, [dataAdapter]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Determine user mode
  const isFaculty = session?.role === AuthRole.FACULTY || session?.employeeProfile?.category === EmployeeCategory.TEACHING;
  const isSuperAdmin = session?.role === AuthRole.SUPER_ADMIN || session?.user.username === 'admin';
  const isNonTeachingStaff = session?.role === AuthRole.NON_TEACHING_STAFF || (session?.employeeProfile?.category === EmployeeCategory.NON_TEACHING && !isSuperAdmin);

  // Active office resolution
  const currentAssignedOffice = useMemo(() => {
    if (isSuperAdmin) {
      return SIX_PERMANENT_OFFICES.find((o) => o.canonical_username === 'admin');
    }
    if (session?.permanentOffice) {
      return session.permanentOffice;
    }
    if (session?.availableOffices && session.availableOffices.length > 0) {
      if (activeOfficeKey) {
        const found = session.availableOffices.find((o) => o.office_key === activeOfficeKey);
        if (found) return found;
      }
      return session.availableOffices[0];
    }
    return undefined;
  }, [isSuperAdmin, session, activeOfficeKey]);

  // Load employee's permissions if non-teaching staff
  useEffect(() => {
    let isMounted = true;
    const fetchPerms = async () => {
      if (currentAssignedOffice && dataAdapter.officePermissions.getByOffice) {
        const perms = await dataAdapter.officePermissions.getByOffice(currentAssignedOffice.office_id);
        if (isMounted) setOfficePermissions(perms);
      }
    };
    fetchPerms();
    return () => {
      isMounted = false;
    };
  }, [currentAssignedOffice, dataAdapter]);

  const activeOfficeUsername = currentAssignedOffice?.canonical_username || session?.user.username;

  // Set default tab when role/office context changes
  useEffect(() => {
    if (isFaculty) {
      setActiveTab('faculty_courses');
    } else if (activeOfficeKey === PermanentOfficeKey.ADMISSIONS || activeOfficeUsername === 'admissionsoffice') {
      setActiveTab('admissions');
    } else if (activeOfficeKey === PermanentOfficeKey.ACADEMIC || activeOfficeUsername === 'academicoffice') {
      setActiveTab('academic');
    } else if (activeOfficeKey === PermanentOfficeKey.COE || activeOfficeUsername === 'coeoffice') {
      setActiveTab('coe');
    } else if (activeOfficeKey === PermanentOfficeKey.FINANCE || activeOfficeUsername === 'finance') {
      setActiveTab('finance');
    } else if (activeOfficeKey === PermanentOfficeKey.HOSTEL || activeOfficeUsername === 'hosteloffice') {
      setActiveTab('hostel');
    } else if (activeOfficeKey === PermanentOfficeKey.IT || activeOfficeUsername === 'itoffice') {
      setActiveTab('it');
    } else if (isSuperAdmin) {
      setActiveTab('overview');
    }
  }, [isFaculty, isSuperAdmin, activeOfficeUsername, activeOfficeKey]);

  // ---------------------------------------------------------------------------
  // Action Handlers
  // ---------------------------------------------------------------------------

  // Live projected registration number preview
  const projectedRegNumber = useMemo(() => {
    const existingRegs = employees.map((emp) => emp.registration_number);
    const joiningYear = parseInt(newEmpDateOfJoining?.split('-')[0], 10) || 2026;
    return allocateNextEmployeeRegistrationNumber(
      existingRegs,
      newEmpCategory,
      newEmpDept,
      joiningYear
    );
  }, [employees, newEmpCategory, newEmpDept, newEmpDateOfJoining]);

  // Copy helper
  const handleCopy = (text: string) => {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedText(text);
      setTimeout(() => setCopiedText(null), 2000);
    }
  };

  // 1. Add Employee (Administration Super Admin)
  const handleAddEmployee = async (e: FormEvent) => {
    e.preventDefault();
    setEmpFormError(null);
    setActionErrorMsg(null);

    // Form Validation
    if (!newEmpFirstName.trim() || !newEmpLastName.trim()) {
      setEmpFormError('First Name and Last Name are required.');
      return;
    }
    if (!newEmpPhone.trim()) {
      setEmpFormError('Valid contact phone number is required.');
      return;
    }
    if (!newEmpDateOfJoining) {
      setEmpFormError('Date of joining is required.');
      return;
    }

    try {
      setIsSubmittingEmp(true);
      const email = newEmpEmail.trim() || `${newEmpFirstName.trim().toLowerCase()}.${newEmpLastName.trim().toLowerCase()}@eit.edu`;
      const joiningYear = parseInt(newEmpDateOfJoining.split('-')[0], 10) || 2026;
      const existingRegs = employees.map((emp) => emp.registration_number);
      const regNumber = allocateNextEmployeeRegistrationNumber(
        existingRegs,
        newEmpCategory,
        newEmpDept,
        joiningYear
      );

      const created = await dataAdapter.employees.create({
        registration_number: regNumber,
        category: newEmpCategory,
        first_name: newEmpFirstName.trim(),
        last_name: newEmpLastName.trim(),
        institutional_email: email,
        phone_number: newEmpPhone.trim(),
        primary_department: newEmpDept,
        designation: newEmpDesignation.trim() || (newEmpCategory === EmployeeCategory.TEACHING ? 'Assistant Professor' : 'Administrative Officer'),
        employment_status: newEmpStatus,
        date_of_joining: newEmpDateOfJoining,
      });

      setEmployees((prev) => [...prev, created]);
      setActionSuccessMsg(
        `Employee ${created.first_name} ${created.last_name} registered successfully! Unique ID: ${created.registration_number} (Repeat-safe Login Account provisioned).`
      );
      setIsAddEmployeeModalOpen(false);

      // Reset form
      setNewEmpFirstName('');
      setNewEmpLastName('');
      setNewEmpPhone('+1 (555) 234-5678');
      setNewEmpEmail('');
      setNewEmpDesignation(newEmpCategory === EmployeeCategory.TEACHING ? 'Assistant Professor' : 'Administrative Officer');
      setEmpFormError(null);
    } catch (err: any) {
      setEmpFormError(err?.message || 'Failed to register employee.');
    } finally {
      setIsSubmittingEmp(false);
    }
  };

  // Open Edit Permitted Details Modal
  const handleOpenEditModal = (emp: EmployeeRecord) => {
    setEditingEmployee(emp);
    setEditPhone(emp.phone_number);
    setEditDept(emp.primary_department);
    setEditDesignation(emp.designation);
    setEditStatus(emp.employment_status);
    setEditEmail(emp.institutional_email);
    setEditError(null);
  };

  // Save Edit Handler
  const handleSaveEdit = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;

    const isDeactivation = [
      EmploymentStatus.TERMINATED,
      EmploymentStatus.RESIGNED,
      EmploymentStatus.RETIRED,
    ].includes(editStatus);

    if (isDeactivation && editingEmployee.employment_status === EmploymentStatus.ACTIVE) {
      setConfirmDialog({
        isOpen: true,
        title: `Confirm Status Change: ${editStatus}`,
        description: `Changing employment status to ${editStatus} will suspend ${editingEmployee.first_name} ${editingEmployee.last_name}'s login account. Do you wish to proceed?`,
        confirmLabel: `Confirm ${editStatus}`,
        isDestructive: true,
        onConfirm: async () => {
          setConfirmDialog(null);
          await executeEmployeeUpdate();
        },
      });
      return;
    }

    await executeEmployeeUpdate();
  };

  const executeEmployeeUpdate = async () => {
    if (!editingEmployee) return;
    try {
      setIsSubmittingEdit(true);
      setEditError(null);
      const updated = await dataAdapter.employees.update(editingEmployee.employee_id, {
        phone_number: editPhone.trim(),
        primary_department: editDept.trim(),
        designation: editDesignation.trim(),
        employment_status: editStatus,
        institutional_email: editEmail.trim(),
      });

      setEmployees((prev) => prev.map((e) => (e.employee_id === updated.employee_id ? updated : e)));
      if (inspectingEmployee?.employee_id === updated.employee_id) {
        setInspectingEmployee(updated);
      }
      setActionSuccessMsg(`Employee details updated for ${updated.first_name} ${updated.last_name} (${updated.registration_number}).`);
      setEditingEmployee(null);
    } catch (err: any) {
      setEditError(err?.message || 'Failed to update employee details.');
    } finally {
      setIsSubmittingEdit(false);
    }
  };

  // 2. Assign Non-Teaching Staff (Admin)
  const isDuplicateAssignment = useMemo(() => {
    if (!selectedStaffId || !selectedTargetOfficeId) return false;
    return officeAssignments.some(
      (a) =>
        a.employee_id === selectedStaffId &&
        a.office_id === selectedTargetOfficeId &&
        a.assignment_status === OfficeAssignmentStatus.ACTIVE
    );
  }, [officeAssignments, selectedStaffId, selectedTargetOfficeId]);

  const handleAssignOffice = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedStaffId || !selectedTargetOfficeId) return;
    if (isDuplicateAssignment) {
      setActionErrorMsg('Staff member already has an active assignment in this permanent office. Please transfer or revoke the existing assignment instead.');
      return;
    }

    try {
      setIsSubmittingAssign(true);
      setActionErrorMsg(null);
      const assigned = await dataAdapter.officeAssignments.assign({
        employee_id: selectedStaffId,
        office_id: selectedTargetOfficeId,
        assigned_role_title: assignRoleTitle.trim() || 'Office Associate',
        assignment_status: OfficeAssignmentStatus.ACTIVE,
        assigned_by_employee_id: session?.user.user_id || 'USR-PO-001',
        effective_from: assignEffectiveFrom || new Date().toISOString().split('T')[0],
      });

      setOfficeAssignments((prev) => [...prev, assigned]);
      const targetOff = SIX_PERMANENT_OFFICES.find((o) => o.office_id === selectedTargetOfficeId);
      const emp = employees.find((e) => e.employee_id === selectedStaffId);
      setActionSuccessMsg(`Assigned ${emp?.first_name || 'Staff member'} to ${targetOff?.office_name || selectedTargetOfficeId} as ${assigned.assigned_role_title}.`);
      setAssignRoleTitle('');
    } catch (err: any) {
      setActionErrorMsg(err?.message || 'Failed to assign staff member.');
    } finally {
      setIsSubmittingAssign(false);
    }
  };

  // Transfer Assignment Modal & Action
  const handleOpenTransferModal = (assignment: OfficeAssignmentRecord) => {
    setTransferringAssignment(assignment);
    const otherOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id !== assignment.office_id);
    setTransferTargetOfficeId(otherOffice?.office_id || 'PO-005');
    setTransferRoleTitle(assignment.assigned_role_title);
    setTransferError(null);
  };

  const handleTransferAssignment = async (e: FormEvent) => {
    e.preventDefault();
    if (!transferringAssignment) return;
    try {
      setIsSubmittingTransfer(true);
      setTransferError(null);
      const newAssignment = await dataAdapter.officeAssignments.transfer(
        transferringAssignment.assignment_id,
        transferTargetOfficeId,
        transferRoleTitle
      );

      const targetOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id === transferTargetOfficeId);
      const emp = employees.find((e) => e.employee_id === transferringAssignment.employee_id);

      // Refresh assignments state
      const refreshed = await dataAdapter.officeAssignments.getAll();
      setOfficeAssignments(refreshed);

      setActionSuccessMsg(`Transferred ${emp?.first_name || 'staff member'} to ${targetOffice?.office_name || transferTargetOfficeId}.`);
      setTransferringAssignment(null);
    } catch (err: any) {
      setTransferError(err?.message || 'Failed to transfer assignment.');
    } finally {
      setIsSubmittingTransfer(false);
    }
  };

  // Revoke Assignment with Confirmation Modal
  const handleOpenRevokeModal = (assignment: OfficeAssignmentRecord) => {
    const emp = employees.find((e) => e.employee_id === assignment.employee_id);
    const off = SIX_PERMANENT_OFFICES.find((o) => o.office_id === assignment.office_id);

    setConfirmDialog({
      isOpen: true,
      title: 'Revoke Office Assignment',
      description: `Are you sure you want to revoke ${emp?.first_name || ''} ${emp?.last_name || ''}'s assignment in ${off?.office_name || assignment.office_id}? They will no longer have access to this office.`,
      confirmLabel: 'Revoke Assignment',
      isDestructive: true,
      onConfirm: async () => {
        try {
          await dataAdapter.officeAssignments.revoke(assignment.assignment_id);
          const refreshed = await dataAdapter.officeAssignments.getAll();
          setOfficeAssignments(refreshed);
          setActionSuccessMsg(`Revoked assignment for ${emp?.first_name || 'staff member'} in ${off?.office_name || assignment.office_id}.`);
        } catch (err: any) {
          setActionErrorMsg(err?.message || 'Failed to revoke assignment.');
        } finally {
          setConfirmDialog(null);
        }
      },
    });
  };

  // 3. Grant Permission (Admin)
  const handleGrantPermission = async (e: FormEvent) => {
    e.preventDefault();
    if (!permStaffId || !permOfficeId) return;

    const granted = await dataAdapter.officePermissions.grant({
      assignment_id: `OAS-GRANT-${Date.now().toString().slice(-4)}`,
      office_id: permOfficeId,
      employee_id: permStaffId,
      module_name: permModule,
      permission_scope: permScope,
      granted_by_employee_id: session?.user.user_id || 'USR-PO-001',
      status: 'ACTIVE',
    });

    setOfficePermissions((prev) => [...prev, granted]);
    setActionSuccessMsg(`Permission granted: ${permModule} (${permScope}) to employee.`);
  };

  const handleRevokePermission = async (permissionId: string) => {
    await dataAdapter.officePermissions.revoke(permissionId);
    setOfficePermissions((prev) =>
      prev.map((p) => (p.permission_id === permissionId ? { ...p, status: 'REVOKED' } : p))
    );
    setActionSuccessMsg('Permission successfully revoked.');
  };

  // 4. Register Student Intake (Admissions Office)
  const handleRegisterStudent = async (e: FormEvent) => {
    e.preventDefault();
    if (!newStuFirstName || !newStuLastName) return;

    const existingRegs = students.map((s) => s.registration_number);
    const regNumber = allocateNextStudentRegistrationNumber(existingRegs, 2026, newStuDept);

    const created = await dataAdapter.students.create({
      registration_number: regNumber,
      first_name: newStuFirstName,
      last_name: newStuLastName,
      date_of_birth: '2005-01-01',
      gender: 'MALE',
      institutional_email: `${newStuFirstName.toLowerCase()}.${newStuLastName.toLowerCase()}@student.eit.edu`,
      personal_phone: '+1 (555) 999-8877',
      program_name: newStuProgram,
      department: newStuDept,
      admission_year: 2026,
      current_semester: 1,
      section: 'A',
      enrollment_status: StudentStatus.ENROLLED,
    });

    setStudents((prev) => [...prev, created]);
    setActionSuccessMsg(`Student registered with unique Registration Number: ${created.registration_number}`);
    setNewStuFirstName('');
    setNewStuLastName('');
  };

  // 5. Assign Faculty to Course (Academic Office)
  const handleAssignFaculty = async (e: FormEvent) => {
    e.preventDefault();
    if (!fcaFacultyId || !fcaCourseCode) return;

    const assigned = await dataAdapter.facultyAssignments.assign({
      employee_id: fcaFacultyId,
      course_code: fcaCourseCode,
      course_title: fcaCourseTitle,
      department: fcaDept,
      semester: fcaSemester,
      academic_year: '2026-2027',
      section: fcaSection,
      role_in_course: fcaRole,
      assignment_status: 'ACTIVE',
      assigned_by_office_id: 'PO-003',
      effective_from: new Date().toISOString().split('T')[0],
    });

    setFacultyAssignments((prev) => [...prev, assigned]);
    setActionSuccessMsg(`Faculty course allocation saved for ${fcaCourseCode} (Sec ${fcaSection}).`);
  };

  // 6. Record/Moderate Examination (COE Office)
  const handleRecordExam = async (e: FormEvent) => {
    e.preventDefault();
    if (!dataAdapter.examinations.recordOrUpdate) return;
    const stu = students.find((s) => s.student_id === examStudentId);
    const total = examInternal + examExternal;

    const recorded = await dataAdapter.examinations.recordOrUpdate({
      exam_session: examSessionName,
      course_code: examCourseCode,
      student_id: examStudentId,
      hall_ticket_number: examHallTicket,
      internal_marks: examInternal,
      external_marks: examExternal,
      total_marks: total,
      max_marks: 100,
      exam_status: examStatusVal,
      evaluated_by_employee_id: session?.user.user_id || 'PO-004',
      moderated_by_office_id: 'PO-004',
    });

    setExaminations((prev) => {
      const idx = prev.findIndex((x) => x.exam_id === recorded.exam_id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = recorded;
        return next;
      }
      return [...prev, recorded];
    });

    setActionSuccessMsg(`Examination marks validated & saved for ${stu?.first_name || examStudentId} in ${examCourseCode}. Total: ${total}/100.`);
  };

  // 7. Create Fee Invoice (Finance Office)
  const handleCreateInvoice = async (e: FormEvent) => {
    e.preventDefault();
    if (!dataAdapter.finance.createInvoice) return;
    const stu = students.find((s) => s.student_id === finStudentId);

    const created = await dataAdapter.finance.createInvoice({
      student_id: finStudentId,
      registration_number: stu?.registration_number || finStudentId,
      fee_category: finCategory,
      academic_year: '2026-2027',
      semester: finSemester,
      amount_due: finAmount,
      amount_paid: 0,
      currency: 'USD',
      payment_status: PaymentStatus.PENDING,
      transaction_reference: '',
      payment_method: '',
      payment_date: '',
    });

    setInvoices((prev) => [...prev, created]);
    setActionSuccessMsg(`Invoice generated: ${created.invoice_id} for $${created.amount_due} (${created.fee_category}).`);
  };

  // 8. Allocate Hostel Room (Hostel Office)
  const handleAllocateHostel = async (e: FormEvent) => {
    e.preventDefault();
    if (!dataAdapter.hostel.allocate) return;
    const stu = students.find((s) => s.student_id === hstStudentId);

    const allocated = await dataAdapter.hostel.allocate({
      student_id: hstStudentId,
      registration_number: stu?.registration_number || hstStudentId,
      hostel_block_name: hstBlock,
      room_number: hstRoom,
      bed_identifier: hstBed,
      status: HostelAllocationStatus.OCCUPIED,
      check_in_date: new Date().toISOString().split('T')[0],
      allocated_by_employee_id: session?.user.user_id || 'PO-006',
      approved_by_office_id: 'PO-006',
      emergency_contact_phone: hstEmergencyPhone,
    });

    setHostelAllocations((prev) => [...prev, allocated]);
    setActionSuccessMsg(`Hostel bed allocated: ${allocated.block_name || allocated.hostel_block_name || 'Room'} Room ${allocated.room_number} (Bed ${allocated.bed_identifier}).`);
  };

  // 9. Record Class Attendance (Faculty)
  const handleRecordAttendance = async (e: FormEvent) => {
    e.preventDefault();
    if (!attCourseCode || !attStudentId) return;

    try {
      const stu = students.find((s) => s.student_id === attStudentId);
      const targetAssignment = myFacultyAssignments.find((f) => f.course_code === attCourseCode);

      const rec = await dataAdapter.attendance.record(
        {
          date: new Date().toISOString().split('T')[0],
          course_code: attCourseCode,
          session_slot: '09:00 - 10:00 AM',
          student_id: attStudentId,
          registration_number: stu?.registration_number || attStudentId,
          status: attStatusVal,
          recorded_by_employee_id: session?.employeeProfile?.employee_id || 'EMP-001',
          remarks: attRemarksVal || (targetAssignment ? `Sec ${targetAssignment.section}` : undefined),
        },
        {
          userId: session?.user.user_id || '',
          employeeId: session?.employeeProfile?.employee_id,
          role: session?.role || 'FACULTY',
        }
      );

      setAttendanceRecords((prev) => [...prev, rec]);
      setActionSuccessMsg(
        `Attendance recorded: ${stu?.first_name || attStudentId} marked ${attStatusVal} for ${attCourseCode}.`
      );
      setAttRemarksVal('');
    } catch (err: any) {
      setActionErrorMsg(err?.message || 'Failed to record attendance.');
    }
  };

  // Open Section Class Roster
  const handleOpenRoster = async (assignment: FacultyCourseAssignmentRecord) => {
    setViewingRosterAssignment(assignment);
    setIsLoadingRoster(true);
    setRosterError(null);
    try {
      const roster = await dataAdapter.academic.getClassRoster(
        assignment.course_code,
        assignment.section,
        {
          userId: session?.user.user_id || '',
          employeeId: session?.employeeProfile?.employee_id,
          role: session?.role || 'FACULTY',
        }
      );
      setRosterStudents(roster);
    } catch (err: any) {
      setRosterError(err?.message || 'Failed to retrieve section roster.');
    } finally {
      setIsLoadingRoster(false);
    }
  };

  // 10. Record Internal Assessment Grade (Faculty)
  const handleRecordFacultyGrade = async (e: FormEvent) => {
    e.preventDefault();
    if (!facGradeCourse || !facGradeStudentId) return;
    const stu = students.find((s) => s.student_id === facGradeStudentId);

    setConfirmDialog({
      isOpen: true,
      title: 'Confirm Internal Assessment Grade',
      description: `Submit internal assessment marks of ${facGradeInternalMarks}/40 for ${stu?.first_name || facGradeStudentId} ${stu?.last_name || ''} in course ${facGradeCourse}?`,
      confirmLabel: 'Confirm & Submit',
      isDestructive: false,
      onConfirm: async () => {
        try {
          setIsSubmittingGrade(true);
          if (!dataAdapter.examinations.recordOrUpdate) return;
          const rec = await dataAdapter.examinations.recordOrUpdate(
            {
              student_id: facGradeStudentId,
              course_code: facGradeCourse,
              exam_session: facGradeSession,
              hall_ticket_number: `HT-${facGradeCourse}-${stu?.registration_number || '001'}`,
              internal_marks: facGradeInternalMarks,
              external_marks: 0,
              total_marks: facGradeInternalMarks,
              max_marks: 100,
              exam_status: ExamStatus.APPEARED,
              evaluated_by_employee_id: session?.employeeProfile?.employee_id || 'EMP-001',
              moderated_by_office_id: 'PO-004',
            },
            {
              userId: session?.user.user_id || '',
              employeeId: session?.employeeProfile?.employee_id,
              role: session?.role || 'FACULTY',
            }
          );

          setExaminations((prev) => {
            const idx = prev.findIndex((item) => item.exam_id === rec.exam_id);
            if (idx >= 0) {
              const cp = [...prev];
              cp[idx] = rec;
              return cp;
            }
            return [...prev, rec];
          });
          setActionSuccessMsg(
            `Internal marks (${facGradeInternalMarks}/40) successfully recorded for ${stu?.first_name || facGradeStudentId} in ${facGradeCourse}.`
          );
        } catch (err: any) {
          setActionErrorMsg(err?.message || 'Failed to submit internal marks.');
        } finally {
          setIsSubmittingGrade(false);
          setConfirmDialog(null);
        }
      },
    });
  };

  // Filtered queries
  const nonTeachingEmployees = useMemo(
    () => employees.filter((e) => e.category === EmployeeCategory.NON_TEACHING),
    [employees]
  );

  const teachingEmployees = useMemo(
    () => employees.filter((e) => e.category === EmployeeCategory.TEACHING),
    [employees]
  );

  const myFacultyAssignments = useMemo(() => {
    if (isFaculty) {
      if (!session?.employeeProfile?.employee_id) return [];
      return facultyAssignments.filter(
        (f) => f.employee_id === session.employeeProfile?.employee_id && f.assignment_status === 'ACTIVE'
      );
    }
    return facultyAssignments;
  }, [facultyAssignments, isFaculty, session]);

  // Keep attendance and grade course selector synced to assigned courses
  useEffect(() => {
    if (isFaculty && myFacultyAssignments.length > 0) {
      if (!attCourseCode || !myFacultyAssignments.some((f) => f.course_code === attCourseCode)) {
        setAttCourseCode(myFacultyAssignments[0].course_code);
      }
      if (!facGradeCourse || !myFacultyAssignments.some((f) => f.course_code === facGradeCourse)) {
        setFacGradeCourse(myFacultyAssignments[0].course_code);
      }
    }
  }, [isFaculty, myFacultyAssignments, attCourseCode, facGradeCourse]);

  // Load attendance roster for selected course
  useEffect(() => {
    let isCancelled = false;
    const fetchAttRoster = async () => {
      if (!isFaculty || myFacultyAssignments.length === 0 || !attCourseCode) return;
      const currentAssign = myFacultyAssignments.find((f) => f.course_code === attCourseCode) || myFacultyAssignments[0];
      if (!currentAssign) return;
      setIsLoadingAttRoster(true);
      try {
        const roster = await dataAdapter.academic.getClassRoster(
          currentAssign.course_code,
          currentAssign.section,
          {
            userId: session?.user.user_id || '',
            employeeId: session?.employeeProfile?.employee_id,
            role: session?.role || 'FACULTY',
          }
        );
        if (!isCancelled) {
          setAttRoster(roster);
          if (roster.length > 0 && !roster.some((r) => r.student.student_id === attStudentId)) {
            setAttStudentId(roster[0].student.student_id);
          }
        }
      } catch {
        // Fallback
      } finally {
        if (!isCancelled) setIsLoadingAttRoster(false);
      }
    };
    fetchAttRoster();
    return () => {
      isCancelled = true;
    };
  }, [isFaculty, attCourseCode, myFacultyAssignments, session, dataAdapter]);

  // Load grade roster for selected course
  useEffect(() => {
    let isCancelled = false;
    const fetchGradeRoster = async () => {
      if (!isFaculty || myFacultyAssignments.length === 0 || !facGradeCourse) return;
      const currentAssign = myFacultyAssignments.find((f) => f.course_code === facGradeCourse) || myFacultyAssignments[0];
      if (!currentAssign) return;
      setIsLoadingGradeRoster(true);
      try {
        const roster = await dataAdapter.academic.getClassRoster(
          currentAssign.course_code,
          currentAssign.section,
          {
            userId: session?.user.user_id || '',
            employeeId: session?.employeeProfile?.employee_id,
            role: session?.role || 'FACULTY',
          }
        );
        if (!isCancelled) {
          setFacGradeRoster(roster);
          if (roster.length > 0 && !roster.some((r) => r.student.student_id === facGradeStudentId)) {
            setFacGradeStudentId(roster[0].student.student_id);
          }
        }
      } catch {
        // Fallback
      } finally {
        if (!isCancelled) setIsLoadingGradeRoster(false);
      }
    };
    fetchGradeRoster();
    return () => {
      isCancelled = true;
    };
  }, [isFaculty, facGradeCourse, myFacultyAssignments, session, dataAdapter]);

  const filteredEmployees = useMemo(() => {
    return employees.filter((e) => {
      if (empCategoryFilter !== 'ALL' && e.category !== empCategoryFilter) return false;
      if (empStatusFilter !== 'ALL' && e.employment_status !== empStatusFilter) return false;
      if (empDeptFilter !== 'ALL' && e.primary_department !== empDeptFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = `${e.first_name} ${e.last_name}`.toLowerCase().includes(q);
        const matchesReg = e.registration_number.toLowerCase().includes(q);
        const matchesDept = e.primary_department.toLowerCase().includes(q);
        const matchesDesig = e.designation.toLowerCase().includes(q);
        const matchesEmail = e.institutional_email.toLowerCase().includes(q);
        const matchesPhone = e.phone_number.includes(q);
        if (!matchesName && !matchesReg && !matchesDept && !matchesDesig && !matchesEmail && !matchesPhone) {
          return false;
        }
      }
      return true;
    });
  }, [employees, empCategoryFilter, empStatusFilter, empDeptFilter, searchQuery]);

  const filteredStudents = useMemo(() => {
    if (!searchQuery.trim()) return students;
    const q = searchQuery.toLowerCase();
    return students.filter(
      (s) =>
        s.first_name.toLowerCase().includes(q) ||
        s.last_name.toLowerCase().includes(q) ||
        s.registration_number.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q)
    );
  }, [students, searchQuery]);

  const filteredInvoices = useMemo(() => {
    if (!searchQuery.trim()) return invoices;
    const q = searchQuery.toLowerCase();
    return invoices.filter(
      (i) =>
        i.invoice_id.toLowerCase().includes(q) ||
        i.registration_number.toLowerCase().includes(q) ||
        i.fee_category.toLowerCase().includes(q) ||
        i.payment_status.toLowerCase().includes(q)
    );
  }, [invoices, searchQuery]);

  const filteredExaminations = useMemo(() => {
    if (!searchQuery.trim()) return examinations;
    const q = searchQuery.toLowerCase();
    return examinations.filter(
      (ex) =>
        ex.course_code.toLowerCase().includes(q) ||
        ex.hall_ticket_number.toLowerCase().includes(q) ||
        ex.exam_session.toLowerCase().includes(q) ||
        ex.exam_status.toLowerCase().includes(q)
    );
  }, [examinations, searchQuery]);

  const filteredHostel = useMemo(() => {
    if (!searchQuery.trim()) return hostelAllocations;
    const q = searchQuery.toLowerCase();
    return hostelAllocations.filter(
      (h) =>
        h.hostel_block_name.toLowerCase().includes(q) ||
        h.room_number.includes(q) ||
        h.registration_number.toLowerCase().includes(q)
    );
  }, [hostelAllocations, searchQuery]);

  if (isFaculty) {
    return <FacultyWorkspace onRefreshRoot={loadAllData} />;
  }

  const isAdmissionsOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.ADMISSIONS ||
      activeOfficeKey?.toLowerCase() === 'admissions' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'admissionsoffice' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'admissions'
      )));

  if (isAdmissionsOffice) {
    return <AdmissionsOfficeSection onRefreshData={loadAllData} />;
  }

  const isAcademicOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.ACADEMIC ||
      activeOfficeKey?.toLowerCase() === 'academic' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'academicoffice' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'academic'
      )));

  if (isAcademicOffice) {
    return <AcademicOfficeSection onRefreshData={loadAllData} />;
  }

  const isCoeOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.COE ||
      activeOfficeKey?.toLowerCase() === 'coe' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'coeoffice' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'coe'
      )));

  if (isCoeOffice) {
    return <CoeOfficeSection onRefreshData={loadAllData} />;
  }

  const isFinanceOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.FINANCE ||
      activeOfficeKey?.toLowerCase() === 'finance' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'finance' ||
        activeOfficeUsername === 'financeoffice' ||
        session?.permanentOffice?.office_id === 'PO-005' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'finance'
      )));

  if (isFinanceOffice) {
    return <FinanceOfficeSection onRefreshData={loadAllData} />;
  }

  const isHostelOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.HOSTEL ||
      activeOfficeKey?.toLowerCase() === 'hostel' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'hosteloffice' ||
        activeOfficeUsername === 'hostel' ||
        session?.permanentOffice?.office_id === 'PO-006' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'hostel' ||
        session?.user?.username?.toLowerCase() === 'hosteloffice'
      )));

  if (isHostelOffice) {
    return <HostelOfficeSection onRefreshData={loadAllData} />;
  }

  const isItOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.IT ||
      activeOfficeKey?.toLowerCase() === 'it' ||
      (!isSuperAdmin && (
        activeOfficeUsername === 'itoffice' ||
        activeOfficeUsername === 'it' ||
        session?.permanentOffice?.office_id === 'PO-007' ||
        session?.permanentOffice?.office_key?.toLowerCase() === 'it' ||
        session?.user?.username?.toLowerCase() === 'itoffice'
      )));

  if (isItOffice) {
    return <ItOfficeSection onRefreshData={loadAllData} />;
  }

  const isAdministrationOffice =
    !isFaculty &&
    (activeOfficeKey === PermanentOfficeKey.ADMINISTRATION ||
      activeOfficeKey?.toLowerCase() === 'administration' ||
      activeOfficeUsername === 'admin' ||
      session?.permanentOffice?.office_id === 'PO-001' ||
      session?.permanentOffice?.office_key?.toLowerCase() === 'administration' ||
      (isSuperAdmin && (!activeOfficeKey || activeOfficeKey.toLowerCase() === 'administration')));

  if (isAdministrationOffice) {
    return <AdminWorkspace />;
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
      {/* Office / Faculty Header Banner - Hidden for Super Admin as header matches screenshot */}
      {!isSuperAdmin && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 sm:p-8 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-[#1E3A8A] text-white flex items-center justify-center shrink-0">
                {isFaculty ? (
                  <BookOpen className="w-8 h-8 stroke-[1.8]" />
                ) : (
                  <Building2 className="w-8 h-8 stroke-[1.8]" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h1 className="text-2xl font-bold tracking-tight text-slate-900">
                    {isFaculty
                      ? `Faculty: ${session?.displayName}`
                      : currentAssignedOffice?.office_name || session?.displayName}
                  </h1>
                  {isFaculty && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-900 border border-blue-200">
                      <BookOpen className="w-3.5 h-3.5 text-blue-700" />
                      <span>Teaching Faculty</span>
                    </span>
                  )}
                  {isNonTeachingStaff && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-900 border border-purple-200">
                      <UserCheck2 className="w-3.5 h-3.5 text-purple-700" />
                      <span>Assigned Office Staff</span>
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  {isFaculty
                    ? `${session?.employeeProfile?.designation || 'Faculty Member'} · Department of ${session?.employeeProfile?.primary_department || 'Engineering'}`
                    : currentAssignedOffice?.description || `Authorized account: ${session?.user.username}`}
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:items-end gap-2">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-xs font-mono font-semibold text-[#1e3a8a]">
                  AY: {activeAcademicYear || '2026–2027'}
                </span>
                <span className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-semibold text-slate-700">
                  User: {session?.user.username}
                </span>
              </div>

              {/* Office Switcher for Non-Teaching Staff assigned to multiple offices */}
              {isNonTeachingStaff && session?.availableOffices && session.availableOffices.length > 1 && (
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-500 font-medium">Switch Assigned Office:</span>
                  <select
                    value={currentAssignedOffice?.office_key}
                    onChange={(e) => switchActiveOffice(e.target.value)}
                    className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-[#1E3A8A] cursor-pointer"
                  >
                    {session.availableOffices.map((off) => (
                      <option key={off.office_id} value={off.office_key}>
                        {off.office_name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* Non-Teaching Staff Active Permissions Notice */}
          {isNonTeachingStaff && (
            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
              <span className="text-slate-500 font-medium">Granted Office Permissions:</span>
              {officePermissions.length === 0 ? (
                <span className="text-slate-400 italic">Standard Associate Access</span>
              ) : (
                officePermissions.map((perm) => (
                  <span key={perm.permission_id} className="px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-800 font-mono text-[11px]">
                    {perm.module_name}: {perm.permission_scope}
                  </span>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {actionSuccessMsg && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{actionSuccessMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionSuccessMsg(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold text-xs cursor-pointer ml-3 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {actionErrorMsg && (
        <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{actionErrorMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionErrorMsg(null)}
            className="text-rose-700 hover:text-rose-900 font-bold text-xs cursor-pointer ml-3 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Navigation Tabs based on role & active office (Only for non-super admins) */}
      {!isSuperAdmin && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 mb-6 pb-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {/* Admissions Office View */}
            {(activeOfficeUsername === 'admissionsoffice' || activeOfficeKey === PermanentOfficeKey.ADMISSIONS) && (
              <button
                type="button"
                onClick={() => { setActiveTab('admissions'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                Admissions Intake &amp; Registry
              </button>
            )}

            {/* Academic Office View */}
            {(activeOfficeUsername === 'academicoffice' || activeOfficeKey === PermanentOfficeKey.ACADEMIC) && (
              <button
                type="button"
                onClick={() => { setActiveTab('academic'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                Academic Office &amp; Faculty Management
              </button>
            )}

            {/* COE Office View */}
            {(activeOfficeUsername === 'coeoffice' || activeOfficeKey === PermanentOfficeKey.COE) && (
              <button
                type="button"
                onClick={() => { setActiveTab('coe'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                COE Examinations &amp; Moderation
              </button>
            )}

            {/* Finance Office View */}
            {(activeOfficeUsername === 'finance' || activeOfficeKey === PermanentOfficeKey.FINANCE) && (
              <button
                type="button"
                onClick={() => { setActiveTab('finance'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                Finance &amp; Dues Ledger
              </button>
            )}

            {/* Hostel Office View */}
            {(activeOfficeUsername === 'hosteloffice' || activeOfficeKey === PermanentOfficeKey.HOSTEL) && (
              <button
                type="button"
                onClick={() => { setActiveTab('hostel'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                Hostel Blocks &amp; Room Allocations
              </button>
            )}

            {/* IT Department View */}
            {(activeOfficeUsername === 'itoffice' || activeOfficeKey === PermanentOfficeKey.IT) && (
              <button
                type="button"
                onClick={() => { setActiveTab('it'); setSearchQuery(''); }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#1E3A8A] text-white shadow-xs cursor-pointer"
              >
                IT Department &amp; Services
              </button>
            )}

            {/* Teaching Faculty View */}
            {isFaculty && (
              <>
                <button
                  type="button"
                  onClick={() => { setActiveTab('faculty_courses'); setSearchQuery(''); }}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'faculty_courses' ? 'bg-[#1E3A8A] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  My Courses &amp; Rosters
                </button>
                <button
                  type="button"
                  onClick={() => { setActiveTab('faculty_attendance'); setSearchQuery(''); }}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'faculty_attendance' ? 'bg-[#1E3A8A] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  Mark Class Attendance
                </button>
                <button
                  type="button"
                  onClick={() => { setActiveTab('faculty_grades'); setSearchQuery(''); }}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'faculty_grades' ? 'bg-[#1E3A8A] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  Internal Assessment Grades
                </button>
              </>
            )}
          </div>

          {/* Global Tab Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search active module..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl text-xs bg-white border border-slate-200 focus:outline-none focus:border-[#1E3A8A]"
            />
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="p-12 text-center text-slate-500">Loading module data...</div>
      ) : (
        isSuperAdmin ? (
          <div className="flex flex-col lg:flex-row items-start gap-6">
            {/* Left Sidebar */}
            <aside className="w-full lg:w-60 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-4 sm:p-5 shrink-0 self-start">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 px-3">
                MANAGEMENT
              </div>
              <nav className="space-y-1">
                {/* 1. Overview */}
                <button
                  type="button"
                  onClick={() => { setActiveTab('overview'); setSearchQuery(''); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'overview'
                      ? 'bg-blue-50/80 text-[#1E3A8A] font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-medium'
                  }`}
                >
                  <LayoutGrid className={`w-4 h-4 ${activeTab === 'overview' ? 'text-[#1E3A8A]' : 'text-slate-400'}`} />
                  <span>Overview</span>
                </button>

                {/* 2. Employees */}
                <button
                  type="button"
                  onClick={() => { setActiveTab('employees'); setSearchQuery(''); }}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'employees'
                      ? 'bg-blue-50/80 text-[#1E3A8A] font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Users className={`w-4 h-4 ${activeTab === 'employees' ? 'text-[#1E3A8A]' : 'text-slate-400'}`} />
                    <span>Employees</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                    activeTab === 'employees' ? 'bg-blue-100 text-[#1E3A8A]' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {employees.length}
                  </span>
                </button>

                {/* 3. Bulk Import */}
                <button
                  type="button"
                  onClick={() => { setActiveTab('bulk_import'); setSearchQuery(''); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'bulk_import'
                      ? 'bg-blue-50/80 text-[#1E3A8A] font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-medium'
                  }`}
                >
                  <UploadCloud className={`w-4 h-4 ${activeTab === 'bulk_import' ? 'text-[#1E3A8A]' : 'text-slate-400'}`} />
                  <span>Bulk Import</span>
                </button>

                {/* 4. Settings */}
                <button
                  type="button"
                  onClick={() => { setActiveTab('settings'); setSearchQuery(''); }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-semibold transition-colors cursor-pointer ${
                    activeTab === 'settings'
                      ? 'bg-blue-50/80 text-[#1E3A8A] font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 font-medium'
                  }`}
                >
                  <Settings className={`w-4 h-4 ${activeTab === 'settings' ? 'text-[#1E3A8A]' : 'text-slate-400'}`} />
                  <span>Settings</span>
                </button>
              </nav>
            </aside>

            {/* Right Main Content */}
            <main className="flex-1 min-w-0 w-full space-y-6">
              {/* Tab 1: Overview */}
              {activeTab === 'overview' && (
                <AdministrationOverviewSection
                  employees={employees}
                  officeAssignments={officeAssignments}
                  departments={departments}
                  onNavigateToEmployees={() => setActiveTab('employees')}
                  onNavigateToBulkImport={() => setActiveTab('bulk_import')}
                  onOpenAddEmployeeModal={() => setIsAddEmployeeModalOpen(true)}
                />
              )}

              {/* Tab 2: Bulk Import */}
              {activeTab === 'bulk_import' && (
                <AdministrationBulkImportSection
                  existingEmployees={employees}
                  dataAdapter={dataAdapter}
                  onEmployeesImported={(newEmps) => {
                    setEmployees((prev) => [...prev, ...newEmps]);
                    loadAllData();
                  }}
                  actor={session?.user ? { userId: session.user.user_id, role: session.user.role, employeeId: session.user.linked_record_id } : undefined}
                />
              )}

              {/* Tab 3: Settings */}
              {activeTab === 'settings' && (
                <AdministrationSettingsSection />
              )}

              {/* Tab 4: Employees Management */}
              {activeTab === 'employees' && (
                <div className="space-y-6">
                  {/* Employee Management Header with Subtabs & Add Employee button */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-xl font-bold text-slate-900">Institution Staff Management</h2>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Inspect profiles, view assignments, manage office permissions, and allocate credentials.
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setIsAddEmployeeModalOpen(true)}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-[#1E3A8A] hover:bg-[#162D6E] text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
                      >
                        <UserPlus className="w-4 h-4" />
                        <span>Add Employee</span>
                      </button>
                    </div>
                  </div>

                  {/* Sub-Navigation Tabs */}
                  <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl max-w-fit overflow-x-auto">
                    <button
                      type="button"
                      onClick={() => setEmpSubTab('directory')}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        empSubTab === 'directory' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Staff Directory ({employees.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEmpSubTab('assignments')}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        empSubTab === 'assignments' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <UserCheck2 className="w-3.5 h-3.5" />
                      <span>Office Assignments ({officeAssignments.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEmpSubTab('permissions')}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        empSubTab === 'permissions' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Shield className="w-3.5 h-3.5" />
                      <span>Permissions Governance</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setEmpSubTab('offices')}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        empSubTab === 'offices' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>Permanent Offices (6)</span>
                    </button>
                  </div>

                  {/* SubTab 1: Staff Directory */}
                  {empSubTab === 'directory' && (
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                      <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <h2 className="text-base font-bold text-slate-900">Institution Staff Directory</h2>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Inspect profiles, view teaching allocations, manage office assignments, and update employment status.
                          </p>
                        </div>

                        {/* Multi-facet Filters */}
                        <div className="flex items-center gap-2 flex-wrap">
                          {/* Category Filter */}
                          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs">
                            <button
                              type="button"
                              onClick={() => setEmpCategoryFilter('ALL')}
                              className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                                empCategoryFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              All ({employees.length})
                            </button>
                            <button
                              type="button"
                              onClick={() => setEmpCategoryFilter(EmployeeCategory.TEACHING)}
                              className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                                empCategoryFilter === EmployeeCategory.TEACHING ? 'bg-white text-blue-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              Teaching ({teachingEmployees.length})
                            </button>
                            <button
                              type="button"
                              onClick={() => setEmpCategoryFilter(EmployeeCategory.NON_TEACHING)}
                              className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                                empCategoryFilter === EmployeeCategory.NON_TEACHING ? 'bg-white text-purple-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              Non-Teaching ({nonTeachingEmployees.length})
                            </button>
                          </div>

                          {/* Status Filter */}
                          <select
                            value={empStatusFilter}
                            onChange={(e) => setEmpStatusFilter(e.target.value as any)}
                            className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 cursor-pointer"
                          >
                            <option value="ALL">All Statuses</option>
                            <option value={EmploymentStatus.ACTIVE}>Active</option>
                            <option value={EmploymentStatus.PROBATION}>Probation</option>
                            <option value={EmploymentStatus.ON_LEAVE}>On Leave</option>
                            <option value={EmploymentStatus.RESIGNED}>Resigned</option>
                            <option value={EmploymentStatus.RETIRED}>Retired</option>
                            <option value={EmploymentStatus.TERMINATED}>Terminated</option>
                          </select>

                          <div className="text-xs font-mono text-slate-400 pl-1">
                            Showing: {filteredEmployees.length}
                          </div>
                        </div>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                          <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                            <tr>
                              <th className="px-6 py-3.5">Registration Number</th>
                              <th className="px-6 py-3.5">Staff Name &amp; Contact</th>
                              <th className="px-6 py-3.5">Category</th>
                              <th className="px-6 py-3.5">Department &amp; Designation</th>
                              <th className="px-6 py-3.5">Status</th>
                              <th className="px-6 py-3.5">Login Account</th>
                              <th className="px-6 py-3.5 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-slate-800">
                            {filteredEmployees.length === 0 ? (
                              <tr>
                                <td colSpan={7} className="px-6 py-10 text-center text-slate-500 text-xs">
                                  No employees found matching the filter or search criteria.
                                </td>
                              </tr>
                            ) : (
                              filteredEmployees.map((emp) => (
                                <tr key={emp.employee_id} className="hover:bg-slate-50/70 transition-colors">
                                  {/* Registration Number with Copy button */}
                                  <td className="px-6 py-4">
                                    <div className="flex items-center gap-1.5 font-mono font-semibold text-[#1E3A8A]">
                                      <span>{emp.registration_number}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleCopy(emp.registration_number)}
                                        title="Copy Registration Number"
                                        className="text-slate-400 hover:text-slate-600 p-0.5 rounded cursor-pointer"
                                      >
                                        {copiedText === emp.registration_number ? (
                                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                                        ) : (
                                          <Copy className="w-3.5 h-3.5" />
                                        )}
                                      </button>
                                    </div>
                                    <div className="text-[11px] font-mono text-slate-400">{emp.employee_id}</div>
                                  </td>

                                  {/* Name & Contact */}
                                  <td className="px-6 py-4">
                                    <div className="font-semibold text-slate-900">
                                      {emp.first_name} {emp.last_name}
                                    </div>
                                    <div className="text-xs text-slate-500 font-mono flex items-center gap-1 mt-0.5">
                                      <Mail className="w-3 h-3 text-slate-400" />
                                      <span>{emp.institutional_email}</span>
                                    </div>
                                    <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                                      <Phone className="w-3 h-3 text-slate-400" />
                                      <span>{emp.phone_number}</span>
                                    </div>
                                  </td>

                                  {/* Category */}
                                  <td className="px-6 py-4">
                                    <span
                                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold ${
                                        emp.category === EmployeeCategory.TEACHING
                                          ? 'bg-blue-50 text-blue-900 border border-blue-200'
                                          : 'bg-purple-50 text-purple-900 border border-purple-200'
                                      }`}
                                    >
                                      {emp.category === EmployeeCategory.TEACHING ? (
                                        <>
                                          <BookOpen className="w-3 h-3 text-blue-700" />
                                          <span>Faculty</span>
                                        </>
                                      ) : (
                                        <>
                                          <UserCheck2 className="w-3 h-3 text-purple-700" />
                                          <span>Staff</span>
                                        </>
                                      )}
                                    </span>
                                  </td>

                                  {/* Department & Designation */}
                                  <td className="px-6 py-4">
                                    <div className="font-medium text-slate-900 text-xs">{emp.designation}</div>
                                    <div className="text-xs text-slate-500 font-mono mt-0.5">
                                      Dept: {emp.primary_department}
                                    </div>
                                  </td>

                                  {/* Employment Status */}
                                  <td className="px-6 py-4">
                                    <span
                                      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                                        emp.employment_status === EmploymentStatus.ACTIVE
                                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                          : emp.employment_status === EmploymentStatus.PROBATION
                                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                          : emp.employment_status === EmploymentStatus.ON_LEAVE
                                          ? 'bg-blue-50 text-blue-800 border border-blue-200'
                                          : 'bg-slate-100 text-slate-700 border border-slate-300'
                                      }`}
                                    >
                                      {emp.employment_status}
                                    </span>
                                  </td>

                                  {/* Login Account Status */}
                                  <td className="px-6 py-4">
                                    <div className="flex items-center gap-1 text-xs text-emerald-700 font-semibold">
                                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                      <span>Provisioned</span>
                                    </div>
                                    <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                                      Portal: Employee
                                    </div>
                                  </td>

                                  {/* Action Buttons */}
                                  <td className="px-6 py-4 text-right">
                                    <div className="flex items-center justify-end gap-1.5">
                                      <button
                                        type="button"
                                        onClick={() => setInspectingEmployee(emp)}
                                        className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-[#1E3A8A] font-semibold text-xs flex items-center gap-1 cursor-pointer transition-colors border border-slate-200/60"
                                        title="Inspect Profile"
                                      >
                                        <Eye className="w-3.5 h-3.5" />
                                        <span>Inspect</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleOpenEditModal(emp)}
                                        className="p-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center gap-1 cursor-pointer transition-colors border border-slate-200/60"
                                        title="Edit Permitted Details"
                                      >
                                        <Edit3 className="w-3.5 h-3.5" />
                                        <span>Edit</span>
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* SubTab 2: Office Assignments */}
                  {empSubTab === 'assignments' && (
                    <div className="space-y-6">
                      {/* Assignment Form */}
                      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 sm:p-7">
                        <div className="flex items-center gap-2.5 text-[#1E3A8A] mb-4 pb-3 border-b border-slate-100">
                          <div className="w-9 h-9 rounded-xl bg-purple-50 flex items-center justify-center text-purple-900">
                            <UserCheck2 className="w-5 h-5 stroke-[2]" />
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 text-base">Assign Non-Teaching Staff to Permanent Office</h3>
                            <p className="text-xs text-slate-500">
                              Super Admin delegates non-teaching staff into one or more of the 6 Permanent Offices. Teaching faculty are managed separately through course allocations.
                            </p>
                          </div>
                        </div>

                        {/* Duplicate Assignment Warning */}
                        {isDuplicateAssignment && (
                          <div className="mb-4 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2.5">
                            <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
                            <div>
                              <span className="font-bold">Duplicate Active Assignment Guard: </span>
                              <span>
                                This staff member already holds an active assignment in the selected office. Duplicate active assignments are prohibited. Transfer or revoke the existing assignment below instead.
                              </span>
                            </div>
                          </div>
                        )}

                        <form onSubmit={handleAssignOffice} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                          {/* Non-Teaching Staff Selector */}
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              Non-Teaching Staff Member <span className="text-rose-500">*</span>
                            </label>
                            <select
                              value={selectedStaffId}
                              onChange={(e) => setSelectedStaffId(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800 cursor-pointer"
                            >
                              {nonTeachingEmployees.length === 0 ? (
                                <option value="">No non-teaching staff available</option>
                              ) : (
                                nonTeachingEmployees.map((nte) => (
                                  <option key={nte.employee_id} value={nte.employee_id}>
                                    {nte.first_name} {nte.last_name} ({nte.registration_number})
                                  </option>
                                ))
                              )}
                            </select>
                          </div>

                          {/* Target Permanent Office Selector */}
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              Target Permanent Office <span className="text-rose-500">*</span>
                            </label>
                            <select
                              value={selectedTargetOfficeId}
                              onChange={(e) => setSelectedTargetOfficeId(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800 cursor-pointer"
                            >
                              {SIX_PERMANENT_OFFICES.map((off) => (
                                <option key={off.office_id} value={off.office_id}>
                                  {off.office_name} ({off.canonical_username})
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Role Title */}
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">
                              Assigned Office Role Title <span className="text-rose-500">*</span>
                            </label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Accounts Executive, Warden, Registrar"
                              value={assignRoleTitle}
                              onChange={(e) => setAssignRoleTitle(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                            />
                          </div>

                          {/* Effective From Date */}
                          <div>
                            <label className="block text-xs font-semibold text-slate-700 mb-1">Effective Date</label>
                            <input
                              type="date"
                              value={assignEffectiveFrom}
                              onChange={(e) => setAssignEffectiveFrom(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                            />
                          </div>

                          <div className="col-span-1 sm:col-span-2 md:col-span-4 flex items-center justify-between pt-2">
                            <div className="text-xs text-slate-500 flex items-center gap-1">
                              <Lock className="w-3.5 h-3.5 text-slate-400" />
                              <span>Assignments grant multi-office access in the Employee Portal without altering core identity.</span>
                            </div>

                            <button
                              type="submit"
                              disabled={isDuplicateAssignment || isSubmittingAssign || !selectedStaffId}
                              className="py-2.5 px-6 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 transition-all shrink-0"
                            >
                              {isSubmittingAssign ? (
                                <>
                                  <RefreshCw className="w-4 h-4 animate-spin" />
                                  <span>Assigning...</span>
                                </>
                              ) : (
                                <>
                                  <UserCheck2 className="w-4 h-4" />
                                  <span>Assign Staff to Office</span>
                                </>
                              )}
                            </button>
                          </div>
                        </form>
                      </div>

                      {/* Assignments Table */}
                      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                          <div>
                            <h2 className="text-base font-bold text-slate-900">Institutional Office Assignments Directory</h2>
                            <p className="text-xs text-slate-500 mt-0.5">
                              Super Admin governance of non-teaching staff assignments, department transfers, and revocations.
                            </p>
                          </div>
                          <div className="text-xs font-mono text-slate-500">
                            Total: {officeAssignments.length}
                          </div>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                              <tr>
                                <th className="px-6 py-3.5">Assignment ID</th>
                                <th className="px-6 py-3.5">Staff Member</th>
                                <th className="px-6 py-3.5">Assigned Permanent Office</th>
                                <th className="px-6 py-3.5">Role Title</th>
                                <th className="px-6 py-3.5">Status</th>
                                <th className="px-6 py-3.5">Effective Dates</th>
                                <th className="px-6 py-3.5 text-right">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-slate-800">
                              {officeAssignments.length === 0 ? (
                                <tr>
                                  <td colSpan={7} className="px-6 py-8 text-center text-slate-500 text-xs">
                                    No office assignments recorded.
                                  </td>
                                </tr>
                              ) : (
                                officeAssignments.map((a) => {
                                  const emp = employees.find((e) => e.employee_id === a.employee_id);
                                  const off = SIX_PERMANENT_OFFICES.find((o) => o.office_id === a.office_id);
                                  const isActive = a.assignment_status === OfficeAssignmentStatus.ACTIVE;

                                  return (
                                    <tr key={a.assignment_id} className="hover:bg-slate-50/70 transition-colors">
                                      <td className="px-6 py-4 font-mono font-semibold text-[#1E3A8A]">
                                        {a.assignment_id}
                                      </td>

                                      <td className="px-6 py-4">
                                        <div className="font-semibold text-slate-900">
                                          {emp ? `${emp.first_name} ${emp.last_name}` : a.employee_id}
                                        </div>
                                        <div className="text-xs text-slate-500 font-mono">
                                          {emp?.registration_number}
                                        </div>
                                      </td>

                                      <td className="px-6 py-4">
                                        <div className="font-medium text-slate-900">{off?.office_name || a.office_id}</div>
                                        <div className="text-xs text-slate-400 font-mono">
                                          {off?.canonical_username} · {off?.office_code}
                                        </div>
                                      </td>

                                      <td className="px-6 py-4 text-xs font-medium text-slate-800">
                                        {a.assigned_role_title}
                                      </td>

                                      <td className="px-6 py-4">
                                        <span
                                          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                                            a.assignment_status === OfficeAssignmentStatus.ACTIVE
                                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                              : a.assignment_status === OfficeAssignmentStatus.TRANSFERRED
                                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                              : 'bg-slate-100 text-slate-600 border border-slate-300'
                                          }`}
                                        >
                                          {a.assignment_status}
                                        </span>
                                      </td>

                                      <td className="px-6 py-4 text-xs font-mono text-slate-500">
                                        <div>From: {a.effective_from || '—'}</div>
                                        {a.effective_to && <div className="text-slate-400">To: {a.effective_to}</div>}
                                      </td>

                                      <td className="px-6 py-4 text-right">
                                        {isActive ? (
                                          <div className="flex items-center justify-end gap-2">
                                            <button
                                              type="button"
                                              onClick={() => handleOpenTransferModal(a)}
                                              className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-[#1E3A8A] text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                                            >
                                              <ArrowRightLeft className="w-3.5 h-3.5" />
                                              <span>Transfer</span>
                                            </button>
                                            <button
                                              type="button"
                                              onClick={() => handleOpenRevokeModal(a)}
                                              className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                                            >
                                              <Trash2 className="w-3.5 h-3.5" />
                                              <span>Revoke</span>
                                            </button>
                                          </div>
                                        ) : (
                                          <span className="text-xs text-slate-400 italic">Archived</span>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SubTab 3: Permissions Governance */}
                  {empSubTab === 'permissions' && (
                    <div className="space-y-6">
                      {/* Separation of Duties Banner */}
                      <div className="bg-amber-50/70 border border-amber-200/90 rounded-2xl p-6">
                        <div className="flex items-start gap-3">
                          <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                            <Shield className="w-5 h-5" />
                          </div>
                          <div>
                            <h3 className="font-bold text-amber-900 text-base">
                              Separation of Duties: Institutional Permission Governance
                            </h3>
                            <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                              Administration manages institutional employee registration and delegates non-teaching staff into permanent offices via Office Assignments.
                              <strong> In accordance with EIT governance policy, granular operational permissions (e.g. Fee Collections in Finance, Room Allocations in Hostel, Marks Moderation in COE) must be administered directly by each respective authorized office.</strong> Administration&apos;s employee-management authority does not silently grant unrelated operational permissions.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Permissions Table across all offices */}
                      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                          <div>
                            <h2 className="text-base font-bold text-slate-900">Institutional Permissions Audit Ledger</h2>
                            <p className="text-xs text-slate-500 mt-0.5">
                              All granular office module grants authorized across the 6 Permanent Offices.
                            </p>
                          </div>
                          <div className="text-xs font-mono text-slate-500">
                            Active Grants: {officePermissions.filter(p => p.status === 'ACTIVE').length}
                          </div>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                              <tr>
                                <th className="px-6 py-3.5">Permission ID</th>
                                <th className="px-6 py-3.5">Staff Member</th>
                                <th className="px-6 py-3.5">Authorized Office</th>
                                <th className="px-6 py-3.5">Operational Module</th>
                                <th className="px-6 py-3.5">Scope</th>
                                <th className="px-6 py-3.5">Status</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 text-slate-800">
                              {officePermissions.length === 0 ? (
                                <tr>
                                  <td colSpan={6} className="px-6 py-8 text-center text-slate-500 text-xs">
                                    No office permissions currently granted.
                                  </td>
                                </tr>
                              ) : (
                                officePermissions.map((p) => {
                                  const emp = employees.find((e) => e.employee_id === p.employee_id);
                                  const off = SIX_PERMANENT_OFFICES.find((o) => o.office_id === p.office_id);
                                  return (
                                    <tr key={p.permission_id} className="hover:bg-slate-50/60 transition-colors">
                                      <td className="px-6 py-4 font-mono font-semibold text-[#1E3A8A]">{p.permission_id}</td>
                                      <td className="px-6 py-4 font-medium">
                                        <div>{emp ? `${emp.first_name} ${emp.last_name}` : p.employee_id}</div>
                                        <div className="text-xs text-slate-400 font-mono">{emp?.registration_number}</div>
                                      </td>
                                      <td className="px-6 py-4 font-medium">{off?.office_name || p.office_id}</td>
                                      <td className="px-6 py-4 font-mono text-xs font-semibold text-slate-800">{p.module_name}</td>
                                      <td className="px-6 py-4">
                                        <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-blue-50 text-blue-900 border border-blue-200">
                                          {p.permission_scope}
                                        </span>
                                      </td>
                                      <td className="px-6 py-4">
                                        <span
                                          className={`px-2 py-0.5 rounded text-xs font-semibold ${
                                            p.status === 'ACTIVE' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                                          }`}
                                        >
                                          {p.status}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* SubTab 4: Permanent Offices */}
                  {empSubTab === 'offices' && (
                    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                      <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                        <div>
                          <h2 className="text-base font-bold text-slate-900">Six Permanent Institutional Offices</h2>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Immutable core accounts. Self-registration is strictly blocked.
                          </p>
                        </div>
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-800">
                          <Shield className="w-3.5 h-3.5" />
                          <span>6 Fixed Accounts</span>
                        </span>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                          <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                            <tr>
                              <th className="px-6 py-3.5">Office ID</th>
                              <th className="px-6 py-3.5">Office Name</th>
                              <th className="px-6 py-3.5">Canonical Username</th>
                              <th className="px-6 py-3.5">Code</th>
                              <th className="px-6 py-3.5">System Lock</th>
                              <th className="px-6 py-3.5">Contact Email</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-slate-800">
                            {SIX_PERMANENT_OFFICES.map((off) => (
                              <tr key={off.office_id} className="hover:bg-slate-50/60 transition-colors">
                                <td className="px-6 py-4 font-mono font-semibold text-[#1E3A8A]">{off.office_id}</td>
                                <td className="px-6 py-4 font-medium">{off.office_name}</td>
                                <td className="px-6 py-4 font-mono font-semibold text-slate-900 bg-slate-50/80 rounded">
                                  {off.canonical_username}
                                </td>
                                <td className="px-6 py-4 font-mono">{off.office_code}</td>
                                <td className="px-6 py-4">
                                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600">
                                    <KeyRound className="w-3 h-3 text-slate-400" />
                                    <span>Reserved</span>
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-xs text-slate-500">{off.primary_contact_email}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </main>
          </div>
        ) : (
          <div className="space-y-8">

          {/* =========================================================================
              5. ADMISSIONS OFFICE: Candidate Intake & Applicant Management (Phase 6)
             ========================================================================= */}
          {(activeTab === 'admissions' ||
            activeOfficeUsername === 'admissionsoffice' ||
            activeOfficeKey === PermanentOfficeKey.ADMISSIONS) && (
            <AdmissionsOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              6. ACADEMIC OFFICE: Academic Office & Faculty Management (Phase 7)
             ========================================================================= */}
          {(activeTab === 'academic' ||
            activeOfficeUsername === 'academicoffice' ||
            activeOfficeKey === PermanentOfficeKey.ACADEMIC) && (
            <AcademicOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              7. COE OFFICE: Controller of Examinations (Phase 8 Complete)
             ========================================================================= */}
          {(activeTab === 'coe' ||
            activeOfficeUsername === 'coeoffice' ||
            activeOfficeKey === PermanentOfficeKey.COE) && (
            <CoeOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              8. FINANCE OFFICE: Invoices & Reconciliation (Phase 9 Complete)
             ========================================================================= */}
          {(activeTab === 'finance' ||
            activeOfficeUsername === 'finance' ||
            activeOfficeKey === PermanentOfficeKey.FINANCE) && (
            <FinanceOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              9. HOSTEL OFFICE: Room Allocations & Inventory (Phase 9 Complete)
             ========================================================================= */}
          {(activeTab === 'hostel' ||
            activeOfficeUsername === 'hosteloffice' ||
            activeOfficeKey === PermanentOfficeKey.HOSTEL) && (
            <HostelOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              9b. IT OFFICE: Technical Services & Infrastructure (Phase 10)
             ========================================================================= */}
          {(activeTab === 'it' ||
            activeOfficeUsername === 'itoffice' ||
            activeOfficeKey === PermanentOfficeKey.IT) && (
            <ItOfficeSection onRefreshData={loadAllData} />
          )}

          {/* =========================================================================
              10. TEACHING FACULTY DASHBOARD (Separated from Non-Teaching Offices)
             ========================================================================= */}
          {isFaculty && (
            <div className="space-y-6">
              {/* Tab 1: My Courses & Class Rosters */}
              {activeTab === 'faculty_courses' && (
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                      <div>
                        <h3 className="font-bold text-slate-900 text-base">My Teaching Course Allocations</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Academic offerings and sections allocated to your faculty registration number by the Academic Office.
                        </p>
                      </div>
                      <div className="text-xs font-mono px-2.5 py-1 rounded-lg bg-blue-50 text-[#1E3A8A] font-semibold border border-blue-100 self-start sm:self-auto">
                        Allocated Courses: {myFacultyAssignments.length}
                      </div>
                    </div>

                    {myFacultyAssignments.length === 0 ? (
                      <div className="py-12 px-4 text-center rounded-xl bg-slate-50 border border-dashed border-slate-200">
                        <div className="w-12 h-12 rounded-2xl bg-white shadow-xs border border-slate-200 text-slate-400 mx-auto flex items-center justify-center mb-3">
                          <BookOpen className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-slate-800 text-sm">No Teaching Allocations Found</h4>
                        <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 leading-relaxed">
                          You currently do not have any active course or section assignments. The Academic Office (<span className="font-mono text-slate-700">academicoffice</span>) manages faculty allocations to academic curriculum offerings.
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {myFacultyAssignments.map((fca) => (
                          <div
                            key={fca.faculty_assignment_id}
                            className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex flex-col justify-between gap-4 hover:border-blue-300 transition-all"
                          >
                            <div>
                              <div className="flex items-center justify-between gap-2">
                                <span className="px-2.5 py-1 rounded-lg text-xs font-bold font-mono bg-blue-50 text-[#1E3A8A] border border-blue-200">
                                  {fca.course_code}
                                </span>
                                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                                  Sec {fca.section}
                                </span>
                              </div>
                              <h4 className="font-bold text-slate-900 mt-2 text-sm">{fca.course_title}</h4>
                              <div className="text-xs text-slate-500 mt-1 space-y-0.5">
                                <div>Dept: <span className="font-semibold text-slate-700">{fca.department}</span> · Sem: <span className="font-semibold text-slate-700">{fca.semester}</span></div>
                                <div>Role: <span className="font-semibold text-slate-700">{fca.role_in_course.replace('_', ' ')}</span></div>
                                <div className="text-[11px] font-mono text-slate-400">AY: {fca.academic_year}</div>
                              </div>
                            </div>

                            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
                              <button
                                type="button"
                                onClick={() => handleOpenRoster(fca)}
                                className="w-full py-2 px-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                              >
                                <Users className="w-3.5 h-3.5 text-[#1E3A8A]" />
                                <span>View Class Roster</span>
                              </button>
                              <div className="grid grid-cols-2 gap-2">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setAttCourseCode(fca.course_code);
                                    setActiveTab('faculty_attendance');
                                  }}
                                  className="py-1.5 px-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-[#1E3A8A] text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                                >
                                  <CalendarCheck className="w-3.5 h-3.5" />
                                  <span>Attendance</span>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setFacGradeCourse(fca.course_code);
                                    setActiveTab('faculty_grades');
                                  }}
                                  className="py-1.5 px-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                                >
                                  <Award className="w-3.5 h-3.5" />
                                  <span>Grades</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tab 2: Mark Class Attendance */}
              {activeTab === 'faculty_attendance' && (
                <div className="space-y-6">
                  {/* Mark Attendance Form */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
                    <div className="flex items-center gap-2 text-[#1E3A8A] mb-4">
                      <CalendarCheck className="w-5 h-5" />
                      <div>
                        <h3 className="font-bold text-slate-900">Mark Student Session Attendance</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Attendance entries are restricted to students enrolled in your assigned sections.
                        </p>
                      </div>
                    </div>

                    {myFacultyAssignments.length === 0 ? (
                      <div className="p-6 rounded-xl bg-amber-50 text-amber-800 text-xs border border-amber-200">
                        You have not been assigned to any course offerings. Only assigned faculty can mark attendance for class sections.
                      </div>
                    ) : (
                      <form onSubmit={handleRecordAttendance} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Assigned Course &amp; Section <span className="text-rose-500">*</span>
                          </label>
                          <select
                            value={attCourseCode}
                            onChange={(e) => setAttCourseCode(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-mono font-semibold"
                          >
                            {myFacultyAssignments.map((fca) => (
                              <option key={fca.faculty_assignment_id} value={fca.course_code}>
                                {fca.course_code} (Sec {fca.section})
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Enrolled Student <span className="text-rose-500">*</span>
                          </label>
                          {isLoadingAttRoster ? (
                            <div className="px-3 py-2 text-xs text-slate-400 bg-slate-50 rounded-xl">Loading roster...</div>
                          ) : attRoster.length === 0 ? (
                            <select disabled className="w-full px-3 py-2 rounded-xl text-xs bg-slate-100 border border-slate-200 text-slate-400">
                              <option>No students enrolled in section</option>
                            </select>
                          ) : (
                            <select
                              value={attStudentId}
                              onChange={(e) => setAttStudentId(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-medium"
                            >
                              {attRoster.map((item) => (
                                <option key={item.enrolment.enrolment_id} value={item.student.student_id}>
                                  {item.student.first_name} {item.student.last_name} ({item.student.registration_number})
                                </option>
                              ))}
                            </select>
                          )}
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
                          <select
                            value={attStatusVal}
                            onChange={(e) => setAttStatusVal(e.target.value as AttendanceStatus)}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-semibold"
                          >
                            <option value={AttendanceStatus.PRESENT}>PRESENT</option>
                            <option value={AttendanceStatus.LATE}>LATE</option>
                            <option value={AttendanceStatus.ABSENT}>ABSENT</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Remarks (Optional)</label>
                          <input
                            type="text"
                            placeholder="e.g. Lab exercise 3"
                            value={attRemarksVal}
                            onChange={(e) => setAttRemarksVal(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200"
                          />
                        </div>

                        <div className="flex items-end">
                          <button
                            type="submit"
                            disabled={attRoster.length === 0 || !attStudentId}
                            className="w-full py-2 px-4 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <CalendarCheck className="w-4 h-4" />
                            <span>Record Entry</span>
                          </button>
                        </div>
                      </form>
                    )}
                  </div>

                  {/* Attendance Roster Table */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                    <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                      <div>
                        <h2 className="text-base font-bold text-slate-900">Recorded Course Attendance Logs</h2>
                        <p className="text-xs text-slate-500 mt-0.5">Logs for your assigned curriculum offerings.</p>
                      </div>
                      <div className="text-xs text-slate-500 font-mono">Total Recorded: {attendanceRecords.length}</div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                          <tr>
                            <th className="px-6 py-3.5">Date</th>
                            <th className="px-6 py-3.5">Course</th>
                            <th className="px-6 py-3.5">Student ID</th>
                            <th className="px-6 py-3.5">Status</th>
                            <th className="px-6 py-3.5">Remarks</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800">
                          {attendanceRecords.length === 0 ? (
                            <tr>
                              <td colSpan={5} className="px-6 py-8 text-center text-xs text-slate-400">
                                No attendance records logged yet.
                              </td>
                            </tr>
                          ) : (
                            attendanceRecords.map((att) => (
                              <tr key={att.attendance_id} className="hover:bg-slate-50/60 transition-colors">
                                <td className="px-6 py-4 font-mono text-slate-600">{att.date}</td>
                                <td className="px-6 py-4 font-mono font-semibold text-[#1E3A8A]">{att.course_code}</td>
                                <td className="px-6 py-4 font-mono">{att.registration_number}</td>
                                <td className="px-6 py-4">
                                  <span
                                    className={`px-2 py-0.5 rounded-md text-xs font-semibold ${
                                      att.status === AttendanceStatus.PRESENT
                                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                        : att.status === AttendanceStatus.LATE
                                        ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                        : 'bg-red-50 text-red-800 border border-red-200'
                                    }`}
                                  >
                                    {att.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-xs text-slate-500">{att.remarks || '—'}</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Internal Assessment Grades */}
              {activeTab === 'faculty_grades' && (
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
                    <div className="flex items-center gap-2 text-[#1E3A8A] mb-4">
                      <Award className="w-5 h-5" />
                      <div>
                        <h3 className="font-bold text-slate-900">Record Course Internal Assessment</h3>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Enter continuous assessment and sessional scores for students in your assigned sections.
                        </p>
                      </div>
                    </div>

                    {myFacultyAssignments.length === 0 ? (
                      <div className="p-6 rounded-xl bg-amber-50 text-amber-800 text-xs border border-amber-200">
                        You have not been assigned to any course offerings. Only assigned faculty can record marks.
                      </div>
                    ) : (
                      <form onSubmit={handleRecordFacultyGrade} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Assigned Course <span className="text-rose-500">*</span>
                          </label>
                          <select
                            value={facGradeCourse}
                            onChange={(e) => setFacGradeCourse(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-mono font-semibold"
                          >
                            {myFacultyAssignments.map((fca) => (
                              <option key={fca.faculty_assignment_id} value={fca.course_code}>
                                {fca.course_code} (Sec {fca.section})
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Enrolled Student <span className="text-rose-500">*</span>
                          </label>
                          {isLoadingGradeRoster ? (
                            <div className="px-3 py-2 text-xs text-slate-400 bg-slate-50 rounded-xl">Loading roster...</div>
                          ) : facGradeRoster.length === 0 ? (
                            <select disabled className="w-full px-3 py-2 rounded-xl text-xs bg-slate-100 border border-slate-200 text-slate-400">
                              <option>No students enrolled in section</option>
                            </select>
                          ) : (
                            <select
                              value={facGradeStudentId}
                              onChange={(e) => setFacGradeStudentId(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-medium"
                            >
                              {facGradeRoster.map((item) => (
                                <option key={item.enrolment.enrolment_id} value={item.student.student_id}>
                                  {item.student.first_name} {item.student.last_name} ({item.student.registration_number})
                                </option>
                              ))}
                            </select>
                          )}
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">Assessment Session</label>
                          <select
                            value={facGradeSession}
                            onChange={(e) => setFacGradeSession(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-mono text-xs"
                          >
                            <option value="FALL_2026_INTERNAL_1">FALL_2026_INTERNAL_1</option>
                            <option value="FALL_2026_INTERNAL_2">FALL_2026_INTERNAL_2</option>
                            <option value="FALL_2026_LAB_SESSIONAL">FALL_2026_LAB_SESSIONAL</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Internal Marks (Max 40) <span className="text-rose-500">*</span>
                          </label>
                          <input
                            type="number"
                            min={0}
                            max={40}
                            required
                            value={facGradeInternalMarks}
                            onChange={(e) => setFacGradeInternalMarks(Number(e.target.value))}
                            className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 font-mono font-bold"
                          />
                        </div>

                        <div className="flex items-end">
                          <button
                            type="submit"
                            disabled={isSubmittingGrade || facGradeRoster.length === 0 || !facGradeStudentId}
                            className="w-full py-2 px-4 rounded-xl bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                          >
                            <Award className="w-4 h-4" />
                            <span>{isSubmittingGrade ? 'Submitting...' : 'Submit Grade'}</span>
                          </button>
                        </div>
                      </form>
                    )}
                  </div>

                  {/* Recorded Grades Table */}
                  <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
                    <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                      <div>
                        <h2 className="text-base font-bold text-slate-900">Recorded Academic Marks &amp; Grades</h2>
                        <p className="text-xs text-slate-500 mt-0.5">Continuous evaluation entries for courses you teach.</p>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm">
                        <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                          <tr>
                            <th className="px-6 py-3.5">Course</th>
                            <th className="px-6 py-3.5">Student Reg #</th>
                            <th className="px-6 py-3.5">Session</th>
                            <th className="px-6 py-3.5">Internal Score</th>
                            <th className="px-6 py-3.5">Grade</th>
                            <th className="px-6 py-3.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800">
                          {examinations
                            .filter((ex) => myFacultyAssignments.some((f) => f.course_code === ex.course_code))
                            .map((ex) => {
                              const s = students.find((stu) => stu.student_id === ex.student_id);
                              return (
                                <tr key={ex.exam_id} className="hover:bg-slate-50/60 transition-colors">
                                  <td className="px-6 py-4 font-mono font-semibold text-[#1E3A8A]">{ex.course_code}</td>
                                  <td className="px-6 py-4 font-mono font-semibold">{s?.registration_number || ex.student_id}</td>
                                  <td className="px-6 py-4 font-mono text-xs">{ex.exam_session}</td>
                                  <td className="px-6 py-4 font-mono font-bold text-slate-900">{ex.internal_marks} / 40</td>
                                  <td className="px-6 py-4 font-mono text-slate-500">{ex.total_marks} / {ex.max_marks}</td>
                                  <td className="px-6 py-4">
                                    <span className="px-2 py-0.5 rounded text-xs font-semibold bg-blue-50 text-blue-900 border border-blue-200">
                                      {ex.exam_status}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
      {/* =========================================================================
          MODALS & DIALOGS (Phase 5 Employee Management)
         ========================================================================= */}

      {/* 1. Inspect Profile Modal */}
      {inspectingEmployee && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 overflow-y-auto max-h-[90vh] space-y-6 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3.5">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                    inspectingEmployee.category === EmployeeCategory.TEACHING
                      ? 'bg-blue-100 text-[#1E3A8A]'
                      : 'bg-purple-100 text-purple-900'
                  }`}
                >
                  {inspectingEmployee.category === EmployeeCategory.TEACHING ? (
                    <BookOpen className="w-6 h-6 stroke-[2]" />
                  ) : (
                    <UserCheck2 className="w-6 h-6 stroke-[2]" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-xl font-bold text-slate-900">
                      {inspectingEmployee.first_name} {inspectingEmployee.last_name}
                    </h2>
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        inspectingEmployee.category === EmployeeCategory.TEACHING
                          ? 'bg-blue-50 text-blue-900 border border-blue-200'
                          : 'bg-purple-50 text-purple-900 border border-purple-200'
                      }`}
                    >
                      {inspectingEmployee.category}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        inspectingEmployee.employment_status === EmploymentStatus.ACTIVE
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : inspectingEmployee.employment_status === EmploymentStatus.PROBATION
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-300'
                      }`}
                    >
                      {inspectingEmployee.employment_status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="font-mono text-xs font-semibold text-[#1E3A8A] bg-blue-50/60 px-2 py-0.5 rounded border border-blue-200/50">
                      {inspectingEmployee.registration_number}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(inspectingEmployee.registration_number)}
                      title="Copy ID"
                      className="text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {copiedText === inspectingEmployee.registration_number ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <span className="text-xs text-slate-400 font-mono">
                      (ID: {inspectingEmployee.employee_id})
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setInspectingEmployee(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Grid: Official & Personal Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50/70 p-4 rounded-xl border border-slate-100">
              <div>
                <span className="text-slate-500 font-medium block">Designation</span>
                <span className="font-bold text-slate-900 text-sm mt-0.5 block">{inspectingEmployee.designation}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Department</span>
                <span className="font-semibold text-slate-900 block mt-0.5 font-mono">{inspectingEmployee.primary_department}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Institutional Email</span>
                <span className="font-semibold text-slate-900 block mt-0.5 font-mono">{inspectingEmployee.institutional_email}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Contact Phone</span>
                <span className="font-semibold text-slate-900 block mt-0.5 font-mono">{inspectingEmployee.phone_number}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Date of Joining</span>
                <span className="font-semibold text-slate-900 block mt-0.5 font-mono">{inspectingEmployee.date_of_joining}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block">Record Created</span>
                <span className="font-semibold text-slate-900 block mt-0.5 font-mono text-[11px]">
                  {inspectingEmployee.created_at ? new Date(inspectingEmployee.created_at).toLocaleDateString() : 'System'}
                </span>
              </div>
            </div>

            {/* Institutional Roles Context Section */}
            {inspectingEmployee.category === EmployeeCategory.TEACHING ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-blue-700" />
                    <span>Academic Course Allocations</span>
                  </h3>
                  <span className="text-[11px] text-slate-500 italic">Governed by Academic Office</span>
                </div>

                {facultyAssignments.filter((f) => f.employee_id === inspectingEmployee.employee_id).length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 text-xs text-slate-500 text-center">
                    No courses currently allocated. Teaching faculty course assignments are scheduled via Academic Office.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {facultyAssignments
                      .filter((f) => f.employee_id === inspectingEmployee.employee_id)
                      .map((fca) => (
                        <div
                          key={fca.faculty_assignment_id}
                          className="p-3 rounded-xl bg-blue-50/40 border border-blue-200/60 flex items-center justify-between text-xs"
                        >
                          <div>
                            <span className="font-mono font-bold text-[#1E3A8A]">{fca.course_code}: </span>
                            <span className="font-medium text-slate-900">{fca.course_title}</span>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              Semester {fca.semester} · Section {fca.section} · {fca.academic_year}
                            </div>
                          </div>
                          <span className="px-2 py-0.5 rounded bg-blue-100/80 text-blue-900 font-semibold text-[11px]">
                            {fca.role_in_course}
                          </span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-purple-700" />
                    <span>Permanent Office Assignments</span>
                  </h3>
                  <span className="text-[11px] text-slate-500 italic">Delegated by Administration</span>
                </div>

                {officeAssignments.filter((a) => a.employee_id === inspectingEmployee.employee_id).length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 text-xs text-slate-500 text-center">
                    No permanent office assignments recorded. Assign this staff member to an office in the Staff Assignments tab.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {officeAssignments
                      .filter((a) => a.employee_id === inspectingEmployee.employee_id)
                      .map((oas) => {
                        const off = SIX_PERMANENT_OFFICES.find((o) => o.office_id === oas.office_id);
                        return (
                          <div
                            key={oas.assignment_id}
                            className="p-3 rounded-xl bg-purple-50/40 border border-purple-200/60 flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="font-bold text-slate-900">{off?.office_name || oas.office_id}</div>
                              <div className="text-xs text-purple-900 font-medium mt-0.5">
                                Role: {oas.assigned_role_title}
                              </div>
                              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                                Effective: {oas.effective_from || '—'} {oas.effective_to ? `to ${oas.effective_to}` : '(Active)'}
                              </div>
                            </div>
                            <span
                              className={`px-2 py-0.5 rounded font-semibold text-[11px] ${
                                oas.assignment_status === OfficeAssignmentStatus.ACTIVE
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {oas.assignment_status}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>
            )}

            {/* Login Account & Security Details */}
            <div className="p-4 rounded-xl bg-slate-900 text-white space-y-2 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-emerald-400" />
                  <span>Employee Login Account Provisioning</span>
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono font-semibold">
                  Active &amp; Repeat-Safe
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                <div>
                  <span className="text-slate-400">Login Username:</span>
                  <div className="font-mono text-white font-bold">{inspectingEmployee.registration_number}</div>
                </div>
                <div>
                  <span className="text-slate-400">Target Portal:</span>
                  <div className="text-white font-medium">Employee Login Gateway</div>
                </div>
                <div>
                  <span className="text-slate-400">Password Storage:</span>
                  <div className="text-emerald-400 font-medium">One-Way Salated Hash (Zero Plaintext)</div>
                </div>
                <div>
                  <span className="text-slate-400">Access Status:</span>
                  <div className="text-white font-medium">
                    {inspectingEmployee.employment_status === EmploymentStatus.ACTIVE
                      ? 'Authorized'
                      : `Suspended (${inspectingEmployee.employment_status})`}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  const emp = inspectingEmployee;
                  setInspectingEmployee(null);
                  handleOpenEditModal(emp);
                }}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Permitted Details</span>
              </button>

              <button
                type="button"
                onClick={() => setInspectingEmployee(null)}
                className="px-5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] text-white text-xs font-semibold cursor-pointer shadow-xs transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Edit Permitted Details Modal */}
      {editingEmployee && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5 text-[#1E3A8A]">
                <Edit3 className="w-5 h-5" />
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Edit Employee Profile</h3>
                  <p className="text-xs text-slate-500">
                    Update permitted details for {editingEmployee.first_name} {editingEmployee.last_name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Immutable Registration Number & Category Banner */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-500 font-medium block">Immutable Registration Number</span>
                <span className="font-mono font-bold text-[#1E3A8A] text-sm">{editingEmployee.registration_number}</span>
              </div>
              <div className="text-right">
                <span className="text-slate-500 font-medium block">Category</span>
                <span className="font-semibold text-slate-800">{editingEmployee.category}</span>
              </div>
            </div>

            {editError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{editError}</span>
              </div>
            )}

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    required
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Institutional Email</label>
                  <input
                    type="email"
                    required
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Primary Department</label>
                  <select
                    value={editDept}
                    onChange={(e) => setEditDept(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800"
                  >
                    <option value="CSE">CSE — Computer Science &amp; Engineering</option>
                    <option value="ECE">ECE — Electronics &amp; Communication</option>
                    <option value="MECH">MECH — Mechanical Engineering</option>
                    <option value="EEE">EEE — Electrical &amp; Electronics</option>
                    <option value="CIVIL">CIVIL — Civil Engineering</option>
                    <option value="ADM">ADM — Administration</option>
                    <option value="FIN">FIN — Finance</option>
                    <option value="HOS">HOS — Hostel</option>
                    <option value="ADM-OFF">ADM-OFF — Admissions</option>
                    <option value="COE">COE — Examination</option>
                    <option value="ACA">ACA — Academic</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                  <input
                    type="text"
                    required
                    value={editDesignation}
                    onChange={(e) => setEditDesignation(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                  />
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Employment Status</label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as EmploymentStatus)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800"
                  >
                    <option value={EmploymentStatus.ACTIVE}>ACTIVE (Full Regular)</option>
                    <option value={EmploymentStatus.PROBATION}>PROBATION (Evaluation Period)</option>
                    <option value={EmploymentStatus.ON_LEAVE}>ON_LEAVE</option>
                    <option value={EmploymentStatus.RESIGNED}>RESIGNED (Suspends login access)</option>
                    <option value={EmploymentStatus.RETIRED}>RETIRED (Suspends login access)</option>
                    <option value={EmploymentStatus.TERMINATED}>TERMINATED (Suspends login access)</option>
                  </select>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Setting status to RESIGNED, RETIRED, or TERMINATED automatically suspends employee authentication.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingEmployee(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingEdit}
                  className="px-5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] text-white font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {isSubmittingEdit ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>Save Changes</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Transfer Office Assignment Modal */}
      {transferringAssignment && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5 text-[#1E3A8A]">
                <ArrowRightLeft className="w-5 h-5" />
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Transfer Office Assignment</h3>
                  <p className="text-xs text-slate-500">
                    Reassign staff member to another permanent office. Previous assignment will be marked as Transferred.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setTransferringAssignment(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {transferError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{transferError}</span>
              </div>
            )}

            <form onSubmit={handleTransferAssignment} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">New Target Permanent Office</label>
                <select
                  value={transferTargetOfficeId}
                  onChange={(e) => setTransferTargetOfficeId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800"
                >
                  {SIX_PERMANENT_OFFICES.map((off) => (
                    <option key={off.office_id} value={off.office_id}>
                      {off.office_name} ({off.canonical_username})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">New Role Title</label>
                <input
                  type="text"
                  required
                  value={transferRoleTitle}
                  onChange={(e) => setTransferRoleTitle(e.target.value)}
                  placeholder="e.g. Accounts Executive, Warden"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setTransferringAssignment(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTransfer}
                  className="px-5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] text-white font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  {isSubmittingTransfer ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Transferring...</span>
                    </>
                  ) : (
                    <span>Confirm Transfer</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Confirmation Dialog Modal (Destructive / Critical actions) */}
      {confirmDialog && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  confirmDialog.isDestructive ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                }`}
              >
                {confirmDialog.isDestructive ? (
                  <Trash2 className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">{confirmDialog.title}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {confirmDialog.description}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-100 font-semibold text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDialog.onConfirm}
                className={`px-5 py-2 rounded-xl font-semibold text-xs text-white cursor-pointer shadow-xs transition-colors ${
                  confirmDialog.isDestructive
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-[#1E3A8A] hover:bg-[#172E6E]'
                }`}
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Class Section Roster Modal (Teaching Faculty) */}
      {viewingRosterAssignment && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] flex flex-col">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#1E3A8A] flex items-center justify-center shrink-0">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    Section Roster: {viewingRosterAssignment.course_code} (Sec {viewingRosterAssignment.section})
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {viewingRosterAssignment.course_title} · {viewingRosterAssignment.department} · Semester {viewingRosterAssignment.semester}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setViewingRosterAssignment(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {rosterError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{rosterError}</span>
              </div>
            )}

            <div className="overflow-y-auto flex-1">
              {isLoadingRoster ? (
                <div className="py-12 text-center text-xs text-slate-400">Loading student roster...</div>
              ) : rosterStudents.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                  No students currently enrolled in this section.
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-700 uppercase tracking-wider font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Student Name</th>
                      <th className="px-4 py-2.5">Reg #</th>
                      <th className="px-4 py-2.5">Department</th>
                      <th className="px-4 py-2.5">Enrolment Date</th>
                      <th className="px-4 py-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {rosterStudents.map(({ enrolment, student }) => {
                      return (
                        <tr key={enrolment.enrolment_id} className="hover:bg-slate-50/60">
                          <td className="px-4 py-3 font-semibold text-slate-900">
                            {student.first_name} {student.last_name}
                          </td>
                          <td className="px-4 py-3 font-mono text-[#1E3A8A] font-bold">{student.registration_number}</td>
                          <td className="px-4 py-3">{student.department || '—'}</td>
                          <td className="px-4 py-3 font-mono text-slate-500">{enrolment.enrolled_at.split('T')[0]}</td>
                          <td className="px-4 py-3">
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                              {enrolment.enrolment_status}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Total Enrolled: {rosterStudents.length} Students</span>
              <button
                type="button"
                onClick={() => setViewingRosterAssignment(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer transition-colors"
              >
                Close Roster
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Employee Modal */}
      <AddEmployeeModal
        isOpen={isAddEmployeeModalOpen}
        onClose={() => setIsAddEmployeeModalOpen(false)}
        onEmployeeCreated={(newEmp) => {
          setEmployees((prev) => [newEmp, ...prev]);
          loadAllData();
        }}
        existingEmployees={employees}
        dataAdapter={dataAdapter}
        actor={session?.user ? { userId: session.user.user_id, role: session.user.role, employeeId: session.user.linked_record_id } : undefined}
      />
    </div>
  );
}

