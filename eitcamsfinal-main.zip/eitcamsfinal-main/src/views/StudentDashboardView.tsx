import { useAuth } from '../context/AuthContext';
import { StudentWorkspace } from '../components/student/StudentWorkspace';
import { UserSession } from '../types/auth';

/**
 * Student Dashboard Route View
 * Connects the authenticated student session to the reference-based Student Workspace.
 * Strictly derives student identity from session context without any hardcoded identity fallback.
 */
export function StudentDashboardView() {
  const { session, logout } = useAuth();

  if (!session) {
    return null;
  }

  // Guard against unauthorized non-student access to Student Portal
  if (session.portalType && session.portalType !== 'student') {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-6">
        <div className="bg-white rounded-xl border border-rose-200 shadow-xs p-8 max-w-md w-full text-center space-y-4">
          <h2 className="text-lg font-bold text-[#1e293b]">Unauthorized Portal Access</h2>
          <p className="text-xs text-[#475569]">
            The current active session is not authenticated as a student account.
          </p>
          <button
            type="button"
            onClick={logout}
            className="px-4 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  // Derive authenticated student identity strictly from the active session
  // Do NOT fall back to arbitrary 'STU-001' or any other student record
  const studentProfile = session.studentProfile;
  const username = session.user?.username || studentProfile?.registration_number || '';
  const studentId =
    studentProfile?.student_id ||
    session.user?.linked_record_id ||
    session.user?.user_id ||
    username;

  const displayName =
    session.displayName ||
    (studentProfile
      ? `${studentProfile.first_name} ${studentProfile.last_name}`.trim()
      : '') ||
    session.user?.username ||
    'Student';

  const userSession: UserSession = {
    id: studentId,
    username: username,
    email: studentProfile?.institutional_email || '',
    displayName: displayName,
    role: session.role || 'STUDENT',
    portalType: session.portalType || 'student',
  };

  return <StudentWorkspace user={userSession} onLogout={logout} />;
}
