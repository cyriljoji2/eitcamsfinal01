import { LandingPage } from '../components/landing/LandingPage';
import { PortalType } from '../types/portal';

export interface HomeGatewayViewProps {
  onSelectPortal?: (portal: PortalType) => void;
}

export function HomeGatewayView({ onSelectPortal }: HomeGatewayViewProps = {}) {
  return <LandingPage onSelectPortal={onSelectPortal} />;
}
