import { PortalType } from '../types/portal';
import { LoginPage } from '../components/auth/LoginPage';

export interface PortalLoginViewProps {
  portalId: PortalType;
  onBackToHome?: () => void;
  onLoginSuccess?: (portalType: PortalType) => void;
}

export function PortalLoginView({ portalId, onBackToHome, onLoginSuccess }: PortalLoginViewProps) {
  return (
    <LoginPage
      key={portalId}
      portal={portalId}
      onBackToHome={onBackToHome}
      onLoginSuccess={onLoginSuccess}
    />
  );
}
