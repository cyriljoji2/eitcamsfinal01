import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ParentWorkspace } from '../components/parent/ParentWorkspace';
import { UserSession } from '../types/auth';
import { PortalType } from '../types/portal';

export function ParentDashboardView() {
  const { session, logout } = useAuth();

  const userSession: UserSession = {
    id: session?.parentProfile?.parent_id || session?.user?.user_id || 'PAR-001',
    username: session?.user?.username || 'parent',
    name: session?.parentProfile
      ? `${session.parentProfile.first_name} ${session.parentProfile.last_name}`
      : session?.displayName || 'Guardian',
    displayName: session?.displayName,
    email: session?.parentProfile?.email,
    role: session?.role || 'PARENT',
    portalType: PortalType.Parent,
  };

  return <ParentWorkspace user={userSession} onLogout={logout} />;
}
