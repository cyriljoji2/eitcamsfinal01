import { FormEvent, useMemo, useState } from 'react';
import {
  BookOpen,
  Info,
  RefreshCw,
  Shield,
  UserCheck2,
  UserPlus,
  X,
} from 'lucide-react';
import { EmployeeCategory, EmployeeRecord, EmploymentStatus } from '../types/database';
import { IEitDataAdapter } from '../services/dataAdapter';
import { allocateNextEmployeeRegistrationNumber } from '../services/regNumberGenerator';

interface AddEmployeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEmployeeCreated: (newEmp: EmployeeRecord) => void;
  existingEmployees: EmployeeRecord[];
  dataAdapter: IEitDataAdapter;
  actor?: { userId: string; role: string; employeeId?: string };
}

export function AddEmployeeModal({
  isOpen,
  onClose,
  onEmployeeCreated,
  existingEmployees,
  dataAdapter,
}: AddEmployeeModalProps) {
  const [category, setCategory] = useState<EmployeeCategory>(EmployeeCategory.TEACHING);
  const [department, setDepartment] = useState('CSE');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('+1 (555) 234-5678');
  const [email, setEmail] = useState('');
  const [designation, setDesignation] = useState('Assistant Professor');
  const [dateOfJoining, setDateOfJoining] = useState(() => new Date().toISOString().split('T')[0]);
  const [status, setStatus] = useState<EmploymentStatus>(EmploymentStatus.ACTIVE);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Live projected registration number preview
  const projectedRegNumber = useMemo(() => {
    const existingRegs = existingEmployees.map((emp) => emp.registration_number);
    const joiningYear = parseInt(dateOfJoining?.split('-')[0], 10) || 2026;
    return allocateNextEmployeeRegistrationNumber(
      existingRegs,
      category,
      department,
      joiningYear
    );
  }, [existingEmployees, category, department, dateOfJoining]);

  if (!isOpen) return null;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!firstName.trim() || !lastName.trim()) {
      setFormError('First Name and Last Name are required.');
      return;
    }
    if (!phoneNumber.trim()) {
      setFormError('Valid contact phone number is required.');
      return;
    }
    if (!dateOfJoining) {
      setFormError('Date of joining is required.');
      return;
    }

    try {
      setIsSubmitting(true);
      const computedEmail = email.trim() || `${firstName.trim().toLowerCase()}.${lastName.trim().toLowerCase()}@eit.edu`;
      const joiningYear = parseInt(dateOfJoining.split('-')[0], 10) || 2026;
      const existingRegs = existingEmployees.map((emp) => emp.registration_number);
      const regNumber = allocateNextEmployeeRegistrationNumber(
        existingRegs,
        category,
        department,
        joiningYear
      );

      const created = await dataAdapter.employees.create({
        registration_number: regNumber,
        category,
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        institutional_email: computedEmail,
        phone_number: phoneNumber.trim(),
        primary_department: department,
        designation: designation.trim() || (category === EmployeeCategory.TEACHING ? 'Assistant Professor' : 'Administrative Officer'),
        employment_status: status,
        date_of_joining: dateOfJoining,
      });

      // Automatically provision account
      try {
        await dataAdapter.employees.provisionAccount(created.employee_id);
      } catch {
        // Non-blocking
      }

      onEmployeeCreated(created);

      // Reset and close
      setFirstName('');
      setLastName('');
      setPhoneNumber('+1 (555) 234-5678');
      setEmail('');
      setDesignation(category === EmployeeCategory.TEACHING ? 'Assistant Professor' : 'Administrative Officer');
      setFormError(null);
      onClose();
    } catch (err: any) {
      setFormError(err?.message || 'Failed to register employee.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#1E3A8A] flex items-center justify-center shrink-0">
              <UserPlus className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Register Employee &amp; Provision Account</h3>
              <p className="text-xs text-slate-500">
                Allocate guaranteed unique registration numbers with automatic account provisioning.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto flex-1 pr-1 space-y-5">
          {/* Category Switcher */}
          <div className="flex items-center justify-between p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setCategory(EmployeeCategory.TEACHING);
                setDesignation('Assistant Professor');
                setDepartment('CSE');
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                category === EmployeeCategory.TEACHING
                  ? 'bg-white text-[#1E3A8A] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Teaching Faculty</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setCategory(EmployeeCategory.NON_TEACHING);
                setDesignation('Administrative Officer');
                setDepartment('ADM');
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                category === EmployeeCategory.NON_TEACHING
                  ? 'bg-white text-purple-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck2 className="w-4 h-4" />
              <span>Non-Teaching Staff</span>
            </button>
          </div>

          {/* Workflow Separation Guidance & Projected ID */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div
              className={`p-3 rounded-xl border col-span-1 sm:col-span-2 ${
                category === EmployeeCategory.TEACHING
                  ? 'bg-blue-50/60 border-blue-200/80 text-blue-900'
                  : 'bg-purple-50/60 border-purple-200/80 text-purple-900'
              }`}
            >
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-[11px] uppercase tracking-wide">
                    {category === EmployeeCategory.TEACHING
                      ? 'Teaching Faculty Workflow'
                      : 'Non-Teaching Staff Workflow'}
                  </span>
                  <p className="text-[11px] mt-0.5 leading-relaxed opacity-90">
                    {category === EmployeeCategory.TEACHING
                      ? 'Assigned to academic courses & sections by the Academic Office.'
                      : 'Assigned to one of the 6 Permanent Offices by Administration.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-900 text-white flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400">Allocated ID Preview</span>
                <div className="text-sm font-mono font-bold text-emerald-400 mt-0.5 tracking-tight">
                  {projectedRegNumber}
                </div>
              </div>
              <span className="text-[10px] text-emerald-300">Guaranteed Unique</span>
            </div>
          </div>

          {formError && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              {formError}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  First Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. David"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Last Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Miller"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Department / Office <span className="text-rose-500">*</span>
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800"
                >
                  {category === EmployeeCategory.TEACHING ? (
                    <>
                      <option value="CSE">CSE — Computer Science &amp; Engineering</option>
                      <option value="ECE">ECE — Electronics &amp; Communication</option>
                      <option value="MECH">MECH — Mechanical Engineering</option>
                      <option value="EEE">EEE — Electrical &amp; Electronics</option>
                      <option value="CIVIL">CIVIL — Civil Engineering</option>
                    </>
                  ) : (
                    <>
                      <option value="ADM">ADM — Administration Office</option>
                      <option value="ADM-OFF">ADM-OFF — Admissions Office</option>
                      <option value="ACA">ACA — Academic Affairs Office</option>
                      <option value="COE">COE — Controller of Examination</option>
                      <option value="FIN">FIN — Finance &amp; Accounts Office</option>
                      <option value="HOS">HOS — Hostel &amp; Residence Office</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Designation <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Assistant Professor"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Institutional Email (Optional)
                </label>
                <input
                  type="email"
                  placeholder="Leave blank to auto-generate"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Contact Phone Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="+1 (555) 234-5678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Date of Joining <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={dateOfJoining}
                  onChange={(e) => setDateOfJoining(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Employment Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as EmploymentStatus)}
                  className="w-full px-3 py-2 rounded-xl text-xs bg-slate-50 border border-slate-200 focus:bg-white focus:border-[#1E3A8A] focus:outline-none font-semibold text-slate-800"
                >
                  <option value={EmploymentStatus.ACTIVE}>ACTIVE (Full Regular)</option>
                  <option value={EmploymentStatus.PROBATION}>PROBATION (New Hire)</option>
                  <option value={EmploymentStatus.ON_LEAVE}>ON_LEAVE</option>
                </select>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-100">
              <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-600" />
                <span>One-way hashed credentials provisioned securely.</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:text-slate-800 hover:bg-slate-100 font-semibold text-xs cursor-pointer transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-[#1E3A8A] hover:bg-[#172E6E] text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 transition-all shrink-0"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Provisioning...</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Register &amp; Provision</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
