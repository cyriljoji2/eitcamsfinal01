import React from 'react';
import { ShieldCheck, LogOut, RefreshCw, Menu, X, Award, Calendar } from 'lucide-react';
import { Button } from '../ui/Button';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface CoeHeaderProps {
  currentUserName: string;
  currentUserRole?: string;
  onLogout: () => void;
  onRefreshData?: () => void;
  isRefreshing?: boolean;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export function CoeHeader({
  currentUserName,
  currentUserRole = 'Controller of Examinations',
  onLogout,
  onRefreshData,
  isRefreshing = false,
  mobileMenuOpen,
  setMobileMenuOpen,
}: CoeHeaderProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-black shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-[#1e3a8a] text-base tracking-tight block leading-tight">
                  Office of the Controller of Examinations
                </span>
                <span className="hidden sm:inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-[#1e3a8a] border border-blue-200">
                  Autonomous Examination Cell
                </span>
              </div>
              <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase block">
                Electrix Institute of Technology (EIT)
              </span>
            </div>
          </div>
        </div>

        {/* User Identity & Logout */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-[#1e3a8a] border border-blue-200">
            <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
            <span>AY:</span>
            <span className="font-mono font-bold">{activeAcademicYear || '2026–2027'}</span>
          </div>
          {onRefreshData && (
            <button
              onClick={onRefreshData}
              disabled={isRefreshing}
              title="Refresh Examination Records"
              className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#1e3a8a]' : ''}`} />
            </button>
          )}

          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-bold text-slate-800">{currentUserName}</span>
            <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">
              {currentUserRole}
            </span>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={onLogout}
            className="text-xs gap-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
