import React, { useState } from 'react';
import { X, RotateCcw, AlertTriangle, ShieldCheck } from 'lucide-react';
import { Button } from '../../ui/Button';

interface ReopenMarkEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  schedule: any | null;
  onConfirmReopen: (scheduleId: string, reason: string) => Promise<void>;
  currentUserName?: string;
}

export function ReopenMarkEntryModal({
  isOpen,
  onClose,
  schedule,
  onConfirmReopen,
  currentUserName = 'coeoffice',
}: ReopenMarkEntryModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen || !schedule) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!reason.trim()) {
      setErrorMessage('A descriptive justification reason is strictly required to reopen marks entry.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onConfirmReopen(schedule.id || schedule.schedule_id, reason.trim());
      setReason('');
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to reopen mark entry window.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const courseTitle = schedule.courseTitle || schedule.courseName || schedule.subjectName || schedule.course_code;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden animate-fadeIn">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center shadow-xs">
              <RotateCcw className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Reopen Faculty Marks Entry</h2>
              <p className="text-xs text-slate-500">Controlled assessment window override</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-500">Course Paper:</span>
              <span className="font-bold text-slate-900">{courseTitle}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Course Code:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">
                {schedule.courseCode || schedule.subjectCode || schedule.course_code}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Target Cohort:</span>
              <span className="font-medium text-slate-700">
                {schedule.programme_code || schedule.className || 'B.Tech'} (Sec {schedule.section || 'A'})
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Documented Justification Reason <span className="text-red-500">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Authorized by COE for faculty correction of missing internal assessment component..."
              rows={3}
              required
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-700 leading-relaxed"
            />
            <span className="text-[10px] text-slate-400">
              Reopening will immediately grant faculty write privileges and generate an immutable audit log entry.
            </span>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              isLoading={isSubmitting}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              Confirm Reopen Window
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
