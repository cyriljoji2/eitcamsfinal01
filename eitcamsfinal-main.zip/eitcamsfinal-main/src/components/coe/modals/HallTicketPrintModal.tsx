import React from 'react';
import { X, Printer, Award, ShieldCheck, Download, CheckCircle2 } from 'lucide-react';
import { Button } from '../../ui/Button';

interface HallTicketPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  hallTicket: any | null;
}

export function HallTicketPrintModal({
  isOpen,
  onClose,
  hallTicket,
}: HallTicketPrintModalProps) {
  if (!isOpen || !hallTicket) return null;

  const handlePrint = () => {
    window.print();
  };

  const schedules = hallTicket.schedules || [];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full overflow-hidden animate-fadeIn">
        {/* Top Modal Controls (Screen Only) */}
        <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 text-xs">University Hall Ticket Preview</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-100 text-[#1e3a8a]">
              {hallTicket.hallTicketNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={handlePrint} className="text-xs gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Admit Card</span>
            </Button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Hall Ticket Document */}
        <div className="p-8 space-y-6 text-slate-900 bg-white" id="printable-hall-ticket">
          {/* Institution Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-700 tracking-wider uppercase mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Autonomous Institution Under University Grants Commission
            </div>
            <h1 className="text-xl font-black tracking-tight uppercase text-slate-900 font-serif">
              ELECTRIX INSTITUTE OF TECHNOLOGY
            </h1>
            <p className="text-xs text-slate-600 font-medium">
              Campus Avenue, Technology City, Chennai — 600127 | Accredited Autonomous University
            </p>
            <h2 className="text-sm font-bold text-[#1e3a8a] tracking-wider uppercase pt-1">
              Office of the Controller of Examinations (COE)
            </h2>
            <div className="inline-block mt-1 px-4 py-1 bg-slate-900 text-white text-xs font-bold uppercase tracking-widest rounded">
              Official Examination Hall Ticket / Admit Card
            </div>
          </div>

          {/* Student Candidate & Session Identification */}
          <div className="grid grid-cols-4 gap-4 p-4 rounded-xl border border-slate-300 bg-slate-50/50 text-xs">
            <div className="col-span-3 grid grid-cols-2 gap-y-2 gap-x-4">
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Examination Session:</span>
                <span className="font-bold text-slate-900">{hallTicket.examinationName}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Academic Year:</span>
                <span className="font-bold text-slate-900">{hallTicket.academicSession || '2026–2027'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Candidate Full Name:</span>
                <span className="font-bold text-slate-900 uppercase">{hallTicket.studentName}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Registration Number:</span>
                <span className="font-mono font-black text-[#1e3a8a] text-sm">
                  {hallTicket.studentRegistrationNumber}
                </span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Programme / Degree:</span>
                <span className="font-semibold text-slate-800">{hallTicket.className || 'B.Tech CSE'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium block text-[11px]">Hall Ticket Number:</span>
                <span className="font-mono font-bold text-slate-900">{hallTicket.hallTicketNumber}</span>
              </div>
            </div>

            {/* Photo Box */}
            <div className="col-span-1 flex flex-col items-center justify-center border-2 border-dashed border-slate-300 rounded-lg p-2 bg-white text-center">
              <div className="w-20 h-24 bg-slate-100 rounded flex flex-col items-center justify-center text-slate-400">
                <span className="text-[10px] font-semibold text-slate-500 text-center px-1">
                  Affix Passport Photo
                </span>
              </div>
              <span className="text-[9px] text-slate-400 mt-1 uppercase font-bold">Verified ID</span>
            </div>
          </div>

          {/* Scheduled Course Papers Table */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2">
              Registered Examination Papers &amp; Schedule
            </h3>
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                  <tr>
                    <th className="px-3 py-2">Code</th>
                    <th className="px-3 py-2">Course Title</th>
                    <th className="px-3 py-2">Date</th>
                    <th className="px-3 py-2">Time Slot</th>
                    <th className="px-3 py-2">Hall / Room</th>
                    <th className="px-3 py-2 text-center">Invigilator Sign</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {schedules.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-4 text-center text-slate-500">
                        No specific papers slotted.
                      </td>
                    </tr>
                  ) : (
                    schedules.map((s: any, idx: number) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono font-bold text-[#1e3a8a]">{s.courseCode}</td>
                        <td className="px-3 py-2 font-medium">{s.courseName || s.subjectName}</td>
                        <td className="px-3 py-2 font-mono">{s.examDate}</td>
                        <td className="px-3 py-2 font-mono">{s.timeSlot || `${s.startTime} - ${s.endTime}`}</td>
                        <td className="px-3 py-2 font-mono">{s.room || 'Main Hall'}</td>
                        <td className="px-3 py-2 text-center border-l border-slate-200">
                          <div className="h-6 w-20 border-b border-dashed border-slate-300 mx-auto" />
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Examination Instructions */}
          <div className="border border-slate-200 rounded-lg p-3.5 bg-slate-50 text-[10px] space-y-1 text-slate-600 leading-normal">
            <div className="font-bold uppercase text-slate-800 text-[11px] mb-1">
              Instructions to the Candidates:
            </div>
            <p>1. Candidates must arrive at the designated examination venue at least 20 minutes before the scheduled start time.</p>
            <p>2. This Admit Card and the valid University Identity Card must be displayed throughout the assessment.</p>
            <p>3. Electronic gadgets including smartwatches, mobile phones, and unauthorized memory devices are strictly banned.</p>
            <p>4. Candidates will not be permitted to leave the examination hall during the initial 60 minutes or final 10 minutes.</p>
            <p>5. Tampering with or altering any details on this Hall Ticket constitutes an examination malpractice punishable under university bylaws.</p>
          </div>

          {/* Official Signatures & Seal */}
          <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
            <div className="space-y-1">
              <div className="h-10 border-b border-dashed border-slate-400 mx-8" />
              <div className="font-bold text-slate-800">Candidate's Signature</div>
              <div className="text-[10px] text-slate-500">Signed in Presence of Invigilator</div>
            </div>

            <div className="space-y-1">
              <div className="h-10 border-b border-dashed border-slate-400 mx-8" />
              <div className="font-bold text-slate-800">Invigilator's Signature</div>
              <div className="text-[10px] text-slate-500">Hall Verification Authority</div>
            </div>

            <div className="space-y-1 flex flex-col items-center">
              <div className="w-24 h-10 flex items-center justify-center font-serif text-[#1e3a8a] font-black text-sm italic">
                C.O.E. EIT
              </div>
              <div className="w-full border-b border-slate-900" />
              <div className="font-bold text-slate-900">Controller of Examinations</div>
              <div className="text-[10px] text-slate-500">Electrix Institute of Technology</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
