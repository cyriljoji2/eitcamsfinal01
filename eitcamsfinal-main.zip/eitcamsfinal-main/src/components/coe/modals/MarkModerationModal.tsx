import React, { useState, useEffect } from 'react';
import { X, Award, AlertCircle, ShieldCheck } from 'lucide-react';
import { Button } from '../../ui/Button';

interface MarkModerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: any | null;
  onConfirmModerate: (resultId: string, internal: number, external: number, reason: string) => Promise<void>;
}

export function MarkModerationModal({
  isOpen,
  onClose,
  result,
  onConfirmModerate,
}: MarkModerationModalProps) {
  const [internal, setInternal] = useState(0);
  const [external, setExternal] = useState(0);
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (result) {
      setInternal(result.internal_marks ?? result.internalMarks ?? 36);
      setExternal(result.external_marks ?? result.externalMarks ?? 52);
      setReason('');
    }
    setErrorMessage(null);
  }, [result, isOpen]);

  if (!isOpen || !result) return null;

  const total = Number(internal) + Number(external);
  const maxMarks = result.max_marks || result.maxMarks || 100;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (total > maxMarks) {
      setErrorMessage(`Total moderated marks (${total}) cannot exceed maximum marks (${maxMarks}).`);
      return;
    }
    if (internal < 0 || external < 0) {
      setErrorMessage('Marks cannot be negative.');
      return;
    }
    if (!reason.trim()) {
      setErrorMessage('A detailed moderation justification is required by University Examination Regulations.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onConfirmModerate(result.result_id || result.id, Number(internal), Number(external), reason.trim());
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to moderate student marks.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden animate-fadeIn">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-indigo-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Moderate Evaluation Marks</h2>
              <p className="text-xs text-slate-500">Autonomous COE Board of Moderation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-500">Candidate:</span>
              <span className="font-bold text-slate-900">{result.student_name || result.studentName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Registration Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{result.registration_number || result.studentRegistrationNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Course Code:</span>
              <span className="font-mono font-bold text-slate-700">{result.course_code || result.subjectCode}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Internal Assessment (/40)
              </label>
              <input
                type="number"
                value={internal}
                min={0}
                max={50}
                onChange={(e) => setInternal(Number(e.target.value))}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                External Theory (/60)
              </label>
              <input
                type="number"
                value={external}
                min={0}
                max={60}
                onChange={(e) => setExternal(Number(e.target.value))}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
          </div>

          <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center justify-between text-xs font-mono">
            <span className="text-indigo-900 font-bold">Total Moderated Mark:</span>
            <span className="text-base font-black text-indigo-700">
              {total} / {maxMarks} ({Math.round((total / maxMarks) * 100)}%)
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Moderation Reason &amp; Board Justification <span className="text-red-500">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Scrutiny committee re-evaluation of question 4 ambiguity; or anomalous total correction..."
              rows={3}
              required
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-700 leading-relaxed"
            />
            <span className="text-[10px] text-slate-400">
              Moderation adjustments are logged into the Enterprise Audit history.
            </span>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              isLoading={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              Apply Moderation
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
