import React, { useState, useEffect } from 'react';
import { X, UserCheck, ShieldAlert, CheckCircle2, AlertCircle, FileText } from 'lucide-react';
import { Button } from '../../ui/Button';

interface EligibilityModalProps {
  isOpen: boolean;
  onClose: () => void;
  eligibility: any | null;
  onSave: (examId: string, studentRegNo: string, isEligible: boolean, reason?: string) => Promise<void>;
}

export function EligibilityModal({
  isOpen,
  onClose,
  eligibility,
  onSave,
}: EligibilityModalProps) {
  const [isEligible, setIsEligible] = useState(true);
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (eligibility) {
      setIsEligible(Boolean(eligibility.isEligible ?? eligibility.is_eligible));
      setReason(eligibility.ineligibilityReason || eligibility.ineligibility_reasons?.join('; ') || '');
    }
    setErrorMessage(null);
  }, [eligibility, isOpen]);

  if (!isOpen || !eligibility) return null;

  const studentName = eligibility.studentName || eligibility.name || 'Candidate';
  const regNo = eligibility.studentRegistrationNumber || eligibility.registration_number || '';
  const examId = eligibility.examinationId || eligibility.session_id || 'EXAM-2026';
  const attendancePct = eligibility.attendancePercentage ?? eligibility.attendance_percentage ?? 0;
  const feeClearance = Boolean(eligibility.feeClearance ?? eligibility.fee_clearance);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!isEligible && !reason.trim()) {
      setErrorMessage('A documented administrative justification is required when marking a candidate ineligible.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave(examId, regNo, isEligible, reason.trim());
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to update student eligibility.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden animate-fadeIn">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Review Student Eligibility</h2>
              <p className="text-xs text-slate-500">Candidate compliance verification &amp; manual override</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">Student Candidate:</span>
              <span className="font-bold text-slate-900">{studentName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Registration Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{regNo}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Course / Programme:</span>
              <span className="font-medium text-slate-700">
                {eligibility.courseCode || 'All Enrolled Courses'} ({eligibility.className || eligibility.section || 'A'})
              </span>
            </div>
            <div className="flex justify-between pt-1 border-t border-slate-200">
              <span className="text-slate-500">Attendance Compliance:</span>
              <span
                className={`font-mono font-bold ${
                  attendancePct >= 75 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {attendancePct}% {attendancePct >= 75 ? '(Satisfactory ≥ 75%)' : '(Shortage < 75%)'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Institutional Fee Clearance:</span>
              <span
                className={`font-semibold ${
                  feeClearance ? 'text-emerald-700' : 'text-amber-700'
                }`}
              >
                {feeClearance ? 'CLEARED' : 'PENDING CLEARANCE'}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Official Examination Access Status
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setIsEligible(true)}
                className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  isEligible
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-600/20'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <CheckCircle2 className={`w-4 h-4 ${isEligible ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span>ELIGIBLE</span>
              </button>

              <button
                type="button"
                onClick={() => setIsEligible(false)}
                className={`p-3 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  !isEligible
                    ? 'border-red-600 bg-red-50 text-red-800 ring-2 ring-red-600/20'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ShieldAlert className={`w-4 h-4 ${!isEligible ? 'text-red-600' : 'text-slate-400'}`} />
                <span>INELIGIBLE</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Documented Justification / Authority Note <span className="text-red-500">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Approved medical condonation by Dean of Academic Affairs; OR Ineligible due to critical attendance shortage."
              rows={3}
              required
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] text-slate-700"
            />
            <span className="text-[10px] text-slate-400">
              This reason will be immutably recorded in the institutional COE Audit Log.
            </span>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" size="sm" isLoading={isSubmitting}>
              Save Eligibility Decision
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
