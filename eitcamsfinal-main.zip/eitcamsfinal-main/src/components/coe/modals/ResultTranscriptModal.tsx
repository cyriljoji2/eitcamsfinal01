import React from 'react';
import { X, Printer, Award, ShieldCheck, Download, CheckCircle2 } from 'lucide-react';
import { Button } from '../../ui/Button';

interface ResultTranscriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: any | null;
}

export function ResultTranscriptModal({
  isOpen,
  onClose,
  result,
}: ResultTranscriptModalProps) {
  if (!isOpen || !result) return null;

  const handlePrint = () => {
    window.print();
  };

  const subjectMarks = result.subjectMarks || [
    {
      subjectCode: result.subjectCode || 'CS201',
      subjectName: result.subjectName || 'Data Structures',
      credits: result.credits || 4,
      internalMarks: result.internalMarks ?? 36,
      externalMarks: result.externalMarks ?? 52,
      marksObtained: result.marksObtained ?? 88,
      maxMarks: result.maxMarks || 100,
      grade: result.grade || 'A+',
      gradePoint: result.gradePoint ?? 9,
      isPassed: result.status === 'Passed' || result.resultStatus === 'Pass',
    },
  ];

  const totalCredits = subjectMarks.reduce((acc: number, s: any) => acc + (s.credits || 4), 0);
  const totalEarnedCredits = subjectMarks
    .filter((s: any) => s.isPassed)
    .reduce((acc: number, s: any) => acc + (s.credits || 4), 0);
  const totalCreditPoints = subjectMarks.reduce(
    (acc: number, s: any) => acc + (s.credits || 4) * (s.gradePoint ?? 8),
    0
  );
  const sgpa = totalCredits > 0 ? (totalCreditPoints / totalCredits).toFixed(2) : '8.50';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full overflow-hidden animate-fadeIn">
        {/* Top Controls (Screen Only) */}
        <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 text-xs">Official University Grade Transcript</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800">
              OFFICIALLY PUBLISHED
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={handlePrint} className="text-xs gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Transcript</span>
            </Button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Transcript Document */}
        <div className="p-8 space-y-6 text-slate-900 bg-white" id="printable-transcript">
          {/* Institution Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-slate-100 text-[10px] font-bold text-slate-700 tracking-wider uppercase mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Autonomous Institution Under University Grants Commission
            </div>
            <h1 className="text-xl font-black tracking-tight uppercase text-slate-900 font-serif">
              ELECTRIX INSTITUTE OF TECHNOLOGY
            </h1>
            <p className="text-xs text-slate-600 font-medium">
              Campus Avenue, Technology City, Chennai — 600127 | Accredited Autonomous University
            </p>
            <h2 className="text-sm font-bold text-[#1e3a8a] tracking-wider uppercase pt-1">
              Office of the Controller of Examinations (COE)
            </h2>
            <div className="inline-block mt-1 px-4 py-1 bg-[#1e3a8a] text-white text-xs font-bold uppercase tracking-widest rounded">
              Statement of Grades &amp; Academic Transcript
            </div>
          </div>

          {/* Student Profile Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl border border-slate-300 bg-slate-50/50 text-xs">
            <div>
              <span className="text-slate-500 font-medium block text-[11px]">Candidate Full Name:</span>
              <span className="font-bold text-slate-900 uppercase">{result.studentName}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block text-[11px]">Registration Number:</span>
              <span className="font-mono font-black text-[#1e3a8a]">{result.studentRegistrationNumber}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block text-[11px]">Degree &amp; Programme:</span>
              <span className="font-semibold text-slate-800">{result.className || 'B.Tech CSE'}</span>
            </div>
            <div>
              <span className="text-slate-500 font-medium block text-[11px]">Academic Term:</span>
              <span className="font-bold text-slate-900">{result.semester || 'Semester 3'}</span>
            </div>
          </div>

          {/* Grades Table */}
          <div>
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 border-b border-slate-300 font-bold text-slate-800">
                  <tr>
                    <th className="px-3 py-2.5">Course Code</th>
                    <th className="px-3 py-2.5">Course Title</th>
                    <th className="px-3 py-2.5 text-center">Credits</th>
                    <th className="px-3 py-2.5 text-center">Internal</th>
                    <th className="px-3 py-2.5 text-center">External</th>
                    <th className="px-3 py-2.5 text-center">Total</th>
                    <th className="px-3 py-2.5 text-center">Grade</th>
                    <th className="px-3 py-2.5 text-center">Points</th>
                    <th className="px-3 py-2.5 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {subjectMarks.map((s: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-mono font-bold text-[#1e3a8a]">{s.subjectCode}</td>
                      <td className="px-3 py-2.5 font-medium">{s.subjectName}</td>
                      <td className="px-3 py-2.5 text-center font-mono">{s.credits || 4}</td>
                      <td className="px-3 py-2.5 text-center font-mono">{s.internalMarks ?? '-'}</td>
                      <td className="px-3 py-2.5 text-center font-mono">{s.externalMarks ?? '-'}</td>
                      <td className="px-3 py-2.5 text-center font-mono font-bold">{s.marksObtained}</td>
                      <td className="px-3 py-2.5 text-center font-bold">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a] border border-blue-200">
                          {s.grade}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center font-mono">{s.gradePoint ?? 9}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            s.isPassed ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
                          }`}
                        >
                          {s.isPassed ? 'PASS' : 'FAIL'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Transcript Summary Metrics */}
          <div className="grid grid-cols-4 gap-3 p-4 rounded-xl border border-slate-300 bg-slate-50 text-center text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Registered Credits</span>
              <span className="text-base font-bold font-mono text-slate-900">{totalCredits}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Earned Credits</span>
              <span className="text-base font-bold font-mono text-emerald-700">{totalEarnedCredits}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Semester GPA (SGPA)</span>
              <span className="text-base font-bold font-mono text-[#1e3a8a]">{sgpa} / 10.0</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-500 block">Cumulative GPA (CGPA)</span>
              <span className="text-base font-bold font-mono text-slate-900">{sgpa} / 10.0</span>
            </div>
          </div>

          {/* Grading System Legend */}
          <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50 text-[10px] text-slate-600">
            <span className="font-bold uppercase text-slate-800 block mb-1">EIT Autonomous Grading System:</span>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1 font-mono">
              <div>O (10): 90-100%</div>
              <div>A+ (9): 80-89%</div>
              <div>A (8): 70-79%</div>
              <div>B+ (7): 60-69%</div>
              <div>B (6): 50-59%</div>
              <div>C (5): 40-49%</div>
              <div>F (0): Fail &lt;40%</div>
            </div>
          </div>

          {/* Official Seals & Date */}
          <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
            <div className="space-y-1">
              <div className="text-[11px] font-mono text-slate-500">Date of Declaration:</div>
              <div className="font-bold text-slate-800">
                {result.publishedAt ? new Date(result.publishedAt).toLocaleDateString() : 'November 3, 2026'}
              </div>
            </div>

            <div className="space-y-1">
              <div className="w-16 h-16 rounded-full border-2 border-slate-400 mx-auto flex items-center justify-center text-[9px] uppercase font-bold text-slate-400">
                Official Seal
              </div>
            </div>

            <div className="space-y-1 flex flex-col items-center">
              <div className="w-24 h-10 flex items-center justify-center font-serif text-[#1e3a8a] font-black text-sm italic">
                C.O.E. EIT
              </div>
              <div className="w-full border-b border-slate-900" />
              <div className="font-bold text-slate-900">Controller of Examinations</div>
              <div className="text-[10px] text-slate-500">Electrix Institute of Technology</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
