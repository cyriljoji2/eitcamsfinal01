import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, MapPin, User, BookOpen, AlertCircle, Shield } from 'lucide-react';
import { Button } from '../../ui/Button';
import { CourseRecord, DepartmentRecord, EmployeeRecord, ExamType } from '../../../types/database';

interface ExamScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  initialData?: any | null;
  examinations: any[];
  departments?: DepartmentRecord[];
  courses: CourseRecord[];
  facultyMembers?: EmployeeRecord[];
  defaultExamId?: string;
}

export function ExamScheduleModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  examinations,
  departments = [],
  courses = [],
  facultyMembers = [],
  defaultExamId,
}: ExamScheduleModalProps) {
  const [examinationId, setExaminationId] = useState('');
  const [examName, setExamName] = useState('');
  const [courseCode, setCourseCode] = useState('CS201');
  const [programmeCode, setProgrammeCode] = useState('BTECH-CSE');
  const [department, setDepartment] = useState('CSE');
  const [semester, setSemester] = useState(3);
  const [section, setSection] = useState('A');
  const [examDate, setExamDate] = useState('');
  const [startTime, setStartTime] = useState('09:30');
  const [endTime, setEndTime] = useState('12:30');
  const [room, setRoom] = useState('Exam Hall 101');
  const [examType, setExamType] = useState<ExamType>(ExamType.END_SEMESTER);
  const [maxMarks, setMaxMarks] = useState(100);
  const [passingMarks, setPassingMarks] = useState(40);
  const [assignedFacultyId, setAssignedFacultyId] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setExaminationId(initialData.examinationId || initialData.session_id || '');
      setExamName(initialData.exam_name || initialData.subjectName || '');
      setCourseCode(initialData.courseCode || initialData.course_code || initialData.subjectCode || 'CS201');
      setProgrammeCode(initialData.programme_code || initialData.className || 'BTECH-CSE');
      setDepartment(initialData.department || 'CSE');
      setSemester(Number(initialData.semester || 3));
      setSection(initialData.section || 'A');
      setExamDate(initialData.examDate || initialData.exam_date || '');
      setStartTime(initialData.startTime || initialData.start_time || '09:30');
      setEndTime(initialData.endTime || initialData.end_time || '12:30');
      setRoom(initialData.room || initialData.roomVenue || 'Exam Hall 101');
      setExamType(initialData.examType || initialData.exam_type || ExamType.END_SEMESTER);
      setMaxMarks(Number(initialData.maxMarks || initialData.max_marks || 100));
      setPassingMarks(Number(initialData.passMarks || initialData.passing_marks || 40));
      setAssignedFacultyId(initialData.assigned_evaluator_id || '');
      setNotes(initialData.notes || '');
    } else {
      const fallbackExamId = defaultExamId || examinations[0]?.id || examinations[0]?.session_id || '';
      setExaminationId(fallbackExamId);
      const defaultCourse = courses[0]?.course_code || 'CS201';
      setCourseCode(defaultCourse);
      const selectedCourse = courses.find((c) => c.course_code === defaultCourse);
      setExamName(selectedCourse ? `${selectedCourse.course_title} Theory Exam` : 'Data Structures Theory Exam');
      setProgrammeCode('BTECH-CSE');
      setDepartment(selectedCourse?.department || 'CSE');
      setSemester(selectedCourse?.semester || 3);
      setSection('A');
      setExamDate(new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0]);
      setStartTime('09:30');
      setEndTime('12:30');
      setRoom('Exam Hall 101');
      setExamType(ExamType.END_SEMESTER);
      setMaxMarks(100);
      setPassingMarks(40);
      setAssignedFacultyId(facultyMembers[0]?.employee_id || '');
      setNotes('');
    }
    setErrorMessage(null);
  }, [initialData, examinations, defaultExamId, courses, facultyMembers, isOpen]);

  if (!isOpen) return null;

  const handleCourseChange = (code: string) => {
    setCourseCode(code);
    const crs = courses.find((c) => c.course_code === code);
    if (crs) {
      setExamName(`${crs.course_title} Examination`);
      setDepartment(crs.department);
      if (crs.semester) setSemester(crs.semester);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!examinationId) {
      setErrorMessage('Please select an active examination session.');
      return;
    }
    if (!courseCode) {
      setErrorMessage('Course code is required.');
      return;
    }
    if (!examDate) {
      setErrorMessage('Examination date is required.');
      return;
    }
    if (startTime >= endTime) {
      setErrorMessage('Start time must precede end time.');
      return;
    }

    const selCourse = courses.find((c) => c.course_code === courseCode);
    const faculty = facultyMembers.find((f) => f.employee_id === assignedFacultyId);

    setIsSubmitting(true);
    try {
      await onSubmit({
        id: initialData?.id || initialData?.schedule_id,
        examinationId,
        session_id: examinationId,
        courseCode,
        course_code: courseCode,
        courseName: selCourse?.course_title || examName,
        course_title: selCourse?.course_title || examName,
        subjectCode: courseCode,
        subjectName: selCourse?.course_title || examName,
        programmeCode,
        programme_code: programmeCode,
        className: programmeCode,
        department,
        semester: Number(semester),
        section,
        examDate,
        exam_date: examDate,
        startTime,
        start_time: startTime,
        endTime,
        end_time: endTime,
        room,
        roomVenue: room,
        examType,
        exam_type: examType,
        maxMarks: Number(maxMarks),
        max_marks: Number(maxMarks),
        passMarks: Number(passingMarks),
        passing_marks: Number(passingMarks),
        assigned_evaluator_id: assignedFacultyId,
        assigned_evaluator_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : undefined,
        notes,
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save examination schedule paper.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-2xl w-full overflow-hidden animate-fadeIn">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {initialData ? 'Edit Examination Schedule Paper' : 'Schedule University Course Examination'}
              </h2>
              <p className="text-xs text-slate-500">Timetable slotting with venue & evaluator allocation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Examination Session <span className="text-red-500">*</span>
              </label>
              <select
                value={examinationId}
                onChange={(e) => setExaminationId(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-medium"
              >
                {examinations.map((ex) => (
                  <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                    {ex.name || ex.session_name} ({ex.id || ex.session_id})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Course Curriculum Subject <span className="text-red-500">*</span>
              </label>
              <select
                value={courseCode}
                onChange={(e) => handleCourseChange(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-mono"
              >
                {courses.length > 0 ? (
                  courses.map((c) => (
                    <option key={c.course_code} value={c.course_code}>
                      {c.course_code} — {c.course_title}
                    </option>
                  ))
                ) : (
                  <>
                    <option value="CS201">CS201 — Data Structures</option>
                    <option value="CS202">CS202 — Computer Architecture</option>
                    <option value="CS301">CS301 — Database Management Systems</option>
                    <option value="EC201">EC201 — Digital Electronics</option>
                  </>
                )}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Degree Programme</label>
              <select
                value={programmeCode}
                onChange={(e) => setProgrammeCode(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-mono"
              >
                <option value="BTECH-CSE">BTECH-CSE (Computer Science)</option>
                <option value="BTECH-ECE">BTECH-ECE (Electronics)</option>
                <option value="BTECH-MECH">BTECH-MECH (Mechanical)</option>
                <option value="MTECH-CSE">MTECH-CSE (Postgraduate)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Semester &amp; Section</label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={semester}
                  onChange={(e) => setSemester(Number(e.target.value))}
                  className="w-full px-2 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={s}>
                      Sem {s}
                    </option>
                  ))}
                </select>

                <select
                  value={section}
                  onChange={(e) => setSection(e.target.value)}
                  className="w-full px-2 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-semibold"
                >
                  <option value="A">Sec A</option>
                  <option value="B">Sec B</option>
                  <option value="C">Sec C</option>
                  <option value="ALL">All Cohort</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Examination Category</label>
              <select
                value={examType}
                onChange={(e) => setExamType(e.target.value as ExamType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                <option value={ExamType.END_SEMESTER}>End Semester (Regular)</option>
                <option value={ExamType.SUPPLEMENTARY}>Supplementary / Arrear</option>
                <option value={ExamType.MIDTERM}>Continuous Internal Assessment</option>
                <option value={ExamType.PRACTICAL}>Practical / Laboratory</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Examination Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Time Slot (24h)</label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                  className="w-full px-2 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                />
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                  className="w-full px-2 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Examination Hall / Venue</label>
              <input
                type="text"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="e.g. Exam Hall 101"
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Maximum Marks</label>
              <input
                type="number"
                value={maxMarks}
                min={20}
                max={200}
                onChange={(e) => setMaxMarks(Number(e.target.value))}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Passing Marks Threshold</label>
              <input
                type="number"
                value={passingMarks}
                min={10}
                max={maxMarks}
                onChange={(e) => setPassingMarks(Number(e.target.value))}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Designated Evaluator / Faculty</label>
              <select
                value={assignedFacultyId}
                onChange={(e) => setAssignedFacultyId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                <option value="">-- Unassigned (COE Desk) --</option>
                {facultyMembers.map((fac) => (
                  <option key={fac.employee_id} value={fac.employee_id}>
                    {fac.first_name} {fac.last_name} ({fac.primary_department})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Special Instructions &amp; Permitted Materials</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Non-programmable scientific calculators permitted. Log tables provided."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" size="sm" isLoading={isSubmitting}>
              {initialData ? 'Update Schedule Paper' : 'Schedule Course Exam'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
