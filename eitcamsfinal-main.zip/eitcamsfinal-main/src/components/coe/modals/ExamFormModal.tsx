import React, { useState, useEffect } from 'react';
import { X, Calendar, Layers, FileText, CheckCircle2, AlertCircle, Award } from 'lucide-react';
import { Button } from '../../ui/Button';
import { ExamType, ExamSessionStatus } from '../../../types/database';

interface ExamFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    id: string;
    name: string;
    academicSession: string;
    termType: string;
    semester: number;
    startDate: string;
    endDate: string;
    status: string;
    instructions: string;
    registrationDeadline?: string;
    department?: string;
  }) => Promise<void>;
  initialData?: any | null;
  currentAcademicSession?: string;
  currentUserName?: string;
}

export function ExamFormModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  currentAcademicSession = '2026-2027',
  currentUserName = 'coeoffice',
}: ExamFormModalProps) {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [academicSession, setAcademicSession] = useState(currentAcademicSession);
  const [termType, setTermType] = useState('Semester 3 Regular Examination');
  const [semester, setSemester] = useState(3);
  const [examType, setExamType] = useState<ExamType>(ExamType.END_SEMESTER);
  const [department, setDepartment] = useState('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [regDeadline, setRegDeadline] = useState('');
  const [status, setStatus] = useState<string>('SCHEDULED');
  const [instructions, setInstructions] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setId(initialData.id || initialData.session_id);
      setName(initialData.name || initialData.session_name);
      setAcademicSession(initialData.academicSession || initialData.academic_year || '2026-2027');
      setTermType(initialData.termType || `Semester ${initialData.semester || 3} Examination`);
      setSemester(initialData.semester || 3);
      setStartDate(initialData.startDate || initialData.start_date || '');
      setEndDate(initialData.endDate || initialData.end_date || '');
      setRegDeadline(initialData.registrationDeadline || initialData.registration_deadline || '');
      setStatus(initialData.status || 'SCHEDULED');
      setInstructions(
        initialData.instructions ||
          'Candidates must present their official EIT Hall Ticket and University Identity Card for all sessions. Standard autonomous examination regulations apply.'
      );
    } else {
      const year = new Date().getFullYear();
      setId(`EXAM-SESS-${year}-AUTUMN`);
      setName(`End Semester Examinations — Autumn ${year}`);
      setAcademicSession(currentAcademicSession || `${year}-${year + 1}`);
      setTermType('Semester 3 Regular Examination');
      setSemester(3);
      setExamType(ExamType.END_SEMESTER);
      setDepartment('ALL');
      const start = new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0];
      const end = new Date(Date.now() + 86400000 * 28).toISOString().split('T')[0];
      const reg = new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0];
      setStartDate(start);
      setEndDate(end);
      setRegDeadline(reg);
      setStatus('SCHEDULED');
      setInstructions(
        'Candidates must present their official EIT Hall Ticket and University Identity Card for all sessions. Electronic devices, smartwatches, and unauthorized materials are strictly prohibited inside the examination halls.'
      );
    }
    setErrorMessage(null);
  }, [initialData, currentAcademicSession, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!id.trim()) {
      setErrorMessage('Examination Session ID is required (e.g. EXAM-SESS-2026-AUTUMN).');
      return;
    }
    if (!name.trim()) {
      setErrorMessage('Examination Session Title is required.');
      return;
    }
    if (!startDate || !endDate) {
      setErrorMessage('Please specify valid Start and End dates.');
      return;
    }
    if (new Date(startDate) > new Date(endDate)) {
      setErrorMessage('Start Date must precede End Date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        id: id.trim(),
        name: name.trim(),
        academicSession,
        termType,
        semester: Number(semester),
        startDate,
        endDate,
        registrationDeadline: regDeadline,
        department,
        status,
        instructions: instructions.trim(),
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save examination session.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-2xl w-full overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {initialData ? 'Configure Examination Session' : 'Create University Examination Session'}
              </h2>
              <p className="text-xs text-slate-500">Autonomous curriculum assessment session definition</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMessage && (
          <div className="mx-6 mt-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Session Identifier <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={id}
                onChange={(e) => setId(e.target.value.toUpperCase())}
                placeholder="e.g. EXAM-SESS-2026-AUTUMN"
                disabled={Boolean(initialData)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono bg-slate-50 disabled:bg-slate-100 disabled:text-slate-500"
              />
              <span className="text-[10px] text-slate-400">Institutional session key</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Academic Year <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={academicSession}
                onChange={(e) => setAcademicSession(e.target.value)}
                placeholder="e.g. 2026-2027"
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Examination Title / Description <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. End Semester Theory & Practical Examinations — Autumn 2026"
              required
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Semester</label>
              <select
                value={semester}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSemester(val);
                  setTermType(`Semester ${val} Regular Examination`);
                }}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                  <option key={s} value={s}>
                    Semester {s}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Examination Type</label>
              <select
                value={examType}
                onChange={(e) => setExamType(e.target.value as ExamType)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                <option value={ExamType.END_SEMESTER}>End Semester Regular</option>
                <option value={ExamType.SUPPLEMENTARY}>Supplementary / Arrear</option>
                <option value={ExamType.MIDTERM}>Continuous Internal / Mid-Term</option>
                <option value={ExamType.PRACTICAL}>Practical / Laboratory</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white"
              >
                <option value="ALL">All Departments</option>
                <option value="CSE">Computer Science (CSE)</option>
                <option value="ECE">Electronics (ECE)</option>
                <option value="MECH">Mechanical (MECH)</option>
                <option value="EEE">Electrical (EEE)</option>
                <option value="CIVIL">Civil (CIVIL)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Start Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                End Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Lifecycle Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-white font-semibold"
              >
                <option value="SCHEDULED">SCHEDULED</option>
                <option value="IN_PROGRESS">IN_PROGRESS (Active)</option>
                <option value="MARKS_ENTRY_OPEN">MARKS_ENTRY_OPEN</option>
                <option value="EVALUATION">EVALUATION</option>
                <option value="COMPLETED">COMPLETED (Published)</option>
                <option value="CANCELLED">CANCELLED</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Official Hall Ticket Instructions</label>
            <textarea
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] text-slate-700 leading-relaxed"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" size="sm" isLoading={isSubmitting}>
              {initialData ? 'Save Changes' : 'Create Examination Session'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
