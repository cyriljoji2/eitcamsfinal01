import React from 'react';
import {
  FileText,
  Calendar,
  Lock,
  Unlock,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  Award,
  Users,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Plus,
  BookOpen,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface CoeOverviewProps {
  examinations: any[];
  schedules: any[];
  results: any[];
  hallTickets: any[];
  auditLogs: any[];
  eligibilities?: any[];
  metrics?: any;
  onNavigateTab: (tab: string) => void;
  onOpenCreateExamModal: () => void;
  onOpenScheduleModal: () => void;
}

export function CoeOverview({
  examinations,
  schedules,
  results,
  hallTickets,
  auditLogs,
  eligibilities = [],
  metrics,
  onNavigateTab,
  onOpenCreateExamModal,
  onOpenScheduleModal,
}: CoeOverviewProps) {
  const activeExams = examinations.filter(
    (e) => e.status === 'Active' || e.status === 'IN_PROGRESS' || e.status === 'MARKS_ENTRY_OPEN' || e.status === 'SCHEDULED'
  );
  const markEntryOpenPapers = schedules.filter((s) => s.markEntryStatus === 'Open' || s.marks_entry_open);
  const submittedPapers = schedules.filter((s) => s.markSubmissionStatus === 'Submitted' || s.status === 'FACULTY_SUBMITTED');
  const verifiedPapers = schedules.filter((s) => s.markSubmissionStatus === 'Verified' || s.status === 'APPROVED' || s.status === 'PUBLISHED');
  const publishedExams = examinations.filter((e) => e.status === 'Published' || e.status === 'COMPLETED');

  const totalEligible = eligibilities.length > 0 ? eligibilities.filter((e) => e.isEligible).length : 2;

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Actions Banner */}
      <div className="bg-gradient-to-r from-[#1e3a8a] via-[#1e293b] to-[#0f172a] rounded-2xl p-6 sm:p-7 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-blue-200 mb-2.5 backdrop-blur-xs">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-300" />
            <span>Autonomous University Controller of Examinations Workspace</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Curriculum Examination &amp; Evaluation Governance
          </h1>
          <p className="text-xs sm:text-sm text-blue-100/90 mt-1.5 max-w-2xl leading-relaxed">
            Centralized autonomous management of curriculum assessment sessions, room scheduling, attendance eligibility compliance, faculty marks moderation, and official grade transcript declarations.
          </p>
        </div>
        <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
          <Button
            onClick={onOpenCreateExamModal}
            className="bg-white text-[#1e3a8a] hover:bg-blue-50 font-bold text-xs shadow-sm cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Exam Session</span>
          </Button>
          <Button
            onClick={onOpenScheduleModal}
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 text-xs cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Schedule Course Paper</span>
          </Button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigateTab('exams')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-[#1e3a8a] transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Exam Sessions</span>
            <div className="p-2 bg-blue-50 text-[#1e3a8a] rounded-xl group-hover:bg-[#1e3a8a] group-hover:text-white transition-colors">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{examinations.length}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span className="font-semibold text-[#1e3a8a]">{activeExams.length} active sessions</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('schedule')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-[#1e3a8a] transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Scheduled Papers</span>
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-xl group-hover:bg-indigo-700 group-hover:text-white transition-colors">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{schedules.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Timetable slotted courses</div>
        </div>

        <div
          onClick={() => onNavigateTab('mark-entry')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-amber-600 transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Marks Windows Open</span>
            <div className="p-2 bg-amber-50 text-amber-700 rounded-xl group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Unlock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-700 font-mono">{markEntryOpenPapers.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Faculty submissions in progress</div>
        </div>

        <div
          onClick={() => onNavigateTab('verification')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-emerald-600 transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Awaiting Verification</span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono">{submittedPapers.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span className="font-semibold text-emerald-800">{verifiedPapers.length} verified</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('eligibility')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-[#1e3a8a] transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Eligible Students</span>
            <div className="p-2 bg-teal-50 text-teal-700 rounded-xl group-hover:bg-teal-700 group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">{totalEligible}</div>
          <div className="text-[11px] text-slate-500 mt-1">Attendance &ge; 75% &amp; Fee Cleared</div>
        </div>

        <div
          onClick={() => onNavigateTab('hall-tickets')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-purple-600 transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Hall Tickets Issued</span>
            <div className="p-2 bg-purple-50 text-purple-700 rounded-xl group-hover:bg-purple-700 group-hover:text-white transition-colors">
              <Printer className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-purple-700 font-mono">{hallTickets.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Official admit cards generated</div>
        </div>

        <div
          onClick={() => onNavigateTab('results')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-blue-600 transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Calculated Grades</span>
            <div className="p-2 bg-blue-50 text-blue-700 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-blue-700 font-mono">{results.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Transcripts ready for review</div>
        </div>

        <div
          onClick={() => onNavigateTab('results')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 hover:border-emerald-600 transition-all cursor-pointer shadow-2xs group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Published Results</span>
            <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono">
            {metrics?.publishedResultsCount ?? results.filter((r) => r.isPublished).length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Synced to Student Portals</div>
        </div>
      </div>

      {/* Progress and Active Examinations Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Examination Pipelines */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Active Examination Pipelines</h2>
              <p className="text-xs text-slate-500">Real-time status of scheduled assessments</p>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('exams')}
              className="text-xs gap-1"
            >
              <span>View Registry</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </Button>
          </div>

          <div className="space-y-3">
            {examinations.length === 0 ? (
              <div className="text-center py-10 text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                No examination sessions created yet. Click "New Exam Session" to begin.
              </div>
            ) : (
              examinations.slice(0, 4).map((exam) => {
                const examSchedules = schedules.filter(
                  (s) => s.examinationId === exam.id || s.session_id === exam.id
                );
                const openCount = examSchedules.filter((s) => s.markEntryStatus === 'Open' || s.marks_entry_open).length;
                const verifiedCount = examSchedules.filter(
                  (s) => s.markSubmissionStatus === 'Verified' || s.status === 'APPROVED' || s.status === 'PUBLISHED'
                ).length;
                const total = examSchedules.length;
                const percent = total > 0 ? Math.round((verifiedCount / total) * 100) : 0;

                return (
                  <div
                    key={exam.id}
                    className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{exam.name}</span>
                          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a] border border-blue-200">
                            {exam.id}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {exam.termType || 'Semester Assessment'} &bull; Session: {exam.academicSession || '2026-2027'} &bull;{' '}
                          {exam.startDate} to {exam.endDate}
                        </div>
                      </div>
                      <span
                        className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase ${
                          exam.status === 'Published' || exam.status === 'COMPLETED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : exam.status === 'Mark Entry Open' || exam.status === 'MARKS_ENTRY_OPEN'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {exam.status}
                      </span>
                    </div>

                    {/* Papers progress bar */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] text-slate-500">
                        <span>
                          Evaluation Progress: {verifiedCount}/{total} papers verified ({openCount} open)
                        </span>
                        <span className="font-bold font-mono text-slate-700">{percent}%</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-[#1e3a8a] h-full rounded-full transition-all"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Recent Audit & System Activity */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 sm:p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">COE Audit Trail</h2>
              <p className="text-xs text-slate-500">Immutable authority event log</p>
            </div>
            <div className="p-1 bg-slate-100 text-slate-600 rounded">
              <Clock className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
            {auditLogs.slice(0, 7).map((log) => (
              <div
                key={log.id}
                className="text-xs border-l-2 border-[#1e3a8a] pl-3 py-1 space-y-0.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{log.action.replace('EXAM_', '').replace(/_/g, ' ')}</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">{log.details}</p>
                <div className="text-[10px] text-slate-400">
                  By: <strong className="text-slate-600">{log.performedByName || log.performedBy}</strong>
                </div>
              </div>
            ))}
            {auditLogs.length === 0 && (
              <div className="text-center py-8 text-xs text-slate-400">
                No recent activity logged.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
