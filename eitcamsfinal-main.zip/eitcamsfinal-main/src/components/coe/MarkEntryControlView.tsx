import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  RotateCcw,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  BookOpen,
  Download,
  ShieldCheck,
  Edit3,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface MarkEntryControlViewProps {
  examinations: any[];
  schedules: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenWindow: (scheduleId: string) => Promise<void>;
  onCloseWindow: (scheduleId: string) => Promise<void>;
  onOpenReopenModal: (schedule: any) => void;
  onBulkOpenWindows: (examId: string) => Promise<void>;
  onBulkCloseWindows: (examId: string) => Promise<void>;
  onOpenRecordMarks?: (schedule: any) => void;
}

export function MarkEntryControlView({
  examinations,
  schedules,
  selectedExamId,
  onSelectExamId,
  onOpenWindow,
  onCloseWindow,
  onOpenReopenModal,
  onBulkOpenWindows,
  onBulkCloseWindows,
  onOpenRecordMarks,
}: MarkEntryControlViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'All';

  const examSchedules = schedules.filter(
    (s) => !activeExamId || activeExamId === 'All' || s.examinationId === activeExamId || s.session_id === activeExamId
  );

  const filteredSchedules = examSchedules.filter((sch) => {
    const isWindowOpen = sch.marks_entry_open || sch.markEntryStatus === 'Open';
    const matchesStatus =
      statusFilter === 'All' ||
      (statusFilter === 'Open' && isWindowOpen) ||
      (statusFilter === 'Closed' && !isWindowOpen);

    const q = searchTerm.toLowerCase();
    const title = (sch.course_title || sch.courseName || sch.subjectName || '').toLowerCase();
    const code = (sch.course_code || sch.courseCode || sch.subjectCode || '').toLowerCase();
    const prog = (sch.programme_code || sch.className || '').toLowerCase();
    const fac = (sch.assigned_evaluator_name || sch.assignedFacultyName || '').toLowerCase();

    return matchesStatus && (title.includes(q) || code.includes(q) || prog.includes(q) || fac.includes(q));
  });

  const openCount = examSchedules.filter((s) => s.marks_entry_open || s.markEntryStatus === 'Open').length;
  const closedCount = examSchedules.length - openCount;

  const handleBulkOpen = async () => {
    if (!activeExamId || activeExamId === 'All') return;
    if (
      window.confirm(
        `Are you sure you want to open Mark Entry for ALL ${examSchedules.length} papers in ${activeExamId}? Assigned faculty instructors will immediately gain write permissions.`
      )
    ) {
      setIsBulkProcessing(true);
      try {
        await onBulkOpenWindows(activeExamId);
      } finally {
        setIsBulkProcessing(false);
      }
    }
  };

  const handleBulkClose = async () => {
    if (!activeExamId || activeExamId === 'All') return;
    if (
      window.confirm(
        `Are you sure you want to CLOSE Mark Entry for ALL papers in ${activeExamId}? This will lock the assessment interface for faculty.`
      )
    ) {
      setIsBulkProcessing(true);
      try {
        await onBulkCloseWindows(activeExamId);
      } finally {
        setIsBulkProcessing(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Course Code',
      'Course Title',
      'Programme',
      'Section',
      'Assigned Evaluator',
      'Window Status',
      'Submission Status',
      'Max Marks',
      'Passing Marks',
    ];
    const rows = filteredSchedules.map((s) => [
      s.course_code || s.courseCode,
      `"${(s.course_title || s.courseName || s.subjectName || '').replace(/"/g, '""')}"`,
      s.programme_code || s.className,
      s.section || 'A',
      `"${(s.assigned_evaluator_name || s.assignedFacultyName || 'Unassigned').replace(/"/g, '""')}"`,
      s.marks_entry_open || s.markEntryStatus === 'Open' ? 'OPEN' : 'CLOSED',
      s.markSubmissionStatus || s.status || 'PENDING',
      s.max_marks || s.maxMarks || 100,
      s.passing_marks || s.passMarks || 40,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `mark_entry_control_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Marks Entry Window Control Console
          </h1>
          <p className="text-xs text-slate-500">
            Open assessment evaluation portals for faculty instructors, close expired submission windows, and reopen with mandatory audit justifications
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </Button>
          <Button
            size="sm"
            onClick={handleBulkOpen}
            disabled={isBulkProcessing || activeExamId === 'All'}
            className="text-xs gap-1.5 bg-emerald-700 hover:bg-emerald-800 text-white cursor-pointer"
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>Bulk Open All Windows</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleBulkClose}
            disabled={isBulkProcessing || activeExamId === 'All'}
            className="text-xs gap-1.5 border-slate-300 text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Bulk Lock All Windows</span>
          </Button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Total Scheduled Papers</div>
            <div className="text-2xl font-black text-slate-900 font-mono mt-0.5">{examSchedules.length}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Under evaluation oversight</div>
          </div>
          <div className="p-2.5 bg-blue-50 text-[#1e3a8a] rounded-xl">
            <BookOpen className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Active Entry Windows (Open)</div>
            <div className="text-2xl font-black text-amber-700 font-mono mt-0.5">{openCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Faculty write permissions granted</div>
          </div>
          <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl">
            <Unlock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Locked Windows (Closed)</div>
            <div className="text-2xl font-black text-slate-700 font-mono mt-0.5">{closedCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Submitted or awaiting release</div>
          </div>
          <div className="p-2.5 bg-slate-100 text-slate-700 rounded-xl">
            <Lock className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            <option value="All">All Examination Sessions</option>
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Window Access State
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Windows</option>
            <option value="Open">Open (Writable)</option>
            <option value="Closed">Closed (Locked)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search Paper or Evaluator
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search course code, title, instructor..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Control Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Course Subject</th>
                <th className="px-5 py-3.5">Programme &amp; Section</th>
                <th className="px-5 py-3.5">Assigned Faculty Evaluator</th>
                <th className="px-5 py-3.5">Assessment Window</th>
                <th className="px-5 py-3.5">Faculty Submission</th>
                <th className="px-5 py-3.5 text-right">Window Control Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredSchedules.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-slate-400">
                    No course papers found matching your criteria.
                  </td>
                </tr>
              ) : (
                filteredSchedules.map((s) => {
                  const schId = s.id || s.schedule_id;
                  const courseCode = s.course_code || s.courseCode || s.subjectCode;
                  const courseTitle = s.course_title || s.courseName || s.subjectName;
                  const prog = s.programme_code || s.className;
                  const facultyName = s.assigned_evaluator_name || s.assignedFacultyName || 'Assigned Instructor';
                  const isWindowOpen = s.marks_entry_open || s.markEntryStatus === 'Open';
                  const subStatus = s.markSubmissionStatus || s.status || 'PENDING';

                  return (
                    <tr key={schId} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900 text-sm">{courseTitle}</div>
                        <div className="font-mono text-slate-500 text-[11px] mt-0.5">{courseCode}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-medium text-slate-800">{prog}</div>
                        <div className="text-[11px] text-slate-500">Sec {s.section || 'A'}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-slate-800">{facultyName}</div>
                        <div className="text-[10px] text-slate-400">Department of Engineering</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            isWindowOpen
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {isWindowOpen ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                          <span>{isWindowOpen ? 'PORTAL OPEN' : 'LOCKED (CLOSED)'}</span>
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            subStatus === 'Verified' || subStatus === 'APPROVED' || subStatus === 'PUBLISHED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : subStatus === 'Submitted' || subStatus === 'FACULTY_SUBMITTED'
                              ? 'bg-blue-100 text-blue-800'
                              : subStatus === 'Returned' || subStatus === 'REOPENED'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {subStatus}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1.5">
                        {isWindowOpen ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onCloseWindow(schId)}
                            className="text-[11px] py-1 px-2.5 text-slate-700 hover:bg-slate-100 cursor-pointer"
                          >
                            <Lock className="w-3 h-3 text-slate-500" />
                            <span>Lock Window</span>
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => onOpenWindow(schId)}
                            className="text-[11px] py-1 px-2.5 bg-emerald-700 hover:bg-emerald-800 text-white cursor-pointer"
                          >
                            <Unlock className="w-3 h-3" />
                            <span>Open Window</span>
                          </Button>
                        )}

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenReopenModal(s)}
                          className="text-[11px] py-1 px-2.5 text-amber-800 border-amber-300 hover:bg-amber-50 cursor-pointer"
                        >
                          <RotateCcw className="w-3 h-3 text-amber-600" />
                          <span>Reopen (Audit)</span>
                        </Button>

                        {onOpenRecordMarks && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onOpenRecordMarks(s)}
                            className="text-[11px] py-1 px-2.5 text-[#1e3a8a] border-blue-200 hover:bg-blue-50 cursor-pointer"
                          >
                            <Edit3 className="w-3 h-3" />
                            <span>Operator Entry</span>
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
