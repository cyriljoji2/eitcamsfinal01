import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Edit2,
  Calendar,
  Layers,
  CheckCircle2,
  Lock,
  Unlock,
  Archive,
  Download,
  AlertCircle,
  Eye,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface ExamManagementViewProps {
  examinations: any[];
  onOpenCreateModal: () => void;
  onOpenEditModal: (exam: any) => void;
  onUpdateStatus: (examId: string, status: any) => Promise<void>;
  onViewSchedule: (examId: string) => void;
}

export function ExamManagementView({
  examinations,
  onOpenCreateModal,
  onOpenEditModal,
  onUpdateStatus,
  onViewSchedule,
}: ExamManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sessionFilter, setSessionFilter] = useState<string>('All');

  // Filter distinct academic sessions
  const sessions = Array.from(new Set(examinations.map((e) => e.academicSession || e.academic_year || '2026-2027')));

  const filteredExams = examinations.filter((exam) => {
    const name = exam.name || exam.session_name || '';
    const id = exam.id || exam.session_id || '';
    const matchesSearch =
      name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      id.toLowerCase().includes(searchTerm.toLowerCase());
    const currStatus = exam.status;
    const matchesStatus = statusFilter === 'All' || currStatus === statusFilter;
    const sessYear = exam.academicSession || exam.academic_year || '2026-2027';
    const matchesSession = sessionFilter === 'All' || sessYear === sessionFilter;
    return matchesSearch && matchesStatus && matchesSession;
  });

  const handleExportCSV = () => {
    const headers = [
      'Session ID',
      'Examination Title',
      'Academic Session',
      'Term / Semester',
      'Start Date',
      'End Date',
      'Status',
    ];
    const rows = filteredExams.map((e) => [
      e.id || e.session_id,
      `"${(e.name || e.session_name || '').replace(/"/g, '""')}"`,
      e.academicSession || e.academic_year || '2026-2027',
      e.termType || `Semester ${e.semester || 3}`,
      e.startDate || e.start_date || '',
      e.endDate || e.end_date || '',
      e.status,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `examinations_registry_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">University Examinations Registry</h1>
          <p className="text-xs text-slate-500">
            Define institutional examination sessions, configure registration windows, and administer lifecycle stages
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </Button>
          <Button size="sm" onClick={onOpenCreateModal} className="text-xs gap-1.5 cursor-pointer">
            <Plus className="w-3.5 h-3.5" />
            <span>New Examination Session</span>
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search session by title or ID..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Lifecycle Statuses</option>
            <option value="SCHEDULED">SCHEDULED</option>
            <option value="IN_PROGRESS">IN_PROGRESS (Active)</option>
            <option value="MARKS_ENTRY_OPEN">MARKS_ENTRY_OPEN</option>
            <option value="EVALUATION">EVALUATION</option>
            <option value="COMPLETED">COMPLETED (Published)</option>
            <option value="CANCELLED">CANCELLED</option>
          </select>
        </div>

        <div>
          <select
            value={sessionFilter}
            onChange={(e) => setSessionFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Academic Years</option>
            {sessions.map((sess) => (
              <option key={sess} value={sess}>
                Academic Year {sess}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Examinations Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Session ID &amp; Title</th>
                <th className="px-5 py-3.5">Academic Session</th>
                <th className="px-5 py-3.5">Term / Semester</th>
                <th className="px-5 py-3.5">Date Range</th>
                <th className="px-5 py-3.5">Lifecycle Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredExams.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-slate-400">
                    No examination sessions found matching your criteria.
                  </td>
                </tr>
              ) : (
                filteredExams.map((exam) => {
                  const examId = exam.id || exam.session_id;
                  const examName = exam.name || exam.session_name;
                  const isPublished = exam.status === 'Published' || exam.status === 'COMPLETED';

                  return (
                    <tr key={examId} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900 text-sm">{examName}</div>
                        <div className="font-mono text-slate-500 text-[11px] mt-0.5">{examId}</div>
                      </td>
                      <td className="px-5 py-3.5 font-mono">
                        {exam.academicSession || exam.academic_year || '2026-2027'}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                          {exam.termType || `Semester ${exam.semester || 3}`}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 font-mono">
                        <div>{exam.startDate || exam.start_date || 'TBD'}</div>
                        <div className="text-[11px] text-slate-500">to {exam.endDate || exam.end_date || 'TBD'}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            isPublished
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : exam.status === 'Active' || exam.status === 'IN_PROGRESS' || exam.status === 'MARKS_ENTRY_OPEN'
                              ? 'bg-blue-100 text-blue-800 border border-blue-200'
                              : exam.status === 'CANCELLED'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {exam.status}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onViewSchedule(examId)}
                          className="text-[11px] py-1 px-2.5"
                        >
                          <Eye className="w-3 h-3 text-[#1e3a8a]" />
                          <span>Timetable</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenEditModal(exam)}
                          className="text-[11px] py-1 px-2.5"
                        >
                          <Edit2 className="w-3 h-3 text-slate-500" />
                          <span>Configure</span>
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
