import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  LayoutDashboard,
  Layers,
  Calendar,
  Users,
  Printer,
  Lock,
  FileCheck2,
  Award,
  BarChart3,
  CheckCircle2,
  AlertCircle,
  X,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { CoeTab } from '../../types/coe';
import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { CoeHeader } from './CoeHeader';

// 9 Views
import { CoeOverview } from './CoeOverview';
import { ExamManagementView } from './ExamManagementView';
import { ExamScheduleView } from './ExamScheduleView';
import { StudentEligibilityView } from './StudentEligibilityView';
import { HallTicketView } from './HallTicketView';
import { MarkEntryControlView } from './MarkEntryControlView';
import { MarksVerificationView } from './MarksVerificationView';
import { ResultsView } from './ResultsView';
import { ExamReportsView } from './ExamReportsView';

// Modals
import { ExamFormModal } from './modals/ExamFormModal';
import { ExamScheduleModal } from './modals/ExamScheduleModal';
import { EligibilityModal } from './modals/EligibilityModal';
import { HallTicketPrintModal } from './modals/HallTicketPrintModal';
import { ReopenMarkEntryModal } from './modals/ReopenMarkEntryModal';
import { ReturnMarksModal } from './modals/ReturnMarksModal';
import { ResultTranscriptModal } from './modals/ResultTranscriptModal';
import { MarkModerationModal } from './modals/MarkModerationModal';

// Services
import { examinationRepository } from '../../services/examinationService';
import { devDataAdapter } from '../../services/devDataAdapter';
import { employeeRepository } from '../../services/employeeService';
import { CourseRecord, DepartmentRecord, EmployeeRecord } from '../../types/database';

interface CoeWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
  onRefreshData?: () => void;
}

export function CoeWorkspace({ user, onLogout, onRefreshData }: CoeWorkspaceProps) {
  // Navigation
  const [activeTab, setActiveTab] = useState<CoeTab>('overview');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Active selection
  const [selectedExamId, setSelectedExamId] = useState<string>('');

  // Primary Data Collections
  const [examinations, setExaminations] = useState<any[]>([]);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [eligibilities, setEligibilities] = useState<any[]>([]);
  const [hallTickets, setHallTickets] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [dashboardMetrics, setDashboardMetrics] = useState<any>(null);

  // Academic Master Data
  const [courses, setCourses] = useState<CourseRecord[]>([]);
  const [facultyMembers, setFacultyMembers] = useState<EmployeeRecord[]>([]);

  // Feedback notifications
  const [toastMessage, setToastMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const showToast = (type: 'success' | 'error', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  };

  // Modals state
  const [isExamModalOpen, setIsExamModalOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<any | null>(null);

  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<any | null>(null);

  const [isEligibilityModalOpen, setIsEligibilityModalOpen] = useState(false);
  const [editingEligibility, setEditingEligibility] = useState<any | null>(null);

  const [isPrintTicketModalOpen, setIsPrintTicketModalOpen] = useState(false);
  const [selectedTicketForPrint, setSelectedTicketForPrint] = useState<any | null>(null);

  const [isReopenWindowModalOpen, setIsReopenWindowModalOpen] = useState(false);
  const [scheduleForReopen, setScheduleForReopen] = useState<any | null>(null);

  const [isReturnMarksModalOpen, setIsReturnMarksModalOpen] = useState(false);
  const [scheduleForReturn, setScheduleForReturn] = useState<any | null>(null);

  const [isModerateModalOpen, setIsModerateModalOpen] = useState(false);
  const [resultForModerate, setResultForModerate] = useState<any | null>(null);

  const [isTranscriptModalOpen, setIsTranscriptModalOpen] = useState(false);
  const [resultForTranscript, setResultForTranscript] = useState<any | null>(null);

  // Load all examination data
  const loadAllData = useCallback(async () => {
    setIsRefreshing(true);
    try {
      const [
        examsData,
        schedulesData,
        eligibilitiesData,
        ticketsData,
        resultsData,
        logsData,
        coursesData,
        allEmps,
        dashboardMetricsData,
      ] = await Promise.all([
        examinationRepository.getExaminations(),
        examinationRepository.getSchedules(),
        examinationRepository.getEligibilities(),
        examinationRepository.getHallTickets(),
        examinationRepository.getResults(),
        examinationRepository.getAuditLogs(),
        devDataAdapter.academic.getCourses(),
        employeeRepository.getAll(),
        (devDataAdapter.coe as any).getCoeDashboardMetrics
          ? (devDataAdapter.coe as any).getCoeDashboardMetrics()
          : (devDataAdapter.coe as any).getMetrics(),
      ]);

      setExaminations(examsData || []);
      setSchedules(schedulesData || []);
      setEligibilities(eligibilitiesData || []);
      setHallTickets(ticketsData || []);
      setResults(resultsData || []);
      setAuditLogs(logsData || []);
      setCourses(coursesData || []);
      setFacultyMembers((allEmps as any[]) || []);
      setDashboardMetrics(dashboardMetricsData || null);

      if (examsData && examsData.length > 0 && !selectedExamId) {
        setSelectedExamId(examsData[0].id || (examsData[0] as any).session_id);
      }
    } catch (err: any) {
      console.error('Failed to load COE workspace data:', err);
      showToast('error', `Failed to load examination records: ${err?.message || 'Network error'}`);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [selectedExamId]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Sidebar Menu Items for COE Workspace
  const sidebarItems: PortalSidebarItem[] = useMemo(() => {
    const activeExamsCount = examinations.filter(
      (e) => (e.status || e.session_status) === 'ACTIVE' || (e.status || e.session_status) === 'ONGOING'
    ).length;

    const pendingMarksCount = schedules.filter(
      (s) => s.marksEntryStatus === 'OPEN' || s.marksEntryStatus === 'REOPENED'
    ).length;

    const publishedResultsCount = examinations.filter(
      (e) => (e.status || e.session_status) === 'RESULTS_PUBLISHED'
    ).length;

    return [
      {
        id: 'overview',
        label: 'COE Overview',
        icon: LayoutDashboard,
      },
      {
        id: 'exam-management',
        label: 'Exam Sessions',
        icon: Layers,
        badge: activeExamsCount > 0 ? `${activeExamsCount} Active` : undefined,
        badgeVariant: 'blue',
      },
      {
        id: 'exam-schedule',
        label: 'Timetable & Schedule',
        icon: Calendar,
      },
      {
        id: 'eligibility',
        label: 'Student Eligibility',
        icon: Users,
      },
      {
        id: 'hall-tickets',
        label: 'Hall Tickets',
        icon: Printer,
      },
      {
        id: 'mark-entry',
        label: 'Marks Entry Control',
        icon: Lock,
        badge: pendingMarksCount > 0 ? `${pendingMarksCount} Open` : undefined,
        badgeVariant: 'amber',
      },
      {
        id: 'marks-verification',
        label: 'Audit & Moderation',
        icon: FileCheck2,
      },
      {
        id: 'results',
        label: 'Results & Transcripts',
        icon: Award,
        badge: publishedResultsCount > 0 ? `${publishedResultsCount} Published` : undefined,
        badgeVariant: 'emerald',
      },
      {
        id: 'reports',
        label: 'Reports & Analytics',
        icon: BarChart3,
      },
    ];
  }, [examinations, schedules]);

  // Handle Tab Switch
  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId as CoeTab);
    setMobileMenuOpen(false);
  };

  // ==========================================
  // ACTION HANDLERS
  // ==========================================

  // 1. Examination Sessions CRUD
  const handleSaveExam = async (examData: any) => {
    try {
      if (editingExam) {
        await examinationRepository.updateExamination(
          examData.id,
          {
            name: examData.name,
            termType: examData.termType,
            startDate: examData.startDate,
            endDate: examData.endDate,
            registrationDeadline: examData.registrationDeadline,
            status: examData.status,
            instructions: examData.instructions,
          },
          user.username
        );
        showToast('success', `Exam session "${examData.name}" updated successfully.`);
      } else {
        await examinationRepository.createExamination(examData, user.username);
        showToast('success', `New examination session "${examData.name}" created.`);
      }
      setIsExamModalOpen(false);
      setEditingExam(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to save examination session');
      throw err;
    }
  };

  const handleUpdateExamStatus = async (examId: string, status: any) => {
    try {
      await examinationRepository.updateExamination(examId, { status }, user.username);
      showToast('success', `Examination status updated to ${status}.`);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to update status');
    }
  };

  // 2. Schedule CRUD
  const handleSaveSchedule = async (scheduleData: any) => {
    try {
      if (editingSchedule) {
        await examinationRepository.updateSchedule(
          scheduleData.id,
          scheduleData,
          user.username
        );
        showToast('success', `Course examination schedule updated successfully.`);
      } else {
        await examinationRepository.createSchedule(scheduleData, user.username);
        showToast('success', `Examination timetable paper scheduled.`);
      }
      setIsScheduleModalOpen(false);
      setEditingSchedule(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to schedule examination');
      throw err;
    }
  };

  const handleDeleteSchedule = async (scheduleId: string) => {
    if (!confirm('Are you sure you want to remove this examination schedule?')) return;
    try {
      await examinationRepository.deleteSchedule(scheduleId, user.username);
      showToast('success', 'Examination schedule deleted.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to delete schedule');
    }
  };

  // 3. Eligibility Handlers
  const handleSaveEligibility = async (
    examId: string,
    regNo: string,
    isEligible: boolean,
    reason?: string
  ) => {
    try {
      await examinationRepository.updateStudentEligibility(
        examId,
        regNo,
        isEligible,
        reason,
        user.username
      );
      showToast(
        'success',
        `Eligibility updated for ${regNo}: ${isEligible ? 'ELIGIBLE' : 'DEBARRED'}.`
      );
      setIsEligibilityModalOpen(false);
      setEditingEligibility(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to update student eligibility');
      throw err;
    }
  };

  const handleSyncEligibility = async (examId: string) => {
    try {
      const synced = await examinationRepository.syncEligibilityFromAdmission(
        examId,
        user.username
      );
      showToast(
        'success',
        `Eligibility synchronized: ${synced.length} university candidate records verified.`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to sync student eligibility');
    }
  };

  const handleBulkSetEligible = async (examId: string, className?: string) => {
    try {
      const updated = await examinationRepository.bulkSetEligibility(
        examId,
        true,
        className,
        user.username
      );
      showToast(
        'success',
        `Approved ${updated.length} candidates as eligible for examination.`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to bulk approve candidates');
    }
  };

  // 4. Hall Ticket Generation Handlers
  const handleGenerateIndividualTicket = async (examId: string, regNo: string) => {
    try {
      const ticket = await examinationRepository.generateHallTicket(
        examId,
        regNo,
        user.username
      );
      showToast('success', `Hall ticket generated for ${regNo}.`);
      await loadAllData();
      if (onRefreshData) onRefreshData();
      return ticket;
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to generate hall ticket');
      throw err;
    }
  };

  const handleGenerateClassBatchTickets = async (examId: string, className: string) => {
    try {
      const tickets = await examinationRepository.generateClassHallTickets(
        examId,
        className,
        user.username
      );
      showToast(
        'success',
        `Generated ${tickets.length} hall tickets for section ${className}.`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
      return tickets;
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to batch generate hall tickets');
      throw err;
    }
  };

  const handleGenerateExamBulkTickets = async (examId: string) => {
    try {
      const tickets = await examinationRepository.generateAllHallTicketsForExam(
        examId,
        user.username
      );
      showToast(
        'success',
        `Generated ${tickets.length} hall tickets for entire examination session.`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
      return tickets;
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to generate bulk hall tickets');
      throw err;
    }
  };

  // 5. Marks Entry Window Control Handlers
  const handleOpenWindow = async (scheduleId: string) => {
    try {
      await examinationRepository.openMarkEntry(scheduleId, user.username);
      showToast('success', 'Faculty marks entry window opened.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to open marks entry window');
    }
  };

  const handleCloseWindow = async (scheduleId: string) => {
    try {
      await examinationRepository.closeMarkEntry(scheduleId, user.username);
      showToast('success', 'Marks entry window locked successfully.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to lock marks entry window');
    }
  };

  const handleConfirmReopenWindow = async (scheduleId: string, reason: string) => {
    try {
      await examinationRepository.reopenMarkEntry(scheduleId, reason, user.username);
      showToast('success', 'Marks entry window reopened with formal audit record.');
      setIsReopenWindowModalOpen(false);
      setScheduleForReopen(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to reopen window');
      throw err;
    }
  };

  const handleBulkOpenWindows = async (examId: string) => {
    try {
      await examinationRepository.bulkOpenMarkEntry(examId, user.username);
      showToast('success', 'All examination course windows opened for faculty entry.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to open windows');
    }
  };

  const handleBulkCloseWindows = async (examId: string) => {
    try {
      await examinationRepository.bulkCloseMarkEntry(examId, user.username);
      showToast('success', 'All course marks windows locked for verification.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to close windows');
    }
  };

  // 6. Marks Verification & Moderation Handlers
  const handleVerifyMarks = async (scheduleId: string, notes?: string) => {
    try {
      await examinationRepository.verifyMarks(scheduleId, notes, user.username);
      showToast('success', 'Marks verified and sealed by COE auditor.');
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to verify marks');
    }
  };

  const handleConfirmReturnMarks = async (scheduleId: string, reason: string) => {
    try {
      await examinationRepository.returnMarksForCorrection(
        scheduleId,
        reason,
        user.username
      );
      showToast('success', 'Course marks returned to faculty for mandatory correction.');
      setIsReturnMarksModalOpen(false);
      setScheduleForReturn(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to return marks');
      throw err;
    }
  };

  const handleConfirmModerateMarks = async (
    resultId: string,
    internal: number,
    external: number,
    reason: string
  ) => {
    try {
      if ((devDataAdapter.coe as any).moderateMarks) {
        await (devDataAdapter.coe as any).moderateMarks(
          resultId,
          {
            revised_internal: internal,
            revised_external: external,
            reason,
          },
          {
            userId: user.username,
            role: user.role,
          }
        );
      }
      showToast('success', 'Marks moderated and audit trail recorded.');
      setIsModerateModalOpen(false);
      setResultForModerate(null);
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to moderate marks');
      throw err;
    }
  };

  // 7. Results Handlers
  const handleCalculateResults = async (examId: string) => {
    try {
      const calculated = await examinationRepository.calculateResultsForExam(
        examId,
        user.username
      );
      showToast(
        'success',
        `Computed grades and SGPA/CGPA for ${calculated.length} candidates.`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to calculate results');
    }
  };

  const handlePublishResults = async (examId: string) => {
    try {
      const published = await examinationRepository.publishResults(
        examId,
        user.username
      );
      showToast(
        'success',
        `Official results published to Student Portal (${published.length} transcripts).`
      );
      await loadAllData();
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      showToast('error', err?.message || 'Failed to publish results');
    }
  };

  // Render active functional view
  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <CoeOverview
            examinations={examinations}
            schedules={schedules}
            results={results}
            hallTickets={hallTickets}
            auditLogs={auditLogs}
            eligibilities={eligibilities}
            metrics={dashboardMetrics}
            onNavigateTab={(tab) => handleSelectTab(tab)}
            onOpenCreateExamModal={() => {
              setEditingExam(null);
              setIsExamModalOpen(true);
            }}
            onOpenScheduleModal={() => {
              setEditingSchedule(null);
              setIsScheduleModalOpen(true);
            }}
          />
        );

      case 'exam-management':
      case 'exams':
        return (
          <ExamManagementView
            examinations={examinations}
            onOpenCreateModal={() => {
              setEditingExam(null);
              setIsExamModalOpen(true);
            }}
            onOpenEditModal={(exam) => {
              setEditingExam(exam);
              setIsExamModalOpen(true);
            }}
            onUpdateStatus={handleUpdateExamStatus}
            onViewSchedule={(examId) => {
              setSelectedExamId(examId);
              setActiveTab('exam-schedule');
            }}
          />
        );

      case 'exam-schedule':
      case 'schedule':
        return (
          <ExamScheduleView
            examinations={examinations}
            schedules={schedules}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onOpenAddScheduleModal={() => {
              setEditingSchedule(null);
              setIsScheduleModalOpen(true);
            }}
            onOpenEditScheduleModal={(schedule) => {
              setEditingSchedule(schedule);
              setIsScheduleModalOpen(true);
            }}
            onDeleteSchedule={handleDeleteSchedule}
            onToggleMarksWindow={async (schedule) => {
              if (schedule.marksEntryStatus === 'OPEN') {
                await handleCloseWindow(schedule.id || schedule.schedule_id);
              } else {
                await handleOpenWindow(schedule.id || schedule.schedule_id);
              }
            }}
          />
        );

      case 'eligibility':
        return (
          <StudentEligibilityView
            examinations={examinations}
            eligibilities={eligibilities}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onOpenEligibilityModal={(elig) => {
              setEditingEligibility(elig);
              setIsEligibilityModalOpen(true);
            }}
            onSyncEligibility={handleSyncEligibility}
            onBulkSetEligible={handleBulkSetEligible}
          />
        );

      case 'hall-tickets':
        return (
          <HallTicketView
            examinations={examinations}
            hallTickets={hallTickets}
            schedules={schedules}
            eligibilities={eligibilities}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onGenerateIndividual={handleGenerateIndividualTicket}
            onGenerateClassBatch={handleGenerateClassBatchTickets}
            onGenerateExamBulk={handleGenerateExamBulkTickets}
            onOpenPrintModal={(ticket) => {
              setSelectedTicketForPrint(ticket);
              setIsPrintTicketModalOpen(true);
            }}
          />
        );

      case 'mark-entry':
        return (
          <MarkEntryControlView
            examinations={examinations}
            schedules={schedules}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onOpenWindow={handleOpenWindow}
            onCloseWindow={handleCloseWindow}
            onOpenReopenModal={(schedule) => {
              setScheduleForReopen(schedule);
              setIsReopenWindowModalOpen(true);
            }}
            onBulkOpenWindows={handleBulkOpenWindows}
            onBulkCloseWindows={handleBulkCloseWindows}
            onOpenRecordMarks={(schedule) => {
              setEditingSchedule(schedule);
              setActiveTab('marks-verification');
            }}
          />
        );

      case 'marks-verification':
      case 'verification':
        return (
          <MarksVerificationView
            examinations={examinations}
            schedules={schedules}
            allMarks={results}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onVerifyMarks={handleVerifyMarks}
            onOpenReturnModal={(schedule) => {
              setScheduleForReturn(schedule);
              setIsReturnMarksModalOpen(true);
            }}
            onOpenModerateModal={(res) => {
              setResultForModerate(res);
              setIsModerateModalOpen(true);
            }}
          />
        );

      case 'results':
        return (
          <ResultsView
            examinations={examinations}
            results={results}
            schedules={schedules}
            selectedExamId={selectedExamId}
            onSelectExamId={setSelectedExamId}
            onCalculateResults={handleCalculateResults}
            onPublishResults={handlePublishResults}
            onOpenTranscriptModal={(res) => {
              setResultForTranscript(res);
              setIsTranscriptModalOpen(true);
            }}
            isCoeUser={true}
          />
        );

      case 'reports':
        return (
          <ExamReportsView
            examinations={examinations}
            schedules={schedules}
            results={results}
            hallTickets={hallTickets}
            eligibilities={eligibilities}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      {/* 1. Autonomous Examination Cell Header */}
      <CoeHeader
        currentUserName={user.displayName || user.name || user.username}
        currentUserRole={user.roleTitle || 'Controller of Examinations'}
        onLogout={onLogout}
        onRefreshData={loadAllData}
        isRefreshing={isRefreshing}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 w-full">
          <div
            className={`p-3.5 rounded-xl border flex items-center justify-between text-xs font-medium shadow-xs transition-all ${
              toastMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {toastMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{toastMessage.text}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        <div className="flex flex-col lg:flex-row gap-6 items-start">
          {/* 2. Responsive University Navigation Sidebar */}
          <PortalSidebar
            items={sidebarItems}
            activeTab={activeTab}
            onSelectTab={handleSelectTab}
            isOpenMobile={mobileMenuOpen}
            idPrefix="coe-nav"
            headerSlot={
              <div className="px-3 py-2 border-b border-slate-100 mb-2">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  COE Office Core
                </span>
                <div className="text-xs font-bold text-slate-800">
                  Examination Cell
                </div>
              </div>
            }
          />

          {/* 3. Main Workspace Destination Screen */}
          <main className="flex-1 min-w-0 w-full">
            {isLoading ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-3 border-[#1e3a8a] border-t-transparent mb-3" />
                <p className="text-sm font-semibold text-slate-700">
                  Loading Examination Management records...
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Synchronizing authoritative session data and registers
                </p>
              </div>
            ) : (
              renderTabContent()
            )}
          </main>
        </div>
      </div>

      {/* =========================================================================
          COE MODALS
         ========================================================================= */}

      {/* 1. Exam Session Modal */}
      <ExamFormModal
        isOpen={isExamModalOpen}
        onClose={() => {
          setIsExamModalOpen(false);
          setEditingExam(null);
        }}
        onSubmit={handleSaveExam}
        initialData={editingExam}
        currentUserName={user.username}
      />

      {/* 2. Exam Schedule Modal */}
      <ExamScheduleModal
        isOpen={isScheduleModalOpen}
        onClose={() => {
          setIsScheduleModalOpen(false);
          setEditingSchedule(null);
        }}
        onSubmit={handleSaveSchedule}
        initialData={editingSchedule}
        examinations={examinations}
        courses={courses}
        facultyMembers={facultyMembers}
        defaultExamId={selectedExamId}
      />

      {/* 3. Student Eligibility Review & Debarment Modal */}
      <EligibilityModal
        isOpen={isEligibilityModalOpen}
        onClose={() => {
          setIsEligibilityModalOpen(false);
          setEditingEligibility(null);
        }}
        eligibility={editingEligibility}
        onSave={handleSaveEligibility}
      />

      {/* 4. Official Hall Ticket Print Modal */}
      <HallTicketPrintModal
        isOpen={isPrintTicketModalOpen}
        onClose={() => {
          setIsPrintTicketModalOpen(false);
          setSelectedTicketForPrint(null);
        }}
        hallTicket={selectedTicketForPrint}
      />

      {/* 5. Reopen Marks Entry Window Modal (Audit Justification) */}
      <ReopenMarkEntryModal
        isOpen={isReopenWindowModalOpen}
        onClose={() => {
          setIsReopenWindowModalOpen(false);
          setScheduleForReopen(null);
        }}
        schedule={scheduleForReopen}
        onConfirmReopen={handleConfirmReopenWindow}
        currentUserName={user.username}
      />

      {/* 6. Return Marks to Faculty Modal */}
      <ReturnMarksModal
        isOpen={isReturnMarksModalOpen}
        onClose={() => {
          setIsReturnMarksModalOpen(false);
          setScheduleForReturn(null);
        }}
        schedule={scheduleForReturn}
        onConfirmReturn={handleConfirmReturnMarks}
        currentUserName={user.username}
      />

      {/* 7. Score Moderation Modal */}
      <MarkModerationModal
        isOpen={isModerateModalOpen}
        onClose={() => {
          setIsModerateModalOpen(false);
          setResultForModerate(null);
        }}
        result={resultForModerate}
        onConfirmModerate={handleConfirmModerateMarks}
      />

      {/* 8. Semester Grade Card / Transcript Modal */}
      <ResultTranscriptModal
        isOpen={isTranscriptModalOpen}
        onClose={() => {
          setIsTranscriptModalOpen(false);
          setResultForTranscript(null);
        }}
        result={resultForTranscript}
      />
    </div>
  );
}
