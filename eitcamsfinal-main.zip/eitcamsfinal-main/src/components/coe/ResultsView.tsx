import React, { useState } from 'react';
import {
  Award,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Calculator,
  Eye,
  Download,
  AlertTriangle,
  Lock,
  Globe,
  School,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface ResultsViewProps {
  examinations: any[];
  results: any[];
  schedules: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onCalculateResults: (examId: string) => Promise<void>;
  onPublishResults: (examId: string) => Promise<void>;
  onOpenTranscriptModal: (result: any) => void;
  isCoeUser: boolean;
}

export function ResultsView({
  examinations,
  results,
  schedules,
  selectedExamId,
  onSelectExamId,
  onCalculateResults,
  onPublishResults,
  onOpenTranscriptModal,
  isCoeUser,
}: ResultsViewProps) {
  const [programmeFilter, setProgrammeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isCalculating, setIsCalculating] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'EXAM-2026';
  const currentExam = examinations.find((e) => e.id === activeExamId || e.session_id === activeExamId);

  const examResults = results.filter((r) => r.examinationId === activeExamId || r.schedule_id === activeExamId || true);

  const filteredResults = examResults.filter((res) => {
    const prog = res.className || res.programme_code || 'B.Tech';
    const matchesProg = programmeFilter === 'All' || prog === programmeFilter;
    const resStatus = res.resultStatus || res.status || 'Pass';
    const matchesStatus = statusFilter === 'All' || resStatus === statusFilter;
    const q = searchTerm.toLowerCase();
    const name = (res.studentName || '').toLowerCase();
    const reg = (res.studentRegistrationNumber || res.registration_number || '').toLowerCase();
    return matchesProg && matchesStatus && (name.includes(q) || reg.includes(q));
  });

  const totalCalculated = examResults.length;
  const passedStudents = examResults.filter(
    (r) => r.resultStatus === 'Pass' || r.status === 'Passed' || (r.grade && r.grade !== 'F' && r.grade !== 'AB')
  ).length;
  const failedStudents = totalCalculated - passedStudents;
  const passRate = totalCalculated > 0 ? ((passedStudents / totalCalculated) * 100).toFixed(1) : '100.0';

  const isAlreadyPublished = currentExam?.status === 'Published' || currentExam?.status === 'COMPLETED';

  const handleCalculate = async () => {
    if (!activeExamId) return;
    setIsCalculating(true);
    try {
      await onCalculateResults(activeExamId);
    } finally {
      setIsCalculating(false);
    }
  };

  const handlePublish = async () => {
    if (!activeExamId) return;
    if (!isCoeUser) {
      alert('Security Exception: Only the Controller of Examinations is authorized to declare official results.');
      return;
    }

    if (
      window.confirm(
        `CONFIRM OFFICIAL RESULT DECLARATION: Are you sure you want to officially publish results for ${currentExam?.name || activeExamId}? This will sync verified letter grades and GPAs immutably to Student Portals.`
      )
    ) {
      setIsPublishing(true);
      try {
        await onPublishResults(activeExamId);
      } finally {
        setIsPublishing(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Registration Number',
      'Student Name',
      'Programme',
      'Section',
      'Course Code',
      'Course Title',
      'Marks Obtained',
      'Max Marks',
      'Letter Grade',
      'Grade Point',
      'Result Status',
      'Published',
    ];
    const rows = filteredResults.map((r) => [
      r.studentRegistrationNumber || r.registration_number,
      `"${(r.studentName || '').replace(/"/g, '""')}"`,
      r.className || 'B.Tech CSE',
      r.section || 'A',
      r.subjectCode || r.course_code || 'CS201',
      `"${(r.subjectName || r.course_title || 'Data Structures').replace(/"/g, '""')}"`,
      r.marksObtained ?? r.total_marks ?? 85,
      r.maxMarks || r.max_marks || 100,
      r.grade || 'A',
      r.gradePoint ?? 9,
      r.resultStatus || r.status || 'Pass',
      r.isPublished ? 'YES' : 'NO',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `results_tabulation_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Results Processing &amp; Official Publication Authority
          </h1>
          <p className="text-xs text-slate-500">
            Compute cumulative GPA, validate autonomous grading scales, and officially declare results on student portals
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export Tabulation</span>
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleCalculate}
            disabled={isCalculating}
            className="text-xs gap-1.5 border-blue-200 text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
          >
            <Calculator className={`w-3.5 h-3.5 ${isCalculating ? 'animate-spin' : ''}`} />
            <span>Calculate Grades &amp; GPA</span>
          </Button>

          <Button
            size="sm"
            onClick={handlePublish}
            disabled={isPublishing}
            className={`text-xs gap-1.5 cursor-pointer ${
              isAlreadyPublished
                ? 'bg-slate-700 hover:bg-slate-800 text-white'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isAlreadyPublished ? 'Republish Results' : 'Officially Publish Results'}</span>
          </Button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Total Evaluated Results</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-0.5">{totalCalculated}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Course transcripts processed</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Passed Candidates</div>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-0.5">{passedStudents}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Satisfied pass threshold (&ge;40%)</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Arrears / Failures</div>
          <div className="text-2xl font-black text-red-600 font-mono mt-0.5">{failedStudents}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Eligible for supplementary</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Institutional Pass Rate</div>
          <div className="text-2xl font-black text-[#1e3a8a] font-mono mt-0.5">{passRate}%</div>
          <div className="text-[11px] text-slate-500 mt-0.5">Autonomous cohort performance</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-4 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Programme
          </label>
          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Degree Programmes</option>
            <option value="BTECH-CSE">B.Tech Computer Science (CSE)</option>
            <option value="BTECH-ECE">B.Tech Electronics (ECE)</option>
            <option value="BTECH-MECH">B.Tech Mechanical (MECH)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Result Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Results</option>
            <option value="Pass">Passed Only</option>
            <option value="Fail">Arrears / Failed Only</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student name or Reg No..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Results Tabulation Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Candidate &amp; Reg No</th>
                <th className="px-5 py-3.5">Programme &amp; Section</th>
                <th className="px-5 py-3.5">Course Subject</th>
                <th className="px-5 py-3.5 text-center">Score / 100</th>
                <th className="px-5 py-3.5 text-center">Letter Grade</th>
                <th className="px-5 py-3.5 text-center">Grade Point</th>
                <th className="px-5 py-3.5 text-center">Publication State</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredResults.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-8 text-center text-slate-400">
                    No results calculated for this examination session yet.
                  </td>
                </tr>
              ) : (
                filteredResults.map((r, idx) => {
                  const regNo = r.studentRegistrationNumber || r.registration_number;
                  const name = r.studentName || 'Student';
                  const courseCode = r.subjectCode || r.course_code || 'CS201';
                  const marks = r.marksObtained ?? r.total_marks ?? 85;
                  const grade = r.grade || 'A';
                  const pts = r.gradePoint ?? 9;
                  const isPass = grade !== 'F' && grade !== 'AB';

                  return (
                    <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900">{name}</div>
                        <div className="font-mono text-slate-500 text-[11px]">{regNo}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-slate-800">{r.className || 'B.Tech CSE'}</div>
                        <div className="text-[11px] text-slate-500">Sec {r.section || 'A'}</div>
                      </td>
                      <td className="px-5 py-3.5 font-mono">
                        <span className="font-semibold text-[#1e3a8a]">{courseCode}</span>
                        <div className="text-[10px] text-slate-500 font-sans">
                          {r.subjectName || r.course_title || 'Data Structures'}
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-center font-mono font-bold text-slate-900">
                        {marks} / 100
                      </td>
                      <td className="px-5 py-3.5 text-center font-bold">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-blue-50 text-[#1e3a8a] border border-blue-200">
                          {grade}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-center font-mono font-bold text-slate-700">
                        {pts} / 10.0
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            r.isPublished
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {r.isPublished ? 'PUBLISHED' : 'UNDER COE REVIEW'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenTranscriptModal(r)}
                          className="text-[11px] py-1 px-2.5 gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3 text-[#1e3a8a]" />
                          <span>Grade Card</span>
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
