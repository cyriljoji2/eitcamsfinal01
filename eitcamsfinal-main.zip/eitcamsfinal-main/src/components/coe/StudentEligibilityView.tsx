import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  Download,
  ShieldAlert,
  ShieldCheck,
  Edit2,
  Award,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface StudentEligibilityViewProps {
  examinations: any[];
  eligibilities: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenEligibilityModal: (eligibility: any) => void;
  onSyncEligibility: (examId: string) => Promise<void>;
  onBulkSetEligible: (examId: string, className?: string) => Promise<void>;
}

export function StudentEligibilityView({
  examinations,
  eligibilities,
  selectedExamId,
  onSelectExamId,
  onOpenEligibilityModal,
  onSyncEligibility,
  onBulkSetEligible,
}: StudentEligibilityViewProps) {
  const [programmeFilter, setProgrammeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'EXAM-2026';

  const filteredList = eligibilities.filter((el) => {
    const prog = el.className || el.programme_code || 'B.Tech';
    const matchesProg = programmeFilter === 'All' || prog === programmeFilter;
    const isElig = Boolean(el.isEligible ?? el.is_eligible);
    const matchesStatus =
      statusFilter === 'All' ||
      (statusFilter === 'Eligible' && isElig) ||
      (statusFilter === 'Ineligible' && !isElig);
    const q = searchTerm.toLowerCase();
    const name = (el.studentName || el.name || '').toLowerCase();
    const reg = (el.studentRegistrationNumber || el.registration_number || '').toLowerCase();
    const matchesSearch = name.includes(q) || reg.includes(q);

    return matchesProg && matchesStatus && matchesSearch;
  });

  const totalCandidates = eligibilities.length;
  const eligibleCount = eligibilities.filter((e) => e.isEligible ?? e.is_eligible).length;
  const ineligibleCount = totalCandidates - eligibleCount;

  const handleSync = async () => {
    if (!activeExamId) return;
    setIsSyncing(true);
    try {
      await onSyncEligibility(activeExamId);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleBulkApprove = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to mark all candidates in ${
          programmeFilter === 'All' ? 'all degree programmes' : programmeFilter
        } as eligible for examination ${activeExamId}? Documented audit log will be created.`
      )
    ) {
      await onBulkSetEligible(activeExamId, programmeFilter === 'All' ? undefined : programmeFilter);
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Registration Number',
      'Student Name',
      'Programme',
      'Section',
      'Course Code',
      'Attendance Percentage',
      'Fee Clearance',
      'Eligibility Status',
      'Ineligibility Reason',
    ];
    const rows = filteredList.map((e) => [
      e.studentRegistrationNumber || e.registration_number,
      `"${(e.studentName || e.name || '').replace(/"/g, '""')}"`,
      e.className || e.programme_code || 'B.Tech',
      e.section || 'A',
      e.courseCode || e.course_code || 'CS201',
      `${e.attendancePercentage ?? e.attendance_percentage ?? 0}%`,
      e.feeClearance ?? e.fee_clearance ? 'CLEARED' : 'PENDING',
      (e.isEligible ?? e.is_eligible) ? 'ELIGIBLE' : 'INELIGIBLE',
      `"${(e.ineligibilityReason || e.ineligibility_reasons?.join('; ') || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `student_eligibility_roster_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Student Examination Eligibility Registry
          </h1>
          <p className="text-xs text-slate-500">
            Verify academic enrolment, institutional attendance compliance (&ge;75%), and financial clearance
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSync}
            disabled={isSyncing}
            className="text-xs gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>Sync Enrolments</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleBulkApprove}
            className="text-xs gap-1.5 border-emerald-300 text-emerald-800 hover:bg-emerald-50 cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Bulk Approve Cohort</span>
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export Roster</span>
          </Button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Total Enrolled Candidates</div>
            <div className="text-2xl font-black text-slate-900 font-mono mt-0.5">{totalCandidates}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Authoritative active records</div>
          </div>
          <div className="p-2.5 bg-blue-50 text-[#1e3a8a] rounded-xl">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Eligible Candidates</div>
            <div className="text-2xl font-black text-emerald-700 font-mono mt-0.5">{eligibleCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Hall ticket clearance approved</div>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Ineligible / Pending Action</div>
            <div className="text-2xl font-black text-red-600 font-mono mt-0.5">{ineligibleCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Attendance shortage or dues</div>
          </div>
          <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-4 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Degree Programme
          </label>
          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Programmes</option>
            <option value="BTECH-CSE">B.Tech Computer Science (CSE)</option>
            <option value="BTECH-ECE">B.Tech Electronics (ECE)</option>
            <option value="BTECH-MECH">B.Tech Mechanical (MECH)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Eligibility Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Statuses</option>
            <option value="Eligible">Eligible Only</option>
            <option value="Ineligible">Ineligible Only</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search Candidate
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search name or Reg No..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Student Eligibility Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Student &amp; Registration No</th>
                <th className="px-5 py-3.5">Programme &amp; Section</th>
                <th className="px-5 py-3.5">Course Subject</th>
                <th className="px-5 py-3.5">Attendance Compliance</th>
                <th className="px-5 py-3.5">Institutional Fees</th>
                <th className="px-5 py-3.5">Eligibility Decision</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-slate-400">
                    No student eligibility records found for current criteria.
                  </td>
                </tr>
              ) : (
                filteredList.map((st) => {
                  const regNo = st.studentRegistrationNumber || st.registration_number;
                  const name = st.studentName || st.name;
                  const isElig = Boolean(st.isEligible ?? st.is_eligible);
                  const att = st.attendancePercentage ?? st.attendance_percentage ?? 0;
                  const feeCleared = Boolean(st.feeClearance ?? st.fee_clearance);

                  return (
                    <tr key={regNo} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900">{name}</div>
                        <div className="font-mono text-slate-500 text-[11px]">{regNo}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-medium text-slate-800">{st.className || 'B.Tech CSE'}</div>
                        <div className="text-[11px] text-slate-500">Sec {st.section || 'A'}</div>
                      </td>
                      <td className="px-5 py-3.5 font-mono">
                        <span className="font-semibold text-[#1e3a8a]">{st.courseCode || 'CS201'}</span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`font-mono font-bold ${
                            att >= 75 ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {att}%
                        </span>
                        <div className="text-[10px] text-slate-400">
                          {att >= 75 ? 'Meets threshold' : 'Attendance shortage'}
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            feeCleared ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {feeCleared ? 'CLEARED' : 'PENDING'}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        {isElig ? (
                          <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>ELIGIBLE</span>
                          </span>
                        ) : (
                          <div>
                            <span className="inline-flex items-center gap-1 font-bold text-red-600">
                              <XCircle className="w-3.5 h-3.5" />
                              <span>INELIGIBLE</span>
                            </span>
                            <div className="text-[10px] text-red-500 mt-0.5 max-w-xs leading-tight">
                              {st.ineligibilityReason || st.ineligibility_reasons?.join('; ') || 'Criteria not met'}
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenEligibilityModal(st)}
                          className="text-[11px] py-1 px-2.5"
                        >
                          <Edit2 className="w-3 h-3 text-slate-500" />
                          <span>Review Decision</span>
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
