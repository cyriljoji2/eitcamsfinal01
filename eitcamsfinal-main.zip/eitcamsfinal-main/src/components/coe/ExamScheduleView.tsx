import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  Clock,
  MapPin,
  User,
  BookOpen,
  Download,
  AlertCircle,
  CheckCircle2,
  Lock,
  Unlock,
  AlertTriangle,
  LayoutGrid,
  List,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface ExamScheduleViewProps {
  examinations: any[];
  schedules: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onOpenAddScheduleModal: () => void;
  onOpenEditScheduleModal: (schedule: any) => void;
  onDeleteSchedule: (id: string) => Promise<void>;
  onToggleMarksWindow?: (schedule: any) => Promise<void>;
}

export function ExamScheduleView({
  examinations,
  schedules,
  selectedExamId,
  onSelectExamId,
  onOpenAddScheduleModal,
  onOpenEditScheduleModal,
  onDeleteSchedule,
  onToggleMarksWindow,
}: ExamScheduleViewProps) {
  const [programmeFilter, setProgrammeFilter] = useState<string>('All');
  const [deptFilter, setDeptFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'All';

  // Conflict detection
  const conflicts = useMemo(() => {
    const list: Array<{ type: 'ROOM' | 'COHORT'; message: string; scheduleIds: string[] }> = [];

    for (let i = 0; i < schedules.length; i++) {
      for (let j = i + 1; j < schedules.length; j++) {
        const a = schedules[i];
        const b = schedules[j];

        if (a.exam_date === b.exam_date || a.examDate === b.examDate) {
          const aDate = a.exam_date || a.examDate;
          const aStart = a.start_time || a.startTime;
          const aEnd = a.end_time || a.endTime;
          const bStart = b.start_time || b.startTime;
          const bEnd = b.end_time || b.endTime;

          const isTimeOverlap = aStart < bEnd && bStart < aEnd;

          if (isTimeOverlap) {
            // Room clash
            const aRoom = a.room || a.roomVenue;
            const bRoom = b.room || b.roomVenue;
            if (aRoom && bRoom && aRoom.toLowerCase() === bRoom.toLowerCase()) {
              list.push({
                type: 'ROOM',
                message: `Venue Clash: Room '${aRoom}' double-booked on ${aDate} between ${a.course_code || a.courseCode} and ${b.course_code || b.courseCode}.`,
                scheduleIds: [a.schedule_id || a.id, b.schedule_id || b.id],
              });
            }

            // Cohort clash
            const aProg = a.programme_code || a.className;
            const bProg = b.programme_code || b.className;
            const aSem = a.semester;
            const bSem = b.semester;
            if (aProg === bProg && aSem === bSem) {
              list.push({
                type: 'COHORT',
                message: `Student Cohort Clash: Same programme '${aProg}' Sem ${aSem} has multiple simultaneous exams (${a.course_code || a.courseCode} & ${b.course_code || b.courseCode}).`,
                scheduleIds: [a.schedule_id || a.id, b.schedule_id || b.id],
              });
            }
          }
        }
      }
    }
    return list;
  }, [schedules]);

  const filteredSchedules = schedules.filter((sch) => {
    const examMatch =
      !activeExamId || activeExamId === 'All' || sch.examinationId === activeExamId || sch.session_id === activeExamId;
    const progMatch =
      programmeFilter === 'All' || sch.programme_code === programmeFilter || sch.className === programmeFilter;
    const deptMatch =
      deptFilter === 'All' || sch.department === deptFilter;
    const q = searchTerm.toLowerCase();
    const title = (sch.course_title || sch.courseName || sch.subjectName || '').toLowerCase();
    const code = (sch.course_code || sch.courseCode || sch.subjectCode || '').toLowerCase();
    const room = (sch.room || sch.roomVenue || '').toLowerCase();
    const matchesSearch = title.includes(q) || code.includes(q) || room.includes(q);

    return examMatch && progMatch && deptMatch && matchesSearch;
  });

  const handleExportCSV = () => {
    const headers = [
      'Session ID',
      'Course Code',
      'Course Title',
      'Programme',
      'Semester',
      'Section',
      'Exam Date',
      'Time Slot',
      'Room Venue',
      'Max Marks',
      'Pass Marks',
      'Marks Window',
    ];
    const rows = filteredSchedules.map((s) => [
      s.session_id || s.examinationId,
      s.course_code || s.courseCode,
      `"${(s.course_title || s.courseName || s.subjectName || '').replace(/"/g, '""')}"`,
      s.programme_code || s.className,
      s.semester || 3,
      s.section || 'A',
      s.exam_date || s.examDate,
      `"${(s.start_time || s.startTime)} - ${(s.end_time || s.endTime)}"`,
      `"${(s.room || s.roomVenue || '').replace(/"/g, '""')}"`,
      s.max_marks || s.maxMarks || 100,
      s.passing_marks || s.passMarks || 40,
      s.marks_entry_open || s.markEntryStatus === 'Open' ? 'OPEN' : 'CLOSED',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `exam_schedule_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Curriculum Examination Timetable &amp; Paper Schedules
          </h1>
          <p className="text-xs text-slate-500">
            Schedule course examination slots, designate room venues, allocate evaluators, and resolve venue clashes
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'list' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List</span>
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer ${
                viewMode === 'calendar' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Timetable</span>
            </button>
          </div>

          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export Timetable</span>
          </Button>
          <Button size="sm" onClick={onOpenAddScheduleModal} className="text-xs gap-1.5 cursor-pointer">
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Course Paper</span>
          </Button>
        </div>
      </div>

      {/* Conflict Detection Banner */}
      {conflicts.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 space-y-1.5 text-xs">
          <div className="flex items-center gap-2 font-bold text-amber-950">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Scheduling Integrity Warning: {conflicts.length} conflict(s) detected</span>
          </div>
          <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-800 pl-1">
            {conflicts.map((c, idx) => (
              <li key={idx}>{c.message}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-4 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            <option value="All">All Examination Sessions</option>
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Programme
          </label>
          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Degree Programmes</option>
            <option value="BTECH-CSE">B.Tech Computer Science (CSE)</option>
            <option value="BTECH-ECE">B.Tech Electronics (ECE)</option>
            <option value="BTECH-MECH">B.Tech Mechanical (MECH)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Department
          </label>
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Departments</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="MECH">MECH</option>
            <option value="EEE">EEE</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search course or hall..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Schedules Table / Calendar View */}
      {viewMode === 'list' ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-5 py-3.5">Course &amp; Title</th>
                  <th className="px-5 py-3.5">Programme &amp; Cohort</th>
                  <th className="px-5 py-3.5">Date &amp; Time Slot</th>
                  <th className="px-5 py-3.5">Hall / Room</th>
                  <th className="px-5 py-3.5">Max / Pass Marks</th>
                  <th className="px-5 py-3.5">Evaluation Window</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredSchedules.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-8 text-center text-slate-400">
                      No examination schedules found matching your filters.
                    </td>
                  </tr>
                ) : (
                  filteredSchedules.map((s) => {
                    const schId = s.id || s.schedule_id;
                    const courseCode = s.course_code || s.courseCode || s.subjectCode;
                    const courseTitle = s.course_title || s.courseName || s.subjectName;
                    const date = s.exam_date || s.examDate;
                    const time = `${s.start_time || s.startTime} - ${s.end_time || s.endTime}`;
                    const room = s.room || s.roomVenue;
                    const prog = s.programme_code || s.className;
                    const isWindowOpen = s.marks_entry_open || s.markEntryStatus === 'Open';

                    return (
                      <tr key={schId} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-5 py-3.5">
                          <div className="font-bold text-slate-900 text-sm">{courseTitle}</div>
                          <div className="font-mono text-slate-500 text-[11px] mt-0.5">{courseCode}</div>
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="font-mono font-semibold text-slate-800">{prog}</div>
                          <div className="text-[11px] text-slate-500">
                            Sem {s.semester || 3} (Sec {s.section || 'A'})
                          </div>
                        </td>
                        <td className="px-5 py-3.5 font-mono">
                          <div className="font-semibold text-slate-900">{date}</div>
                          <div className="text-[11px] text-slate-500">{time}</div>
                        </td>
                        <td className="px-5 py-3.5 font-mono">
                          <span className="inline-flex items-center gap-1 text-slate-700">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            <span>{room}</span>
                          </span>
                        </td>
                        <td className="px-5 py-3.5 font-mono">
                          <span className="font-bold text-slate-900">{s.max_marks || s.maxMarks || 100}</span>
                          <span className="text-slate-400 text-[11px]"> / {s.passing_marks || s.passMarks || 40} pass</span>
                        </td>
                        <td className="px-5 py-3.5">
                          {onToggleMarksWindow ? (
                            <button
                              onClick={() => onToggleMarksWindow(s)}
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer inline-flex items-center gap-1 ${
                                isWindowOpen
                                  ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border border-slate-300'
                              }`}
                            >
                              {isWindowOpen ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                              <span>{isWindowOpen ? 'WINDOW OPEN' : 'WINDOW CLOSED'}</span>
                            </button>
                          ) : (
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                isWindowOpen ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {isWindowOpen ? 'OPEN' : 'CLOSED'}
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-right space-x-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onOpenEditScheduleModal(s)}
                            className="text-[11px] py-1 px-2.5"
                          >
                            <Edit2 className="w-3 h-3 text-slate-500" />
                            <span>Edit</span>
                          </Button>
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => onDeleteSchedule(schId)}
                            className="text-[11px] py-1 px-2.5 text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3 text-red-600" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Timetable Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSchedules.map((s) => {
            const schId = s.id || s.schedule_id;
            const courseCode = s.course_code || s.courseCode;
            const courseTitle = s.course_title || s.courseName || s.subjectName;
            const date = s.exam_date || s.examDate;
            const time = `${s.start_time || s.startTime} - ${s.end_time || s.endTime}`;
            const room = s.room || s.roomVenue;

            return (
              <div
                key={schId}
                className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between gap-4 hover:border-blue-300 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-md text-xs font-bold font-mono bg-blue-50 text-[#1e3a8a] border border-blue-200">
                      {courseCode}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {s.programme_code || s.className} (Sem {s.semester || 3})
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-900 mt-2 text-sm">{courseTitle}</h3>
                  <div className="text-xs text-slate-500 mt-2 space-y-1">
                    <div className="flex items-center gap-1.5 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{date}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{time}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>Venue: {room}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-600">
                    Max: {s.max_marks || s.maxMarks || 100} / Pass: {s.passing_marks || s.passMarks || 40}
                  </span>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onOpenEditScheduleModal(s)}
                      className="text-[10px] py-1 px-2"
                    >
                      Edit
                    </Button>
                    <button
                      onClick={() => onDeleteSchedule(schId)}
                      className="p-1 rounded text-red-600 hover:bg-red-50 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
