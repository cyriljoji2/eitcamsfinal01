import React, { useState } from 'react';
import {
  Printer,
  Search,
  Filter,
  Users,
  Download,
  Eye,
  CheckCircle2,
  FileCheck,
  Calendar,
  Sparkles,
  AlertCircle,
  ShieldAlert,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface HallTicketViewProps {
  examinations: any[];
  hallTickets: any[];
  schedules: any[];
  eligibilities?: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onGenerateIndividual: (examId: string, regNo: string) => Promise<any>;
  onGenerateClassBatch: (examId: string, className: string) => Promise<any[]>;
  onGenerateExamBulk: (examId: string) => Promise<any[]>;
  onOpenPrintModal: (ticket: any) => void;
}

export function HallTicketView({
  examinations,
  hallTickets,
  schedules,
  eligibilities = [],
  selectedExamId,
  onSelectExamId,
  onGenerateIndividual,
  onGenerateClassBatch,
  onGenerateExamBulk,
  onOpenPrintModal,
}: HallTicketViewProps) {
  const [programmeFilter, setProgrammeFilter] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [individualRegNo, setIndividualRegNo] = useState('');
  const [targetBatchProg, setTargetBatchProg] = useState<string>('BTECH-CSE');
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'EXAM-2026';

  const examTickets = hallTickets.filter((t) => t.examinationId === activeExamId || t.examination_id === activeExamId);

  const filteredTickets = examTickets.filter((t) => {
    const prog = t.className || t.programme_code || 'B.Tech';
    const matchesProg = programmeFilter === 'All' || prog === programmeFilter;
    const q = searchTerm.toLowerCase();
    const name = (t.studentName || '').toLowerCase();
    const reg = (t.studentRegistrationNumber || '').toLowerCase();
    const htNo = (t.hallTicketNumber || '').toLowerCase();
    return matchesProg && (name.includes(q) || reg.includes(q) || htNo.includes(q));
  });

  const handleGenerateIndividual = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!individualRegNo.trim() || !activeExamId) return;

    setIsGenerating(true);
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      const ticket = await onGenerateIndividual(activeExamId, individualRegNo.trim());
      setIndividualRegNo('');
      setStatusMessage(`Successfully generated Hall Ticket ${ticket.hallTicketNumber} for ${ticket.studentName}.`);
      onOpenPrintModal(ticket);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate hall ticket.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateClassBatch = async () => {
    if (!activeExamId || !targetBatchProg) return;
    setIsGenerating(true);
    setStatusMessage(null);
    setErrorMessage(null);
    try {
      const batch = await onGenerateClassBatch(activeExamId, targetBatchProg);
      setStatusMessage(`Generated ${batch.length} Hall Tickets for ${targetBatchProg}.`);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate batch hall tickets.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateAllExam = async () => {
    if (!activeExamId) return;
    if (
      window.confirm(
        `Are you sure you want to generate Hall Tickets for ALL eligible candidates across all degree programmes for ${activeExamId}? Ineligible students will be safely protected.`
      )
    ) {
      setIsGenerating(true);
      setStatusMessage(null);
      setErrorMessage(null);
      try {
        const batch = await onGenerateExamBulk(activeExamId);
        setStatusMessage(`Generated ${batch.length} Hall Tickets across all eligible degree programmes.`);
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to generate bulk hall tickets.');
      } finally {
        setIsGenerating(false);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Hall Ticket Number',
      'Registration Number',
      'Student Full Name',
      'Programme',
      'Section',
      'Session ID',
      'Papers Scheduled',
      'Issue Date',
    ];
    const rows = filteredTickets.map((t) => [
      t.hallTicketNumber,
      t.studentRegistrationNumber,
      `"${(t.studentName || '').replace(/"/g, '""')}"`,
      t.className,
      t.section,
      t.examinationId,
      t.schedules?.length || 0,
      t.generatedAt ? new Date(t.generatedAt).toISOString().split('T')[0] : '2026-11-03',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `hall_tickets_${activeExamId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Hall Ticket &amp; Admit Card Generation Authority
          </h1>
          <p className="text-xs text-slate-500">
            Generate official examination hall tickets for verified eligible students with automated venue &amp; schedule mapping
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="text-xs gap-1.5 cursor-pointer">
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </Button>
          <Button
            size="sm"
            onClick={handleGenerateAllExam}
            disabled={isGenerating || !activeExamId}
            className="text-xs gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Bulk Generate All Eligible</span>
          </Button>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{statusMessage}</span>
          </div>
          <button onClick={() => setStatusMessage(null)} className="text-emerald-700 hover:text-emerald-900">
            &times;
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-red-700 hover:text-red-900">
            &times;
          </button>
        </div>
      )}

      {/* Generation Workstations Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Individual Generation */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
            <Users className="w-4 h-4 text-[#1e3a8a]" />
            <span>Individual Candidate Hall Ticket Generation</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Generate and print admit card for a specific eligible university student.
          </p>
          <form onSubmit={handleGenerateIndividual} className="flex gap-2">
            <input
              type="text"
              value={individualRegNo}
              onChange={(e) => setIndividualRegNo(e.target.value.toUpperCase())}
              placeholder="e.g. EIT-STU-2026-CSE-0001"
              required
              className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] font-mono bg-slate-50 focus:bg-white"
            />
            <Button type="submit" size="sm" isLoading={isGenerating} className="text-xs whitespace-nowrap">
              Generate &amp; Print
            </Button>
          </form>
        </div>

        {/* Programme Batch Generation */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
            <Printer className="w-4 h-4 text-indigo-700" />
            <span>Programme Cohort Batch Generation</span>
          </div>
          <p className="text-[11px] text-slate-500">
            Generate hall tickets for all verified eligible students in a degree programme.
          </p>
          <div className="flex gap-2">
            <select
              value={targetBatchProg}
              onChange={(e) => setTargetBatchProg(e.target.value)}
              className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-mono"
            >
              <option value="BTECH-CSE">B.Tech Computer Science (CSE)</option>
              <option value="BTECH-ECE">B.Tech Electronics (ECE)</option>
              <option value="BTECH-MECH">B.Tech Mechanical (MECH)</option>
            </select>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleGenerateClassBatch}
              disabled={isGenerating}
              className="text-xs whitespace-nowrap"
            >
              Generate Programme Batch
            </Button>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Programme
          </label>
          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Degree Programmes</option>
            <option value="BTECH-CSE">B.Tech Computer Science (CSE)</option>
            <option value="BTECH-ECE">B.Tech Electronics (ECE)</option>
            <option value="BTECH-MECH">B.Tech Mechanical (MECH)</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student name, Reg No, or Hall Ticket..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Hall Tickets Roster Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 text-xs uppercase tracking-wider font-semibold border-b border-slate-200">
              <tr>
                <th className="px-5 py-3.5">Hall Ticket No</th>
                <th className="px-5 py-3.5">Student &amp; Registration No</th>
                <th className="px-5 py-3.5">Programme &amp; Section</th>
                <th className="px-5 py-3.5">Scheduled Papers</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-800">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-slate-400">
                    No hall tickets generated yet for this examination session. Use the generator tools above.
                  </td>
                </tr>
              ) : (
                filteredTickets.map((t) => {
                  return (
                    <tr key={t.id || t.hallTicketNumber} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-3.5 font-mono font-bold text-[#1e3a8a]">
                        {t.hallTicketNumber}
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-slate-900">{t.studentName}</div>
                        <div className="font-mono text-slate-500 text-[11px]">{t.studentRegistrationNumber}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-slate-800">{t.className}</div>
                        <div className="text-[11px] text-slate-500">Sec {t.section}</div>
                      </td>
                      <td className="px-5 py-3.5 font-mono">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a] font-semibold border border-blue-200">
                          {t.schedules?.length || 0} papers
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                          OFFICIALLY ISSUED
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenPrintModal(t)}
                          className="text-[11px] py-1 px-2.5 gap-1"
                        >
                          <Eye className="w-3 h-3 text-[#1e3a8a]" />
                          <span>View Admit Card</span>
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
