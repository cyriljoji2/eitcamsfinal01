import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  RotateCcw,
  Search,
  Filter,
  AlertCircle,
  Eye,
  FileCheck,
  ChevronDown,
  ChevronUp,
  User,
  BookOpen,
  Award,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';
import { Button } from '../ui/Button';

interface MarksVerificationViewProps {
  examinations: any[];
  schedules: any[];
  allMarks: any[];
  selectedExamId?: string;
  onSelectExamId: (id: string) => void;
  onVerifyMarks: (scheduleId: string, notes?: string) => Promise<void>;
  onOpenReturnModal: (schedule: any) => void;
  onOpenModerateModal?: (result: any) => void;
}

export function MarksVerificationView({
  examinations,
  schedules,
  allMarks,
  selectedExamId,
  onSelectExamId,
  onVerifyMarks,
  onOpenReturnModal,
  onOpenModerateModal,
}: MarksVerificationViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [expandedScheduleId, setExpandedScheduleId] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const activeExamId = selectedExamId || examinations[0]?.id || examinations[0]?.session_id || 'All';

  const examSchedules = schedules.filter(
    (s) => !activeExamId || activeExamId === 'All' || s.examinationId === activeExamId || s.session_id === activeExamId
  );

  const filteredSchedules = examSchedules.filter((sch) => {
    const subStatus = sch.markSubmissionStatus || sch.status || 'Pending';
    const matchesStatus = statusFilter === 'All' || subStatus === statusFilter;

    const q = searchTerm.toLowerCase();
    const title = (sch.course_title || sch.courseName || sch.subjectName || '').toLowerCase();
    const code = (sch.course_code || sch.courseCode || sch.subjectCode || '').toLowerCase();
    const fac = (sch.assigned_evaluator_name || sch.assignedFacultyName || '').toLowerCase();

    return matchesStatus && (title.includes(q) || code.includes(q) || fac.includes(q));
  });

  const submittedCount = examSchedules.filter(
    (s) => (s.markSubmissionStatus === 'Submitted' || s.status === 'FACULTY_SUBMITTED')
  ).length;
  const verifiedCount = examSchedules.filter(
    (s) => (s.markSubmissionStatus === 'Verified' || s.status === 'APPROVED' || s.status === 'PUBLISHED')
  ).length;
  const returnedCount = examSchedules.filter(
    (s) => (s.markSubmissionStatus === 'Returned' || s.status === 'REOPENED')
  ).length;

  const handleVerify = async (scheduleId: string) => {
    if (
      window.confirm(
        'Confirm approval for this course examination paper? Once approved by the Controller of Examinations, student marks will be immutably locked for official grade calculation and result declaration.'
      )
    ) {
      setIsVerifying(true);
      try {
        await onVerifyMarks(scheduleId, 'Audited and verified by Controller of Examinations Autonomous Board');
      } finally {
        setIsVerifying(false);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 tracking-tight">
            Marks Audit &amp; Moderation Workspace
          </h1>
          <p className="text-xs text-slate-500">
            Review faculty submitted student evaluations, moderate marks with documented justification, approve verified scores, or return papers for revision
          </p>
        </div>
      </div>

      {/* Verification KPI stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Pending COE Moderation</div>
            <div className="text-2xl font-black text-blue-700 font-mono mt-0.5">{submittedCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Faculty submissions ready for review</div>
          </div>
          <div className="p-2.5 bg-blue-50 text-blue-700 rounded-xl">
            <FileCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Verified &amp; Approved</div>
            <div className="text-2xl font-black text-emerald-700 font-mono mt-0.5">{verifiedCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Approved for result declaration</div>
          </div>
          <div className="p-2.5 bg-emerald-50 text-emerald-700 rounded-xl">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-500">Returned for Revision</div>
            <div className="text-2xl font-black text-red-700 font-mono mt-0.5">{returnedCount}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Discrepancy notices sent to faculty</div>
          </div>
          <div className="p-2.5 bg-red-50 text-red-700 rounded-xl">
            <RotateCcw className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-xs">
        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Exam Session
          </label>
          <select
            value={activeExamId}
            onChange={(e) => onSelectExamId(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white font-medium"
          >
            <option value="All">All Examination Sessions</option>
            {examinations.map((ex) => (
              <option key={ex.id || ex.session_id} value={ex.id || ex.session_id}>
                {ex.name || ex.session_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Moderation Status
          </label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
          >
            <option value="All">All Evaluation Statuses</option>
            <option value="Submitted">Submitted (Pending Moderation)</option>
            <option value="FACULTY_SUBMITTED">FACULTY_SUBMITTED</option>
            <option value="Verified">Verified &amp; Approved</option>
            <option value="APPROVED">APPROVED</option>
            <option value="Returned">Returned for Revision</option>
          </select>
        </div>

        <div>
          <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">
            Search
          </label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search course code or faculty..."
              className="w-full pl-8 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] bg-slate-50 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Schedules & Marks Roster List */}
      <div className="space-y-4">
        {filteredSchedules.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200/80 p-8 text-center text-xs text-slate-400 shadow-xs">
            No course papers found matching moderation filter criteria.
          </div>
        ) : (
          filteredSchedules.map((sch) => {
            const schId = sch.id || sch.schedule_id;
            const courseCode = sch.course_code || sch.courseCode || sch.subjectCode;
            const courseTitle = sch.course_title || sch.courseName || sch.subjectName;
            const isExpanded = expandedScheduleId === schId;
            const isVerified = sch.markSubmissionStatus === 'Verified' || sch.status === 'APPROVED' || sch.status === 'PUBLISHED';
            const isSubmitted = sch.markSubmissionStatus === 'Submitted' || sch.status === 'FACULTY_SUBMITTED';

            const scheduleMarks = allMarks.filter(
              (m) => (m.subjectCode === courseCode || m.course_code === courseCode)
            );

            return (
              <div
                key={schId}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-all"
              >
                {/* Paper Header Row */}
                <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/50">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#1e3a8a] flex items-center justify-center shrink-0 font-bold font-mono">
                      {courseCode.slice(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900 text-sm">{courseTitle}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-100 text-[#1e3a8a]">
                          {courseCode}
                        </span>
                        <span className="text-xs text-slate-500 font-medium">
                          &bull; {sch.programme_code || sch.className} (Sec {sch.section || 'A'})
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                        <span>Evaluator: <strong>{sch.assigned_evaluator_name || sch.assignedFacultyName || 'Assigned Faculty'}</strong></span>
                        <span>&bull;</span>
                        <span>Exam Date: <strong>{sch.exam_date || sch.examDate}</strong></span>
                        <span>&bull;</span>
                        <span>Evaluated Candidates: <strong>{scheduleMarks.length}</strong></span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap self-end md:self-auto">
                    {isSubmitted && (
                      <>
                        <Button
                          size="sm"
                          onClick={() => handleVerify(schId)}
                          disabled={isVerifying}
                          className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs gap-1 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve Marks</span>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenReturnModal(sch)}
                          className="text-red-700 border-red-200 hover:bg-red-50 text-xs gap-1 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-red-600" />
                          <span>Return to Faculty</span>
                        </Button>
                      </>
                    )}

                    {isVerified && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>VERIFIED &amp; APPROVED</span>
                      </span>
                    )}

                    <button
                      onClick={() => setExpandedScheduleId(isExpanded ? null : schId)}
                      className="p-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 transition-colors cursor-pointer"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Student Marks Table & Moderation Actions */}
                {isExpanded && (
                  <div className="p-5 border-t border-slate-200 space-y-4 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Candidate Evaluation Details &amp; Moderation
                      </div>
                      <span className="text-[11px] text-slate-500">
                        Max Marks: {sch.max_marks || sch.maxMarks || 100} / Pass: {sch.passing_marks || sch.passMarks || 40}
                      </span>
                    </div>

                    <div className="border border-slate-200 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 font-bold text-slate-700 border-b border-slate-200 uppercase text-[10px]">
                          <tr>
                            <th className="px-4 py-2.5">Candidate Registration No</th>
                            <th className="px-4 py-2.5">Student Name</th>
                            <th className="px-4 py-2.5 text-center">Internal (/40)</th>
                            <th className="px-4 py-2.5 text-center">External (/60)</th>
                            <th className="px-4 py-2.5 text-center">Total Score</th>
                            <th className="px-4 py-2.5 text-center">Computed Grade</th>
                            <th className="px-4 py-2.5 text-center">Status</th>
                            <th className="px-4 py-2.5 text-right">Moderation</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-slate-800">
                          {scheduleMarks.length === 0 ? (
                            <tr>
                              <td colSpan={8} className="px-4 py-6 text-center text-slate-400">
                                No candidate evaluation marks entered for this paper yet.
                              </td>
                            </tr>
                          ) : (
                            scheduleMarks.map((m, idx) => {
                              const total = m.marksObtained ?? m.total_marks ?? 85;
                              const internal = m.internal_marks ?? 36;
                              const external = m.external_marks ?? (total - internal);
                              const isPass = total >= (sch.passing_marks || 40);

                              return (
                                <tr key={idx} className="hover:bg-slate-50/60">
                                  <td className="px-4 py-2.5 font-mono font-bold text-[#1e3a8a]">
                                    {m.studentRegistrationNumber || m.registration_number}
                                  </td>
                                  <td className="px-4 py-2.5 font-medium">{m.student_name || 'Candidate Student'}</td>
                                  <td className="px-4 py-2.5 text-center font-mono">{internal}</td>
                                  <td className="px-4 py-2.5 text-center font-mono">{external}</td>
                                  <td className="px-4 py-2.5 text-center font-mono font-bold text-slate-900">
                                    {total}
                                  </td>
                                  <td className="px-4 py-2.5 text-center">
                                    <span className="px-2 py-0.5 rounded font-bold bg-blue-50 text-[#1e3a8a]">
                                      {m.grade || 'A'}
                                    </span>
                                  </td>
                                  <td className="px-4 py-2.5 text-center">
                                    <span
                                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                        isPass ? 'text-emerald-700 bg-emerald-50' : 'text-red-700 bg-red-50'
                                      }`}
                                    >
                                      {isPass ? 'PASS' : 'FAIL'}
                                    </span>
                                  </td>
                                  <td className="px-4 py-2.5 text-right">
                                    {onOpenModerateModal && (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() =>
                                          onOpenModerateModal({
                                            ...m,
                                            course_code: courseCode,
                                            max_marks: sch.max_marks || 100,
                                          })
                                        }
                                        className="text-[10px] py-1 px-2"
                                      >
                                        Moderate Score
                                      </Button>
                                    )}
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
