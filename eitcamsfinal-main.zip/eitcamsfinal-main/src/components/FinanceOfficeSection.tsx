import React, { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { FinanceWorkspace } from './finance/FinanceWorkspace';
import { UserSession } from '../types';

interface FinanceOfficeSectionProps {
  onRefreshData?: () => Promise<void> | void;
  embedded?: boolean;
}

export function FinanceOfficeSection({ onRefreshData, embedded }: FinanceOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'Finance Officer';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-005',
      username: session?.user?.username || 'finance',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'finance@eit.edu.in',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'Comptroller of Finance',
      department: emp?.primary_department || 'FINANCE',
      portalType: 'employee',
      employeeId: emp?.registration_number || 'FIN-001',
      permanentOffice: session?.permanentOffice || {
        office_id: 'PO-005',
        office_name: 'Finance Office',
        canonical_username: 'finance',
        office_code: 'FINANCE',
        is_system_reserved: true,
        primary_contact_email: 'finance@eit.edu.in',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    };
  }, [session]);

  const handleLogout = async () => {
    await logout();
  };

  const handleRefresh = async () => {
    if (onRefreshData) {
      await onRefreshData();
    }
  };

  return (
    <FinanceWorkspace
      user={userSession}
      onLogout={handleLogout}
      onRefreshData={handleRefresh}
    />
  );
}

export default FinanceOfficeSection;
