import React, { useState } from 'react';
import {
  GraduationCap,
  Briefcase,
  Users,
  Lock,
  User,
  ArrowLeft,
  KeyRound,
  FlaskConical,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { PortalType } from '../../types/auth';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';

export interface LoginPageProps {
  portal: PortalType;
  onBackToHome?: () => void;
  onLoginSuccess?: (portalType: PortalType) => void;
}

export function LoginPage({ portal, onBackToHome, onLoginSuccess }: LoginPageProps) {
  const { login, navigateToLanding, isLoading, isDevMode } = useAuth();
  const handleBack = onBackToHome || navigateToLanding;

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showDevAccounts, setShowDevAccounts] = useState(false);

  // Portal-specific metadata
  const portalMeta = {
    student: {
      title: 'Student Login',
      subtitle: 'Enter your student credentials to access your portal.',
      icon: GraduationCap,
      identifierLabel: 'Registration Number / Username',
      identifierPlaceholder: 'Enter your username or Student ID',
    },
    employee: {
      title: 'Employee Login',
      subtitle: 'Enter your Employee ID or institutional username.',
      icon: Briefcase,
      identifierLabel: 'Username / Employee ID',
      identifierPlaceholder: 'Enter your username or Employee ID',
    },
    parent: {
      title: 'Parent/Guardian Login',
      subtitle: 'Enter your registered guardian credentials.',
      icon: Users,
      identifierLabel: 'Username / Guardian ID',
      identifierPlaceholder: 'Enter your username or Guardian ID',
    },
  }[portal] || {
    title: 'Portal Login',
    subtitle: 'Enter your credentials to continue.',
    icon: User,
    identifierLabel: 'Username',
    identifierPlaceholder: 'Enter your username',
  };

  const Icon = portalMeta.icon;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const trimmedIdentifier = identifier.trim();
    if (!trimmedIdentifier) {
      setErrorMessage('Please enter your username to continue.');
      return;
    }

    if (!password) {
      setErrorMessage('Please enter your password to continue.');
      return;
    }

    const result = await login({
      identifier: trimmedIdentifier,
      password,
      portalType: portal,
    });

    if (result.success) {
      if (onLoginSuccess) {
        onLoginSuccess(portal);
      } else {
        window.location.hash = `#/dashboard/${portal}`;
      }
    } else {
      setErrorMessage(result.errorMessage || result.error || 'Authentication failed. Please verify credentials.');
    }
  };

  const handleQuickFill = (user: string) => {
    setIdentifier(user);
    setPassword('dev_test_password');
    setErrorMessage(null);
  };

  return (
    <div className="w-full max-w-[420px] mx-auto px-4 py-8 sm:py-12 flex flex-col items-center">
      {/* Clean Minimalism Login Box */}
      <div className="w-full bg-white border border-[#e2e8f0] rounded-xl p-8 sm:p-10 shadow-[0_4px_6px_-1px_rgba(0,0,0,0.08)]">
        {/* Header with Circular Icon and Clean Headings */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#eff6ff] text-[#1e3a8a] mb-3">
            <Icon className="w-7 h-7" />
          </div>

          <span className="text-[11px] font-bold text-[#1e3a8a] tracking-wider uppercase block mb-1">
            Electrix Institute of Technology (EIT)
          </span>

          <h2 id="login-title" className="text-[22px] sm:text-[24px] font-bold text-[#1e293b] tracking-tight mb-1">
            {portalMeta.title}
          </h2>

          <p id="login-desc" className="text-[13px] sm:text-[14px] text-[#64748b]">
            {portalMeta.subtitle}
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-5">
            <Alert
              type="error"
              message={errorMessage}
              onDismiss={() => setErrorMessage(null)}
            />
          </div>
        )}

        {/* Login Form */}
        <form id={`${portal}-login-form`} onSubmit={handleSubmit} className="space-y-4">
          <Input
            id={`${portal}-identifier-input`}
            label={portalMeta.identifierLabel}
            placeholder={portalMeta.identifierPlaceholder}
            value={identifier}
            onChange={(e) => {
              setIdentifier(e.target.value);
              if (errorMessage) setErrorMessage(null);
            }}
            disabled={isLoading}
            required
            startIcon={<User className="w-4 h-4" />}
            autoFocus
          />

          <Input
            id={`${portal}-password-input`}
            label="Password"
            placeholder="Enter password"
            type="password"
            isPassword
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (errorMessage) setErrorMessage(null);
            }}
            disabled={isLoading}
            required
            startIcon={<Lock className="w-4 h-4" />}
          />

          <div className="pt-2">
            <Button
              id={`${portal}-submit-btn`}
              type="submit"
              variant="primary"
              size="lg"
              isLoading={isLoading}
              className="w-full"
              rightIcon={<KeyRound className="w-4 h-4" />}
            >
              Sign In
            </Button>
          </div>
        </form>

        {/* Back Link */}
        <div className="mt-5 text-center">
          <button
            id="login-back-button"
            type="button"
            onClick={handleBack}
            className="inline-flex items-center gap-1.5 text-[13px] text-[#64748b] hover:text-[#1e293b] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to selection</span>
          </button>
        </div>
      </div>

      {/* Dev helper below the card if in development mode */}
      {isDevMode && (
        <div className="w-full mt-4 p-3 bg-slate-50 border border-slate-200/80 rounded-xl text-xs">
          <button
            type="button"
            onClick={() => setShowDevAccounts((prev) => !prev)}
            className="w-full flex items-center justify-between text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <FlaskConical className="w-3.5 h-3.5 text-amber-600" aria-hidden="true" />
              <span>Development Quick-Fill Accounts</span>
            </span>
            {showDevAccounts ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {showDevAccounts && (
            <div className="mt-2.5 pt-2 border-t border-slate-200/60 space-y-2">
              {portal === PortalType.Employee && (
                <div className="space-y-1.5">
                  <div className="text-[11px] font-semibold text-slate-700">Permanent Offices:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {['admin', 'admissionsoffice', 'academicoffice', 'coeoffice', 'finance', 'hosteloffice', 'itoffice'].map((u) => (
                      <button
                        key={u}
                        type="button"
                        onClick={() => handleQuickFill(u)}
                        className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 rounded font-mono text-[11px] text-slate-800 cursor-pointer"
                      >
                        {u}
                      </button>
                    ))}
                  </div>
                  <div className="text-[11px] font-semibold text-slate-700 pt-1">Teaching Faculty:</div>
                  <button
                    type="button"
                    onClick={() => handleQuickFill('dr.sharma')}
                    className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 rounded font-mono text-[11px] text-slate-800 cursor-pointer"
                  >
                    dr.sharma
                  </button>
                </div>
              )}

              {portal === PortalType.Student && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-slate-700">Student Account:</div>
                  <button
                    type="button"
                    onClick={() => handleQuickFill('EIT-STU-2026-CSE-0001')}
                    className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 rounded font-mono text-[11px] text-slate-800 cursor-pointer"
                  >
                    EIT-STU-2026-CSE-0001 (Arjun Kumar)
                  </button>
                </div>
              )}

              {portal === PortalType.Parent && (
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-slate-700">Parent Account:</div>
                  <button
                    type="button"
                    onClick={() => handleQuickFill('rajesh.kumar')}
                    className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-200 rounded font-mono text-[11px] text-slate-800 cursor-pointer"
                  >
                    rajesh.kumar (Rajesh Kumar)
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
