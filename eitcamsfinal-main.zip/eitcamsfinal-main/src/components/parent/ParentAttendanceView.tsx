import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  ShieldCheck,
  CalendarCheck,
  Lock,
  BookOpen,
} from 'lucide-react';
import { Student } from '../../types/studentPortalTypes';
import { AttendanceRecord } from '../../types/academic';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface ParentAttendanceViewProps {
  student: Student;
  attendanceRecords: AttendanceRecord[];
  canViewAttendance?: boolean;
}

export function ParentAttendanceView({
  student,
  attendanceRecords,
  canViewAttendance = true,
}: ParentAttendanceViewProps) {
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!canViewAttendance) {
    return (
      <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-[#1e293b]">Attendance Records Restricted</h3>
        <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
          Daily classroom attendance tracking is protected by student consent settings and not authorized for this guardian account.
        </p>
      </div>
    );
  }

  // Normalize status checks
  const isPresent = (st: string) => ['Present', 'PRESENT'].includes(st);
  const isLate = (st: string) => ['Late', 'LATE'].includes(st);
  const isAbsent = (st: string) => ['Absent', 'ABSENT'].includes(st);
  const isLeave = (st: string) => ['Leave', 'LEAVE', 'EXCUSED'].includes(st);

  // Metrics
  const totalDays = attendanceRecords.length;
  const presentCount = attendanceRecords.filter((r) => isPresent(r.status)).length;
  const absentCount = attendanceRecords.filter((r) => isAbsent(r.status)).length;
  const lateCount = attendanceRecords.filter((r) => isLate(r.status)).length;
  const leaveCount = attendanceRecords.filter((r) => isLeave(r.status)).length;

  // Percentage calculation: (Present + Late) / Total
  const effectivePresent = presentCount + lateCount;
  const percentage = totalDays > 0 ? Math.round((effectivePresent / totalDays) * 100) : 100;

  // Course-wise aggregation
  const courseMap = new Map<string, { total: number; present: number; courseName: string }>();
  for (const rec of attendanceRecords) {
    const raw = rec as any;
    const code = raw.courseCode || raw.course_code || rec.className || 'General Course';
    const title = raw.courseTitle || raw.course_title || rec.sectionName || code;
    if (!courseMap.has(code)) {
      courseMap.set(code, { total: 0, present: 0, courseName: title });
    }
    const entry = courseMap.get(code)!;
    entry.total += 1;
    if (isPresent(rec.status) || isLate(rec.status)) {
      entry.present += 1;
    }
  }

  // Filtered attendance records
  const filteredRecords = attendanceRecords.filter((rec) => {
    const raw = rec as any;
    const statusMatch =
      filterStatus === 'All' ||
      rec.status.toUpperCase() === filterStatus.toUpperCase() ||
      (filterStatus === 'Leave' && isLeave(rec.status));
    const searchMatch =
      !searchQuery ||
      rec.date.includes(searchQuery) ||
      (raw.courseCode && raw.courseCode.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (raw.course_code && raw.course_code.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (rec.className && rec.className.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (rec.remarks && rec.remarks.toLowerCase().includes(searchQuery.toLowerCase()));
    return statusMatch && searchMatch;
  });

  return (
    <div className="space-y-6">
      {/* Attendance Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <CalendarCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Attendance Record</h1>
                <Badge variant={percentage >= 85 ? 'emerald' : percentage >= 75 ? 'amber' : 'rose'} size="sm">
                  {percentage}% Semester Cumulative Rate
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: {student.fullName} ({student.registrationNumber}) • {student.program || student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#64748b] bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Certified Faculty Attendance Logs</span>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Working Days */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <span className="text-xs text-[#64748b] font-medium block">Working Sessions</span>
          <span className="text-xl font-bold text-[#1e293b] mt-1 block">{totalDays}</span>
          <span className="text-[11px] text-[#64748b]">Total class periods</span>
        </div>

        {/* Present */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-emerald-700 font-semibold">Present</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-xl font-bold text-emerald-700 mt-1 block">{presentCount}</span>
          <span className="text-[11px] text-[#64748b]">
            {totalDays > 0 ? Math.round((presentCount / totalDays) * 100) : 0}% of sessions
          </span>
        </div>

        {/* Late */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-700 font-semibold">Late</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-xl font-bold text-amber-700 mt-1 block">{lateCount}</span>
          <span className="text-[11px] text-[#64748b]">Counted present</span>
        </div>

        {/* Leave / Excused */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-700 font-semibold">Excused / OD</span>
            <AlertCircle className="w-4 h-4 text-blue-600" />
          </div>
          <span className="text-xl font-bold text-blue-700 mt-1 block">{leaveCount}</span>
          <span className="text-[11px] text-[#64748b]">Authorized duty/leave</span>
        </div>

        {/* Absent */}
        <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-700 font-semibold">Absent</span>
            <XCircle className="w-4 h-4 text-rose-600" />
          </div>
          <span className="text-xl font-bold text-rose-700 mt-1 block">{absentCount}</span>
          <span className="text-[11px] text-[#64748b]">Unexcused absences</span>
        </div>
      </div>

      {/* Course-Wise Attendance Summary (Stage C) */}
      {courseMap.size > 0 && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Course-Wise Attendance Breakdown</h2>
            </div>
            <span className="text-xs text-[#64748b]">Eligibility threshold: 75% per course</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from(courseMap.entries()).map(([code, data]) => {
              const coursePct = data.total > 0 ? Math.round((data.present / data.total) * 100) : 100;
              return (
                <div key={code} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-[#1e3a8a]">{code}</span>
                    <Badge variant={coursePct >= 75 ? 'emerald' : 'rose'} size="sm">
                      {coursePct}%
                    </Badge>
                  </div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${coursePct >= 75 ? 'bg-emerald-600' : 'bg-rose-600'}`}
                      style={{ width: `${Math.min(100, coursePct)}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#64748b]">
                    <span>Attended: {data.present} / {data.total}</span>
                    <span className={coursePct >= 75 ? 'text-emerald-700 font-medium' : 'text-rose-700 font-bold'}>
                      {coursePct >= 75 ? 'Eligible' : 'Shortage Risk'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Progress Bar & Policy Status */}
      <div className="bg-white p-5 rounded-xl border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-[#1e293b]">Institutional COE Examination Eligibility Criteria</span>
          <span className="font-bold text-[#1e293b]">{percentage}% / 75% Minimum Required</span>
        </div>
        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              percentage >= 85 ? 'bg-emerald-600' : percentage >= 75 ? 'bg-amber-500' : 'bg-rose-600'
            }`}
            style={{ width: `${Math.min(100, percentage)}%` }}
          />
        </div>
        <p className="text-[11px] text-[#64748b]">
          {percentage >= 75
            ? 'Candidate satisfies the mandatory 75% attendance threshold for university final examination hall ticket issuance.'
            : 'Warning: Attendance is below 75%. Please contact the assigned Proctor to review leave authorizations and remediation.'}
        </p>
      </div>

      {/* Attendance History Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        {/* Controls Bar */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Classroom Attendance Sessions Log</h2>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full sm:w-auto">
            <div className="w-full sm:w-56">
              <Input
                placeholder="Search date, course..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              {['All', 'Present', 'Late', 'Leave', 'Absent'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setFilterStatus(st)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    filterStatus === st
                      ? 'bg-white text-[#1e293b] shadow-2xs'
                      : 'text-[#64748b] hover:text-[#1e293b]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3.5">Date</th>
                <th className="px-5 py-3.5">Course / Module</th>
                <th className="px-5 py-3.5">Section</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Recorded By</th>
                <th className="px-5 py-3.5">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-[#64748b]">
                    No attendance session records match the selected filter.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((record, idx) => {
                  const raw = record as any;
                  return (
                    <tr key={record.id || idx} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-semibold text-[#1e293b] font-mono">
                        {record.date}
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-[#1e293b]">
                          {raw.courseCode || raw.course_code || record.className}
                        </div>
                        <div className="text-[11px] text-[#64748b]">
                          {raw.courseTitle || raw.course_title || 'Classroom Instruction'}
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-[#475569]">Section {record.sectionName || student.section}</td>
                      <td className="px-5 py-3.5">
                        <Badge
                          variant={
                            isPresent(record.status)
                              ? 'emerald'
                              : isLate(record.status)
                              ? 'amber'
                              : isLeave(record.status)
                              ? 'blue'
                              : 'rose'
                          }
                          size="sm"
                        >
                          {record.status}
                        </Badge>
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b]">
                        {record.recordedBy || 'Faculty Instructor'}
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b]">
                        {record.remarks || 'Session verified by teaching faculty.'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
