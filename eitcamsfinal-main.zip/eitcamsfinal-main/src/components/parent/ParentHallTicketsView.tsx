import React from 'react';
import {
  Award,
  Printer,
  Lock,
} from 'lucide-react';
import { Student } from '../../types/studentPortalTypes';
import { HallTicket } from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface ParentHallTicketsViewProps {
  student: Student;
  hallTickets: HallTicket[];
  onViewHallTicket: (hallTicket: HallTicket) => void;
  canViewGrades?: boolean;
}

export function ParentHallTicketsView({
  student,
  hallTickets,
  onViewHallTicket,
  canViewGrades = true,
}: ParentHallTicketsViewProps) {
  if (!canViewGrades) {
    return (
      <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-[#1e293b]">Hall Tickets Restricted</h3>
        <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
          Examination admit card records are restricted from guardian inspection per student privacy preferences.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Hall Tickets Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Official Examination Hall Tickets</h1>
                <Badge variant="blue" size="sm">
                  {hallTickets.length} Issued Admit Cards
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Official Controller of Examinations (COE) admit passes for {student.fullName} ({student.registrationNumber})
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Hall Tickets Grid */}
      {hallTickets.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs text-[#64748b]">
          <Award className="w-12 h-12 mx-auto text-[#cbd5e1] mb-3" />
          <h3 className="text-base font-bold text-[#1e293b]">No Hall Tickets Released</h3>
          <p className="text-xs mt-1">
            Hall tickets are generated and issued by the Controller of Examinations (COE) after attendance and fee clearance verification.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {hallTickets.map((ht) => (
            <div
              key={ht.id}
              className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden flex flex-col justify-between hover:border-[#cbd5e1] hover:shadow-sm transition-all"
            >
              <div className="p-6 space-y-4">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-[#64748b] block">
                      University Admit Pass
                    </span>
                    <span className="text-sm font-bold text-[#1e293b]">{ht.examinationName}</span>
                  </div>
                  <Badge variant={ht.status === 'Generated' || !ht.status ? 'emerald' : 'blue'} size="sm">
                    {ht.status === 'Generated' || !ht.status ? 'Official / Issued' : ht.status}
                  </Badge>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-[#64748b] block">Hall Ticket No.</span>
                    <span className="font-mono font-bold text-[#1e3a8a] mt-0.5 block">
                      {ht.hallTicketNumber}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Candidate Reg No.</span>
                    <span className="font-mono font-bold text-[#1e293b] mt-0.5 block">
                      {ht.studentRegistrationNumber}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Programme &amp; Section</span>
                    <span className="font-semibold text-[#1e293b] mt-0.5 block">
                      {ht.className} - Section {ht.section}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Institutional Center</span>
                    <span className="font-semibold text-[#1e293b] mt-0.5 block">
                      {ht.schoolName || 'Electrix Institute of Technology (EIT)'}
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[#64748b] block">Scheduled Papers</span>
                    <span className="font-semibold text-[#1e293b] mt-0.5 block">
                      {ht.schedules?.length || 0} Course Papers Scheduled
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex items-center justify-between">
                <span className="text-[11px] text-[#64748b] font-mono">
                  Issued: {ht.generatedAt || '2026-11-01'}
                </span>
                <Button
                  id={`btn-print-hall-ticket-${ht.id}`}
                  size="sm"
                  variant="primary"
                  onClick={() => onViewHallTicket(ht)}
                  className="gap-1.5 text-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>View / Print Pass</span>
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
