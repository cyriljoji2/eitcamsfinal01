import React, { useState } from 'react';
import {
  Receipt,
  Download,
  Eye,
  Lock,
} from 'lucide-react';
import { Student } from '../../types/studentPortalTypes';
import { FeeReceipt } from '../../types/finance';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface ParentReceiptsViewProps {
  student: Student;
  receipts: FeeReceipt[];
  onViewReceipt: (receipt: FeeReceipt) => void;
  canViewFinance?: boolean;
}

export function ParentReceiptsView({
  student,
  receipts,
  onViewReceipt,
  canViewFinance = true,
}: ParentReceiptsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');

  if (!canViewFinance) {
    return (
      <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-[#1e293b]">Payment Receipts Restricted</h3>
        <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
          Access to payment receipts is restricted per student privacy authorizations.
        </p>
      </div>
    );
  }

  const filteredReceipts = receipts.filter(
    (r) =>
      r.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.feeTypeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.receiptDate.includes(searchTerm) ||
      (r.paymentMode && r.paymentMode.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (r.transactionReference && r.transactionReference.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleExportCsv = () => {
    if (receipts.length === 0) return;

    const headers = [
      'Receipt Number',
      'Date',
      'Student Name',
      'Registration Number',
      'Programme',
      'Section',
      'Fee Description',
      'Amount Paid ($)',
      'Payment Mode',
      'Transaction Reference',
      'Status',
    ];

    const rows = receipts.map((r) => [
      r.receiptNumber,
      r.receiptDate,
      r.studentName,
      r.studentRegistrationNumber,
      r.className,
      r.section,
      r.feeTypeName,
      r.amountPaid.toFixed(2),
      r.paymentMode,
      r.transactionReference || 'N/A',
      r.isVoided ? 'Voided' : 'Valid',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Fee_Receipts_${student.registrationNumber || 'Student'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Receipts Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Receipt className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Official Fee Payment Receipts</h1>
                <Badge variant="emerald" size="sm">
                  {receipts.length} Official Receipts
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: {student.fullName} ({student.registrationNumber}) • Programme: {student.program || student.admissionClass}
              </p>
            </div>
          </div>

          <Button
            id="btn-export-receipts-csv"
            size="sm"
            variant="outline"
            onClick={handleExportCsv}
            disabled={receipts.length === 0}
            className="gap-1.5 text-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Receipts CSV</span>
          </Button>
        </div>
      </div>

      {/* Receipts Table Card */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Certified Institutional Receipts Log</h2>
          </div>

          <div className="w-full sm:w-64">
            <Input
              placeholder="Search receipt #, fee, date..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3.5">Receipt #</th>
                <th className="px-5 py-3.5">Payment Date</th>
                <th className="px-5 py-3.5">Fee Head</th>
                <th className="px-5 py-3.5 text-right">Amount Paid</th>
                <th className="px-5 py-3.5">Payment Mode</th>
                <th className="px-5 py-3.5">Transaction Ref</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-8 text-center text-[#64748b]">
                    No official payment receipts found for this student account.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((receipt) => (
                  <tr key={receipt.receiptNumber} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5 font-bold text-[#1e293b] font-mono">
                      {receipt.receiptNumber}
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b]">{receipt.receiptDate}</td>
                    <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                      {receipt.feeTypeName}
                    </td>
                    <td className="px-5 py-3.5 text-right font-bold text-emerald-700">
                      ${receipt.amountPaid.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-[#475569]">{receipt.paymentMode}</td>
                    <td className="px-5 py-3.5 font-mono text-[#64748b]">
                      {receipt.transactionReference || '—'}
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge variant={receipt.isVoided ? 'rose' : 'emerald'} size="sm">
                        {receipt.isVoided ? 'Voided' : 'Valid'}
                      </Badge>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <button
                        id={`btn-view-receipt-${receipt.receiptNumber}`}
                        type="button"
                        onClick={() => onViewReceipt(receipt)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#1e3a8a] hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-md transition-colors cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View / Print</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
