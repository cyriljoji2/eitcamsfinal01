import React from 'react';
import {
  CalendarCheck,
  DollarSign,
  Award,
  User,
  GraduationCap,
  Clock,
  Receipt,
  ChevronRight,
  ShieldCheck,
  Calendar,
  Home,
  UserCheck,
  Lock,
  Megaphone,
} from 'lucide-react';
import { Student, ProctorAssignment } from '../../types/studentPortalTypes';
import { AcademicSession } from '../../types/academic';
import { FeeAssignment, FeeReceipt } from '../../types/finance';
import {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
} from '../../types/examination';
import { StudentHostelDetails } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { ParentTab } from './ParentWorkspace';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface ParentOverviewProps {
  parentUser: any;
  student: Student;
  allLinkedStudents: Student[];
  currentSession: AcademicSession | null;
  attendance: any[];
  feeAssignments: FeeAssignment[];
  receipts: FeeReceipt[];
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  hallTickets: HallTicket[];
  results: StudentExamResult[];
  proctor?: ProctorAssignment | null;
  hostelDetails?: StudentHostelDetails | null;
  permissions?: {
    can_view_grades: boolean;
    can_view_attendance: boolean;
    can_view_finance: boolean;
  };
  onNavigateTab: (tab: ParentTab) => void;
  onSelectStudent: (student: Student) => void;
}

export function ParentOverview({
  parentUser,
  student,
  allLinkedStudents,
  currentSession,
  attendance,
  feeAssignments,
  receipts,
  examinations,
  schedules,
  hallTickets,
  results,
  proctor,
  hostelDetails,
  permissions = { can_view_grades: true, can_view_attendance: true, can_view_finance: true },
  onNavigateTab,
  onSelectStudent,
}: ParentOverviewProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  // 1. Calculate Attendance Percentage
  const isPresent = (st: string) => ['Present', 'PRESENT'].includes(st);
  const isLate = (st: string) => ['Late', 'LATE'].includes(st);
  const totalDays = attendance.length;
  const presentDays = attendance.filter((a) => isPresent(a.status)).length;
  const lateDays = attendance.filter((a) => isLate(a.status)).length;
  const attendanceRate =
    totalDays > 0 ? Math.round(((presentDays + lateDays) / totalDays) * 100) : 100;

  // 2. Calculate Financial Summary
  const totalBilled = feeAssignments.reduce((sum, f) => sum + (f.amountDue || 0), 0);
  const totalPaid = feeAssignments.reduce((sum, f) => sum + (f.amountPaid || 0), 0);
  const totalWaived = feeAssignments.reduce((sum, f) => sum + (f.discountOrWaiver || 0), 0);
  const totalOutstanding = Math.max(0, totalBilled - totalPaid - totalWaived);

  // 3. Upcoming Examinations for this student's class
  const upcomingExams = examinations.filter(
    (e) =>
      e.status === 'Active' ||
      e.status === 'Draft' ||
      e.status === 'Mark Entry Open' ||
      (e as any).session_status === 'ACTIVE'
  );

  // 4. Latest Published Result (strict COE published check)
  const publishedResults = results.filter((res) => {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
    );
    return (
      parentExam?.status === 'Published' ||
      (parentExam as any)?.session_status === 'RESULTS_PUBLISHED' ||
      res.verificationStatus === 'Published' ||
      (res as any).result_status === 'PASS'
    );
  });
  const latestPublishedResult = publishedResults[0] || null;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#1e3a8a] to-[#1e293b] text-white rounded-2xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="text-xs font-semibold uppercase tracking-wider text-blue-200 bg-blue-900/60 px-2.5 py-1 rounded-md border border-blue-700/40">
                Guardian / Parent Portal
              </span>
              <span className="text-xs text-blue-200 flex items-center gap-1 bg-white/10 px-2.5 py-0.5 rounded-md">
                <Calendar className="w-3.5 h-3.5 text-blue-300" />
                <span>Academic Year {activeAcademicYear || currentSession?.name || '2026–2027'}</span>
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Welcome, {parentUser.name || parentUser.displayName || 'Guardian'}
            </h1>
            <p className="text-sm text-blue-100/90 max-w-2xl leading-relaxed">
              Real-time academic monitoring, verified attendance, fee statements, and COE published results for{' '}
              <strong className="text-white font-semibold">{student.fullName}</strong>.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-xs border border-white/15 px-4 py-3 rounded-xl shrink-0">
            <div className="w-10 h-10 rounded-lg bg-white text-[#1e3a8a] flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-blue-200 block">Monitored Student</span>
              <p className="text-sm font-bold text-white leading-tight">{student.fullName}</p>
              <p className="text-xs text-blue-200 font-mono mt-0.5">
                {student.program || student.admissionClass} • Sec {student.section}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Student Switcher Bar (if more than 1 linked child) */}
      {allLinkedStudents.length > 1 && (
        <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-[#1e3a8a]" />
            <span className="text-xs font-bold text-[#1e293b]">
              Officially Linked Dependents ({allLinkedStudents.length}):
            </span>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {allLinkedStudents.map((child) => (
              <button
                key={child.id}
                id={`btn-select-child-${child.id}`}
                type="button"
                onClick={() => onSelectStudent(child)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  child.id === student.id
                    ? 'bg-[#1e3a8a] text-white shadow-xs'
                    : 'bg-slate-100 text-[#475569] hover:bg-slate-200 hover:text-[#1e293b]'
                }`}
              >
                {child.fullName} ({child.section})
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Attendance */}
        <div
          onClick={() => onNavigateTab('attendance')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Attendance Rate
            </span>
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          {permissions.can_view_attendance ? (
            <>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-[#1e293b]">{attendanceRate}%</span>
                <Badge
                  variant={attendanceRate >= 85 ? 'emerald' : attendanceRate >= 75 ? 'amber' : 'rose'}
                  size="sm"
                >
                  {attendanceRate >= 85 ? 'Excellent' : attendanceRate >= 75 ? 'Eligible' : 'Low Warning'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
                <span>{presentDays} Attended • {totalDays} Sessions</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
              </p>
            </>
          ) : (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Permission Protected</span>
            </div>
          )}
        </div>

        {/* KPI 2: Fee Balance */}
        <div
          onClick={() => onNavigateTab('fees')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Fee Balance
            </span>
            <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center group-hover:scale-105 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          {permissions.can_view_finance ? (
            <>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-[#1e293b]">
                  ${totalOutstanding.toLocaleString()}
                </span>
                <Badge variant={totalOutstanding === 0 ? 'emerald' : 'amber'} size="sm">
                  {totalOutstanding === 0 ? 'Fully Cleared' : 'Payment Due'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
                <span>Paid: ${totalPaid.toLocaleString()} / ${totalBilled.toLocaleString()}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
              </p>
            </>
          ) : (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Permission Protected</span>
            </div>
          )}
        </div>

        {/* KPI 3: Upcoming Examinations */}
        <div
          onClick={() => onNavigateTab('examinations')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Upcoming Exams
            </span>
            <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          {permissions.can_view_grades ? (
            <>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-[#1e293b]">{upcomingExams.length}</span>
                <span className="text-xs text-[#64748b] font-medium">Scheduled Terms</span>
              </div>
              <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
                <span>{hallTickets.length} Hall Tickets Issued</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
              </p>
            </>
          ) : (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Permission Protected</span>
            </div>
          )}
        </div>

        {/* KPI 4: Latest Published Result */}
        <div
          onClick={() => onNavigateTab('results')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#cbd5e1] hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b] uppercase tracking-wider">
              Latest Result
            </span>
            <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Award className="w-5 h-5" />
            </div>
          </div>
          {permissions.can_view_grades ? (
            <>
              <div className="mt-3 flex items-baseline gap-2">
                {latestPublishedResult ? (
                  <>
                    <span className="text-2xl font-bold text-[#1e293b]">
                      {latestPublishedResult.percentage}%
                    </span>
                    <Badge
                      variant={latestPublishedResult.resultStatus === 'Pass' ? 'emerald' : 'rose'}
                      size="sm"
                    >
                      {latestPublishedResult.resultStatus}
                    </Badge>
                  </>
                ) : (
                  <span className="text-sm font-semibold text-[#64748b]">Awaiting COE Release</span>
                )}
              </div>
              <p className="text-xs text-[#64748b] mt-1.5 flex items-center justify-between">
                <span>{latestPublishedResult?.examinationName || 'Pending formal audit'}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#94a3b8] group-hover:text-[#1e293b]" />
              </p>
            </>
          ) : (
            <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-500">
              <Lock className="w-4 h-4 text-slate-400" />
              <span>Permission Protected</span>
            </div>
          )}
        </div>
      </div>

      {/* University Welfare & Advisor Highlights (Stage D) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Proctor Highlight */}
        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#1e3a8a] flex items-center justify-center shrink-0">
            <UserCheck className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
              Assigned Faculty Proctor
            </span>
            <p className="text-sm font-bold text-[#1e293b] mt-0.5 truncate">
              {proctor ? proctor.facultyName : 'Dr. Ramesh Sundaram'}
            </p>
            <p className="text-xs text-[#64748b] truncate">
              {proctor ? proctor.facultyDepartment : 'Computer Science & Engineering'}
            </p>
            <p className="text-[11px] font-mono text-[#1e3a8a] mt-1 truncate">
              {proctor?.facultyEmail || 'r.sundaram@eit.edu'}
            </p>
          </div>
        </div>

        {/* Hostel Highlight */}
        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
            <Home className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
              Hostel Accommodation
            </span>
            {hostelDetails && hostelDetails.currentAllocation ? (
              <>
                <p className="text-sm font-bold text-[#1e293b] mt-0.5 truncate">
                  {hostelDetails.currentAllocation.hostel_block_name}
                </p>
                <p className="text-xs text-emerald-700 font-mono mt-0.5">
                  Room {hostelDetails.currentAllocation.room_number} &bull; Bed {hostelDetails.currentAllocation.bed_identifier}
                </p>
                <span className="text-[10px] text-[#64748b] block mt-1">
                  Status: <strong>{hostelDetails.currentAllocation.status}</strong>
                </span>
              </>
            ) : (
              <>
                <p className="text-sm font-bold text-[#1e293b] mt-0.5">Day Scholar</p>
                <p className="text-xs text-[#64748b] mt-0.5">Off-campus daily commuting student</p>
              </>
            )}
          </div>
        </div>

        {/* Institutional Announcements */}
        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5 sm:col-span-2 lg:col-span-1">
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <Megaphone className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
              Campus Notice
            </span>
            <p className="text-xs font-bold text-[#1e293b] mt-0.5 leading-snug">
              Autonomous Curriculum &amp; Examination Cycles
            </p>
            <p className="text-[11px] text-[#64748b] mt-1 leading-relaxed">
              Official mid-term evaluations and end-semester registration schedules active under AY {activeAcademicYear || '2026–2027'}.
            </p>
          </div>
        </div>
      </div>

      {/* Two-Column Detail Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Recent Attendance History */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarCheck className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Recent Attendance Record</h2>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('attendance')}
              className="text-xs"
            >
              Full Attendance Log
            </Button>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {attendance.length === 0 ? (
              <div className="p-8 text-center text-[#64748b]">
                <CalendarCheck className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
                <p className="text-xs">No attendance sessions recorded for this term yet.</p>
              </div>
            ) : (
              attendance.slice(0, 5).map((att, idx) => (
                <div key={att.id || idx} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-md bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-mono font-bold text-[#475569]">
                      {att.date ? att.date.split('-')[2] : '—'}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-[#1e293b]">{att.date}</p>
                      <p className="text-[11px] text-[#64748b]">
                        {att.courseCode || att.course_code || att.className} • Section {att.sectionName || student.section}
                      </p>
                    </div>
                  </div>
                  <Badge
                    variant={
                      isPresent(att.status)
                        ? 'emerald'
                        : isLate(att.status)
                        ? 'amber'
                        : 'rose'
                    }
                    size="sm"
                  >
                    {att.status}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Upcoming Examination Schedule & Hall Tickets */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-700" />
              <h2 className="text-sm font-bold text-[#1e293b]">Upcoming Exam Timetable</h2>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('examinations')}
              className="text-xs"
            >
              View All Schedules
            </Button>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {schedules.length === 0 ? (
              <div className="p-8 text-center text-[#64748b]">
                <Clock className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
                <p className="text-xs">No examination schedules announced for this cohort yet.</p>
              </div>
            ) : (
              schedules.slice(0, 5).map((sch, idx) => (
                <div key={sch.id || idx} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <p className="text-xs font-bold text-[#1e293b]">{sch.subjectName}</p>
                    <p className="text-[11px] text-[#64748b] mt-0.5">
                      {sch.examDate} • {sch.startTime} - {sch.endTime}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-mono font-semibold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                      {sch.roomVenue || 'Examination Complex'}
                    </span>
                    <span className="block text-[10px] text-[#64748b] mt-0.5">
                      Max: {sch.maxMarks} Marks
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Receipts Section */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-700" />
            <h2 className="text-sm font-bold text-[#1e293b]">Official Fee Receipts</h2>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => onNavigateTab('receipts')}
            className="text-xs"
          >
            All Receipts ({receipts.length})
          </Button>
        </div>

        <div className="p-4 sm:p-5">
          {receipts.length === 0 ? (
            <div className="p-6 text-center text-[#64748b]">
              <Receipt className="w-8 h-8 mx-auto text-[#cbd5e1] mb-2" />
              <p className="text-xs">No fee receipts on record yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {receipts.slice(0, 3).map((rec) => (
                <div
                  key={rec.receiptNumber}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1e293b] font-mono">
                      {rec.receiptNumber}
                    </span>
                    <Badge variant="emerald" size="sm">
                      Paid
                    </Badge>
                  </div>
                  <p className="text-xs text-[#64748b]">{rec.feeTypeName}</p>
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-200">
                    <span className="text-[#64748b]">{rec.receiptDate}</span>
                    <span className="font-bold text-[#1e293b]">${rec.amountPaid.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
