import React from 'react';
import {
  User,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  ShieldCheck,
  Building,
  Heart,
  Users,
  CheckCircle2,
  Home,
  UserCheck,
} from 'lucide-react';
import { Student, ProctorAssignment } from '../../types/studentPortalTypes';
import { AcademicSession } from '../../types/academic';
import { StudentHostelDetails } from '../../types/database';
import { Badge } from '../ui/Badge';

interface ParentProfileViewProps {
  student: Student;
  currentSession: AcademicSession | null;
  proctor?: ProctorAssignment | null;
  hostelDetails?: StudentHostelDetails | null;
}

export function ParentProfileView({
  student,
  currentSession,
  proctor,
  hostelDetails,
}: ParentProfileViewProps) {
  // Extract department from program if not set
  const departmentName =
    student.admissionClass?.includes('Computer') || student.program?.includes('Computer')
      ? 'Department of Computer Science & Engineering'
      : student.admissionClass?.includes('Electronics') || student.program?.includes('Electronics')
      ? 'Department of Electronics & Communication Engineering'
      : student.admissionClass?.includes('Mechanical') || student.program?.includes('Mechanical')
      ? 'Department of Mechanical Engineering'
      : 'Department of Electrical & Electronic Engineering';

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-2xl font-bold shrink-0 shadow-xs">
              <User className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">{student.fullName}</h1>
                <Badge variant="blue" size="sm">
                  {student.program || student.admissionClass} - Section {student.section}
                </Badge>
                <Badge variant={student.accountStatus === 'active' ? 'emerald' : 'rose'} size="sm">
                  {student.accountStatus === 'active' ? 'Active Student' : 'Inactive'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] font-mono mt-1">
                EIT Registration No: <strong className="text-[#1e3a8a]">{student.registrationNumber || 'Pending Official Allotment'}</strong> • Session:{' '}
                {currentSession?.name || '2026–2027'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Academic & Institutional Details */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">University Enrollment Details</h2>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Department</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block truncate" title={departmentName}>
                {departmentName}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Academic Programme</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.program || student.admissionClass}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Current Semester &amp; Section</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.currentSemester || 'Semester 3'} &bull; Section {student.section}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Batch &amp; Admission Year</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.batch || '2026–2030'} ({student.admissionDate ? student.admissionDate.split('-')[0] : '2026'})
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Academic Session</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {currentSession?.name || '2026–2027'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Official Academic Status</span>
              <span className="font-semibold text-emerald-700 mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Officially Enrolled &amp; In Good Standing
              </span>
            </div>
          </div>
        </div>

        {/* Section 2: Personal Information */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <User className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Student Personal Details</h2>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Date of Birth</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.dateOfBirth}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Gender</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.gender}</span>
            </div>
            <div>
              <span className="text-[#64748b] block">Institutional Email</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block truncate" title={student.email}>
                {student.email || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Primary Mobile</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.mobile || '—'}</span>
            </div>
          </div>
        </div>

        {/* Section 3: Proctor & Faculty Mentorship (Stage D) */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <UserCheck className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Assigned Proctor &amp; Faculty Advisor</h2>
          </div>

          {proctor ? (
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[#64748b] block">Proctor Name</span>
                  <span className="font-bold text-[#1e293b] text-sm mt-0.5 block">{proctor.facultyName}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Department</span>
                  <span className="font-semibold text-[#1e293b] mt-0.5 block">{proctor.facultyDepartment}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Official Email</span>
                  <span className="font-mono text-[#1e3a8a] mt-0.5 block truncate">{proctor.facultyEmail}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Contact Phone</span>
                  <span className="font-mono text-[#1e293b] mt-0.5 block">{proctor.facultyPhone || '+91 94440 12345'}</span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-blue-50/70 border border-blue-200/60 text-[11px] text-[#1e3a8a]">
                Proctor acts as primary institutional mentor for academic counsel and student welfare.
              </div>
            </div>
          ) : (
            <p className="text-xs text-[#64748b]">Proctor assignment in progress by Academic Office.</p>
          )}
        </div>

        {/* Section 4: Residential Hostel Accommodation (Stage D) */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <Home className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Campus Residence &amp; Hostel Details</h2>
          </div>

          {hostelDetails && hostelDetails.currentAllocation ? (
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[#64748b] block">Hostel Block</span>
                  <span className="font-bold text-[#1e293b] text-sm mt-0.5 block">
                    {hostelDetails.currentAllocation.hostel_block_name}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Room &amp; Bed</span>
                  <span className="font-mono font-bold text-[#1e3a8a] mt-0.5 block">
                    Room {hostelDetails.currentAllocation.room_number} &bull; Bed {hostelDetails.currentAllocation.bed_identifier}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Check-in Status</span>
                  <span className="font-semibold text-emerald-700 mt-0.5 block">
                    {hostelDetails.currentAllocation.status}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Check-in Date</span>
                  <span className="font-mono text-[#64748b] mt-0.5 block">
                    {hostelDetails.currentAllocation.check_in_date ? hostelDetails.currentAllocation.check_in_date.split('T')[0] : '2026-08-01'}
                  </span>
                </div>
              </div>
              <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200/60 text-[11px] text-emerald-800">
                Official residency registered under Hostel Administration governance.
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-[#64748b] text-center">
              <p className="font-semibold text-[#1e293b]">Day Scholar</p>
              <p className="text-[11px] mt-0.5">Student commutes daily; off-campus residential address applies.</p>
            </div>
          )}
        </div>

        {/* Section 5: Guardian & Family Contacts */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4 md:col-span-2">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <Users className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Guardian &amp; Family Information on Official Record</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-[#64748b] block">Father / Guardian Name</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.fatherName || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Emergency Phone</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.emergencyContact || student.fatherPhone || '—'}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block">Authorized Guardian Profile</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.guardianName || student.fatherName || '—'}
              </span>
            </div>
            <div className="sm:col-span-3">
              <span className="text-[#64748b] block">Official Residential Address</span>
              <span className="font-semibold text-[#1e293b] mt-0.5 block">
                {student.presentAddress || student.permanentAddress || '—'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
