import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Users,
  LayoutDashboard,
  User,
  BookOpen,
  CalendarCheck,
  DollarSign,
  Receipt,
  Award,
  FileText,
  LogOut,
  Menu,
  X,
  ShieldCheck,
  GraduationCap,
  Clock,
  Calendar,
  LifeBuoy,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student, ProctorAssignment, HallTicket } from '../../types/studentPortalTypes';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  AttendanceRecord,
  FacultyAssignment,
} from '../../types/academic';
import { FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import {
  Examination,
  ExamSubjectSchedule,
  StudentExamResult,
} from '../../types/examination';
import { StudentHostelDetails } from '../../types/database';
import { parentService, LinkedWardEntry } from '../../services/parentService';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

import { ParentOverview } from './ParentOverview';
import { ParentProfileView } from './ParentProfileView';
import { ParentAcademicsView } from './ParentAcademicsView';
import { ParentAttendanceView } from './ParentAttendanceView';
import { ParentFeesView } from './ParentFeesView';
import { ParentReceiptsView } from './ParentReceiptsView';
import { ParentExaminationsView } from './ParentExaminationsView';
import { ParentHallTicketsView } from './ParentHallTicketsView';
import { ParentResultsView } from './ParentResultsView';
import { ParentChildSelector } from './ParentChildSelector';

import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { ReceiptPreviewModal } from '../student/modals/ReceiptPreviewModal';
import { HallTicketPrintModal } from '../student/modals/HallTicketPrintModal';
import { ResultTranscriptModal } from '../student/modals/ResultTranscriptModal';
import { NewTicketModal } from '../it/modals/NewTicketModal';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ParentWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export type ParentTab =
  | 'overview'
  | 'profile'
  | 'academics'
  | 'attendance'
  | 'fees'
  | 'receipts'
  | 'examinations'
  | 'hall-tickets'
  | 'results';

export const PARENT_NAV_ITEMS = [
  { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'profile', label: 'Student Profile', icon: User },
  { id: 'academics', label: 'Academics & Courses', icon: BookOpen },
  { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
  { id: 'fees', label: 'Fee Statement', icon: DollarSign },
  { id: 'receipts', label: 'Payment Receipts', icon: Receipt },
  { id: 'examinations', label: 'Exam Timetable', icon: Clock },
  { id: 'hall-tickets', label: 'Hall Tickets', icon: Award },
  { id: 'results', label: 'Report Cards', icon: FileText },
] as const;

export function ParentWorkspace({ user, onLogout }: ParentWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<ParentTab>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Authoritative Central Academic Year
  const { activeAcademicYear } = useActiveAcademicYear();

  // Authenticated Parent's Linked Wards & Active Selection
  const [linkedWardEntries, setLinkedWardEntries] = useState<LinkedWardEntry[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // Academic Reference Collections
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyAssignment[]>([]);

  // Raw Database Collections
  const [allAttendanceRecords, setAllAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [allFeeAssignments, setAllFeeAssignments] = useState<FeeAssignment[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRecord[]>([]);
  const [allReceipts, setAllReceipts] = useState<FeeReceipt[]>([]);
  const [allExaminations, setAllExaminations] = useState<Examination[]>([]);
  const [allSchedules, setAllSchedules] = useState<ExamSubjectSchedule[]>([]);
  const [allHallTickets, setAllHallTickets] = useState<HallTicket[]>([]);
  const [allResults, setAllResults] = useState<StudentExamResult[]>([]);

  // Stage D Additional University State
  const [wardProctor, setWardProctor] = useState<ProctorAssignment | null>(null);
  const [wardHostelDetails, setWardHostelDetails] = useState<StudentHostelDetails | null>(null);

  // Modals State
  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceipt | null>(null);
  const [selectedHallTicket, setSelectedHallTicket] = useState<HallTicket | null>(null);
  const [selectedResult, setSelectedResult] = useState<StudentExamResult | null>(null);
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);

  // Load parent student links and authoritative domain datasets
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      // 1. Resolve linked students strictly for this authenticated parent
      const wardEntries = await parentService.getLinkedWards(user);
      setLinkedWardEntries(wardEntries);

      const initialStudent = wardEntries[0]?.student || null;
      setSelectedStudent(initialStudent);

      // 2. Fetch domain datasets in parallel
      const datasets = await parentService.getDomainDatasets();

      setSessions(datasets.sessions);
      setClasses(datasets.classes);
      setSections(datasets.sections);
      setSubjects(datasets.subjects);
      setFacultyAssignments(datasets.facultyAssignments);
      setAllAttendanceRecords(datasets.attendance as any);
      setAllFeeAssignments(datasets.feeAssignments);
      setAllPayments(datasets.payments as any);
      setAllReceipts(datasets.receipts);
      setAllExaminations(datasets.examinations);
      setAllSchedules(datasets.schedules);
      setAllHallTickets(datasets.hallTickets);
      setAllResults(datasets.results);
    } catch (err) {
      console.error('Failed to load parent portal data', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Load student-specific Proctor & Hostel details when active student changes
  useEffect(() => {
    let isCancelled = false;
    const loadStudentSpecificDetails = async () => {
      if (!selectedStudent) {
        setWardProctor(null);
        setWardHostelDetails(null);
        return;
      }

      try {
        const [proc, hst] = await Promise.all([
          parentService.getProctorForStudent(selectedStudent.registrationNumber),
          parentService.getHostelDetailsForWard(selectedStudent.id, user),
        ]);

        if (!isCancelled) {
          setWardProctor(proc);
          setWardHostelDetails(hst);
        }
      } catch (err) {
        console.error('Failed to load ward specific details', err);
      }
    };

    loadStudentSpecificDetails();

    return () => {
      isCancelled = true;
    };
  }, [selectedStudent, user]);

  // Student Switching handler that immediately clears previous student data
  const handleSelectStudent = (newStudent: Student) => {
    if (!newStudent || newStudent.id === selectedStudent?.id) return;

    // STAGE B: Clear previous student data during switching to prevent accidental data leakage
    setWardProctor(null);
    setWardHostelDetails(null);
    setSelectedReceipt(null);
    setSelectedHallTicket(null);
    setSelectedResult(null);

    // Switch to new student
    setSelectedStudent(newStudent);
  };

  // Find permissions for currently selected ward
  const currentWardEntry = useMemo(() => {
    if (!selectedStudent) return null;
    return (
      linkedWardEntries.find((w) => w.student.id === selectedStudent.id) ||
      linkedWardEntries[0] ||
      null
    );
  }, [selectedStudent, linkedWardEntries]);

  const permissions = currentWardEntry?.permissions || {
    can_view_grades: true,
    can_view_attendance: true,
    can_view_finance: true,
  };

  // Derived filtered data for the currently selected student
  const studentRegNorm = (selectedStudent?.registrationNumber || '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .toLowerCase();

  const studentAttendance = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_attendance) return [];
    return allAttendanceRecords.filter((a) => {
      const aReg = ((a as any).registrationNumber || (a as any).registration_number || '')
        .replace(/[^a-zA-Z0-9]/g, '')
        .toLowerCase();
      return (
        aReg === studentRegNorm ||
        (a as any).registrationNumber === selectedStudent.registrationNumber ||
        (a as any).studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allAttendanceRecords, studentRegNorm, permissions.can_view_attendance]);

  const studentFees = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_finance) return [];
    return allFeeAssignments.filter((f) => {
      const fReg = (f.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return (
        fReg === studentRegNorm ||
        f.studentRegistrationNumber === selectedStudent.registrationNumber ||
        (f as any).studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allFeeAssignments, studentRegNorm, permissions.can_view_finance]);

  const studentPayments = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_finance) return [];
    return allPayments.filter((p) => {
      const pReg = (p.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return (
        pReg === studentRegNorm ||
        p.studentRegistrationNumber === selectedStudent.registrationNumber ||
        (p as any).studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allPayments, studentRegNorm, permissions.can_view_finance]);

  const studentReceipts = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_finance) return [];
    return allReceipts.filter((r) => {
      const rReg = (r.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return (
        rReg === studentRegNorm ||
        r.studentRegistrationNumber === selectedStudent.registrationNumber ||
        (r as any).studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allReceipts, studentRegNorm, permissions.can_view_finance]);

  const studentHallTickets = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_grades) return [];
    return allHallTickets.filter((ht) => {
      const htReg = (ht.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return (
        htReg === studentRegNorm ||
        ht.studentRegistrationNumber === selectedStudent.registrationNumber ||
        (ht as any).studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allHallTickets, studentRegNorm, permissions.can_view_grades]);

  const studentResults = useMemo(() => {
    if (!selectedStudent || !permissions.can_view_grades) return [];
    return allResults.filter((res) => {
      const resReg = (res.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return (
        resReg === studentRegNorm ||
        res.studentRegistrationNumber === selectedStudent.registrationNumber ||
        res.studentId === selectedStudent.id
      );
    });
  }, [selectedStudent, allResults, studentRegNorm, permissions.can_view_grades]);

  const currentSession = sessions.find((s) => s.isCurrent) || sessions[0] || null;

  // Exactly nine primary navigation destinations
  const navigationItems = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'profile', label: 'Student Profile', icon: User },
    { id: 'academics', label: 'Academics & Courses', icon: BookOpen },
    { id: 'attendance', label: 'Attendance', icon: CalendarCheck, count: studentAttendance.length },
    { id: 'fees', label: 'Fee Statement', icon: DollarSign },
    { id: 'receipts', label: 'Payment Receipts', icon: Receipt, count: studentReceipts.length },
    { id: 'examinations', label: 'Exam Timetable', icon: Clock, count: allExaminations.length },
    { id: 'hall-tickets', label: 'Hall Tickets', icon: Award, count: studentHallTickets.length },
    { id: 'results', label: 'Report Cards', icon: FileText, count: studentResults.length },
  ];

  // Grouped Sidebar Items for single-expansion accordion (STAGE A)
  const sidebarItems: PortalSidebarItem[] = useMemo(() => [
    {
      id: 'overview',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'profile',
      label: 'Student Profile',
      icon: User,
    },
    {
      id: 'academics-group',
      label: 'Academics & Attendance',
      icon: BookOpen,
      subItems: [
        { id: 'academics', label: 'Academics & Courses' },
        {
          id: 'attendance',
          label: 'Attendance',
          badge: studentAttendance.length || undefined,
          badgeVariant: 'emerald',
        },
      ],
    },
    {
      id: 'finance-group',
      label: 'Fees & Receipts',
      icon: DollarSign,
      subItems: [
        { id: 'fees', label: 'Fee Statement' },
        {
          id: 'receipts',
          label: 'Payment Receipts',
          badge: studentReceipts.length || undefined,
          badgeVariant: 'blue',
        },
      ],
    },
    {
      id: 'examinations-group',
      label: 'Examinations & Results',
      icon: Award,
      subItems: [
        {
          id: 'examinations',
          label: 'Exam Timetable',
          badge: allExaminations.length || undefined,
          badgeVariant: 'amber',
        },
        {
          id: 'hall-tickets',
          label: 'Hall Tickets',
          badge: studentHallTickets.length || undefined,
          badgeVariant: 'blue',
        },
        {
          id: 'results',
          label: 'Report Cards',
          badge: studentResults.length || undefined,
          badgeVariant: 'emerald',
        },
      ],
    },
  ], [
    studentAttendance.length,
    studentReceipts.length,
    allExaminations.length,
    studentHallTickets.length,
    studentResults.length,
  ]);

  const allLinkedStudents = useMemo(
    () => linkedWardEntries.map((w) => w.student),
    [linkedWardEntries]
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-md animate-pulse">
          <Users className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold text-[#1e293b] mt-4">Loading Parent Portal...</p>
        <p className="text-xs text-[#64748b] mt-1">Retrieving family records and student profiles</p>
      </div>
    );
  }

  // Handle case with no linked students
  if (!selectedStudent || linkedWardEntries.length === 0) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center mb-4">
          <Users className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-[#1e293b]">No Linked Student Account Found</h2>
        <p className="text-xs text-[#64748b] max-w-md mt-2 leading-relaxed">
          There are currently no active student enrollments linked to your parent credentials ({user.email || user.username || user.name}).
          Please contact the Admissions &amp; Records Office to link your child's student record.
        </p>
        <div className="mt-6 flex items-center gap-3">
          <Button variant="outline" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-1.5" />
            <span>Sign Out</span>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Top Application Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Brand & Portal Badge */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                    Parent Portal
                  </span>
                  <span className="hidden sm:inline-block text-[11px] font-semibold text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded border border-[#bfdbfe]">
                    Guardian Gateway
                  </span>
                </div>
                <span className="text-[11px] text-[#64748b] font-medium hidden md:inline">
                  Student Progress, Attendance &amp; Official Transcripts
                </span>
              </div>
            </div>

            {/* Right: Parent Profile, Academic Year, & Logout */}
            <div className="flex items-center gap-3">
              {/* Central Academic Year Badge (STAGE E) */}
              <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>AY {activeAcademicYear || '2026–2027'}</span>
              </div>

              <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-[#e2e8f0]">
                <div className="w-7 h-7 rounded-full bg-[#f1f5f9] border border-[#e2e8f0] flex items-center justify-center text-[#1e293b]">
                  <User className="w-3.5 h-3.5" />
                </div>
                <div className="text-left leading-none">
                  <p className="text-[13px] font-semibold text-[#1e293b]">{user.name || user.displayName}</p>
                  <p className="text-[11px] text-[#64748b] font-mono mt-0.5">{user.username || 'Guardian'}</p>
                </div>
              </div>

              <Badge variant="blue" size="sm" className="hidden md:inline-flex capitalize">
                Parent / Guardian
              </Badge>

              <Button
                id="btn-parent-it-support"
                variant="outline"
                size="sm"
                onClick={() => setIsTicketModalOpen(true)}
                className="gap-1.5 text-xs text-cyan-700 border-cyan-200 hover:bg-cyan-50 cursor-pointer"
              >
                <LifeBuoy className="w-3.5 h-3.5 text-cyan-600" />
                <span className="hidden sm:inline">IT Support</span>
              </Button>

              <Button
                id="btn-parent-logout"
                variant="outline"
                size="sm"
                onClick={onLogout}
                className="gap-1.5 text-xs text-[#64748b] hover:text-[#1e293b]"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </Button>

              {/* Mobile Menu Toggle */}
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-lg text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-[#e2e8f0] bg-white px-4 pt-2 pb-4 space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`btn-parent-tab-${item.id}`}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id as ParentTab);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold ${
                    isActive
                      ? 'bg-[#1e3a8a] text-white'
                      : 'text-[#475569] hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && item.count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        isActive ? 'bg-blue-800 text-white' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* Main Workspace Layout */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {/* Left Navigation Sidebar */}
          <aside className="hidden md:block md:col-span-1 lg:col-span-1 space-y-4">
            {/* Child Selector Card in Sidebar (STAGE B) */}
            <ParentChildSelector
              students={allLinkedStudents}
              selectedStudent={selectedStudent}
              onSelectStudent={handleSelectStudent}
            />

            {/* Navigation Tabs with Single-Expansion Accordion (STAGE A) */}
            <PortalSidebar
              items={sidebarItems}
              activeTab={activeTab}
              onSelectTab={(id) => setActiveTab(id as ParentTab)}
              idPrefix="btn-parent-tab"
            />

            {/* Institutional Security Notice */}
            <div className="bg-[#eff6ff]/70 border border-[#bfdbfe]/60 rounded-xl p-3.5 text-xs text-[#1e3a8a] space-y-1">
              <div className="flex items-center gap-1.5 font-bold">
                <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
                <span>Verified Read-Only Access</span>
              </div>
              <p className="text-[11px] text-[#475569] leading-relaxed">
                Parent access provides authoritative real-time academic, attendance, and bursar tracking for officially registered dependents.
              </p>
            </div>
          </aside>

          {/* Right Main Content Area */}
          <main className="md:col-span-3 lg:col-span-4">
            {activeTab === 'overview' && (
              <ParentOverview
                parentUser={user}
                student={selectedStudent}
                allLinkedStudents={allLinkedStudents}
                currentSession={currentSession}
                attendance={studentAttendance}
                feeAssignments={studentFees}
                receipts={studentReceipts}
                examinations={allExaminations}
                schedules={allSchedules}
                hallTickets={studentHallTickets}
                results={studentResults}
                proctor={wardProctor}
                hostelDetails={wardHostelDetails}
                permissions={permissions}
                onNavigateTab={(tab) => setActiveTab(tab)}
                onSelectStudent={handleSelectStudent}
              />
            )}

            {activeTab === 'profile' && (
              <ParentProfileView
                student={selectedStudent}
                currentSession={currentSession}
                proctor={wardProctor}
                hostelDetails={wardHostelDetails}
              />
            )}

            {activeTab === 'academics' && (
              <ParentAcademicsView
                student={selectedStudent}
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                subjects={subjects}
                facultyAssignments={facultyAssignments}
                canViewGrades={permissions.can_view_grades}
              />
            )}

            {activeTab === 'attendance' && (
              <ParentAttendanceView
                student={selectedStudent}
                attendanceRecords={studentAttendance}
                canViewAttendance={permissions.can_view_attendance}
              />
            )}

            {activeTab === 'fees' && (
              <ParentFeesView
                student={selectedStudent}
                feeAssignments={studentFees}
                payments={studentPayments}
                onViewReceipts={() => setActiveTab('receipts')}
                canViewFinance={permissions.can_view_finance}
              />
            )}

            {activeTab === 'receipts' && (
              <ParentReceiptsView
                student={selectedStudent}
                receipts={studentReceipts}
                onViewReceipt={(receipt) => setSelectedReceipt(receipt)}
                canViewFinance={permissions.can_view_finance}
              />
            )}

            {activeTab === 'examinations' && (
              <ParentExaminationsView
                student={selectedStudent}
                examinations={allExaminations}
                schedules={allSchedules}
                canViewGrades={permissions.can_view_grades}
              />
            )}

            {activeTab === 'hall-tickets' && (
              <ParentHallTicketsView
                student={selectedStudent}
                hallTickets={studentHallTickets}
                onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
                canViewGrades={permissions.can_view_grades}
              />
            )}

            {activeTab === 'results' && (
              <ParentResultsView
                student={selectedStudent}
                examinations={allExaminations}
                results={studentResults}
                onViewTranscript={(res) => setSelectedResult(res)}
                canViewGrades={permissions.can_view_grades}
              />
            )}
          </main>
        </div>
      </div>

      {/* Modals for Read-Only Inspection and Printing */}
      <ReceiptPreviewModal
        isOpen={Boolean(selectedReceipt)}
        onClose={() => setSelectedReceipt(null)}
        receipt={selectedReceipt}
      />

      <HallTicketPrintModal
        isOpen={Boolean(selectedHallTicket)}
        onClose={() => setSelectedHallTicket(null)}
        hallTicket={selectedHallTicket}
      />

      <ResultTranscriptModal
        isOpen={Boolean(selectedResult)}
        onClose={() => setSelectedResult(null)}
        result={selectedResult}
      />

      <NewTicketModal
        isOpen={isTicketModalOpen}
        onClose={() => setIsTicketModalOpen(false)}
        requesterId={user.id || 'parent-user'}
        requesterName={user.name || user.displayName || 'Parent/Guardian'}
        requesterAccountType="PARENT"
        requesterEmail={user.email || 'parent@guardian.com'}
        onTicketCreated={() => {
          setIsTicketModalOpen(false);
        }}
      />
    </div>
  );
}
