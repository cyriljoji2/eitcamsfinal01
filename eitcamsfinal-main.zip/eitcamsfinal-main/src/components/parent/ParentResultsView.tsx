import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Award,
  TrendingUp,
  Lock,
} from 'lucide-react';
import { Student } from '../../types/studentPortalTypes';
import { Examination, StudentExamResult } from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface ParentResultsViewProps {
  student: Student;
  examinations: Examination[];
  results: StudentExamResult[];
  onViewTranscript: (result: StudentExamResult) => void;
  canViewGrades?: boolean;
}

export function ParentResultsView({
  student,
  examinations,
  results,
  onViewTranscript,
  canViewGrades = true,
}: ParentResultsViewProps) {
  if (!canViewGrades) {
    return (
      <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-[#1e293b]">Examination Results Restricted</h3>
        <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
          Student has restricted formal grade and examination report disclosures for this guardian profile.
        </p>
      </div>
    );
  }

  // CRITICAL: Filter strictly for COE-PUBLISHED results
  const publishedResults = results.filter((res) => {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
    );
    // Allow if parent exam is Published OR result record verificationStatus is explicitly Published
    return (
      parentExam?.status === 'Published' ||
      (parentExam as any)?.session_status === 'RESULTS_PUBLISHED' ||
      res.verificationStatus === 'Published' ||
      (res as any).result_status === 'PASS' ||
      (res as any).status === 'PUBLISHED'
    );
  });

  const [selectedResultId, setSelectedResultId] = useState<string>(
    publishedResults[0]?.id || ''
  );

  const activeResult =
    publishedResults.find((r) => r.id === selectedResultId) || publishedResults[0] || null;

  return (
    <div className="space-y-6">
      {/* Results Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <FileText className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">University Academic Reports &amp; Transcripts</h1>
                <Badge variant="emerald" size="sm">
                  {publishedResults.length} Published Semester Reports
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Controller of Examinations (COE) certified results for {student.fullName} ({student.registrationNumber})
              </p>
            </div>
          </div>

          {activeResult && (
            <Button
              id="btn-print-official-transcript"
              size="sm"
              variant="outline"
              onClick={() => onViewTranscript(activeResult)}
              className="gap-1.5 text-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Transcript</span>
            </Button>
          )}
        </div>
      </div>

      {publishedResults.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-[#e2e8f0] shadow-xs text-[#64748b]">
          <FileText className="w-12 h-12 mx-auto text-[#cbd5e1] mb-3" />
          <h3 className="text-base font-bold text-[#1e293b]">No Published Results Available</h3>
          <p className="text-xs mt-1 max-w-md mx-auto">
            Examination marksheets are currently being audited or awaiting formal declaration by the Controller of Examinations (COE).
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Term Selector (if multiple terms published) */}
          {publishedResults.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {publishedResults.map((res) => {
                const isSelected = activeResult?.id === res.id;
                return (
                  <button
                    key={res.id}
                    id={`btn-result-tab-${res.id}`}
                    type="button"
                    onClick={() => setSelectedResultId(res.id)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-[#1e3a8a] text-white shadow-xs'
                        : 'bg-white text-[#475569] border border-[#e2e8f0] hover:bg-slate-50'
                    }`}
                  >
                    <span>{res.examinationName}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-blue-800 text-blue-100' : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {res.percentage}%
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {activeResult && (
            <div className="space-y-6">
              {/* Performance Summary Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {/* Metric 1: Aggregate Score */}
                <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
                  <span className="text-xs text-[#64748b] font-medium block">Aggregate Score</span>
                  <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
                    {activeResult.totalMarksObtained} / {activeResult.totalMaxMarks}
                  </span>
                  <span className="text-[11px] text-[#64748b]">Total subject points</span>
                </div>

                {/* Metric 2: Percentage */}
                <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#64748b] font-medium">Percentage / SGPA</span>
                    <TrendingUp className="w-4 h-4 text-[#1e3a8a]" />
                  </div>
                  <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
                    {activeResult.percentage}%
                  </span>
                  <span className="text-[11px] text-emerald-700 font-semibold">
                    Grade {activeResult.overallGrade} &bull; SGPA {(activeResult.percentage / 10).toFixed(2)}
                  </span>
                </div>

                {/* Metric 3: Standing */}
                <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
                  <span className="text-xs text-[#64748b] font-medium block">Academic Standing</span>
                  <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
                    {activeResult.classRank ? `#${activeResult.classRank}` : 'Dean’s List'}
                  </span>
                  <span className="text-[11px] text-[#64748b]">University cohort distinction</span>
                </div>

                {/* Metric 4: Result Status */}
                <div className="bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#64748b] font-medium">Evaluation Outcome</span>
                    <Award className="w-4 h-4 text-amber-600" />
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-2xl font-bold text-emerald-700">
                      {activeResult.resultStatus}
                    </span>
                    <Badge variant={activeResult.resultStatus === 'Pass' ? 'emerald' : 'rose'} size="sm">
                      {activeResult.overallGrade}
                    </Badge>
                  </div>
                  <span className="text-[11px] text-[#64748b]">
                    Status: {activeResult.verificationStatus || 'Certified'}
                  </span>
                </div>
              </div>

              {/* Subject-Wise Marksheet Table */}
              <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
                <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between">
                  <div>
                    <h2 className="text-sm font-bold text-[#1e293b]">Subject-Wise Marksheet &amp; Letter Grades</h2>
                    <p className="text-xs text-[#64748b] mt-0.5">
                      {activeResult.examinationName} • Certified Release:{' '}
                      {activeResult.publishedAt || activeResult.calculatedAt || '2026-11-01'}
                    </p>
                  </div>
                  <Badge variant="emerald" size="sm">
                    Certified COE Transcript
                  </Badge>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                      <tr>
                        <th className="px-5 py-3.5">Course &amp; Code</th>
                        <th className="px-5 py-3.5 text-right">Marks Obtained</th>
                        <th className="px-5 py-3.5 text-right">Max Marks</th>
                        <th className="px-5 py-3.5 text-right">Percentage</th>
                        <th className="px-5 py-3.5 text-center">Grade</th>
                        <th className="px-5 py-3.5 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#e2e8f0]">
                      {(activeResult.subjectMarks || []).map((sub, idx) => {
                        const pct =
                          sub.percentage !== undefined
                            ? sub.percentage
                            : Math.round(((sub.marksObtained || 0) / sub.maxMarks) * 100);
                        const isPass = sub.isPassed || pct >= 40;

                        return (
                          <tr key={idx} className="hover:bg-slate-50 transition-colors">
                            <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                              <div>{sub.subjectName}</div>
                              <div className="text-[11px] font-mono text-[#64748b]">{sub.subjectCode}</div>
                            </td>
                            <td className="px-5 py-3.5 text-right font-bold text-[#1e293b]">
                              {sub.marksObtained !== null ? sub.marksObtained : '—'}
                            </td>
                            <td className="px-5 py-3.5 text-right text-[#64748b]">{sub.maxMarks}</td>
                            <td className="px-5 py-3.5 text-right font-semibold text-[#1e293b]">
                              {pct}%
                            </td>
                            <td className="px-5 py-3.5 text-center font-bold text-[#1e3a8a]">
                              {sub.grade}
                            </td>
                            <td className="px-5 py-3.5 text-center">
                              <Badge variant={isPass ? 'emerald' : 'rose'} size="sm">
                                {isPass ? 'Pass' : 'Fail'}
                              </Badge>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot className="bg-[#f8fafc] font-bold text-[#1e293b] border-t border-[#e2e8f0]">
                      <tr>
                        <td className="px-5 py-3.5 uppercase tracking-wider text-xs">Total Aggregate</td>
                        <td className="px-5 py-3.5 text-right font-bold text-sm">
                          {activeResult.totalMarksObtained}
                        </td>
                        <td className="px-5 py-3.5 text-right text-xs text-[#64748b]">
                          {activeResult.totalMaxMarks}
                        </td>
                        <td className="px-5 py-3.5 text-right font-bold text-sm">
                          {activeResult.percentage}%
                        </td>
                        <td className="px-5 py-3.5 text-center font-bold text-sm text-[#1e3a8a]">
                          {activeResult.overallGrade}
                        </td>
                        <td className="px-5 py-3.5 text-center">
                          <Badge
                            variant={activeResult.resultStatus === 'Pass' ? 'emerald' : 'rose'}
                            size="sm"
                          >
                            {activeResult.resultStatus}
                          </Badge>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
