import React, { useState, useEffect, useRef } from 'react';
import {
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  AlertCircle,
  FileText,
  Clock,
  ShieldCheck,
  RefreshCw,
  Eye,
  Check,
  Filter,
} from 'lucide-react';
import { CsvImportPreviewReport, CsvImportValidationRow } from '../../../types/academic';
import { CsvImportBatchRecord } from '../../../types/database';
import { academicRepository, generateFfcsCsvTemplate } from '../../../services/academicService';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface CsvRegistrationImportSectionProps {
  actor: { userId: string; role: string; employeeId?: string };
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
  onRefresh: () => void;
}

export function CsvRegistrationImportSection({
  actor,
  onSuccess,
  onError,
  onRefresh,
}: CsvRegistrationImportSectionProps) {
  // Input file state
  const [fileName, setFileName] = useState<string>('');
  const [csvContent, setCsvContent] = useState<string>('');
  const [isValidating, setIsValidating] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Stage 1: Validation preview report
  const [previewReport, setPreviewReport] = useState<CsvImportPreviewReport | null>(null);

  // Stage 2: Approved row numbers
  const [approvedRowIndices, setApprovedRowIndices] = useState<number[]>([]);
  const [isCommitting, setIsCommitting] = useState(false);
  const [committedBatch, setCommittedBatch] = useState<CsvImportBatchRecord | null>(null);

  // Historical Import Batches
  const [importBatches, setImportBatches] = useState<CsvImportBatchRecord[]>([]);
  const [isLoadingBatches, setIsLoadingBatches] = useState(false);

  // Table filter inside preview
  const [previewFilter, setPreviewFilter] = useState<'ALL' | 'VALID' | 'INVALID'>('ALL');

  // Load audit history
  const loadImportBatches = async () => {
    setIsLoadingBatches(true);
    try {
      const batches = await academicRepository.getCsvImportBatches();
      setImportBatches(batches);
    } catch (err: any) {
      console.error('Failed to load CSV batches:', err);
    } finally {
      setIsLoadingBatches(false);
    }
  };

  useEffect(() => {
    loadImportBatches();
  }, []);

  // Download official CSV template
  const handleDownloadTemplate = () => {
    const templateContent = generateFfcsCsvTemplate();
    const blob = new Blob([templateContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'EIT_FFCS_Registration_Import_Template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onSuccess('Template downloaded (Schema: EIT-FFCS-REG-V1.0)');
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.csv') && !file.name.endsWith('.txt')) {
      onError('Please select a valid .csv file.');
      return;
    }

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCsvContent(content || '');
      setPreviewReport(null);
      setCommittedBatch(null);
    };
    reader.readAsText(file);
  };

  // Stage 1: Validate file
  const handleValidateCsv = async () => {
    if (!csvContent.trim()) {
      onError('Please upload a CSV file or paste CSV content first.');
      return;
    }

    setIsValidating(true);
    setPreviewReport(null);
    setCommittedBatch(null);

    try {
      const report = await academicRepository.validateCsvImport(csvContent, fileName || 'upload.csv');
      setPreviewReport(report);

      // Pre-select all valid rows for convenience
      const validIndices = report.rows.filter((r) => r.is_valid || r.status === 'VALID').map((r) => r.row_index);
      setApprovedRowIndices(validIndices);

      if (report.is_valid) {
        onSuccess(`Validation complete: All ${report.valid_rows_count} rows passed validation.`);
      } else {
        onError(`Validation completed with errors: ${report.invalid_rows_count} rejected row(s).`);
      }
    } catch (err: any) {
      onError(err?.message || 'Failed to parse and validate CSV file.');
    } finally {
      setIsValidating(false);
    }
  };

  // Download Rejected Rows
  const handleDownloadRejectedRows = () => {
    if (!previewReport || previewReport.invalid_rows_count === 0) return;

    const rejectedRows = previewReport.rows.filter((r) => !r.is_valid && r.status !== 'VALID');
    const header = 'row_number,registration_number,student_name,course_code,academic_year,semester,errors\n';
    const csvData = rejectedRows
      .map(
        (r) =>
          `${r.row_index + 1},"${r.registration_number}","${r.student_name || ''}","${r.course_code}","${r.academic_year}","${r.semester}","${(r.errors || r.reasons || []).join('; ')}"`
      )
      .join('\n');

    const blob = new Blob([header + csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Rejected_Rows_${fileName || 'import'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onSuccess('Rejected rows downloaded with error reasons.');
  };

  // Stage 2: Confirm & Commit Import
  const handleCommitImport = async () => {
    if (!previewReport) return;
    if (approvedRowIndices.length === 0) {
      onError('Please approve at least one valid row for enrolment.');
      return;
    }

    setIsCommitting(true);
    try {
      const batchRecord = await academicRepository.commitCsvImport(
        {
          fileName: fileName || 'import.csv',
          approvedRows: approvedRowIndices,
          csvContent,
        },
        actor
      );

      setCommittedBatch(batchRecord);
      onSuccess(
        `Import committed: Batch ${batchRecord.batch_id} created with ${batchRecord.successful_enrolments} successful enrolments.`
      );
      await loadImportBatches();
      onRefresh();
    } catch (err: any) {
      onError(err?.message || 'Commit failed during bulk import.');
    } finally {
      setIsCommitting(false);
    }
  };

  // Filter rows shown in validation table
  const displayedRows = (previewReport?.rows || []).filter((r) => {
    if (previewFilter === 'VALID') return r.is_valid;
    if (previewFilter === 'INVALID') return !r.is_valid;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Contract & Upload Section */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-[#1e3a8a]" />
              <h3 className="text-base font-bold text-[#1e293b]">
                FFCS Course Registration CSV Import
              </h3>
              <Badge variant="blue">Contract: EIT-FFCS-REG-V1.0</Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Import registered student courses from external registrations with authoritative identity verification.
            </p>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadTemplate}
            leftIcon={<Download className="w-4 h-4" />}
          >
            Download CSV Template
          </Button>
        </div>

        {/* Contract Specification Callout */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1 text-slate-600">
          <div className="font-semibold text-slate-800 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
            Authoritative Import Rules & Field Contract
          </div>
          <p>
            Primary identity keys: <code className="bg-white px-1.5 py-0.5 border border-slate-200 rounded text-slate-800 font-mono">registration_number</code> and <code className="bg-white px-1.5 py-0.5 border border-slate-200 rounded text-slate-800 font-mono">course_code</code>.
            Names and descriptions in the CSV are verification fields only and are never trusted as identity records.
          </p>
          <div className="text-[11px] text-slate-500 pt-1">
            Supported columns: registration_number, student_name, academic_year, semester, programme_code, batch, section_code, course_code, course_name, preference_rank, registration_status.
          </div>
        </div>

        {/* Dropzone / File Picker */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv,.txt"
              className="hidden"
            />
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              leftIcon={<Upload className="w-4 h-4" />}
            >
              Choose CSV File
            </Button>
            {fileName && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-lg text-xs font-medium text-blue-900">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>{fileName}</span>
              </div>
            )}
            <div className="sm:ml-auto">
              <Button
                variant="primary"
                onClick={handleValidateCsv}
                isLoading={isValidating}
                disabled={!csvContent.trim()}
                leftIcon={<ShieldCheck className="w-4 h-4" />}
              >
                Stage 1: Validate File
              </Button>
            </div>
          </div>

          {/* Quick paste textarea alternative */}
          <details className="text-xs text-slate-500">
            <summary className="cursor-pointer hover:text-slate-800 font-medium">
              Or paste raw CSV text directly
            </summary>
            <div className="mt-2">
              <textarea
                value={csvContent}
                onChange={(e) => {
                  setCsvContent(e.target.value);
                  setPreviewReport(null);
                  setCommittedBatch(null);
                }}
                rows={5}
                placeholder="Paste CSV rows here..."
                className="w-full font-mono text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-[#1e3a8a]"
              />
            </div>
          </details>
        </div>
      </div>

      {/* =========================================================================
          STAGE 1: VALIDATION PREVIEW REPORT
         ========================================================================= */}
      {previewReport && (
        <div className="bg-white border-2 border-blue-200 rounded-xl p-5 shadow-xs space-y-4 animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <h4 className="text-base font-bold text-slate-900">
                  Stage 1: Preview & Validation Report
                </h4>
                <Badge variant={previewReport.is_valid ? 'green' : 'yellow'}>
                  {previewReport.is_valid ? 'All Rows Valid' : 'Requires Review'}
                </Badge>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Batch validation for {previewReport.file_name} ({previewReport.schema_version})
              </p>
            </div>

            <div className="flex items-center gap-2">
              {previewReport.invalid_rows_count > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownloadRejectedRows}
                  leftIcon={<Download className="w-3.5 h-3.5" />}
                >
                  Download Rejected Rows ({previewReport.invalid_rows_count})
                </Button>
              )}
              <Button
                variant="primary"
                size="sm"
                onClick={handleCommitImport}
                isLoading={isCommitting}
                disabled={approvedRowIndices.length === 0}
                leftIcon={<Check className="w-4 h-4" />}
              >
                Stage 2: Confirm & Import ({approvedRowIndices.length})
              </Button>
            </div>
          </div>

          {/* Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
              <div className="text-[10px] font-bold text-slate-500 uppercase">Total Rows</div>
              <div className="text-lg font-bold text-slate-800">{previewReport.total_rows}</div>
            </div>

            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-center">
              <div className="text-[10px] font-bold text-emerald-700 uppercase">Valid Rows</div>
              <div className="text-lg font-bold text-emerald-800">{previewReport.valid_rows_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-center">
              <div className="text-[10px] font-bold text-rose-700 uppercase">Rejected Rows</div>
              <div className="text-lg font-bold text-rose-800">{previewReport.invalid_rows_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-center">
              <div className="text-[10px] font-bold text-amber-700 uppercase">Unknown Students</div>
              <div className="text-lg font-bold text-amber-800">{previewReport.unknown_students_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-center">
              <div className="text-[10px] font-bold text-amber-700 uppercase">Unknown Courses</div>
              <div className="text-lg font-bold text-amber-800">{previewReport.unknown_courses_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-purple-50 border border-purple-200 text-center">
              <div className="text-[10px] font-bold text-purple-700 uppercase">Duplicates</div>
              <div className="text-lg font-bold text-purple-800">{previewReport.duplicate_rows_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-orange-50 border border-orange-200 text-center">
              <div className="text-[10px] font-bold text-orange-700 uppercase">Already Enrolled</div>
              <div className="text-lg font-bold text-orange-800">{previewReport.already_enrolled_count}</div>
            </div>
          </div>

          {/* Filter and Row Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-700">Filter View:</span>
                <button
                  type="button"
                  onClick={() => setPreviewFilter('ALL')}
                  className={`px-2 py-0.5 rounded font-medium cursor-pointer ${
                    previewFilter === 'ALL' ? 'bg-[#1e3a8a] text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  All ({previewReport.rows.length})
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewFilter('VALID')}
                  className={`px-2 py-0.5 rounded font-medium cursor-pointer ${
                    previewFilter === 'VALID' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  Valid ({previewReport.valid_rows_count})
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewFilter('INVALID')}
                  className={`px-2 py-0.5 rounded font-medium cursor-pointer ${
                    previewFilter === 'INVALID' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  Rejected ({previewReport.invalid_rows_count})
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const valid = previewReport.rows.filter((r) => r.is_valid || r.status === 'VALID').map((r) => r.row_index);
                    setApprovedRowIndices(valid);
                  }}
                  className="text-[11px] font-semibold text-[#1e3a8a] hover:underline cursor-pointer"
                >
                  Approve All Valid
                </button>
                <span className="text-slate-300">|</span>
                <button
                  type="button"
                  onClick={() => setApprovedRowIndices([])}
                  className="text-[11px] font-semibold text-slate-500 hover:underline cursor-pointer"
                >
                  Clear Selection
                </button>
              </div>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px] sticky top-0">
                  <tr>
                    <th className="p-2 w-8">
                      <input
                        type="checkbox"
                        checked={
                          previewReport.rows.filter((r) => r.is_valid || r.status === 'VALID').length > 0 &&
                          approvedRowIndices.length === previewReport.rows.filter((r) => r.is_valid || r.status === 'VALID').length
                        }
                        onChange={() => {
                          const valid = previewReport.rows.filter((r) => r.is_valid || r.status === 'VALID').map((r) => r.row_index);
                          if (approvedRowIndices.length === valid.length) {
                            setApprovedRowIndices([]);
                          } else {
                            setApprovedRowIndices(valid);
                          }
                        }}
                      />
                    </th>
                    <th className="p-2">Row</th>
                    <th className="p-2">Reg Number</th>
                    <th className="p-2">Course</th>
                    <th className="p-2">Cohort</th>
                    <th className="p-2">Validation Status</th>
                    <th className="p-2">Diagnostics / Error</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {displayedRows.map((r) => {
                    const isSelected = approvedRowIndices.includes(r.row_index);
                    const isValid = r.is_valid || r.status === 'VALID';
                    return (
                      <tr
                        key={r.row_index}
                        className={`hover:bg-slate-50 ${!isValid ? 'bg-rose-50/20' : ''}`}
                      >
                        <td className="p-2">
                          <input
                            type="checkbox"
                            disabled={!isValid}
                            checked={isSelected}
                            onChange={() => {
                              setApprovedRowIndices((prev) =>
                                prev.includes(r.row_index)
                                  ? prev.filter((i) => i !== r.row_index)
                                  : [...prev, r.row_index]
                              );
                            }}
                          />
                        </td>
                        <td className="p-2 font-mono text-slate-500">{r.row_index + 1}</td>
                        <td className="p-2 font-mono font-semibold text-slate-800">
                          {r.registration_number}
                          {r.student_name && (
                            <span className="block text-[11px] text-slate-500 font-normal">
                              {r.student_name}
                            </span>
                          )}
                        </td>
                        <td className="p-2 font-semibold text-slate-800">
                          {r.course_code}
                          {r.course_name && (
                            <span className="block text-[11px] text-slate-500 font-normal">
                              {r.course_name}
                            </span>
                          )}
                        </td>
                        <td className="p-2 text-slate-600">
                          {r.programme_code} Sem {r.semester} ({r.academic_year})
                        </td>
                        <td className="p-2">
                          {isValid ? (
                            <Badge variant="green">Valid</Badge>
                          ) : (
                            <Badge variant="red">Rejected</Badge>
                          )}
                        </td>
                        <td className="p-2 text-[11px]">
                          {isValid ? (
                            <span className="text-emerald-700">Ready to commit to offering {r.matched_offering_id || r.offering_id}</span>
                          ) : (
                            <span className="text-rose-700 font-medium">{(r.errors || r.reasons || []).join('; ')}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          STAGE 2: COMMITTED BATCH SUMMARY
         ========================================================================= */}
      {committedBatch && (
        <div className="bg-white border-2 border-emerald-300 rounded-xl p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <h4 className="text-base font-bold text-slate-900">Import Batch Committed</h4>
              <Badge variant="green">Authoritative Import Complete</Badge>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setCommittedBatch(null);
                setPreviewReport(null);
                setCsvContent('');
                setFileName('');
              }}
            >
              Start New Import
            </Button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-[10px] font-bold text-slate-500 uppercase">Batch ID</div>
              <div className="font-mono text-xs font-bold text-slate-900 mt-1">{committedBatch.batch_id}</div>
            </div>
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200">
              <div className="text-[10px] font-bold text-emerald-700 uppercase">Successful Enrolments</div>
              <div className="text-lg font-bold text-emerald-800 mt-1">{committedBatch.successful_enrolments}</div>
            </div>
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200">
              <div className="text-[10px] font-bold text-rose-700 uppercase">Rejected Rows</div>
              <div className="text-lg font-bold text-rose-800 mt-1">{committedBatch.rejected_rows}</div>
            </div>
            <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
              <div className="text-[10px] font-bold text-blue-700 uppercase">Imported By</div>
              <div className="text-xs font-semibold text-blue-900 mt-1">{committedBatch.imported_by}</div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          AUDIT HISTORY OF CSV IMPORT BATCHES
         ========================================================================= */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#1e3a8a]" />
            <h4 className="text-sm font-bold text-slate-900">CSV Import Audit History</h4>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadImportBatches}
            isLoading={isLoadingBatches}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Refresh History
          </Button>
        </div>

        {importBatches.length === 0 ? (
          <div className="p-4 text-center text-slate-500 text-xs">
            No previous CSV import batches recorded.
          </div>
        ) : (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-2.5">Batch ID</th>
                  <th className="p-2.5">File Name</th>
                  <th className="p-2.5">Imported By</th>
                  <th className="p-2.5">Timestamp</th>
                  <th className="p-2.5">Total Rows</th>
                  <th className="p-2.5">Success</th>
                  <th className="p-2.5">Rejected</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {importBatches.map((b) => (
                  <tr key={b.batch_id} className="hover:bg-slate-50">
                    <td className="p-2.5 font-mono font-semibold text-slate-800">{b.batch_id}</td>
                    <td className="p-2.5 font-medium text-slate-700">{b.file_name}</td>
                    <td className="p-2.5 text-slate-600">{b.imported_by}</td>
                    <td className="p-2.5 text-slate-500">
                      {new Date(b.created_at).toLocaleString()}
                    </td>
                    <td className="p-2.5 font-semibold text-slate-800">{b.total_rows}</td>
                    <td className="p-2.5 text-emerald-700 font-semibold">{b.successful_enrolments}</td>
                    <td className="p-2.5 text-rose-700 font-semibold">{b.rejected_rows}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
