import React, { useState, useMemo, useEffect } from 'react';
import {
  UserPlus,
  Search,
  CheckCircle2,
  AlertCircle,
  X,
  BookOpen,
  User,
  Layers,
  Calendar,
  AlertTriangle,
  History,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { CourseOfferingRecord, CourseEnrolmentRecord } from '../../../types/database';
import { academicRepository } from '../../../services/academicService';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface IndividualEnrolmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  offerings: CourseOfferingRecord[];
  students: Student[];
  actor: { userId: string; role: string; employeeId?: string };
  onSuccess: (message: string) => void;
  initialOffering?: CourseOfferingRecord | null;
}

export function IndividualEnrolmentModal({
  isOpen,
  onClose,
  offerings,
  students,
  actor,
  onSuccess,
  initialOffering,
}: IndividualEnrolmentModalProps) {
  const [studentSearchQuery, setStudentSearchQuery] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [selectedOfferingIds, setSelectedOfferingIds] = useState<string[]>([]);
  const [studentEnrolments, setStudentEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [isLoadingEnrolments, setIsLoadingEnrolments] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Set initial offering if passed
  useEffect(() => {
    if (initialOffering) {
      setSelectedOfferingIds([initialOffering.offering_id]);
    } else {
      setSelectedOfferingIds([]);
    }
  }, [initialOffering, isOpen]);

  // Reset on open/close
  useEffect(() => {
    if (!isOpen) {
      setStudentSearchQuery('');
      setSelectedStudentId('');
      setSelectedOfferingIds([]);
      setStudentEnrolments([]);
      setErrorMessage(null);
    }
  }, [isOpen]);

  // Filter students based on search query
  const filteredStudents = useMemo(() => {
    if (!studentSearchQuery.trim()) return students.slice(0, 8);
    const q = studentSearchQuery.toLowerCase().trim();
    return students.filter(
      (s) =>
        s.fullName?.toLowerCase().includes(q) ||
        s.registrationNumber?.toLowerCase().includes(q) ||
        s.program?.toLowerCase().includes(q) ||
        s.section?.toLowerCase().includes(q) ||
        s.batch?.toLowerCase().includes(q)
    ).slice(0, 15);
  }, [students, studentSearchQuery]);

  const selectedStudent = useMemo(() => {
    return students.find(
      (s) => s.id === selectedStudentId || s.registrationNumber === selectedStudentId
    );
  }, [students, selectedStudentId]);

  // Load selected student's existing active and historical enrolments
  useEffect(() => {
    if (!selectedStudent) {
      setStudentEnrolments([]);
      return;
    }
    let isMounted = true;
    async function loadEnrolments() {
      setIsLoadingEnrolments(true);
      try {
        const list = await devDataAdapter.academic.getEnrolments({
          student_id: selectedStudent!.id || selectedStudent!.registrationNumber,
        });
        if (isMounted) {
          setStudentEnrolments(list);
        }
      } catch (err) {
        console.error('Failed to load student enrolments', err);
      } finally {
        if (isMounted) setIsLoadingEnrolments(false);
      }
    }
    loadEnrolments();
    return () => {
      isMounted = false;
    };
  }, [selectedStudent]);

  // Eligible offerings for this student
  const eligibleOfferings = useMemo(() => {
    return offerings.filter((o) => o.status === 'PUBLISHED');
  }, [offerings]);

  // Toggle offering selection
  const handleToggleOffering = (offeringId: string) => {
    setSelectedOfferingIds((prev) =>
      prev.includes(offeringId) ? prev.filter((id) => id !== offeringId) : [...prev, offeringId]
    );
  };

  const handleExecuteEnrolment = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!selectedStudent) {
      setErrorMessage('Please select a student to enrol.');
      return;
    }

    if (selectedOfferingIds.length === 0) {
      setErrorMessage('Please select at least one course offering.');
      return;
    }

    setIsSubmitting(true);
    const successList: string[] = [];
    const errorList: string[] = [];

    try {
      for (const offId of selectedOfferingIds) {
        const offering = offerings.find((o) => o.offering_id === offId);
        if (!offering) continue;

        try {
          await academicRepository.enrolStudent(
            {
              student_id: selectedStudent.id,
              offering_id: offering.offering_id,
              course_code: offering.course_code,
              section: offering.section,
              semester: offering.semester,
              academic_year: offering.academic_year,
            },
            actor
          );
          successList.push(`${offering.course_code} (Sec ${offering.section})`);
        } catch (err: any) {
          errorList.push(`${offering.course_code}: ${err.message || 'Failed to enrol'}`);
        }
      }

      if (successList.length > 0) {
        onSuccess(
          `Successfully enrolled ${selectedStudent.fullName} (${selectedStudent.registrationNumber}) into: ${successList.join(', ')}.`
        );
        if (errorList.length === 0) {
          onClose();
        } else {
          setErrorMessage(`Partial enrolment completed. Errors: ${errorList.join(' | ')}`);
        }
      } else if (errorList.length > 0) {
        setErrorMessage(`Enrolment rejected: ${errorList.join(' | ')}`);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Enrolment operation failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-[#cbd5e1] max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Individual Student Course Enrolment</h3>
              <p className="text-xs text-[#64748b]">
                Search a student, verify eligibility & capacity, and enrol into published course offerings.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleExecuteEnrolment} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Step 1: Student Search & Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
              1. Search & Select Student
            </label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search by registration number, student name, programme or section..."
                value={studentSearchQuery}
                onChange={(e) => setStudentSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-[#1E3A8A]"
              />
            </div>

            {/* Quick student selection pill list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto pt-1">
              {filteredStudents.map((stu) => {
                const isSelected = selectedStudent?.id === stu.id;
                return (
                  <button
                    key={stu.id}
                    type="button"
                    onClick={() => {
                      setSelectedStudentId(stu.id);
                      setStudentSearchQuery(stu.registrationNumber || stu.fullName);
                    }}
                    className={`p-2 rounded-lg border text-left text-xs transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'border-[#1E3A8A] bg-blue-50/60 ring-1 ring-[#1E3A8A]'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-slate-900">{stu.fullName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {stu.registrationNumber} &bull; {stu.program || 'Engineering'} (Sec {stu.section || 'A'})
                      </div>
                    </div>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-[#1E3A8A] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Student Details & Existing Enrolments */}
          {selectedStudent && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-[#1E3A8A]" />
                  <span className="text-xs font-bold text-slate-900">
                    {selectedStudent.fullName} ({selectedStudent.registrationNumber})
                  </span>
                </div>
                <Badge variant="blue" size="sm">
                  {selectedStudent.program || 'B.Tech'} &bull; Sem {selectedStudent.currentSemester || '3'}
                </Badge>
              </div>

              {/* Current Active Enrolments Summary */}
              <div className="text-xs text-slate-600">
                <span className="font-semibold text-slate-700">Active Course Enrolments: </span>
                {isLoadingEnrolments ? (
                  <span className="text-slate-400">Loading...</span>
                ) : studentEnrolments.filter((e) => e.enrolment_status === 'ACTIVE').length === 0 ? (
                  <span className="text-slate-500 italic">None</span>
                ) : (
                  <span className="font-medium text-slate-800">
                    {studentEnrolments
                      .filter((e) => e.enrolment_status === 'ACTIVE')
                      .map((e) => `${e.course_code} (${e.section})`)
                      .join(', ')}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Step 2: Course Offerings Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                2. Select Eligible Course Offerings
              </label>
              <span className="text-xs text-slate-500">
                {selectedOfferingIds.length} course(s) selected
              </span>
            </div>

            <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 max-h-56 overflow-y-auto">
              {eligibleOfferings.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500">
                  No published course offerings available for enrolment.
                </div>
              ) : (
                eligibleOfferings.map((off) => {
                  const isChecked = selectedOfferingIds.includes(off.offering_id);
                  const isAlreadyEnrolled = studentEnrolments.some(
                    (e) => e.course_code === off.course_code && e.enrolment_status === 'ACTIVE'
                  );
                  const maxCap = off.max_capacity || 60;
                  const currentCount = off.enrolled_count || 0;
                  const isFull = currentCount >= maxCap;

                  return (
                    <div
                      key={off.offering_id}
                      onClick={() => !isAlreadyEnrolled && !isFull && handleToggleOffering(off.offering_id)}
                      className={`p-3 text-xs flex items-center justify-between gap-3 transition-colors ${
                        isAlreadyEnrolled || isFull
                          ? 'bg-slate-50/70 opacity-60 cursor-not-allowed'
                          : isChecked
                          ? 'bg-blue-50/50 cursor-pointer'
                          : 'hover:bg-slate-50 cursor-pointer bg-white'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          disabled={isAlreadyEnrolled || isFull}
                          onChange={() => handleToggleOffering(off.offering_id)}
                          className="mt-0.5 rounded text-[#1E3A8A] focus:ring-[#1E3A8A]"
                        />
                        <div>
                          <div className="font-bold text-slate-900 flex items-center gap-1.5">
                            <span>{off.course_code}</span>
                            <span className="text-slate-400 font-normal">&mdash;</span>
                            <span className="font-semibold text-slate-700">{off.course_title}</span>
                            <Badge variant="gray" size="sm">
                              Sec {off.section}
                            </Badge>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5">
                            Instructor: {off.assigned_faculty_name || 'Assigned Faculty'} &bull; Room: {off.room || 'TBD'} &bull; Sem {off.semester}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        {isAlreadyEnrolled ? (
                          <Badge variant="yellow" size="sm">
                            Already Enrolled
                          </Badge>
                        ) : isFull ? (
                          <Badge variant="red" size="sm">
                            Capacity Full ({currentCount}/{maxCap})
                          </Badge>
                        ) : (
                          <span className="text-[11px] font-medium text-slate-600">
                            Available: <strong className="text-emerald-700">{maxCap - currentCount}</strong> / {maxCap}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </form>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-[#e2e8f0] flex items-center justify-between">
          <Button variant="secondary" size="sm" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={handleExecuteEnrolment}
            disabled={!selectedStudent || selectedOfferingIds.length === 0 || isSubmitting}
            isLoading={isSubmitting}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Enrol Student ({selectedOfferingIds.length} Courses)
          </Button>
        </div>
      </div>
    </div>
  );
}
