import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Calendar,
  Clock,
  Building2,
  Users,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  AlertCircle,
  History,
  Send,
  RefreshCw,
  Eye,
  FileCheck2,
  Layers,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { AcademicClass, AcademicSection, AcademicSession, TimetableValidationResult, TimetableConflictDetail } from '../../../types/academic';
import { CourseOfferingRecord, TimetableSlotRecord, TimetableVersionRecord } from '../../../types/database';
import { academicRepository } from '../../../services/academicService';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface TimetableReviewPublishSectionProps {
  offerings: CourseOfferingRecord[];
  timetableSlots: TimetableSlotRecord[];
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  actor: { userId: string; role: string; employeeId?: string };
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
  onRefresh: () => void;
}

const DAYS_OF_WEEK = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'] as const;
const TIME_BLOCKS = [
  '08:00 - 09:00',
  '09:00 - 10:00',
  '10:00 - 11:00',
  '11:00 - 12:00',
  '12:00 - 13:00',
  '13:00 - 14:00',
  '14:00 - 15:00',
  '15:00 - 16:00',
  '16:00 - 17:00',
];

export function TimetableReviewPublishSection({
  offerings,
  timetableSlots,
  currentSession,
  classes,
  sections,
  actor,
  onSuccess,
  onError,
  onRefresh,
}: TimetableReviewPublishSectionProps) {
  // Cohort Filters
  const [academicYear, setAcademicYear] = useState<string>(currentSession?.id || '2026-2027');
  const [semester, setSemester] = useState<number>(3);
  const [programmeCode, setProgrammeCode] = useState<string>('BTECH-CSE');
  const [sectionCode, setSectionCode] = useState<string>('A');
  const [batch, setBatch] = useState<string>('2026');

  // Matrix View Configuration: 'week' or 'day'
  const [viewMode, setViewMode] = useState<'week' | 'day'>('week');
  const [selectedDay, setSelectedDay] = useState<string>('MONDAY');

  // Validation State
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<TimetableValidationResult | null>(null);

  // Version history & Publish modal
  const [versions, setVersions] = useState<TimetableVersionRecord[]>([]);
  const [isLoadingVersions, setIsLoadingVersions] = useState(false);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [changeNotes, setChangeNotes] = useState('');
  const [isPublishing, setIsPublishing] = useState(false);

  // Load version history
  const loadVersions = useCallback(async () => {
    setIsLoadingVersions(true);
    try {
      const history = await academicRepository.getTimetableVersions({
        academic_year: academicYear,
        programme_code: programmeCode,
        semester,
        section: sectionCode,
      });
      setVersions(history);
    } catch (err: any) {
      console.error('Failed to load timetable versions:', err);
    } finally {
      setIsLoadingVersions(false);
    }
  }, [academicYear, programmeCode, semester, sectionCode]);

  useEffect(() => {
    loadVersions();
  }, [loadVersions]);

  // Current published version for this cohort
  const currentPublishedVersion = useMemo(() => {
    return versions.find((v) => v.status === 'PUBLISHED');
  }, [versions]);

  // Filter slots for this cohort
  const cohortSlots = useMemo(() => {
    return timetableSlots.filter((slot) => {
      const matchAy = !academicYear || slot.academic_year === academicYear;
      const matchSem = !semester || slot.semester === semester;
      const matchProg = !programmeCode || slot.programme_code === programmeCode;
      const matchSec = !sectionCode || sectionCode === 'ALL' || slot.section === sectionCode;
      return matchAy && matchSem && matchProg && matchSec;
    });
  }, [timetableSlots, academicYear, semester, programmeCode, sectionCode]);

  // Run Conflict & Integrity check
  const handleRunValidation = async () => {
    setIsValidating(true);
    setValidationResult(null);
    try {
      const res = await academicRepository.validateTimetable({
        academic_year: academicYear,
        semester,
        programme_code: programmeCode,
        section: sectionCode,
      });
      setValidationResult(res);
      if (res.is_valid) {
        onSuccess(`Integrity check passed: ${res.total_slots_checked} slots validated with 0 conflicts.`);
      } else {
        onError(`Integrity check detected ${res.conflicts.length} conflict(s). Review before publishing.`);
      }
    } catch (err: any) {
      onError(err?.message || 'Failed to validate timetable.');
    } finally {
      setIsValidating(false);
    }
  };

  // Publish timetable
  const handlePublishTimetable = async () => {
    setIsPublishing(true);
    try {
      const published = await academicRepository.publishTimetable(
        {
          academic_year: academicYear,
          semester,
          programme_code: programmeCode,
          section: sectionCode,
          batch,
          change_notes: changeNotes.trim() || undefined,
        },
        actor
      );

      setShowPublishModal(false);
      setChangeNotes('');
      onSuccess(
        `Official timetable published: Version ${published.version} is now authoritative for ${programmeCode} Sem ${semester} Sec ${sectionCode}.`
      );
      await loadVersions();
      onRefresh();
    } catch (err: any) {
      onError(err?.message || 'Failed to publish timetable.');
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Configuration & Action Header */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#1e3a8a]" />
              <h3 className="text-base font-bold text-[#1e293b]">
                Timetable Conflict Review & Official Publication
              </h3>
              {currentPublishedVersion ? (
                <Badge variant="green">Published: v{currentPublishedVersion.version}</Badge>
              ) : (
                <Badge variant="yellow">Draft (Pending Publication)</Badge>
              )}
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Validate room, faculty, student, and section conflicts. Only PUBLISHED timetables appear in the Student Portal.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleRunValidation}
              isLoading={isValidating}
              leftIcon={<ShieldCheck className="w-4 h-4" />}
            >
              Run Conflict & Integrity Check
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setShowPublishModal(true)}
              leftIcon={<Send className="w-4 h-4" />}
            >
              {currentPublishedVersion ? 'Republish Timetable' : 'Publish Official Timetable'}
            </Button>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Academic Year
            </label>
            <select
              value={academicYear}
              onChange={(e) => setAcademicYear(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="2026-2027">2026-2027</option>
              <option value="2025-2026">2025-2026</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Semester
            </label>
            <select
              value={semester}
              onChange={(e) => setSemester(Number(e.target.value))}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                <option key={s} value={s}>Semester {s}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Programme
            </label>
            <select
              value={programmeCode}
              onChange={(e) => setProgrammeCode(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="BTECH-CSE">B.Tech Computer Science (BTECH-CSE)</option>
              <option value="BTECH-ECE">B.Tech Electronics & Comm (BTECH-ECE)</option>
              <option value="BTECH-MECH">B.Tech Mechanical (BTECH-MECH)</option>
              <option value="BTECH-CIVIL">B.Tech Civil (BTECH-CIVIL)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section
            </label>
            <select
              value={sectionCode}
              onChange={(e) => setSectionCode(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
              <option value="ALL">All Sections</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              View Matrix
            </label>
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg">
              <button
                type="button"
                onClick={() => setViewMode('week')}
                className={`flex-1 py-1 rounded text-xs font-semibold cursor-pointer ${
                  viewMode === 'week' ? 'bg-white text-[#1e3a8a] shadow-xs' : 'text-slate-600'
                }`}
              >
                Week View
              </button>
              <button
                type="button"
                onClick={() => setViewMode('day')}
                className={`flex-1 py-1 rounded text-xs font-semibold cursor-pointer ${
                  viewMode === 'day' ? 'bg-white text-[#1e3a8a] shadow-xs' : 'text-slate-600'
                }`}
              >
                Day View
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          VALIDATION REPORT BANNER
         ========================================================================= */}
      {validationResult && (
        <div
          className={`p-4 rounded-xl border ${
            validationResult.is_valid
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border-rose-200 text-rose-900'
          } space-y-2`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {validationResult.is_valid ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              )}
              <span className="font-bold text-sm">
                {validationResult.is_valid
                  ? `Integrity Verified: ${validationResult.total_slots_checked} slots ready for publication.`
                  : `Integrity Warnings: ${validationResult.conflicts.length} conflict(s) detected.`}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setValidationResult(null)}
              className="text-xs font-bold hover:underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>

          {validationResult.conflicts.length > 0 && (
            <div className="mt-2 space-y-1.5 pl-7">
              {validationResult.conflicts.map((c, idx) => (
                <div key={idx} className="text-xs flex items-start gap-1.5">
                  <Badge variant="red">{c.conflict_type}</Badge>
                  <span className="font-medium">{c.description}</span>
                  {c.involved_courses && (
                    <span className="text-slate-600">({c.involved_courses.join(', ')})</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TIMETABLE MATRIX VIEW
         ========================================================================= */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#1e3a8a]" />
            <h4 className="text-sm font-bold text-slate-900">
              {programmeCode} &bull; Semester {semester} &bull; Section {sectionCode} Timetable
            </h4>
          </div>
          {viewMode === 'day' && (
            <div className="flex items-center gap-1">
              {DAYS_OF_WEEK.map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setSelectedDay(d)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer ${
                    selectedDay === d ? 'bg-[#1e3a8a] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {d.slice(0, 3)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Weekly Matrix Grid */}
        {viewMode === 'week' ? (
          <div className="border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse min-w-[700px]">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-2.5 border-r border-slate-200 w-28">Day</th>
                  <th className="p-2.5">Scheduled Lecture & Lab Slots</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {DAYS_OF_WEEK.map((day) => {
                  const daySlots = cohortSlots.filter((s) => s.day_of_week === day);
                  return (
                    <tr key={day} className="hover:bg-slate-50/50">
                      <td className="p-3 border-r border-slate-200 font-bold text-slate-700 bg-slate-50/30">
                        {day}
                      </td>
                      <td className="p-3">
                        {daySlots.length === 0 ? (
                          <span className="text-slate-400 italic text-[11px]">No slots scheduled</span>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            {daySlots.map((slot) => (
                              <div
                                key={slot.slot_id}
                                className="p-2.5 rounded-lg border border-blue-200 bg-blue-50/60 max-w-xs shadow-2xs"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <span className="font-bold text-blue-950 text-xs">
                                    {slot.course_code}
                                  </span>
                                  <span className="font-mono text-[10px] text-blue-800 bg-blue-100 px-1 rounded">
                                    {slot.start_time} - {slot.end_time}
                                  </span>
                                </div>
                                <div className="text-[11px] font-medium text-slate-800 line-clamp-1 mt-0.5">
                                  {slot.course_name}
                                </div>
                                <div className="text-[10px] text-slate-600 mt-1 flex items-center justify-between">
                                  <span className="flex items-center gap-1">
                                    <Building2 className="w-3 h-3 text-slate-400" />
                                    {slot.room_number || slot.room || 'TBA'}
                                  </span>
                                  <span>{slot.faculty_name || 'TBA'}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* Day Matrix View */
          <div className="space-y-3">
            {cohortSlots.filter((s) => s.day_of_week === selectedDay).length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs bg-slate-50 rounded-lg border border-slate-200">
                No scheduled slots for {selectedDay}.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {cohortSlots
                  .filter((s) => s.day_of_week === selectedDay)
                  .map((slot) => (
                    <div
                      key={slot.slot_id}
                      className="p-3.5 rounded-lg border border-slate-200 bg-white shadow-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-slate-900">{slot.course_code}</span>
                        <Badge variant="blue">{slot.start_time} - {slot.end_time}</Badge>
                      </div>
                      <div className="text-xs font-semibold text-slate-700">{slot.course_name}</div>
                      <div className="text-xs text-slate-500 space-y-1 pt-1 border-t border-slate-100">
                        <div className="flex justify-between">
                          <span>Room:</span>
                          <span className="font-semibold text-slate-800">{slot.room_number || slot.room || 'TBA'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Faculty:</span>
                          <span className="font-semibold text-slate-800">{slot.faculty_name || 'TBA'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Section:</span>
                          <span className="font-semibold text-slate-800">{slot.section}</span>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* =========================================================================
          PUBLISHED VERSION HISTORY & AUDIT LOG
         ========================================================================= */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#1e3a8a]" />
            <h4 className="text-sm font-bold text-slate-900">
              Official Timetable Version History & Publication Audit
            </h4>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadVersions}
            isLoading={isLoadingVersions}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Refresh
          </Button>
        </div>

        {versions.length === 0 ? (
          <div className="p-4 text-center text-slate-500 text-xs">
            No published versions yet for {programmeCode} Sem {semester} Sec {sectionCode}. Currently in DRAFT state.
          </div>
        ) : (
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px]">
                <tr>
                  <th className="p-2.5">Version</th>
                  <th className="p-2.5">Status</th>
                  <th className="p-2.5">Cohort</th>
                  <th className="p-2.5">Published By</th>
                  <th className="p-2.5">Publication Date</th>
                  <th className="p-2.5">Change Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {versions.map((ver) => (
                  <tr key={ver.version_id} className="hover:bg-slate-50">
                    <td className="p-2.5 font-mono font-bold text-slate-900">v{ver.version}</td>
                    <td className="p-2.5">
                      {ver.status === 'PUBLISHED' && <Badge variant="green">PUBLISHED</Badge>}
                      {ver.status === 'SUPERSEDED' && <Badge variant="gray">SUPERSEDED</Badge>}
                      {ver.status === 'VALIDATED' && <Badge variant="blue">VALIDATED</Badge>}
                      {ver.status === 'DRAFT' && <Badge variant="yellow">DRAFT</Badge>}
                    </td>
                    <td className="p-2.5 text-slate-700">
                      {ver.programme_code} Sem {ver.semester} ({ver.section})
                    </td>
                    <td className="p-2.5 text-slate-600 font-medium">{ver.published_by}</td>
                    <td className="p-2.5 text-slate-500">
                      {ver.published_at ? new Date(ver.published_at).toLocaleString() : 'Pending'}
                    </td>
                    <td className="p-2.5 text-slate-600 text-[11px]">
                      {ver.change_notes || 'Initial official publication.'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* =========================================================================
          PUBLISH / REPUBLISH CONFIRMATION MODAL
         ========================================================================= */}
      {showPublishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-in fade-in duration-100">
          <div className="bg-white rounded-xl max-w-md w-full p-5 space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                <Send className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {currentPublishedVersion ? 'Republish Official Timetable' : 'Publish Official Timetable'}
                </h4>
                <p className="text-xs text-slate-500">
                  Instantly releases the timetable to student portal views.
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-lg text-xs space-y-1.5 text-slate-700">
              <div className="flex justify-between">
                <span>Target Cohort:</span>
                <span className="font-semibold text-slate-900">
                  {programmeCode} &bull; Sem {semester} (Sec {sectionCode})
                </span>
              </div>
              <div className="flex justify-between">
                <span>Academic Year:</span>
                <span className="font-semibold text-slate-900">{academicYear}</span>
              </div>
              <div className="flex justify-between">
                <span>New Version:</span>
                <span className="font-bold text-blue-700">
                  v{(currentPublishedVersion?.version || 0) + 1}
                </span>
              </div>
              {currentPublishedVersion && (
                <div className="flex justify-between pt-1 border-t border-slate-200 text-amber-700">
                  <span>Previous Version v{currentPublishedVersion.version}:</span>
                  <span className="font-semibold">Will be archived as SUPERSEDED</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
                Publication Change Notes (Audit Record)
              </label>
              <textarea
                value={changeNotes}
                onChange={(e) => setChangeNotes(e.target.value)}
                placeholder="E.g., Updated lecture slot for CS201 to CR-102; ratified by Academic Council."
                rows={3}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-[#1e3a8a]"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowPublishModal(false)}
                disabled={isPublishing}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handlePublishTimetable}
                isLoading={isPublishing}
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
              >
                Confirm & Publish
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
