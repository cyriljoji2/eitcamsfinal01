import React, { useState, useMemo } from 'react';
import {
  Users,
  Layers,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  AlertCircle,
  Check,
  Search,
  Filter,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Info,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicClass, AcademicSection, AcademicSession, BulkEnrolmentRequest, BulkEnrolmentPreReview, BulkEnrolmentResult } from '../../../types/academic';
import { CourseOfferingRecord } from '../../../types/database';
import { academicRepository } from '../../../services/academicService';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface BulkEnrolmentSectionProps {
  offerings: CourseOfferingRecord[];
  students: Student[];
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  actor: { userId: string; role: string; employeeId?: string };
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
  onRefresh: () => void;
}

export function BulkEnrolmentSection({
  offerings,
  students,
  currentSession,
  classes,
  sections,
  actor,
  onSuccess,
  onError,
  onRefresh,
}: BulkEnrolmentSectionProps) {
  // Filter & Cohort configuration
  const [academicYear, setAcademicYear] = useState<string>(currentSession?.id || '2026-2027');
  const [semester, setSemester] = useState<number>(3);
  const [programmeCode, setProgrammeCode] = useState<string>('BTECH-CSE');
  const [batch, setBatch] = useState<string>('2026');
  const [sectionCode, setSectionCode] = useState<string>('A');

  // Operating Mode: 'cohort' (Mode 1) vs 'selected_students' (Mode 2)
  const [operatingMode, setOperatingMode] = useState<'cohort' | 'selected_students'>('cohort');

  // Mode 2 Student Selection
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [studentSearchQuery, setStudentSearchQuery] = useState('');

  // Course offerings selection
  const [selectedOfferingIds, setSelectedOfferingIds] = useState<string[]>([]);

  // Pre-review state
  const [isReviewing, setIsReviewing] = useState(false);
  const [preReview, setPreReview] = useState<BulkEnrolmentPreReview | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Execution result state
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<BulkEnrolmentResult | null>(null);

  // Filter available published offerings for current cohort
  const availableOfferings = useMemo(() => {
    const progDept = (programmeCode || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
    return offerings.filter(
      (o) =>
        o.status === 'PUBLISHED' &&
        o.academic_year === academicYear &&
        o.semester === semester &&
        (!programmeCode || o.programme_code === programmeCode || (o.department && o.department.toUpperCase() === progDept))
    );
  }, [offerings, academicYear, semester, programmeCode]);

  // Candidate students matching the cohort criteria
  const cohortStudents = useMemo(() => {
    const progDept = (programmeCode || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
    return students.filter((s) => {
      const sProgUpper = (s.program || '').toUpperCase();
      const sDeptUpper = ((s as any).department || '').toUpperCase();
      const matchProg = !programmeCode ||
        sProgUpper === programmeCode.toUpperCase() ||
        (progDept && sDeptUpper === progDept) ||
        (progDept && sProgUpper.includes(progDept));
      const matchBatch = !batch || String(s.batch) === String(batch);
      const matchSec = !sectionCode || sectionCode === 'ALL' || s.section === sectionCode;
      const isActive = s.accountStatus === 'active' && (s as any).status !== 'inactive' && (s as any).status !== 'withdrawn' && (s as any).status !== 'graduated';
      return matchProg && matchBatch && matchSec && isActive;
    });
  }, [students, programmeCode, batch, sectionCode]);

  // Filtered candidate students for Mode 2 table search
  const filteredCandidateStudents = useMemo(() => {
    if (!studentSearchQuery.trim()) return cohortStudents;
    const q = studentSearchQuery.toLowerCase();
    return cohortStudents.filter(
      (s) =>
        s.fullName?.toLowerCase().includes(q) ||
        s.registrationNumber?.toLowerCase().includes(q) ||
        s.email?.toLowerCase().includes(q)
    );
  }, [cohortStudents, studentSearchQuery]);

  // Handle Select All / Deselect All for Mode 2
  const handleToggleSelectAllStudents = () => {
    if (selectedStudentIds.length === filteredCandidateStudents.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(filteredCandidateStudents.map((s) => s.id || s.registrationNumber));
    }
  };

  const handleToggleStudent = (id: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleOffering = (id: string) => {
    setSelectedOfferingIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Generate Pre-review
  const handleGeneratePreReview = async () => {
    if (selectedOfferingIds.length === 0) {
      onError('Please select at least one course offering for bulk enrolment.');
      return;
    }

    if (operatingMode === 'selected_students' && selectedStudentIds.length === 0) {
      onError('Please select at least one student in Selected-Student mode.');
      return;
    }

    if (operatingMode === 'cohort' && cohortStudents.length === 0) {
      onError('No active students found matching the selected programme, batch, and section.');
      return;
    }

    setIsReviewing(true);
    setPreReview(null);
    setExecutionResult(null);

    try {
      const request: BulkEnrolmentRequest = {
        mode: operatingMode === 'selected_students' ? 'selected_students' : 'programme_section',
        academic_year: academicYear,
        semester,
        programme_code: programmeCode,
        batch,
        section: sectionCode,
        section_code: sectionCode,
        offering_ids: selectedOfferingIds,
        student_ids: operatingMode === 'selected_students' ? selectedStudentIds : undefined,
        selected_student_ids: operatingMode === 'selected_students' ? selectedStudentIds : undefined,
      };

      const review = await academicRepository.previewBulkEnrolment(request);
      setPreReview(review);
    } catch (err: any) {
      onError(err?.message || 'Failed to generate bulk enrolment preview.');
    } finally {
      setIsReviewing(false);
    }
  };

  // Execute Bulk Enrolment
  const handleExecuteBulkEnrolment = async () => {
    if (!preReview) return;
    setShowConfirmModal(false);
    setIsExecuting(true);

    try {
      const request: BulkEnrolmentRequest = {
        mode: operatingMode === 'selected_students' ? 'selected_students' : 'programme_section',
        academic_year: academicYear,
        semester,
        programme_code: programmeCode,
        batch,
        section: sectionCode,
        section_code: sectionCode,
        offering_ids: selectedOfferingIds,
        student_ids: operatingMode === 'selected_students' ? selectedStudentIds : undefined,
        selected_student_ids: operatingMode === 'selected_students' ? selectedStudentIds : undefined,
      };

      const result = await academicRepository.bulkEnrolStudents(request, actor);
      setExecutionResult(result);
      const successCount = result.successful_count ?? result.successful.length;
      const skipCount = result.skipped_count ?? result.skipped.length;
      const failCount = result.failed_count ?? result.failed.length;
      onSuccess(
        `Bulk enrolment executed: ${successCount} enrolled, ${skipCount} skipped, ${failCount} failed.`
      );
      onRefresh();
    } catch (err: any) {
      onError(err?.message || 'Bulk enrolment execution failed.');
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Configuration Header Card */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h3 className="text-base font-bold text-[#1e293b] flex items-center gap-2">
              <Users className="w-5 h-5 text-[#1e3a8a]" />
              <span>Programme-Wise Bulk Enrolment</span>
            </h3>
            <p className="text-xs text-[#64748b] mt-0.5">
              Enrol entire cohorts or designated student groups into eligible course offerings with strict pre-validation.
            </p>
          </div>

          {/* Operating Mode Selector */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => {
                setOperatingMode('cohort');
                setPreReview(null);
                setExecutionResult(null);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-all ${
                operatingMode === 'cohort'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mode 1: Programme / Section Cohort
            </button>
            <button
              type="button"
              onClick={() => {
                setOperatingMode('selected_students');
                setPreReview(null);
                setExecutionResult(null);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-all ${
                operatingMode === 'selected_students'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mode 2: Selected Students
            </button>
          </div>
        </div>

        {/* Cohort Parameters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3.5">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Academic Year
            </label>
            <select
              value={academicYear}
              onChange={(e) => {
                setAcademicYear(e.target.value);
                setPreReview(null);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="2026-2027">2026-2027 (Current)</option>
              <option value="2025-2026">2025-2026</option>
              <option value="2027-2028">2027-2028</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Semester
            </label>
            <select
              value={semester}
              onChange={(e) => {
                setSemester(Number(e.target.value));
                setPreReview(null);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                <option key={s} value={s}>
                  Semester {s}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Programme
            </label>
            <select
              value={programmeCode}
              onChange={(e) => {
                setProgrammeCode(e.target.value);
                setPreReview(null);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="BTECH-CSE">B.Tech Computer Science (BTECH-CSE)</option>
              <option value="BTECH-ECE">B.Tech Electronics & Comm (BTECH-ECE)</option>
              <option value="BTECH-MECH">B.Tech Mechanical (BTECH-MECH)</option>
              <option value="BTECH-CIVIL">B.Tech Civil (BTECH-CIVIL)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Batch Cohort
            </label>
            <select
              value={batch}
              onChange={(e) => {
                setBatch(e.target.value);
                setPreReview(null);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="2026">Batch 2026</option>
              <option value="2025">Batch 2025</option>
              <option value="2024">Batch 2024</option>
              <option value="2023">Batch 2023</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1">
              Section
            </label>
            <select
              value={sectionCode}
              onChange={(e) => {
                setSectionCode(e.target.value);
                setPreReview(null);
              }}
              className="w-full px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium"
            >
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
              <option value="ALL">All Sections (Entire Programme)</option>
            </select>
          </div>
        </div>

        {/* Course Offerings Selection */}
        <div className="space-y-2 pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
              Select Target Course Offerings ({selectedOfferingIds.length} of {availableOfferings.length} selected)
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSelectedOfferingIds(availableOfferings.map((o) => o.offering_id))}
                className="text-[11px] font-semibold text-[#1e3a8a] hover:underline cursor-pointer"
              >
                Select All
              </button>
              <span className="text-slate-300">|</span>
              <button
                type="button"
                onClick={() => setSelectedOfferingIds([])}
                className="text-[11px] font-semibold text-slate-500 hover:underline cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>

          {availableOfferings.length === 0 ? (
            <div className="p-4 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs">
              No PUBLISHED offerings found for {programmeCode} Sem {semester} ({academicYear}). Create or publish offerings first.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {availableOfferings.map((offering) => {
                const isSelected = selectedOfferingIds.includes(offering.offering_id);
                const enrolled = offering.enrolled_count || 0;
                const capacity = offering.max_capacity || 60;
                const available = Math.max(0, capacity - enrolled);
                return (
                  <div
                    key={offering.offering_id}
                    onClick={() => handleToggleOffering(offering.offering_id)}
                    className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'border-[#1e3a8a] bg-blue-50/50 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="rounded text-[#1e3a8a] focus:ring-0 cursor-pointer"
                        />
                        <span className="text-xs font-bold text-slate-900">
                          {offering.course_code}
                        </span>
                      </div>
                      <Badge variant={available > 0 ? 'green' : 'red'}>
                        {available} seats left
                      </Badge>
                    </div>
                    <div className="text-xs font-medium text-slate-700 mt-1 line-clamp-1">
                      {offering.course_title}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                      <span>Sec {offering.section} &bull; {offering.credits || 4} Cr</span>
                      <span>Faculty: {offering.assigned_faculty_name || 'TBA'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Mode 2: Selected Students Table */}
        {operatingMode === 'selected_students' && (
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-[#1e3a8a]" />
                Select Specific Students ({selectedStudentIds.length} of {filteredCandidateStudents.length} selected)
              </span>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search candidate students..."
                    value={studentSearchQuery}
                    onChange={(e) => setStudentSearchQuery(e.target.value)}
                    className="pl-8 pr-2.5 py-1 text-xs bg-slate-50 border border-slate-200 rounded-md w-48"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleToggleSelectAllStudents}
                  className="text-[11px] font-semibold text-[#1e3a8a] hover:underline cursor-pointer"
                >
                  {selectedStudentIds.length === filteredCandidateStudents.length ? 'Deselect All' : 'Select All'}
                </button>
              </div>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden max-h-56 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px] sticky top-0">
                  <tr>
                    <th className="p-2 w-8">
                      <input
                        type="checkbox"
                        checked={
                          filteredCandidateStudents.length > 0 &&
                          selectedStudentIds.length === filteredCandidateStudents.length
                        }
                        onChange={handleToggleSelectAllStudents}
                      />
                    </th>
                    <th className="p-2">Reg Number</th>
                    <th className="p-2">Student Name</th>
                    <th className="p-2">Programme & Sec</th>
                    <th className="p-2">Batch</th>
                    <th className="p-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCandidateStudents.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-4 text-center text-slate-500">
                        No students found matching current filters.
                      </td>
                    </tr>
                  ) : (
                    filteredCandidateStudents.map((st) => {
                      const id = st.id || st.registrationNumber;
                      const isSelected = selectedStudentIds.includes(id);
                      return (
                        <tr
                          key={id}
                          onClick={() => handleToggleStudent(id)}
                          className={`hover:bg-slate-50 cursor-pointer ${isSelected ? 'bg-blue-50/40' : ''}`}
                        >
                          <td className="p-2" onClick={(e) => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleStudent(id)}
                            />
                          </td>
                          <td className="p-2 font-mono font-semibold text-slate-800">
                            {st.registrationNumber}
                          </td>
                          <td className="p-2 text-slate-900 font-medium">{st.fullName}</td>
                          <td className="p-2 text-slate-600">
                            {st.program} (Sec {st.section || 'A'})
                          </td>
                          <td className="p-2 text-slate-600">{st.batch}</td>
                          <td className="p-2">
                            <Badge variant="green">Active</Badge>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Action Button: Review */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <div className="text-xs text-slate-600">
            {operatingMode === 'cohort' ? (
              <span>
                Cohort Target: <strong className="text-slate-900">{cohortStudents.length}</strong> active students in {programmeCode} Sec {sectionCode}
              </span>
            ) : (
              <span>
                Selected Target: <strong className="text-slate-900">{selectedStudentIds.length}</strong> students selected
              </span>
            )}
          </div>
          <Button
            variant="primary"
            onClick={handleGeneratePreReview}
            isLoading={isReviewing}
            disabled={
              selectedOfferingIds.length === 0 ||
              (operatingMode === 'selected_students' && selectedStudentIds.length === 0) ||
              (operatingMode === 'cohort' && cohortStudents.length === 0)
            }
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Review Bulk Enrolment
          </Button>
        </div>
      </div>

      {/* =========================================================================
          PRE-REVIEW VERIFICATION SCREEN
         ========================================================================= */}
      {preReview && (
        <div className="bg-white border-2 border-blue-200 rounded-xl p-5 shadow-xs space-y-5 animate-in fade-in duration-150">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <h4 className="text-base font-bold text-slate-900">Pre-Enrolment Verification Review</h4>
                <Badge variant="blue">Pre-Commit Validation</Badge>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Review verified student eligibility, active enrolments, and course capacity prior to committing.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPreReview(null)}
              >
                Adjust Filters
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={preReview.expected_successful === 0}
                onClick={() => setShowConfirmModal(true)}
                leftIcon={<Check className="w-4 h-4" />}
              >
                Confirm & Enrol ({preReview.expected_successful})
              </Button>
            </div>
          </div>

          {/* 8-Card Verification Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Total Selected</div>
              <div className="text-lg font-bold text-slate-800 mt-0.5">{preReview.total_students ?? preReview.total_selected_students}</div>
            </div>

            <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-center">
              <div className="text-[10px] font-bold text-blue-700 uppercase tracking-wider">Eligible Students</div>
              <div className="text-lg font-bold text-blue-900 mt-0.5">{preReview.eligible_students ?? preReview.eligible_students_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-center">
              <div className="text-[10px] font-bold text-amber-700 uppercase tracking-wider">Already Enrolled</div>
              <div className="text-lg font-bold text-amber-900 mt-0.5">{preReview.already_enrolled ?? preReview.students_already_enrolled_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-center">
              <div className="text-[10px] font-bold text-rose-700 uppercase tracking-wider">Ineligible</div>
              <div className="text-lg font-bold text-rose-900 mt-0.5">{preReview.ineligible_students ?? preReview.ineligible_students_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-orange-50 border border-orange-200 text-center">
              <div className="text-[10px] font-bold text-orange-700 uppercase tracking-wider">Duplicate Enrol</div>
              <div className="text-lg font-bold text-orange-900 mt-0.5">{preReview.duplicate_enrolments ?? preReview.duplicate_enrolments_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-purple-50 border border-purple-200 text-center">
              <div className="text-[10px] font-bold text-purple-700 uppercase tracking-wider">Capacity Limits</div>
              <div className="text-lg font-bold text-purple-900 mt-0.5">{preReview.capacity_limited ?? preReview.capacity_limited_count}</div>
            </div>

            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-center">
              <div className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider">Expected Success</div>
              <div className="text-lg font-bold text-emerald-900 mt-0.5">{preReview.expected_successful}</div>
            </div>

            <div className="p-3 rounded-lg bg-slate-100 border border-slate-300 text-center">
              <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">Expected Rejected</div>
              <div className="text-lg font-bold text-slate-800 mt-0.5">{preReview.expected_rejected}</div>
            </div>
          </div>

          {/* Breakdown Table of Proposed Registrations */}
          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px] sticky top-0">
                <tr>
                  <th className="p-2.5">Student</th>
                  <th className="p-2.5">Reg Number</th>
                  <th className="p-2.5">Course Code</th>
                  <th className="p-2.5">Offering Section</th>
                  <th className="p-2.5">Status</th>
                  <th className="p-2.5">Reason / Capacity Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(preReview.details || preReview.breakdown || []).map((item: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-2.5 font-medium text-slate-900">{item.student_name}</td>
                    <td className="p-2.5 font-mono text-slate-700">{item.registration_number}</td>
                    <td className="p-2.5 font-semibold text-slate-800">{item.course_code}</td>
                    <td className="p-2.5 text-slate-600">Sec {item.section || 'A'}</td>
                    <td className="p-2.5">
                      {item.status === 'ELIGIBLE' && <Badge variant="green">Eligible</Badge>}
                      {item.status === 'ALREADY_ENROLLED' && <Badge variant="yellow">Already Enrolled</Badge>}
                      {(item.status === 'CAPACITY_FULL' || item.status === 'CAPACITY_EXCEEDED') && <Badge variant="red">Capacity Exceeded</Badge>}
                      {(item.status === 'INELIGIBLE' || item.status === 'INELIGIBLE_PROGRAMME') && <Badge variant="red">Ineligible</Badge>}
                      {(item.status === 'DUPLICATE' || item.status === 'DUPLICATE_IN_REQUEST') && <Badge variant="yellow">Duplicate</Badge>}
                    </td>
                    <td className="p-2.5 text-slate-500 text-[11px]">{item.reason || 'Will be enrolled'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          EXECUTION RESULT REPORT
         ========================================================================= */}
      {executionResult && (
        <div className="bg-white border-2 border-emerald-300 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <h4 className="text-base font-bold text-slate-900">Bulk Enrolment Execution Report</h4>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">
                Batch ID: <strong className="font-mono text-slate-700">{executionResult.batch_id || 'BULK-COMMITTED'}</strong>
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setExecutionResult(null)}
              >
                Dismiss Report
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
              <div className="text-[10px] font-bold text-slate-500 uppercase">Attempted</div>
              <div className="text-lg font-bold text-slate-800">{executionResult.total_attempted}</div>
            </div>
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-center">
              <div className="text-[10px] font-bold text-emerald-700 uppercase">Successful</div>
              <div className="text-lg font-bold text-emerald-800">{executionResult.successful_count ?? executionResult.successful.length}</div>
            </div>
            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-center">
              <div className="text-[10px] font-bold text-amber-700 uppercase">Skipped</div>
              <div className="text-lg font-bold text-amber-800">{executionResult.skipped_count ?? executionResult.skipped.length}</div>
            </div>
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-center">
              <div className="text-[10px] font-bold text-rose-700 uppercase">Failed</div>
              <div className="text-lg font-bold text-rose-800">{executionResult.failed_count ?? executionResult.failed.length}</div>
            </div>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-60 overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[11px] sticky top-0">
                <tr>
                  <th className="p-2.5">Student</th>
                  <th className="p-2.5">Course Code</th>
                  <th className="p-2.5">Status</th>
                  <th className="p-2.5">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(executionResult.results && executionResult.results.length > 0
                  ? executionResult.results
                  : [
                      ...executionResult.successful.map((s) => ({
                        student_name: s.student_name,
                        registration_number: s.registration_number,
                        course_code: s.course_code,
                        status: 'SUCCESS',
                        message: 'Enrolled successfully',
                      })),
                      ...executionResult.skipped.map((s) => ({
                        student_name: s.student_name,
                        registration_number: s.registration_number,
                        course_code: s.course_code,
                        status: 'SKIPPED',
                        message: s.reason,
                      })),
                      ...executionResult.failed.map((f) => ({
                        student_name: f.student_name,
                        registration_number: f.registration_number,
                        course_code: f.course_code,
                        status: 'FAILED',
                        message: f.reason,
                      })),
                    ]
                ).map((r: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-2.5 font-medium text-slate-900">{r.student_name || r.registration_number}</td>
                    <td className="p-2.5 font-semibold text-slate-800">{r.course_code}</td>
                    <td className="p-2.5">
                      {r.status === 'SUCCESS' && <Badge variant="green">Success</Badge>}
                      {r.status === 'SKIPPED' && <Badge variant="yellow">Skipped</Badge>}
                      {r.status === 'FAILED' && <Badge variant="red">Failed</Badge>}
                    </td>
                    <td className="p-2.5 text-slate-600 text-[11px]">{r.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONFIRMATION MODAL
         ========================================================================= */}
      {showConfirmModal && preReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 animate-in fade-in duration-100">
          <div className="bg-white rounded-xl max-w-md w-full p-5 space-y-4 shadow-xl border border-slate-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">Confirm Bulk Enrolment</h4>
                <p className="text-xs text-slate-500">This action will create authoritative academic enrolments.</p>
              </div>
            </div>

            <div className="bg-slate-50 p-3.5 rounded-lg text-xs space-y-1.5 text-slate-700">
              <div className="flex justify-between">
                <span>Target Programme:</span>
                <span className="font-semibold text-slate-900">{programmeCode}</span>
              </div>
              <div className="flex justify-between">
                <span>Academic Year & Semester:</span>
                <span className="font-semibold text-slate-900">{academicYear} &bull; Sem {semester}</span>
              </div>
              <div className="flex justify-between">
                <span>Target Offerings:</span>
                <span className="font-semibold text-slate-900">{selectedOfferingIds.length} course(s)</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200">
                <span>Eligible Enrolments to Commit:</span>
                <span className="font-bold text-emerald-700">{preReview.expected_successful}</span>
              </div>
              <div className="flex justify-between">
                <span>Will Be Skipped:</span>
                <span className="font-medium text-amber-700">{preReview.expected_rejected}</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500">
              Each student will be enrolled in the authoritative academic database. An audit record will be logged under your identity ({actor.userId}).
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowConfirmModal(false)}
                disabled={isExecuting}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecuteBulkEnrolment}
                isLoading={isExecuting}
                leftIcon={<Check className="w-4 h-4" />}
              >
                Apply Bulk Enrolment
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
