import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Download,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  X,
  BookOpen,
  RefreshCw,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  AcademicCurriculumEntry,
  CsvCurriculumValidationResult,
} from '../../types/academic';
import {
  generateCurriculumCsvTemplate,
  parseCurriculumCsvText,
  validateCsvCurriculumRows,
  academicRepository,
} from '../../services/academicService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface CurriculumImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: (result: { added: number; updated: number }) => void;
}

export function CurriculumImportModal({
  isOpen,
  onClose,
  onImportComplete,
}: CurriculumImportModalProps) {
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [validationResult, setValidationResult] = useState<CsvCurriculumValidationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [importResult, setImportResult] = useState<{ added: number; updated: number } | null>(null);
  const [rawTextMode, setRawTextMode] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDownloadTemplate = () => {
    const content = generateCurriculumCsvTemplate();
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'curriculum_import_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const processCsv = async (text: string, name: string = 'pasted_data.csv') => {
    setFileName(name);
    setCsvContent(text);
    setImportResult(null);

    const parsedRows = parseCurriculumCsvText(text);
    const programs = await academicRepository.getAllClasses().catch(() => []);
    const validated = validateCsvCurriculumRows(parsedRows, programs);
    setValidationResult(validated);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      processCsv(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      processCsv(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleConfirmImport = async () => {
    if (!validationResult || validationResult.validRows.length === 0) return;

    setIsProcessing(true);
    try {
      const res = await academicRepository.importCurriculum(validationResult.validRows);
      setImportResult({ added: res.added, updated: res.updated });
      onImportComplete({ added: res.added, updated: res.updated });
    } catch (err) {
      console.error('Curriculum import failed:', err);
      alert('Failed to import curriculum. Please check your data format.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    setCsvContent('');
    setFileName('');
    setValidationResult(null);
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-[#e2e8f0] overflow-hidden my-auto animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-[#f8fafc]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">
                Import Program/Batch Curriculum CSV
              </h2>
              <p className="text-xs text-[#64748b]">
                Scoped by Degree Program and Admission Batch (Idempotent upsert & Google Sheets sync)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#64748b] hover:text-[#1e293b] hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Instructions and Template Download */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-blue-50/70 border border-blue-200/70">
            <div className="space-y-1">
              <div className="font-semibold text-blue-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-blue-700" />
                <span>Required CSV Column Headers</span>
              </div>
              <p className="text-blue-800 leading-relaxed">
                <code>Batch, Program, Course Code, Course Name, Type, Credits, Category, Basket</code>
              </p>
              <p className="text-[11px] text-blue-700">
                Categories: <strong>PC</strong> (Program Core), <strong>PE</strong> (Program Elective), <strong>OE</strong> (Open Elective), <strong>UC</strong> (University Core). Semester is deliberately excluded from curriculum definition.
              </p>
            </div>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleDownloadTemplate}
              leftIcon={<Download className="w-4 h-4" />}
              className="shrink-0 bg-white hover:bg-blue-50 text-blue-900 border-blue-300"
            >
              Download Template
            </Button>
          </div>

          {/* Import Success State */}
          {importResult && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                <div>
                  <div className="font-bold text-sm">Curriculum Imported Successfully!</div>
                  <div className="text-xs text-emerald-700 mt-0.5">
                    Added <strong>{importResult.added}</strong> new courses and updated{' '}
                    <strong>{importResult.updated}</strong> existing records. Persisted locally and queued for Google Sheets sync.
                  </div>
                </div>
              </div>
              <Button size="sm" variant="primary" onClick={onClose}>
                Done
              </Button>
            </div>
          )}

          {/* Upload Dropzone & Controls (Hidden when success) */}
          {!importResult && (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setRawTextMode(false)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      !rawTextMode
                        ? 'bg-[#1e3a8a] text-white'
                        : 'bg-slate-100 text-[#64748b] hover:bg-slate-200'
                    }`}
                  >
                    File Upload
                  </button>
                  <button
                    type="button"
                    onClick={() => setRawTextMode(true)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                      rawTextMode
                        ? 'bg-[#1e3a8a] text-white'
                        : 'bg-slate-100 text-[#64748b] hover:bg-slate-200'
                    }`}
                  >
                    Paste CSV Text
                  </button>
                </div>

                {validationResult && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleReset}
                    leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
                  >
                    Clear & Start Over
                  </Button>
                )}
              </div>

              {!rawTextMode ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-colors ${
                    isDragging
                      ? 'border-[#1e3a8a] bg-blue-50/50'
                      : 'border-[#cbd5e1] hover:border-[#94a3b8] bg-[#f8fafc]'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,text/csv"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <UploadCloud className="w-10 h-10 mx-auto text-[#64748b] mb-3" />
                  <p className="font-semibold text-[#1e293b]">
                    {fileName ? fileName : 'Click to browse or drag and drop your curriculum CSV'}
                  </p>
                  <p className="text-[11px] text-[#94a3b8] mt-1">
                    Standard comma-separated format (.csv) up to 5MB
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <textarea
                    rows={6}
                    value={csvContent}
                    onChange={(e) => processCsv(e.target.value, 'pasted_text.csv')}
                    placeholder="Batch,Program,Course Code,Course Name,Type,Credits,Category,Basket&#10;2026,B.Tech Computer Science & Engineering,CSE1001,Problem Solving & Algorithmic Programming,Core,4,PC,Program Core"
                    className="w-full p-3 font-mono text-xs border border-[#cbd5e1] rounded-xl bg-[#f8fafc] text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                  />
                </div>
              )}

              {/* Validation Feedback */}
              {validationResult && (
                <div className="space-y-4">
                  {/* Stats Bar */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-50 border border-[#e2e8f0] p-3 rounded-xl">
                      <div className="text-[11px] text-[#64748b] font-medium">Total Rows</div>
                      <div className="text-lg font-bold text-[#1e293b]">
                        {validationResult.totalRows}
                      </div>
                    </div>
                    <div className="bg-emerald-50/60 border border-emerald-200 p-3 rounded-xl">
                      <div className="text-[11px] text-emerald-800 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Valid Entries</span>
                      </div>
                      <div className="text-lg font-bold text-emerald-700">
                        {validationResult.validRows.length}
                      </div>
                    </div>
                    <div className="bg-rose-50/60 border border-rose-200 p-3 rounded-xl">
                      <div className="text-[11px] text-rose-800 font-medium flex items-center gap-1">
                        <XCircle className="w-3.5 h-3.5 text-rose-600" />
                        <span>Invalid / Errors</span>
                      </div>
                      <div className="text-lg font-bold text-rose-700">
                        {validationResult.invalidRows.length}
                      </div>
                    </div>
                  </div>

                  {/* Invalid Rows Table */}
                  {validationResult.invalidRows.length > 0 && (
                    <div className="border border-rose-200 rounded-xl overflow-hidden bg-rose-50/30">
                      <div className="px-4 py-2.5 bg-rose-100/70 border-b border-rose-200 font-semibold text-rose-900 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                          Rows requiring correction ({validationResult.invalidRows.length})
                        </span>
                        <span className="text-[11px] text-rose-700 font-normal">
                          These will be skipped during import
                        </span>
                      </div>
                      <div className="max-h-40 overflow-y-auto divide-y divide-rose-100">
                        {validationResult.invalidRows.map((err: any, idx: number) => (
                          <div key={idx} className="p-3 text-xs flex items-start gap-3">
                            <span className="font-mono font-bold text-rose-800 shrink-0">
                              Row {err.rowNumber}:
                            </span>
                            <div className="flex-1">
                              <span className="text-[#1e293b] font-medium">
                                {err.data?.CourseCode || err.data?.course_code || 'Missing Code'} — {err.data?.CourseName || err.data?.course_title || 'Missing Title'}
                              </span>
                              <div className="text-rose-700 mt-0.5 space-x-2">
                                {err.errors.map((msg: any, mIdx: number) => (
                                  <span key={mIdx} className="inline-block bg-white/80 border border-rose-200 rounded px-1.5 py-0.5 text-[11px]">
                                    {msg}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Valid Rows Preview */}
                  {validationResult.validRows.length > 0 && (
                    <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
                      <div className="px-4 py-2.5 bg-[#f8fafc] border-b border-[#e2e8f0] font-semibold text-[#1e293b] flex items-center justify-between">
                        <span>Preview of Valid Entries ({validationResult.validRows.length})</span>
                        <span className="text-[11px] text-[#64748b] font-normal">
                          Idempotent upsert by Program + Batch + Course Code
                        </span>
                      </div>
                      <div className="max-h-56 overflow-y-auto">
                        <table className="w-full text-left text-[11px] text-[#1e293b]">
                          <thead className="bg-[#f1f5f9] text-[#475569] font-bold border-b border-[#e2e8f0] sticky top-0">
                            <tr>
                              <th className="px-3 py-2">Batch</th>
                              <th className="px-3 py-2">Program</th>
                              <th className="px-3 py-2">Code</th>
                              <th className="px-3 py-2">Course Name</th>
                              <th className="px-3 py-2">Type</th>
                              <th className="px-3 py-2">Credits</th>
                              <th className="px-3 py-2">Category</th>
                              <th className="px-3 py-2">Basket</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#f1f5f9]">
                            {validationResult.validRows.slice(0, 25).map((row, idx) => (
                              <tr key={idx} className="hover:bg-slate-50">
                                <td className="px-3 py-1.5 font-medium">{row.batch}</td>
                                <td className="px-3 py-1.5 max-w-[140px] truncate" title={row.program}>
                                  {row.program}
                                </td>
                                <td className="px-3 py-1.5 font-mono font-bold text-[#1e3a8a]">
                                  {row.courseCode}
                                </td>
                                <td className="px-3 py-1.5 font-medium max-w-[180px] truncate" title={row.courseName}>
                                  {row.courseName}
                                </td>
                                <td className="px-3 py-1.5">{row.type}</td>
                                <td className="px-3 py-1.5 font-bold">{row.credits}</td>
                                <td className="px-3 py-1.5">
                                  <span className="px-1.5 py-0.5 rounded bg-slate-100 font-semibold text-[#475569]">
                                    {row.category}
                                  </span>
                                </td>
                                <td className="px-3 py-1.5 text-[#64748b]">{row.basket}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {validationResult.validRows.length > 25 && (
                          <div className="p-2 text-center text-[11px] text-[#64748b] bg-slate-50 border-t border-[#e2e8f0]">
                            ...and {validationResult.validRows.length - 25} more rows
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
          <Button variant="outline" size="sm" onClick={onClose}>
            {importResult ? 'Close' : 'Cancel'}
          </Button>

          {!importResult && (
            <Button
              variant="primary"
              size="sm"
              disabled={
                isProcessing ||
                !validationResult ||
                validationResult.validRows.length === 0
              }
              isLoading={isProcessing}
              onClick={handleConfirmImport}
              leftIcon={<UploadCloud className="w-4 h-4" />}
            >
              {validationResult && validationResult.validRows.length > 0
                ? `Confirm & Import ${validationResult.validRows.length} Courses`
                : 'Import Curriculum'}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
