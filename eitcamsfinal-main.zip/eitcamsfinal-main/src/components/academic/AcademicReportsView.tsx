import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  Users,
  Layers,
  Grid,
  BookOpen,
  UserCheck,
  CheckCircle2,
  Filter,
} from 'lucide-react';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  FacultyAssignment,
  AttendanceRecord,
  AcademicSession,
} from '../../types/academic';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface AcademicReportsViewProps {
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyEmployees: Employee[];
  assignments: FacultyAssignment[];
  students: Student[];
  attendanceRecords: AttendanceRecord[];
}

type ReportType =
  | 'students_by_class'
  | 'students_by_section'
  | 'faculty_assignments'
  | 'subject_assignments'
  | 'attendance_summary';

export function AcademicReportsView({
  currentSession,
  classes,
  sections,
  subjects,
  facultyEmployees,
  assignments,
  students,
  attendanceRecords,
}: AcademicReportsViewProps) {
  const [selectedReport, setSelectedReport] = useState<ReportType>('students_by_class');

  // CSV Export utility
  const exportToCsv = (filename: string, rows: (string | number)[][]) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      rows.map((e) => e.map((val) => `"${String(val).replace(/"/g, '""')}"`).join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link罕 = document.createElement('a');
    link罕.setAttribute('href', encodedUri);
    link罕.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link罕);
    link罕.click();
    document.body.removeChild(link罕);
  };

  const handleExportCurrent = () => {
    const dateStr = new Date().toISOString().split('T')[0];

    if (selectedReport === 'students_by_class') {
      const header = ['Registration No', 'Student Name', 'Program', 'Batch', 'Semester', 'Email', 'Mobile', 'Guardian', 'Account Status'];
      const data = students.map((s) => [
        s.registrationNumber,
        s.fullName,
        s.program || s.admissionClass,
        s.batch || s.section,
        s.currentSemester || 'Semester 1',
        s.email,
        s.mobile,
        s.guardianName || s.fatherName || '',
        s.accountStatus,
      ]);
      exportToCsv(`Students_By_Program_${dateStr}`, [header, ...data]);
    } else if (selectedReport === 'students_by_section') {
      const header = ['Program', 'Batch', 'Registration No', 'Student Name', 'Guardian', 'Mobile'];
      const data = students.map((s) => [
        s.program || s.admissionClass,
        s.batch || s.section,
        s.registrationNumber,
        s.fullName,
        s.guardianName || s.fatherName || '',
        s.mobile,
      ]);
      exportToCsv(`Students_By_Batch_${dateStr}`, [header, ...data]);
    } else if (selectedReport === 'faculty_assignments') {
      const header = ['Employee ID', 'Faculty Name', 'Program', 'Batch', 'Course', 'Course Code', 'Session', 'Status'];
      const data = assignments.map((a) => [
        a.employeeId || a.facultyId || '',
        a.facultyName || '',
        a.className || '',
        a.sectionName || a.section || '',
        a.subjectName || '',
        a.subjectCode || '',
        a.academicSession || a.academicYear || '',
        a.status || '',
      ]);
      exportToCsv(`Faculty_Course_Allocations_${dateStr}`, [header, ...data]);
    } else if (selectedReport === 'subject_assignments') {
      const header = ['Course ID', 'Course Code', 'Course Name', 'Offering Program', 'Type', 'Credits', 'Status'];
      const data = subjects.map((sub) => [
        sub.id || '',
        sub.code || '',
        sub.name || '',
        sub.className || '',
        sub.type || 'Core',
        sub.creditsOrPeriodsPerWeek || 4,
        sub.status || '',
      ]);
      exportToCsv(`Course_Curriculum_${dateStr}`, [header, ...data]);
    } else if (selectedReport === 'attendance_summary') {
      const header = ['Date', 'Registration No', 'Student Name', 'Program', 'Batch', 'Status', 'Recorded By', 'Remarks'];
      const dataRows = attendanceRecords.map((att) => [
        att.date || '',
        att.registrationNumber || att.registration_number || '',
        att.studentName || '',
        att.className || '',
        att.sectionName || '',
        att.status || '',
        att.recordedBy || '',
        att.remarks || '',
      ]);
      exportToCsv(`Attendance_Summary_${dateStr}`, [header, ...dataRows]);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs print:hidden">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#1e3a8a]" />
            <span>Institutional Academic Reports</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Audit academic rosters, curriculum distributions, faculty teaching allocations, and roll-call compliance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            leftIcon={<Printer className="w-4 h-4 text-[#64748b]" />}
          >
            Print Formatted
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleExportCurrent}
            leftIcon={<Download className="w-4 h-4" />}
          >
            Export to CSV
          </Button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#e2e8f0] pb-3 print:hidden">
        {[
          { id: 'students_by_class', label: 'Students by Program', icon: Layers },
          { id: 'students_by_section', label: 'Students by Batch', icon: Grid },
          { id: 'faculty_assignments', label: 'Faculty Course Allocations', icon: UserCheck },
          { id: 'subject_assignments', label: 'Course Curriculum', icon: BookOpen },
          { id: 'attendance_summary', label: 'Attendance Summary', icon: CheckCircle2 },
        ].map((tab) => {
          const Icon = tab.icon;
          const isSelected的的 = selectedReport === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSelectedReport(tab.id as ReportType)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                isSelected的的
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'bg-white border border-[#e2e8f0] text-[#64748b] hover:text-[#1e293b] hover:bg-[#f8fafc]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Report Printable Container */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs p-6 space-y-6">
        {/* Printable Report Header */}
        <div className="border-b border-[#e2e8f0] pb-4 flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-[#1e3a8a] uppercase tracking-wider">
              ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)
            </div>
            <h1 className="text-xl font-bold text-[#1e293b] mt-0.5">
              {selectedReport === 'students_by_class' && 'Program / Batch Student Enrollment Report'}
              {selectedReport === 'students_by_section' && 'Section-Wise Classroom Distribution Report'}
              {selectedReport === 'faculty_assignments' && 'Faculty Teaching Duty & Course Assignment Matrix'}
              {selectedReport === 'subject_assignments' && 'Institutional Course Syllabus & Course Register'}
              {selectedReport === 'attendance_summary' && 'Institutional Roll-Call & Attendance Summary'}
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Academic Session: <strong>{currentSession?.name || '2026–2027'}</strong> &bull; Generated on:{' '}
              {new Date().toLocaleDateString()}
            </p>
          </div>

          <div className="text-right text-xs text-[#64748b]">
            <Badge variant="blue">Official Academic Document</Badge>
          </div>
        </div>

        {/* 1. Students By Class / Program Report */}
        {selectedReport === 'students_by_class' && (
          <div className="space-y-6">
            {classes.map((cls) => {
              const classStudents = students.filter(
                (s) =>
                  (s.program && (s.program.toLowerCase() === cls.name.toLowerCase() || s.program.toLowerCase() === cls.id.toLowerCase())) ||
                  (s.admissionClass && (s.admissionClass.toLowerCase() === cls.name.toLowerCase() || s.admissionClass.toLowerCase() === cls.id.toLowerCase()))
              );

              return (
                <div key={cls.id} className="border border-[#e2e8f0] rounded-lg overflow-hidden">
                  <div className="bg-[#f8fafc] p-3 border-b border-[#e2e8f0] flex items-center justify-between text-xs">
                    <div className="font-bold text-[#1e293b] flex items-center gap-2">
                      <span>{cls.name}</span>
                      <Badge variant="slate">{cls.stream || 'General'}</Badge>
                    </div>
                    <span className="text-[#64748b]">
                      Total Enrolled: <strong className="text-[#1e293b]">{classStudents.length} Students</strong>
                    </span>
                  </div>

                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                      <tr>
                        <th className="py-2 px-3">Reg No.</th>
                        <th className="py-2 px-3">Student Name</th>
                        <th className="py-2 px-3">Batch / Section</th>
                        <th className="py-2 px-3">Guardian</th>
                        <th className="py-2 px-3">Contact</th>
                        <th className="py-2 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#f1f5f9]">
                      {classStudents.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-4 text-center text-[#94a3b8]">
                            No students enrolled in {cls.name} yet.
                          </td>
                        </tr>
                      ) : (
                        classStudents.map((st) => (
                          <tr key={st.id}>
                            <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">
                              {st.registrationNumber}
                            </td>
                            <td className="py-2 px-3 font-medium text-[#1e293b]">{st.fullName}</td>
                            <td className="py-2 px-3 font-bold">{st.batch || `Sec ${st.section}`}</td>
                            <td className="py-2 px-3 text-[#64748b]">
                              {st.guardianName || st.fatherName || 'Parent'}
                            </td>
                            <td className="py-2 px-3 text-[#64748b]">{st.mobile}</td>
                            <td className="py-2 px-3">
                              <Badge variant={st.accountStatus === 'active' ? 'emerald' : 'slate'}>
                                {st.accountStatus}
                              </Badge>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              );
            })}
          </div>
        )}

        {/* 2. Students By Section / Batch Report */}
        {selectedReport === 'students_by_section' && (
          <div className="space-y-6">
            {sections.map((sec) => {
              const secClass = (sec.className || '').toLowerCase();
              const secClassId = (sec.classId || '').toLowerCase();
              const secStudents = students.filter(
                (s) =>
                  ((s.program && (s.program.toLowerCase() === secClass || (secClassId && s.program.toLowerCase() === secClassId))) ||
                    (s.admissionClass && (s.admissionClass.toLowerCase() === secClass || (secClassId && s.admissionClass.toLowerCase() === secClassId)))) &&
                  ((s.batch && s.batch.toLowerCase() === sec.name.toLowerCase()) ||
                    (s.section && s.section.toLowerCase() === sec.name.toLowerCase()))
              );

              return (
                <div key={sec.id} className="border border-[#e2e8f0] rounded-lg overflow-hidden">
                  <div className="bg-[#f8fafc] p-3 border-b border-[#e2e8f0] flex items-center justify-between text-xs">
                    <div className="font-bold text-[#1e293b]">
                      {sec.className} - Batch {sec.name}{' '}
                      <span className="font-normal text-[#64748b]">
                        ({sec.roomNumber || 'Room TBD'} &bull; Cap: {sec.capacity || 35})
                      </span>
                    </div>
                    <span className="text-[#64748b]">
                      Headcount: <strong className="text-[#1e293b]">{secStudents.length} Students</strong>
                    </span>
                  </div>

                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                      <tr>
                        <th className="py-2 px-3">#</th>
                        <th className="py-2 px-3">Reg No.</th>
                        <th className="py-2 px-3">Student Name</th>
                        <th className="py-2 px-3">Parent / Guardian</th>
                        <th className="py-2 px-3">Contact</th>
                        <th className="py-2 px-3">Admission Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#f1f5f9]">
                      {secStudents.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-4 text-center text-[#94a3b8]">
                            No students enrolled in this section.
                          </td>
                        </tr>
                      ) : (
                        secStudents.map((st, i) => (
                          <tr key={st.id}>
                            <td className="py-2 px-3 text-[#64748b]">{i + 1}</td>
                            <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">
                              {st.registrationNumber}
                            </td>
                            <td className="py-2 px-3 font-medium text-[#1e293b]">{st.fullName}</td>
                            <td className="py-2 px-3 text-[#64748b]">
                              {st.guardianName || st.fatherName || 'Parent'}
                            </td>
                            <td className="py-2 px-3 text-[#64748b]">{st.mobile}</td>
                            <td className="py-2 px-3 text-[#64748b]">{st.admissionDate}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              );
            })}
          </div>
        )}

        {/* 3. Faculty Assignments Report */}
        {selectedReport === 'faculty_assignments' && (
          <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-3 px-4">Faculty ID</th>
                  <th className="py-3 px-4">Faculty Member Name</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Class & Section</th>
                  <th className="py-3 px-4">Subject Assigned</th>
                  <th className="py-3 px-4">Session</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {assignments.map((a) => (
                  <tr key={a.id} className="hover:bg-[#f8fafc]">
                    <td className="py-2.5 px-4 font-mono font-bold text-[#1e3a8a]">{a.employeeId}</td>
                    <td className="py-2.5 px-4 font-bold text-[#1e293b]">{a.facultyName}</td>
                    <td className="py-2.5 px-4 text-[#64748b]">{a.department || 'Academic Department'}</td>
                    <td className="py-2.5 px-4 font-medium text-[#1e293b]">
                      {a.className} - Sec {a.sectionName}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-[#1e293b]">
                      {a.subjectName} ({a.subjectCode || 'CORE'})
                    </td>
                    <td className="py-2.5 px-4">
                      <Badge variant="blue">{a.academicSession}</Badge>
                    </td>
                    <td className="py-2.5 px-4">
                      <Badge variant={a.status === 'active' ? 'emerald' : 'slate'}>{a.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. Subject Assignments Report */}
        {selectedReport === 'subject_assignments' && (
          <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-3 px-4">Subject ID</th>
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Subject Name</th>
                  <th className="py-3 px-4">Class</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4">Periods / Wk</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {subjects.map((sub) => (
                  <tr key={sub.id} className="hover:bg-[#f8fafc]">
                    <td className="py-2.5 px-4 font-mono text-[#64748b]">{sub.id}</td>
                    <td className="py-2.5 px-4 font-mono font-bold text-[#1e3a8a]">{sub.code}</td>
                    <td className="py-2.5 px-4 font-bold text-[#1e293b]">{sub.name}</td>
                    <td className="py-2.5 px-4">
                      <Badge variant="blue">{sub.className}</Badge>
                    </td>
                    <td className="py-2.5 px-4 text-[#1e293b]">{sub.type || 'Core'}</td>
                    <td className="py-2.5 px-4 font-medium">{sub.creditsOrPeriodsPerWeek || 5} periods</td>
                    <td className="py-2.5 px-4">
                      <Badge variant={sub.status === 'active' ? 'emerald' : 'slate'}>{sub.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 5. Attendance Summary Report */}
        {selectedReport === 'attendance_summary' && (
          <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
            <div className="p-3 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between text-xs">
              <span className="font-bold text-[#1e293b]">
                Total Logged Attendance Records: {attendanceRecords.length}
              </span>
              <span className="text-[#64748b]">Institutional Roll-Call Registry</span>
            </div>
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Reg No.</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Class & Sec</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Recorded By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {attendanceRecords.map((att) => (
                  <tr key={att.id}>
                    <td className="py-2 px-3 font-mono text-[#1e293b]">{att.date}</td>
                    <td className="py-2 px-3 font-mono font-bold text-[#1e3a8a]">
                      {att.registrationNumber}
                    </td>
                    <td className="py-2 px-3 font-medium text-[#1e293b]">{att.studentName}</td>
                    <td className="py-2 px-3">
                      {att.className} - {att.sectionName}
                    </td>
                    <td className="py-2 px-3">
                      <Badge
                        variant={
                          att.status === 'Present'
                            ? 'emerald'
                            : att.status === 'Late'
                            ? 'amber'
                            : att.status === 'Leave'
                            ? 'blue'
                            : 'slate'
                        }
                      >
                        {att.status}
                      </Badge>
                    </td>
                    <td className="py-2 px-3 text-[#64748b]">{att.recordedBy}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
