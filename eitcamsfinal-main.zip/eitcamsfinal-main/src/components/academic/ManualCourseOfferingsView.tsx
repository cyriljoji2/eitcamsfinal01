import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Filter,
  Users,
  Layers,
  Calendar,
  Clock,
  Building2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Eye,
  Edit2,
  UserPlus,
  UserMinus,
  ArrowRightLeft,
  X,
  FileSpreadsheet,
  AlertCircle,
  ShieldCheck,
  Check,
  Radio,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { AcademicClass, AcademicSection, AcademicSession, AcademicSubject } from '../../types/academic';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { CourseOfferingRecord, CourseEnrolmentRecord, TimetableSlotRecord, FacultyCourseRole } from '../../types/database';
import { academicRepository } from '../../services/academicService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { IndividualEnrolmentModal } from './manual/IndividualEnrolmentModal';
import { BulkEnrolmentSection } from './manual/BulkEnrolmentSection';
import { CsvRegistrationImportSection } from './manual/CsvRegistrationImportSection';
import { TimetableReviewPublishSection } from './manual/TimetableReviewPublishSection';

interface ManualCourseOfferingsViewProps {
  user: UserSession;
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyEmployees: Employee[];
  students: Student[];
  onRefresh?: () => void;
}

export function ManualCourseOfferingsView({
  user,
  currentSession,
  classes,
  sections,
  subjects,
  facultyEmployees,
  students,
  onRefresh,
}: ManualCourseOfferingsViewProps) {
  // Navigation sub-tab inside module
  const [activeSubTab, setActiveSubTab] = useState<'offerings' | 'enrolments' | 'bulk-enrolment' | 'csv-import' | 'timetable'>('offerings');

  // Individual Student Enrolment Modal State
  const [isIndividualEnrolModalOpen, setIsIndividualEnrolModalOpen] = useState(false);
  const [individualEnrolInitialOffering, setIndividualEnrolInitialOffering] = useState<CourseOfferingRecord | null>(null);

  // Core data states
  const [offerings, setOfferings] = useState<CourseOfferingRecord[]>([]);
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [timetableSlots, setTimetableSlots] = useState<TimetableSlotRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Notifications
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAyFilter, setSelectedAyFilter] = useState<string>('all');
  const [selectedSemFilter, setSelectedSemFilter] = useState<string>('all');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState<string>('all');
  const [selectedProgFilter, setSelectedProgFilter] = useState<string>('all');
  const [selectedCourseFilter, setSelectedCourseFilter] = useState<string>('all');
  const [selectedFacultyFilter, setSelectedFacultyFilter] = useState<string>('all');
  const [selectedSectionFilter, setSelectedSectionFilter] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingOffering, setEditingOffering] = useState<CourseOfferingRecord | null>(null);
  const [inspectingOffering, setInspectingOffering] = useState<CourseOfferingRecord | null>(null);

  // Cancel Offering Modal
  const [cancellingOffering, setCancellingOffering] = useState<CourseOfferingRecord | null>(null);
  const [cancelReason, setCancelReason] = useState('');

  // Manual Enrolment Modal
  const [enrolTargetOffering, setEnrolTargetOffering] = useState<CourseOfferingRecord | null>(null);
  const [selectedStudentToEnrol, setSelectedStudentToEnrol] = useState('');
  const [isSubmittingEnrol, setIsSubmittingEnrol] = useState(false);

  // Student Withdrawal Modal
  const [withdrawingEnrolment, setWithdrawingEnrolment] = useState<CourseEnrolmentRecord | null>(null);
  const [withdrawalReason, setWithdrawalReason] = useState('');

  // Form State for Create / Edit Offering
  const [formCourseCode, setFormCourseCode] = useState('');
  const [formProgramme, setFormProgramme] = useState('BTECH-CSE');
  const [formDepartment, setFormDepartment] = useState('CSE');
  const [formSemester, setFormSemester] = useState<number>(3);
  const [formAcademicYear, setFormAcademicYear] = useState(currentSession?.id || '2026-2027');
  const [formSection, setFormSection] = useState('A');
  const [formBatch, setFormBatch] = useState('2026');
  const [formFacultyId, setFormFacultyId] = useState('');
  const [formMaxCapacity, setFormMaxCapacity] = useState<number>(60);
  const [formRoom, setFormRoom] = useState('CR-101');
  const [formSlotDay, setFormSlotDay] = useState('MONDAY');
  const [formSlotStartTime, setFormSlotStartTime] = useState('09:00');
  const [formSlotEndTime, setFormSlotEndTime] = useState('10:00');
  const [formStartDate, setFormStartDate] = useState('2026-07-15');
  const [formEndDate, setFormEndDate] = useState('2026-11-30');
  const [formStatus, setFormStatus] = useState<'DRAFT' | 'PUBLISHED'>('PUBLISHED');
  const [isSubmittingForm, setIsSubmittingForm] = useState(false);

  // Actor payload for service-level security
  const actor = useMemo(() => ({
    userId: user.username || user.id || 'academicoffice',
    role: user.role || 'OFFICE_STAFF',
    employeeId: user.id,
  }), [user]);

  // Load all offerings, enrolments, and timetable slots
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [offeringsData, enrolmentsData, timetableData] = await Promise.all([
        academicRepository.getCourseOfferings(),
        academicRepository.getEnrolments(undefined, actor),
        academicRepository.getTimetable(),
      ]);
      setOfferings(offeringsData);
      setEnrolments(enrolmentsData);
      setTimetableSlots(timetableData);
    } catch (err: any) {
      console.error('Failed to load course offerings data:', err);
      setErrorMessage(err?.message || 'Failed to load offerings');
    } finally {
      setIsLoading(false);
    }
  }, [actor]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Approved curriculum courses (source for offerings)
  const curriculumCourses = useMemo(() => {
    return subjects.filter((s) => s.status !== 'inactive');
  }, [subjects]);

  // Handle course selection in create/edit modal to auto-populate metadata
  const handleSelectCurriculumCourse = (code: string) => {
    setFormCourseCode(code);
    const selected = curriculumCourses.find((c) => c.code === code);
    if (selected) {
      if (selected.department) setFormDepartment(selected.department);
      if (typeof selected.semester === 'number') setFormSemester(selected.semester);
      if (selected.classId) setFormProgramme(selected.classId);
    }
  };

  // Filtered offerings directory
  const filteredOfferings = useMemo(() => {
    return offerings.filter((o) => {
      if (selectedAyFilter !== 'all' && o.academic_year !== selectedAyFilter) return false;
      if (selectedSemFilter !== 'all' && String(o.semester) !== selectedSemFilter) return false;
      if (selectedDeptFilter !== 'all' && o.department !== selectedDeptFilter) return false;
      if (selectedProgFilter !== 'all' && o.programme_code !== selectedProgFilter) return false;
      if (selectedCourseFilter !== 'all' && o.course_code !== selectedCourseFilter) return false;
      if (selectedFacultyFilter !== 'all' && o.assigned_faculty_id !== selectedFacultyFilter) return false;
      if (selectedSectionFilter !== 'all' && o.section !== selectedSectionFilter) return false;
      if (selectedStatusFilter !== 'all' && o.status !== selectedStatusFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          o.course_code.toLowerCase().includes(q) ||
          o.course_title.toLowerCase().includes(q) ||
          (o.assigned_faculty_name && o.assigned_faculty_name.toLowerCase().includes(q)) ||
          o.section.toLowerCase().includes(q) ||
          o.department.toLowerCase().includes(q) ||
          o.programme_code.toLowerCase().includes(q) ||
          (o.room && o.room.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [
    offerings,
    selectedAyFilter,
    selectedSemFilter,
    selectedDeptFilter,
    selectedProgFilter,
    selectedCourseFilter,
    selectedFacultyFilter,
    selectedSectionFilter,
    selectedStatusFilter,
    searchQuery,
  ]);

  // Map of offering_id -> count of active enrolments
  const offeringEnrolmentCounts = useMemo(() => {
    const map = new Map<string, number>();
    enrolments.forEach((e) => {
      if (e.enrolment_status === 'ACTIVE' && e.offering_id) {
        map.set(e.offering_id, (map.get(e.offering_id) || 0) + 1);
      }
    });
    return map;
  }, [enrolments]);

  // Eligible teaching faculty (only active teaching employees)
  const eligibleFaculty = useMemo(() => {
    return facultyEmployees.filter(
      (f) =>
        f.status !== 'inactive' &&
        f.status !== 'INACTIVE' &&
        (f as any).employment_status !== 'INACTIVE' &&
        (f as any).employment_status !== 'SUSPENDED' &&
        (f as any).employment_status !== 'TERMINATED' &&
        (f.isTeachingStaff || f.role === 'faculty' || (f.roles && f.roles.includes('FACULTY')) || (f as any).category === 'TEACHING')
    );
  }, [facultyEmployees]);

  // Check for timetable conflict helper
  const detectTimetableConflict = (
    day: string,
    startTime: string,
    endTime: string,
    room: string,
    facultyId?: string,
    section?: string,
    excludeOfferingId?: string
  ): string | null => {
    for (const slot of timetableSlots) {
      if (slot.day_of_week === day && ((slot.status as string) === 'SCHEDULED' || slot.status === 'ACTIVE')) {
        const timeOverlap = !(endTime <= slot.start_time || startTime >= slot.end_time);
        if (timeOverlap) {
          if (room && (slot.room_number || slot.room || '').toLowerCase() === room.toLowerCase()) {
            return `Room Conflict: Room '${room}' is already booked on ${day} from ${slot.start_time} to ${slot.end_time} for ${slot.course_code} (${slot.section}).`;
          }
          if (facultyId && slot.faculty_id === facultyId) {
            return `Faculty Conflict: Assigned instructor is already scheduled on ${day} from ${slot.start_time} to ${slot.end_time} for ${slot.course_code}.`;
          }
          if (section && slot.section === section && slot.semester === formSemester) {
            return `Section Conflict: Section '${section}' already has a lecture on ${day} from ${slot.start_time} to ${slot.end_time}.`;
          }
        }
      }
    }
    return null;
  };

  // Open Create Modal
  const handleOpenCreateModal = () => {
    setEditingOffering(null);
    const defaultCourse = curriculumCourses[0]?.code || 'CS201';
    handleSelectCurriculumCourse(defaultCourse);
    setFormSection('A');
    setFormBatch('2026');
    setFormFacultyId(eligibleFaculty[0]?.id || '');
    setFormMaxCapacity(60);
    setFormRoom('CR-101');
    setFormSlotDay('MONDAY');
    setFormSlotStartTime('09:00');
    setFormSlotEndTime('10:00');
    setFormStatus('PUBLISHED');
    setIsCreateModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (offering: CourseOfferingRecord) => {
    setEditingOffering(offering);
    setFormCourseCode(offering.course_code);
    setFormProgramme(offering.programme_code);
    setFormDepartment(offering.department);
    setFormSemester(offering.semester);
    setFormAcademicYear(offering.academic_year);
    setFormSection(offering.section);
    setFormBatch(offering.batch || '2026');
    setFormFacultyId(offering.assigned_faculty_id || '');
    setFormMaxCapacity(offering.max_capacity || 60);
    setFormRoom(offering.room || 'CR-101');
    setFormStatus(offering.status === 'DRAFT' ? 'DRAFT' : 'PUBLISHED');
    setIsCreateModalOpen(true);
  };

  // Submit Create or Edit Offering
  const handleSubmitOffering = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCourseCode || !formSection) {
      setErrorMessage('Course from approved curriculum and section are required.');
      return;
    }

    const selectedCourse = curriculumCourses.find((c) => c.code === formCourseCode);
    if (!selectedCourse) {
      setErrorMessage('Selected course does not exist in the approved curriculum.');
      return;
    }

    // Timetable conflict check
    const conflict = detectTimetableConflict(
      formSlotDay,
      formSlotStartTime,
      formSlotEndTime,
      formRoom,
      formFacultyId || undefined,
      formSection,
      editingOffering?.offering_id
    );

    if (conflict) {
      setErrorMessage(conflict);
      return;
    }

    setIsSubmittingForm(true);
    setErrorMessage(null);

    try {
      const faculty = eligibleFaculty.find((f) => f.id === formFacultyId);

      if (formStatus === 'PUBLISHED' && !formFacultyId) {
        setErrorMessage('A valid teaching faculty member is required to publish an offering. Select an instructor or save as DRAFT.');
        setIsSubmittingForm(false);
        return;
      }

      if (editingOffering) {
        // Edit existing offering
        const updated = await academicRepository.updateCourseOffering(
          editingOffering.offering_id,
          {
            programme_code: formProgramme,
            department: formDepartment,
            semester: formSemester,
            section: formSection,
            batch: formBatch,
            assigned_faculty_id: faculty?.id,
            assigned_faculty_name: faculty?.fullName,
            max_capacity: Number(formMaxCapacity) || 60,
            room: formRoom,
            timetable_slots: formSlotDay && formSlotStartTime && formSlotEndTime ? [`${formSlotDay} ${formSlotStartTime}-${formSlotEndTime}`] : undefined,
            start_date: formStartDate,
            end_date: formEndDate,
            status: formStatus,
          },
          actor
        );
        if (updated.status === 'DRAFT') {
          setSuccessMessage('Offering saved as draft');
        } else {
          setSuccessMessage('Offering published successfully');
        }
      } else {
        // Create new offering with atomic timetable scheduling
        const timetableData = (formRoom && formSlotStartTime && formSlotEndTime)
          ? {
              day_of_week: formSlotDay as any,
              start_time: formSlotStartTime,
              end_time: formSlotEndTime,
              room: formRoom,
            }
          : undefined;

        const result = await academicRepository.createCourseOfferingWithTimetable(
          {
            course_code: selectedCourse.code,
            course_title: selectedCourse.name,
            department: formDepartment,
            programme_code: formProgramme,
            academic_year: formAcademicYear,
            semester: formSemester,
            section: formSection,
            batch: formBatch,
            assigned_faculty_id: faculty?.id,
            assigned_faculty_name: faculty?.fullName,
            credits: selectedCourse.credits,
            course_type: selectedCourse.type,
            max_capacity: Number(formMaxCapacity) || 60,
            room: formRoom,
            timetable_slots: timetableData ? [`${formSlotDay} ${formSlotStartTime}-${formSlotEndTime}`] : undefined,
            start_date: formStartDate,
            end_date: formEndDate,
            status: formStatus,
          },
          timetableData,
          actor
        );

        if (result.offering.status === 'DRAFT') {
          setSuccessMessage('Offering saved as draft');
        } else {
          setSuccessMessage('Offering published successfully');
        }
      }

      setIsCreateModalOpen(false);
      await loadData();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to save course offering.');
    } finally {
      setIsSubmittingForm(false);
    }
  };

  // Publish offering
  const handlePublish = async (offering: CourseOfferingRecord) => {
    try {
      await academicRepository.publishCourseOffering(offering.offering_id, actor);
      setSuccessMessage('Offering published successfully');
      await loadData();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to publish offering');
    }
  };

  // Close offering
  const handleClose = async (offering: CourseOfferingRecord) => {
    try {
      await academicRepository.closeCourseOffering(offering.offering_id, actor);
      setSuccessMessage('Offering closed for enrolment');
      await loadData();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to close offering');
    }
  };

  // Cancel offering
  const handleExecuteCancel = async () => {
    if (!cancellingOffering || !cancelReason.trim()) {
      setErrorMessage('Please state a valid reason for cancelling this course offering.');
      return;
    }
    try {
      await academicRepository.cancelCourseOffering(cancellingOffering.offering_id, cancelReason.trim(), actor);
      setSuccessMessage('Offering cancelled');
      setCancellingOffering(null);
      setCancelReason('');
      await loadData();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to cancel offering');
    }
  };

  // Execute manual student enrolment
  const handleExecuteEnrolment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!enrolTargetOffering || !selectedStudentToEnrol) {
      setErrorMessage('Please select a student to enrol.');
      return;
    }

    // Capacity limit check
    const currentEnrolledCount = offeringEnrolmentCounts.get(enrolTargetOffering.offering_id) || 0;
    const maxCapacity = enrolTargetOffering.max_capacity || 60;
    if (currentEnrolledCount >= maxCapacity) {
      setErrorMessage(
        `Offering Capacity Reached: Cannot enrol student. Max capacity of ${maxCapacity} seats has been met.`
      );
      return;
    }

    setIsSubmittingEnrol(true);
    setErrorMessage(null);

    try {
      const studentObj = students.find((s) => s.id === selectedStudentToEnrol);
      if (!studentObj) throw new Error('Selected student not found.');

      await academicRepository.enrolStudent(
        {
          student_id: studentObj.id,
          offering_id: enrolTargetOffering.offering_id,
          course_code: enrolTargetOffering.course_code,
          section: enrolTargetOffering.section,
          semester: enrolTargetOffering.semester,
          academic_year: enrolTargetOffering.academic_year,
        },
        actor
      );

      setSuccessMessage(
        `Student ${studentObj.fullName} (${studentObj.registrationNumber}) manually enrolled into ${enrolTargetOffering.course_code} (Section ${enrolTargetOffering.section}).`
      );
      setSelectedStudentToEnrol('');
      await loadData();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to enrol student');
    } finally {
      setIsSubmittingEnrol(false);
    }
  };

  // Execute student withdrawal
  const handleExecuteWithdrawal = async () => {
    if (!withdrawingEnrolment || !withdrawalReason.trim()) {
      setErrorMessage('A withdrawal justification reason is required.');
      return;
    }

    try {
      await academicRepository.withdrawStudent(withdrawingEnrolment.enrolment_id, withdrawalReason.trim(), actor);
      setSuccessMessage(
        `Student ${withdrawingEnrolment.student_name} (${withdrawingEnrolment.student_registration_number}) withdrawn from ${withdrawingEnrolment.course_code}. Record preserved in audit.`
      );
      setWithdrawingEnrolment(null);
      setWithdrawalReason('');
      await loadData();
      if (onRefresh) onRefresh();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to withdraw student');
    }
  };

  return (
    <div className="space-y-6">
      {/* Module Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#1e3a8a]" />
              <span>Manual Course Offerings</span>
            </h2>
            <Badge variant="blue">Academic Office Authority</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Centrally select approved curriculum courses, establish term offerings, assign faculty, schedule rooms, and control student enrolments.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setIndividualEnrolInitialOffering(null);
              setIsIndividualEnrolModalOpen(true);
            }}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Individual Enrolment
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleOpenCreateModal}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Create Course Offering
          </Button>
        </div>
      </div>

      {/* Success Banner */}
      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold text-xs cursor-pointer ml-3 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="text-rose-700 hover:text-rose-900 font-bold text-xs cursor-pointer ml-3 shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl max-w-fit overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveSubTab('offerings')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeSubTab === 'offerings' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Active Offerings Directory ({offerings.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('enrolments')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeSubTab === 'enrolments' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Student Enrolments ({enrolments.filter((e) => e.enrolment_status === 'ACTIVE').length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('bulk-enrolment')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeSubTab === 'bulk-enrolment' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Bulk Enrolment</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('csv-import')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeSubTab === 'csv-import' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>CSV Import (FFCS)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('timetable')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            activeSubTab === 'timetable' ? 'bg-white text-[#1E3A8A] shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Timetable & Publication</span>
        </button>
      </div>

      {/* =========================================================================
          SUB-TAB 1: OFFERINGS DIRECTORY
         ========================================================================= */}
      {activeSubTab === 'offerings' && (
        <div className="space-y-4">
          {/* Comprehensive 8-Level Filters Bar */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search code, course, faculty..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 focus:outline-none focus:border-[#1E3A8A]"
                />
              </div>

              {/* Academic Year Filter */}
              <div>
                <select
                  value={selectedAyFilter}
                  onChange={(e) => setSelectedAyFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Academic Years</option>
                  <option value="2026-2027">2026–2027</option>
                  <option value="2025-2026">2025–2026</option>
                </select>
              </div>

              {/* Semester Filter */}
              <div>
                <select
                  value={selectedSemFilter}
                  onChange={(e) => setSelectedSemFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Semesters</option>
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((s) => (
                    <option key={s} value={String(s)}>Semester {s}</option>
                  ))}
                </select>
              </div>

              {/* Department Filter */}
              <div>
                <select
                  value={selectedDeptFilter}
                  onChange={(e) => setSelectedDeptFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Departments</option>
                  <option value="CSE">CSE</option>
                  <option value="ECE">ECE</option>
                  <option value="MECH">MECH</option>
                </select>
              </div>

              {/* Programme Filter */}
              <div>
                <select
                  value={selectedProgFilter}
                  onChange={(e) => setSelectedProgFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Programmes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.code || c.name}>{c.name}</option>
                  ))}
                </select>
              </div>

              {/* Faculty Filter */}
              <div>
                <select
                  value={selectedFacultyFilter}
                  onChange={(e) => setSelectedFacultyFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Instructors</option>
                  {eligibleFaculty.map((f) => (
                    <option key={f.id} value={f.id}>{f.fullName}</option>
                  ))}
                </select>
              </div>

              {/* Section Filter */}
              <div>
                <select
                  value={selectedSectionFilter}
                  onChange={(e) => setSelectedSectionFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Sections</option>
                  {['A', 'B', 'C', 'D'].map((sec) => (
                    <option key={sec} value={sec}>Section {sec}</option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <select
                  value={selectedStatusFilter}
                  onChange={(e) => setSelectedStatusFilter(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg text-xs bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                >
                  <option value="all">All Lifecycle Statuses</option>
                  <option value="PUBLISHED">PUBLISHED (Active to Students)</option>
                  <option value="DRAFT">DRAFT</option>
                  <option value="CLOSED">CLOSED</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>
            </div>
          </div>

          {/* Offerings Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#f8fafc] text-[#475569] text-xs font-semibold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-4 py-3">Offering ID / Course</th>
                    <th className="px-4 py-3">Dept & Term</th>
                    <th className="px-4 py-3">Sec</th>
                    <th className="px-4 py-3">Assigned Faculty</th>
                    <th className="px-4 py-3">Capacity & Seats</th>
                    <th className="px-4 py-3">Room / Slot</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9] text-[#1e293b]">
                  {filteredOfferings.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-xs text-[#94a3b8]">
                        No course offerings match the active criteria. Click "Create Course Offering" above.
                      </td>
                    </tr>
                  ) : (
                    filteredOfferings.map((offering) => {
                      const enrolledCount = offeringEnrolmentCounts.get(offering.offering_id) || 0;
                      const maxCapacity = offering.max_capacity || 60;
                      const fillPercent = Math.min(100, Math.round((enrolledCount / maxCapacity) * 100));

                      return (
                        <tr key={offering.offering_id} className="hover:bg-slate-50/70 transition-colors">
                          {/* Course & ID */}
                          <td className="px-4 py-3.5">
                            <div className="font-bold text-[#1e3a8a] text-xs font-mono">{offering.course_code}</div>
                            <div className="text-xs font-semibold text-[#1e293b]">{offering.course_title}</div>
                            <div className="text-[11px] text-slate-400 font-mono">{offering.offering_id}</div>
                          </td>

                          {/* Dept & Term */}
                          <td className="px-4 py-3.5 text-xs">
                            <div className="font-semibold text-slate-700">{offering.department}</div>
                            <div className="text-slate-500">Sem {offering.semester} ({offering.academic_year})</div>
                          </td>

                          {/* Section */}
                          <td className="px-4 py-3.5">
                            <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-slate-100 text-slate-800">
                              {offering.section}
                            </span>
                          </td>

                          {/* Faculty */}
                          <td className="px-4 py-3.5 text-xs">
                            {offering.assigned_faculty_name ? (
                              <div>
                                <div className="font-semibold text-slate-800">{offering.assigned_faculty_name}</div>
                                <div className="text-[11px] text-slate-400 font-mono">{offering.assigned_faculty_id}</div>
                              </div>
                            ) : (
                              <span className="text-amber-600 italic text-[11px]">Unassigned</span>
                            )}
                          </td>

                          {/* Capacity & Seats */}
                          <td className="px-4 py-3.5 text-xs min-w-[140px]">
                            <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                              <span className="font-semibold text-slate-700">{enrolledCount} enrolled</span>
                              <span className="text-slate-400">/ {maxCapacity}</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  fillPercent >= 100 ? 'bg-rose-500' : fillPercent >= 80 ? 'bg-amber-500' : 'bg-[#1e3a8a]'
                                }`}
                                style={{ width: `${fillPercent}%` }}
                              />
                            </div>
                          </td>

                          {/* Room / Slot */}
                          <td className="px-4 py-3.5 text-xs">
                            <div className="font-medium text-slate-800">{offering.room || 'Room TBD'}</div>
                            <div className="text-[11px] text-slate-500 truncate max-w-[120px]">
                              {offering.timetable_slots?.[0] || 'Schedule TBD'}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="px-4 py-3.5">
                            <Badge
                              variant={
                                offering.status === 'PUBLISHED' || offering.status === 'ACTIVE'
                                  ? 'emerald'
                                  : offering.status === 'DRAFT'
                                  ? 'amber'
                                  : offering.status === 'CLOSED'
                                  ? 'slate'
                                  : 'rose'
                              }
                            >
                              {offering.status}
                            </Badge>
                          </td>

                          {/* Actions */}
                          <td className="px-4 py-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Details button */}
                              <button
                                type="button"
                                onClick={() => setInspectingOffering(offering)}
                                className="p-1.5 rounded-lg text-slate-500 hover:text-[#1e3a8a] hover:bg-slate-100 transition-colors cursor-pointer"
                                title="View Offering Details & Enrolled Students"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              {/* Enrol button */}
                              {offering.status !== 'CANCELLED' && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setIndividualEnrolInitialOffering(offering);
                                    setIsIndividualEnrolModalOpen(true);
                                  }}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 transition-colors cursor-pointer"
                                  title="Enrol Student Manually"
                                >
                                  <UserPlus className="w-4 h-4" />
                                </button>
                              )}

                              {/* Edit button */}
                              {offering.status !== 'CANCELLED' && (
                                <button
                                  type="button"
                                  onClick={() => handleOpenEditModal(offering)}
                                  className="p-1.5 rounded-lg text-slate-500 hover:text-[#1e3a8a] hover:bg-slate-100 transition-colors cursor-pointer"
                                  title="Edit Offering Details"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                              )}

                              {/* Lifecycle buttons */}
                              {offering.status === 'DRAFT' && (
                                <button
                                  type="button"
                                  onClick={() => handlePublish(offering)}
                                  className="px-2 py-1 text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md hover:bg-emerald-100 cursor-pointer"
                                >
                                  Publish
                                </button>
                              )}

                              {offering.status === 'PUBLISHED' && (
                                <button
                                  type="button"
                                  onClick={() => handleClose(offering)}
                                  className="px-2 py-1 text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-200 rounded-md hover:bg-slate-200 cursor-pointer"
                                >
                                  Close
                                </button>
                              )}

                              {offering.status !== 'CANCELLED' && (
                                <button
                                  type="button"
                                  onClick={() => setCancellingOffering(offering)}
                                  className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                  title="Cancel Offering"
                                >
                                  <XCircle className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 2: STUDENT ENROLMENTS LEDGER
         ========================================================================= */}
      {activeSubTab === 'enrolments' && (
        <div className="space-y-4">
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-slate-800">Authoritative Student Enrolment Ledger</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage student course seats, transfer sections, and withdraw students under authorized Academic Office procedures.
              </p>
            </div>
            <div className="text-xs font-mono text-slate-500">
              Total Enrolments: {enrolments.length} | Active: {enrolments.filter((e) => e.enrolment_status === 'ACTIVE').length}
            </div>
          </div>

          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-[#f8fafc] text-[#475569] text-xs font-semibold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-4 py-3">Enrolment ID</th>
                    <th className="px-4 py-3">Student Name & Registration</th>
                    <th className="px-4 py-3">Course</th>
                    <th className="px-4 py-3">Sec</th>
                    <th className="px-4 py-3">Enrolled At</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9] text-[#1e293b]">
                  {enrolments.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-xs text-[#94a3b8]">
                        No student enrolments recorded.
                      </td>
                    </tr>
                  ) : (
                    enrolments.map((enr) => (
                      <tr key={enr.enrolment_id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-4 py-3.5 font-mono text-xs font-semibold text-[#1e3a8a]">
                          {enr.enrolment_id}
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="font-semibold text-xs text-[#1e293b]">{enr.student_name}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{enr.student_registration_number}</div>
                        </td>
                        <td className="px-4 py-3.5 text-xs">
                          <span className="font-bold font-mono text-[#1e3a8a]">{enr.course_code}</span>
                          <span className="text-slate-500 ml-1.5">{enr.course_title}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-slate-100 text-slate-800">
                            {enr.section}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-xs text-slate-500">
                          {new Date(enr.enrolled_at).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3.5">
                          <Badge
                            variant={
                              enr.enrolment_status === 'ACTIVE'
                                ? 'emerald'
                                : enr.enrolment_status === 'TRANSFERRED'
                                ? 'amber'
                                : 'rose'
                            }
                          >
                            {enr.enrolment_status}
                          </Badge>
                        </td>
                        <td className="px-4 py-3.5 text-right">
                          {enr.enrolment_status === 'ACTIVE' && (
                            <button
                              type="button"
                              onClick={() => setWithdrawingEnrolment(enr)}
                              className="px-2.5 py-1 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-md hover:bg-rose-100 font-semibold cursor-pointer"
                            >
                              Withdraw
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-TAB 3: PROGRAMME-WISE BULK ENROLMENT
         ========================================================================= */}
      {activeSubTab === 'bulk-enrolment' && (
        <BulkEnrolmentSection
          offerings={offerings}
          students={students}
          currentSession={currentSession}
          classes={classes}
          sections={sections}
          actor={actor}
          onSuccess={(msg) => {
            setSuccessMessage(msg);
            loadData();
          }}
          onError={(msg) => setErrorMessage(msg)}
          onRefresh={loadData}
        />
      )}

      {/* =========================================================================
          SUB-TAB 4: CSV REGISTRATION IMPORT (FFCS CONTRACT)
         ========================================================================= */}
      {activeSubTab === 'csv-import' && (
        <CsvRegistrationImportSection
          actor={actor}
          onSuccess={(msg) => {
            setSuccessMessage(msg);
            loadData();
          }}
          onError={(msg) => setErrorMessage(msg)}
          onRefresh={loadData}
        />
      )}

      {/* =========================================================================
          SUB-TAB 5: AUTHORITATIVE TIMETABLE CONFLICT REVIEW & PUBLICATION
         ========================================================================= */}
      {activeSubTab === 'timetable' && (
        <TimetableReviewPublishSection
          offerings={offerings}
          timetableSlots={timetableSlots}
          currentSession={currentSession}
          classes={classes}
          sections={sections}
          actor={actor}
          onSuccess={(msg) => {
            setSuccessMessage(msg);
            loadData();
          }}
          onError={(msg) => setErrorMessage(msg)}
          onRefresh={loadData}
        />
      )}

      {/* =========================================================================
          MODAL 1: CREATE / EDIT COURSE OFFERING
         ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#cbd5e1] animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#1e293b]">
                    {editingOffering ? `Edit Course Offering: ${editingOffering.offering_id}` : 'Create Course Offering'}
                  </h3>
                  <p className="text-xs text-[#64748b]">
                    Originates directly from approved institutional curriculum.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitOffering} className="p-5 space-y-4">
              {/* Select Course from Curriculum */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  1. Select Course from Approved Curriculum *
                </label>
                <select
                  disabled={Boolean(editingOffering)}
                  value={formCourseCode}
                  onChange={(e) => handleSelectCurriculumCourse(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300 font-semibold text-slate-800 focus:outline-none focus:border-[#1E3A8A] disabled:opacity-60"
                  required
                >
                  {curriculumCourses.map((c) => (
                    <option key={c.id} value={c.code}>
                      {c.code} &mdash; {c.name} ({c.credits} Credits &bull; {c.department})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Authoritative title, credits, and syllabus originate from Course Curriculum and cannot be tampered with here.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Programme */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Programme *</label>
                  <select
                    value={formProgramme}
                    onChange={(e) => setFormProgramme(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300 font-medium"
                    required
                  >
                    {classes.map((cls) => (
                      <option key={cls.id} value={cls.code || cls.name}>
                        {cls.name} ({cls.code || cls.id})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Section */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Class Section *</label>
                  <select
                    value={formSection}
                    onChange={(e) => setFormSection(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300 font-medium"
                    required
                  >
                    {['A', 'B', 'C', 'D'].map((sec) => (
                      <option key={sec} value={sec}>Section {sec}</option>
                    ))}
                  </select>
                </div>

                {/* Academic Year */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year *</label>
                  <input
                    type="text"
                    value={formAcademicYear}
                    onChange={(e) => setFormAcademicYear(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>

                {/* Semester */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Semester (1-8) *</label>
                  <input
                    type="number"
                    min={1}
                    max={8}
                    value={formSemester}
                    onChange={(e) => setFormSemester(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>
              </div>

              {/* Faculty Assignment */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  2. Assign Course Instructor (Teaching Faculty Only)
                </label>
                <select
                  value={formFacultyId}
                  onChange={(e) => setFormFacultyId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300 font-semibold text-slate-800"
                >
                  <option value="">-- No Faculty Assigned Yet --</option>
                  {eligibleFaculty.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} &bull; Dept of {f.department} ({f.designation})
                    </option>
                  ))}
                </select>
              </div>

              {/* Capacity, Room, Timetable */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Max Capacity (Seats) *</label>
                  <input
                    type="number"
                    min={1}
                    max={300}
                    value={formMaxCapacity}
                    onChange={(e) => setFormMaxCapacity(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Classroom / Hall *</label>
                  <input
                    type="text"
                    value={formRoom}
                    onChange={(e) => setFormRoom(e.target.value)}
                    placeholder="e.g. CR-101"
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Day of Week *</label>
                  <select
                    value={formSlotDay}
                    onChange={(e) => setFormSlotDay(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                  >
                    {['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'].map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Time Slots */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Start Time *</label>
                  <input
                    type="time"
                    value={formSlotStartTime}
                    onChange={(e) => setFormSlotStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">End Time *</label>
                  <input
                    type="time"
                    value={formSlotEndTime}
                    onChange={(e) => setFormSlotEndTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300"
                    required
                  />
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Offering Lifecycle Status</label>
                <div className="flex items-center gap-4 text-xs font-semibold text-slate-700">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="PUBLISHED"
                      checked={formStatus === 'PUBLISHED'}
                      onChange={() => setFormStatus('PUBLISHED')}
                    />
                    <span>PUBLISHED (Active to Students)</span>
                  </label>
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="status"
                      value="DRAFT"
                      checked={formStatus === 'DRAFT'}
                      onChange={() => setFormStatus('DRAFT')}
                    />
                    <span>DRAFT (Hidden from Students)</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCreateModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmittingForm}
                >
                  {editingOffering ? 'Save Offering Changes' : 'Establish Course Offering'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: VIEW OFFERING DETAILS & ENROLLED ROSTER
         ========================================================================= */}
      {inspectingOffering && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#cbd5e1] animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-[#1e293b]">
                    {inspectingOffering.course_code} &mdash; {inspectingOffering.course_title}
                  </h3>
                  <Badge variant="blue">Section {inspectingOffering.section}</Badge>
                </div>
                <div className="text-xs text-[#64748b] font-mono mt-0.5">
                  {inspectingOffering.offering_id} &bull; {inspectingOffering.academic_year}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInspectingOffering(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Offering Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase">Enrolled</div>
                  <div className="text-lg font-bold text-[#1e3a8a]">
                    {offeringEnrolmentCounts.get(inspectingOffering.offering_id) || 0}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase">Capacity</div>
                  <div className="text-lg font-bold text-slate-800">
                    {inspectingOffering.max_capacity || 60}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase">Room</div>
                  <div className="text-sm font-bold text-slate-800 mt-1">
                    {inspectingOffering.room || 'TBD'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase">Status</div>
                  <div className="mt-1">
                    <Badge variant={inspectingOffering.status === 'PUBLISHED' ? 'emerald' : 'amber'}>
                      {inspectingOffering.status}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Enrolled Students Table */}
              <div>
                <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider mb-2">
                  Enrolled Students in this Offering
                </h4>
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 font-semibold text-slate-600 border-b border-slate-200">
                      <tr>
                        <th className="px-3 py-2">Reg Number</th>
                        <th className="px-3 py-2">Student Name</th>
                        <th className="px-3 py-2">Status</th>
                        <th className="px-3 py-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {enrolments.filter((e) => e.offering_id === inspectingOffering.offering_id).length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-3 py-6 text-center text-slate-400">
                            No students enrolled in this offering yet.
                          </td>
                        </tr>
                      ) : (
                        enrolments
                          .filter((e) => e.offering_id === inspectingOffering.offering_id)
                          .map((enr) => (
                            <tr key={enr.enrolment_id} className="hover:bg-slate-50">
                              <td className="px-3 py-2 font-mono font-semibold text-[#1e3a8a]">
                                {enr.student_registration_number}
                              </td>
                              <td className="px-3 py-2 font-medium">{enr.student_name}</td>
                              <td className="px-3 py-2">
                                <Badge variant={enr.enrolment_status === 'ACTIVE' ? 'emerald' : 'slate'}>
                                  {enr.enrolment_status}
                                </Badge>
                              </td>
                              <td className="px-3 py-2 text-right">
                                {enr.enrolment_status === 'ACTIVE' && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setInspectingOffering(null);
                                      setWithdrawingEnrolment(enr);
                                    }}
                                    className="text-rose-600 hover:text-rose-800 font-semibold cursor-pointer"
                                  >
                                    Withdraw
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end">
                <Button variant="outline" size="sm" onClick={() => setInspectingOffering(null)}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3: MANUAL STUDENT ENROLMENT
         ========================================================================= */}
      {enrolTargetOffering && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full border border-[#cbd5e1] animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#1e3a8a]" />
                <h3 className="text-base font-bold text-[#1e293b]">
                  Manual Student Enrolment
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEnrolTargetOffering(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleExecuteEnrolment} className="p-5 space-y-4">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs space-y-1">
                <div className="font-bold text-[#1e3a8a]">
                  {enrolTargetOffering.course_code} &mdash; {enrolTargetOffering.course_title} (Sec {enrolTargetOffering.section})
                </div>
                <div className="text-slate-600">
                  Current Enrolments: {offeringEnrolmentCounts.get(enrolTargetOffering.offering_id) || 0} / {enrolTargetOffering.max_capacity || 60}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select Student to Enrol *
                </label>
                <select
                  value={selectedStudentToEnrol}
                  onChange={(e) => setSelectedStudentToEnrol(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 border border-slate-300 font-medium"
                  required
                >
                  <option value="">-- Choose Enrolled Student --</option>
                  {students.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.fullName} ({st.registrationNumber}) &bull; {st.program || 'B.Tech'}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Enrolment is checked against offering capacity and prevents duplicate course registrations.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setEnrolTargetOffering(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmittingEnrol}
                >
                  Confirm Enrolment
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 4: CANCEL COURSE OFFERING
         ========================================================================= */}
      {cancellingOffering && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-rose-200 animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-rose-100 flex items-center justify-between bg-rose-50/50">
              <div className="flex items-center gap-2 text-rose-800">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold">Cancel Course Offering</h3>
              </div>
              <button
                type="button"
                onClick={() => setCancellingOffering(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Cancelling offering <strong>{cancellingOffering.offering_id}</strong> ({cancellingOffering.course_code}) will withdraw active access and record the reason in the institutional audit log.
              </p>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Cancellation Reason *
                </label>
                <textarea
                  rows={3}
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  placeholder="e.g. Inadequate cohort enrollment / Curriculum restructuring"
                  className="w-full p-2.5 rounded-lg text-xs bg-slate-50 border border-slate-300 focus:outline-none focus:border-rose-600"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setCancellingOffering(null)}
                >
                  Never mind
                </Button>
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  onClick={handleExecuteCancel}
                >
                  Confirm Cancellation
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 5: WITHDRAW STUDENT FROM OFFERING
         ========================================================================= */}
      {withdrawingEnrolment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-rose-200 animate-in fade-in zoom-in-95">
            <div className="p-4 sm:p-5 border-b border-rose-100 flex items-center justify-between bg-rose-50/50">
              <div className="flex items-center gap-2 text-rose-800">
                <UserMinus className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold">Withdraw Student Enrolment</h3>
              </div>
              <button
                type="button"
                onClick={() => setWithdrawingEnrolment(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                Withdraw student <strong>{withdrawingEnrolment.student_name}</strong> ({withdrawingEnrolment.student_registration_number}) from <strong>{withdrawingEnrolment.course_code}</strong>.
              </p>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Official Withdrawal Justification *
                </label>
                <textarea
                  rows={3}
                  value={withdrawalReason}
                  onChange={(e) => setWithdrawalReason(e.target.value)}
                  placeholder="e.g. Academic advisor approved withdrawal request"
                  className="w-full p-2.5 rounded-lg text-xs bg-slate-50 border border-slate-300 focus:outline-none focus:border-rose-600"
                  required
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2.5">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setWithdrawingEnrolment(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="danger"
                  size="sm"
                  onClick={handleExecuteWithdrawal}
                >
                  Confirm Withdrawal
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Authoritative Individual Student Enrolment Modal */}
      <IndividualEnrolmentModal
        isOpen={isIndividualEnrolModalOpen}
        onClose={() => {
          setIsIndividualEnrolModalOpen(false);
          setIndividualEnrolInitialOffering(null);
        }}
        offerings={offerings}
        students={students}
        actor={actor}
        initialOffering={individualEnrolInitialOffering}
        onSuccess={(msg) => {
          setSuccessMessage(msg);
          loadData();
          if (onRefresh) onRefresh();
        }}
      />
    </div>
  );
}
