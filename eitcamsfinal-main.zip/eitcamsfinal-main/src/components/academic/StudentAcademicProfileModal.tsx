import React, { useState, useEffect } from 'react';
import {
  User,
  GraduationCap,
  BookOpen,
  UserCheck,
  CheckCircle2,
  Calendar,
  X,
  Phone,
  Mail,
  Shield,
  Layers,
  Grid,
  Clock,
} from 'lucide-react';
import { StudentAcademicSummary } from '../../types/academic';
import { academicRepository } from '../../services/academicService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentAcademicProfileModalProps {
  registrationNumber: string;
  onClose: () => void;
  onOpenReassign?: (regNo: string) => void;
  actor?: { userId: string; role: string; employeeId?: string };
}

export function StudentAcademicProfileModal({
  registrationNumber,
  onClose,
  onOpenReassign,
  actor,
}: StudentAcademicProfileModalProps) {
  const [profile, setProfile] = useState<StudentAcademicSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    async function loadProfile() {
      setIsLoading(true);
      setErrorMessage(null);
      try {
        const data = await academicRepository.getStudentAcademicProfile(registrationNumber, actor);
        setProfile(data);
      } catch (err: any) {
        console.error('Failed to fetch student academic profile', err);
        setErrorMessage(err?.message || 'Failed to fetch student academic profile');
      } finally {
        setIsLoading(false);
      }
    }
    loadProfile();
  }, [registrationNumber, actor]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#1e3a8a] text-white font-bold flex items-center justify-center text-sm shadow-xs">
              {profile?.fullName
                ? profile.fullName
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .slice(0, 2)
                : 'ST'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-[#1e293b]">
                  {profile?.fullName || 'Student Academic Profile'}
                </h3>
                <Badge variant="blue" className="font-mono text-xs">
                  {registrationNumber}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b]">
                {profile ? `${profile.className || ''} • ${(profile.sectionName || '').startsWith('Batch') ? profile.sectionName : `Batch ${profile.sectionName || ''}`}` : 'Academic Record'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-[#94a3b8] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-[#f1f5f9]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          {isLoading ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              Loading student academic profile...
            </div>
          ) : !profile ? (
            <div className="py-12 text-center text-rose-600 text-xs px-4">
              {errorMessage || 'Student record not found.'}
            </div>
          ) : (
            <>
              {/* Top Overview Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg">
                  <div className="text-[10px] text-[#64748b] font-medium uppercase">Program & Batch</div>
                  <div className="text-sm font-bold text-[#1e293b] mt-0.5">
                    {profile.className || ''} - {profile.sectionName || ''}
                  </div>
                </div>

                <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg">
                  <div className="text-[10px] text-[#64748b] font-medium uppercase">Attendance Rate</div>
                  <div className="text-sm font-bold text-emerald-700 mt-0.5">
                    {profile.attendancePercentage}%{' '}
                    <span className="text-[10px] text-[#64748b] font-normal">
                      ({profile.attendancePresent}/{profile.attendanceTotal} days)
                    </span>
                  </div>
                </div>

                <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg">
                  <div className="text-[10px] text-[#64748b] font-medium uppercase">Enrolled Courses</div>
                  <div className="text-sm font-bold text-[#1e293b] mt-0.5">
                    {(profile.subjects || []).length} Courses
                  </div>
                </div>

                <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg">
                  <div className="text-[10px] text-[#64748b] font-medium uppercase">Account Status</div>
                  <div className="mt-0.5">
                    <Badge variant={profile.accountStatus === 'active' ? 'emerald' : 'slate'}>
                      {profile.accountStatus}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Student Personal & Guardian Info */}
              <div className="border border-[#e2e8f0] rounded-lg p-3.5 bg-white space-y-2">
                <div className="text-xs font-bold text-[#1e293b] flex items-center justify-between">
                  <span>Student Identity & Contact Details</span>
                  <span className="text-[11px] font-normal text-[#64748b]">
                    Enrolled: {profile.admissionDate}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#64748b]">
                  <div>
                    <span className="text-[#94a3b8] block text-[10px]">Guardian</span>
                    <strong className="text-[#1e293b]">{profile.guardianName}</strong>
                  </div>
                  <div>
                    <span className="text-[#94a3b8] block text-[10px]">Email</span>
                    <span className="text-[#1e293b] truncate block">{profile.email || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-[#94a3b8] block text-[10px]">Mobile</span>
                    <span className="text-[#1e293b]">{profile.mobile || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {/* Enrolled Courses & Assigned Faculty for this Program/Batch */}
              <div className="border border-[#e2e8f0] rounded-lg overflow-hidden bg-white">
                <div className="p-3 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between">
                  <div className="font-bold text-[#1e293b] flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                    <span>Curriculum Courses & Faculty In-Charge</span>
                  </div>
                  <span className="text-[11px] text-[#64748b]">
                    {profile.className} Syllabus
                  </span>
                </div>

                <div className="divide-y divide-[#f1f5f9]">
                  {(!profile.subjects || profile.subjects.length === 0) ? (
                    <div className="p-4 text-center text-[#94a3b8]">
                      No courses configured for this program yet.
                    </div>
                  ) : (
                    profile.subjects.map((sub: any) => {
                      const teacher = (profile.facultyAssignments || []).find(
                        (a: any) => a.subjectId === sub.id || a.subjectName?.toLowerCase() === sub.name?.toLowerCase()
                      );

                      return (
                        <div
                          key={sub.id}
                          className="p-3 flex items-center justify-between hover:bg-[#f8fafc] transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="font-mono font-bold text-[#1e3a8a] text-xs bg-[#eff6ff] px-2 py-0.5 rounded">
                              {sub.code}
                            </div>
                            <div>
                              <div className="font-bold text-[#1e293b]">{sub.name}</div>
                              <div className="text-[10px] text-[#64748b]">
                                {sub.type || 'Core'} &bull; {sub.creditsOrPeriodsPerWeek || 5} periods/wk
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            {teacher ? (
                              <div className="flex items-center gap-1.5 justify-end">
                                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                                <div>
                                  <div className="font-bold text-[#1e293b] text-xs">
                                    {teacher.facultyName}
                                  </div>
                                  <div className="text-[10px] text-[#64748b]">{teacher.employeeId}</div>
                                </div>
                              </div>
                            ) : (
                              <span className="text-[11px] text-[#94a3b8] italic">
                                Faculty pending
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Attendance Log Breakdown */}
              <div className="border border-[#e2e8f0] rounded-lg p-3.5 bg-[#f8fafc] space-y-2">
                <div className="font-bold text-[#1e293b] flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Attendance Statistics</span>
                  </span>
                  <Badge variant="emerald">{profile.attendancePercentage}% Rate</Badge>
                </div>
                <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                  <div className="bg-white p-2 rounded border border-[#e2e8f0]">
                    <div className="text-xs font-black text-emerald-700">{profile.attendancePresent}</div>
                    <div className="text-[10px] text-[#64748b]">Present</div>
                  </div>
                  <div className="bg-white p-2 rounded border border-[#e2e8f0]">
                    <div className="text-xs font-black text-amber-600">{profile.attendanceLate}</div>
                    <div className="text-[10px] text-[#64748b]">Late</div>
                  </div>
                  <div className="bg-white p-2 rounded border border-[#e2e8f0]">
                    <div className="text-xs font-black text-blue-600">{profile.attendanceLeave}</div>
                    <div className="text-[10px] text-[#64748b]">Leave</div>
                  </div>
                  <div className="bg-white p-2 rounded border border-[#e2e8f0]">
                    <div className="text-xs font-black text-rose-600">{profile.attendanceAbsent}</div>
                    <div className="text-[10px] text-[#64748b]">Absent</div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
          <div className="text-[11px] text-[#64748b]">
            Primary Institutional ID: <strong className="text-[#1e293b]">{registrationNumber}</strong>
          </div>

          <div className="flex items-center gap-2">
            {onOpenReassign && profile && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  onClose();
                  onOpenReassign(registrationNumber);
                }}
                leftIcon={<Layers className="w-3.5 h-3.5" />}
              >
                Reassign Program/Batch
              </Button>
            )}
            <Button variant="primary" size="sm" onClick={onClose}>
              Close Record
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
