import React, { useState } from 'react';
import {
  UserCheck,
  Plus,
  Trash2,
  Edit2,
  Search,
  Filter,
  Users,
  BookOpen,
  Layers,
  Grid,
  Calendar,
  X,
  Sparkles,
} from 'lucide-react';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  FacultyAssignment,
  AcademicSession,
  AssignmentStatus,
} from '../../types/academic';
import { Employee } from '../../types/employee';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface FacultyAssignmentsViewProps {
  facultyEmployees: Employee[];
  assignments: FacultyAssignment[];
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  currentSession: AcademicSession | null;
  onCreateAssignment: (data: Omit<FacultyAssignment, 'id' | 'assignedAt'>) => Promise<FacultyAssignment>;
  onUpdateAssignment: (id: string, data: Partial<FacultyAssignment>) => Promise<FacultyAssignment>;
  onDeleteAssignment: (id: string) => Promise<boolean>;
}

export function FacultyAssignmentsView({
  facultyEmployees,
  assignments,
  classes,
  sections,
  subjects,
  currentSession,
  onCreateAssignment,
  onUpdateAssignment,
  onDeleteAssignment,
}: FacultyAssignmentsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [facultyFilter, setFacultyFilter] = useState('all');
  const [classFilter, setClassFilter] = useState('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<FacultyAssignment | null>(null);

  const [selectedFacultyId, setSelectedFacultyId] = useState(facultyEmployees[0]?.id || '');
  const [selectedClassId, setSelectedClassId] = useState(classes[0]?.id || '');
  const [selectedSectionId, setSelectedSectionId] = useState('');
  const [selectedSubjectId, setSelectedSubjectId] = useState('');
  const [assignmentSession, setAssignmentSession] = useState(currentSession?.id || '2026-27');
  const [assignmentStatus, setAssignmentStatus] = useState<AssignmentStatus>('active');

  const [isProcessing, setIsProcessing] = useState(false);

  // Available sections and subjects for currently selected class in modal
  const availableSections = sections.filter((s) => s.classId === selectedClassId);
  const availableSubjects = subjects.filter((sub) => sub.classId === selectedClassId);

  // Filtered Assignments
  const filteredAssignments = assignments.filter((a) => {
    const matchesSearch =
      (a.facultyName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.employeeId || a.facultyId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.subjectName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.className || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFaculty =
      facultyFilter === 'all' ||
      (a.employeeId || a.facultyId || '').toLowerCase() === facultyFilter.toLowerCase();

    const matchesClass =
      classFilter === 'all' || (a.classId || '').toLowerCase() === classFilter.toLowerCase();

    return matchesSearch && matchesFaculty && matchesClass;
  });

  const handleOpenAdd = () => {
    setEditingAssignment(null);
    const initialClassId = classes[0]?.id || '';
    const initialSecs = sections.filter((s) => s.classId === initialClassId);
    const initialSubs = subjects.filter((s) => s.classId === initialClassId);

    setSelectedFacultyId(facultyEmployees[0]?.id || '');
    setSelectedClassId(initialClassId);
    setSelectedSectionId(initialSecs[0]?.id || '');
    setSelectedSubjectId(initialSubs[0]?.id || '');
    setAssignmentSession(currentSession?.id || '2026-27');
    setAssignmentStatus('active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (asg: FacultyAssignment) => {
    setEditingAssignment(asg);
    setSelectedFacultyId(asg.employeeId || asg.facultyId || '');
    setSelectedClassId(asg.classId || '');
    setSelectedSectionId(asg.sectionId || asg.section || '');
    setSelectedSubjectId(asg.subjectId || '');
    setAssignmentSession(asg.academicSession || asg.academicYear || currentSession?.id || '2026-27');
    setAssignmentStatus((asg.status as AssignmentStatus) || 'active');
    setIsModalOpen(true);
  };

  const handleClassChangeInModal = (newClassId: string) => {
    setSelectedClassId(newClassId);
    const newSecs = sections.filter((s) => s.classId === newClassId);
    const newSubs = subjects.filter((s) => s.classId === newClassId);
    setSelectedSectionId(newSecs[0]?.id || '');
    setSelectedSubjectId(newSubs[0]?.id || '');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFacultyId || !selectedClassId || !selectedSectionId || !selectedSubjectId) {
      alert('Please fill all required assignment fields.');
      return;
    }

    const faculty = facultyEmployees.find((f) => f.id === selectedFacultyId);
    const targetClass = classes.find((c) => c.id === selectedClassId);
    const targetSection = sections.find((s) => s.id === selectedSectionId);
    const targetSubject = subjects.find((sub) => sub.id === selectedSubjectId);

    if (!faculty || !targetClass || !targetSection || !targetSubject) {
      alert('Invalid selection parameters');
      return;
    }

    setIsProcessing(true);
    try {
      if (editingAssignment) {
        await onUpdateAssignment(editingAssignment.id, {
          employeeId: faculty.id,
          facultyName: faculty.fullName,
          facultyEmail: faculty.email,
          department: faculty.department,
          classId: targetClass.id,
          className: targetClass.name,
          section: targetSection.name,
          sectionId: targetSection.id,
          sectionName: targetSection.name,
          subjectId: targetSubject.id,
          subjectName: targetSubject.name,
          subjectCode: targetSubject.code,
          academicSession: assignmentSession,
          status: assignmentStatus,
        });
      } else {
        await onCreateAssignment({
          employeeId: faculty.id,
          facultyName: faculty.fullName,
          facultyEmail: faculty.email,
          department: faculty.department,
          classId: targetClass.id,
          className: targetClass.name,
          section: targetSection.name,
          sectionId: targetSection.id,
          sectionName: targetSection.name,
          subjectId: targetSubject.id,
          subjectName: targetSubject.name,
          subjectCode: targetSubject.code,
          academicSession: assignmentSession,
          status: assignmentStatus,
        });
      }
      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save assignment');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-[#1e3a8a]" />
            <span>Faculty Teaching Assignments</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Assign registered faculty to programs, batches, and courses for the active academic session.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={handleOpenAdd}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          Assign Faculty to Course
        </Button>
      </div>

      {/* Top Faculty Load Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {facultyEmployees.map((fac) => {
          const facAssignments = assignments.filter(
            (a) => (a.employeeId || a.facultyId || '').toLowerCase() === fac.id.toLowerCase() && a.status === 'active'
          );

          return (
            <div
              key={fac.id}
              onClick={() => setFacultyFilter(fac.id)}
              className={`bg-white border rounded-xl p-4 shadow-xs cursor-pointer transition-all ${
                facultyFilter === fac.id
                  ? 'border-[#1e3a8a] ring-2 ring-[#1e3a8a]/10'
                  : 'border-[#e2e8f0] hover:border-[#cbd5e1]'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#eff6ff] text-[#1e3a8a] font-bold text-xs flex items-center justify-center">
                    {fac.fullName
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .slice(0, 2)}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#1e293b]">{fac.fullName}</div>
                    <div className="text-[10px] text-[#64748b] font-mono">{fac.id}</div>
                  </div>
                </div>
                <Badge variant={fac.status === 'active' ? 'emerald' : 'slate'} className="text-[10px]">
                  {fac.status}
                </Badge>
              </div>

              <div className="mt-3 pt-2.5 border-t border-[#f1f5f9] flex items-center justify-between text-xs">
                <span className="text-[#64748b]">Teaching Load:</span>
                <span className="font-bold text-[#1e293b]">{facAssignments.length} Assignments</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="w-full md:w-80">
          <Input
            placeholder="Search by faculty, course or program..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            startIcon={<Search className="w-4 h-4 text-[#94a3b8]" />}
            className="h-9 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Faculty Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <Filter className="w-3.5 h-3.5" />
            <span>Faculty:</span>
            <select
              value={facultyFilter}
              onChange={(e) => setFacultyFilter(e.target.value)}
              className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
            >
              <option value="all">All Faculty ({facultyEmployees.length})</option>
              {facultyEmployees.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.fullName} ({f.id})
                </option>
              ))}
            </select>
          </div>

          {/* Program Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <span>Program:</span>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
            >
              <option value="all">All Programs</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Assignments Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span className="font-semibold text-[#1e293b]">
            Active Teaching Duties ({filteredAssignments.length} Records)
          </span>
          <span className="text-[#64748b]">Session: {currentSession?.name || '2026-27'}</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4 font-semibold">Faculty Member</th>
                <th className="py-3 px-4 font-semibold">Program & Batch</th>
                <th className="py-3 px-4 font-semibold">Course & Code</th>
                <th className="py-3 px-4 font-semibold">Academic Session</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredAssignments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-xs text-[#94a3b8]">
                    No teaching assignments found matching the criteria.
                  </td>
                </tr>
              ) : (
                filteredAssignments.map((asg) => (
                  <tr key={asg.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">{asg.facultyName}</div>
                      <div className="text-[11px] text-[#64748b] font-mono">{asg.employeeId}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">
                        {asg.className || ''} &bull; {(asg.sectionName || asg.section || '').startsWith('Batch') ? (asg.sectionName || asg.section) : `Batch ${asg.sectionName || asg.section || ''}`}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">{asg.subjectName}</div>
                      {asg.subjectCode && (
                        <div className="text-[10px] text-[#64748b] font-mono">{asg.subjectCode}</div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="blue">{asg.academicSession || asg.academicYear || '2026-27'}</Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant={asg.status === 'active' ? 'emerald' : 'slate'}>
                        {asg.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(asg)}
                          className="p-1.5 rounded hover:bg-[#f1f5f9] text-[#64748b] hover:text-[#1e3a8a]"
                          title="Edit Assignment"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Remove teaching assignment for ${asg.facultyName}?`)) {
                              onDeleteAssignment(asg.id);
                            }
                          }}
                          className="p-1.5 rounded hover:bg-[#f1f5f9] text-[#64748b] hover:text-rose-600"
                          title="Delete Assignment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assignment Modal (Add / Edit) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">
                  {editingAssignment ? 'Edit Teaching Assignment' : 'Assign Faculty to Course'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Select Faculty Member *
                </label>
                <select
                  required
                  value={selectedFacultyId}
                  onChange={(e) => setSelectedFacultyId(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  {facultyEmployees.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} ({f.id} &bull; {f.department})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-[#64748b] mt-1">
                  Using existing verified employee identity. No duplicate accounts created.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Degree Program *
                  </label>
                  <select
                    required
                    value={selectedClassId}
                    onChange={(e) => handleClassChangeInModal(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Batch / Cohort *
                  </label>
                  <select
                    required
                    value={selectedSectionId}
                    onChange={(e) => setSelectedSectionId(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    {availableSections.map((sec) => (
                      <option key={sec.id} value={sec.id}>
                        {sec.name} ({sec.roomNumber || 'Room TBD'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Course *
                </label>
                <select
                  required
                  value={selectedSubjectId}
                  onChange={(e) => setSelectedSubjectId(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  {availableSubjects.length === 0 ? (
                    <option value="">No courses registered for this program</option>
                  ) : (
                    availableSubjects.map((sub) => (
                      <option key={sub.id} value={sub.id}>
                        {sub.name} ({sub.code})
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Academic Session *
                  </label>
                  <input
                    type="text"
                    required
                    value={assignmentSession}
                    onChange={(e) => setAssignmentSession(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Status</label>
                  <select
                    value={assignmentStatus}
                    onChange={(e) => setAssignmentStatus(e.target.value as AssignmentStatus)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  {editingAssignment ? 'Save Assignment' : 'Assign Faculty'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
