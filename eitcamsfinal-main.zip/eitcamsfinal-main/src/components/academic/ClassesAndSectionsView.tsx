import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Edit2,
  Power,
  Trash2,
  Users,
  Grid,
  Search,
  CheckCircle2,
  XCircle,
  X,
  Sparkles,
  School,
  UserCheck,
} from 'lucide-react';
import { AcademicClass, AcademicSection, ClassStatus, SectionStatus } from '../../types/academic';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface ClassesAndSectionsViewProps {
  classes: AcademicClass[];
  sections: AcademicSection[];
  students: Student[];
  facultyEmployees: Employee[];
  onCreateClass: (data: Omit<AcademicClass, 'id' | 'createdAt'>) => Promise<AcademicClass>;
  onUpdateClass: (id: string, data: Partial<AcademicClass>) => Promise<AcademicClass>;
  onToggleClassStatus: (id: string) => Promise<AcademicClass>;
  onDeleteClass: (id: string) => Promise<boolean>;
  onCreateSection: (data: Omit<AcademicSection, 'id' | 'createdAt'>) => Promise<AcademicSection>;
  onUpdateSection: (id: string, data: Partial<AcademicSection>) => Promise<AcademicSection>;
  onToggleSectionStatus: (id: string) => Promise<AcademicSection>;
  onDeleteSection: (id: string) => Promise<boolean>;
}

export function ClassesAndSectionsView({
  classes,
  sections,
  students,
  facultyEmployees,
  onCreateClass,
  onUpdateClass,
  onToggleClassStatus,
  onDeleteClass,
  onCreateSection,
  onUpdateSection,
  onToggleSectionStatus,
  onDeleteSection,
}: ClassesAndSectionsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>(classes[0]?.id || '');

  // Modal States
  const [isClassModalOpen, setIsClassModalOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<AcademicClass | null>(null);
  const [classCodeInput, setClassCodeInput] = useState('');
  const [classNameInput, setClassNameInput] = useState('');
  const [classDepartmentInput, setClassDepartmentInput] = useState('');
  const [classProgramTypeInput, setClassProgramTypeInput] = useState('Undergraduate');
  const [classDurationInput, setClassDurationInput] = useState<number>(4);
  const [classSemestersInput, setClassSemestersInput] = useState<number>(8);
  const [classNumericInput, setClassNumericInput] = useState<number>(1);
  const [classStreamInput, setClassStreamInput] = useState('Computer Science');
  const [classDescInput, setClassDescInput] = useState('');
  const [classStatusInput, setClassStatusInput] = useState<ClassStatus>('active');

  const [isSectionModalOpen, setIsSectionModalOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<AcademicSection | null>(null);
  const [sectionClassIdInput, setSectionClassIdInput] = useState('');
  const [sectionNameInput, setSectionNameInput] = useState('A');
  const [sectionBatchYearInput, setSectionBatchYearInput] = useState('2026');
  const [sectionCurrentSemInput, setSectionCurrentSemInput] = useState('Semester 1');
  const [sectionAcademicSessionInput, setSectionAcademicSessionInput] = useState('2026-27');
  const [sectionRoomInput, setSectionRoomInput] = useState('');
  const [sectionCapacityInput, setSectionCapacityInput] = useState<number>(60);
  const [sectionTeacherIdInput, setSectionTeacherIdInput] = useState('');
  const [sectionStatusInput, setSectionStatusInput] = useState<SectionStatus>('active');

  const [isProcessing, setIsProcessing] = useState(false);

  // Filtered classes (Programs)
  const filteredClasses = classes.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.code && c.code.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (c.department && c.department.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (c.stream && c.stream.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (c.description && c.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const selectedClass = classes.find((c) => c.id === selectedClassId) || classes[0];
  const selectedClassSections = sections.filter((s) => s.classId === selectedClass?.id);

  // Helper to count students for a class / program
  const getStudentCountForClass = (clsName: string, clsId: string) => {
    return students.filter(
      (s) =>
        (s.program && (s.program.toLowerCase() === clsName.toLowerCase() || s.program.toLowerCase() === clsId.toLowerCase())) ||
        s.admissionClass.toLowerCase() === clsName.toLowerCase() ||
        s.admissionClass.toLowerCase() === clsId.toLowerCase()
    ).length;
  };

  // Helper to count students for a section / batch
  const getStudentCountForSection = (clsName: string, clsId: string, secName: string) => {
    return students.filter(
      (s) =>
        ((s.program && (s.program.toLowerCase() === clsName.toLowerCase() || s.program.toLowerCase() === clsId.toLowerCase())) ||
          s.admissionClass.toLowerCase() === clsName.toLowerCase() ||
          s.admissionClass.toLowerCase() === clsId.toLowerCase()) &&
        ((s.batch && s.batch.toLowerCase() === secName.toLowerCase()) ||
          s.section.toLowerCase() === secName.toLowerCase())
    ).length;
  };

  // Open Add Class / Program Modal
  const handleOpenAddClass = () => {
    setEditingClass(null);
    setClassCodeInput('');
    setClassNameInput('');
    setClassDepartmentInput('Department of Computer Science & Engineering');
    setClassProgramTypeInput('Undergraduate');
    setClassDurationInput(4);
    setClassSemestersInput(8);
    setClassNumericInput(classes.length > 0 ? (classes[classes.length - 1].numericLevel || 1) + 1 : 1);
    setClassStreamInput('Computer Science');
    setClassDescInput('');
    setClassStatusInput('active');
    setIsClassModalOpen(true);
  };

  // Open Edit Class / Program Modal
  const handleOpenEditClass = (cls: AcademicClass) => {
    setEditingClass(cls);
    setClassCodeInput(cls.code || '');
    setClassNameInput(cls.name);
    setClassDepartmentInput(cls.department || 'Department of Computer Science & Engineering');
    setClassProgramTypeInput(cls.programType || 'Undergraduate');
    setClassDurationInput(cls.durationYears || 4);
    setClassSemestersInput(cls.totalSemesters || 8);
    setClassNumericInput(cls.numericLevel || 1);
    setClassStreamInput(cls.stream || 'General');
    setClassDescInput(cls.description || '');
    setClassStatusInput((cls.status || 'active') as ClassStatus);
    setIsClassModalOpen(true);
  };

  // Submit Class / Program Form
  const handleClassSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!classNameInput.trim()) return;

    setIsProcessing(true);
    try {
      const payload: Partial<AcademicClass> = {
        name: classNameInput.trim(),
        code: classCodeInput.trim().toUpperCase() || classNameInput.trim().slice(0, 8).toUpperCase(),
        department: classDepartmentInput.trim(),
        programType: classProgramTypeInput.trim(),
        durationYears: Number(classDurationInput) || 4,
        totalSemesters: Number(classSemestersInput) || 8,
        numericLevel: Number(classNumericInput) || 1,
        stream: classStreamInput.trim() || 'General',
        description: classDescInput.trim(),
        status: classStatusInput,
      };

      if (editingClass) {
        await onUpdateClass(editingClass.id, payload);
      } else {
        const created = await onCreateClass(payload as Omit<AcademicClass, 'id' | 'createdAt'>);
        setSelectedClassId(created.id);
      }
      setIsClassModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save academic program');
    } finally {
      setIsProcessing(false);
    }
  };

  // Open Add Section / Batch Modal
  const handleOpenAddSection = (classId?: string) => {
    const targetClassId = classId || selectedClass?.id || classes[0]?.id;
    setEditingSection(null);
    setSectionClassIdInput(targetClassId);
    const existingSecs = sections.filter((s) => s.classId === targetClassId);
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const nextLetter = alphabet[existingSecs.length] || 'A';
    setSectionNameInput(`Batch 2026 - Group ${nextLetter}`);
    setSectionBatchYearInput('2026');
    setSectionCurrentSemInput('Semester 1');
    setSectionAcademicSessionInput('2026-27');
    setSectionRoomInput(`Lab-${301 + existingSecs.length}`);
    setSectionCapacityInput(60);
    setSectionTeacherIdInput('');
    setSectionStatusInput('active');
    setIsSectionModalOpen(true);
  };

  // Open Edit Section / Batch Modal
  const handleOpenEditSection = (sec: AcademicSection) => {
    setEditingSection(sec);
    setSectionClassIdInput(sec.classId || '');
    setSectionNameInput(sec.name);
    setSectionBatchYearInput(sec.batchYear || '2026');
    setSectionCurrentSemInput(sec.currentSemester || 'Semester 1');
    setSectionAcademicSessionInput(sec.academicSession || '2026-27');
    setSectionRoomInput(sec.roomNumber || '');
    setSectionCapacityInput(sec.capacity || 60);
    setSectionTeacherIdInput(sec.classTeacherId || '');
    setSectionStatusInput((sec.status || 'active') as SectionStatus);
    setIsSectionModalOpen(true);
  };

  // Submit Section / Batch Form
  const handleSectionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sectionNameInput.trim()) return;

    const parentClass = classes.find((c) => c.id === sectionClassIdInput) || selectedClass;
    if (!parentClass) return;

    const teacher = facultyEmployees.find((f) => f.id === sectionTeacherIdInput);

    setIsProcessing(true);
    try {
      const payload: Partial<AcademicSection> = {
        name: sectionNameInput.trim(),
        batchYear: sectionBatchYearInput.trim() || '2026',
        currentSemester: sectionCurrentSemInput.trim() || 'Semester 1',
        academicSession: sectionAcademicSessionInput.trim() || '2026-27',
        roomNumber: sectionRoomInput.trim(),
        capacity: Number(sectionCapacityInput) || 60,
        classTeacherId: teacher?.id || '',
        classTeacherName: teacher?.fullName || '',
        status: sectionStatusInput,
      };

      if (editingSection) {
        await onUpdateSection(editingSection.id, payload);
      } else {
        await onCreateSection({
          classId: parentClass.id,
          className: parentClass.name,
          ...payload,
        } as Omit<AcademicSection, 'id' | 'createdAt'>);
      }
      setIsSectionModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save batch');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#1e3a8a]" />
            <span>Academic Programs & Student Batches</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Configure degree programs, academic batches, cohorts, capacities, and faculty advisors/mentors.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleOpenAddSection(selectedClass?.id)}
            leftIcon={<Grid className="w-4 h-4 text-cyan-600" />}
          >
            Add Student Batch
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={handleOpenAddClass}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Add Program
          </Button>
        </div>
      </div>

      {/* Two Column Layout: Classes Directory & Selected Class Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Classes Roster List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="p-3.5 border-b border-[#e2e8f0] bg-[#f8fafc]">
              <Input
                placeholder="Search programs, codes or departments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                startIcon={<Search className="w-4 h-4 text-[#94a3b8]" />}
                className="h-9 text-xs"
              />
            </div>

            <div className="divide-y divide-[#f1f5f9] max-h-[600px] overflow-y-auto">
              {filteredClasses.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#94a3b8]">No academic programs match your search.</div>
              ) : (
                filteredClasses.map((cls) => {
                  const studentCount = getStudentCountForClass(cls.name, cls.id);
                  const classSecs = sections.filter((s) => s.classId === cls.id);
                  const isSelected = cls.id === selectedClass?.id;

                  return (
                    <div
                      key={cls.id}
                      onClick={() => setSelectedClassId(cls.id)}
                      className={`p-3.5 flex items-center justify-between cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-[#eff6ff] border-l-4 border-[#1e3a8a]'
                          : 'hover:bg-[#f8fafc]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-lg font-bold text-xs flex items-center justify-center p-1 text-center ${
                            isSelected
                              ? 'bg-[#1e3a8a] text-white shadow-xs'
                              : 'bg-[#f1f5f9] text-[#1e293b]'
                          }`}
                        >
                          {cls.code || (cls.numericLevel ? `G${cls.numericLevel}` : cls.name.slice(0, 3))}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                            <span>{cls.name}</span>
                            <Badge variant={cls.status === 'active' ? 'emerald' : 'slate'} className="text-[10px] py-0 px-1.5">
                              {cls.status}
                            </Badge>
                          </div>
                          <div className="text-xs text-[#64748b] flex items-center gap-2 mt-0.5">
                            <span>{cls.department || cls.stream || 'Department of Engineering'}</span>
                            <span>&bull;</span>
                            <span>{classSecs.length} Batches</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="text-xs font-bold text-[#1e293b]">{studentCount}</div>
                          <div className="text-[10px] text-[#64748b]">Students</div>
                        </div>
                        <div className="flex items-center gap-1 ml-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenEditClass(cls);
                            }}
                            className="p-1 rounded hover:bg-white text-[#64748b] hover:text-[#1e3a8a]"
                            title="Edit Program"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleClassStatus(cls.id);
                            }}
                            className="p-1 rounded hover:bg-white text-[#64748b] hover:text-amber-600"
                            title={cls.status === 'active' ? 'Deactivate Program' : 'Activate Program'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Active Program Details & Batches List (7 Cols) */}
        <div className="lg:col-span-7 space-y-4">
          {selectedClass ? (
            <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
              {/* Program Header Card */}
              <div className="p-4 sm:p-5 border-b border-[#e2e8f0] bg-[#f8fafc] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-bold text-[#1e293b]">{selectedClass.name}</h3>
                    {selectedClass.code && (
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-semibold rounded-md">
                        {selectedClass.code}
                      </span>
                    )}
                    <Badge variant="blue">{selectedClass.programType || selectedClass.stream || 'Undergraduate'}</Badge>
                    <Badge variant={selectedClass.status === 'active' ? 'emerald' : 'slate'}>
                      {selectedClass.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-[#64748b] mt-1">
                    {selectedClass.department || 'Department of Computer Science & Engineering'} &bull;{' '}
                    {selectedClass.durationYears || 4} Years ({selectedClass.totalSemesters || 8} Semesters)
                  </p>
                  {selectedClass.description && (
                    <p className="text-xs text-[#475569] mt-1 italic">
                      {selectedClass.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleOpenAddSection(selectedClass.id)}
                    leftIcon={<Plus className="w-3.5 h-3.5" />}
                  >
                    Add Batch
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleOpenEditClass(selectedClass)}
                    leftIcon={<Edit2 className="w-3.5 h-3.5" />}
                  >
                    Edit Program
                  </Button>
                </div>
              </div>

              {/* Batches Table */}
              <div className="p-4">
                <div className="flex items-center justify-between mb-3 text-xs text-[#64748b]">
                  <span className="font-bold text-[#1e293b]">
                    Configured Cohorts & Batches ({selectedClassSections.length})
                  </span>
                  <span>
                    Total Program Enrollment:{' '}
                    <strong className="text-[#1e293b]">
                      {getStudentCountForClass(selectedClass.name, selectedClass.id)}
                    </strong>
                  </span>
                </div>

                {selectedClassSections.length === 0 ? (
                  <div className="p-8 border border-dashed border-[#cbd5e1] rounded-xl text-center space-y-2">
                    <Grid className="w-8 h-8 text-[#94a3b8] mx-auto" />
                    <div className="text-xs font-bold text-[#1e293b]">No cohorts/batches configured yet</div>
                    <p className="text-[11px] text-[#64748b]">
                      Add student cohort batches (e.g. Batch 2026 - Group A, B) to allocate rooms and faculty mentors.
                    </p>
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => handleOpenAddSection(selectedClass.id)}
                      leftIcon={<Plus className="w-3.5 h-3.5" />}
                      className="mt-2"
                    >
                      Add First Batch
                    </Button>
                  </div>
                ) : (
                  <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                        <tr>
                          <th className="py-2.5 px-3 font-semibold">Cohort / Batch</th>
                          <th className="py-2.5 px-3 font-semibold">Semester & Session</th>
                          <th className="py-2.5 px-3 font-semibold">Room / Lab</th>
                          <th className="py-2.5 px-3 font-semibold">Faculty Mentor</th>
                          <th className="py-2.5 px-3 font-semibold text-center">Students</th>
                          <th className="py-2.5 px-3 font-semibold">Status</th>
                          <th className="py-2.5 px-3 font-semibold text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#f1f5f9]">
                        {selectedClassSections.map((sec) => {
                          const secCount = getStudentCountForSection(
                            selectedClass.name,
                            selectedClass.id,
                            sec.name
                          );

                          return (
                            <tr key={sec.id} className="hover:bg-[#f8fafc] transition-colors">
                              <td className="py-2.5 px-3 font-semibold text-[#1e293b]">
                                <div>{sec.name}</div>
                                {sec.batchYear && (
                                  <span className="text-[10px] text-[#64748b]">Class of {sec.batchYear}</span>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-[#475569]">
                                <div>{sec.currentSemester || 'Semester 1'}</div>
                                <div className="text-[10px] text-[#94a3b8]">{sec.academicSession || '2026-27'}</div>
                              </td>
                              <td className="py-2.5 px-3 text-[#64748b]">
                                <div>{sec.roomNumber || 'TBD'}</div>
                                <div className="text-[10px] text-[#94a3b8]">Cap: {sec.capacity || 60}</div>
                              </td>
                              <td className="py-2.5 px-3 text-[#1e293b]">
                                {sec.classTeacherName ? (
                                  <div className="flex items-center gap-1.5">
                                    <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>{sec.classTeacherName}</span>
                                  </div>
                                ) : (
                                  <span className="text-[#94a3b8] italic">Unassigned</span>
                                )}
                              </td>
                              <td className="py-2.5 px-3 text-center">
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-[#1e3a8a]">
                                  {secCount}
                                </span>
                              </td>
                              <td className="py-2.5 px-3">
                                <Badge
                                  variant={sec.status === 'active' ? 'emerald' : 'slate'}
                                  className="text-[10px] py-0 px-1.5"
                                >
                                  {sec.status}
                                </Badge>
                              </td>
                              <td className="py-2.5 px-3 text-right">
                                <div className="flex items-center justify-end gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleOpenEditSection(sec)}
                                    className="p-1 rounded hover:bg-[#e2e8f0] text-[#64748b] hover:text-[#1e3a8a]"
                                    title="Edit Batch"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => onToggleSectionStatus(sec.id)}
                                    className="p-1 rounded hover:bg-[#e2e8f0] text-[#64748b] hover:text-amber-600"
                                    title={sec.status === 'active' ? 'Deactivate' : 'Activate'}
                                  >
                                    <Power className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => onDeleteSection(sec.id)}
                                    className="p-1 rounded hover:bg-[#e2e8f0] text-[#64748b] hover:text-rose-600"
                                    title="Delete Batch"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#e2e8f0] rounded-xl p-12 text-center text-xs text-[#94a3b8]">
              Select a program from the left to view and manage its student batches.
            </div>
          )}
        </div>
      </div>

      {/* Program Modal (Add/Edit) */}
      {isClassModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">
                  {editingClass ? 'Edit Degree / Academic Program' : 'Add New Academic Program'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsClassModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleClassSubmit} className="p-4 space-y-3.5 text-xs max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Program Code *
                  </label>
                  <Input
                    required
                    placeholder="e.g. BTECH-CSE"
                    value={classCodeInput}
                    onChange={(e) => setClassCodeInput(e.target.value.toUpperCase())}
                    className="h-9 text-xs uppercase"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Program / Degree Name *
                  </label>
                  <Input
                    required
                    placeholder="e.g. B.Tech Computer Science & Engineering"
                    value={classNameInput}
                    onChange={(e) => setClassNameInput(e.target.value)}
                    className="h-9 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Department *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Department of Computer Science & Engineering"
                    value={classDepartmentInput}
                    onChange={(e) => setClassDepartmentInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Program Type / Level
                  </label>
                  <select
                    value={classProgramTypeInput}
                    onChange={(e) => setClassProgramTypeInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    <option value="Undergraduate">Undergraduate (B.Tech / B.Sc / B.Com)</option>
                    <option value="Postgraduate">Postgraduate (M.Tech / M.Sc / MBA)</option>
                    <option value="Doctoral">Doctoral (Ph.D.)</option>
                    <option value="Diploma">Diploma / Certificate</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Duration (Years)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    required
                    value={classDurationInput}
                    onChange={(e) => setClassDurationInput(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Total Semesters
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="12"
                    required
                    value={classSemestersInput}
                    onChange={(e) => setClassSemestersInput(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Specialization / Stream
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. AI & ML / Core"
                    value={classStreamInput}
                    onChange={(e) => setClassStreamInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Program Curriculum / Accreditation Description
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. AICTE/UGC accredited engineering program with FFCS credit model..."
                  value={classDescInput}
                  onChange={(e) => setClassDescInput(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">Status</label>
                <select
                  value={classStatusInput}
                  onChange={(e) => setClassStatusInput(e.target.value as ClassStatus)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  <option value="active">Active (Enrolling)</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsClassModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  {editingClass ? 'Save Changes' : 'Create Program'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch / Cohort Modal (Add/Edit) */}
      {isSectionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <Grid className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">
                  {editingSection ? 'Edit Student Cohort / Batch' : 'Add New Cohort / Batch'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSectionModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSectionSubmit} className="p-4 space-y-3.5 text-xs max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Parent Program *
                </label>
                <select
                  disabled={Boolean(editingSection)}
                  value={sectionClassIdInput}
                  onChange={(e) => setSectionClassIdInput(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.code || c.stream || 'Program'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Batch / Group Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Batch 2026 - Group A or A"
                    value={sectionNameInput}
                    onChange={(e) => setSectionNameInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Batch Year (Class of) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 2026"
                    value={sectionBatchYearInput}
                    onChange={(e) => setSectionBatchYearInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Current Semester *
                  </label>
                  <select
                    value={sectionCurrentSemInput}
                    onChange={(e) => setSectionCurrentSemInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    <option value="Semester 1">Semester 1 (Autumn / Odd)</option>
                    <option value="Semester 2">Semester 2 (Winter / Even)</option>
                    <option value="Semester 3">Semester 3</option>
                    <option value="Semester 4">Semester 4</option>
                    <option value="Semester 5">Semester 5</option>
                    <option value="Semester 6">Semester 6</option>
                    <option value="Semester 7">Semester 7</option>
                    <option value="Semester 8">Semester 8</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Academic Session
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 2026-27"
                    value={sectionAcademicSessionInput}
                    onChange={(e) => setSectionAcademicSessionInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Room / Lab Hall
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Lab 302"
                    value={sectionRoomInput}
                    onChange={(e) => setSectionRoomInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Max Capacity
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="150"
                    value={sectionCapacityInput}
                    onChange={(e) => setSectionCapacityInput(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Status</label>
                  <select
                    value={sectionStatusInput}
                    onChange={(e) => setSectionStatusInput(e.target.value as SectionStatus)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Faculty Mentor / Advisor (Proctor)
                </label>
                <select
                  value={sectionTeacherIdInput}
                  onChange={(e) => setSectionTeacherIdInput(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  <option value="">-- Select Faculty Advisor (Optional) --</option>
                  {facultyEmployees.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} ({f.id} &bull; {f.department})
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsSectionModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  {editingSection ? 'Save Batch' : 'Create Batch'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
