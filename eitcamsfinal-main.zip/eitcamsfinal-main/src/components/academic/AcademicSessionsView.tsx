import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  CheckCircle2,
  Clock,
  Archive,
  Star,
  Layers,
  X,
  Sparkles,
} from 'lucide-react';
import { AcademicSession } from '../../types/academic';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface AcademicSessionsViewProps {
  sessions: AcademicSession[];
  onCreateSession: (data: Omit<AcademicSession, 'id' | 'isCurrent'>) => Promise<AcademicSession>;
  onSetCurrentSession: (id: string) => Promise<AcademicSession>;
}

export function AcademicSessionsView({
  sessions,
  onCreateSession,
  onSetCurrentSession,
}: AcademicSessionsViewProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [startDateInput, setStartDateInput] = useState('');
  const [endDateInput, setEndDateInput] = useState('');
  const [statusInput, setStatusInput] = useState<'active' | 'archived' | 'upcoming'>('upcoming');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleOpenAdd = () => {
    setNameInput('');
    setStartDateInput('2027-06-01');
    setEndDateInput('2028-04-30');
    setStatusInput('upcoming');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim() || !startDateInput || !endDateInput) return;

    setIsProcessing(true);
    try {
      await onCreateSession({
        name: nameInput.trim(),
        startDate: startDateInput,
        endDate: endDateInput,
        status: statusInput,
      });
      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to create academic session');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#1e3a8a]" />
            <span>Academic Sessions & Terms</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            Manage institutional academic years, active terms, term dates, and historical session archives.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={handleOpenAdd}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Academic Session
        </Button>
      </div>

      {/* Sessions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sessions.map((sess) => {
          return (
            <div
              key={sess.id}
              className={`bg-white border rounded-xl p-5 shadow-xs transition-all relative overflow-hidden ${
                sess.isCurrent
                  ? 'border-[#1e3a8a] ring-2 ring-[#1e3a8a]/10 bg-blue-50/20'
                  : 'border-[#e2e8f0]'
              }`}
            >
              {sess.isCurrent && (
                <div className="absolute top-0 right-0 bg-[#1e3a8a] text-white text-[10px] font-bold px-3 py-0.5 rounded-bl-lg uppercase tracking-wider flex items-center gap-1">
                  <Star className="w-3 h-3 fill-white" />
                  <span>Active Session</span>
                </div>
              )}

              <div className="space-y-3">
                <div className="flex items-start justify-between pr-16">
                  <div>
                    <h3 className="text-base font-bold text-[#1e293b]">{sess.name}</h3>
                    <div className="font-mono text-xs text-[#1e3a8a] font-semibold mt-0.5">
                      {sess.id}
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-[#64748b] pt-2 border-t border-[#f1f5f9]">
                  <div className="flex items-center justify-between">
                    <span>Term Duration:</span>
                    <strong className="text-[#1e293b]">
                      {sess.startDate} &rarr; {sess.endDate}
                    </strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Status:</span>
                    <Badge
                      variant={
                        sess.status === 'active'
                          ? 'emerald'
                          : sess.status === 'upcoming'
                          ? 'blue'
                          : 'neutral'
                      }
                    >
                      {sess.status}
                    </Badge>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between">
                  {sess.isCurrent ? (
                    <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Current Institutional Term
                    </span>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onSetCurrentSession(sess.id)}
                      className="text-xs w-full"
                    >
                      Set as Active Session
                    </Button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Session Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Create Academic Session</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Session Name / Academic Year *
                </label>
                <Input
                  required
                  placeholder="e.g. 2027–2028 Academic Year"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="h-9 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Term Start Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={startDateInput}
                    onChange={(e) => setStartDateInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Term End Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={endDateInput}
                    onChange={(e) => setEndDateInput(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Initial Status
                </label>
                <select
                  value={statusInput}
                  onChange={(e) =>
                    setStatusInput(e.target.value as 'active' | 'archived' | 'upcoming')
                  }
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  <option value="upcoming">Upcoming</option>
                  <option value="active">Active</option>
                  <option value="archived">Archived</option>
                </select>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  Create Session
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
