import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Edit2,
  Power,
  Trash2,
  Search,
  CheckCircle2,
  XCircle,
  X,
  BookOpen,
  GraduationCap,
  Users,
} from 'lucide-react';
import { AcademicDepartment, DepartmentStatus, AcademicClass } from '../../types/academic';
import { Employee } from '../../types/employee';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface DepartmentsViewProps {
  departments: AcademicDepartment[];
  programs: AcademicClass[];
  facultyEmployees: Employee[];
  onCreateDepartment: (data: Omit<AcademicDepartment, 'id' | 'createdAt'>) => Promise<AcademicDepartment>;
  onUpdateDepartment: (id: string, data: Partial<AcademicDepartment>) => Promise<AcademicDepartment>;
  onToggleDepartmentStatus: (id: string) => Promise<AcademicDepartment>;
  onDeleteDepartment: (id: string) => Promise<boolean>;
}

export function DepartmentsView({
  departments,
  programs,
  facultyEmployees,
  onCreateDepartment,
  onUpdateDepartment,
  onToggleDepartmentStatus,
  onDeleteDepartment,
}: DepartmentsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState<AcademicDepartment | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Form Inputs
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [hodId, setHodId] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<DepartmentStatus>('active');

  const filteredDepartments = departments.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (d.description && d.description.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || d.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAdd = () => {
    setEditingDepartment(null);
    setCode('');
    setName('');
    setHodId('');
    setDescription('');
    setStatus('active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (dept: AcademicDepartment) => {
    setEditingDepartment(dept);
    setCode(dept.code);
    setName(dept.name);
    setHodId(dept.headOfDepartmentId || '');
    setDescription(dept.description || '');
    setStatus(dept.status);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) return;

    const selectedHod = facultyEmployees.find((f) => f.id === hodId);

    setIsProcessing(true);
    try {
      if (editingDepartment) {
        await onUpdateDepartment(editingDepartment.id, {
          code: code.trim().toUpperCase(),
          name: name.trim(),
          headOfDepartment: selectedHod?.fullName || '',
          headOfDepartmentId: selectedHod?.id || '',
          description: description.trim(),
          status,
        });
      } else {
        await onCreateDepartment({
          code: code.trim().toUpperCase(),
          name: name.trim(),
          headOfDepartment: selectedHod?.fullName || '',
          headOfDepartmentId: selectedHod?.id || '',
          description: description.trim(),
          status,
        });
      }
      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save department');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-neutral-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-700 border border-blue-100">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-neutral-900">Academic Departments</h2>
            <p className="text-sm text-neutral-500">
              Manage collegiate departments, department heads, linked programs, and faculty.
            </p>
          </div>
        </div>
        <Button onClick={handleOpenAdd} className="bg-blue-600 hover:bg-blue-700 text-white gap-2 shadow-sm">
          <Plus className="w-4 h-4" />
          Add Department
        </Button>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search departments or codes..."
            className="pl-9 bg-white"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-medium text-neutral-500">Status:</span>
          <div className="flex rounded-lg border border-neutral-200 bg-white p-1">
            {(['all', 'active', 'inactive'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`px-3 py-1 text-xs font-medium rounded-md capitalize transition-colors ${
                  statusFilter === filter
                    ? 'bg-neutral-900 text-white'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Department Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDepartments.map((dept) => {
          // Count linked programs
          const linkedPrograms = programs.filter(
            (p) =>
              p.departmentId === dept.id ||
              (p.department && p.department.toLowerCase().includes(dept.name.toLowerCase())) ||
              (p.department && p.department.toLowerCase().includes(dept.code.toLowerCase()))
          );

          // Count linked faculty (belonging to department)
          const linkedFaculty = facultyEmployees.filter(
            (f) =>
              f.department?.toLowerCase() === dept.name.toLowerCase() ||
              f.department?.toLowerCase() === dept.code.toLowerCase()
          );

          return (
            <div
              key={dept.id}
              className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 text-xs font-mono font-bold bg-neutral-100 text-neutral-800 rounded-md border border-neutral-200">
                      {dept.code}
                    </span>
                    <Badge variant={dept.status === 'active' ? 'success' : 'secondary'}>
                      {dept.status === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(dept)}
                      title="Edit Department"
                      className="p-1 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-md transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onToggleDepartmentStatus(dept.id)}
                      title={dept.status === 'active' ? 'Deactivate Department' : 'Activate Department'}
                      className="p-1 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-md transition-colors"
                    >
                      <Power className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${dept.name}?`)) {
                          onDeleteDepartment(dept.id);
                        }
                      }}
                      title="Delete Department"
                      className="p-1 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-md transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <h3 className="font-semibold text-neutral-900 text-base mb-1">{dept.name}</h3>
                <p className="text-xs text-neutral-500 line-clamp-2 mb-4">
                  {dept.description || 'No description provided.'}
                </p>

                {/* HOD Info */}
                <div className="bg-neutral-50 rounded-lg p-3 border border-neutral-100 mb-4 text-xs space-y-1">
                  <div className="text-neutral-500 font-medium">Head of Department (HOD)</div>
                  <div className="font-semibold text-neutral-800">
                    {dept.headOfDepartment || 'Unassigned'}
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-2 text-xs text-neutral-600 pt-2 border-t border-neutral-100">
                  <div className="flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
                    <span>{linkedPrograms.length} Programs</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{linkedFaculty.length} Faculty</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredDepartments.length === 0 && (
          <div className="col-span-full bg-white rounded-2xl border border-dashed border-neutral-300 p-12 text-center">
            <Building2 className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="text-neutral-600 font-medium">No departments found</p>
            <p className="text-xs text-neutral-400 mt-1">Try refining your search query or add a new department.</p>
          </div>
        )}
      </div>

      {/* Modal: Add/Edit Department */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-6 border-b border-neutral-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-neutral-900">
                    {editingDepartment ? 'Edit Department' : 'Create Academic Department'}
                  </h3>
                  <p className="text-xs text-neutral-500">
                    {editingDepartment ? 'Update department specifications' : 'Define a collegiate department unit'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Department Code <span className="text-red-500">*</span>
                  </label>
                  <Input
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="e.g. CSE"
                    required
                    maxLength={8}
                    className="uppercase font-mono"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Department Name <span className="text-red-500">*</span>
                  </label>
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Department of Computer Science & Engineering"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Head of Department (HOD)
                </label>
                <select
                  value={hodId}
                  onChange={(e) => setHodId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">-- Select Faculty Head of Department --</option>
                  {facultyEmployees.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} ({f.id}) — {f.designation || 'Faculty'}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  placeholder="Summary of research areas, domains, and academic focus..."
                  className="w-full px-3 py-2 text-sm bg-white border border-neutral-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">Status</label>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 text-xs font-medium text-neutral-700 cursor-pointer">
                    <input
                      type="radio"
                      name="deptStatus"
                      value="active"
                      checked={status === 'active'}
                      onChange={() => setStatus('active')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    Active
                  </label>
                  <label className="flex items-center gap-2 text-xs font-medium text-neutral-700 cursor-pointer">
                    <input
                      type="radio"
                      name="deptStatus"
                      value="inactive"
                      checked={status === 'inactive'}
                      onChange={() => setStatus('inactive')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    Inactive
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-neutral-100">
                <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isProcessing} className="bg-blue-600 hover:bg-blue-700 text-white">
                  {isProcessing ? 'Saving...' : editingDepartment ? 'Update Department' : 'Create Department'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
