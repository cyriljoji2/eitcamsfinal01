import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  Users,
  UserCheck,
  UserPlus,
  Search,
  Filter,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  GraduationCap,
  Layers,
  ChevronRight,
  BookOpen,
  Building,
  History,
  XCircle,
  FileText,
  UserX,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { AcademicClass, AcademicSection, AcademicSession } from '../../types/academic';
import { ProctorAssignment } from '../../types/proctor';
import { proctorRepository } from '../../services/proctorService';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface ProctorManagementViewProps {
  students: Student[];
  facultyEmployees: Employee[];
  classes: AcademicClass[];
  sections: AcademicSection[];
  currentSession: AcademicSession | null;
  user: { name: string; username: string; id: string };
}

type SubTab = 'active' | 'assign' | 'history';

export function ProctorManagementView({
  students,
  facultyEmployees,
  classes,
  sections,
  currentSession,
  user,
}: ProctorManagementViewProps) {
  const [subTab, setSubTab] = useState<SubTab>('active');
  const [assignments, setAssignments] = useState<ProctorAssignment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters for Active Allocations
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassFilter, setSelectedClassFilter] = useState('all');
  const [selectedFacultyFilter, setSelectedFacultyFilter] = useState('all');

  // Single Assignment Modal / Form State
  const [isSingleModalOpen, setIsSingleModalOpen] = useState(false);
  const [targetStudentId, setTargetStudentId] = useState('');
  const [selectedFacultyId, setSelectedFacultyId] = useState('');
  const [assignmentNotes, setAssignmentNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);

  // Batch Assignment State
  const [batchClass, setBatchClass] = useState('');
  const [batchSection, setBatchSection] = useState('');
  const [batchFacultyId, setBatchFacultyId] = useState('');
  const [batchSelectedStudentIds, setBatchSelectedStudentIds] = useState<string[]>([]);
  const [batchNotes, setBatchNotes] = useState('');

  const loadAssignments = async () => {
    setIsLoading(true);
    try {
      const all = await proctorRepository.getAllAssignments();
      setAssignments(all);
    } catch (e) {
      console.error('Failed to load proctor assignments:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAssignments();
    const unsub = proctorRepository.subscribe(() => {
      loadAssignments();
    });
    return unsub;
  }, []);

  // Filter active vs history
  const activeAssignments = useMemo(() => {
    return assignments.filter((a) => a.status === 'active');
  }, [assignments]);

  const historyAssignments = useMemo(() => {
    return assignments.filter((a) => a.status !== 'active');
  }, [assignments]);

  // Active student IDs with proctor
  const activeAssignedStudentIds = useMemo(() => {
    const set = new Set<string>();
    activeAssignments.forEach((a) => {
      if (a.studentId) set.add(a.studentId.toLowerCase());
      if (a.studentRegistrationNumber) set.add(a.studentRegistrationNumber.toLowerCase());
    });
    return set;
  }, [activeAssignments]);

  // Faculty workload map: facultyId -> active proctee count
  const facultyWorkload = useMemo(() => {
    const map = new Map<string, number>();
    activeAssignments.forEach((a) => {
      const count = map.get(a.facultyId) || 0;
      map.set(a.facultyId, count + 1);
    });
    return map;
  }, [activeAssignments]);

  // Filtered active allocations list
  const filteredActiveList = useMemo(() => {
    return activeAssignments.filter((a) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        (a.studentName || '').toLowerCase().includes(q) ||
        (a.studentRegistrationNumber || '').toLowerCase().includes(q) ||
        (a.facultyName || '').toLowerCase().includes(q) ||
        (a.studentClass && a.studentClass.toLowerCase().includes(q)) ||
        (a.studentSection && a.studentSection.toLowerCase().includes(q));

      const matchClass =
        selectedClassFilter === 'all' || a.studentClass === selectedClassFilter;

      const matchFaculty =
        selectedFacultyFilter === 'all' || a.facultyId === selectedFacultyFilter;

      return matchSearch && matchClass && matchFaculty;
    });
  }, [activeAssignments, searchQuery, selectedClassFilter, selectedFacultyFilter]);

  // Summary Metrics
  const totalStudentsCount = students.length;
  const assignedCount = activeAssignments.length;
  const unassignedCount = Math.max(0, totalStudentsCount - assignedCount);
  const coveragePercent =
    totalStudentsCount > 0 ? Math.round((assignedCount / totalStudentsCount) * 100) : 0;
  const activeProctorCount = new Set(activeAssignments.map((a) => a.facultyId)).size;

  // Single Assignment handler
  const handleAssignSingle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetStudentId || !selectedFacultyId) return;

    const studentObj = students.find(
      (s) => s.id === targetStudentId || s.registrationNumber === targetStudentId
    );
    const facultyObj = facultyEmployees.find((f) => f.id === selectedFacultyId);

    if (!studentObj || !facultyObj) return;

    setIsSubmitting(true);
    try {
      await proctorRepository.assignProctor({
        studentId: studentObj.id,
        studentRegNo: studentObj.registrationNumber,
        studentName: studentObj.fullName,
        studentClass: studentObj.admissionClass,
        studentSection: studentObj.section,
        facultyId: facultyObj.id,
        facultyName: facultyObj.fullName,
        facultyDepartment: facultyObj.department,
        facultyEmail: facultyObj.email,
        facultyMobile: facultyObj.mobile,
        facultyDesignation: facultyObj.designation,
        academicSession: currentSession?.name || '2026-27',
        assignedBy: user.name || user.username,
        notes: assignmentNotes.trim() || undefined,
      });

      setActionSuccessMessage(`Successfully assigned ${facultyObj.fullName} to ${studentObj.fullName}`);
      setIsSingleModalOpen(false);
      setTargetStudentId('');
      setSelectedFacultyId('');
      setAssignmentNotes('');
      await loadAssignments();
      setTimeout(() => setActionSuccessMessage(null), 5000);
    } catch (err: any) {
      alert('Error allocating proctor: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  // Deactivate Assignment handler
  const handleDeactivate = async (assignment: ProctorAssignment) => {
    if (
      !window.confirm(
        `Are you sure you want to deactivate the proctor assignment for ${assignment.studentName}?`
      )
    ) {
      return;
    }

    try {
      await proctorRepository.deactivateAssignment(
        assignment.id,
        `Deactivated by ${user.name || user.username}`
      );
      setActionSuccessMessage(`Deactivated proctor assignment for ${assignment.studentName}`);
      await loadAssignments();
      setTimeout(() => setActionSuccessMessage(null), 5000);
    } catch (e) {
      console.error(e);
    }
  };

  // Batch section students
  const batchEligibleStudents = useMemo(() => {
    if (!batchClass && !batchSection) return [];
    return students.filter((s) => {
      const matchClass = !batchClass || s.admissionClass === batchClass;
      const matchSection = !batchSection || s.section === batchSection;
      return matchClass && matchSection;
    });
  }, [students, batchClass, batchSection]);

  const handleSelectAllBatch = () => {
    setBatchSelectedStudentIds(batchEligibleStudents.map((s) => s.id));
  };

  const handleSelectOnlyUnassignedBatch = () => {
    const unassigned = batchEligibleStudents
      .filter((s) => !activeAssignedStudentIds.has(s.id.toLowerCase()) && !activeAssignedStudentIds.has(s.registrationNumber?.toLowerCase() || ''))
      .map((s) => s.id);
    setBatchSelectedStudentIds(unassigned);
  };

  const handleExecuteBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchFacultyId || batchSelectedStudentIds.length === 0) return;

    const facultyObj = facultyEmployees.find((f) => f.id === batchFacultyId);
    if (!facultyObj) return;

    setIsSubmitting(true);
    try {
      const itemsToAssign = batchSelectedStudentIds.map((sId) => {
        const studentObj = students.find((s) => s.id === sId)!;
        return {
          studentId: studentObj.id,
          studentRegNo: studentObj.registrationNumber,
          studentName: studentObj.fullName,
          studentClass: studentObj.admissionClass,
          studentSection: studentObj.section,
          facultyId: facultyObj.id,
          facultyName: facultyObj.fullName,
          facultyDepartment: facultyObj.department,
          facultyEmail: facultyObj.email,
          facultyMobile: facultyObj.mobile,
          facultyDesignation: facultyObj.designation,
          academicSession: currentSession?.name || '2026-27',
          assignedBy: user.name || user.username,
          notes: batchNotes.trim() || undefined,
        };
      });

      await proctorRepository.bulkAssignProctors(itemsToAssign);

      setActionSuccessMessage(
        `Batch Allocation Complete: ${itemsToAssign.length} students assigned to ${facultyObj.fullName}`
      );
      setBatchSelectedStudentIds([]);
      setBatchNotes('');
      setSubTab('active');
      await loadAssignments();
      setTimeout(() => setActionSuccessMessage(null), 5000);
    } catch (err: any) {
      alert('Error in batch allocation: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">
                Proctor Allocation & Mentorship Administration
              </h1>
              <Badge variant="blue" size="sm">
                Academic Year {currentSession?.name || '2026-27'}
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Centralized proctor–proctee assignment engine, section batching, and institutional mentorship compliance
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            id="academic-assign-proctor-modal-btn"
            variant="primary"
            size="sm"
            onClick={() => setIsSingleModalOpen(true)}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Assign Proctor
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={loadAssignments}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Success Alert */}
      {actionSuccessMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{actionSuccessMessage}</span>
          </div>
          <button
            onClick={() => setActionSuccessMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 cursor-pointer"
          >
            &times;
          </button>
        </div>
      )}

      {/* Institutional Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] text-xs">
            <span className="font-semibold uppercase tracking-wider">Active Allocations</span>
            <UserCheck className="w-4 h-4 text-[#1e3a8a]" />
          </div>
          <div className="text-2xl font-bold text-[#1e293b] mt-2">{assignedCount}</div>
          <p className="text-[11px] text-[#64748b] mt-1">Students assigned to a Proctor</p>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] text-xs">
            <span className="font-semibold uppercase tracking-wider">Unassigned Students</span>
            <UserX className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-700 mt-2">{unassignedCount}</div>
          <p className="text-[11px] text-[#64748b] mt-1">Pending mentorship assignment</p>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] text-xs">
            <span className="font-semibold uppercase tracking-wider">Active Proctors</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-[#1e293b] mt-2">{activeProctorCount}</div>
          <p className="text-[11px] text-[#64748b] mt-1">Faculty with designated proctees</p>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs">
          <div className="flex items-center justify-between text-[#64748b] text-xs">
            <span className="font-semibold uppercase tracking-wider">Mentorship Coverage</span>
            <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
          </div>
          <div className="text-2xl font-bold text-[#1e3a8a] mt-2">{coveragePercent}%</div>
          <p className="text-[11px] text-[#64748b] mt-1">Overall cohort coverage</p>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="border-b border-[#e2e8f0] bg-white rounded-t-xl px-4 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setSubTab('active')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
            subTab === 'active'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>Active Allocations ({activeAssignments.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('assign')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
            subTab === 'assign'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Batch Section Allocation</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('history')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all cursor-pointer ${
            subTab === 'history'
              ? 'border-[#1e3a8a] text-[#1e3a8a] bg-blue-50/40'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Allocation History & Transfers ({historyAssignments.length})</span>
        </button>
      </div>

      {/* SUB-TAB 1: Active Allocations */}
      {subTab === 'active' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by student, reg no, or proctor..."
                className="w-full pl-9 pr-4 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden bg-white"
              />
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <select
                value={selectedClassFilter}
                onChange={(e) => setSelectedClassFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
              >
                <option value="all">All Classes / Programs</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>

              <select
                value={selectedFacultyFilter}
                onChange={(e) => setSelectedFacultyFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
              >
                <option value="all">All Faculty Members</option>
                {facultyEmployees.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.fullName} ({facultyWorkload.get(f.id) || 0} proctees)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Table */}
          {filteredActiveList.length === 0 ? (
            <div className="py-14 text-center text-[#94a3b8] text-xs">
              <UserCheck className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="font-semibold text-slate-600">No active proctor allocations match the filter.</p>
              <p className="mt-1 text-[11px]">Click "Assign Proctor" to allocate proctors to students.</p>
            </div>
          ) : (
            <div className="overflow-x-auto border border-[#e2e8f0] rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#64748b] font-semibold uppercase tracking-wider text-[11px]">
                    <th className="p-3">Student Details</th>
                    <th className="p-3">Program & Section</th>
                    <th className="p-3">Designated Proctor</th>
                    <th className="p-3">Department</th>
                    <th className="p-3">Session</th>
                    <th className="p-3">Assigned Date</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {filteredActiveList.map((asg) => (
                    <tr key={asg.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-[#1e293b]">{asg.studentName}</div>
                        <div className="text-[11px] font-mono text-[#64748b]">
                          {asg.studentRegistrationNumber}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="font-medium text-[#1e293b]">{asg.studentClass}</div>
                        <div className="text-[11px] text-[#64748b]">Sec {asg.studentSection}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-[#1e3a8a]">{asg.facultyName}</div>
                        <div className="text-[11px] font-mono text-[#64748b]">{asg.facultyId}</div>
                      </td>
                      <td className="p-3 text-[#475569]">{asg.facultyDepartment || '—'}</td>
                      <td className="p-3 text-[#475569]">{asg.academicSession}</td>
                      <td className="p-3 text-[#64748b] text-[11px]">
                        {asg.assignedDate ? asg.assignedDate.split('T')[0] : '—'}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => {
                              setTargetStudentId(asg.studentId);
                              setSelectedFacultyId('');
                              setIsSingleModalOpen(true);
                            }}
                            className="text-[11px] font-semibold text-[#1e3a8a] hover:underline px-2 py-1 rounded hover:bg-blue-50 cursor-pointer"
                          >
                            Reassign
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeactivate(asg)}
                            className="text-[11px] font-semibold text-rose-600 hover:underline px-2 py-1 rounded hover:bg-rose-50 cursor-pointer"
                          >
                            Deactivate
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: Batch Section Allocation */}
      {subTab === 'assign' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-6 space-y-6">
          <div className="border-b border-[#f1f5f9] pb-4">
            <h2 className="text-base font-bold text-[#1e293b]">Batch Section Proctor Allocation</h2>
            <p className="text-xs text-[#64748b] mt-0.5">
              Select a batch and section, choose a target faculty member, and allocate all or unassigned students with one click.
            </p>
          </div>

          <form onSubmit={handleExecuteBatch} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                  1. Program / Class <span className="text-rose-500">*</span>
                </label>
                <select
                  value={batchClass}
                  onChange={(e) => {
                    setBatchClass(e.target.value);
                    setBatchSelectedStudentIds([]);
                  }}
                  required
                  className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Select Class / Batch --</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                  2. Section <span className="text-rose-500">*</span>
                </label>
                <select
                  value={batchSection}
                  onChange={(e) => {
                    setBatchSection(e.target.value);
                    setBatchSelectedStudentIds([]);
                  }}
                  required
                  className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Select Section --</option>
                  {sections
                    .filter((s) => !batchClass || s.className === batchClass)
                    .map((s) => (
                      <option key={s.id} value={s.name}>
                        Section {s.name}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                  3. Assign To Faculty Proctor <span className="text-rose-500">*</span>
                </label>
                <select
                  value={batchFacultyId}
                  onChange={(e) => setBatchFacultyId(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Select Faculty Proctor --</option>
                  {facultyEmployees.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} ({f.department} &bull; {facultyWorkload.get(f.id) || 0} active proctees)
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Students in Selected Section */}
            {batchClass && batchSection && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-[#1e293b]">
                    Eligible Students in {batchClass} - Section {batchSection} ({batchEligibleStudents.length} total)
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleSelectAllBatch}
                      className="text-[11px] font-semibold text-[#1e3a8a] hover:underline"
                    >
                      Select All ({batchEligibleStudents.length})
                    </button>
                    <span className="text-[#cbd5e1]">&bull;</span>
                    <button
                      type="button"
                      onClick={handleSelectOnlyUnassignedBatch}
                      className="text-[11px] font-semibold text-emerald-700 hover:underline"
                    >
                      Select Only Unassigned
                    </button>
                    <span className="text-[#cbd5e1]">&bull;</span>
                    <button
                      type="button"
                      onClick={() => setBatchSelectedStudentIds([])}
                      className="text-[11px] font-semibold text-[#64748b] hover:underline"
                    >
                      Clear Selection
                    </button>
                  </div>
                </div>

                <div className="max-h-60 overflow-y-auto border border-[#e2e8f0] rounded-lg divide-y divide-[#f1f5f9]">
                  {batchEligibleStudents.map((st) => {
                    const isAssigned =
                      activeAssignedStudentIds.has(st.id.toLowerCase()) ||
                      activeAssignedStudentIds.has(st.registrationNumber?.toLowerCase() || '');
                    const currentAsg = activeAssignments.find(
                      (a) =>
                        a.studentId.toLowerCase() === st.id.toLowerCase() ||
                        (st.registrationNumber &&
                          (a.studentRegistrationNumber || '').toLowerCase() ===
                            st.registrationNumber.toLowerCase())
                    );
                    const isChecked = batchSelectedStudentIds.includes(st.id);

                    return (
                      <label
                        key={st.id}
                        className={`p-2.5 flex items-center justify-between text-xs hover:bg-slate-50 cursor-pointer ${
                          isChecked ? 'bg-blue-50/40' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setBatchSelectedStudentIds((prev) => [...prev, st.id]);
                              } else {
                                setBatchSelectedStudentIds((prev) =>
                                  prev.filter((id) => id !== st.id)
                                );
                              }
                            }}
                            className="rounded border-[#cbd5e1] text-[#1e3a8a] focus:ring-[#1e3a8a]"
                          />
                          <div>
                            <span className="font-bold text-[#1e293b]">{st.fullName}</span>
                            <span className="ml-2 font-mono text-[11px] text-[#64748b]">
                              {st.registrationNumber}
                            </span>
                          </div>
                        </div>

                        <div>
                          {isAssigned && currentAsg ? (
                            <span className="text-[11px] text-[#64748b] bg-slate-100 px-2 py-0.5 rounded">
                              Current: <strong className="text-[#1e293b]">{currentAsg.facultyName}</strong> (will transfer)
                            </span>
                          ) : (
                            <span className="text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-semibold">
                              Unassigned
                            </span>
                          )}
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                Allocation Notes (Optional)
              </label>
              <input
                type="text"
                value={batchNotes}
                onChange={(e) => setBatchNotes(e.target.value)}
                placeholder="e.g. Regular semester mentorship allocation for Section A"
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
              />
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-[#f1f5f9]">
              <div className="text-xs text-[#64748b]">
                Selected students to allocate:{' '}
                <strong className="text-[#1e293b]">{batchSelectedStudentIds.length}</strong>
              </div>

              <Button
                type="submit"
                variant="primary"
                disabled={isSubmitting || !batchFacultyId || batchSelectedStudentIds.length === 0}
                leftIcon={<UserCheck className="w-4 h-4" />}
              >
                {isSubmitting ? 'Allocating Proctors...' : `Confirm Allocation (${batchSelectedStudentIds.length})`}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* SUB-TAB 3: History & Transfers */}
      {subTab === 'history' && (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-5 space-y-4">
          <div className="border-b border-[#f1f5f9] pb-3">
            <h2 className="text-base font-bold text-[#1e293b]">Mentorship Audit & Transfer History</h2>
            <p className="text-xs text-[#64748b]">
              Complete chronological audit trail of reassignments, transfers, and inactive allocations
            </p>
          </div>

          {historyAssignments.length === 0 ? (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              No transferred or historical assignments recorded yet.
            </div>
          ) : (
            <div className="overflow-x-auto border border-[#e2e8f0] rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#64748b] font-semibold uppercase tracking-wider text-[11px]">
                    <th className="p-3">Student</th>
                    <th className="p-3">Previous Proctor</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Assigned Date</th>
                    <th className="p-3">Updated / Transferred</th>
                    <th className="p-3">Assigned By</th>
                    <th className="p-3">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {historyAssignments.map((h) => (
                    <tr key={h.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-[#1e293b]">{h.studentName}</div>
                        <div className="text-[11px] font-mono text-[#64748b]">
                          {h.studentRegistrationNumber}
                        </div>
                      </td>
                      <td className="p-3 font-semibold text-[#1e293b]">
                        {h.facultyName} ({h.facultyId})
                      </td>
                      <td className="p-3">
                        <Badge
                          variant={h.status === 'transferred' ? 'neutral' : 'amber'}
                          size="sm"
                          className="capitalize"
                        >
                          {h.status}
                        </Badge>
                      </td>
                      <td className="p-3 text-[11px] text-[#64748b]">
                        {h.assignedDate ? h.assignedDate.split('T')[0] : '—'}
                      </td>
                      <td className="p-3 text-[11px] text-[#64748b]">
                        {h.updatedAt ? h.updatedAt.split('T')[0] : '—'}
                      </td>
                      <td className="p-3 text-[11px] text-[#475569]">{h.assignedBy || 'Admin'}</td>
                      <td className="p-3 text-[11px] text-[#64748b] max-w-xs truncate">
                        {h.notes || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SINGLE ASSIGNMENT / REASSIGNMENT MODAL */}
      {isSingleModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full border border-[#e2e8f0] overflow-hidden">
            <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center font-bold">
                  <UserPlus className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-[#1e293b]">
                  {targetStudentId ? 'Assign / Reassign Proctor' : 'Individual Proctor Allocation'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsSingleModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b] text-lg font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleAssignSingle} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Select Student <span className="text-rose-500">*</span>
                </label>
                <select
                  value={targetStudentId}
                  onChange={(e) => setTargetStudentId(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Choose Student --</option>
                  {students.map((st) => {
                    const isAllocated =
                      activeAssignedStudentIds.has(st.id.toLowerCase()) ||
                      activeAssignedStudentIds.has(st.registrationNumber?.toLowerCase() || '');
                    return (
                      <option key={st.id} value={st.id}>
                        {st.fullName} ({st.registrationNumber} &bull; {st.admissionClass} Sec {st.section})
                        {isAllocated ? ' [Has Active Proctor]' : ' [Unassigned]'}
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Inform if student already has a proctor */}
              {(() => {
                const currentAsg = activeAssignments.find(
                  (a) =>
                    a.studentId.toLowerCase() === targetStudentId.toLowerCase() ||
                    (a.studentRegistrationNumber &&
                      a.studentRegistrationNumber.toLowerCase() === targetStudentId.toLowerCase())
                );
                if (currentAsg) {
                  return (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-blue-900 text-[11px] leading-relaxed">
                      <strong className="block mb-0.5">Strict Single Proctor Rule:</strong>
                      This student currently has <strong>{currentAsg.facultyName}</strong> as their active proctor.
                      Assigning a new proctor will automatically transfer the student and archive the previous assignment.
                    </div>
                  );
                }
                return null;
              })()}

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Select Faculty Proctor <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedFacultyId}
                  onChange={(e) => setSelectedFacultyId(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="">-- Choose Faculty Member --</option>
                  {facultyEmployees.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.fullName} ({f.department} &bull; {facultyWorkload.get(f.id) || 0} active proctees)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Allocation Notes (Optional)
                </label>
                <input
                  type="text"
                  value={assignmentNotes}
                  onChange={(e) => setAssignmentNotes(e.target.value)}
                  placeholder="e.g. Assigned per Department Dean recommendation"
                  className="w-full px-3 py-2 border border-[#cbd5e1] rounded-lg bg-white text-[#1e293b] focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsSingleModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={isSubmitting || !targetStudentId || !selectedFacultyId}
                >
                  {isSubmitting ? 'Assigning...' : 'Confirm Assignment'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
