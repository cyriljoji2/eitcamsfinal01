import React from 'react';
import {
  GraduationCap,
  Calendar,
  LogOut,
  User,
  ShieldCheck,
  BookOpen,
  Menu,
  X,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { AcademicSession } from '../../types/academic';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface AcademicHeaderProps {
  user: UserSession;
  currentSession: AcademicSession | null;
  sessions?: AcademicSession[];
  onSessionChange?: (sessionId: string) => void;
  onLogout: () => void;
  isFacultyMode?: boolean;
  customTitle?: string;
  isMobileMenuOpen?: boolean;
  onToggleMobileMenu?: () => void;
}

export function AcademicHeader({
  user,
  currentSession,
  sessions = [],
  onSessionChange,
  onLogout,
  isFacultyMode = false,
  customTitle,
  isMobileMenuOpen = false,
  onToggleMobileMenu,
}: AcademicHeaderProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Portal Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              {isFacultyMode ? <BookOpen className="w-5 h-5" /> : <GraduationCap className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-[#1e293b] text-base tracking-tight">
                  Electrix Institute of Technology (EIT)
                </span>
                <span className="text-xs text-[#94a3b8]">&bull;</span>
                <Badge variant={isFacultyMode ? 'emerald' : 'blue'}>
                  {isFacultyMode ? 'Faculty Portal' : 'Academic Office'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] hidden sm:block">
                {isFacultyMode
                  ? 'Instruction, Classroom Management & Attendance'
                  : 'Curriculum Planning, Class Structuring & Faculty Assignments'}
              </p>
            </div>
          </div>

          {/* Right Session Switcher & User Profile */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* Authoritative Academic Year Badge */}
            <div className="flex items-center gap-1.5 bg-[#eff6ff] border border-[#dbeafe] px-2.5 py-1.5 rounded-lg text-xs">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              <span className="text-[#1e3a8a] font-semibold hidden md:inline">AY:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">
                {activeAcademicYear || '2026–2027'}
              </span>
            </div>

            {/* Academic Session Selector if available */}
            {sessions.length > 0 && onSessionChange && !isFacultyMode && (
              <div className="hidden sm:flex items-center gap-1.5 bg-[#f8fafc] border border-[#e2e8f0] px-2.5 py-1.5 rounded-lg text-xs">
                <span className="text-[#64748b]">Session:</span>
                <select
                  value={currentSession?.id || '2026-27'}
                  onChange={(e) => onSessionChange(e.target.value)}
                  className="bg-transparent font-semibold text-[#1e293b] outline-hidden cursor-pointer text-xs"
                >
                  {sessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} {s.isCurrent ? '(Active)' : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* User Info */}
            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-[#e2e8f0]">
              <div className="w-8 h-8 rounded-full bg-[#f1f5f9] border border-[#cbd5e1] flex items-center justify-center text-[#1e3a8a] font-bold text-xs">
                {((user?.name || user?.displayName || user?.username || 'AO'))
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .slice(0, 2)
                  .toUpperCase()}
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-[#1e293b] flex items-center gap-1">
                  <span>{user?.name || user?.displayName || user?.username || 'Academic Office'}</span>
                  {user.employeeRole === 'super_admin' && (
                    <span title="Super Admin Authority">
                      <ShieldCheck className="w-3 h-3 text-amber-600" />
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-[#64748b]">
                  {user.id} &bull; {user.roleTitle || user.employeeRole || user.role}
                </div>
              </div>
            </div>

            {/* Logout Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={onLogout}
              className="text-[#64748b] hover:text-rose-700 hover:border-rose-200"
              leftIcon={<LogOut className="w-3.5 h-3.5" />}
            >
              <span className="hidden sm:inline">Logout</span>
            </Button>

            {/* Mobile menu toggle */}
            {onToggleMobileMenu && (
              <button
                type="button"
                onClick={onToggleMobileMenu}
                className="lg:hidden p-2 rounded-lg text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100 cursor-pointer transition-colors"
                aria-label="Toggle navigation menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
