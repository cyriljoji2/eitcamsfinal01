import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Calendar,
  Layers,
  BookOpen,
  UserCheck,
  Users,
  CalendarCheck,
  FileText,
  Settings,
  Sparkles,
  Clock,
  Building2,
  ShieldCheck,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import {
  AcademicClass,
  AcademicDepartment,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  AttendanceRecord,
  FacultyAssignment,
} from '../../types/academic';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { academicRepository } from '../../services/academicService';
import { admissionRepository } from '../../services/admissionService';
import { employeeRepository } from '../../services/employeeService';

import { AcademicHeader } from './AcademicHeader';
import { AcademicOverview } from './AcademicOverview';
import { AcademicSessionsView } from './AcademicSessionsView';
import { DepartmentsView } from './DepartmentsView';
import { ClassesAndSectionsView } from './ClassesAndSectionsView';
import { SubjectManagementView } from './SubjectManagementView';
import { FacultyAssignmentsView } from './FacultyAssignmentsView';
import { StudentAcademicView } from './StudentAcademicView';
import { AttendanceView } from './AttendanceView';
import { AcademicReportsView } from './AcademicReportsView';
import { ManualCourseOfferingsView } from './ManualCourseOfferingsView';
import { ProctorManagementView } from './ProctorManagementView';
import { PortalSidebar } from '../common/PortalSidebar';

interface AcademicWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export type AcademicTab =
  | 'overview'
  | 'sessions'
  | 'departments'
  | 'classes'
  | 'subjects'
  | 'faculty'
  | 'proctors'
  | 'students'
  | 'attendance'
  | 'reports'
  | 'offerings';

export function AcademicWorkspace({ user, onLogout }: AcademicWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<AcademicTab>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Academic State
  const [departments, setDepartments] = useState<AcademicDepartment[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyAssignment[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  // Admission & Employee references
  const [students, setStudents] = useState<Student[]>([]);
  const [facultyEmployees, setFacultyEmployees] = useState<Employee[]>([]);

  // Load all academic data
  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [
        departmentsData,
        sessionsData,
        classesData,
        sectionsData,
        subjectsData,
        assignmentsData,
        attendanceData,
        studentsData,
        allEmployees,
      ] = await Promise.all([
        academicRepository.getAllDepartments(),
        academicRepository.getSessions(),
        academicRepository.getClasses(),
        academicRepository.getSections(),
        academicRepository.getSubjects(),
        academicRepository.getFacultyAssignments(),
        academicRepository.getAttendanceRecords(),
        admissionRepository.getAllStudents(),
        employeeRepository.getAll(),
      ]);

      setDepartments(departmentsData);
      setSessions(sessionsData);
      setClasses(classesData);
      setSections(sectionsData);
      setSubjects(subjectsData);
      setFacultyAssignments(assignmentsData);
      setAttendanceRecords(attendanceData as AttendanceRecord[]);
      setStudents(studentsData);
      setFacultyEmployees(allEmployees.filter((e) => e.role === 'faculty'));
    } catch (err) {
      console.error('Failed to load academic workspace data', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const currentSession = sessions.find((s) => s.isCurrent) || sessions[0] || null;

  // Handler Actions for Sessions
  const handleCreateSession = async (data: Omit<AcademicSession, 'id' | 'isCurrent'>) => {
    const id = data.name.replace(/[^0-9-–]/g, '').replace('–', '-') || `${Date.now().toString().slice(-4)}`;
    const res = await academicRepository.createSession({
      ...data,
      id,
    });
    await loadData();
    return res;
  };

  const handleSetCurrentSession = async (id: string) => {
    const res = await academicRepository.setCurrentSession(id);
    await loadData();
    return res;
  };

  // Handler Actions for Classes
  const handleCreateClass = async (data: Omit<AcademicClass, 'id' | 'createdAt'>) => {
    const res = await academicRepository.createClass(data);
    await loadData();
    return res;
  };

  const handleUpdateClass = async (id: string, data: Partial<AcademicClass>) => {
    const res = await academicRepository.updateClass(id, data);
    await loadData();
    return res;
  };

  const handleToggleClassStatus = async (id: string) => {
    const res = await academicRepository.toggleClassStatus(id);
    await loadData();
    return res;
  };

  const handleDeleteClass = async (id: string) => {
    const res = await academicRepository.deleteClass(id);
    await loadData();
    return res;
  };

  // Handler Actions for Sections
  const handleCreateSection = async (data: Omit<AcademicSection, 'id' | 'createdAt'>) => {
    const res = await academicRepository.createSection(data);
    await loadData();
    return res;
  };

  const handleUpdateSection = async (id: string, data: Partial<AcademicSection>) => {
    const res = await academicRepository.updateSection(id, data);
    await loadData();
    return res;
  };

  const handleToggleSectionStatus = async (id: string) => {
    const res = await academicRepository.toggleSectionStatus(id);
    await loadData();
    return res;
  };

  const handleDeleteSection = async (id: string) => {
    const res = await academicRepository.deleteSection(id);
    await loadData();
    return res;
  };

  // Handler Actions for Subjects
  const handleCreateSubject = async (data: Omit<AcademicSubject, 'id' | 'createdAt'>) => {
    const res = await academicRepository.createSubject(data);
    await loadData();
    return res;
  };

  const handleUpdateSubject = async (id: string, data: Partial<AcademicSubject>) => {
    const res = await academicRepository.updateSubject(id, data);
    await loadData();
    return res;
  };

  const handleToggleSubjectStatus = async (id: string) => {
    const res = await academicRepository.toggleSubjectStatus(id);
    await loadData();
    return res;
  };

  const handleDeleteSubject = async (id: string) => {
    const res = await academicRepository.deleteSubject(id);
    await loadData();
    return res;
  };

  // Handler Actions for Faculty Assignments
  const handleCreateAssignment = async (data: Omit<FacultyAssignment, 'id' | 'assignedAt'>) => {
    const res = await academicRepository.createFacultyAssignment(data);
    await loadData();
    return res;
  };

  const handleUpdateAssignment = async (id: string, data: Partial<FacultyAssignment>) => {
    const res = await academicRepository.updateFacultyAssignment(id, data);
    await loadData();
    return res;
  };

  const handleDeleteAssignment = async (id: string) => {
    const res = await academicRepository.deleteFacultyAssignment(id);
    await loadData();
    return res;
  };

  // Handler for Student Reassignment
  const handleReassignStudent = async (
    studentIdOrRegNo: string,
    newClassName: string,
    newSectionName: string
  ) => {
    const res = await academicRepository.reassignStudent(
      studentIdOrRegNo,
      newClassName,
      newSectionName
    );
    await loadData();
    return res;
  };

  // Department Handlers
  const handleCreateDepartment = async (data: Omit<AcademicDepartment, 'id' | 'createdAt'>) => {
    const res = await academicRepository.createDepartment(data);
    await loadData();
    return res;
  };

  const handleUpdateDepartment = async (id: string, data: Partial<AcademicDepartment>) => {
    const res = await academicRepository.updateDepartment(id, data);
    await loadData();
    return res;
  };

  const handleToggleDepartmentStatus = async (id: string) => {
    const res = await academicRepository.toggleDepartmentStatus(id);
    await loadData();
    return res;
  };

  const handleDeleteDepartment = async (id: string) => {
    const res = await academicRepository.deleteDepartment(id);
    await loadData();
    return res;
  };

  // Handler for Attendance Batch Save
  const handleSaveAttendance = async (
    records: Omit<AttendanceRecord, 'id' | 'recordedAt'>[]
  ) => {
    const res = await academicRepository.saveBatchAttendance(records as any);
    await loadData();
    return res as AttendanceRecord[];
  };

  const navItems = [
    { id: 'overview', label: 'Academic Overview', icon: LayoutDashboard },
    { id: 'sessions', label: 'Academic Sessions', icon: Calendar },
    { id: 'departments', label: 'Departments', icon: Building2 },
    { id: 'classes', label: 'Programs & Batches', icon: Layers },
    { id: 'subjects', label: 'Course Curriculum', icon: BookOpen },
    { id: 'faculty', label: 'Faculty Assignments', icon: UserCheck },
    { id: 'proctors', label: 'Proctor Management', icon: ShieldCheck },
    { id: 'students', label: 'Students', icon: Users },
    { id: 'attendance', label: 'Attendance Management', icon: CalendarCheck },
    { id: 'reports', label: 'Academic Reports', icon: FileText },
    { id: 'offerings', label: 'Manual Course Offerings', icon: Clock },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Shared Academic Header */}
      <AcademicHeader
        user={user}
        currentSession={currentSession}
        sessions={sessions}
        onSessionChange={handleSetCurrentSession}
        onLogout={onLogout}
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      />

      {/* Main Workspace Layout (Sidebar + Content) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col lg:flex-row gap-6">
        {/* Left Navigation Sidebar */}
        <PortalSidebar
          items={navItems}
          activeTab={activeTab}
          onSelectTab={(tabId) => {
            setActiveTab(tabId as AcademicTab);
            setIsMobileMenuOpen(false);
          }}
          isOpenMobile={isMobileMenuOpen}
          idPrefix="academic-nav"
        />

        {/* Content Canvas */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="py-20 text-center text-xs text-[#94a3b8]">
              Loading Academic Office workspace...
            </div>
          ) : (
            <>
            {activeTab === 'overview' && (
              <AcademicOverview
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                subjects={subjects}
                facultyAssignments={facultyAssignments}
                facultyEmployees={facultyEmployees}
                students={students}
                attendanceRecords={attendanceRecords}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'sessions' && (
              <AcademicSessionsView
                sessions={sessions}
                onCreateSession={handleCreateSession}
                onSetCurrentSession={handleSetCurrentSession}
              />
            )}

            {activeTab === 'departments' && (
              <DepartmentsView
                departments={departments}
                programs={classes}
                facultyEmployees={facultyEmployees}
                onCreateDepartment={handleCreateDepartment}
                onUpdateDepartment={handleUpdateDepartment}
                onToggleDepartmentStatus={handleToggleDepartmentStatus}
                onDeleteDepartment={handleDeleteDepartment}
              />
            )}

            {activeTab === 'classes' && (
              <ClassesAndSectionsView
                classes={classes}
                sections={sections}
                students={students}
                facultyEmployees={facultyEmployees}
                onCreateClass={handleCreateClass}
                onUpdateClass={handleUpdateClass}
                onToggleClassStatus={handleToggleClassStatus}
                onDeleteClass={handleDeleteClass}
                onCreateSection={handleCreateSection}
                onUpdateSection={handleUpdateSection}
                onToggleSectionStatus={handleToggleSectionStatus}
                onDeleteSection={handleDeleteSection}
              />
            )}

            {activeTab === 'subjects' && (
              <SubjectManagementView
                subjects={subjects}
                classes={classes}
                sections={sections}
                onCreateSubject={handleCreateSubject}
                onUpdateSubject={handleUpdateSubject}
                onToggleSubjectStatus={handleToggleSubjectStatus}
                onDeleteSubject={handleDeleteSubject}
              />
            )}

            {activeTab === 'faculty' && (
              <FacultyAssignmentsView
                facultyEmployees={facultyEmployees}
                assignments={facultyAssignments}
                classes={classes}
                sections={sections}
                subjects={subjects}
                currentSession={currentSession}
                onCreateAssignment={handleCreateAssignment}
                onUpdateAssignment={handleUpdateAssignment}
                onDeleteAssignment={handleDeleteAssignment}
              />
            )}

            {activeTab === 'proctors' && (
              <ProctorManagementView
                students={students}
                facultyEmployees={facultyEmployees}
                classes={classes}
                sections={sections}
                currentSession={currentSession}
                user={{ name: user.name || user.username || user.id, username: user.username || user.id, id: user.id }}
              />
            )}

            {activeTab === 'students' && (
              <StudentAcademicView
                students={students}
                classes={classes}
                sections={sections}
                onReassignStudent={handleReassignStudent}
              />
            )}

            {activeTab === 'attendance' && (
              <AttendanceView
                user={user}
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                students={students}
                assignments={facultyAssignments}
                attendanceRecords={attendanceRecords}
                onSaveAttendance={handleSaveAttendance}
                isFacultyOnly={false}
              />
            )}

            {activeTab === 'reports' && (
              <AcademicReportsView
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                subjects={subjects}
                facultyEmployees={facultyEmployees}
                assignments={facultyAssignments}
                students={students}
                attendanceRecords={attendanceRecords}
              />
            )}

            {activeTab === 'offerings' && (
              <ManualCourseOfferingsView
                user={user}
                currentSession={currentSession}
                classes={classes}
                sections={sections}
                subjects={subjects}
                facultyEmployees={facultyEmployees}
                students={students}
                onRefresh={loadData}
              />
            )}
          </>
        )}
        </main>
      </div>
    </div>
  );
}
