import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  Layers,
  Grid,
  FileText,
  Edit2,
  CheckCircle2,
  XCircle,
  X,
  Sparkles,
  Eye,
  ArrowRightLeft,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { AcademicClass, AcademicSection } from '../../types/academic';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';
import { StudentAcademicProfileModal } from './StudentAcademicProfileModal';

interface StudentAcademicViewProps {
  students: Student[];
  classes: AcademicClass[];
  sections: AcademicSection[];
  onReassignStudent: (
    studentIdOrRegNo: string,
    newClassName: string,
    newSectionName: string
  ) => Promise<Student>;
}

export function StudentAcademicView({
  students,
  classes,
  sections,
  onReassignStudent,
}: StudentAcademicViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassFilter, setSelectedClassFilter] = useState('all');
  const [selectedSectionFilter, setSelectedSectionFilter] = useState('all');

  // Academic Profile Modal
  const [selectedRegNo, setSelectedRegNo] = useState<string | null>(null);

  // Reassignment Modal
  const [reassignModalOpen, setReassignModalOpen] = useState(false);
  const [targetStudent, setTargetStudent] = useState<Student | null>(null);
  const [newClassInput, setNewClassInput] = useState('');
  const [newSectionInput, setNewSectionInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Filter students
  const filteredStudents = students.filter((s) => {
    const studentProgram = s.program || s.admissionClass || '';
    const studentBatch = s.batch || s.section || '';

    const matchesSearch =
      s.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.registrationNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      studentProgram.toLowerCase().includes(searchQuery.toLowerCase()) ||
      studentBatch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.guardianName && s.guardianName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesClass =
      selectedClassFilter === 'all' ||
      studentProgram.toLowerCase() === selectedClassFilter.toLowerCase();

    const matchesSection =
      selectedSectionFilter === 'all' ||
      studentBatch.toLowerCase().includes(selectedSectionFilter.toLowerCase());

    return matchesSearch && matchesClass && matchesSection;
  });

  const handleOpenReassign = (student: Student) => {
    setTargetStudent(student);
    setNewClassInput(student.program || student.admissionClass);
    setNewSectionInput(student.batch || student.section);
    setReassignModalOpen(true);
  };

  const handleReassignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetStudent || !newClassInput || !newSectionInput) return;

    setIsProcessing(true);
    try {
      await onReassignStudent(targetStudent.id, newClassInput, newSectionInput);
      setReassignModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Failed to reassign student');
    } finally {
      setIsProcessing(false);
    }
  };

  // Sections available for the selected target class in reassignment modal
  const targetClassSections = sections.filter(
    (sec) =>
      (sec.className && sec.className.toLowerCase() === newClassInput.toLowerCase()) ||
      (sec.classId && sec.classId.toLowerCase() === newClassInput.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <Users className="w-5 h-5 text-[#1e3a8a]" />
            <span>Student Academic Directory & Class Assignments</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            View enrolled students from Admissions, review course rosters, and reassign academic grade levels or sections.
          </p>
        </div>

        <div className="text-xs text-[#64748b] bg-[#f8fafc] border border-[#e2e8f0] px-3.5 py-2 rounded-lg">
          Enrolled Roster: <strong className="text-[#1e293b]">{students.length} Students</strong>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="w-full md:w-80">
          <Input
            placeholder="Search by name, Registration # (REG-2026-...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            startIcon={<Search className="w-4 h-4 text-[#94a3b8]" />}
            className="h-9 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          {/* Program Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <Filter className="w-3.5 h-3.5" />
            <span>Program:</span>
            <select
              value={selectedClassFilter}
              onChange={(e) => {
                setSelectedClassFilter(e.target.value);
                setSelectedSectionFilter('all');
              }}
              className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
            >
              <option value="all">All Programs</option>
              {classes.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Batch Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <span>Batch:</span>
            <select
              value={selectedSectionFilter}
              onChange={(e) => setSelectedSectionFilter(e.target.value)}
              className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
            >
              <option value="all">All Batches</option>
              <option value="2026">Batch 2026</option>
              <option value="2025">Batch 2025</option>
              <option value="2024">Batch 2024</option>
              <option value="A">Group A</option>
              <option value="B">Group B</option>
            </select>
          </div>
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span className="font-semibold text-[#1e293b]">
            Enrolled Student Records ({filteredStudents.length} Students)
          </span>
          <span>Primary Identifier: Registration Number</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4 font-semibold">Registration No.</th>
                <th className="py-3 px-4 font-semibold">Student Name</th>
                <th className="py-3 px-4 font-semibold">Enrolled Program & Batch</th>
                <th className="py-3 px-4 font-semibold">Parent / Guardian</th>
                <th className="py-3 px-4 font-semibold">Admission Date</th>
                <th className="py-3 px-4 font-semibold">Account</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-xs text-[#94a3b8]">
                    No students match your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => setSelectedRegNo(s.registrationNumber)}
                        className="font-mono font-bold text-[#1e3a8a] hover:underline text-xs"
                      >
                        {s.registrationNumber}
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">{s.fullName}</div>
                      <div className="text-[11px] text-[#64748b]">{s.email}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-1.5">
                          <Badge variant="blue">{s.program || s.admissionClass}</Badge>
                          <span className="font-bold text-[#1e293b] text-[11px]">
                            {s.batch || (s.section ? `Sec ${s.section}` : '')}
                          </span>
                        </div>
                        {s.currentSemester && (
                          <span className="text-[10px] text-[#64748b]">
                            {s.currentSemester}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-[#1e293b]">
                      <div>{s.guardianName || s.fatherName || s.motherName || 'Parent'}</div>
                      <div className="text-[11px] text-[#64748b]">{s.mobile}</div>
                    </td>
                    <td className="py-3 px-4 text-[#64748b]">{s.admissionDate}</td>
                    <td className="py-3 px-4">
                      <Badge variant={s.accountStatus === 'active' ? 'emerald' : 'slate'}>
                        {s.accountStatus}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedRegNo(s.registrationNumber)}
                          leftIcon={<Eye className="w-3.5 h-3.5" />}
                          className="h-7 text-xs px-2"
                        >
                          Profile
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenReassign(s)}
                          leftIcon={<ArrowRightLeft className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                          className="h-7 text-xs px-2 text-[#1e3a8a] hover:bg-[#eff6ff]"
                          title="Reassign Program & Batch"
                        >
                          Reassign
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Student Academic Profile Modal */}
      {selectedRegNo && (
        <StudentAcademicProfileModal
          registrationNumber={selectedRegNo}
          onClose={() => setSelectedRegNo(null)}
          onOpenReassign={(reg) => {
            const st = students.find((s) => s.registrationNumber === reg);
            if (st) handleOpenReassign(st);
          }}
        />
      )}

      {/* Reassign Class & Section Modal */}
      {reassignModalOpen && targetStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Reassign Program & Batch</h3>
              </div>
              <button
                type="button"
                onClick={() => setReassignModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleReassignSubmit} className="p-4 space-y-3.5 text-xs">
              <div className="bg-[#f8fafc] border border-[#e2e8f0] p-3 rounded-lg space-y-1">
                <div className="font-bold text-[#1e293b]">{targetStudent.fullName}</div>
                <div className="text-[11px] text-[#64748b] flex items-center gap-2">
                  <span className="font-mono">{targetStudent.registrationNumber}</span>
                  <span>&bull;</span>
                  <span>
                    Current: <strong>{targetStudent.program || targetStudent.admissionClass} - {targetStudent.batch || targetStudent.section}</strong>
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Select New Degree Program *
                </label>
                <select
                  required
                  value={newClassInput}
                  onChange={(e) => {
                    setNewClassInput(e.target.value);
                    const matchingSecs = sections.filter(
                      (sec) =>
                        (sec.className && sec.className.toLowerCase() === e.target.value.toLowerCase()) ||
                        (sec.classId && sec.classId.toLowerCase() === e.target.value.toLowerCase())
                    );
                    if (matchingSecs.length > 0) {
                      setNewSectionInput(matchingSecs[0].name);
                    }
                  }}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name} ({c.stream || c.department || 'General'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Select Batch / Cohort *
                </label>
                <select
                  required
                  value={newSectionInput}
                  onChange={(e) => setNewSectionInput(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  {targetClassSections.length > 0 ? (
                    targetClassSections.map((sec) => (
                      <option key={sec.id} value={sec.name}>
                        {sec.name} ({sec.roomNumber || sec.room || 'Room TBD'})
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="Batch 2026 - Group A">Batch 2026 - Group A</option>
                      <option value="Batch 2026 - Group B">Batch 2026 - Group B</option>
                      <option value="A">Section A</option>
                      <option value="B">Section B</option>
                    </>
                  )}
                </select>
              </div>

              <p className="text-[11px] text-[#64748b] bg-amber-50 border border-amber-200 text-amber-900 p-2.5 rounded-lg">
                <strong>Notice:</strong> Registration Number (<code>{targetStudent.registrationNumber}</code>) will remain permanently unchanged. Curriculum courses will automatically map to the new program.
              </p>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setReassignModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  Confirm Reassignment
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
