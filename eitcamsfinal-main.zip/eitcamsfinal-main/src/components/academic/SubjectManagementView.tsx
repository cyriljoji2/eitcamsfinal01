import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  BookOpen,
  Plus,
  Edit2,
  Power,
  Trash2,
  Search,
  Filter,
  Layers,
  X,
  Sparkles,
  UploadCloud,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  GraduationCap,
} from 'lucide-react';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  AcademicCurriculumEntry,
  SubjectStatus,
  SubjectType,
} from '../../types/academic';
import {
  academicRepository,
  generateCurriculumCsvTemplate,
} from '../../services/academicService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';
import { CurriculumImportModal } from './CurriculumImportModal';

interface SubjectManagementViewProps {
  subjects: AcademicSubject[];
  classes: AcademicClass[];
  sections?: AcademicSection[];
  onCreateSubject: (data: Omit<AcademicSubject, 'id' | 'createdAt'>) => Promise<AcademicSubject>;
  onUpdateSubject: (id: string, data: Partial<AcademicSubject>) => Promise<AcademicSubject>;
  onToggleSubjectStatus: (id: string) => Promise<AcademicSubject>;
  onDeleteSubject: (id: string) => Promise<boolean>;
}

export function SubjectManagementView({
  subjects,
  classes,
  sections = [],
  onCreateSubject,
  onUpdateSubject,
  onToggleSubjectStatus,
  onDeleteSubject,
}: SubjectManagementViewProps) {
  // Top view mode: 'curriculum' or 'catalog'
  const [activeSubTab, setActiveSubTab] = useState<'curriculum' | 'catalog'>('curriculum');

  // Dynamic classes and sections master data
  const [activeClasses, setActiveClasses] = useState<AcademicClass[]>(classes || []);
  const [activeSections, setActiveSections] = useState<AcademicSection[]>(sections || []);

  const refreshMasterData = useCallback(async () => {
    try {
      const [fetchedClasses, fetchedSections] = await Promise.all([
        academicRepository.getAllClasses(),
        academicRepository.getAllSections(),
      ]);
      if (fetchedClasses && fetchedClasses.length > 0) {
        setActiveClasses(fetchedClasses);
      }
      if (fetchedSections && fetchedSections.length > 0) {
        setActiveSections(fetchedSections);
      }
    } catch (err) {
      console.error('Failed to refresh academic master data:', err);
    }
  }, []);

  useEffect(() => {
    refreshMasterData();
  }, [refreshMasterData]);

  useEffect(() => {
    if (classes && classes.length > 0) {
      setActiveClasses(classes);
    }
  }, [classes]);

  useEffect(() => {
    if (sections && sections.length > 0) {
      setActiveSections(sections);
    }
  }, [sections]);

  // ==========================================
  // CURRICULUM STATE
  // ==========================================
  const [curriculumList, setCurriculumList] = useState<AcademicCurriculumEntry[]>([]);
  const [isCurriculumLoading, setIsCurriculumLoading] = useState(true);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isAddCurriculumModalOpen, setIsAddCurriculumModalOpen] = useState(false);

  // Curriculum Filters
  const [curriculumProgramFilter, setCurriculumProgramFilter] = useState<string>('all');
  const [curriculumBatchFilter, setCurriculumBatchFilter] = useState<string>('all');
  const [curriculumBasketFilter, setCurriculumBasketFilter] = useState<string>('all');
  const [curriculumCategoryFilter, setCurriculumCategoryFilter] = useState<string>('all');
  const [curriculumSearchQuery, setCurriculumSearchQuery] = useState('');

  // Manual Add Curriculum Form
  const [formProg, setFormProg] = useState('');
  const [formBatch, setFormBatch] = useState('');
  const [formCode, setFormCode] = useState('');
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState('Core');
  const [formCredits, setFormCredits] = useState<number>(4);
  const [formCategory, setFormCategory] = useState('PC');
  const [formBasket, setFormBasket] = useState('Program Core');
  const [isSubmittingCurriculum, setIsSubmittingCurriculum] = useState(false);

  // Load Curriculum
  const loadCurriculum = useCallback(async () => {
    setIsCurriculumLoading(true);
    try {
      const data = await academicRepository.getAllCurriculum();
      setCurriculumList(data);
      refreshMasterData();
    } catch (err) {
      console.error('Failed to load curriculum:', err);
    } finally {
      setIsCurriculumLoading(false);
    }
  }, [refreshMasterData]);

  useEffect(() => {
    loadCurriculum();
  }, [loadCurriculum]);

  // Subscribe to academic repository updates (e.g. background hydration or remote sync)
  useEffect(() => {
    if (typeof academicRepository.subscribe === 'function') {
      const unsubscribe = academicRepository.subscribe(() => {
        loadCurriculum();
      });
      return () => {
        unsubscribe();
      };
    }
  }, [loadCurriculum]);

  // Distinct Batches and Programs in Curriculum
  const distinctPrograms = useMemo(() => {
    const set = new Set<string>();
    activeClasses.forEach((c) => { if (c.name) set.add(c.name); });
    curriculumList.forEach((c) => { if (c.program) set.add(c.program); });
    return Array.from(set).filter(Boolean);
  }, [activeClasses, curriculumList]);

  const distinctBatches = useMemo(() => {
    const set = new Set<string>();
    activeSections.forEach((s) => { if (s.name) set.add(s.name); });
    curriculumList.forEach((c) => { if (c.batch) set.add(c.batch); });
    return Array.from(set).filter(Boolean);
  }, [activeSections, curriculumList]);

  const distinctBaskets = useMemo(() => {
    const set = new Set<string>();
    curriculumList.forEach((c) => {
      if (c.basket) set.add(c.basket);
    });
    return Array.from(set);
  }, [curriculumList]);

  const handleOpenAddCurriculum = () => {
    const initialProg =
      curriculumProgramFilter !== 'all'
        ? curriculumProgramFilter
        : activeClasses[0]?.name || distinctPrograms[0] || '';
    const initialBatch =
      curriculumBatchFilter !== 'all'
        ? curriculumBatchFilter
        : activeSections[0]?.name || distinctBatches[0] || '';

    setFormProg(initialProg);
    setFormBatch(initialBatch);
    setFormCode('');
    setFormName('');
    setFormType('Core');
    setFormCredits(4);
    setFormCategory('PC');
    setFormBasket('Program Core');
    setIsAddCurriculumModalOpen(true);
  };

  // Filtered Curriculum
  const filteredCurriculum = useMemo(() => {
    return curriculumList.filter((item) => {
      if (curriculumProgramFilter !== 'all' && item.program !== curriculumProgramFilter) {
        return false;
      }
      if (curriculumBatchFilter !== 'all' && item.batch !== curriculumBatchFilter) {
        return false;
      }
      if (curriculumBasketFilter !== 'all' && item.basket !== curriculumBasketFilter) {
        return false;
      }
      if (curriculumCategoryFilter !== 'all' && item.category !== curriculumCategoryFilter) {
        return false;
      }
      if (curriculumSearchQuery.trim()) {
        const q = curriculumSearchQuery.toLowerCase().trim();
        return (
          (item.courseCode && item.courseCode.toLowerCase().includes(q)) ||
          (item.courseName && item.courseName.toLowerCase().includes(q)) ||
          (item.program && item.program.toLowerCase().includes(q)) ||
          (item.batch && item.batch.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [
    curriculumList,
    curriculumProgramFilter,
    curriculumBatchFilter,
    curriculumBasketFilter,
    curriculumCategoryFilter,
    curriculumSearchQuery,
  ]);

  // Curriculum Stats
  const curriculumTotalCredits = filteredCurriculum.reduce((sum, item) => sum + (Number(item.credits) || 0), 0);
  const pcCredits = filteredCurriculum.filter((c) => c.category === 'PC').reduce((sum, c) => sum + (Number(c.credits) || 0), 0);
  const peCredits = filteredCurriculum.filter((c) => c.category === 'PE').reduce((sum, c) => sum + (Number(c.credits) || 0), 0);
  const oeCredits = filteredCurriculum.filter((c) => c.category === 'OE').reduce((sum, c) => sum + (Number(c.credits) || 0), 0);
  const ucCredits = filteredCurriculum.filter((c) => c.category === 'UC').reduce((sum, c) => sum + (Number(c.credits) || 0), 0);

  const handleDownloadTemplate = () => {
    const content = generateCurriculumCsvTemplate();
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'curriculum_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCreateCurriculum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCode.trim() || !formName.trim() || !formProg.trim() || !formBatch.trim()) return;

    setIsSubmittingCurriculum(true);
    try {
      await academicRepository.createCurriculumEntry({
        batch: formBatch,
        program: formProg,
        courseCode: formCode.toUpperCase().trim(),
        courseName: formName.trim(),
        type: formType,
        credits: Number(formCredits) || 3,
        category: formCategory.toUpperCase().trim(),
        basket: formBasket.trim(),
        status: 'active',
      });
      await loadCurriculum();
      setIsAddCurriculumModalOpen(false);
      setFormCode('');
      setFormName('');
    } catch (err) {
      console.error('Failed to create curriculum entry:', err);
    } finally {
      setIsSubmittingCurriculum(false);
    }
  };

  const handleDeleteCurriculum = async (id: string, code: string) => {
    if (!confirm(`Are you sure you want to remove ${code} from this curriculum?`)) return;
    try {
      await academicRepository.deleteCurriculumEntry(id);
      await loadCurriculum();
    } catch (err) {
      console.error('Failed to delete curriculum item:', err);
    }
  };

  // ==========================================
  // CATALOG STATE (Existing Subjects)
  // ==========================================
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<AcademicSubject | null>(null);

  const [subjectNameInput, setSubjectNameInput] = useState('');
  const [subjectCodeInput, setSubjectCodeInput] = useState('');
  const [subjectClassIdInput, setSubjectClassIdInput] = useState(activeClasses[0]?.id || '');
  const [subjectTypeInput, setSubjectTypeInput] = useState<SubjectType>('Core');
  const [subjectCreditsInput, setSubjectCreditsInput] = useState<number>(5);
  const [subjectDescInput, setSubjectDescInput] = useState('');
  const [subjectStatusInput, setSubjectStatusInput] = useState<SubjectStatus>('active');

  const [isProcessing, setIsProcessing] = useState(false);

  // Filter subjects
  const filteredSubjects = subjects.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.className ? s.className.toLowerCase().includes(searchQuery.toLowerCase()) : false);

    const matchesClass =
      selectedClassFilter === 'all' || (s.classId ? s.classId.toLowerCase() === selectedClassFilter.toLowerCase() : false);

    const matchesStatus = selectedStatusFilter === 'all' || s.status === selectedStatusFilter;

    return matchesSearch && matchesClass && matchesStatus;
  });

  const handleOpenAdd = () => {
    setEditingSubject(null);
    setSubjectNameInput('');
    setSubjectCodeInput('');
    setSubjectClassIdInput(activeClasses[0]?.id || '');
    setSubjectTypeInput('Core');
    setSubjectCreditsInput(5);
    setSubjectDescInput('');
    setSubjectStatusInput('active');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (sub: AcademicSubject) => {
    setEditingSubject(sub);
    setSubjectNameInput(sub.name);
    setSubjectCodeInput(sub.code);
    setSubjectClassIdInput(sub.classId || '');
    setSubjectTypeInput(sub.type || 'Core');
    setSubjectCreditsInput(sub.creditsOrPeriodsPerWeek || 5);
    setSubjectDescInput(sub.description || '');
    setSubjectStatusInput(sub.status || 'active');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjectNameInput.trim() || !subjectCodeInput.trim()) return;

    const parentClass = activeClasses.find((c) => c.id === subjectClassIdInput) || activeClasses[0];
    if (!parentClass) return;

    setIsProcessing(true);
    try {
      if (editingSubject) {
        await onUpdateSubject(editingSubject.id, {
          name: subjectNameInput.trim(),
          code: subjectCodeInput.trim().toUpperCase(),
          classId: parentClass.id,
          className: parentClass.name,
          credits: Number(subjectCreditsInput) || 3,
          creditsOrPeriodsPerWeek: Number(subjectCreditsInput) || 3,
          type: subjectTypeInput,
          description: subjectDescInput.trim() || undefined,
          status: subjectStatusInput,
        });
      } else {
        await onCreateSubject({
          name: subjectNameInput.trim(),
          code: subjectCodeInput.trim().toUpperCase(),
          classId: parentClass.id,
          className: parentClass.name,
          credits: Number(subjectCreditsInput) || 3,
          creditsOrPeriodsPerWeek: Number(subjectCreditsInput) || 3,
          type: subjectTypeInput,
          description: subjectDescInput.trim() || undefined,
          status: subjectStatusInput,
        });
      }
      setIsModalOpen(false);
    } catch (err) {
      console.error('Failed to save subject:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Level Sub-Tab Toggle */}
      <div className="flex items-center justify-between flex-wrap gap-3 bg-white p-2 border border-[#e2e8f0] rounded-xl shadow-xs">
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setActiveSubTab('curriculum')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeSubTab === 'curriculum'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Program & Batch Curriculum</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
              {curriculumList.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('catalog')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-all ${
              activeSubTab === 'catalog'
                ? 'bg-[#1e3a8a] text-white shadow-xs'
                : 'text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Master Course Catalog</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-[#475569]">
              {subjects.length}
            </span>
          </button>
        </div>

        {/* Global Action Shortcut */}
        {activeSubTab === 'curriculum' ? (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadTemplate}
              leftIcon={<Download className="w-3.5 h-3.5" />}
            >
              CSV Template
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsImportModalOpen(true)}
              leftIcon={<UploadCloud className="w-4 h-4" />}
            >
              Import CSV
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenAddCurriculum}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Curriculum Course
            </Button>
          </div>
        ) : (
          <Button
            variant="primary"
            size="sm"
            onClick={handleOpenAdd}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Add Master Course
          </Button>
        )}
      </div>

      {/* ========================================================================= */}
      {/* VIEW 1: PROGRAM & BATCH CURRICULUM                                        */}
      {/* ========================================================================= */}
      {activeSubTab === 'curriculum' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Header Banner */}
          <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base font-bold text-[#1e293b]">
                  Degree Program & Batch Curriculum Master
                </h2>
                <Badge variant="blue" size="sm">
                  Official Degree Syllabus
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 max-w-2xl">
                Curriculum requirements are scoped strictly by <strong>Degree Program</strong> and{' '}
                <strong>Admission Batch</strong>. Semester is deliberately independent and belongs to FFCS offering cycles.
              </p>
            </div>

            {/* Credit Metrics Pill */}
            <div className="flex items-center gap-2 bg-[#f8fafc] border border-[#e2e8f0] px-3.5 py-2 rounded-xl text-xs">
              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-[#64748b] block">
                  Total Credits Filtered
                </span>
                <span className="font-extrabold text-[#1e3a8a] text-sm">
                  {curriculumTotalCredits} cr
                </span>
              </div>
            </div>
          </div>

          {/* Quick Credit Breakdown Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white border border-[#e2e8f0] p-3 rounded-xl shadow-2xs">
              <span className="text-[11px] font-semibold text-[#64748b] block">Program Core (PC)</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-base font-bold text-blue-700">{pcCredits} Credits</span>
                <Badge variant="blue" size="sm">PC</Badge>
              </div>
            </div>
            <div className="bg-white border border-[#e2e8f0] p-3 rounded-xl shadow-2xs">
              <span className="text-[11px] font-semibold text-[#64748b] block">Program Elective (PE)</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-base font-bold text-indigo-700">{peCredits} Credits</span>
                <Badge variant="slate" size="sm">PE</Badge>
              </div>
            </div>
            <div className="bg-white border border-[#e2e8f0] p-3 rounded-xl shadow-2xs">
              <span className="text-[11px] font-semibold text-[#64748b] block">University Core (UC)</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-base font-bold text-emerald-700">{ucCredits} Credits</span>
                <Badge variant="emerald" size="sm">UC</Badge>
              </div>
            </div>
            <div className="bg-white border border-[#e2e8f0] p-3 rounded-xl shadow-2xs">
              <span className="text-[11px] font-semibold text-[#64748b] block">Open Elective (OE)</span>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-base font-bold text-amber-700">{oeCredits} Credits</span>
                <Badge variant="amber" size="sm">OE</Badge>
              </div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1 md:max-w-xs">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
              <input
                type="text"
                placeholder="Search curriculum by code or title..."
                value={curriculumSearchQuery}
                onChange={(e) => setCurriculumSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              {/* Program Filter */}
              <div className="flex items-center gap-1">
                <span className="text-[#64748b] font-medium">Program:</span>
                <select
                  value={curriculumProgramFilter}
                  onChange={(e) => setCurriculumProgramFilter(e.target.value)}
                  className="py-1 px-2.5 border border-[#cbd5e1] rounded-lg text-xs bg-white text-[#1e293b]"
                >
                  <option value="all">All Programs ({distinctPrograms.length})</option>
                  {distinctPrograms.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>

              {/* Batch Filter */}
              <div className="flex items-center gap-1">
                <span className="text-[#64748b] font-medium">Batch:</span>
                <select
                  value={curriculumBatchFilter}
                  onChange={(e) => setCurriculumBatchFilter(e.target.value)}
                  className="py-1 px-2.5 border border-[#cbd5e1] rounded-lg text-xs bg-white text-[#1e293b]"
                >
                  <option value="all">All Batches ({distinctBatches.length})</option>
                  {distinctBatches.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </div>

              {/* Basket Filter */}
              {distinctBaskets.length > 0 && (
                <div className="flex items-center gap-1">
                  <span className="text-[#64748b] font-medium">Basket:</span>
                  <select
                    value={curriculumBasketFilter}
                    onChange={(e) => setCurriculumBasketFilter(e.target.value)}
                    className="py-1 px-2.5 border border-[#cbd5e1] rounded-lg text-xs bg-white text-[#1e293b]"
                  >
                    <option value="all">All Baskets</option>
                    {distinctBaskets.map((bk) => (
                      <option key={bk} value={bk}>
                        {bk}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Category Filter */}
              <div className="flex items-center gap-1">
                <span className="text-[#64748b] font-medium">Category:</span>
                <select
                  value={curriculumCategoryFilter}
                  onChange={(e) => setCurriculumCategoryFilter(e.target.value)}
                  className="py-1 px-2.5 border border-[#cbd5e1] rounded-lg text-xs bg-white text-[#1e293b]"
                >
                  <option value="all">All Categories</option>
                  <option value="PC">PC (Program Core)</option>
                  <option value="PE">PE (Program Elective)</option>
                  <option value="UC">UC (University Core)</option>
                  <option value="OE">OE (Open Elective)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Curriculum Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b] bg-[#f8fafc]">
              <span className="font-semibold text-[#1e293b]">
                Curriculum Courses ({filteredCurriculum.length} records)
              </span>
              <span className="text-[11px]">
                Showing {filteredCurriculum.length} of {curriculumList.length} total entries
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#f8fafc] text-[#475569] border-b border-[#e2e8f0] uppercase text-[11px] font-bold">
                  <tr>
                    <th className="py-3 px-4">Batch</th>
                    <th className="py-3 px-4">Degree Program</th>
                    <th className="py-3 px-4">Course Code</th>
                    <th className="py-3 px-4">Course Name</th>
                    <th className="py-3 px-4">Credits</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Curriculum Basket</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {isCurriculumLoading ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-xs text-[#94a3b8]">
                        Loading curriculum definitions...
                      </td>
                    </tr>
                  ) : filteredCurriculum.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-12 text-center text-xs text-[#94a3b8] space-y-2">
                        <FileSpreadsheet className="w-8 h-8 mx-auto text-[#cbd5e1]" />
                        <div className="font-semibold text-[#1e293b]">No Curriculum Entries Found</div>
                        <p className="max-w-md mx-auto text-[#64748b]">
                          Import curriculum via CSV or click "Add Curriculum Course" to register courses for this Program and Batch.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredCurriculum.map((curr) => (
                      <tr key={curr.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4 font-semibold text-[#1e293b]">
                          {curr.batch}
                        </td>
                        <td className="py-3 px-4 text-[#475569] max-w-[200px] truncate" title={curr.program}>
                          {curr.program}
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                          {curr.courseCode}
                        </td>
                        <td className="py-3 px-4 font-medium text-[#1e293b]">
                          {curr.courseName}
                        </td>
                        <td className="py-3 px-4 font-bold text-[#1e293b]">
                          {curr.credits} cr
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-block px-2 py-0.5 rounded bg-[#f1f5f9] text-[#1e293b] font-medium text-[11px]">
                            {curr.type}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge
                            variant={
                              curr.category === 'PC'
                                ? 'blue'
                                : curr.category === 'PE'
                                ? 'slate'
                                : curr.category === 'UC'
                                ? 'emerald'
                                : 'amber'
                            }
                            size="sm"
                          >
                            {curr.category}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-[#475569]">
                          {curr.basket}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => handleDeleteCurriculum(curr.id, curr.courseCode)}
                            className="p-1.5 rounded hover:bg-rose-50 text-[#94a3b8] hover:text-rose-600 transition-colors"
                            title="Delete Curriculum Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* VIEW 2: MASTER COURSE CATALOG (Existing Subjects View)                     */}
      {/* ========================================================================= */}
      {activeSubTab === 'catalog' && (
        <div className="space-y-6 animate-in fade-in duration-150">
          {/* Header Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
            <div>
              <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
                <Layers className="w-5 h-5 text-[#1e3a8a]" />
                <span>Master Institutional Course Catalog</span>
              </h2>
              <p className="text-xs text-[#64748b] mt-0.5">
                All canonical courses approved by the Academic Office, available for curriculum mapping and faculty assignment.
              </p>
            </div>

            <Button
              variant="primary"
              size="sm"
              onClick={handleOpenAdd}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Course
            </Button>
          </div>

          {/* Filter and Search Bar */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="w-full md:w-80">
              <Input
                placeholder="Search by course name or code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                startIcon={<Search className="w-4 h-4 text-[#94a3b8]" />}
                className="h-9 text-xs"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              {/* Program Filter */}
              <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
                <Filter className="w-3.5 h-3.5" />
                <span>Program:</span>
                <select
                  value={selectedClassFilter}
                  onChange={(e) => setSelectedClassFilter(e.target.value)}
                  className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
                >
                  <option value="all">All Programs ({activeClasses.length})</option>
                  {activeClasses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
                <span>Status:</span>
                <select
                  value={selectedStatusFilter}
                  onChange={(e) => setSelectedStatusFilter(e.target.value)}
                  className="h-8 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white text-[#1e293b] outline-hidden"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>

          {/* Courses Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
              <span className="font-semibold text-[#1e293b]">
                Course Catalog ({filteredSubjects.length} of {subjects.length} courses)
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Course Code & ID</th>
                    <th className="py-3 px-4 font-semibold">Course Name</th>
                    <th className="py-3 px-4 font-semibold">Offering Program</th>
                    <th className="py-3 px-4 font-semibold">Type</th>
                    <th className="py-3 px-4 font-semibold">Credits</th>
                    <th className="py-3 px-4 font-semibold">Status</th>
                    <th className="py-3 px-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {filteredSubjects.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-xs text-[#94a3b8]">
                        No courses found matching your filters.
                      </td>
                    </tr>
                  ) : (
                    filteredSubjects.map((sub) => (
                      <tr key={sub.id} className="hover:bg-[#f8fafc] transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-mono font-bold text-[#1e3a8a]">{sub.code}</div>
                          <div className="text-[10px] text-[#94a3b8]">{sub.id}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-[#1e293b]">{sub.name}</div>
                          {sub.description && (
                            <div className="text-[11px] text-[#64748b] truncate max-w-xs">
                              {sub.description}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="blue">{sub.className}</Badge>
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-block px-2 py-0.5 rounded bg-[#f1f5f9] text-[#1e293b] font-medium text-[11px]">
                            {sub.type || 'Core'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-[#1e293b] font-semibold">
                          {sub.creditsOrPeriodsPerWeek || 3} Credits
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={sub.status === 'active' ? 'emerald' : 'slate'}>
                            {sub.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(sub)}
                              className="p-1.5 rounded hover:bg-[#f1f5f9] text-[#64748b] hover:text-[#1e3a8a]"
                              title="Edit Course"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onToggleSubjectStatus(sub.id)}
                              className="p-1.5 rounded hover:bg-[#f1f5f9] text-[#64748b] hover:text-amber-600"
                              title={sub.status === 'active' ? 'Deactivate Course' : 'Activate Course'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: CSV Import */}
      <CurriculumImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportComplete={async () => {
          await loadCurriculum();
        }}
      />

      {/* Modal: Add Curriculum Course Manually */}
      {isAddCurriculumModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Add Course to Program Curriculum</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddCurriculumModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCurriculum} className="p-4 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Degree Program *
                  </label>
                  <select
                    value={formProg}
                    onChange={(e) => setFormProg(e.target.value)}
                    className="w-full h-9 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white"
                  >
                    {distinctPrograms.map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Admission Batch *
                  </label>
                  <select
                    value={formBatch}
                    onChange={(e) => setFormBatch(e.target.value)}
                    className="w-full h-9 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white"
                  >
                    {distinctBatches.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Course Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CSE1001"
                    value={formCode}
                    onChange={(e) => {
                      const code = e.target.value.toUpperCase();
                      setFormCode(code);
                      // Auto-fill title if found in subjects catalog
                      const existing = subjects.find((s) => s.code.toUpperCase() === code);
                      if (existing && !formName) {
                        setFormName(existing.name);
                        setFormCredits(existing.credits || 3);
                      }
                    }}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] text-xs uppercase"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Course Title *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Problem Solving & Programming"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Course Type *</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value)}
                    className="w-full h-9 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white"
                  >
                    <option value="Core">Core</option>
                    <option value="Elective">Elective</option>
                    <option value="Lab">Lab</option>
                    <option value="Open Elective">Open Elective</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Credits *</label>
                  <input
                    type="number"
                    min={1}
                    max={12}
                    required
                    value={formCredits}
                    onChange={(e) => setFormCredits(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] text-xs"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Category *</label>
                  <select
                    value={formCategory}
                    onChange={(e) => {
                      const cat = e.target.value;
                      setFormCategory(cat);
                      if (cat === 'PC') setFormBasket('Program Core');
                      else if (cat === 'PE') setFormBasket('Program Elective');
                      else if (cat === 'UC') setFormBasket('University Core');
                      else if (cat === 'OE') setFormBasket('Open Elective');
                    }}
                    className="w-full h-9 px-2.5 rounded-lg border border-[#cbd5e1] text-xs bg-white"
                  >
                    <option value="PC">PC (Program Core)</option>
                    <option value="PE">PE (Program Elective)</option>
                    <option value="UC">UC (University Core)</option>
                    <option value="OE">OE (Open Elective)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">Curriculum Basket *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Program Core, Program Elective, Open Elective"
                  value={formBasket}
                  onChange={(e) => setFormBasket(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] text-xs"
                />
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsAddCurriculumModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmittingCurriculum}
                >
                  Add to Curriculum
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Master Catalog Subject Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">
                  {editingSubject ? 'Edit Catalog Course' : 'Add Catalog Course'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-[#94a3b8] hover:text-[#1e293b]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Course Full Name *
                </label>
                <Input
                  required
                  placeholder="e.g. Data Structures and Algorithms"
                  value={subjectNameInput}
                  onChange={(e) => {
                    setSubjectNameInput(e.target.value);
                    if (!editingSubject && !subjectCodeInput) {
                      const words = e.target.value.trim().split(' ');
                      const code = words.length > 1 ? words.map((w) => w[0]).join('') : words[0]?.slice(0, 4);
                      setSubjectCodeInput(code.toUpperCase());
                    }
                  }}
                  className="h-9 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Course Code *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CSE1001"
                    value={subjectCodeInput}
                    onChange={(e) => setSubjectCodeInput(e.target.value.toUpperCase())}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs uppercase"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">
                    Offering Program *
                  </label>
                  <select
                    value={subjectClassIdInput}
                    onChange={(e) => setSubjectClassIdInput(e.target.value)}
                    className="w-full h-9 px-2 rounded-lg border border-[#cbd5e1] text-xs bg-white outline-hidden"
                  >
                    {activeClasses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Type *</label>
                  <select
                    value={subjectTypeInput}
                    onChange={(e) => setSubjectTypeInput(e.target.value as SubjectType)}
                    className="w-full h-9 px-2 rounded-lg border border-[#cbd5e1] text-xs bg-white outline-hidden"
                  >
                    <option value="Core">Core</option>
                    <option value="Elective">Elective</option>
                    <option value="Lab">Lab</option>
                    <option value="Optional">Optional</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#1e293b] mb-1">Credits *</label>
                  <input
                    type="number"
                    min={1}
                    max={12}
                    required
                    value={subjectCreditsInput}
                    onChange={(e) => setSubjectCreditsInput(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Course Description & Prerequisites
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Covers foundational algorithms, complexity analysis, and laboratory programming."
                  value={subjectDescInput}
                  onChange={(e) => setSubjectDescInput(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">Status</label>
                <select
                  value={subjectStatusInput}
                  onChange={(e) => setSubjectStatusInput(e.target.value as SubjectStatus)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                >
                  <option value="active">Active (Offered This Session)</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                >
                  {editingSubject ? 'Save Course' : 'Add Course'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
