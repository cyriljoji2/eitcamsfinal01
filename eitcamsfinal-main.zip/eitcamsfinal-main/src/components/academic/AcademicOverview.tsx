import React from 'react';
import {
  Users,
  Layers,
  Grid,
  BookOpen,
  UserCheck,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  Plus,
  CalendarCheck,
  Activity,
  Award,
} from 'lucide-react';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  FacultyAssignment,
  AttendanceRecord,
  AcademicActivityLog,
  AcademicSession,
} from '../../types/academic';
import { Student } from '../../types/admission';
import { Employee } from '../../types/employee';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface AcademicOverviewProps {
  currentSession: AcademicSession | null;
  students: Student[];
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyEmployees: Employee[];
  assignments?: FacultyAssignment[];
  facultyAssignments?: FacultyAssignment[];
  attendanceRecords?: AttendanceRecord[];
  activities?: AcademicActivityLog[];
  onNavigateTab: (tab: any) => void;
  onOpenAddClass?: () => void;
  onOpenAddSubject?: () => void;
  onOpenAddAssignment?: () => void;
  onOpenRecordAttendance?: () => void;
}

export function AcademicOverview({
  currentSession,
  students,
  classes,
  sections,
  subjects,
  facultyEmployees,
  assignments,
  facultyAssignments,
  attendanceRecords = [],
  activities = [],
  onNavigateTab,
  onOpenAddClass,
  onOpenAddSubject,
  onOpenAddAssignment,
  onOpenRecordAttendance,
}: AcademicOverviewProps) {
  const effectiveAssignments = assignments || facultyAssignments || [];
  // Compute Key Metrics
  const activeStudentsCount = students.filter((s) => s.accountStatus === 'active').length;
  const activeClassesCount = classes.filter((c) => c.status === 'active').length;
  const activeSectionsCount = sections.filter((s) => s.status === 'active').length;
  const activeSubjectsCount = subjects.filter((s) => s.status === 'active').length;
  const activeFacultyCount = facultyEmployees.filter((f) => f.status === 'active').length;

  // Attendance metrics
  const totalAttendance = attendanceRecords.length;
  const presentCount = attendanceRecords.filter((a) => a.status === 'Present').length;
  const lateCount = attendanceRecords.filter((a) => a.status === 'Late').length;
  const overallAttendanceRate =
    totalAttendance > 0 ? Math.round(((presentCount + lateCount) / totalAttendance) * 100) : 98;

  // Group students by Program/Class
  const studentsByClass = classes.map((cls) => {
    const classStudents = students.filter(
      (s) =>
        (s.program && (s.program.toLowerCase() === cls.name.toLowerCase() || s.program.toLowerCase() === cls.id.toLowerCase())) ||
        (s.admissionClass && (s.admissionClass.toLowerCase() === cls.name.toLowerCase() || s.admissionClass.toLowerCase() === cls.id.toLowerCase()))
    );
    const classSections = sections.filter((sec) => sec.classId === cls.id);
    const classSubjects = subjects.filter((sub) => sub.classId === cls.id);
    return {
      class: cls,
      studentCount: classStudents.length,
      sectionsCount: classSections.length,
      subjectsCount: classSubjects.length,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner with Academic Session Context */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl sm:text-2xl font-bold text-[#1e293b]">
              Academic Affairs & Operations
            </h1>
            <Badge variant="blue">{currentSession?.name || '2026–2027'}</Badge>
          </div>
          <p className="text-xs sm:text-sm text-[#64748b]">
            Institutional curriculum oversight, academic program structures, faculty teaching assignments, and attendance monitoring.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenRecordAttendance}
            leftIcon={<CalendarCheck className="w-4 h-4 text-emerald-600" />}
          >
            Log Attendance
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenAddClass}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Add Program
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenAddSubject}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            New Course
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenAddAssignment}
            leftIcon={<UserCheck className="w-4 h-4" />}
          >
            Assign Faculty
          </Button>
        </div>
      </div>

      {/* 6 Core KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Total Enrolled Students */}
        <div
          onClick={() => onNavigateTab('students')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Students</span>
            <Users className="w-4 h-4 text-[#1e3a8a]" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-[#1e293b]">{students.length}</div>
            <div className="text-[11px] text-emerald-700 font-medium flex items-center gap-1 mt-0.5">
              <span>{activeStudentsCount} Active Enrolled</span>
            </div>
          </div>
        </div>

        {/* Total Programs */}
        <div
          onClick={() => onNavigateTab('classes')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Programs</span>
            <Layers className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-[#1e293b]">{classes.length}</div>
            <div className="text-[11px] text-[#64748b] font-medium mt-0.5">
              <span>{activeClassesCount} Active Programs</span>
            </div>
          </div>
        </div>

        {/* Total Batches */}
        <div
          onClick={() => onNavigateTab('classes')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Batches</span>
            <Grid className="w-4 h-4 text-cyan-600" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-[#1e293b]">{sections.length}</div>
            <div className="text-[11px] text-[#64748b] font-medium mt-0.5">
              <span>{activeSectionsCount} Active Batches</span>
            </div>
          </div>
        </div>

        {/* Total Courses */}
        <div
          onClick={() => onNavigateTab('subjects')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Courses</span>
            <BookOpen className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-[#1e293b]">{subjects.length}</div>
            <div className="text-[11px] text-[#64748b] font-medium mt-0.5">
              <span>{activeSubjectsCount} Course Codes</span>
            </div>
          </div>
        </div>

        {/* Total Faculty */}
        <div
          onClick={() => onNavigateTab('faculty')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Faculty</span>
            <UserCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-[#1e293b]">{facultyEmployees.length}</div>
            <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
              <span>{effectiveAssignments.length} Active Duties</span>
            </div>
          </div>
        </div>

        {/* Attendance Summary */}
        <div
          onClick={() => onNavigateTab('attendance')}
          className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#cbd5e1] cursor-pointer transition-all flex flex-col justify-between"
        >
          <div className="flex items-center justify-between text-[#64748b]">
            <span className="text-xs font-semibold uppercase tracking-wider">Attendance</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-emerald-700">{overallAttendanceRate}%</div>
            <div className="text-[11px] text-[#64748b] font-medium mt-0.5">
              <span>{totalAttendance} Records Logged</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid: Class Distribution & Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Academic Class Hierarchy Summary */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-[#1e293b]">Program & Enrollment Distribution</h2>
                <p className="text-xs text-[#64748b]">
                  Overview of degree programs, active batches, and student headcount
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onNavigateTab('classes')}
                className="text-xs text-[#1e3a8a]"
                rightIcon={<ArrowUpRight className="w-3.5 h-3.5" />}
              >
                Manage Programs
              </Button>
            </div>

            <div className="divide-y divide-[#f1f5f9]">
              {studentsByClass.map((item) => (
                <div
                  key={item.class.id}
                  className="p-3.5 sm:p-4 flex items-center justify-between hover:bg-[#f8fafc] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#eff6ff] text-[#1e3a8a] font-bold text-xs flex items-center justify-center">
                      {item.class.name.slice(0, 3)}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                        <span>{item.class.name}</span>
                        {item.class.stream && item.class.stream !== 'General' && (
                          <span className="text-[11px] font-normal text-[#64748b] bg-[#f1f5f9] px-1.5 py-0.5 rounded">
                            {item.class.stream}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-[#64748b] flex items-center gap-3 mt-0.5">
                        <span>{item.sectionsCount} Batches configured</span>
                        <span>&bull;</span>
                        <span>{item.subjectsCount} Courses</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-black text-[#1e293b]">
                      {item.studentCount} <span className="text-xs font-normal text-[#64748b]">Students</span>
                    </div>
                    <Badge variant={item.class.status === 'active' ? 'emerald' : 'slate'} className="mt-1">
                      {item.class.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Shortcuts to Academic Modules */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div
              onClick={() => onNavigateTab('subjects')}
              className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#1e3a8a] cursor-pointer transition-all"
            >
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center mb-2">
                <BookOpen className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold text-[#1e293b]">Courses & Curriculum</h3>
              <p className="text-[11px] text-[#64748b] mt-1">
                Configure course codes, academic credits, and map courses to degree programs.
              </p>
            </div>

            <div
              onClick={() => onNavigateTab('faculty')}
              className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#1e3a8a] cursor-pointer transition-all"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2">
                <UserCheck className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold text-[#1e293b]">Faculty Teaching Roster</h3>
              <p className="text-[11px] text-[#64748b] mt-1">
                Map verified faculty to specific programs, batches, and courses.
              </p>
            </div>

            <div
              onClick={() => onNavigateTab('reports')}
              className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs hover:border-[#1e3a8a] cursor-pointer transition-all"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center mb-2">
                <Award className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold text-[#1e293b]">Academic Reports & CSV</h3>
              <p className="text-[11px] text-[#64748b] mt-1">
                Generate printable rosters, attendance summaries, and curriculum audit sheets.
              </p>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Recent Academic Activity Feed */}
        <div className="space-y-4">
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs p-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Recent Academic Activity</h3>
              </div>
              <span className="text-[11px] text-[#64748b]">{activities.length} Events</span>
            </div>

            <div className="mt-4 space-y-3.5">
              {activities.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#94a3b8]">
                  No recent academic events recorded.
                </div>
              ) : (
                activities.slice(0, 6).map((act) => (
                  <div key={act.id} className="text-xs border-l-2 border-[#1e3a8a] pl-3 py-0.5 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#1e293b]">{act.action || act.title}</span>
                      <span className="text-[10px] text-[#94a3b8]">
                        {new Date(act.timestamp).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#64748b] leading-relaxed">{act.details || act.description}</p>
                    <div className="text-[10px] text-[#94a3b8] flex items-center gap-1">
                      <span>By: {act.performedBy || act.actor}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Academic Session Notice */}
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold text-[#1e293b]">
              <Clock className="w-4 h-4 text-[#1e3a8a]" />
              <span>Active Term Schedule</span>
            </div>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              Active academic operations are bound to <strong>{currentSession?.name || '2026–2027'}</strong>. All faculty assignments and attendance records reference this active session ID.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
