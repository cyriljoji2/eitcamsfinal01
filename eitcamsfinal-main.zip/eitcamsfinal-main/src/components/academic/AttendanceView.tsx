import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  UserX,
  Filter,
  Save,
  Search,
  Users,
  Layers,
  Grid,
  Calendar,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AttendanceRecord,
  AttendanceStatus,
  FacultyAssignment,
} from '../../types/academic';
import { Student } from '../../types/admission';
import { UserSession } from '../../types/auth';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface AttendanceViewProps {
  user: UserSession;
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  students: Student[];
  assignments: FacultyAssignment[];
  attendanceRecords: AttendanceRecord[];
  onSaveAttendance: (records: Omit<AttendanceRecord, 'id' | 'recordedAt'>[]) => Promise<AttendanceRecord[]>;
  isFacultyOnly?: boolean;
}

export function AttendanceView({
  user,
  currentSession,
  classes,
  sections,
  students,
  assignments,
  attendanceRecords,
  onSaveAttendance,
  isFacultyOnly = false,
}: AttendanceViewProps) {
  // If faculty, find their assigned classes and sections
  const facultyAssignments = isFacultyOnly
    ? assignments.filter(
        (a) =>
          (a.employeeId && a.employeeId.toLowerCase() === user.id.toLowerCase()) ||
          (user.id.includes('FAC') && a.employeeId && a.employeeId.includes('FAC'))
      )
    : assignments;

  // Filter available classes
  const availableClasses = isFacultyOnly
    ? classes.filter((c) => facultyAssignments.some((a) => a.classId === c.id))
    : classes;

  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedClassId, setSelectedClassId] = useState<string>(availableClasses[0]?.id || classes[0]?.id || '');
  const [selectedSectionName, setSelectedSectionName] = useState<string>('A');
  const [activeTab, setActiveTab] = useState<'mark' | 'history'>('mark');

  // Attendance state for currently loaded roster: map from regNo -> { status, remarks }
  const [rosterAttendance, setRosterAttendance] = useState<
    Record<string, { status: AttendanceStatus; remarks: string }>
  >({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Selected class object
  const currentClassObj = classes.find((c) => c.id === selectedClassId) || classes[0];

  // Available sections for current class
  const classSections = sections.filter((s) => s.classId === selectedClassId);

  // If faculty mode, further filter sections to only those assigned
  const availableSectionOptions = isFacultyOnly
    ? classSections.filter((sec) =>
        facultyAssignments.some(
          (a) => a.classId === selectedClassId && (a.sectionName || a.section || '').toLowerCase() === sec.name.toLowerCase()
        )
      )
    : classSections;

  // Students matching the selected program and batch
  const enrolledStudents = students.filter((s) => {
    const sProgram = (s.program || s.admissionClass || '').toLowerCase();
    const cName = (currentClassObj?.name || '').toLowerCase();
    const cId = (currentClassObj?.id || '').toLowerCase();
    const progMatch = sProgram === cName || sProgram === cId;

    const sBatch = (s.batch || s.section || '').toLowerCase();
    const selSec = selectedSectionName.toLowerCase();
    const batchMatch =
      sBatch === selSec ||
      sBatch.includes(selSec) ||
      selSec.includes(sBatch) ||
      (selSec.startsWith('group ') && sBatch.endsWith(selSec.replace('group ', '').trim()));

    return progMatch && batchMatch;
  });

  // Load existing attendance for this class/section/date if already saved
  useEffect(() => {
    if (!currentClassObj) return;

    const existingForDate = attendanceRecords.filter(
      (a) =>
        a.date === selectedDate &&
        (((a.className || '').toLowerCase() === currentClassObj.name.toLowerCase()) ||
          ((a.classId || '').toLowerCase() === currentClassObj.id.toLowerCase())) &&
        (a.sectionName || '').toLowerCase() === selectedSectionName.toLowerCase()
    );

    const initialMap: Record<string, { status: AttendanceStatus; remarks: string }> = {};

    enrolledStudents.forEach((st) => {
      const existing = existingForDate.find(
        (rec) => (rec.registrationNumber || rec.registration_number || '').toLowerCase() === st.registrationNumber.toLowerCase()
      );
      if (existing) {
        initialMap[st.registrationNumber] = {
          status: existing.status as AttendanceStatus,
          remarks: existing.remarks || '',
        };
      } else {
        // Default to Present
        initialMap[st.registrationNumber] = {
          status: 'Present',
          remarks: '',
        };
      }
    });

    setRosterAttendance(initialMap);
    setSaveSuccessMsg('');
  }, [selectedDate, selectedClassId, selectedSectionName, students, attendanceRecords]);

  // Quick batch actions
  const handleMarkAll = (status: AttendanceStatus) => {
    const updated: Record<string, { status: AttendanceStatus; remarks: string }> = {};
    enrolledStudents.forEach((st) => {
      updated[st.registrationNumber] = {
        status,
        remarks: rosterAttendance[st.registrationNumber]?.remarks || '',
      };
    });
    setRosterAttendance(updated);
  };

  // Change individual student attendance status
  const handleStatusChange = (regNo: string, status: AttendanceStatus) => {
    setRosterAttendance((prev) => ({
      ...prev,
      [regNo]: {
        status,
        remarks: prev[regNo]?.remarks || '',
      },
    }));
  };

  // Change individual student remarks
  const handleRemarksChange = (regNo: string, remarks: string) => {
    setRosterAttendance((prev) => ({
      ...prev,
      [regNo]: {
        status: prev[regNo]?.status || 'Present',
        remarks,
      },
    }));
  };

  // Save Attendance to Repository
  const handleSave = async () => {
    if (enrolledStudents.length === 0) return;

    setIsSaving(true);
    setSaveSuccessMsg('');

    try {
      const payload: Omit<AttendanceRecord, 'id' | 'recordedAt'>[] = enrolledStudents.map((st) => {
        const item = rosterAttendance[st.registrationNumber] || { status: 'Present', remarks: '' };
        return {
          date: selectedDate,
          academicSession: currentSession?.id || '2026-27',
          registrationNumber: st.registrationNumber,
          studentName: st.fullName,
          classId: currentClassObj.id,
          className: currentClassObj.name,
          sectionId: `SEC-${currentClassObj.id.replace('CLS-', '')}-${selectedSectionName}`,
          sectionName: selectedSectionName,
          status: item.status,
          recordedBy: `${user.name} (${user.id})`,
          recordedById: user.id,
          remarks: item.remarks.trim() || undefined,
        };
      });

      await onSaveAttendance(payload);
      setSaveSuccessMsg(`Attendance saved successfully for ${payload.length} students.`);
    } catch (err: any) {
      alert(err.message || 'Failed to save attendance');
    } finally {
      setIsSaving(false);
    }
  };

  // Metrics for current marked sheet
  const rosterValues = Object.values(rosterAttendance) as { status: AttendanceStatus; remarks: string }[];
  const currentPresent = rosterValues.filter((v) => v.status === 'Present').length;
  const currentAbsent = rosterValues.filter((v) => v.status === 'Absent').length;
  const currentLate = rosterValues.filter((v) => v.status === 'Late').length;
  const currentLeave = rosterValues.filter((v) => v.status === 'Leave').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-[#e2e8f0] p-4 sm:p-5 rounded-xl shadow-xs">
        <div>
          <h2 className="text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-[#1e3a8a]" />
            <span>Attendance Management Desk</span>
          </h2>
          <p className="text-xs text-[#64748b] mt-0.5">
            {isFacultyOnly
              ? 'Record daily classroom attendance for your assigned teaching sections.'
              : 'Institutional roll-call registry, daily attendance recording, and compliance tracking.'}
          </p>
        </div>

        {/* View Switcher */}
        <div className="flex items-center gap-1 bg-[#f1f5f9] p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('mark')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'mark'
                ? 'bg-white text-[#1e3a8a] shadow-xs'
                : 'text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Mark Attendance
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'history'
                ? 'bg-white text-[#1e3a8a] shadow-xs'
                : 'text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            View History
          </button>
        </div>
      </div>

      {activeTab === 'mark' ? (
        <div className="space-y-4">
          {/* Controls & Class/Section Filter Bar */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              {/* Date Selector */}
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Attendance Date *
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white"
                />
              </div>

              {/* Program Selector */}
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Degree Program *
                </label>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    const matchingSecs = sections.filter((s) => s.classId === e.target.value);
                    if (matchingSecs.length > 0) {
                      setSelectedSectionName(matchingSecs[0].name);
                    }
                  }}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white font-medium text-[#1e293b]"
                >
                  {availableClasses.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.stream || c.department || 'General'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Batch / Section Selector */}
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Batch / Cohort *
                </label>
                <select
                  value={selectedSectionName}
                  onChange={(e) => setSelectedSectionName(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden text-xs bg-white font-medium text-[#1e293b]"
                >
                  {availableSectionOptions.length > 0 ? (
                    availableSectionOptions.map((sec) => (
                      <option key={sec.id} value={sec.name}>
                        {sec.name} {sec.roomNumber ? `(${sec.roomNumber})` : ''}
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="Batch 2026 - Group A">Batch 2026 - Group A</option>
                      <option value="Batch 2026 - Group B">Batch 2026 - Group B</option>
                      <option value="A">Section A</option>
                      <option value="B">Section B</option>
                    </>
                  )}
                </select>
              </div>

              {/* Academic Session Indicator */}
              <div>
                <label className="block font-semibold text-[#1e293b] mb-1">
                  Academic Term
                </label>
                <div className="h-9 px-3 rounded-lg bg-[#f8fafc] border border-[#e2e8f0] flex items-center text-xs font-semibold text-[#1e293b]">
                  {currentSession?.name || '2026-27 (Active)'}
                </div>
              </div>
            </div>

            {/* Quick Bulk Marking Actions & Stat Badges */}
            <div className="pt-3 border-t border-[#e2e8f0] flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#64748b] font-medium">Quick Mark All:</span>
                <button
                  type="button"
                  onClick={() => handleMarkAll('Present')}
                  className="px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold hover:bg-emerald-100"
                >
                  All Present
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('Absent')}
                  className="px-2.5 py-1 rounded bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold hover:bg-rose-100"
                >
                  All Absent
                </button>
              </div>

              {/* Counts */}
              <div className="flex items-center gap-2 text-xs">
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded font-bold">
                  {currentPresent} Present
                </span>
                <span className="bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded font-bold">
                  {currentLate} Late
                </span>
                <span className="bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded font-bold">
                  {currentLeave} Leave
                </span>
                <span className="bg-rose-50 text-rose-800 border border-rose-200 px-2 py-0.5 rounded font-bold">
                  {currentAbsent} Absent
                </span>
              </div>
            </div>
          </div>

          {/* Success Message Banner */}
          {saveSuccessMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{saveSuccessMsg}</span>
              </div>
              <button
                type="button"
                onClick={() => setSaveSuccessMsg('')}
                className="text-emerald-700 hover:text-emerald-900 font-bold"
              >
                &times;
              </button>
            </div>
          )}

          {/* Student Roster Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
              <div>
                <strong className="text-[#1e293b]">
                  {currentClassObj?.name} &bull; {selectedSectionName.startsWith('Batch') ? selectedSectionName : `Batch ${selectedSectionName}`}
                </strong>{' '}
                &bull; Date: <strong>{selectedDate}</strong> ({enrolledStudents.length} Students)
              </div>
              <div className="text-[11px]">
                Recorder: <strong className="text-[#1e293b]">{user.name} ({user.id})</strong>
              </div>
            </div>

            {enrolledStudents.length === 0 ? (
              <div className="p-12 text-center text-xs text-[#94a3b8] space-y-2">
                <Users className="w-8 h-8 mx-auto text-[#cbd5e1]" />
                <div className="font-bold text-[#1e293b]">No students enrolled in this batch</div>
                <p>
                  No students currently assigned to {currentClassObj?.name} ({selectedSectionName}).
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold w-12 text-center">#</th>
                      <th className="py-2.5 px-4 font-semibold">Registration Number</th>
                      <th className="py-2.5 px-4 font-semibold">Student Full Name</th>
                      <th className="py-2.5 px-4 font-semibold">Attendance Status</th>
                      <th className="py-2.5 px-4 font-semibold">Remarks / Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#f1f5f9]">
                    {enrolledStudents.map((st, idx) => {
                      const currentVal = rosterAttendance[st.registrationNumber] || {
                        status: 'Present',
                        remarks: '',
                      };

                      return (
                        <tr key={st.id} className="hover:bg-[#f8fafc] transition-colors">
                          <td className="py-3 px-4 text-center text-[#64748b] font-mono">
                            {idx + 1}
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                            {st.registrationNumber}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-[#1e293b]">{st.fullName}</div>
                            <div className="text-[10px] text-[#64748b]">{st.email}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-1">
                              {(['Present', 'Late', 'Leave', 'Absent'] as AttendanceStatus[]).map((status) => {
                                const isSelected = currentVal.status === status;
                                let colorStyle = 'border-[#cbd5e1] text-[#64748b] hover:bg-[#f1f5f9]';
                                if (isSelected) {
                                  if (status === 'Present')
                                    colorStyle = 'bg-emerald-600 text-white border-emerald-600 font-bold';
                                  if (status === 'Late')
                                    colorStyle = 'bg-amber-600 text-white border-amber-600 font-bold';
                                  if (status === 'Leave')
                                    colorStyle = 'bg-blue-600 text-white border-blue-600 font-bold';
                                  if (status === 'Absent')
                                    colorStyle = 'bg-rose-600 text-white border-rose-600 font-bold';
                                }

                                return (
                                  <button
                                    key={status}
                                    type="button"
                                    onClick={() => handleStatusChange(st.registrationNumber, status)}
                                    className={`px-2.5 py-1 rounded text-xs border transition-all ${colorStyle}`}
                                  >
                                    {status}
                                  </button>
                                );
                              })}
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <input
                              type="text"
                              placeholder="e.g. Medical slip, Bus delay..."
                              value={currentVal.remarks}
                              onChange={(e) => handleRemarksChange(st.registrationNumber, e.target.value)}
                              className="w-full h-8 px-2.5 rounded border border-[#cbd5e1] focus:ring-1 focus:ring-[#1e3a8a] outline-hidden text-xs"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Bottom Save Bar */}
            {enrolledStudents.length > 0 && (
              <div className="p-4 border-t border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
                <div className="text-xs text-[#64748b]">
                  Saving will stamp recorder metadata: <strong>{user.name} ({user.id})</strong>
                </div>
                <Button
                  variant="primary"
                  size="md"
                  onClick={handleSave}
                  isLoading={isSaving}
                  leftIcon={<Save className="w-4 h-4" />}
                >
                  Save Attendance Sheet
                </Button>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* History Tab */
        <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#e2e8f0]">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Attendance History Logs</h3>
              <p className="text-xs text-[#64748b]">
                Audit past roll-call entries, recorder credentials, and status logs.
              </p>
            </div>
            <Badge variant="blue">{attendanceRecords.length} Stored Entries</Badge>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Date</th>
                  <th className="py-2.5 px-3 font-semibold">Student</th>
                  <th className="py-2.5 px-3 font-semibold">Class & Sec</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold">Recorded By</th>
                  <th className="py-2.5 px-3 font-semibold">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {attendanceRecords.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#94a3b8]">
                      No historical attendance records found.
                    </td>
                  </tr>
                ) : (
                  attendanceRecords.slice(0, 50).map((rec) => (
                    <tr key={rec.id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3 font-mono font-medium text-[#1e293b]">{rec.date}</td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-[#1e293b]">{rec.studentName}</div>
                        <div className="text-[10px] text-[#64748b] font-mono">{rec.registrationNumber}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        {rec.className} - {rec.sectionName}
                      </td>
                      <td className="py-2.5 px-3">
                        <Badge
                          variant={
                            rec.status === 'Present'
                              ? 'emerald'
                              : rec.status === 'Late'
                              ? 'amber'
                              : rec.status === 'Leave'
                              ? 'blue'
                              : 'slate'
                          }
                        >
                          {rec.status}
                        </Badge>
                      </td>
                      <td className="py-2.5 px-3 text-[#64748b]">{rec.recordedBy}</td>
                      <td className="py-2.5 px-3 text-[#64748b] italic">{rec.remarks || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
