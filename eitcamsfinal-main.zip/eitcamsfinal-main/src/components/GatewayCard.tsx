import { PortalGatewayConfig, PortalType } from '../types/portal';
import { PortalCard } from './landing/PortalCard';
import { GraduationCap, Briefcase, Users } from 'lucide-react';

export interface GatewayCardProps {
  gateway: PortalGatewayConfig;
  onSelect: (portal: PortalType) => void;
}

export function GatewayCard({ gateway, onSelect }: GatewayCardProps) {
  const icon =
    gateway.id === PortalType.Student
      ? GraduationCap
      : gateway.id === PortalType.Employee
      ? Briefcase
      : Users;

  const badgeColor =
    gateway.id === PortalType.Student
      ? 'blue'
      : gateway.id === PortalType.Employee
      ? 'purple'
      : 'emerald';

  return (
    <PortalCard
      id={`${gateway.id}-portal-card`}
      portal={gateway.id}
      title={gateway.title}
      tagline={gateway.title}
      description={gateway.description}
      icon={icon}
      badgeText={gateway.title}
      badgeColor={badgeColor}
      onSelect={onSelect}
    />
  );
}
