import { useState, ChangeEvent, DragEvent } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Copy,
  Download,
  FileSpreadsheet,
  FileText,
  Info,
  RefreshCw,
  Sparkles,
  Upload,
  UploadCloud,
  Users,
  XCircle,
} from 'lucide-react';
import { EmployeeCategory, EmployeeRecord, EmploymentStatus } from '../types/database';
import { IEitDataAdapter } from '../services/dataAdapter';
import { allocateNextEmployeeRegistrationNumber } from '../services/regNumberGenerator';

interface ParsedEmployeeRow {
  rowNumber: number;
  first_name: string;
  last_name: string;
  category: EmployeeCategory | '';
  primary_department: string;
  designation: string;
  phone_number: string;
  institutional_email: string;
  date_of_joining: string;
  status: 'VALID' | 'DUPLICATE' | 'ERROR';
  errorMessage?: string;
}

interface AdministrationBulkImportSectionProps {
  existingEmployees: EmployeeRecord[];
  dataAdapter: IEitDataAdapter;
  onEmployeesImported: (newEmployees: EmployeeRecord[]) => void;
  actor?: { userId: string; role: string; employeeId?: string };
}

const CSV_TEMPLATE_HEADER = 'first_name,last_name,category,primary_department,designation,phone_number,institutional_email,date_of_joining';

const SAMPLE_CSV_DATA = `${CSV_TEMPLATE_HEADER}
David,Miller,TEACHING,CSE,Assistant Professor,+1 (555) 789-0123,david.miller@eit.edu,2026-08-01
Elena,Rostova,TEACHING,ECE,Associate Professor,+1 (555) 890-1234,elena.rostova@eit.edu,2026-08-01
Marcus,Thorne,NON_TEACHING,ADM,Campus Facilities Officer,+1 (555) 901-2345,marcus.thorne@eit.edu,2026-08-15
Kavita,Patel,NON_TEACHING,FIN,Payroll Specialist,+1 (555) 012-3456,kavita.patel@eit.edu,2026-09-01`;

export function AdministrationBulkImportSection({
  existingEmployees,
  dataAdapter,
  onEmployeesImported,
  actor,
}: AdministrationBulkImportSectionProps) {
  const [csvContent, setCsvContent] = useState('');
  const [parsedRows, setParsedRows] = useState<ParsedEmployeeRow[]>([]);
  const [isParsing, setIsParsing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importSummary, setImportSummary] = useState<{
    successCount: number;
    skippedCount: number;
    createdEmployees: EmployeeRecord[];
    provisionedCount: number;
  } | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  // Parse CSV text into validated rows
  const parseAndValidateCsv = (rawText: string) => {
    setIsParsing(true);
    setImportSummary(null);
    setImportError(null);

    try {
      const lines = rawText
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length > 0);

      if (lines.length <= 1) {
        setParsedRows([]);
        setIsParsing(false);
        return;
      }

      // Check header row
      const headers = lines[0].split(',').map((h) => h.trim().toLowerCase().replace(/['"]+/g, ''));
      const expected = [
        'first_name',
        'last_name',
        'category',
        'primary_department',
        'designation',
        'phone_number',
        'institutional_email',
        'date_of_joining',
      ];

      const missingHeaders = expected.filter((exp) => !headers.includes(exp));
      if (missingHeaders.length > 0) {
        setImportError(`CSV missing mandatory column(s): ${missingHeaders.join(', ')}`);
        setParsedRows([]);
        setIsParsing(false);
        return;
      }

      // Track emails within CSV for internal duplicate detection
      const seenEmailsInFile = new Set<string>();
      const existingEmails = new Set(existingEmployees.map((e) => e.institutional_email.toLowerCase()));
      const existingPhones = new Set(existingEmployees.map((e) => e.phone_number.replace(/\D/g, '')));

      const rows: ParsedEmployeeRow[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i];
        // Handle comma separation with potential quotes
        const values: string[] = [];
        let cur = '';
        let insideQuotes = false;
        for (let ch = 0; ch < line.length; ch++) {
          const char = line[ch];
          if (char === '"') {
            insideQuotes = !insideQuotes;
          } else if (char === ',' && !insideQuotes) {
            values.push(cur.trim().replace(/^"|"$/g, ''));
            cur = '';
          } else {
            cur += char;
          }
        }
        values.push(cur.trim().replace(/^"|"$/g, ''));

        // Build row object from headers
        const rowMap: Record<string, string> = {};
        headers.forEach((h, idx) => {
          rowMap[h] = values[idx] || '';
        });

        const firstName = rowMap['first_name'] || '';
        const lastName = rowMap['last_name'] || '';
        const rawCategory = (rowMap['category'] || '').toUpperCase();
        const dept = (rowMap['primary_department'] || '').toUpperCase();
        const designation = rowMap['designation'] || '';
        const phone = rowMap['phone_number'] || '';
        const email = (rowMap['institutional_email'] || '').toLowerCase();
        const doj = rowMap['date_of_joining'] || new Date().toISOString().split('T')[0];

        // Validation
        let status: 'VALID' | 'DUPLICATE' | 'ERROR' = 'VALID';
        let errorMessage: string | undefined;

        if (!firstName || firstName.length < 2) {
          status = 'ERROR';
          errorMessage = 'First name must be at least 2 characters';
        } else if (!lastName) {
          status = 'ERROR';
          errorMessage = 'Last name is required';
        } else if (rawCategory !== 'TEACHING' && rawCategory !== 'NON_TEACHING') {
          status = 'ERROR';
          errorMessage = "Category must be strictly 'TEACHING' or 'NON_TEACHING'";
        } else if (!dept) {
          status = 'ERROR';
          errorMessage = 'Primary department code is required';
        } else if (!designation) {
          status = 'ERROR';
          errorMessage = 'Designation/Job Title is required';
        } else if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          status = 'ERROR';
          errorMessage = 'Invalid institutional email format';
        } else if (existingEmails.has(email)) {
          status = 'DUPLICATE';
          errorMessage = `Email '${email}' is already registered to an existing employee`;
        } else if (seenEmailsInFile.has(email)) {
          status = 'DUPLICATE';
          errorMessage = `Duplicate email '${email}' repeated in this CSV batch`;
        } else if (phone && existingPhones.has(phone.replace(/\D/g, ''))) {
          status = 'DUPLICATE';
          errorMessage = `Phone number '${phone}' already registered to another staff member`;
        }

        if (status === 'VALID') {
          seenEmailsInFile.add(email);
        }

        rows.push({
          rowNumber: i + 1,
          first_name: firstName,
          last_name: lastName,
          category: rawCategory as EmployeeCategory,
          primary_department: dept,
          designation,
          phone_number: phone,
          institutional_email: email,
          date_of_joining: doj,
          status,
          errorMessage,
        });
      }

      setParsedRows(rows);
    } catch (err: any) {
      setImportError(`Failed to parse CSV: ${err.message}`);
      setParsedRows([]);
    } finally {
      setIsParsing(false);
    }
  };

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setCsvContent(text);
      parseAndValidateCsv(text);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV_DATA], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'eit_employee_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLoadSample = () => {
    setCsvContent(SAMPLE_CSV_DATA);
    parseAndValidateCsv(SAMPLE_CSV_DATA);
  };

  // Execute Import
  const handleExecuteImport = async () => {
    const validRows = parsedRows.filter((r) => r.status === 'VALID');
    if (validRows.length === 0) return;

    setIsImporting(true);
    setImportError(null);

    const created: EmployeeRecord[] = [];
    let provisionedCount = 0;
    let skipped = 0;

    try {
      for (const row of validRows) {
        try {
          const currentExistingRegs = [
            ...existingEmployees.map((e) => e.registration_number),
            ...created.map((c) => c.registration_number),
          ];
          const joiningYear = parseInt(row.date_of_joining.split('-')[0], 10) || 2026;
          const regNumber = allocateNextEmployeeRegistrationNumber(
            currentExistingRegs,
            row.category as EmployeeCategory,
            row.primary_department,
            joiningYear
          );

          const emp = await dataAdapter.employees.create({
            registration_number: regNumber,
            category: row.category as EmployeeCategory,
            first_name: row.first_name,
            last_name: row.last_name,
            institutional_email: row.institutional_email,
            phone_number: row.phone_number,
            primary_department: row.primary_department,
            designation: row.designation,
            employment_status: EmploymentStatus.ACTIVE,
            date_of_joining: row.date_of_joining,
          });

          created.push(emp);

          // Provision login credential
          try {
            const prov = await dataAdapter.employees.provisionAccount(emp.employee_id);
            if (prov.success) {
              provisionedCount++;
            }
          } catch {
            // Non-blocking if provision already existed
          }
        } catch {
          skipped++;
        }
      }

      setImportSummary({
        successCount: created.length,
        skippedCount: skipped + parsedRows.filter((r) => r.status !== 'VALID').length,
        createdEmployees: created,
        provisionedCount,
      });

      onEmployeesImported(created);
    } catch (err: any) {
      setImportError(`Import halted due to error: ${err.message}`);
    } finally {
      setIsImporting(false);
    }
  };

  const validCount = parsedRows.filter((r) => r.status === 'VALID').length;
  const duplicateCount = parsedRows.filter((r) => r.status === 'DUPLICATE').length;
  const errorCount = parsedRows.filter((r) => r.status === 'ERROR').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Bulk Employee CSV Import
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Import multiple faculty members or non-teaching staff into EIT with automatic ID allocation and account provisioning.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={handleDownloadTemplate}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Download CSV Template</span>
          </button>
          <button
            type="button"
            onClick={handleLoadSample}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-50 hover:bg-blue-100 text-[#1E3A8A] border border-blue-200 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Load Demo Batch</span>
          </button>
        </div>
      </div>

      {/* Completion Summary */}
      {importSummary && (
        <div className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-sm">
                Successfully Imported {importSummary.successCount} Employee(s)
              </div>
              <p className="text-xs text-emerald-700 mt-0.5">
                {importSummary.provisionedCount} login accounts provisioned with default credentials. Registration numbers allocated monotonically.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setCsvContent('');
              setParsedRows([]);
              setImportSummary(null);
            }}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl transition-colors shrink-0 cursor-pointer"
          >
            Start Another Batch
          </button>
        </div>
      )}

      {importError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-sm flex items-center gap-2.5">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{importError}</span>
        </div>
      )}

      {/* Dropzone & Text Input Box */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dropzone */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={`col-span-1 lg:col-span-1 border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center transition-colors ${
            dragOver ? 'border-[#1E3A8A] bg-blue-50/50' : 'border-slate-300 bg-white hover:border-slate-400'
          }`}
        >
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#1E3A8A] flex items-center justify-center mb-3">
            <UploadCloud className="w-6 h-6 stroke-[1.8]" />
          </div>
          <h3 className="font-bold text-sm text-slate-800">Drag &amp; Drop CSV File</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            Supports .csv, .txt formatted with standard comma delimiters.
          </p>

          <label className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl cursor-pointer transition-colors">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Browse Computer</span>
            <input
              type="file"
              accept=".csv,.txt"
              className="hidden"
              onChange={(e: ChangeEvent<HTMLInputElement>) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileUpload(e.target.files[0]);
                }
              }}
            />
          </label>
        </div>

        {/* Raw Text Input */}
        <div className="col-span-1 lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#1E3A8A]" />
                <span>Or Paste Raw CSV Data</span>
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                {CSV_TEMPLATE_HEADER.split(',').length} columns expected
              </span>
            </div>
            <textarea
              rows={5}
              value={csvContent}
              onChange={(e) => {
                setCsvContent(e.target.value);
                parseAndValidateCsv(e.target.value);
              }}
              placeholder={`${CSV_TEMPLATE_HEADER}\nJohn,Doe,TEACHING,CSE,Assistant Professor,+1 (555) 000-1111,john.doe@eit.edu,2026-08-01`}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#1E3A8A] bg-slate-50/50"
            />
          </div>

          <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
            <span className="text-xs text-slate-500">
              Header mapping automatically verified against institutional schema.
            </span>
            <button
              type="button"
              onClick={() => parseAndValidateCsv(csvContent)}
              disabled={!csvContent.trim() || isParsing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isParsing ? 'animate-spin' : ''}`} />
              <span>Revalidate</span>
            </button>
          </div>
        </div>
      </div>

      {/* Validation & Preview Section */}
      {parsedRows.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          {/* Summary Stat Bar */}
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-sm font-bold text-slate-900">
                Batch Preview ({parsedRows.length} Rows)
              </span>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                {validCount} Valid
              </span>
              {duplicateCount > 0 && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                  {duplicateCount} Duplicate
                </span>
              )}
              {errorCount > 0 && (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                  {errorCount} Error
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleExecuteImport}
              disabled={validCount === 0 || isImporting}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1E3A8A] hover:bg-[#162D6E] disabled:bg-slate-300 text-white font-semibold text-sm rounded-xl shadow-sm transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              {isImporting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Importing Roster...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Confirm Import ({validCount} Valid)</span>
                </>
              )}
            </button>
          </div>

          {/* Table */}
          <div className="overflow-x-auto max-h-[380px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-4 py-3">Row</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Employee Name</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Dept</th>
                  <th className="px-4 py-3">Designation</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Phone</th>
                  <th className="px-4 py-3">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {parsedRows.map((row) => (
                  <tr
                    key={row.rowNumber}
                    className={`transition-colors ${
                      row.status === 'ERROR'
                        ? 'bg-rose-50/40 hover:bg-rose-50/70'
                        : row.status === 'DUPLICATE'
                        ? 'bg-amber-50/40 hover:bg-amber-50/70'
                        : 'hover:bg-slate-50/60'
                    }`}
                  >
                    <td className="px-4 py-3 font-mono font-medium text-slate-500">
                      #{row.rowNumber}
                    </td>
                    <td className="px-4 py-3">
                      {row.status === 'VALID' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Ready</span>
                        </span>
                      )}
                      {row.status === 'DUPLICATE' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          <AlertCircle className="w-3 h-3" />
                          <span>Duplicate</span>
                        </span>
                      )}
                      {row.status === 'ERROR' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-50 text-rose-800 border border-rose-200">
                          <XCircle className="w-3 h-3" />
                          <span>Invalid</span>
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900">
                      {row.first_name} {row.last_name}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          row.category === EmployeeCategory.TEACHING
                            ? 'bg-blue-50 text-[#1E3A8A]'
                            : 'bg-purple-50 text-purple-800'
                        }`}
                      >
                        {row.category}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-slate-700">
                      {row.primary_department}
                    </td>
                    <td className="px-4 py-3 text-slate-700">{row.designation}</td>
                    <td className="px-4 py-3 font-mono text-slate-600">{row.institutional_email}</td>
                    <td className="px-4 py-3 font-mono text-slate-500">{row.phone_number}</td>
                    <td className="px-4 py-3 text-[11px]">
                      {row.errorMessage ? (
                        <span className="text-rose-700 font-medium">{row.errorMessage}</span>
                      ) : (
                        <span className="text-emerald-700 font-medium">Valid for import</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
