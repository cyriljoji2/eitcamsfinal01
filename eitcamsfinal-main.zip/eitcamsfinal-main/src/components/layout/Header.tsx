import { GraduationCap, LogOut, ArrowLeft, User, Calendar } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { DigitalClock } from './DigitalClock';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

export interface HeaderProps {
  onNavigateHome?: () => void;
  isHome?: boolean;
}

export function Header({ onNavigateHome, isHome }: HeaderProps = {}) {
  const {
    user,
    session,
    viewState,
    navigateToLanding,
    logout,
    isLoading,
    activeOfficeKey,
    switchActiveOffice,
  } = useAuth();

  const handleNavigateLanding = () => {
    if (onNavigateHome) {
      onNavigateHome();
    } else {
      navigateToLanding();
    }
  };

  const isLoginView =
    viewState.type === 'login' ||
    (!isHome && typeof window !== 'undefined' && window.location.hash.includes('login'));

  const isDashboardView =
    viewState.type === 'dashboard' ||
    (!isHome && typeof window !== 'undefined' && window.location.hash.includes('dashboard'));

  const { activeAcademicYear } = useActiveAcademicYear();

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="flex items-center justify-between h-16">
          {/* Logo & School Name */}
          <button
            id="school-portal-brand-btn"
            type="button"
            onClick={handleNavigateLanding}
            className="flex items-center gap-3 text-left group focus:outline-none rounded-md p-1 transition-opacity hover:opacity-90 cursor-pointer"
            aria-label="Electrix Institute of Technology (EIT) Home"
          >
            {/* Clean Minimalism Logo Box */}
            <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-[16px] sm:text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                  Electrix Institute of Technology (EIT)
                </span>
                <span className="hidden sm:inline-block text-[11px] font-medium text-[#64748b] bg-[#f8fafc] px-2 py-0.5 rounded border border-[#e2e8f0]">
                  ERP
                </span>
              </div>
              <span className="text-[11px] text-[#64748b] font-medium hidden md:inline">
                College Academic &amp; Administrative Management Gateway
              </span>
            </div>
          </button>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            <span id="header-active-academic-year" className="hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-[#eff6ff] text-[#1e3a8a] border border-[#dbeafe]">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              <span>AY {activeAcademicYear || '2026–2027'}</span>
            </span>
            {isLoginView && (
              <Button
                id="header-back-home-btn"
                variant="ghost"
                size="sm"
                onClick={handleNavigateLanding}
                leftIcon={<ArrowLeft className="w-4 h-4" />}
              >
                Back to Selection
              </Button>
            )}

            {isDashboardView && user && (
              <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-[#e2e8f0]">
                  <div className="w-7 h-7 rounded-full bg-[#f1f5f9] border border-[#e2e8f0] flex items-center justify-center text-[#1e293b]">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-left leading-none">
                    <p className="text-[13px] font-semibold text-[#1e293b]">{user.name}</p>
                    <p className="text-[11px] text-[#64748b] mt-0.5">{user.roleTitle}</p>
                  </div>
                </div>

                <Badge variant="blue" size="sm" className="hidden md:inline-flex capitalize">
                  {user.portalType}
                </Badge>

                {session && session.availableOffices && session.availableOffices.length > 1 && (
                  <div className="flex items-center gap-1.5 text-xs">
                    <label htmlFor="header-office-switcher" className="sr-only">
                      Select Active Office
                    </label>
                    <select
                      id="header-office-switcher"
                      value={activeOfficeKey || ''}
                      onChange={(e) => switchActiveOffice(e.target.value)}
                      className="px-2.5 py-1 rounded-md text-xs font-medium text-[#1e3a8a] bg-[#eff6ff] border border-[#dbeafe] focus:outline-none"
                    >
                      {session.availableOffices.map((off) => (
                        <option key={off.office_id} value={off.office_key}>
                          {off.office_name}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <Button
                  id="header-logout-btn"
                  variant="danger"
                  size="sm"
                  onClick={logout}
                  isLoading={isLoading}
                  leftIcon={<LogOut className="w-3.5 h-3.5" />}
                >
                  Logout
                </Button>
              </div>
            )}

            {/* Live Digital Clock with Date */}
            <DigitalClock />
          </div>
        </div>
      </div>
    </header>
  );
}
