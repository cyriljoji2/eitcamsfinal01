import { useState, useEffect } from 'react';
import { HelpCircle, Mail, Phone, AlertTriangle } from 'lucide-react';
import { itRepository } from '../../services/itService';
import { ItContactSettings } from '../../types/itDepartment';

export function Footer() {
  const [settings, setSettings] = useState<ItContactSettings>(() =>
    itRepository.getContactSettings()
  );

  useEffect(() => {
    const unsubscribe = itRepository.subscribeContactSettings((updated) => {
      setSettings(updated);
    });
    return unsubscribe;
  }, []);

  return (
    <footer className="mt-auto bg-white border-t border-[#e2e8f0] py-6 text-[#64748b]">
      {/* Reactive Broadcast Banner if active */}
      {settings.broadcast_banner_enabled && settings.broadcast_message && (
        <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10 mb-4">
          <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-lg p-2.5 px-3.5 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-medium">{settings.broadcast_message}</span>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-8 lg:px-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-[#64748b]">
            <span className="font-semibold text-[#1e293b]">Electrix Institute of Technology (EIT)</span>
            <span>&bull;</span>
            <span>College Academic &amp; Information Gateway</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-[#64748b]">
            <div className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#64748b]" />
              <span>{settings.primary_support_email || 'portal-support@electrix.edu'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#64748b]" />
              <span>{settings.primary_phone || '+1 (555) 019-2830'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#64748b]" />
              <span>{settings.footer_support_text || `IT Support (${settings.helpdesk_hours})`}</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-[#f1f5f9] flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-[#94a3b8]">
          <p>© {new Date().getFullYear()} Electrix Institute of Technology (EIT). All rights reserved.</p>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="text-[#64748b] font-medium">Phase 1 Foundation &bull; Clean Minimalism</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
