import React, { useMemo, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { ItWorkspace } from './it/ItWorkspace';
import { UserSession } from '../types';

interface ItOfficeSectionProps {
  onRefreshData?: () => Promise<void> | void;
  embedded?: boolean;
}

export function ItOfficeSection({ onRefreshData }: ItOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'IT Administrator';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-007',
      username: session?.user?.username || 'itoffice',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'itoffice@eit.edu.in',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'IT Administrator',
      department: emp?.primary_department || 'IT',
      portalType: 'employee',
      employeeId: emp?.registration_number || 'EMP-IT-001',
      permanentOffice: session?.permanentOffice || {
        office_id: 'PO-007',
        office_name: 'IT Department',
        canonical_username: 'itoffice',
        office_code: 'IT',
        is_system_reserved: true,
        primary_contact_email: 'itoffice@eit.edu.in',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    };
  }, [session]);

  const handleLogout = useCallback(async () => {
    await logout();
  }, [logout]);

  const handleRefresh = useCallback(async () => {
    if (onRefreshData) {
      await onRefreshData();
    }
  }, [onRefreshData]);

  return (
    <ItWorkspace
      user={userSession}
      onLogout={handleLogout}
      onRefreshData={handleRefresh}
    />
  );
}

export default ItOfficeSection;
