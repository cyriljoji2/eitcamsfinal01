import { PortalGatewayConfig, PortalType } from '../types/portal';
import { LoginPage } from './auth/LoginPage';

export interface LoginFormProps {
  portal: PortalGatewayConfig;
  onBackToHome?: () => void;
  onLoginSuccess?: (portalType: PortalType) => void;
}

export function LoginForm({ portal, onBackToHome, onLoginSuccess }: LoginFormProps) {
  return (
    <LoginPage
      portal={portal.id}
      onBackToHome={onBackToHome}
      onLoginSuccess={onLoginSuccess}
    />
  );
}
