import { Briefcase, GraduationCap, Users } from 'lucide-react';
import { PortalType } from '../types/portal';

interface PortalIconProps {
  portal: PortalType;
  className?: string;
}

export function PortalIcon({ portal, className = 'w-7 h-7 stroke-[1.8]' }: PortalIconProps) {
  switch (portal) {
    case PortalType.Student:
      return <GraduationCap className={className} aria-hidden="true" />;
    case PortalType.Employee:
      return <Briefcase className={className} aria-hidden="true" />;
    case PortalType.Parent:
      return <Users className={className} aria-hidden="true" />;
  }
}
