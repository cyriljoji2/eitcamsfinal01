import React, { useState, useEffect } from 'react';
import { Layers, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { FeeCategory, FeeStructureItem } from '../../types/finance';
import { Button } from '../ui/Button';

interface FeeStructureModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: FeeStructureItem | null;
  onSubmit: (data: Omit<FeeStructureItem, 'id'>) => Promise<any>;
}

const CATEGORIES: { label: string; value: FeeCategory }[] = [
  { label: 'Tuition Fee', value: FeeCategory.TUITION },
  { label: 'Examination Fee', value: FeeCategory.EXAMINATION },
  { label: 'Laboratory Fee', value: FeeCategory.LABORATORY },
  { label: 'Library & E-Resources', value: FeeCategory.LIBRARY },
  { label: 'Hostel & Residential', value: FeeCategory.HOSTEL },
  { label: 'Campus Transport', value: FeeCategory.TRANSPORT },
  { label: 'Miscellaneous / Welfare', value: FeeCategory.MISCELLANEOUS },
];

const PROGRAMMES = [
  { code: 'ALL', name: 'All Academic Programmes' },
  { code: 'BTECH-CSE', name: 'B.Tech Computer Science & Engineering' },
  { code: 'BTECH-ECE', name: 'B.Tech Electronics & Communication Engineering' },
  { code: 'BTECH-MECH', name: 'B.Tech Mechanical Engineering' },
  { code: 'BTECH-EEE', name: 'B.Tech Electrical & Electronics Engineering' },
  { code: 'BTECH-CIVIL', name: 'B.Tech Civil Engineering' },
];

export function FeeStructureModal({ isOpen, onClose, item, onSubmit }: FeeStructureModalProps) {
  const [name, setName] = useState('');
  const [feeCategory, setFeeCategory] = useState<FeeCategory>(FeeCategory.TUITION);
  const [amount, setAmount] = useState('');
  const [academicSession, setAcademicSession] = useState('2026-2027');
  const [semester, setSemester] = useState<number>(3);
  const [programmeCode, setProgrammeCode] = useState<string>('BTECH-CSE');
  const [dueDate, setDueDate] = useState('2026-11-30');
  const [frequency, setFrequency] = useState<FeeStructureItem['frequency']>('Per Semester');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setError(null);
      setIsSubmitting(false);
      if (item) {
        setName(item.name);
        setFeeCategory(item.feeCategory as FeeCategory);
        setAmount(String(item.amount));
        setAcademicSession(item.academicSession || '2026-2027');
        setSemester(item.semester || 1);
        setProgrammeCode(item.programmeCode || 'ALL');
        setDueDate(item.dueDate || '2026-11-30');
        setFrequency(item.frequency || 'Per Semester');
        setDescription(item.description || item.applicability || '');
        setStatus((item.status?.toLowerCase() === 'inactive' ? 'inactive' : 'active') as any);
      } else {
        setName('');
        setFeeCategory(FeeCategory.TUITION);
        setAmount('3500');
        setAcademicSession('2026-2027');
        setSemester(3);
        setProgrammeCode('BTECH-CSE');
        setDueDate('2026-11-30');
        setFrequency('Per Semester');
        setDescription('');
        setStatus('active');
      }
    }
  }, [isOpen, item]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please enter a valid amount greater than 0.');
      return;
    }

    if (!name.trim()) {
      setError('Fee head title is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        name: name.trim(),
        feeCategory,
        amount: parsedAmount,
        currency: 'USD',
        academicSession,
        semester: Number(semester),
        programmeCode,
        applicableClassNames: [programmeCode === 'ALL' ? 'All Programmes' : programmeCode],
        dueDate,
        frequency,
        description: description.trim() || undefined,
        status,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save fee structure.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        <div className="p-5 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">
                {item ? 'Edit University Fee Structure' : 'Create New Fee Head'}
              </h3>
              <p className="text-xs text-[#64748b]">Configure official academic rate cards and dues schedule.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Fee Head Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. B.Tech Standard Tuition Fee - Fall 2026"
              className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Category <span className="text-red-500">*</span>
              </label>
              <select
                value={feeCategory}
                onChange={(e) => setFeeCategory(e.target.value as FeeCategory)}
                className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat.value} value={cat.value}>
                    {cat.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Amount (USD) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="3500.00"
                  className="w-full pl-8 pr-3.5 py-2 text-sm font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Academic Session
              </label>
              <select
                value={academicSession}
                onChange={(e) => setAcademicSession(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                <option value="2026-2027">2026–2027</option>
                <option value="2025-2026">2025–2026</option>
                <option value="2027-2028">2027–2028</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Semester
              </label>
              <select
                value={semester}
                onChange={(e) => setSemester(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                <option value={0}>All Semesters (0)</option>
                <option value={1}>Semester 1</option>
                <option value={2}>Semester 2</option>
                <option value={3}>Semester 3</option>
                <option value={4}>Semester 4</option>
                <option value={5}>Semester 5</option>
                <option value={6}>Semester 6</option>
                <option value={7}>Semester 7</option>
                <option value={8}>Semester 8</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Programme
              </label>
              <select
                value={programmeCode}
                onChange={(e) => setProgrammeCode(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {PROGRAMMES.map((p) => (
                  <option key={p.code} value={p.code}>
                    {p.code} ({p.name})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Frequency
              </label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                <option value="Per Semester">Per Semester</option>
                <option value="Annual">Annual</option>
                <option value="One-Time">One-Time (Admission/Convocation)</option>
                <option value="Monthly">Monthly</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Due Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                <option value="active">Active (Billable)</option>
                <option value="inactive">Inactive / Draft</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Applicability Notes / Regulations
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Applicable to 2026 Batch undergraduate engineering cohort."
              className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              disabled={isSubmitting}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
              className="bg-[#1e3a8a] hover:bg-[#172554] cursor-pointer"
            >
              {isSubmitting ? 'Saving...' : item ? 'Update Rate Card' : 'Save Rate Card'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
