import React, { useState } from 'react';
import {
  Search,
  Filter,
  DollarSign,
  CreditCard,
  Download,
  Eye,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  Layers,
  GraduationCap,
} from 'lucide-react';
import { StudentFeeSummary } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentFeeAccountsViewProps {
  summaries: StudentFeeSummary[];
  onOpenPaymentModal: (studentRegNo: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function StudentFeeAccountsView({
  summaries,
  onOpenPaymentModal,
  onViewStudentProfile,
}: StudentFeeAccountsViewProps) {
  const [search, setSearch] = useState('');
  const [programmeFilter, setProgrammeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'outstanding' | 'cleared'>('all');

  const uniqueProgrammes = Array.from(new Set(summaries.map((s) => s.className))).sort();

  const filteredSummaries = summaries.filter((s) => {
    const matchesSearch =
      s.studentName.toLowerCase().includes(search.toLowerCase()) ||
      s.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      s.className.toLowerCase().includes(search.toLowerCase());

    const matchesProg = programmeFilter === 'all' || s.className === programmeFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'outstanding'
        ? s.totalOutstanding > 0
        : s.totalOutstanding === 0;

    return matchesSearch && matchesProg && matchesStatus;
  });

  const totalBilled = summaries.reduce((acc, s) => acc + s.totalDue, 0);
  const totalCollected = summaries.reduce((acc, s) => acc + s.totalPaid, 0);
  const totalOutstanding = summaries.reduce((acc, s) => acc + s.totalOutstanding, 0);
  const totalWaived = summaries.reduce((acc, s) => acc + s.totalWaived, 0);

  const handleExportCsv = () => {
    const headers = [
      'Registration Number',
      'Student Name',
      'Degree Programme',
      'Department',
      'Semester',
      'Section',
      'Academic Session',
      'Total Fees Assigned ($)',
      'Total Paid ($)',
      'Total Waived ($)',
      'Net Outstanding ($)',
      'Status',
    ];

    const rows = filteredSummaries.map((s) => [
      s.studentRegistrationNumber,
      s.studentName,
      s.className,
      s.department,
      s.semester,
      s.section,
      s.academicSession,
      s.totalDue.toFixed(2),
      s.totalPaid.toFixed(2),
      s.totalWaived.toFixed(2),
      s.totalOutstanding.toFixed(2),
      s.totalOutstanding === 0 ? 'CLEARED' : s.totalPaid > 0 ? 'PARTIAL' : 'UNPAID',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Student_Fee_Ledger_Registry_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Student Fee Accounts & Ledgers</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional fee statements, historical vouchers, and dues reconciliation for all students.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Ledger CSV
          </Button>
        </div>
      </div>

      {/* 4 Summary Stat Mini-Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#64748b] block mb-1">
            Total Invoiced
          </span>
          <span className="text-xl font-mono font-black text-[#1e293b]">${totalBilled.toFixed(2)}</span>
          <span className="text-[10px] text-[#64748b] block mt-1">{summaries.length} enrolled student(s)</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
            Total Realized
          </span>
          <span className="text-xl font-mono font-black text-emerald-800">${totalCollected.toFixed(2)}</span>
          <span className="text-[10px] text-emerald-700 font-semibold block mt-1">
            {totalBilled > 0 ? ((totalCollected / totalBilled) * 100).toFixed(1) : 0}% Realization
          </span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block mb-1">
            Concessions & Aid
          </span>
          <span className="text-xl font-mono font-black text-blue-800">${totalWaived.toFixed(2)}</span>
          <span className="text-[10px] text-blue-700 block mt-1">Applied waivers</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
            Net Receivables
          </span>
          <span className="text-xl font-mono font-black text-amber-900">${totalOutstanding.toFixed(2)}</span>
          <span className="text-[10px] text-amber-800 font-medium block mt-1">
            {summaries.filter((s) => s.totalOutstanding > 0).length} student(s) with dues
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student name or registration number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <Filter className="w-3.5 h-3.5" />
            <span>Programme:</span>
          </div>
          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Programmes</option>
            {uniqueProgrammes.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Accounts</option>
            <option value="outstanding">Outstanding Dues Only</option>
            <option value="cleared">Fully Cleared Only</option>
          </select>
        </div>
      </div>

      {/* Student Ledger Accounts Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Registration #</th>
                <th className="py-3 px-4">Student Candidate</th>
                <th className="py-3 px-4">Degree Programme</th>
                <th className="py-3 px-4 text-right">Invoiced ($)</th>
                <th className="py-3 px-4 text-right">Paid ($)</th>
                <th className="py-3 px-4 text-right">Waivers ($)</th>
                <th className="py-3 px-4 text-right">Net Dues ($)</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredSummaries.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#64748b]">
                    No student accounts found matching current query.
                  </td>
                </tr>
              ) : (
                filteredSummaries.map((summary) => (
                  <tr key={summary.studentRegistrationNumber} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                      {summary.studentRegistrationNumber}
                    </td>
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => onViewStudentProfile(summary.studentRegistrationNumber)}
                        className="font-bold text-[#1e293b] hover:text-[#1e3a8a] hover:underline cursor-pointer text-left block"
                      >
                        {summary.studentName}
                      </button>
                      <span className="text-[10px] text-[#64748b]">{summary.department} &bull; Section {summary.section}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-700 font-medium">{summary.className}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-800">
                      ${summary.totalDue.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800">
                      ${summary.totalPaid.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-blue-700">
                      {summary.totalWaived > 0 ? `-$${summary.totalWaived.toFixed(2)}` : '—'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                      ${summary.totalOutstanding.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Badge
                        variant={
                          summary.totalOutstanding === 0
                            ? 'emerald'
                            : summary.totalPaid > 0
                            ? 'amber'
                            : 'rose'
                        }
                        size="sm"
                      >
                        {summary.totalOutstanding === 0 ? 'CLEARED' : summary.totalPaid > 0 ? 'PARTIAL' : 'DUE'}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {summary.totalOutstanding > 0 && (
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => onOpenPaymentModal(summary.studentRegistrationNumber)}
                            className="text-[11px] bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
                          >
                            Pay
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onViewStudentProfile(summary.studentRegistrationNumber)}
                          leftIcon={<Eye className="w-3.5 h-3.5" />}
                          className="text-xs text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
                        >
                          Statement
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
