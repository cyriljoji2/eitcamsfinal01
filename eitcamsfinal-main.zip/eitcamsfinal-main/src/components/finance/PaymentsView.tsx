import React, { useState } from 'react';
import {
  CreditCard,
  Search,
  Filter,
  Plus,
  Receipt,
  Download,
  Calendar,
  ShieldAlert,
  CheckCircle2,
  AlertCircle,
  Hash,
  RotateCcw,
  Eye,
} from 'lucide-react';
import { PaymentRecordItem, FeeReceipt, PaymentMode } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface PaymentsViewProps {
  payments: PaymentRecordItem[];
  receipts: FeeReceipt[];
  onOpenPaymentEntry: () => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onOpenVoidModal: (payment: PaymentRecordItem) => void;
  onOpenRefundModal?: (payment: PaymentRecordItem) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function PaymentsView({
  payments,
  receipts,
  onOpenPaymentEntry,
  onOpenReceiptModal,
  onOpenVoidModal,
  onOpenRefundModal,
  onViewStudentProfile,
}: PaymentsViewProps) {
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'voided'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredPayments = payments.filter((p) => {
    const studentName = p.studentName || '';
    const matchesSearch =
      p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.receiptNumber.toLowerCase().includes(search.toLowerCase()) ||
      studentName.toLowerCase().includes(search.toLowerCase()) ||
      p.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.feeTypeName.toLowerCase().includes(search.toLowerCase()) ||
      (p.transactionReference && p.transactionReference.toLowerCase().includes(search.toLowerCase()));

    const matchesMode = modeFilter === 'all' || p.paymentMode.toLowerCase() === modeFilter.toLowerCase();
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'valid'
        ? !p.isVoided
        : p.isVoided;

    const matchesStart = !startDate || p.paymentDate >= startDate;
    const matchesEnd = !endDate || p.paymentDate <= endDate;

    return matchesSearch && matchesMode && matchesStatus && matchesStart && matchesEnd;
  });

  const validPayments = filteredPayments.filter((p) => !p.isVoided);
  const totalCollectedFiltered = validPayments.reduce((acc, p) => acc + p.amountPaid, 0);
  const voidedVolume = filteredPayments.filter((p) => p.isVoided).reduce((acc, p) => acc + p.amountPaid, 0);

  const handleExportCsv = () => {
    const headers = [
      'Payment ID',
      'Receipt Number',
      'Date',
      'Student Registration Number',
      'Student Name',
      'Fee Head',
      'Amount Paid ($)',
      'Payment Mode',
      'Transaction Reference',
      'Received By',
      'Status',
      'Audit Reason',
    ];

    const rows = filteredPayments.map((p) => [
      p.id,
      p.receiptNumber,
      p.paymentDate,
      p.studentRegistrationNumber,
      p.studentName || 'Student Candidate',
      p.feeTypeName,
      p.amountPaid.toFixed(2),
      p.paymentMode,
      p.transactionReference || 'N/A',
      p.receivedBy || 'Finance Officer',
      p.isVoided ? 'VOIDED / REFUNDED' : 'VALID RECORDED',
      p.voidReason || p.notes || '',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Payments_Ledger_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Payments Ledger & Collections Registry</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Complete transaction register of verified bank settlements, campus cash, and online gateway receipts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Ledger
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={onOpenPaymentEntry}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* 3 Metrics Mini Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#64748b] block mb-1">
            Transactions Filtered
          </span>
          <span className="text-xl font-mono font-black text-[#1e293b]">{filteredPayments.length}</span>
          <span className="text-[10px] text-[#64748b] block mt-1">Vouchers matched</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
            Verified Collection
          </span>
          <span className="text-xl font-mono font-black text-emerald-800">${totalCollectedFiltered.toFixed(2)}</span>
          <span className="text-[10px] text-emerald-700 font-semibold block mt-1">Realized into accounts</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 block mb-1">
            Reversals & Voids
          </span>
          <span className="text-xl font-mono font-black text-red-800">${voidedVolume.toFixed(2)}</span>
          <span className="text-[10px] text-red-700 block mt-1">
            {filteredPayments.filter((p) => p.isVoided).length} cancelled vouchers
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student, receipt, or transaction reference..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          <select
            value={modeFilter}
            onChange={(e) => setModeFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Modes</option>
            <option value="Cash">Cash</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Debit Card">Debit Card</option>
            <option value="Online Gateway">Online Gateway</option>
            <option value="UPI">UPI</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Statuses</option>
            <option value="valid">Valid / Verified</option>
            <option value="voided">Voided / Reversed</option>
          </select>

          <div className="flex items-center gap-1">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none"
              title="Start Date"
            />
            <span className="text-xs text-[#64748b]">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none"
              title="End Date"
            />
          </div>
        </div>
      </div>

      {/* Payments Ledger Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Receipt #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Student Candidate</th>
                <th className="py-3 px-4">Particulars</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Transaction Ref</th>
                <th className="py-3 px-4 text-right">Amount Paid</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#64748b]">
                    No payments found matching the selected filter criteria.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((p) => {
                  const matchingReceipt = receipts.find((r) => r.receiptNumber === p.receiptNumber);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">{p.receiptNumber}</td>
                      <td className="py-3.5 px-4 text-[#64748b] whitespace-nowrap">{p.paymentDate}</td>
                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(p.studentRegistrationNumber)}
                          className="font-bold text-[#1e293b] hover:text-[#1e3a8a] hover:underline cursor-pointer text-left block"
                        >
                          {p.studentName || p.studentRegistrationNumber}
                        </button>
                        <span className="font-mono text-[10px] text-[#64748b]">{p.studentRegistrationNumber}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">{p.feeTypeName}</td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-medium text-[11px]">
                          {p.paymentMode}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-slate-700 max-w-[140px] truncate" title={p.transactionReference}>
                        {p.transactionReference || 'N/A'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                        ${p.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <Badge variant={p.isVoided ? 'rose' : 'emerald'} size="sm">
                          {p.isVoided ? 'VOIDED' : 'VERIFIED'}
                        </Badge>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {matchingReceipt && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onOpenReceiptModal(matchingReceipt)}
                              leftIcon={<Eye className="w-3.5 h-3.5" />}
                              className="text-xs text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
                            >
                              Receipt
                            </Button>
                          )}

                          {!p.isVoided && onOpenRefundModal && (
                            <button
                              type="button"
                              onClick={() => onOpenRefundModal(p)}
                              className="p-1.5 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                              title="Authorize Refund"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {!p.isVoided && (
                            <button
                              type="button"
                              onClick={() => onOpenVoidModal(p)}
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                              title="Void / Reversal"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
