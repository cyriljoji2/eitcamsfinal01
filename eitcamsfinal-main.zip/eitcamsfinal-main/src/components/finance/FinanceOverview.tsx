import React from 'react';
import {
  DollarSign,
  TrendingUp,
  Receipt,
  AlertCircle,
  CreditCard,
  Plus,
  Users,
  Layers,
  ArrowRight,
  CheckCircle2,
  Clock,
  Calendar,
  Eye,
  ShieldCheck,
  Building2,
  Award,
} from 'lucide-react';
import { FinanceDashboardMetrics, PaymentRecordItem, FeeReceipt, FeeAssignment, FinanceTab } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface FinanceOverviewProps {
  metrics: FinanceDashboardMetrics;
  recentPayments: PaymentRecordItem[];
  receipts: FeeReceipt[];
  onOpenPaymentEntry: () => void;
  onOpenFeeStructureModal: () => void;
  onNavigateTab: (tab: FinanceTab) => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function FinanceOverview({
  metrics,
  recentPayments,
  receipts,
  onOpenPaymentEntry,
  onOpenFeeStructureModal,
  onNavigateTab,
  onOpenReceiptModal,
  onViewStudentProfile,
}: FinanceOverviewProps) {
  const collectionRate =
    metrics.totalFeesAssigned > 0
      ? (metrics.totalAmountCollected / metrics.totalFeesAssigned) * 100
      : 0;

  return (
    <div className="space-y-6">
      {/* Welcome Banner with Quick Actions */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h2 className="text-xl font-bold text-[#1e293b]">Finance Operations & Billing Center</h2>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Real-time university fee ledgers, cohort invoicing, digital payment receipts, and dues reconciliation.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={onOpenFeeStructureModal}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            New Fee Head
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('assignments')}
            leftIcon={<Users className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Assign Fees
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('hostel-fees')}
            leftIcon={<Building2 className="w-4 h-4" />}
            className="text-xs text-purple-700 border-purple-200 hover:bg-purple-50 cursor-pointer"
          >
            Hostel Dues
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={onOpenPaymentEntry}
            leftIcon={<CreditCard className="w-4 h-4" />}
            className="text-xs bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* 4 Primary Key Performance Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Fees Invoiced */}
        <div className="p-5 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#64748b]">
              Total Invoiced
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-black text-[#1e293b]">
            ${metrics.totalFeesAssigned.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-[#64748b] flex items-center gap-1.5 pt-1 border-t border-[#f1f5f9]">
            <Users className="w-3.5 h-3.5 text-blue-600" />
            <span>Across all enrolled cohorts</span>
          </div>
        </div>

        {/* Card 2: Total Amount Collected */}
        <div className="p-5 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Total Collected
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-black text-emerald-800">
            ${metrics.totalAmountCollected.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-emerald-700 font-semibold flex items-center justify-between pt-1 border-t border-[#f1f5f9]">
            <span>{collectionRate.toFixed(1)}% Collection Rate</span>
            <span className="text-[10px] text-slate-500 font-normal">Today: ${metrics.todayCollection.toFixed(2)}</span>
          </div>
        </div>

        {/* Card 3: Total Outstanding Balance */}
        <div className="p-5 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
              Outstanding Dues
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-black text-amber-900">
            ${metrics.totalOutstanding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-amber-800 font-medium flex items-center gap-1.5 pt-1 border-t border-[#f1f5f9]">
            <Clock className="w-3.5 h-3.5" />
            <span>{metrics.studentsWithOutstandingCount} student(s) with balance</span>
          </div>
        </div>

        {/* Card 4: Scholarships & Waivers */}
        <div className="p-5 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">
              Scholarships & Aid
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-black text-purple-900">
            ${metrics.totalWaived.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-purple-700 font-medium flex items-center gap-1.5 pt-1 border-t border-[#f1f5f9]">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Authorized concessions & merit grants</span>
          </div>
        </div>
      </div>

      {/* 2 Middle Breakdown Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown */}
        <div className="p-6 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#1e3a8a]" />
              <span>Revenue by Fee Head</span>
            </h3>
            <button
              type="button"
              onClick={() => onNavigateTab('structure')}
              className="text-xs text-[#1e3a8a] font-bold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Manage Heads</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {metrics.categoryCollectionBreakdown.length === 0 ? (
              <div className="text-center py-6 text-xs text-[#64748b]">No fee categories collections recorded yet.</div>
            ) : (
              metrics.categoryCollectionBreakdown.map((cat) => (
                <div key={cat.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-[#1e293b]">{cat.name}</span>
                    <span className="font-mono text-[#64748b]">
                      ${cat.total.toLocaleString()} ({cat.percentage.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-[#1e3a8a] h-full rounded-full transition-all"
                      style={{ width: `${Math.min(100, Math.max(5, cat.percentage))}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Payment Mode Distribution */}
        <div className="p-6 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-700" />
              <span>Collection by Payment Mode</span>
            </h3>
            <button
              type="button"
              onClick={() => onNavigateTab('payments')}
              className="text-xs text-[#1e3a8a] font-bold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View Ledger</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {metrics.paymentModeBreakdown.length === 0 ? (
              <div className="text-center py-6 text-xs text-[#64748b]">No mode transactions logged yet.</div>
            ) : (
              metrics.paymentModeBreakdown.map((mode) => (
                <div key={mode.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-[#1e293b]">{mode.name}</span>
                    <span className="font-mono text-[#64748b]">
                      ${mode.total.toLocaleString()} ({mode.percentage.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full transition-all"
                      style={{ width: `${Math.min(100, Math.max(5, mode.percentage))}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Payments Ledger Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#1e3a8a]" />
              <span>Recent Transaction Vouchers</span>
            </h3>
            <p className="text-xs text-[#64748b] mt-0.5">Audit-stamped payment collections posted to registry.</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('payments')}
            className="text-xs cursor-pointer"
          >
            All Payments
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Receipt #</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Particulars</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {recentPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#64748b]">
                    No recent payments recorded.
                  </td>
                </tr>
              ) : (
                recentPayments.slice(0, 5).map((p) => {
                  const matchingReceipt = receipts.find((r) => r.receiptNumber === p.receiptNumber);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">{p.receiptNumber}</td>
                      <td className="py-3 px-4 text-[#64748b]">{p.paymentDate}</td>
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(p.studentRegistrationNumber)}
                          className="font-bold text-[#1e293b] hover:text-[#1e3a8a] hover:underline cursor-pointer text-left block"
                        >
                          {p.studentName || p.studentRegistrationNumber}
                        </button>
                        <span className="font-mono text-[10px] text-[#64748b]">{p.studentRegistrationNumber}</span>
                      </td>
                      <td className="py-3 px-4 text-slate-700 font-medium">{p.feeTypeName}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-medium text-[11px]">
                          {p.paymentMode}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-sm text-[#1e293b]">
                        ${p.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant={p.isVoided ? 'rose' : 'emerald'} size="sm">
                          {p.isVoided ? 'VOIDED' : 'RECORDED'}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {matchingReceipt && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onOpenReceiptModal(matchingReceipt)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                            className="text-xs text-[#1e3a8a] cursor-pointer"
                          >
                            Receipt
                          </Button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
