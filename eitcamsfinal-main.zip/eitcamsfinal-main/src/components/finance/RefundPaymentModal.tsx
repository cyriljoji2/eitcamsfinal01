import React, { useState } from 'react';
import { RotateCcw, X, AlertCircle, CheckCircle2 } from 'lucide-react';
import { PaymentRecordItem } from '../../types/finance';
import { Button } from '../ui/Button';

interface RefundPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentRecordItem | null;
  onConfirmRefund: (paymentId: string, amount: number, reason: string) => Promise<any>;
}

export function RefundPaymentModal({
  isOpen,
  onClose,
  payment,
  onConfirmRefund,
}: RefundPaymentModalProps) {
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (isOpen && payment) {
      setAmount(String(payment.amountPaid));
      setReason('');
      setError(null);
      setIsSubmitting(false);
    }
  }, [isOpen, payment]);

  if (!isOpen || !payment) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Refund amount must be a positive number.');
      return;
    }
    if (parsedAmount > payment.amountPaid) {
      setError(`Refund amount cannot exceed total payment amount ($${payment.amountPaid.toFixed(2)}).`);
      return;
    }
    if (!reason.trim()) {
      setError('Audit justification reason is required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmRefund(payment.id, parsedAmount, reason.trim());
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to process refund.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-amber-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 bg-amber-50 border-b border-amber-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-amber-600 text-white flex items-center justify-center shadow-xs">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-amber-950">Issue Student Refund</h3>
              <p className="text-xs text-amber-800">Process authorized full or partial cash/bank refund.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-amber-500 hover:text-amber-800 hover:bg-amber-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-100 border border-red-300 rounded-xl text-xs text-red-800">
              {error}
            </div>
          )}

          <div className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-[#64748b]">Payment Voucher:</span>
              <span className="font-mono font-bold text-[#1e293b]">{payment.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Student:</span>
              <span className="font-bold text-[#1e293b]">
                {payment.studentName} ({payment.studentRegistrationNumber})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Original Amount:</span>
              <span className="font-mono font-bold text-slate-800">${payment.amountPaid.toFixed(2)}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Refund Amount (USD) <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">$</span>
              <input
                type="number"
                step="0.01"
                min="0.01"
                max={payment.amountPaid}
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 pr-3.5 py-2 text-sm font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">Maximum refundable: ${payment.amountPaid.toFixed(2)}</p>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Reason / Administrative Approval <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Approved course withdrawal term refund / Excess deposit returned"
              className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              disabled={isSubmitting}
              className="bg-amber-600 hover:bg-amber-700 text-white cursor-pointer"
            >
              {isSubmitting ? 'Processing...' : 'Authorize Refund'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
