import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Download, 
  Calendar, 
  TrendingUp, 
  Layers, 
  PieChart, 
  BookOpen 
} from 'lucide-react';
import { 
  FeeInvoiceRecord, 
  PaymentRecordItem, 
  FeeAdjustmentRecord, 
  StudentRecord, 
  StudentFeeSummary,
  FeeCategory,
  AdjustmentStatus,
  InvoiceStatus
} from '../../types';

interface FinancialReportsViewProps {
  invoices: FeeInvoiceRecord[];
  payments: PaymentRecordItem[];
  adjustments: FeeAdjustmentRecord[];
  students: StudentRecord[];
  studentSummaries: StudentFeeSummary[];
}

export const FinancialReportsView: React.FC<FinancialReportsViewProps> = ({
  invoices,
  payments,
  adjustments,
  students,
  studentSummaries,
}) => {
  const [activeReportTab, setActiveReportTab] = useState<'collection' | 'programme' | 'category' | 'modes' | 'statement'>('collection');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [startDate, setStartDate] = useState<string>(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 6);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });

  // 1. Collection stats
  const collectionStats = useMemo(() => {
    const activePayments = payments.filter(p => !p.isVoided);
    const dateFiltered = activePayments.filter(p => {
      const pDate = p.paymentDate.slice(0, 10);
      return pDate >= startDate && pDate <= endDate;
    });

    const totalCollected = dateFiltered.reduce((sum, p) => sum + p.amountPaid, 0);

    // Group by month
    const monthlyMap: Record<string, number> = {};
    dateFiltered.forEach(p => {
      const monthKey = p.paymentDate.slice(0, 7); // YYYY-MM
      monthlyMap[monthKey] = (monthlyMap[monthKey] || 0) + p.amountPaid;
    });

    const monthlyData = Object.entries(monthlyMap)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([month, amount]) => ({ month, amount }));

    return {
      totalCollected,
      paymentCount: dateFiltered.length,
      monthlyData,
      payments: dateFiltered
    };
  }, [payments, startDate, endDate]);

  // 2. Programme stats
  const programmeStats = useMemo(() => {
    const progMap: Record<string, { billed: number; collected: number; balance: number; students: number }> = {};
    
    // Initialize standard EIT programmes
    const defaultProgs = ['BTECH-CSE', 'BTECH-ECE', 'BTECH-MECH', 'BTECH-EEE', 'BTECH-CIVIL'];
    defaultProgs.forEach(p => {
      progMap[p] = { billed: 0, collected: 0, balance: 0, students: 0 };
    });

    students.forEach(st => {
      const prog = st.department || st.program_name;
      if (!progMap[prog]) {
        progMap[prog] = { billed: 0, collected: 0, balance: 0, students: 0 };
      }
      progMap[prog].students += 1;
    });

    studentSummaries.forEach(summary => {
      const student = students.find(s => s.registration_number === summary.studentRegistrationNumber || s.student_id === summary.studentRegistrationNumber);
      const prog = student ? (student.department || student.program_name) : 'BTECH-CSE';
      if (!progMap[prog]) {
        progMap[prog] = { billed: 0, collected: 0, balance: 0, students: 0 };
      }
      progMap[prog].billed += summary.totalDue;
      progMap[prog].collected += summary.totalPaid;
      progMap[prog].balance += summary.totalOutstanding;
    });

    return Object.entries(progMap).map(([programme, data]) => ({
      programme,
      ...data,
      collectionRate: data.billed > 0 ? ((data.collected / data.billed) * 100).toFixed(1) : '100'
    }));
  }, [students, studentSummaries]);

  // 3. Category Revenue distribution
  const categoryStats = useMemo(() => {
    const catMap: Record<string, { billed: number; paid: number; count: number }> = {
      TUITION: { billed: 0, paid: 0, count: 0 },
      ADMISSION: { billed: 0, paid: 0, count: 0 },
      EXAMINATION: { billed: 0, paid: 0, count: 0 },
      HOSTEL: { billed: 0, paid: 0, count: 0 },
      MESS: { billed: 0, paid: 0, count: 0 },
      LIBRARY: { billed: 0, paid: 0, count: 0 },
      LABORATORY: { billed: 0, paid: 0, count: 0 },
      TRANSPORT: { billed: 0, paid: 0, count: 0 },
      MISCELLANEOUS: { billed: 0, paid: 0, count: 0 },
    };

    invoices.forEach(inv => {
      if (inv.status !== InvoiceStatus.CANCELLED) {
        const cat = inv.fee_category;
        if (!catMap[cat]) {
          catMap[cat] = { billed: 0, paid: 0, count: 0 };
        }
        catMap[cat].billed += inv.amount_due;
        catMap[cat].paid += inv.amount_paid;
        catMap[cat].count += 1;
      }
    });

    return Object.entries(catMap)
      .filter(([_, data]) => data.billed > 0 || data.count > 0)
      .map(([category, data]) => ({
        category,
        ...data,
        due: Math.max(0, data.billed - data.paid)
      }));
  }, [invoices]);

  // 4. Payment Modes breakdown
  const paymentModeStats = useMemo(() => {
    const modeMap: Record<string, { amount: number; count: number }> = {};
    const activePayments = payments.filter(p => !p.isVoided);
    const total = activePayments.reduce((sum, p) => sum + p.amountPaid, 0);

    activePayments.forEach(p => {
      const mode = p.paymentMode;
      if (!modeMap[mode]) modeMap[mode] = { amount: 0, count: 0 };
      modeMap[mode].amount += p.amountPaid;
      modeMap[mode].count += 1;
    });

    return Object.entries(modeMap).map(([mode, data]) => ({
      mode,
      amount: data.amount,
      count: data.count,
      percentage: total > 0 ? ((data.amount / total) * 100).toFixed(1) : '0'
    }));
  }, [payments]);

  // 5. Selected Student Statement
  const studentStatement = useMemo(() => {
    if (!selectedStudentId) return null;
    const student = students.find(s => s.student_id === selectedStudentId || s.registration_number === selectedStudentId);
    if (!student) return null;

    const studentInvoices = invoices.filter(i => i.student_id === student.student_id || i.registration_number === student.registration_number);
    const studentPayments = payments.filter(p => p.studentRegistrationNumber === student.registration_number);
    const studentAdjustments = adjustments.filter(a => a.student_id === student.student_id || a.registration_number === student.registration_number);
    const summary = studentSummaries.find(s => s.studentRegistrationNumber === student.registration_number);

    // Build unified chronological ledger
    interface LedgerEntry {
      date: string;
      type: 'DEBIT' | 'CREDIT';
      category: string;
      reference: string;
      description: string;
      amount: number;
    }

    const ledger: LedgerEntry[] = [];

    studentInvoices.forEach(inv => {
      ledger.push({
        date: inv.created_at,
        type: 'DEBIT',
        category: inv.fee_category,
        reference: inv.invoice_id,
        description: `Fee Invoice: ${inv.fee_category} (${inv.academic_year} Sem ${inv.semester})`,
        amount: inv.amount_due
      });
    });

    studentPayments.forEach(pmt => {
      ledger.push({
        date: pmt.paymentDate,
        type: 'CREDIT',
        category: 'PAYMENT',
        reference: pmt.receiptNumber,
        description: `Payment via ${pmt.paymentMode}${pmt.isVoided ? ' (VOIDED)' : ''}`,
        amount: pmt.isVoided ? 0 : pmt.amountPaid
      });
    });

    studentAdjustments.forEach(adj => {
      if (adj.status === AdjustmentStatus.APPROVED) {
        ledger.push({
          date: adj.created_at,
          type: 'CREDIT',
          category: adj.adjustment_type,
          reference: adj.adjustment_id,
          description: `${adj.adjustment_type}: ${adj.reason}`,
          amount: adj.amount
        });
      }
    });

    // Sort ascending
    ledger.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    // Calculate running balance
    let runningBalance = 0;
    const ledgerWithBalance = ledger.map(entry => {
      if (entry.type === 'DEBIT') {
        runningBalance += entry.amount;
      } else {
        runningBalance -= entry.amount;
      }
      return {
        ...entry,
        runningBalance
      };
    });

    return {
      student,
      summary,
      ledger: ledgerWithBalance
    };
  }, [selectedStudentId, students, invoices, payments, adjustments, studentSummaries]);

  // Export functions
  const handleExportCSV = () => {
    if (activeReportTab === 'collection') {
      const headers = ['Receipt #', 'Student Reg No', 'Amount ($)', 'Mode', 'Reference', 'Date'];
      const rows = collectionStats.payments.map(p => [
        p.receiptNumber,
        p.studentRegistrationNumber,
        p.amountPaid,
        p.paymentMode,
        p.transactionReference || 'N/A',
        new Date(p.paymentDate).toLocaleDateString()
      ]);
      downloadCSV('EIT_Collection_Register', headers, rows);
    } else if (activeReportTab === 'programme') {
      const headers = ['Programme', 'Students', 'Total Billed ($)', 'Total Collected ($)', 'Balance Due ($)', 'Collection Rate (%)'];
      const rows = programmeStats.map(p => [
        p.programme,
        p.students,
        p.billed,
        p.collected,
        p.balance,
        p.collectionRate
      ]);
      downloadCSV('EIT_Programme_Receivables', headers, rows);
    } else if (activeReportTab === 'category') {
      const headers = ['Fee Category', 'Invoices', 'Billed ($)', 'Collected ($)', 'Outstanding ($)'];
      const rows = categoryStats.map(c => [
        c.category,
        c.count,
        c.billed,
        c.paid,
        c.due
      ]);
      downloadCSV('EIT_Category_Revenue_Distribution', headers, rows);
    } else if (activeReportTab === 'statement' && studentStatement) {
      const headers = ['Date', 'Type', 'Category', 'Reference', 'Description', 'Amount ($)', 'Balance ($)'];
      const rows = studentStatement.ledger.map(l => [
        new Date(l.date).toLocaleDateString(),
        l.type,
        l.category,
        l.reference,
        `"${l.description.replace(/"/g, '""')}"`,
        l.amount,
        l.runningBalance
      ]);
      downloadCSV(`EIT_Ledger_${studentStatement.student.registration_number}`, headers, rows);
    }
  };

  const downloadCSV = (filename: string, headers: string[], rows: any[][]) => {
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
              <BarChart3 className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-800">Financial Reports & Reconciliation</h1>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Authoritative institutional audits, programme receivable balances, daily collection logs, and student ledgers.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-semibold shadow-sm transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Export Active Report
          </button>
        </div>
      </div>

      {/* Report Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveReportTab('collection')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeReportTab === 'collection'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Collection Register</span>
        </button>
        <button
          onClick={() => setActiveReportTab('programme')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeReportTab === 'programme'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Programme Receivables</span>
        </button>
        <button
          onClick={() => setActiveReportTab('category')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeReportTab === 'category'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Category Distribution</span>
        </button>
        <button
          onClick={() => setActiveReportTab('modes')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeReportTab === 'modes'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>Payment Channels</span>
        </button>
        <button
          onClick={() => setActiveReportTab('statement')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeReportTab === 'statement'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Student Ledger Audit</span>
        </button>
      </div>

      {/* 1. Collection Register Tab */}
      {activeReportTab === 'collection' && (
        <div className="space-y-6">
          {/* Date Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-500 uppercase">Period Filter:</span>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-sm"
                />
                <span className="text-slate-400">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={e => setEndDate(e.target.value)}
                  className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-sm"
                />
              </div>
            </div>

            <div className="flex items-center gap-4 text-sm">
              <div className="text-slate-500">
                Transactions: <span className="font-bold text-slate-800">{collectionStats.paymentCount}</span>
              </div>
              <div className="text-slate-500">
                Period Total: <span className="font-bold text-emerald-600">${collectionStats.totalCollected.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Monthly Trend Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {collectionStats.monthlyData.map(m => (
              <div key={m.month} className="bg-white p-3 rounded-lg border border-slate-200 text-center">
                <div className="text-xs text-slate-500 font-medium">{m.month}</div>
                <div className="text-base font-bold text-slate-800 mt-1">${m.amount.toLocaleString()}</div>
              </div>
            ))}
          </div>

          {/* Collection Register Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center">
              <h3 className="font-semibold text-slate-800">Verified Payment Entries</h3>
              <span className="text-xs text-slate-500">{collectionStats.payments.length} settled receipts</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Receipt Number</th>
                    <th className="px-6 py-3">Student Reg No</th>
                    <th className="px-6 py-3">Amount</th>
                    <th className="px-6 py-3">Payment Channel</th>
                    <th className="px-6 py-3">Txn Reference</th>
                    <th className="px-6 py-3">Settlement Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {collectionStats.payments.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50/80">
                      <td className="px-6 py-3.5 font-mono font-medium text-slate-900">{p.receiptNumber}</td>
                      <td className="px-6 py-3.5 font-mono text-slate-700">{p.studentRegistrationNumber}</td>
                      <td className="px-6 py-3.5 font-semibold text-emerald-600">${p.amountPaid.toLocaleString()}</td>
                      <td className="px-6 py-3.5">
                        <span className="px-2 py-0.5 bg-slate-100 rounded text-xs font-medium text-slate-700">
                          {p.paymentMode}
                        </span>
                      </td>
                      <td className="px-6 py-3.5 text-xs text-slate-500 font-mono">{p.transactionReference || 'N/A'}</td>
                      <td className="px-6 py-3.5 text-xs text-slate-500">
                        {new Date(p.paymentDate).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. Programme Receivables Tab */}
      {activeReportTab === 'programme' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center">
              <h3 className="font-semibold text-slate-800">Programme-wise Receivables & Recovery Rate</h3>
              <span className="text-xs text-slate-500">All registered undergraduate batches</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Academic Programme</th>
                    <th className="px-6 py-3">Enrolled</th>
                    <th className="px-6 py-3">Gross Billed</th>
                    <th className="px-6 py-3">Net Collected</th>
                    <th className="px-6 py-3">Outstanding Dues</th>
                    <th className="px-6 py-3">Recovery Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {programmeStats.map(row => (
                    <tr key={row.programme} className="hover:bg-slate-50/80">
                      <td className="px-6 py-4 font-semibold text-slate-900">{row.programme}</td>
                      <td className="px-6 py-4 text-slate-600">{row.students} students</td>
                      <td className="px-6 py-4 font-medium text-slate-800">${row.billed.toLocaleString()}</td>
                      <td className="px-6 py-4 font-medium text-emerald-600">${row.collected.toLocaleString()}</td>
                      <td className="px-6 py-4 font-medium text-rose-600">${row.balance.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-slate-200 rounded-full h-2 overflow-hidden">
                            <div 
                              className="bg-emerald-500 h-full rounded-full"
                              style={{ width: `${Math.min(100, Math.max(0, Number(row.collectionRate)))}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-slate-700">{row.collectionRate}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. Category Distribution Tab */}
      {activeReportTab === 'category' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {categoryStats.map(cat => (
              <div key={cat.category} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-800">{cat.category}</span>
                  <span className="text-xs px-2 py-0.5 bg-slate-100 rounded text-slate-600">{cat.count} invoices</span>
                </div>
                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Gross Demanded:</span>
                    <span className="font-semibold text-slate-800">${cat.billed.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Recovered:</span>
                    <span className="font-semibold text-emerald-600">${cat.paid.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-100 pt-1.5 font-bold">
                    <span className="text-slate-600">Pending Due:</span>
                    <span className="text-rose-600">${cat.due.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Payment Channels Tab */}
      {activeReportTab === 'modes' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h3 className="font-semibold text-slate-800">Institutional Payment Gateways & Banking Channels</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Channel / Mode</th>
                    <th className="px-6 py-3">Transaction Count</th>
                    <th className="px-6 py-3">Total Volume</th>
                    <th className="px-6 py-3">Share (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {paymentModeStats.map(pm => (
                    <tr key={pm.mode} className="hover:bg-slate-50/80">
                      <td className="px-6 py-4 font-semibold text-slate-900">{pm.mode}</td>
                      <td className="px-6 py-4 text-slate-700">{pm.count} transactions</td>
                      <td className="px-6 py-4 font-bold text-emerald-600">${pm.amount.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div 
                              className="bg-blue-600 h-full rounded-full"
                              style={{ width: `${pm.percentage}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-slate-700">{pm.percentage}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5. Student Ledger Audit Tab */}
      {activeReportTab === 'statement' && (
        <div className="space-y-6">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-4">
            <label className="text-xs font-semibold text-slate-600 whitespace-nowrap">
              Select Student for Comprehensive Ledger:
            </label>
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="w-full sm:w-96 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            >
              <option value="">-- Choose student --</option>
              {students.map(s => (
                <option key={s.student_id} value={s.student_id}>
                  {s.registration_number} - {s.first_name} {s.last_name} ({s.department || s.program_name})
                </option>
              ))}
            </select>
          </div>

          {studentStatement ? (
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-6">
              {/* Header Details */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-800">
                    {studentStatement.student.first_name} {studentStatement.student.last_name}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Reg No: {studentStatement.student.registration_number} • Programme: {studentStatement.student.program_name} • Semester {studentStatement.student.current_semester}
                  </p>
                </div>
                <div className="text-right mt-3 sm:mt-0">
                  <div className="text-xs text-slate-500">Current Outstanding Balance</div>
                  <div className="text-2xl font-bold text-rose-600">
                    ${(studentStatement.summary?.totalOutstanding ?? 0).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Ledger Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600">
                  <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3">Date</th>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3">Ref / Invoice #</th>
                      <th className="px-4 py-3">Transaction Description</th>
                      <th className="px-4 py-3 text-right">Debit ($)</th>
                      <th className="px-4 py-3 text-right">Credit ($)</th>
                      <th className="px-4 py-3 text-right">Running Balance ($)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {studentStatement.ledger.map((l, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80">
                        <td className="px-4 py-3 text-xs text-slate-500">
                          {new Date(l.date).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            l.type === 'DEBIT' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {l.type}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-slate-700">{l.reference}</td>
                        <td className="px-4 py-3 text-slate-800">{l.description}</td>
                        <td className="px-4 py-3 text-right font-medium text-amber-700">
                          {l.type === 'DEBIT' ? `$${l.amount.toLocaleString()}` : '-'}
                        </td>
                        <td className="px-4 py-3 text-right font-medium text-emerald-700">
                          {l.type === 'CREDIT' ? `$${l.amount.toLocaleString()}` : '-'}
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-slate-900">
                          ${l.runningBalance.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-500">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="font-semibold text-slate-700">Select a student to inspect their full institutional fee ledger</p>
              <p className="text-xs text-slate-500 mt-1">
                Displays every fee invoice debit, scholarship/waiver credit, and receipt settlement in chronological sequence.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
