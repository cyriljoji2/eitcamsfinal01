import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
  Calendar,
  DollarSign,
  Tag,
  Download,
  AlertCircle,
  Users,
} from 'lucide-react';
import { FeeStructureItem, FeeCategory } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { FeeStructureModal } from './FeeStructureModal';

interface FeeStructureViewProps {
  feeStructures: FeeStructureItem[];
  onCreateFeeStructure: (data: Omit<FeeStructureItem, 'id'>) => Promise<any>;
  onUpdateFeeStructure: (id: string, data: Partial<FeeStructureItem>) => Promise<any>;
  onToggleStatus: (id: string) => Promise<any>;
  onDeleteFeeStructure: (id: string) => Promise<any>;
  onNavigateToAssign: (feeStructureId: string) => void;
}

export function FeeStructureView({
  feeStructures,
  onCreateFeeStructure,
  onUpdateFeeStructure,
  onToggleStatus,
  onDeleteFeeStructure,
  onNavigateToAssign,
}: FeeStructureViewProps) {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [programmeFilter, setProgrammeFilter] = useState<string>('all');

  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    item: FeeStructureItem | null;
  }>({
    isOpen: false,
    item: null,
  });

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const filteredItems = feeStructures.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.id.toLowerCase().includes(search.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(search.toLowerCase())) ||
      (item.programmeCode && item.programmeCode.toLowerCase().includes(search.toLowerCase()));

    const matchesCategory = categoryFilter === 'all' || item.feeCategory === categoryFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? item.status.toLowerCase() === 'active'
        : item.status.toLowerCase() === 'inactive';

    const matchesProg = programmeFilter === 'all' || item.programmeCode === programmeFilter;

    return matchesSearch && matchesCategory && matchesStatus && matchesProg;
  });

  const uniqueProgrammes = Array.from(new Set(feeStructures.map((f) => f.programmeCode).filter(Boolean))).sort();

  const handleExportCsv = () => {
    const headers = [
      'Structure ID',
      'Fee Head Name',
      'Category',
      'Amount (USD)',
      'Academic Session',
      'Semester',
      'Programme Code',
      'Frequency',
      'Due Date',
      'Status',
      'Notes',
    ];

    const rows = filteredItems.map((item) => [
      item.id,
      item.name,
      item.feeCategory,
      item.amount.toFixed(2),
      item.academicSession,
      item.semester === 0 ? 'All' : item.semester,
      item.programmeCode || 'ALL',
      item.frequency,
      item.dueDate,
      item.status.toUpperCase(),
      item.description || '',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `EIT_Fee_Structures_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">University Fee Heads & Rate Cards</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative fee structures for Tuition, Examinations, Labs, Residential, and Student Services.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export CSV
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={() => setModalState({ isOpen: true, item: null })}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs bg-[#1e3a8a] hover:bg-[#172554] cursor-pointer"
          >
            Create Fee Head
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by fee title, ID, or programme..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <Filter className="w-3.5 h-3.5" />
            <span>Category:</span>
          </div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Categories</option>
            <option value={FeeCategory.TUITION}>Tuition</option>
            <option value={FeeCategory.EXAMINATION}>Examination</option>
            <option value={FeeCategory.LABORATORY}>Laboratory</option>
            <option value={FeeCategory.LIBRARY}>Library</option>
            <option value={FeeCategory.HOSTEL}>Hostel</option>
            <option value={FeeCategory.TRANSPORT}>Transport</option>
            <option value={FeeCategory.MISCELLANEOUS}>Miscellaneous</option>
          </select>

          <select
            value={programmeFilter}
            onChange={(e) => setProgrammeFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Programmes</option>
            {uniqueProgrammes.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive / Draft</option>
          </select>
        </div>
      </div>

      {/* Fee Structures Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Rate Card / ID</th>
                <th className="py-3 px-4">Fee Head & Description</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Programme & Sem</th>
                <th className="py-3 px-4 text-right">Standard Amount</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#64748b]">
                    No fee structures found matching current filter parameters.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-mono font-bold text-[#1e3a8a] block">{item.id}</span>
                      <span className="text-[10px] text-[#64748b]">{item.academicSession}</span>
                    </td>
                    <td className="py-3.5 px-4 max-w-xs">
                      <span className="font-bold text-[#1e293b] block">{item.name}</span>
                      {item.description && (
                        <span className="text-[11px] text-[#64748b] line-clamp-1">{item.description}</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge variant="blue" size="sm">
                        {item.feeCategory}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800 block">{item.programmeCode || 'ALL'}</span>
                      <span className="text-[10px] text-slate-500">
                        {item.semester === 0 ? 'All Semesters' : `Semester ${item.semester}`}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                      ${item.amount.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-[#64748b] whitespace-nowrap">{item.dueDate}</td>
                    <td className="py-3.5 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => onToggleStatus(item.id)}
                        className="cursor-pointer"
                        title="Click to toggle active state"
                      >
                        <Badge
                          variant={item.status.toLowerCase() === 'active' ? 'emerald' : 'default'}
                          size="sm"
                        >
                          {item.status.toUpperCase()}
                        </Badge>
                      </button>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onNavigateToAssign(item.id)}
                          leftIcon={<Users className="w-3.5 h-3.5" />}
                          className="text-xs text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
                          title="Assign to student cohort"
                        >
                          Assign
                        </Button>

                        <button
                          type="button"
                          onClick={() => setModalState({ isOpen: true, item })}
                          className="p-1.5 text-slate-500 hover:text-[#1e3a8a] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                          title="Edit fee head"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeleteConfirmId(item.id)}
                          className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Deactivate rate card"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-2.5 text-red-600 font-bold">
              <AlertCircle className="w-5 h-5" />
              <span>Deactivate Fee Structure</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to deactivate <span className="font-mono font-bold text-slate-900">{deleteConfirmId}</span>?
              Existing issued invoices will retain their historical billing data.
            </p>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <Button variant="ghost" size="sm" onClick={() => setDeleteConfirmId(null)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={async () => {
                  await onDeleteFeeStructure(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
              >
                Confirm Deactivate
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Fee Structure Creation / Edit Modal */}
      <FeeStructureModal
        isOpen={modalState.isOpen}
        onClose={() => setModalState({ isOpen: false, item: null })}
        item={modalState.item}
        onSubmit={async (data) => {
          if (modalState.item) {
            await onUpdateFeeStructure(modalState.item.id, data);
          } else {
            await onCreateFeeStructure(data);
          }
        }}
      />
    </div>
  );
}
