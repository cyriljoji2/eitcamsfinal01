import React, { useState } from 'react';
import {
  AlertTriangle,
  Search,
  Filter,
  Download,
  DollarSign,
  Calendar,
  Clock,
  Send,
  CheckCircle2,
  BellRing,
  Eye,
  CreditCard,
} from 'lucide-react';
import { FeeAssignment } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface OutstandingFeesViewProps {
  assignments: FeeAssignment[];
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function OutstandingFeesView({
  assignments,
  onOpenPaymentModal,
  onViewStudentProfile,
}: OutstandingFeesViewProps) {
  const [search, setSearch] = useState('');
  const [programmeFilter, setProgrammeFilter] = useState('all');
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [reminderStatus, setReminderStatus] = useState<string | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];

  // Only consider assignments that have a positive balance
  const outstandingList = assignments.filter((a) => {
    const bal = a.balanceDue ?? a.balance ?? 0;
    return bal > 0;
  });

  const uniqueProgrammes = Array.from(new Set(outstandingList.map((a) => a.academicSession || a.category || 'All'))).sort();

  const filtered = outstandingList.filter((a) => {
    const matchesSearch =
      a.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      a.feeTypeName.toLowerCase().includes(search.toLowerCase());

    const isOverdue = a.dueDate < todayStr;
    const matchesOverdue = !overdueOnly || isOverdue;

    return matchesSearch && matchesOverdue;
  });

  const totalOutstandingSum = filtered.reduce((acc, a) => acc + (a.balanceDue ?? a.balance ?? 0), 0);
  const totalOverdueCount = filtered.filter((a) => a.dueDate < todayStr).length;
  const totalOverdueSum = filtered
    .filter((a) => a.dueDate < todayStr)
    .reduce((acc, a) => acc + (a.balanceDue ?? a.balance ?? 0), 0);

  // Aging calculation
  const getDaysOverdue = (dueDate: string) => {
    const due = new Date(dueDate).getTime();
    const now = new Date(todayStr).getTime();
    const diff = Math.floor((now - due) / (1000 * 60 * 60 * 24));
    return diff > 0 ? diff : 0;
  };

  const agingStats = {
    current: filtered.filter((a) => a.dueDate >= todayStr).reduce((s, a) => s + (a.balanceDue ?? a.balance ?? 0), 0),
    days30: filtered.filter((a) => getDaysOverdue(a.dueDate) > 0 && getDaysOverdue(a.dueDate) <= 30).reduce((s, a) => s + (a.balanceDue ?? a.balance ?? 0), 0),
    days60: filtered.filter((a) => getDaysOverdue(a.dueDate) > 30 && getDaysOverdue(a.dueDate) <= 60).reduce((s, a) => s + (a.balanceDue ?? a.balance ?? 0), 0),
    days90Plus: filtered.filter((a) => getDaysOverdue(a.dueDate) > 60).reduce((s, a) => s + (a.balanceDue ?? a.balance ?? 0), 0),
  };

  const handleSendReminder = (regNo: string) => {
    setReminderStatus(`Dispatched official dues clearance notice to student ${regNo}.`);
    setTimeout(() => setReminderStatus(null), 4000);
  };

  const handleSendAllReminders = () => {
    setReminderStatus(`Dispatched electronic fee reminder notices to ${filtered.length} candidate(s).`);
    setTimeout(() => setReminderStatus(null), 4000);
  };

  const handleExportCsv = () => {
    const headers = [
      'Invoice / Assignment ID',
      'Registration Number',
      'Fee Head',
      'Total Amount Due ($)',
      'Amount Paid ($)',
      'Outstanding Balance ($)',
      'Due Date',
      'Days Overdue',
      'Is Overdue',
    ];

    const rows = filtered.map((a) => {
      const balance = a.balanceDue ?? a.balance ?? 0;
      const days = getDaysOverdue(a.dueDate);
      return [
        a.id,
        a.studentRegistrationNumber,
        a.feeTypeName,
        a.amountDue.toFixed(2),
        a.amountPaid.toFixed(2),
        balance.toFixed(2),
        a.dueDate,
        days,
        days > 0 ? 'YES (OVERDUE)' : 'NO (CURRENT)',
      ];
    });

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Outstanding_Dues_Defaulters_${todayStr}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Outstanding Fees & Dues Aging</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional fee defaulters tracking, overdue aging cohorts, and automated balance intimations.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Dues CSV
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={handleSendAllReminders}
            leftIcon={<BellRing className="w-4 h-4" />}
            className="text-xs bg-[#1e3a8a] hover:bg-[#172554] cursor-pointer"
          >
            Dispatch All Reminders
          </Button>
        </div>
      </div>

      {reminderStatus && (
        <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
          <span>{reminderStatus}</span>
        </div>
      )}

      {/* 4 Aging Cohort Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
            Current / Not Due
          </span>
          <span className="text-xl font-mono font-black text-emerald-800">${agingStats.current.toFixed(2)}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Within grace window</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
            1 – 30 Days Overdue
          </span>
          <span className="text-xl font-mono font-black text-amber-800">${agingStats.days30.toFixed(2)}</span>
          <span className="text-[10px] text-amber-700 block mt-1">Stage 1 reminder</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-orange-700 block mb-1">
            31 – 60 Days Overdue
          </span>
          <span className="text-xl font-mono font-black text-orange-800">${agingStats.days60.toFixed(2)}</span>
          <span className="text-[10px] text-orange-700 block mt-1">Stage 2 formal intimation</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 block mb-1">
            &gt; 60 Days Critical
          </span>
          <span className="text-xl font-mono font-black text-red-900">${agingStats.days90Plus.toFixed(2)}</span>
          <span className="text-[10px] text-red-700 block mt-1">Examination block threshold</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by student registration or fee head..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-xs font-semibold text-[#1e293b] cursor-pointer">
            <input
              type="checkbox"
              checked={overdueOnly}
              onChange={(e) => setOverdueOnly(e.target.checked)}
              className="rounded text-[#1e3a8a] focus:ring-[#1e3a8a] h-4 w-4"
            />
            <span>Overdue Balance Only ({totalOverdueCount})</span>
          </label>
        </div>
      </div>

      {/* Defaulters Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Invoice #</th>
                <th className="py-3 px-4">Student Registration</th>
                <th className="py-3 px-4">Particulars</th>
                <th className="py-3 px-4 text-right">Invoiced ($)</th>
                <th className="py-3 px-4 text-right">Paid ($)</th>
                <th className="py-3 px-4 text-right">Balance Due ($)</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4 text-center">Aging Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#64748b]">
                    No outstanding fee balances found matching the filter criteria.
                  </td>
                </tr>
              ) : (
                filtered.map((a) => {
                  const balance = a.balanceDue ?? a.balance ?? 0;
                  const days = getDaysOverdue(a.dueDate);
                  const isOver = days > 0;
                  return (
                    <tr key={a.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">{a.id}</td>
                      <td className="py-3.5 px-4 font-mono font-semibold text-[#1e293b]">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                          className="hover:text-[#1e3a8a] hover:underline cursor-pointer"
                        >
                          {a.studentRegistrationNumber}
                        </button>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-800">{a.feeTypeName}</td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                        ${a.amountDue.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-800">
                        ${a.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-black text-sm text-red-700">
                        ${balance.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-[#64748b] whitespace-nowrap">{a.dueDate}</td>
                      <td className="py-3.5 px-4 text-center">
                        {isOver ? (
                          <Badge variant="rose" size="sm">
                            {days} Days Overdue
                          </Badge>
                        ) : (
                          <Badge variant="emerald" size="sm">
                            Current
                          </Badge>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => onOpenPaymentModal(a.studentRegistrationNumber, a.id)}
                            className="text-[11px] bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
                          >
                            Pay
                          </Button>

                          <button
                            type="button"
                            onClick={() => handleSendReminder(a.studentRegistrationNumber)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                            title="Send electronic reminder"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                            className="text-xs text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
                          >
                            Ledger
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
