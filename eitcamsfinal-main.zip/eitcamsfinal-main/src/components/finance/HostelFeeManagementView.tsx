import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Search, 
  Filter, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  DollarSign, 
  Users, 
  FileCheck, 
  Calendar, 
  Bed, 
  ArrowRight, 
  ShieldCheck, 
  Download 
} from 'lucide-react';
import { 
  HostelChargeRequestRecord, 
  HostelChargeStatus, 
  StudentRecord 
} from '../../types';

interface HostelFeeManagementViewProps {
  hostelCharges: HostelChargeRequestRecord[];
  students: StudentRecord[];
  onIssueInvoice: (chargeId: string, dueDate: string) => Promise<void>;
  onRefresh: () => void;
}

export const HostelFeeManagementView: React.FC<HostelFeeManagementViewProps> = ({
  hostelCharges,
  students,
  onIssueInvoice,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | HostelChargeStatus>('ALL');
  const [selectedCharge, setSelectedCharge] = useState<HostelChargeRequestRecord | null>(null);
  const [dueDate, setDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 15);
    return d.toISOString().split('T')[0];
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Compute metrics
  const metrics = useMemo(() => {
    const totalRequests = hostelCharges.length;
    const requested = hostelCharges.filter(c => c.status === HostelChargeStatus.REQUESTED);
    const invoiced = hostelCharges.filter(c => c.status === HostelChargeStatus.INVOICED);
    
    const pendingTotal = requested.reduce((sum, c) => sum + c.amount, 0);
    const invoicedTotal = invoiced.reduce((sum, c) => sum + c.amount, 0);

    return {
      totalRequests,
      pendingCount: requested.length,
      pendingTotal,
      invoicedCount: invoiced.length,
      invoicedTotal,
    };
  }, [hostelCharges]);

  // Filtered charges
  const filteredCharges = useMemo(() => {
    return hostelCharges.filter(charge => {
      const student = students.find(s => s.student_id === charge.student_id);
      const matchesSearch = 
        charge.student_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        charge.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student && `${student.first_name} ${student.last_name}`.toLowerCase().includes(searchTerm.toLowerCase())) ||
        charge.billing_period.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'ALL' || charge.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [hostelCharges, students, searchTerm, statusFilter]);

  const handleConfirmInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCharge) return;

    setIsSubmitting(true);
    setMessage(null);
    try {
      await onIssueInvoice(selectedCharge.charge_request_id, dueDate);
      setMessage({ type: 'success', text: `Hostel fee invoice successfully generated for student ${selectedCharge.student_id}.` });
      setSelectedCharge(null);
    } catch (err: any) {
      setMessage({ type: 'error', text: err?.message || 'Failed to issue hostel fee invoice.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExportCSV = () => {
    const headers = ['Request ID', 'Student ID', 'Student Name', 'Billing Period', 'Description', 'Amount ($)', 'Status', 'Requested At', 'Invoice ID'];
    const rows = filteredCharges.map(c => {
      const student = students.find(s => s.student_id === c.student_id);
      return [
        c.charge_request_id,
        c.student_id,
        student ? `"${student.first_name} ${student.last_name}"` : `"${c.student_name}"`,
        c.billing_period,
        `"${c.description.replace(/"/g, '""')}"`,
        c.amount,
        c.status,
        new Date(c.requested_at).toLocaleDateString(),
        c.invoice_id || 'N/A'
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EIT_Hostel_Fee_Demands_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
              <Building2 className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-800">Hostel Fee Management</h1>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Reconcile accommodation billing requests sent by Hostel Office (PO-006) and generate authoritative student invoices.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export Demands
          </button>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-xl border text-sm flex items-center justify-between ${
          message.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          <span>{message.text}</span>
          <button onClick={() => setMessage(null)} className="text-xs underline font-medium">Dismiss</button>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Demands</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-bold text-slate-800 mt-2">{metrics.totalRequests}</p>
          <p className="text-xs text-slate-500 mt-1">Resident allocations from Hostel Office</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Pending Invoice</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-bold text-amber-600 mt-2">{metrics.pendingCount}</p>
          <p className="text-xs text-slate-500 mt-1">
            ${metrics.pendingTotal.toLocaleString()} unbilled accommodation
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Invoiced & Active</span>
            <FileCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold text-emerald-600 mt-2">{metrics.invoicedCount}</p>
          <p className="text-xs text-slate-500 mt-1">
            ${metrics.invoicedTotal.toLocaleString()} added to student ledger
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Institutional Sync</span>
            <ShieldCheck className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-base font-bold text-blue-700 mt-2 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4 text-emerald-500" />
            PO-006 Link Active
          </p>
          <p className="text-xs text-slate-500 mt-1">Segregation of duties enforced</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student ID, billing period, details..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Filter className="w-3.5 h-3.5" />
            <span>Status:</span>
          </div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          >
            <option value="ALL">All Statuses</option>
            <option value={HostelChargeStatus.REQUESTED}>Awaiting Invoicing</option>
            <option value={HostelChargeStatus.INVOICED}>Invoiced</option>
            <option value={HostelChargeStatus.REJECTED}>Rejected</option>
          </select>
        </div>
      </div>

      {/* Hostel Charges Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800">Accommodation Billing Queue ({filteredCharges.length})</h3>
          <span className="text-xs text-slate-500">Official hostel charge requests</span>
        </div>

        {filteredCharges.length === 0 ? (
          <div className="text-center py-12">
            <Bed className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-semibold text-slate-700">No hostel charge records found</h4>
            <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
              There are no incoming room allocation billing requests matching the selected filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3">Student & Allocation</th>
                  <th className="px-6 py-3">Billing Period</th>
                  <th className="px-6 py-3">Description</th>
                  <th className="px-6 py-3">Demand Amount</th>
                  <th className="px-6 py-3">Requested At</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredCharges.map(charge => {
                  const student = students.find(s => s.student_id === charge.student_id);
                  return (
                    <tr key={charge.charge_request_id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">
                          {student ? `${student.first_name} ${student.last_name}` : charge.student_name}
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="font-mono">{charge.student_id}</span>
                          {student && <span>• {student.program_name}</span>}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-800 font-medium font-mono text-xs">
                        {charge.billing_period}
                      </td>
                      <td className="px-6 py-4 text-slate-700 text-xs max-w-xs truncate" title={charge.description}>
                        {charge.description}
                      </td>
                      <td className="px-6 py-4 font-bold text-slate-900">
                        ${charge.amount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-500">
                        {new Date(charge.requested_at).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4">
                        {charge.status === HostelChargeStatus.INVOICED ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                              <CheckCircle className="w-3 h-3" />
                              Invoiced
                            </span>
                            {charge.invoice_id && (
                              <div className="text-[10px] font-mono text-slate-500">
                                {charge.invoice_id}
                              </div>
                            )}
                          </div>
                        ) : charge.status === HostelChargeStatus.REJECTED ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800">
                            <AlertCircle className="w-3 h-3" />
                            Rejected
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            Pending Invoice
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        {charge.status === HostelChargeStatus.REQUESTED ? (
                          <button
                            onClick={() => setSelectedCharge(charge)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                          >
                            <span>Issue Invoice</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        ) : (
                          <span className="text-xs text-slate-400 font-mono">Billed</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Confirmation Modal */}
      {selectedCharge && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full shadow-xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-indigo-600" />
                Issue Official Hostel Fee Invoice
              </h3>
              <button
                onClick={() => setSelectedCharge(null)}
                className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmInvoice} className="p-6 space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Student:</span>
                  <span className="font-semibold text-slate-800">{selectedCharge.student_name} ({selectedCharge.student_id})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Description:</span>
                  <span className="font-medium text-slate-800">{selectedCharge.description}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-2 font-bold text-sm">
                  <span className="text-slate-700">Invoice Amount:</span>
                  <span className="text-indigo-600">${selectedCharge.amount.toLocaleString()}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Payment Due Date
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Specifies deadline before outstanding penalty or hostel clearance flag triggers.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setSelectedCharge(null)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold shadow-sm transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {isSubmitting ? 'Issuing...' : 'Generate Invoice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Integration Governance Note */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-start gap-3 text-slate-600 text-xs leading-relaxed">
        <Building2 className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold text-slate-800">Hostel Office & Finance Office Integration Architecture</p>
          <p className="mt-0.5">
            Hostel wardens allocate rooms and post demand requests under PO-006. In accordance with university statutory auditing,
            only Finance Office (PO-005) officers can formally commit receivables, issue student fee invoices, and acknowledge receipts.
          </p>
        </div>
      </div>
    </div>
  );
};
