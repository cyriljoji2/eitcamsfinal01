import React, { useState } from 'react';
import { ArrowRightLeft, X, AlertCircle, CheckCircle2 } from 'lucide-react';
import { AdjustmentType, FeeInvoiceRecord } from '../../types/database';
import { Button } from '../ui/Button';

interface FeeAdjustmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoices: FeeInvoiceRecord[];
  initialInvoiceId?: string;
  onRequestAdjustment: (data: {
    invoice_id: string;
    adjustment_type: AdjustmentType;
    amount: number;
    reason: string;
  }) => Promise<any>;
}

const ADJUSTMENT_TYPES = [
  { label: 'Correction / Billing Revision', value: AdjustmentType.CORRECTION },
  { label: 'Fee Waiver (100% or Partial)', value: AdjustmentType.FEE_WAIVER },
  { label: 'Merit Discount', value: AdjustmentType.MERIT_DISCOUNT },
  { label: 'Need-based Financial Aid', value: AdjustmentType.FINANCIAL_AID },
  { label: 'Institutional Concession', value: AdjustmentType.CONCESSION },
  { label: 'Scholarship Award', value: AdjustmentType.SCHOLARSHIP },
];

export function FeeAdjustmentModal({
  isOpen,
  onClose,
  invoices,
  initialInvoiceId,
  onRequestAdjustment,
}: FeeAdjustmentModalProps) {
  const [selectedInvoiceId, setSelectedInvoiceId] = useState(initialInvoiceId || '');
  const [adjustmentType, setAdjustmentType] = useState<AdjustmentType>(AdjustmentType.CORRECTION);
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (isOpen) {
      setError(null);
      setIsSubmitting(false);
      if (initialInvoiceId) {
        setSelectedInvoiceId(initialInvoiceId);
        const inv = invoices.find((i) => i.invoice_id === initialInvoiceId);
        if (inv) setAmount(String(inv.outstanding_balance));
      } else if (invoices.length > 0) {
        setSelectedInvoiceId(invoices[0].invoice_id);
        setAmount(String(invoices[0].outstanding_balance));
      }
    }
  }, [isOpen, initialInvoiceId, invoices]);

  if (!isOpen) return null;

  const targetInvoice = invoices.find((i) => i.invoice_id === selectedInvoiceId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoiceId) {
      setError('Please select an invoice.');
      return;
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Adjustment amount must be a positive number.');
      return;
    }

    if (targetInvoice && parsedAmount > targetInvoice.total_amount) {
      setError(`Adjustment amount cannot exceed total invoice amount of $${targetInvoice.total_amount}.`);
      return;
    }

    if (!reason.trim()) {
      setError('Please state an authorized reason for this adjustment.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onRequestAdjustment({
        invoice_id: selectedInvoiceId,
        adjustment_type: adjustmentType,
        amount: parsedAmount,
        reason: reason.trim(),
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit adjustment request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        <div className="p-5 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">Request Fee Adjustment</h3>
              <p className="text-xs text-[#64748b]">Submit auditable concession, correction, or waiver.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Target Invoice <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedInvoiceId}
              onChange={(e) => {
                setSelectedInvoiceId(e.target.value);
                const inv = invoices.find((i) => i.invoice_id === e.target.value);
                if (inv) setAmount(String(inv.outstanding_balance));
              }}
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            >
              {invoices.map((inv) => (
                <option key={inv.invoice_id} value={inv.invoice_id}>
                  {inv.invoice_id} — {inv.student_name} ({inv.registration_number}) &bull; {inv.fee_category} (Balance: ${inv.outstanding_balance})
                </option>
              ))}
            </select>
            {targetInvoice && (
              <div className="mt-1.5 p-2 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-[#475569] flex justify-between">
                <span>Subtotal: ${targetInvoice.subtotal}</span>
                <span>Adjustments: ${targetInvoice.adjustments_total}</span>
                <span className="font-bold text-[#1e3a8a]">Outstanding: ${targetInvoice.outstanding_balance}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Adjustment Type <span className="text-red-500">*</span>
              </label>
              <select
                value={adjustmentType}
                onChange={(e) => setAdjustmentType(e.target.value as AdjustmentType)}
                className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {ADJUSTMENT_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Amount (USD) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3.5 py-2 text-xs font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Justification & Approval Reference <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Approved 50% tuition merit concession by Academic Dean Ref #ADM-2026-M4"
              className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              disabled={isSubmitting}
              className="bg-[#1e3a8a] text-white cursor-pointer"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Adjustment Request'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
