import React, { useState } from 'react';
import {
  ArrowRightLeft,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Plus,
  ShieldAlert,
  AlertCircle,
  DollarSign,
  Download,
  Clock,
  RotateCcw,
  Check,
  X,
} from 'lucide-react';
import {
  AdjustmentStatus,
  AdjustmentType,
  FeeAdjustmentRecord,
  FeeInvoiceRecord,
  PaymentRecord as DbPaymentRecord,
} from '../../types/database';
import { PaymentRecordItem } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { FeeAdjustmentModal } from './FeeAdjustmentModal';

interface RefundsAdjustmentsViewProps {
  adjustments: FeeAdjustmentRecord[];
  payments: PaymentRecordItem[];
  invoices: FeeInvoiceRecord[];
  currentUserId?: string;
  onRequestAdjustment: (data: {
    invoice_id: string;
    adjustment_type: AdjustmentType;
    amount: number;
    reason: string;
  }) => Promise<any>;
  onApproveAdjustment: (adjustmentId: string, notes?: string) => Promise<any>;
  onRejectAdjustment: (adjustmentId: string, reason: string) => Promise<any>;
}

export function RefundsAdjustmentsView({
  adjustments,
  payments,
  invoices,
  currentUserId,
  onRequestAdjustment,
  onApproveAdjustment,
  onRejectAdjustment,
}: RefundsAdjustmentsViewProps) {
  const [activeTab, setActiveTab] = useState<'adjustments' | 'refunds-reversals'>('adjustments');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Approval/Rejection action state
  const [actionModal, setActionModal] = useState<{
    isOpen: boolean;
    adjustmentId: string;
    type: 'approve' | 'reject';
    reason: string;
    isSubmitting: boolean;
    error: string | null;
  }>({
    isOpen: false,
    adjustmentId: '',
    type: 'approve',
    reason: '',
    isSubmitting: false,
    error: null,
  });

  // Filtered adjustments
  const filteredAdjustments = adjustments.filter((a) => {
    const matchesSearch =
      a.adjustment_id.toLowerCase().includes(search.toLowerCase()) ||
      a.invoice_id.toLowerCase().includes(search.toLowerCase()) ||
      a.registration_number.toLowerCase().includes(search.toLowerCase()) ||
      a.reason.toLowerCase().includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'pending'
        ? a.status === AdjustmentStatus.PENDING_APPROVAL
        : statusFilter === 'approved'
        ? a.status === AdjustmentStatus.APPROVED
        : a.status === AdjustmentStatus.REJECTED;

    return matchesSearch && matchesStatus;
  });

  // Voided or refunded payments
  const voidedPayments = payments.filter((p) => p.isVoided);

  const totalApprovedAdjustments = adjustments
    .filter((a) => a.status === AdjustmentStatus.APPROVED)
    .reduce((sum, a) => sum + a.amount, 0);

  const pendingAdjustmentsCount = adjustments.filter(
    (a) => a.status === AdjustmentStatus.PENDING_APPROVAL
  ).length;

  const totalReversalsAmount = voidedPayments.reduce((sum, p) => sum + p.amountPaid, 0);

  const handleConfirmAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionModal((prev) => ({ ...prev, isSubmitting: true, error: null }));
    try {
      if (actionModal.type === 'approve') {
        await onApproveAdjustment(actionModal.adjustmentId, actionModal.reason.trim() || undefined);
      } else {
        if (!actionModal.reason.trim()) {
          setActionModal((prev) => ({ ...prev, isSubmitting: false, error: 'Rejection reason is required.' }));
          return;
        }
        await onRejectAdjustment(actionModal.adjustmentId, actionModal.reason.trim());
      }
      setActionModal({ isOpen: false, adjustmentId: '', type: 'approve', reason: '', isSubmitting: false, error: null });
    } catch (err: any) {
      setActionModal((prev) => ({ ...prev, isSubmitting: false, error: err.message || 'Operation failed.' }));
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'Adjustment ID',
      'Invoice ID',
      'Student Registration Number',
      'Adjustment Type',
      'Amount ($)',
      'Reason',
      'Requested By',
      'Status',
      'Approved / Reviewed By',
    ];

    const rows = filteredAdjustments.map((a) => [
      a.adjustment_id,
      a.invoice_id,
      a.registration_number,
      a.adjustment_type,
      a.amount.toFixed(2),
      a.reason,
      a.requested_by,
      a.status,
      a.approved_by || 'Pending',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Fee_Adjustments_Registry_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Refunds, Reversals & Fee Adjustments</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative financial governance for billing corrections, concessions, refunds, and separation-of-duties approvals.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Adjustments CSV
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsModalOpen(true)}
            leftIcon={<Plus className="w-4 h-4" />}
            className="text-xs bg-[#1e3a8a] text-white hover:bg-[#172554] cursor-pointer"
          >
            Request Adjustment
          </Button>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
            Approved Adjustments Total
          </span>
          <span className="text-xl font-mono font-black text-emerald-800">${totalApprovedAdjustments.toFixed(2)}</span>
          <span className="text-[10px] text-slate-500 block mt-1">Applied against invoices</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 block mb-1">
            Pending Officer Review
          </span>
          <span className="text-xl font-mono font-black text-amber-800">{pendingAdjustmentsCount}</span>
          <span className="text-[10px] text-amber-700 font-semibold block mt-1">Requires dual authorization</span>
        </div>

        <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 block mb-1">
            Voided / Refunded Total
          </span>
          <span className="text-xl font-mono font-black text-red-800">${totalReversalsAmount.toFixed(2)}</span>
          <span className="text-[10px] text-red-700 block mt-1">{voidedPayments.length} transaction voucher(s)</span>
        </div>
      </div>

      {/* Inner Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#e2e8f0] pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('adjustments')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'adjustments'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-slate-100 hover:text-[#1e293b]'
          }`}
        >
          Fee Adjustments & Waivers ({adjustments.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('refunds-reversals')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'refunds-reversals'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-slate-100 hover:text-[#1e293b]'
          }`}
        >
          Payment Voids & Refunds Log ({voidedPayments.length})
        </button>
      </div>

      {/* TAB 1: FEE ADJUSTMENTS */}
      {activeTab === 'adjustments' && (
        <div className="space-y-4">
          <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by ID, invoice, or registration number..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>

            <div className="flex items-center gap-2.5">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
              >
                <option value="all">All Adjustments</option>
                <option value="pending">Pending Approval</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="py-3 px-4">Adjustment ID</th>
                    <th className="py-3 px-4">Invoice #</th>
                    <th className="py-3 px-4">Student Reg #</th>
                    <th className="py-3 px-4">Adjustment Type</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4">Justification</th>
                    <th className="py-3 px-4">Requested By</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {filteredAdjustments.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-[#64748b]">
                        No adjustments found matching current filter query.
                      </td>
                    </tr>
                  ) : (
                    filteredAdjustments.map((a) => {
                      const isPending = a.status === AdjustmentStatus.PENDING_APPROVAL;
                      const isSelf = currentUserId && a.requested_by.toLowerCase() === currentUserId.toLowerCase();
                      return (
                        <tr key={a.adjustment_id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">{a.adjustment_id}</td>
                          <td className="py-3 px-4 font-mono text-slate-700">{a.invoice_id}</td>
                          <td className="py-3 px-4 font-mono font-semibold text-[#1e293b]">
                            {a.registration_number}
                          </td>
                          <td className="py-3 px-4">
                            <Badge variant="blue" size="sm">
                              {a.adjustment_type}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                            ${a.amount.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 max-w-xs text-slate-700 truncate" title={a.reason}>
                            {a.reason}
                          </td>
                          <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">{a.requested_by}</td>
                          <td className="py-3 px-4 text-center">
                            <Badge
                              variant={
                                a.status === AdjustmentStatus.APPROVED
                                  ? 'emerald'
                                  : a.status === AdjustmentStatus.PENDING_APPROVAL
                                  ? 'amber'
                                  : 'rose'
                              }
                              size="sm"
                            >
                              {a.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-right">
                            {isPending ? (
                              <div className="flex items-center justify-end gap-1.5">
                                <Button
                                  variant="primary"
                                  size="sm"
                                  onClick={() =>
                                    setActionModal({
                                      isOpen: true,
                                      adjustmentId: a.adjustment_id,
                                      type: 'approve',
                                      reason: '',
                                      isSubmitting: false,
                                      error: isSelf
                                        ? 'Separation of Duties Notice: Another authorized officer must approve your request.'
                                        : null,
                                    })
                                  }
                                  className="text-[11px] bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
                                >
                                  Approve
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() =>
                                    setActionModal({
                                      isOpen: true,
                                      adjustmentId: a.adjustment_id,
                                      type: 'reject',
                                      reason: '',
                                      isSubmitting: false,
                                      error: null,
                                    })
                                  }
                                  className="text-[11px] text-red-600 hover:bg-red-50 cursor-pointer"
                                >
                                  Reject
                                </Button>
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-400">
                                {a.approved_by ? `By ${a.approved_by}` : 'Closed'}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: VOIDS & REFUNDS LOG */}
      {activeTab === 'refunds-reversals' && (
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e2e8f0]">
            <h3 className="text-sm font-bold text-[#1e293b]">Payment Voids & Refunds Register</h3>
            <p className="text-xs text-[#64748b]">Audit log of reversed and refunded fee collections.</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-3 px-4">Payment ID</th>
                  <th className="py-3 px-4">Receipt #</th>
                  <th className="py-3 px-4">Student Reg #</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Particulars</th>
                  <th className="py-3 px-4 text-right">Amount ($)</th>
                  <th className="py-3 px-4">Mode</th>
                  <th className="py-3 px-4">Audit Reason</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {voidedPayments.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="py-8 text-center text-[#64748b]">
                      No voided or refunded payments in current registry.
                    </td>
                  </tr>
                ) : (
                  voidedPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-red-700">{p.id}</td>
                      <td className="py-3 px-4 font-mono text-slate-700">{p.receiptNumber}</td>
                      <td className="py-3 px-4 font-mono font-semibold">{p.studentRegistrationNumber}</td>
                      <td className="py-3 px-4 font-bold text-[#1e293b]">{p.studentName || 'Student'}</td>
                      <td className="py-3 px-4">{p.feeTypeName}</td>
                      <td className="py-3 px-4 text-right font-mono font-black text-sm text-red-700">
                        ${p.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">{p.paymentMode}</td>
                      <td className="py-3 px-4 text-slate-700 max-w-xs truncate" title={p.voidReason || p.notes}>
                        {p.voidReason || p.notes || 'Transaction voided'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <Badge variant="rose" size="sm">
                          VOIDED
                        </Badge>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Approval / Rejection Modal */}
      {actionModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-2.5 font-bold">
              {actionModal.type === 'approve' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-700" />
              ) : (
                <XCircle className="w-5 h-5 text-red-600" />
              )}
              <span className="capitalize">{actionModal.type} Adjustment Request</span>
            </div>

            {actionModal.error && (
              <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                {actionModal.error}
              </div>
            )}

            <p className="text-xs text-slate-600">
              Target Record: <span className="font-mono font-bold text-slate-900">{actionModal.adjustmentId}</span>
            </p>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {actionModal.type === 'approve' ? 'Approval Resolution / Notes' : 'Rejection Reason (Required)'}
              </label>
              <textarea
                rows={2}
                required={actionModal.type === 'reject'}
                value={actionModal.reason}
                onChange={(e) => setActionModal((p) => ({ ...p, reason: e.target.value }))}
                placeholder={actionModal.type === 'approve' ? 'Approved as per institutional regulations' : 'e.g. Ineligible under quota rules'}
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setActionModal((p) => ({ ...p, isOpen: false }))}
              >
                Cancel
              </Button>
              <Button
                variant={actionModal.type === 'approve' ? 'primary' : 'danger'}
                size="sm"
                disabled={actionModal.isSubmitting}
                onClick={handleConfirmAction}
                className="cursor-pointer"
              >
                {actionModal.isSubmitting
                  ? 'Processing...'
                  : actionModal.type === 'approve'
                  ? 'Confirm Approve'
                  : 'Confirm Reject'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Request Adjustment Modal */}
      <FeeAdjustmentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        invoices={invoices}
        onRequestAdjustment={onRequestAdjustment}
      />
    </div>
  );
}
