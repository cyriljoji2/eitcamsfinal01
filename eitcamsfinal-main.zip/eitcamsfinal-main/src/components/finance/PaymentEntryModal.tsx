import React, { useState, useEffect, useMemo } from 'react';
import {
  CreditCard,
  X,
  Search,
  CheckCircle2,
  AlertCircle,
  DollarSign,
  Calendar,
  FileText,
  User,
  Info,
} from 'lucide-react';
import { StudentRecord } from '../../types/database';
import { FeeAssignment, FeeReceipt, PaymentMode, PaymentRecordItem } from '../../types/finance';
import { Button } from '../ui/Button';

interface PaymentEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: StudentRecord[];
  assignments: FeeAssignment[];
  initialStudentRegNo?: string;
  initialAssignmentId?: string;
  currentUserFullName?: string;
  onSubmitPayment: (data: {
    studentRegistrationNumber: string;
    feeAssignmentId?: string;
    feeTypeName: string;
    amountPaid: number;
    paymentDate: string;
    paymentMode: PaymentMode;
    transactionReference?: string;
    remarks?: string;
    receivedBy: string;
  }) => Promise<{ payment: PaymentRecordItem; receipt: FeeReceipt }>;
  onPaymentSuccess?: (receipt: FeeReceipt) => void;
}

const PAYMENT_MODES: PaymentMode[] = [
  'Cash',
  'Bank Transfer',
  'Credit Card',
  'Debit Card',
  'Online Gateway',
  'Demand Draft',
  'Cheque',
  'UPI',
];

export function PaymentEntryModal({
  isOpen,
  onClose,
  students,
  assignments,
  initialStudentRegNo,
  initialAssignmentId,
  currentUserFullName = 'Finance Officer',
  onSubmitPayment,
  onPaymentSuccess,
}: PaymentEntryModalProps) {
  const [selectedRegNo, setSelectedRegNo] = useState<string>('');
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string>('');
  const [feeTypeName, setFeeTypeName] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('Bank Transfer');
  const [transactionRef, setTransactionRef] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [receivedBy, setReceivedBy] = useState<string>(currentUserFullName);

  const [studentSearch, setStudentSearch] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
      setIsSubmitting(false);
      setPaymentDate(new Date().toISOString().split('T')[0]);

      if (initialStudentRegNo) {
        setSelectedRegNo(initialStudentRegNo);
      } else if (students.length > 0) {
        setSelectedRegNo(students[0].registration_number);
      }

      if (initialAssignmentId) {
        setSelectedAssignmentId(initialAssignmentId);
        const match = assignments.find((a) => a.id === initialAssignmentId);
        if (match) {
          setFeeTypeName(match.feeTypeName);
          setAmountPaid(String(match.balanceDue || match.balance || 0));
        }
      } else {
        setSelectedAssignmentId('');
        setAmountPaid('');
        setFeeTypeName('');
      }

      // Auto-populate transaction reference recommendation
      setTransactionRef(`TXN-EIT-${Date.now().toString().slice(-6)}`);
    }
  }, [isOpen, initialStudentRegNo, initialAssignmentId, students, assignments]);

  const studentInvoices = useMemo(() => {
    return assignments.filter(
      (a) => a.studentRegistrationNumber.toLowerCase() === selectedRegNo.toLowerCase()
    );
  }, [assignments, selectedRegNo]);

  const selectedStudent = useMemo(() => {
    return students.find(
      (s) => s.registration_number.toLowerCase() === selectedRegNo.toLowerCase()
    );
  }, [students, selectedRegNo]);

  const activeInvoice = useMemo(() => {
    return studentInvoices.find((a) => a.id === selectedAssignmentId);
  }, [studentInvoices, selectedAssignmentId]);

  const totalOutstanding = useMemo(() => {
    return studentInvoices.reduce((sum, a) => sum + (a.balanceDue || a.balance || 0), 0);
  }, [studentInvoices]);

  const filteredStudents = useMemo(() => {
    if (!studentSearch.trim()) return students;
    const q = studentSearch.toLowerCase();
    return students.filter(
      (s) =>
        s.registration_number.toLowerCase().includes(q) ||
        `${s.first_name} ${s.last_name}`.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q)
    );
  }, [students, studentSearch]);

  if (!isOpen) return null;

  const handleInvoiceChange = (invId: string) => {
    setSelectedAssignmentId(invId);
    if (!invId) {
      setFeeTypeName('Consolidated Dues Clearance');
      setAmountPaid(totalOutstanding > 0 ? String(totalOutstanding) : '');
      return;
    }
    const inv = studentInvoices.find((a) => a.id === invId);
    if (inv) {
      setFeeTypeName(inv.feeTypeName);
      setAmountPaid(String(inv.balanceDue || inv.balance || 0));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!selectedRegNo) {
      setErrorMessage('Please select a student.');
      return;
    }

    const parsedAmount = parseFloat(amountPaid);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setErrorMessage('Please enter a valid positive payment amount.');
      return;
    }

    if (!transactionRef.trim()) {
      setErrorMessage('Unique transaction reference or bank voucher ID is required.');
      return;
    }

    if (activeInvoice && parsedAmount > (activeInvoice.balanceDue || activeInvoice.balance || 0)) {
      setErrorMessage(
        `Payment amount ($${parsedAmount}) exceeds invoice balance of $${
          activeInvoice.balanceDue || activeInvoice.balance
        }. Overpayments must be adjusted via finance administration.`
      );
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await onSubmitPayment({
        studentRegistrationNumber: selectedRegNo,
        feeAssignmentId: selectedAssignmentId || undefined,
        feeTypeName: feeTypeName || activeInvoice?.feeTypeName || 'Tuition & University Fees',
        amountPaid: parsedAmount,
        paymentDate,
        paymentMode,
        transactionReference: transactionRef.trim(),
        remarks: remarks.trim() || undefined,
        receivedBy: receivedBy.trim() || currentUserFullName,
      });

      if (onPaymentSuccess && result.receipt) {
        onPaymentSuccess(result.receipt);
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to record payment transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        <div className="p-5 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center shadow-xs">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">Record Fee Collection</h3>
              <p className="text-xs text-[#64748b]">Post verified payment voucher to institutional ledger.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Student Selection */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Select Student Candidate <span className="text-red-500">*</span>
            </label>
            <div className="space-y-1.5">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter student by name or registration number..."
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
              </div>
              <select
                required
                value={selectedRegNo}
                onChange={(e) => {
                  setSelectedRegNo(e.target.value);
                  setSelectedAssignmentId('');
                  setAmountPaid('');
                }}
                className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {filteredStudents.map((s) => (
                  <option key={s.student_id} value={s.registration_number}>
                    {s.registration_number} — {s.first_name} {s.last_name} ({s.department} Sem {s.current_semester})
                  </option>
                ))}
              </select>
            </div>
            {selectedStudent && (
              <div className="mt-2 p-2.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-center justify-between">
                <div>
                  <span className="font-bold">{selectedStudent.first_name} {selectedStudent.last_name}</span> &bull; {selectedStudent.program_name} (Section {selectedStudent.section})
                </div>
                <div className="font-mono font-bold text-slate-800">
                  Total Dues: <span className="text-red-700">${totalOutstanding.toFixed(2)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Target Invoice */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Target Invoice / Fee Head
            </label>
            <select
              value={selectedAssignmentId}
              onChange={(e) => handleInvoiceChange(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            >
              <option value="">Auto-Apply to Earliest Outstanding Dues</option>
              {studentInvoices.map((inv) => (
                <option key={inv.id} value={inv.id}>
                  {inv.id} — {inv.feeTypeName} (Due: ${Number(inv.balanceDue || inv.balance || 0).toFixed(2)})
                </option>
              ))}
            </select>
          </div>

          {/* Payment Amount & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Amount Paid (USD) <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3.5 py-2 text-sm font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Payment Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>
          </div>

          {/* Payment Mode & Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Payment Mode <span className="text-red-500">*</span>
              </label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                className="w-full px-3.5 py-2 text-sm bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {PAYMENT_MODES.map((mode) => (
                  <option key={mode} value={mode}>
                    {mode}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Transaction Reference / Voucher ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                placeholder="e.g. UTR-982348123 / CHQ-10492"
                className="w-full px-3.5 py-2 text-sm font-mono bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Transaction Remarks / Audit Notes
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Cleared via HDFC Bank NEFT / Term 3 tuition"
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              disabled={isSubmitting}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
              className="bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
            >
              {isSubmitting ? 'Recording...' : 'Post & Generate Official Receipt'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
