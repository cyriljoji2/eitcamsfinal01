import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Layers, 
  Users, 
  CreditCard, 
  BarChart3, 
  RefreshCw 
} from 'lucide-react';
import { 
  FeeStructureItem, 
  FeeInvoiceRecord, 
  PaymentRecordItem, 
  FeeReceipt, 
  FeeAdjustmentRecord, 
  StudentFeeSummary, 
  FinanceTab, 
  HostelChargeRequestRecord, 
  StudentRecord, 
  AuditLogEntry, 
  UserSession,
  FeeAssignment,
  AdjustmentType
} from '../../types';
import type { FinanceDashboardMetrics } from '../../types/finance';
import { financeRepository } from '../../services/financeService';
import { devDataAdapter } from '../../services/devDataAdapter';
import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { FinanceHeader } from './FinanceHeader';

// 12 Destination Views
import { FinanceOverview } from './FinanceOverview';
import { FeeStructureView } from './FeeStructureView';
import { FeeAssignmentsView } from './FeeAssignmentsView';
import { StudentFeeAccountsView } from './StudentFeeAccountsView';
import { PaymentsView } from './PaymentsView';
import { ReceiptsView } from './ReceiptsView';
import { OutstandingFeesView } from './OutstandingFeesView';
import { RefundsAdjustmentsView } from './RefundsAdjustmentsView';
import { ScholarshipsConcessionsView } from './ScholarshipsConcessionsView';
import { HostelFeeManagementView } from './HostelFeeManagementView';
import { FinancialReportsView } from './FinancialReportsView';
import { AuditSettingsView } from './AuditSettingsView';

// Modals
import { PaymentEntryModal } from './PaymentEntryModal';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { StudentFeeProfileModal } from './StudentFeeProfileModal';
import { VoidPaymentModal } from './VoidPaymentModal';
import { RefundPaymentModal } from './RefundPaymentModal';
import { FeeStructureModal } from './FeeStructureModal';
import { FeeAdjustmentModal } from './FeeAdjustmentModal';
import { AwardScholarshipModal } from './AwardScholarshipModal';

interface FinanceWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
  onNavigateToAdmin?: () => void;
  onRefreshData?: () => Promise<void>;
}

export function FinanceWorkspace({
  user,
  onLogout,
  onRefreshData
}: FinanceWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<FinanceTab>('overview');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Authoritative Core Datasets
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [feeStructures, setFeeStructures] = useState<FeeStructureItem[]>([]);
  const [invoices, setInvoices] = useState<FeeInvoiceRecord[]>([]);
  const [assignments, setAssignments] = useState<FeeAssignment[]>([]);
  const [payments, setPayments] = useState<PaymentRecordItem[]>([]);
  const [receipts, setReceipts] = useState<FeeReceipt[]>([]);
  const [adjustments, setAdjustments] = useState<FeeAdjustmentRecord[]>([]);
  const [hostelCharges, setHostelCharges] = useState<HostelChargeRequestRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [summaries, setSummaries] = useState<StudentFeeSummary[]>([]);
  const [metrics, setMetrics] = useState<FinanceDashboardMetrics>({
    totalFeesAssigned: 0,
    totalAmountCollected: 0,
    totalOutstanding: 0,
    totalWaived: 0,
    studentsWithOutstandingCount: 0,
    totalStudentsAssignedCount: 0,
    todayCollection: 0,
    recentPayments: [],
    recentReceipts: [],
    categoryCollectionBreakdown: [],
    paymentModeBreakdown: [],
  });

  // Modal State Controls
  const [paymentModalState, setPaymentModalState] = useState<{
    isOpen: boolean;
    studentId?: string;
    invoiceId?: string;
  }>({ isOpen: false });

  const [receiptModalState, setReceiptModalState] = useState<{
    isOpen: boolean;
    receipt: FeeReceipt | null;
  }>({ isOpen: false, receipt: null });

  const [studentProfileModalState, setStudentProfileModalState] = useState<{
    isOpen: boolean;
    summary: StudentFeeSummary | null;
  }>({ isOpen: false, summary: null });

  const [voidModalState, setVoidModalState] = useState<{
    isOpen: boolean;
    payment: PaymentRecordItem | null;
  }>({ isOpen: false, payment: null });

  const [refundModalState, setRefundModalState] = useState<{
    isOpen: boolean;
    payment: PaymentRecordItem | null;
  }>({ isOpen: false, payment: null });

  const [feeStructureModalState, setFeeStructureModalState] = useState<{
    isOpen: boolean;
    item: FeeStructureItem | null;
  }>({ isOpen: false, item: null });

  const [adjustmentModalState, setAdjustmentModalState] = useState<{
    isOpen: boolean;
    invoice?: FeeInvoiceRecord;
  }>({ isOpen: false });

  const [awardScholarshipModalState, setAwardScholarshipModalState] = useState<{
    isOpen: boolean;
    studentId?: string;
  }>({ isOpen: false });

  const [preselectedFeeStructureId, setPreselectedFeeStructureId] = useState<string | undefined>(undefined);

  // Authoritative Data Fetch
  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [
        loadedStudents,
        loadedStructures,
        loadedInvoices,
        loadedAssignments,
        loadedPayments,
        loadedReceipts,
        loadedAdjustments,
        loadedHostelCharges,
        loadedAuditLogs,
        loadedSummaries,
        loadedMetrics
      ] = await Promise.all([
        devDataAdapter.students.getAll(),
        financeRepository.getFeeStructures(),
        financeRepository.getInvoices(),
        financeRepository.getFeeAssignments(),
        financeRepository.getPayments(),
        financeRepository.getReceipts(),
        financeRepository.getAdjustments(),
        financeRepository.getHostelChargeRequests(),
        financeRepository.getAuditLogs(),
        financeRepository.getAllStudentSummaries(),
        financeRepository.getDashboardMetrics()
      ]);

      setStudents(loadedStudents);
      setFeeStructures(loadedStructures);
      setInvoices(loadedInvoices);
      setAssignments(loadedAssignments);
      setPayments(loadedPayments);
      setReceipts(loadedReceipts);
      setAdjustments(loadedAdjustments);
      setHostelCharges(loadedHostelCharges);
      setAuditLogs(loadedAuditLogs);
      setSummaries(loadedSummaries);
      setMetrics(loadedMetrics);

      // Keep student profile modal refreshed if open
      if (studentProfileModalState.isOpen && studentProfileModalState.summary) {
        const updated = loadedSummaries.find(
          s => s.studentRegistrationNumber.toLowerCase() === studentProfileModalState.summary?.studentRegistrationNumber.toLowerCase()
        );
        if (updated) {
          setStudentProfileModalState(prev => ({ ...prev, summary: updated }));
        }
      }
    } catch (err) {
      console.error('Failed to load authoritative finance workspace data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [studentProfileModalState.isOpen, studentProfileModalState.summary]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Sidebar Items Definition (12 destinations partitioned into 5 accordion groups)
  const sidebarItems: PortalSidebarItem[] = useMemo(() => [
    {
      id: 'overview',
      label: 'Finance Overview',
      icon: LayoutDashboard,
    },
    {
      id: 'fee-governance',
      label: 'Fee Governance',
      icon: Layers,
      subItems: [
        { id: 'structure', label: 'Fee Structures' },
        { id: 'assignments', label: 'Fee Assignments' },
        { 
          id: 'hostel-fees', 
          label: 'Hostel Fee Demands',
          badge: hostelCharges.filter(c => c.status === 'REQUESTED').length || undefined,
          badgeVariant: 'amber'
        },
      ]
    },
    {
      id: 'student-accounts',
      label: 'Student Accounts',
      icon: Users,
      subItems: [
        { id: 'student-fees', label: 'Student Fee Accounts' },
        { 
          id: 'outstanding', 
          label: 'Outstanding Fees',
          badge: metrics.studentsWithOutstandingCount || undefined,
          badgeVariant: 'amber'
        },
      ]
    },
    {
      id: 'collections-adjustments',
      label: 'Collections & Relief',
      icon: CreditCard,
      subItems: [
        { id: 'payments', label: 'Payments' },
        { id: 'receipts', label: 'Receipts' },
        { 
          id: 'refunds-adjustments', 
          label: 'Refunds & Adjustments',
          badge: adjustments.filter(a => a.status === 'PENDING_APPROVAL').length || undefined,
          badgeVariant: 'amber'
        },
        { id: 'scholarships', label: 'Scholarships & Concessions' },
      ]
    },
    {
      id: 'analytics-governance',
      label: 'Reports & Governance',
      icon: BarChart3,
      subItems: [
        { id: 'reports', label: 'Financial Reports' },
        { id: 'audit-settings', label: 'Audit & Settings' },
      ]
    }
  ], [hostelCharges, metrics.studentsWithOutstandingCount, adjustments]);

  // Action Handlers
  const handleRecordPayment = async (data: any) => {
    const result = await financeRepository.recordPayment(data);
    await loadData();
    if (onRefreshData) await onRefreshData();
    return result;
  };

  const handleVoidPayment = async (paymentId: string, reason: string, voidedBy: string) => {
    await financeRepository.voidPayment(paymentId, reason, voidedBy);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleRefundPayment = async (payment: PaymentRecordItem, amount: number, reason: string) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    await devDataAdapter.finance.refundPayment(payment.id, amount, reason, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleWaiveFee = async (assignmentId: string, amount: number, reason: string) => {
    await financeRepository.waiveFee(assignmentId, amount, reason, user.name || 'Finance Officer');
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleSaveFeeStructure = async (structureData: Omit<FeeStructureItem, 'id'>) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    const sanitizedData = {
      ...structureData,
      status: (structureData.status?.toUpperCase() === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE') as 'ACTIVE' | 'INACTIVE',
    };
    if (feeStructureModalState.item) {
      await financeRepository.updateFeeStructure(feeStructureModalState.item.id, sanitizedData, actor);
    } else {
      await financeRepository.createFeeStructure(sanitizedData, actor);
    }
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleUpdateFeeStructure = async (id: string, data: Partial<FeeStructureItem>) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    const { status, ...rest } = data;
    const sanitizedData: Partial<any> = {
      ...rest,
      ...(status ? { status: status.toUpperCase() === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE' } : {})
    };
    await financeRepository.updateFeeStructure(id, sanitizedData, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleToggleStructureStatus = async (id: string) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    await financeRepository.toggleFeeStructureStatus(id, actor);
    await loadData();
  };

  const handleDeleteStructure = async (id: string) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    await financeRepository.deleteFeeStructure(id, actor);
    await loadData();
  };

  const handleAssignToProgramme = async (params: {
    feeStructureId: string;
    programmeCode: string;
    semester: number;
    academicYear?: string;
    dueDate?: string;
    remarks?: string;
  }) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    const res = await financeRepository.assignToProgramme(params, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
    return { count: res.created.length, skippedCount: res.skippedCount };
  };

  const handleAssignToStudent = async (params: {
    feeStructureId: string;
    studentRegistrationNumber: string;
    customAmount?: number;
    discountOrWaiver?: number;
    waiverReason?: string;
    dueDate?: string;
    remarks?: string;
  }) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    const res = await financeRepository.assignToStudent(
      {
        feeStructureId: params.feeStructureId,
        studentRegistrationNumber: params.studentRegistrationNumber,
        customAmount: params.customAmount,
        discountOrWaiver: params.discountOrWaiver,
        waiverReason: params.waiverReason,
        dueDate: params.dueDate,
        remarks: params.remarks,
      },
      actor
    );
    await loadData();
    if (onRefreshData) await onRefreshData();
    return res;
  };

  const handleCancelInvoice = async (invoiceId: string, reason: string) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    await financeRepository.cancelInvoice(invoiceId, reason, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleApproveAdjustment = async (id: string, notes?: string) => {
    const actor = {
      userId: 'FIN-AUDITOR',
      role: 'OFFICE_ADMIN',
      employeeId: 'EMP-FIN-002'
    };
    await devDataAdapter.finance.approveAdjustment(id, actor, notes);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleRejectAdjustment = async (id: string, reason: string) => {
    const actor = {
      userId: 'FIN-AUDITOR',
      role: 'OFFICE_ADMIN',
      employeeId: 'EMP-FIN-002'
    };
    await devDataAdapter.finance.rejectAdjustment(id, reason, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  const handleIssueHostelInvoice = async (chargeId: string, _dueDate: string) => {
    const actor = {
      userId: user.id || 'finance',
      role: user.role || 'OFFICE_ADMIN',
      employeeId: user.employeeId || 'FIN-001'
    };
    await financeRepository.issueInvoiceForHostelCharge(chargeId, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col font-sans">
      {/* Finance Header */}
      <FinanceHeader
        user={user}
        onLogout={onLogout}
        onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
        onToggleMobileMenu={() => setIsMobileSidebarOpen(prev => !prev)}
        isMobileMenuOpen={isMobileSidebarOpen}
      />

      {/* Main Layout Area */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Universal Expandable Sidebar */}
          <PortalSidebar
            items={sidebarItems}
            activeTab={activeTab}
            onSelectTab={(tab) => {
              setActiveTab(tab as FinanceTab);
              setIsMobileSidebarOpen(false);
            }}
            isOpenMobile={isMobileSidebarOpen}
            idPrefix="finance-nav"
            headerSlot={
              <div className="px-3 py-2 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Institutional Portals
              </div>
            }
          />

          {/* Primary View Port */}
          <main className="flex-1 min-w-0">
            {isLoading ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-xs">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-3" />
                <p className="text-slate-600 font-medium">Reconciling institutional financial ledger...</p>
                <p className="text-xs text-slate-400 mt-1">Fetching fee structures, receipts, and student accounts</p>
              </div>
            ) : (
              <>
                {/* 1. Overview */}
                {activeTab === 'overview' && (
                  <FinanceOverview
                    metrics={metrics}
                    recentPayments={payments.slice(0, 5)}
                    receipts={receipts.slice(0, 5)}
                    onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
                    onOpenFeeStructureModal={() => setFeeStructureModalState({ isOpen: true, item: null })}
                    onNavigateTab={(tab) => setActiveTab(tab)}
                    onOpenReceiptModal={(receipt) => setReceiptModalState({ isOpen: true, receipt })}
                    onViewStudentProfile={(studentRegNo) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 2. Fee Structures */}
                {activeTab === 'structure' && (
                  <FeeStructureView
                    feeStructures={feeStructures}
                    onCreateFeeStructure={handleSaveFeeStructure}
                    onUpdateFeeStructure={handleUpdateFeeStructure}
                    onToggleStatus={handleToggleStructureStatus}
                    onDeleteFeeStructure={handleDeleteStructure}
                    onNavigateToAssign={(structureId) => {
                      setPreselectedFeeStructureId(structureId);
                      setActiveTab('assignments');
                    }}
                  />
                )}

                {/* 3. Fee Assignments */}
                {activeTab === 'assignments' && (
                  <FeeAssignmentsView
                    students={students}
                    feeStructures={feeStructures}
                    assignments={assignments}
                    initialPreselectedFeeId={preselectedFeeStructureId}
                    onAssignFeeToProgramme={handleAssignToProgramme}
                    onAssignFeeToStudent={handleAssignToStudent}
                    onCancelInvoice={handleCancelInvoice}
                    onOpenPaymentModal={(studentRegNo, feeAssignmentId) => setPaymentModalState({ isOpen: true, studentId: studentRegNo, invoiceId: feeAssignmentId })}
                    onViewStudentProfile={(studentRegNo) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 4. Student Fee Accounts */}
                {activeTab === 'student-fees' && (
                  <StudentFeeAccountsView
                    summaries={summaries}
                    onOpenPaymentModal={(studentRegNo: string) => setPaymentModalState({ isOpen: true, studentId: studentRegNo })}
                    onViewStudentProfile={(studentRegNo: string) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 5. Payments */}
                {activeTab === 'payments' && (
                  <PaymentsView
                    payments={payments}
                    receipts={receipts}
                    onOpenPaymentEntry={() => setPaymentModalState({ isOpen: true })}
                    onOpenReceiptModal={(receipt: FeeReceipt) => setReceiptModalState({ isOpen: true, receipt })}
                    onOpenVoidModal={(payment: PaymentRecordItem) => setVoidModalState({ isOpen: true, payment })}
                    onOpenRefundModal={(payment: PaymentRecordItem) => setRefundModalState({ isOpen: true, payment })}
                    onViewStudentProfile={(studentRegNo: string) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 6. Receipts */}
                {activeTab === 'receipts' && (
                  <ReceiptsView
                    receipts={receipts}
                    onOpenReceiptModal={(receipt: FeeReceipt) => setReceiptModalState({ isOpen: true, receipt })}
                    onViewStudentProfile={(studentRegNo: string) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 7. Outstanding Fees */}
                {activeTab === 'outstanding' && (
                  <OutstandingFeesView
                    assignments={assignments}
                    onOpenPaymentModal={(studentRegNo: string, feeAssignmentId?: string) =>
                      setPaymentModalState({ isOpen: true, studentId: studentRegNo, invoiceId: feeAssignmentId })
                    }
                    onViewStudentProfile={(studentRegNo: string) => {
                      const summary = summaries.find(s => s.studentRegistrationNumber === studentRegNo);
                      setStudentProfileModalState({ isOpen: true, summary: summary || null });
                    }}
                  />
                )}

                {/* 8. Refunds & Adjustments */}
                {activeTab === 'refunds-adjustments' && (
                  <RefundsAdjustmentsView
                    adjustments={adjustments}
                    payments={payments}
                    invoices={invoices}
                    currentUserId={user.id}
                    onRequestAdjustment={async (data) => {
                      const actor = {
                        userId: user.id || 'finance',
                        role: user.role || 'OFFICE_ADMIN',
                        employeeId: user.employeeId || 'FIN-001'
                      };
                      await devDataAdapter.finance.requestAdjustment(data, actor);
                      await loadData();
                    }}
                    onApproveAdjustment={handleApproveAdjustment}
                    onRejectAdjustment={handleRejectAdjustment}
                  />
                )}

                {/* 9. Scholarships & Concessions */}
                {activeTab === 'scholarships' && (
                  <ScholarshipsConcessionsView
                    adjustments={adjustments}
                    students={students}
                    onOpenAwardModal={() => setAwardScholarshipModalState({ isOpen: true })}
                    onRefresh={loadData}
                  />
                )}

                {/* 10. Hostel Fee Demands */}
                {activeTab === 'hostel-fees' && (
                  <HostelFeeManagementView
                    hostelCharges={hostelCharges}
                    students={students}
                    onIssueInvoice={handleIssueHostelInvoice}
                    onRefresh={loadData}
                  />
                )}

                {/* 11. Financial Reports */}
                {activeTab === 'reports' && (
                  <FinancialReportsView
                    invoices={invoices}
                    payments={payments}
                    adjustments={adjustments}
                    students={students}
                    studentSummaries={summaries}
                  />
                )}

                {/* 12. Audit & Settings */}
                {activeTab === 'audit-settings' && (
                  <AuditSettingsView
                    auditLogs={auditLogs}
                    onRefresh={loadData}
                  />
                )}
              </>
            )}
          </main>
        </div>
      </div>

      {/* Modals Container */}
      <PaymentEntryModal
        isOpen={paymentModalState.isOpen}
        onClose={() => setPaymentModalState({ isOpen: false })}
        students={students}
        assignments={assignments}
        initialStudentRegNo={paymentModalState.studentId}
        initialAssignmentId={paymentModalState.invoiceId}
        currentUserFullName={user.name || 'Finance Officer'}
        onSubmitPayment={handleRecordPayment}
        onPaymentSuccess={(receipt) => {
          setReceiptModalState({ isOpen: true, receipt });
        }}
      />

      <ReceiptPreviewModal
        isOpen={receiptModalState.isOpen}
        onClose={() => setReceiptModalState({ isOpen: false, receipt: null })}
        receipt={receiptModalState.receipt}
      />

      <StudentFeeProfileModal
        isOpen={studentProfileModalState.isOpen}
        onClose={() => setStudentProfileModalState({ isOpen: false, summary: null })}
        summary={studentProfileModalState.summary}
        onOpenPaymentModal={(studentRegNo: string, feeAssignmentId?: string) => {
          setStudentProfileModalState({ isOpen: false, summary: null });
          setPaymentModalState({ isOpen: true, studentId: studentRegNo, invoiceId: feeAssignmentId });
        }}
        onOpenReceiptModal={(receipt: FeeReceipt) => {
          setReceiptModalState({ isOpen: true, receipt });
        }}
        onOpenVoidModal={(payment: PaymentRecordItem) => {
          setVoidModalState({ isOpen: true, payment });
        }}
        onWaiveFee={handleWaiveFee}
      />

      <VoidPaymentModal
        isOpen={voidModalState.isOpen}
        onClose={() => setVoidModalState({ isOpen: false, payment: null })}
        payment={voidModalState.payment}
        currentUserName={user.name || 'Finance Officer'}
        onConfirmVoid={handleVoidPayment}
      />

      <RefundPaymentModal
        isOpen={refundModalState.isOpen}
        onClose={() => setRefundModalState({ isOpen: false, payment: null })}
        payment={refundModalState.payment}
        onConfirmRefund={async (paymentId, amount, reason) => {
          if (refundModalState.payment) {
            await handleRefundPayment(refundModalState.payment, amount, reason);
          }
        }}
      />

      <FeeStructureModal
        isOpen={feeStructureModalState.isOpen}
        onClose={() => setFeeStructureModalState({ isOpen: false, item: null })}
        item={feeStructureModalState.item}
        onSubmit={handleSaveFeeStructure}
      />

      <FeeAdjustmentModal
        isOpen={adjustmentModalState.isOpen}
        onClose={() => setAdjustmentModalState({ isOpen: false })}
        invoices={invoices}
        initialInvoiceId={adjustmentModalState.invoice?.invoice_id}
        onRequestAdjustment={async (data) => {
          const actor = {
            userId: user.id || 'finance',
            role: user.role || 'OFFICE_ADMIN',
            employeeId: user.employeeId || 'FIN-001'
          };
          await devDataAdapter.finance.requestAdjustment(data, actor);
          await loadData();
        }}
      />

      <AwardScholarshipModal
        isOpen={awardScholarshipModalState.isOpen}
        onClose={() => setAwardScholarshipModalState({ isOpen: false })}
        students={students}
        invoices={invoices}
        onAwardScholarship={async (data) => {
          const actor = {
            userId: user.id || 'finance',
            role: user.role || 'OFFICE_ADMIN',
            employeeId: user.employeeId || 'FIN-001'
          };
          await devDataAdapter.finance.requestAdjustment(data, actor);
          await loadData();
        }}
      />
    </div>
  );
}
