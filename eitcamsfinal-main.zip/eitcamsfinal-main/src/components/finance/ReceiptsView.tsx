import React, { useState } from 'react';
import {
  Receipt,
  Search,
  Filter,
  Eye,
  Download,
  Calendar,
  CreditCard,
  Printer,
  CheckCircle2,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { FeeReceipt, PaymentMode } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ReceiptsViewProps {
  receipts: FeeReceipt[];
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function ReceiptsView({
  receipts,
  onOpenReceiptModal,
  onViewStudentProfile,
}: ReceiptsViewProps) {
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'voided'>('all');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filteredReceipts = receipts.filter((r) => {
    const matchesSearch =
      r.receiptNumber.toLowerCase().includes(search.toLowerCase()) ||
      r.studentRegistrationNumber.toLowerCase().includes(search.toLowerCase()) ||
      r.studentName.toLowerCase().includes(search.toLowerCase()) ||
      r.feeTypeName.toLowerCase().includes(search.toLowerCase()) ||
      (r.transactionReference && r.transactionReference.toLowerCase().includes(search.toLowerCase()));

    const matchesMode = modeFilter === 'all' || r.paymentMode.toLowerCase() === modeFilter.toLowerCase();
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'valid'
        ? !r.isVoided
        : r.isVoided;

    const matchesStart = !startDate || r.receiptDate >= startDate;
    const matchesEnd = !endDate || r.receiptDate <= endDate;

    return matchesSearch && matchesMode && matchesStatus && matchesStart && matchesEnd;
  });

  const totalReceiptsAmount = filteredReceipts
    .filter((r) => !r.isVoided)
    .reduce((acc, r) => acc + r.amountPaid, 0);

  const handleExportCsv = () => {
    const headers = [
      'Receipt Number',
      'Date',
      'Payment Ref',
      'Student Registration Number',
      'Student Name',
      'Programme',
      'Fee Head',
      'Amount (USD)',
      'Payment Mode',
      'Transaction Ref',
      'Issued By',
      'Status',
    ];

    const rows = filteredReceipts.map((r) => [
      r.receiptNumber,
      r.receiptDate,
      r.paymentId,
      r.studentRegistrationNumber,
      r.studentName,
      r.className,
      r.feeTypeName,
      r.amountPaid.toFixed(2),
      r.paymentMode,
      r.transactionReference || 'N/A',
      r.receivedBy,
      r.isVoided ? 'VOIDED' : 'OFFICIAL VALID',
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Official_Fee_Receipts_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Official Fee Receipts Registry</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Browse, re-issue, and print authentic digitally signed receipts for institutional fee collections.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Receipts CSV
          </Button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by receipt number, student, or fee head..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          <select
            value={modeFilter}
            onChange={(e) => setModeFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Modes</option>
            <option value="Cash">Cash</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Online Gateway">Online Gateway</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
          >
            <option value="all">All Receipts</option>
            <option value="valid">Valid Only</option>
            <option value="voided">Voided Only</option>
          </select>

          <div className="flex items-center gap-1">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none"
              title="Start Date"
            />
            <span className="text-xs text-[#64748b]">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none"
              title="End Date"
            />
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4">Receipt #</th>
                <th className="py-3 px-4">Issue Date</th>
                <th className="py-3 px-4">Student Candidate</th>
                <th className="py-3 px-4">Degree Programme</th>
                <th className="py-3 px-4">Particulars</th>
                <th className="py-3 px-4">Payment Mode</th>
                <th className="py-3 px-4 text-right">Amount Received</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-[#64748b]">
                    No receipts found matching the filter parameters.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((r) => (
                  <tr key={r.receiptNumber} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">{r.receiptNumber}</td>
                    <td className="py-3.5 px-4 text-[#64748b] whitespace-nowrap">{r.receiptDate}</td>
                    <td className="py-3.5 px-4">
                      <button
                        type="button"
                        onClick={() => onViewStudentProfile(r.studentRegistrationNumber)}
                        className="font-bold text-[#1e293b] hover:text-[#1e3a8a] hover:underline cursor-pointer text-left block"
                      >
                        {r.studentName}
                      </button>
                      <span className="font-mono text-[10px] text-[#64748b]">{r.studentRegistrationNumber}</span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-700">{r.className}</td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">{r.feeTypeName}</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-medium text-[11px]">
                        {r.paymentMode}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                      ${r.amountPaid.toFixed(2)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <Badge variant={r.isVoided ? 'rose' : 'emerald'} size="sm">
                        {r.isVoided ? 'VOIDED' : 'OFFICIAL'}
                      </Badge>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onOpenReceiptModal(r)}
                        leftIcon={<Eye className="w-3.5 h-3.5" />}
                        className="text-xs text-[#1e3a8a] hover:bg-blue-50 cursor-pointer"
                      >
                        Preview / Print
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
