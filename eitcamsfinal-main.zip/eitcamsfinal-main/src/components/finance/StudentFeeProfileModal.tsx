import React, { useState } from 'react';
import {
  User,
  CreditCard,
  X,
  Receipt,
  DollarSign,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  Printer,
  FileText,
  ShieldCheck,
  Tag,
  ShieldAlert,
  Percent,
} from 'lucide-react';
import { StudentFeeSummary, FeeAssignment, FeeReceipt, PaymentRecordItem } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentFeeProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: StudentFeeSummary | null;
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onOpenReceiptModal: (receipt: FeeReceipt) => void;
  onOpenVoidModal: (payment: PaymentRecordItem) => void;
  onWaiveFee: (assignmentId: string, waiverAmount: number, reason: string) => Promise<any>;
}

export function StudentFeeProfileModal({
  isOpen,
  onClose,
  summary,
  onOpenPaymentModal,
  onOpenReceiptModal,
  onOpenVoidModal,
  onWaiveFee,
}: StudentFeeProfileModalProps) {
  const [activeTab, setActiveTab] = useState<'breakdown' | 'payments' | 'receipts'>('breakdown');
  const [waiverModalState, setWaiverModalState] = useState<{
    isOpen: boolean;
    assignment: FeeAssignment | null;
    amount: string;
    reason: string;
    isSubmitting: boolean;
    error: string | null;
  }>({
    isOpen: false,
    assignment: null,
    amount: '',
    reason: '',
    isSubmitting: false,
    error: null,
  });

  if (!isOpen || !summary) return null;

  const handleOpenWaiver = (assignment: FeeAssignment) => {
    const balance = assignment.balanceDue ?? assignment.balance ?? 0;
    setWaiverModalState({
      isOpen: true,
      assignment,
      amount: String(balance),
      reason: 'Merit scholarship / Administrative fee waiver',
      isSubmitting: false,
      error: null,
    });
  };

  const handleConfirmWaiver = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!waiverModalState.assignment) return;

    const amt = parseFloat(waiverModalState.amount);
    const maxBalance = waiverModalState.assignment.balanceDue ?? waiverModalState.assignment.balance ?? 0;

    if (isNaN(amt) || amt <= 0) {
      setWaiverModalState((prev) => ({ ...prev, error: 'Waiver amount must be greater than 0.' }));
      return;
    }
    if (amt > maxBalance) {
      setWaiverModalState((prev) => ({
        ...prev,
        error: `Waiver cannot exceed outstanding balance of $${maxBalance.toFixed(2)}.`,
      }));
      return;
    }
    if (!waiverModalState.reason.trim()) {
      setWaiverModalState((prev) => ({ ...prev, error: 'Please enter an authorization reason.' }));
      return;
    }

    setWaiverModalState((prev) => ({ ...prev, isSubmitting: true, error: null }));
    try {
      await onWaiveFee(waiverModalState.assignment.id, amt, waiverModalState.reason.trim());
      setWaiverModalState({
        isOpen: false,
        assignment: null,
        amount: '',
        reason: '',
        isSubmitting: false,
        error: null,
      });
    } catch (err: any) {
      setWaiverModalState((prev) => ({
        ...prev,
        isSubmitting: false,
        error: err.message || 'Failed to submit waiver.',
      }));
    }
  };

  const handlePrintStatement = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Modal Top Bar */}
        <div className="p-5 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-[#1e293b]">{summary.studentName}</h3>
                <span className="font-mono text-xs bg-blue-100 text-[#1e3a8a] font-bold px-2 py-0.5 rounded">
                  {summary.studentRegistrationNumber}
                </span>
                <Badge
                  variant={
                    summary.status === 'Paid'
                      ? 'emerald'
                      : summary.status === 'Partial' || summary.status === 'Partially Paid'
                      ? 'amber'
                      : 'rose'
                  }
                  size="sm"
                >
                  {summary.status}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b]">
                {summary.className} &bull; Section {summary.section} &bull; Academic Session {summary.academicSession}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrintStatement}
              leftIcon={<Printer className="w-3.5 h-3.5" />}
              className="text-xs cursor-pointer"
            >
              Print Statement
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => onOpenPaymentModal(summary.studentRegistrationNumber)}
              leftIcon={<CreditCard className="w-3.5 h-3.5" />}
              className="text-xs bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
            >
              Record Payment
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 4 Financial KPI Stat Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-5 bg-white border-b border-[#e2e8f0]">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#64748b] block mb-1">
              Total Invoiced
            </span>
            <span className="text-lg font-mono font-bold text-[#1e293b]">
              ${summary.totalDue.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
              Total Paid
            </span>
            <span className="text-lg font-mono font-bold text-emerald-800">
              ${summary.totalPaid.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 block mb-1">
              Concessions / Waivers
            </span>
            <span className="text-lg font-mono font-bold text-blue-800">
              ${summary.totalWaived.toFixed(2)}
            </span>
          </div>

          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block mb-1">
              Outstanding Dues
            </span>
            <span className="text-lg font-mono font-black text-amber-900">
              ${summary.totalOutstanding.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Inner Navigation Tabs */}
        <div className="px-5 pt-3 bg-slate-50 border-b border-[#e2e8f0] flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('breakdown')}
            className={`px-3 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'breakdown'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Invoices & Line Items ({summary.assignments.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('payments')}
            className={`px-3 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'payments'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Payment Vouchers ({summary.payments.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('receipts')}
            className={`px-3 py-2 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'receipts'
                ? 'border-[#1e3a8a] text-[#1e3a8a]'
                : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
            }`}
          >
            Official Receipts ({summary.receipts.length})
          </button>
        </div>

        {/* Tab 1: Invoices Breakdown */}
        {activeTab === 'breakdown' && (
          <div className="p-5 max-h-96 overflow-y-auto">
            {summary.assignments.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#64748b]">No invoices assigned to this student.</div>
            ) : (
              <div className="space-y-3">
                {summary.assignments.map((assignment) => {
                  const balance = assignment.balanceDue ?? assignment.balance ?? 0;
                  return (
                    <div
                      key={assignment.id}
                      className="p-4 bg-white border border-[#e2e8f0] rounded-xl shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs font-bold text-[#1e3a8a]">{assignment.id}</span>
                          <span className="font-bold text-sm text-[#1e293b]">{assignment.feeTypeName}</span>
                          <Badge
                            variant={
                              assignment.status === 'Paid'
                                ? 'emerald'
                                : assignment.status === 'Partial' || assignment.status === 'Partially Paid'
                                ? 'amber'
                                : 'rose'
                            }
                            size="sm"
                          >
                            {assignment.status}
                          </Badge>
                        </div>
                        <div className="text-xs text-[#64748b] flex items-center gap-3">
                          <span>Due: {assignment.dueDate}</span>
                          {assignment.discountOrWaiver > 0 && (
                            <span className="text-blue-700 font-semibold">
                              Waiver/Aid: ${assignment.discountOrWaiver.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <span className="text-[10px] uppercase text-[#64748b] font-bold block">Outstanding</span>
                          <span className="font-mono font-bold text-sm text-[#1e293b]">${balance.toFixed(2)}</span>
                          <span className="text-[10px] text-[#64748b] block">Paid: ${assignment.amountPaid.toFixed(2)}</span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {balance > 0 && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenWaiver(assignment)}
                                className="text-[11px] text-blue-700 hover:bg-blue-50 cursor-pointer"
                              >
                                Waive / Aid
                              </Button>
                              <Button
                                variant="primary"
                                size="sm"
                                onClick={() => onOpenPaymentModal(summary.studentRegistrationNumber, assignment.id)}
                                className="text-[11px] bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
                              >
                                Pay
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Payments History */}
        {activeTab === 'payments' && (
          <div className="p-5 max-h-96 overflow-y-auto">
            {summary.payments.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#64748b]">No payments recorded for this student yet.</div>
            ) : (
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3">Voucher #</th>
                    <th className="py-2 px-3">Mode</th>
                    <th className="py-2 px-3">Reference</th>
                    <th className="py-2 px-3 text-right">Amount</th>
                    <th className="py-2 px-3 text-center">Status</th>
                    <th className="py-2 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {summary.payments.map((payment) => (
                    <tr key={payment.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-[#64748b]">{payment.paymentDate}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-[#1e3a8a]">{payment.receiptNumber}</td>
                      <td className="py-2.5 px-3">{payment.paymentMode}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-700">
                        {payment.transactionReference || 'N/A'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-[#1e293b]">
                        ${payment.amountPaid.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <Badge variant={payment.isVoided ? 'rose' : 'emerald'} size="sm">
                          {payment.isVoided ? 'VOIDED' : 'VALID'}
                        </Badge>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {!payment.isVoided && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onOpenVoidModal(payment)}
                            className="text-[11px] text-red-600 hover:text-red-800 hover:bg-red-50 cursor-pointer"
                          >
                            Void
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {/* Tab 3: Receipts Registry */}
        {activeTab === 'receipts' && (
          <div className="p-5 max-h-96 overflow-y-auto">
            {summary.receipts.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#64748b]">No official receipts issued yet.</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {summary.receipts.map((receipt) => (
                  <div
                    key={receipt.receiptNumber}
                    className="p-3.5 bg-white border border-[#e2e8f0] rounded-xl shadow-2xs hover:border-[#1e3a8a] transition-all flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-1.5 mb-1">
                        <Receipt className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        <span className="font-mono text-xs font-bold text-[#1e3a8a]">{receipt.receiptNumber}</span>
                        {receipt.isVoided && (
                          <Badge variant="rose" size="sm">
                            VOID
                          </Badge>
                        )}
                      </div>
                      <div className="text-[11px] text-[#64748b]">
                        {receipt.receiptDate} &bull; ${receipt.amountPaid.toFixed(2)} ({receipt.paymentMode})
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onOpenReceiptModal(receipt)}
                      className="text-xs cursor-pointer"
                    >
                      View
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Embedded Waiver Modal */}
        {waiverModalState.isOpen && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-blue-200">
              <div className="p-4 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Percent className="w-5 h-5 text-blue-700" />
                  <h4 className="text-sm font-bold text-blue-950">Apply Scholarship / Fee Waiver</h4>
                </div>
                <button
                  type="button"
                  onClick={() => setWaiverModalState((p) => ({ ...p, isOpen: false }))}
                  className="text-blue-500 hover:text-blue-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleConfirmWaiver} className="p-5 space-y-4">
                {waiverModalState.error && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                    {waiverModalState.error}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#1e293b] mb-1">Waiver / Concession Amount (USD)</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      required
                      value={waiverModalState.amount}
                      onChange={(e) => setWaiverModalState((p) => ({ ...p, amount: e.target.value }))}
                      className="w-full pl-7 pr-3 py-1.5 text-sm font-mono font-bold border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1e293b] mb-1">Authorization Justification</label>
                  <input
                    type="text"
                    required
                    value={waiverModalState.reason}
                    onChange={(e) => setWaiverModalState((p) => ({ ...p, reason: e.target.value }))}
                    placeholder="e.g. Dean Merit List / EWS Fee Concession"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                  <Button
                    variant="ghost"
                    size="sm"
                    type="button"
                    onClick={() => setWaiverModalState((p) => ({ ...p, isOpen: false }))}
                  >
                    Cancel
                  </Button>
                  <Button
                    variant="primary"
                    size="sm"
                    type="submit"
                    disabled={waiverModalState.isSubmitting}
                    className="bg-[#1e3a8a] text-white"
                  >
                    {waiverModalState.isSubmitting ? 'Applying...' : 'Apply Waiver'}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex justify-end">
          <Button variant="outline" size="sm" onClick={onClose} className="cursor-pointer">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}
