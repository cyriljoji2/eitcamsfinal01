import React, { useState } from 'react';
import { Award, X, AlertCircle, CheckCircle2 } from 'lucide-react';
import { StudentRecord, FeeInvoiceRecord, AdjustmentType } from '../../types/database';
import { Button } from '../ui/Button';

interface AwardScholarshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: StudentRecord[];
  invoices: FeeInvoiceRecord[];
  onAwardScholarship: (data: {
    invoice_id: string;
    adjustment_type: AdjustmentType;
    amount: number;
    reason: string;
  }) => Promise<any>;
}

const SCHOLARSHIP_SCHEMES = [
  { name: "Chancellor's Top Rank Scholar (100% Tuition Waiver)", type: AdjustmentType.SCHOLARSHIP, discountPct: 100 },
  { name: "Dean's Academic Merit Concession (50% Tuition Waiver)", type: AdjustmentType.MERIT_DISCOUNT, discountPct: 50 },
  { name: "National Sports & Athletics Quota Grant (35% Concession)", type: AdjustmentType.CONCESSION, discountPct: 35 },
  { name: "EWS Economically Weaker Section Financial Assistance", type: AdjustmentType.FINANCIAL_AID, fixedAmount: 1500 },
  { name: "First-Generation Technology Engineering Grant", type: AdjustmentType.SCHOLARSHIP, fixedAmount: 1000 },
];

export function AwardScholarshipModal({
  isOpen,
  onClose,
  students,
  invoices,
  onAwardScholarship,
}: AwardScholarshipModalProps) {
  const [selectedStudentReg, setSelectedStudentReg] = useState(students[0]?.registration_number || '');
  const [selectedScheme, setSelectedScheme] = useState(SCHOLARSHIP_SCHEMES[0].name);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [amount, setAmount] = useState('');
  const [justification, setJustification] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const studentInvoices = invoices.filter(
    (i) => i.registration_number.toLowerCase() === selectedStudentReg.toLowerCase() && i.outstanding_balance > 0
  );

  React.useEffect(() => {
    if (isOpen) {
      setError(null);
      setIsSubmitting(false);
      if (students.length > 0) {
        setSelectedStudentReg(students[0].registration_number);
      }
    }
  }, [isOpen, students]);

  React.useEffect(() => {
    if (studentInvoices.length > 0) {
      setSelectedInvoiceId(studentInvoices[0].invoice_id);
      const inv = studentInvoices[0];
      const scheme = SCHOLARSHIP_SCHEMES.find((s) => s.name === selectedScheme);
      if (scheme?.discountPct) {
        setAmount(String(Math.round((inv.subtotal * scheme.discountPct) / 100)));
      } else if (scheme?.fixedAmount) {
        setAmount(String(Math.min(scheme.fixedAmount, inv.outstanding_balance)));
      }
    } else {
      setSelectedInvoiceId('');
      setAmount('');
    }
  }, [selectedStudentReg, selectedScheme]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoiceId) {
      setError('Student has no active outstanding invoice to apply scholarship against.');
      return;
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Scholarship amount must be greater than 0.');
      return;
    }

    const targetInv = invoices.find((i) => i.invoice_id === selectedInvoiceId);
    if (targetInv && parsedAmount > targetInv.outstanding_balance) {
      setError(`Scholarship amount ($${parsedAmount}) cannot exceed invoice balance ($${targetInv.outstanding_balance}).`);
      return;
    }

    const scheme = SCHOLARSHIP_SCHEMES.find((s) => s.name === selectedScheme);
    const adjType = scheme?.type || AdjustmentType.SCHOLARSHIP;

    setIsSubmitting(true);
    setError(null);
    try {
      await onAwardScholarship({
        invoice_id: selectedInvoiceId,
        adjustment_type: adjType,
        amount: parsedAmount,
        reason: `${selectedScheme}: ${justification.trim() || 'Approved by Academic Dean'}`,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to award scholarship.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        <div className="p-5 bg-blue-50 border-b border-blue-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">Award Institutional Scholarship</h3>
              <p className="text-xs text-[#64748b]">Apply official merit waiver or grant to candidate account.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Select Student Candidate <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedStudentReg}
              onChange={(e) => setSelectedStudentReg(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            >
              {students.map((s) => (
                <option key={s.student_id} value={s.registration_number}>
                  {s.registration_number} — {s.first_name} {s.last_name} ({s.department} Sem {s.current_semester})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Scholarship / Concession Scheme <span className="text-red-500">*</span>
            </label>
            <select
              value={selectedScheme}
              onChange={(e) => setSelectedScheme(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            >
              {SCHOLARSHIP_SCHEMES.map((s) => (
                <option key={s.name} value={s.name}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Apply Against Invoice <span className="text-red-500">*</span>
            </label>
            <select
              required
              value={selectedInvoiceId}
              onChange={(e) => setSelectedInvoiceId(e.target.value)}
              className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            >
              {studentInvoices.length === 0 ? (
                <option value="">No outstanding invoices for this student</option>
              ) : (
                studentInvoices.map((inv) => (
                  <option key={inv.invoice_id} value={inv.invoice_id}>
                    {inv.invoice_id} — {inv.fee_category} (Balance: ${inv.outstanding_balance})
                  </option>
                ))
              )}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Concession Amount (USD) <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">$</span>
              <input
                type="number"
                step="0.01"
                min="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 pr-3.5 py-2 text-xs font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Committee Resolution / Approval Reference
            </label>
            <textarea
              rows={2}
              value={justification}
              onChange={(e) => setJustification(e.target.value)}
              placeholder="e.g. Approved by Institute Scholarship Committee Min 4(b) dated 2026-10-15"
              className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="primary"
              size="sm"
              type="submit"
              disabled={isSubmitting || !selectedInvoiceId}
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
              className="bg-[#1e3a8a] text-white cursor-pointer"
            >
              {isSubmitting ? 'Awarding...' : 'Award Scholarship'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
