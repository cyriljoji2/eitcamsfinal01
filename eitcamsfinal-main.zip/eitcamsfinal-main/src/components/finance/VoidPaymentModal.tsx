import React, { useState } from 'react';
import { AlertTriangle, X, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { PaymentRecordItem } from '../../types/finance';
import { Button } from '../ui/Button';

interface VoidPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: PaymentRecordItem | null;
  currentUserName: string;
  onConfirmVoid: (paymentId: string, reason: string, voidedBy: string) => Promise<any>;
}

export function VoidPaymentModal({
  isOpen,
  onClose,
  payment,
  currentUserName,
  onConfirmVoid,
}: VoidPaymentModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !payment) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setError('Please provide an explicit audit reason for reversing this payment.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmVoid(payment.id, reason.trim(), currentUserName);
      setReason('');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to void payment transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-red-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 bg-red-50 border-b border-red-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-red-950">Void / Reverse Payment</h3>
              <p className="text-xs text-red-700">Audit-controlled reversal of recorded ledger transaction.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-red-400 hover:text-red-700 hover:bg-red-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-100 border border-red-300 rounded-xl text-xs text-red-800">
              {error}
            </div>
          )}

          <div className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-[#64748b]">Transaction ID:</span>
              <span className="font-mono font-bold text-[#1e293b]">{payment.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Receipt Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{payment.receiptNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Student:</span>
              <span className="font-bold text-[#1e293b]">
                {payment.studentName} ({payment.studentRegistrationNumber})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Fee Head:</span>
              <span className="font-medium text-[#1e293b]">{payment.feeTypeName}</span>
            </div>
            <div className="flex justify-between border-t border-[#e2e8f0] pt-1 mt-1">
              <span className="text-[#64748b] font-bold">Amount to Revert:</span>
              <span className="font-mono font-black text-red-700 text-sm">
                ${payment.amountPaid.toFixed(2)} ({payment.paymentMode})
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
              Audit Justification / Reversal Reason <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Bank cheque dishonoured by issuing institution / Duplicate cashier entry"
              className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e2e8f0]">
            <Button variant="ghost" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              variant="danger"
              size="sm"
              type="submit"
              disabled={isSubmitting}
              className="bg-red-600 hover:bg-red-700 text-white cursor-pointer"
            >
              {isSubmitting ? 'Reversing...' : 'Confirm Ledger Reversal'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
