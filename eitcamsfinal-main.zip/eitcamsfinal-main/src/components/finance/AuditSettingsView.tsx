import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  Search, 
  Clock, 
  Building, 
  Sliders, 
  CheckCircle2, 
  Lock, 
  Globe, 
  Database, 
  Download 
} from 'lucide-react';
import { AuditLogEntry } from '../../types';

interface AuditSettingsViewProps {
  auditLogs: AuditLogEntry[];
  onRefresh: () => void;
}

export const AuditSettingsView: React.FC<AuditSettingsViewProps> = ({
  auditLogs,
}) => {
  const [activeTab, setActiveTab] = useState<'audit' | 'settings'>('audit');
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('ALL');

  // Filter logs for finance-related actions
  const financeLogs = useMemo(() => {
    return auditLogs.filter(log => {
      const actorOffice = log.actorOffice || log.actor_role || '';
      const action = String(log.action || '');
      const targetWorksheet = log.target_worksheet || log.entityType || '';
      const actorId = log.actorId || log.actor_id || '';

      return (
        actorOffice.toLowerCase().includes('finance') ||
        action.includes('FINANCE') ||
        action.includes('PAYMENT') ||
        action.includes('INVOICE') ||
        action.includes('FEE') ||
        action.includes('ADJUSTMENT') ||
        action.includes('REFUND') ||
        action.includes('SCHOLARSHIP') ||
        targetWorksheet === 'FeeStructures' ||
        targetWorksheet === 'FeeInvoices' ||
        targetWorksheet === 'PaymentLedger' ||
        targetWorksheet === 'FeeAdjustments' ||
        targetWorksheet === 'HostelCharges' ||
        actorId.toLowerCase().includes('finance')
      );
    });
  }, [auditLogs]);

  const filteredLogs = useMemo(() => {
    return financeLogs.filter(log => {
      const actorId = log.actorId || log.actor_id || '';
      const action = String(log.action || '');
      const entityId = log.entityId || log.target_record_id || '';
      const details = log.details ? JSON.stringify(log.details) : log.description || '';

      const matchesSearch = 
        actorId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entityId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        details.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesAction = actionFilter === 'ALL' || action === actionFilter;

      return matchesSearch && matchesAction;
    });
  }, [financeLogs, searchTerm, actionFilter]);

  const handleExportCSV = () => {
    const headers = ['Timestamp', 'Actor ID', 'Actor Role/Office', 'Action', 'Target Sheet', 'Record ID', 'Description/Details'];
    const rows = filteredLogs.map(l => [
      l.timestamp,
      l.actorId || l.actor_id || '',
      l.actorOffice || l.actor_role || '',
      l.action,
      l.entityType || l.target_worksheet || '',
      l.entityId || l.target_record_id || '',
      `"${JSON.stringify(l.details || l.description || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EIT_Finance_Audit_Trail_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-slate-800 text-white rounded-lg">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </span>
            <h1 className="text-xl font-bold text-slate-800">Financial Audit & Institutional Settings</h1>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Authoritative audit trail of financial events, ledger modifications, and university billing configuration.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {activeTab === 'audit' && (
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-2 border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-500" />
              Export Audit Trail
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeTab === 'audit'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>Financial Audit Log ({financeLogs.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-slate-800 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Institutional Parameters</span>
        </button>
      </div>

      {/* Audit Log Tab */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search audit trail by actor, entity..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-slate-800"
              />
            </div>
            <div className="text-xs text-slate-500 font-medium">
              Showing {filteredLogs.length} verified events
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Timestamp</th>
                    <th className="px-6 py-3">Actor & Office</th>
                    <th className="px-6 py-3">Event Action</th>
                    <th className="px-6 py-3">Entity Reference</th>
                    <th className="px-6 py-3">Audit Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredLogs.map((log, idx) => (
                    <tr key={log.id || log.log_id || idx} className="hover:bg-slate-50/80">
                      <td className="px-6 py-4 text-xs font-mono text-slate-500 whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleString()}
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-900">{log.actorId || log.actor_id}</div>
                        <div className="text-xs text-slate-500">{log.actorOffice || log.actor_role}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-md text-xs font-mono font-medium">
                          {log.action}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-mono text-slate-700">{log.entityId || log.target_record_id}</div>
                        <div className="text-[11px] text-slate-500 uppercase">{log.entityType || log.target_worksheet}</div>
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-600 max-w-md">
                        <pre className="font-mono text-[11px] bg-slate-50 p-2 rounded border border-slate-200 whitespace-pre-wrap overflow-x-auto">
                          {log.details ? JSON.stringify(log.details, null, 2) : log.description || 'Action recorded successfully.'}
                        </pre>
                      </td>
                    </tr>
                  ))}
                  {filteredLogs.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-slate-400">
                        No financial audit records found matching criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Institutional Settings Tab */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Institution & Billing Header */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Building className="w-5 h-5 text-indigo-600" />
              Institutional Identity & Receipts Header
            </h3>
            <div className="space-y-3 text-sm">
              <div>
                <span className="text-xs text-slate-500 block">Institution Name:</span>
                <span className="font-semibold text-slate-800">Electrix Institute of Technology (EIT)</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Governing Finance Office:</span>
                <span className="font-medium text-slate-800">Office of the Comptroller of Finance & Accounts (PO-005)</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Permanent Campus Address:</span>
                <span className="text-slate-700">EIT Technology Campus, Chennai, Tamil Nadu - 600127</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Statutory Approvals & Accreditation:</span>
                <span className="text-slate-700">AICTE Approved • Affiliated to Anna University • NBA Accredited</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Billing Contact & Support:</span>
                <span className="font-mono text-xs text-indigo-600">finance@eit.edu.in • +91 (044) 2745-0005</span>
              </div>
            </div>
          </div>

          {/* Card 2: Financial Governance Rules */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Lock className="w-5 h-5 text-emerald-600" />
              Financial Governance & Segregation of Duties
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-800">Dual-Actor Authorization</span>
                  <p className="text-xs text-slate-500">
                    Refunds, fee adjustments, and scholarships cannot be approved by the same officer who initiated them.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-800">Immutable Receipts</span>
                  <p className="text-xs text-slate-500">
                    Receipt numbers (e.g. REC-...) are strictly monotonically issued and cannot be deleted or renumbered.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-800">Student Portal Isolation</span>
                  <p className="text-xs text-slate-500">
                    Students can inspect invoices, initiate payments, and download receipts, but have no write permissions on ledger structures.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Card 3: Gateway & Integration Parameters */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              Gateway & Third-Party Integrations
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Payment Gateway Simulation:</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono text-xs rounded font-semibold">
                  ACTIVE (MOCK SANDBOX)
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Google Sheets Ledger Sync:</span>
                <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-mono text-xs rounded">
                  DEFERRED (PHASE 11)
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Hostel Office Integration:</span>
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-mono text-xs rounded font-semibold">
                  CONNECTED (PO-006)
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-600">Cloud Database Adapter:</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-800 font-mono text-xs rounded font-semibold">
                  AUTHORITATIVE MEMORY ADAPTER
                </span>
              </div>
            </div>
          </div>

          {/* Card 4: Currency & Academic Cycles */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Database className="w-5 h-5 text-purple-600" />
              Fiscal Cycle & Currency Standards
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Active Academic Year:</span>
                <span className="font-semibold text-slate-800">2024 - 2025</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Active Academic Semesters:</span>
                <span className="font-semibold text-slate-800">Odd Semesters (1, 3, 5, 7)</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Operational Base Currency:</span>
                <span className="font-semibold text-slate-800">USD ($) Standard Demonstration</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-600">Default Late Fee Policy:</span>
                <span className="font-semibold text-slate-800">$50 per week post due-date</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
