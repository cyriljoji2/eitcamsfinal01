import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  DollarSign,
  AlertCircle,
  Download,
  Info,
  CreditCard,
  User,
  XCircle,
} from 'lucide-react';
import { StudentRecord, StudentStatus } from '../../types/database';
import { FeeAssignment, FeeStructureItem, InvoiceStatus } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface FeeAssignmentsViewProps {
  students: StudentRecord[];
  feeStructures: FeeStructureItem[];
  assignments: FeeAssignment[];
  initialPreselectedFeeId?: string;
  onAssignFeeToProgramme: (params: {
    feeStructureId: string;
    programmeCode: string;
    semester: number;
    academicYear?: string;
    dueDate?: string;
    remarks?: string;
  }) => Promise<{ count: number; skippedCount: number }>;
  onAssignFeeToStudent: (params: {
    feeStructureId: string;
    studentRegistrationNumber: string;
    customAmount?: number;
    discountOrWaiver?: number;
    waiverReason?: string;
    dueDate?: string;
    remarks?: string;
  }) => Promise<any>;
  onCancelInvoice?: (invoiceId: string, reason: string) => Promise<any>;
  onOpenPaymentModal: (studentRegNo: string, feeAssignmentId?: string) => void;
  onViewStudentProfile: (studentRegNo: string) => void;
}

export function FeeAssignmentsView({
  students,
  feeStructures,
  assignments,
  initialPreselectedFeeId,
  onAssignFeeToProgramme,
  onAssignFeeToStudent,
  onCancelInvoice,
  onOpenPaymentModal,
  onViewStudentProfile,
}: FeeAssignmentsViewProps) {
  const [activeTab, setActiveTab] = useState<'cohort-assign' | 'student-assign' | 'list'>('list');

  // Cohort Invoicing Form State
  const [selectedFeeId, setSelectedFeeId] = useState<string>(
    initialPreselectedFeeId || (feeStructures[0]?.id ?? '')
  );
  const [targetProgramme, setTargetProgramme] = useState<string>('BTECH-CSE');
  const [targetSemester, setTargetSemester] = useState<number>(3);
  const [dueDateOverride, setDueDateOverride] = useState<string>('');
  const [cohortRemarks, setCohortRemarks] = useState<string>('');
  const [isSubmittingCohort, setIsSubmittingCohort] = useState(false);
  const [cohortMessage, setCohortMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Individual Student Invoicing Form State
  const [indFeeId, setIndFeeId] = useState<string>(
    initialPreselectedFeeId || (feeStructures[0]?.id ?? '')
  );
  const [indStudentRegNo, setIndStudentRegNo] = useState<string>(
    students[0]?.registration_number ?? ''
  );
  const [indStudentSearch, setIndStudentSearch] = useState<string>('');
  const [indCustomAmount, setIndCustomAmount] = useState<string>('');
  const [indWaiverAmount, setIndWaiverAmount] = useState<string>('0');
  const [indWaiverReason, setIndWaiverReason] = useState<string>('');
  const [indDueDate, setIndDueDate] = useState<string>('');
  const [indRemarks, setIndRemarks] = useState<string>('');
  const [isSubmittingInd, setIsSubmittingInd] = useState(false);
  const [indMessage, setIndMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );

  // Cancel Invoice State
  const [cancelModalInvoiceId, setCancelModalInvoiceId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [isCancelling, setIsCancelling] = useState(false);

  // Assignments List Filter State
  const [listSearch, setListSearch] = useState('');
  const [listProgFilter, setListProgFilter] = useState('all');
  const [listStatusFilter, setListStatusFilter] = useState('all');

  const activeFeeStructure = feeStructures.find((f) => f.id === selectedFeeId);
  const indActiveFeeStructure = feeStructures.find((f) => f.id === indFeeId);

  // Eligible students for cohort assignment preview
  const previewMatchingStudents = students.filter((s) => {
    const progMatch =
      targetProgramme === 'ALL' ||
      s.department === targetProgramme ||
      s.program_name.toLowerCase().includes(targetProgramme.toLowerCase());
    const semMatch = targetSemester === 0 || s.current_semester === targetSemester;
    return progMatch && semMatch && (s.enrollment_status === StudentStatus.ENROLLED || (s as any).status === 'ACTIVE');
  });

  const filteredIndividualStudents = students.filter((s) => {
    if (!indStudentSearch.trim()) return true;
    const q = indStudentSearch.toLowerCase();
    return (
      s.registration_number.toLowerCase().includes(q) ||
      `${s.first_name} ${s.last_name}`.toLowerCase().includes(q) ||
      s.department.toLowerCase().includes(q)
    );
  });

  // Filtered assigned invoices list
  const filteredAssignments = assignments.filter((a) => {
    const student = students.find((s) => s.registration_number.toLowerCase() === a.studentRegistrationNumber.toLowerCase());
    const studentName = student ? `${student.first_name} ${student.last_name}` : '';

    const matchesSearch =
      a.id.toLowerCase().includes(listSearch.toLowerCase()) ||
      a.studentRegistrationNumber.toLowerCase().includes(listSearch.toLowerCase()) ||
      studentName.toLowerCase().includes(listSearch.toLowerCase()) ||
      a.feeTypeName.toLowerCase().includes(listSearch.toLowerCase());

    const matchesProg =
      listProgFilter === 'all' ||
      (student && (student.department === listProgFilter || student.program_name.includes(listProgFilter)));

    const matchesStatus =
      listStatusFilter === 'all' ||
      a.status.toLowerCase().includes(listStatusFilter.toLowerCase());

    return matchesSearch && matchesProg && matchesStatus;
  });

  const handleCohortSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFeeId) {
      setCohortMessage({ type: 'error', text: 'Please select an active fee structure.' });
      return;
    }

    if (previewMatchingStudents.length === 0) {
      setCohortMessage({
        type: 'error',
        text: `No active students found in ${targetProgramme} Semester ${targetSemester}.`,
      });
      return;
    }

    setIsSubmittingCohort(true);
    setCohortMessage(null);
    try {
      const res = await onAssignFeeToProgramme({
        feeStructureId: selectedFeeId,
        programmeCode: targetProgramme,
        semester: Number(targetSemester),
        dueDate: dueDateOverride || undefined,
        remarks: cohortRemarks.trim() || undefined,
      });

      setCohortMessage({
        type: 'success',
        text: `Successfully generated ${res.count} invoice(s) for ${targetProgramme} Semester ${targetSemester}! (${res.skippedCount} students already invoiced)`,
      });
      setCohortRemarks('');
    } catch (err: any) {
      setCohortMessage({
        type: 'error',
        text: err.message || 'Failed to issue cohort invoices.',
      });
    } finally {
      setIsSubmittingCohort(false);
    }
  };

  const handleIndividualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!indFeeId || !indStudentRegNo) {
      setIndMessage({ type: 'error', text: 'Fee structure and student registration are required.' });
      return;
    }

    const customAmtNum = indCustomAmount ? parseFloat(indCustomAmount) : undefined;
    const waiverAmtNum = indWaiverAmount ? parseFloat(indWaiverAmount) : undefined;

    setIsSubmittingInd(true);
    setIndMessage(null);
    try {
      await onAssignFeeToStudent({
        feeStructureId: indFeeId,
        studentRegistrationNumber: indStudentRegNo,
        customAmount: customAmtNum,
        discountOrWaiver: waiverAmtNum,
        waiverReason: indWaiverReason.trim() || undefined,
        dueDate: indDueDate || undefined,
        remarks: indRemarks.trim() || undefined,
      });

      setIndMessage({
        type: 'success',
        text: `Successfully generated invoice for student ${indStudentRegNo}!`,
      });
      setIndCustomAmount('');
      setIndWaiverAmount('0');
      setIndWaiverReason('');
      setIndRemarks('');
    } catch (err: any) {
      setIndMessage({
        type: 'error',
        text: err.message || 'Failed to issue student fee invoice.',
      });
    } finally {
      setIsSubmittingInd(false);
    }
  };

  const handleConfirmCancel = async () => {
    if (!cancelModalInvoiceId || !onCancelInvoice) return;
    if (!cancelReason.trim()) {
      alert('Cancellation reason is required.');
      return;
    }
    setIsCancelling(true);
    try {
      await onCancelInvoice(cancelModalInvoiceId, cancelReason.trim());
      setCancelModalInvoiceId(null);
      setCancelReason('');
    } catch (err: any) {
      alert(err.message || 'Failed to cancel invoice.');
    } finally {
      setIsCancelling(false);
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'Invoice ID',
      'Student Registration Number',
      'Student Name',
      'Programme',
      'Fee Head',
      'Amount Due ($)',
      'Adjustments ($)',
      'Amount Paid ($)',
      'Net Balance ($)',
      'Due Date',
      'Status',
    ];

    const rows = filteredAssignments.map((a) => {
      const student = students.find((s) => s.registration_number.toLowerCase() === a.studentRegistrationNumber.toLowerCase());
      const balance = a.balanceDue ?? a.balance ?? 0;
      return [
        a.id,
        a.studentRegistrationNumber,
        student ? `${student.first_name} ${student.last_name}` : 'N/A',
        student ? student.program_name : 'N/A',
        a.feeTypeName,
        a.amountDue.toFixed(2),
        a.discountOrWaiver.toFixed(2),
        a.amountPaid.toFixed(2),
        balance.toFixed(2),
        a.dueDate,
        a.status.toUpperCase(),
      ];
    });

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Fee_Invoices_Registry_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#1e293b]">Fee Assignments & Invoicing</h2>
          <p className="text-xs text-[#64748b] mt-1">
            Generate and dispatch institutional invoices by student cohort, degree programme, or individual candidate.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Export Invoices
          </Button>

          <Button
            variant={activeTab === 'cohort-assign' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('cohort-assign')}
            leftIcon={<Users className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Cohort Invoicing
          </Button>

          <Button
            variant={activeTab === 'student-assign' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('student-assign')}
            leftIcon={<User className="w-4 h-4" />}
            className="text-xs cursor-pointer"
          >
            Individual Student
          </Button>
        </div>
      </div>

      {/* Navigation Pills Bar */}
      <div className="flex items-center gap-2 border-b border-[#e2e8f0] pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('list')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'list'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-slate-100 hover:text-[#1e293b]'
          }`}
        >
          Invoices Registry ({assignments.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('cohort-assign')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'cohort-assign'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-slate-100 hover:text-[#1e293b]'
          }`}
        >
          Cohort / Programme Billing
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('student-assign')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'student-assign'
              ? 'bg-[#1e3a8a] text-white shadow-xs'
              : 'text-[#64748b] hover:bg-slate-100 hover:text-[#1e293b]'
          }`}
        >
          Individual Student Billing
        </button>
      </div>

      {/* TAB 1: COHORT INVOICING */}
      {activeTab === 'cohort-assign' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs p-6 space-y-5">
            <div>
              <h3 className="text-base font-bold text-[#1e293b]">Programme Cohort Billing</h3>
              <p className="text-xs text-[#64748b] mt-0.5">
                Automatically generate official invoices for all active students enrolled in a degree programme and semester.
              </p>
            </div>

            {cohortMessage && (
              <div
                className={`p-3.5 rounded-xl text-xs flex items-center gap-2 border ${
                  cohortMessage.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-red-50 border-red-200 text-red-800'
                }`}
              >
                {cohortMessage.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{cohortMessage.text}</span>
              </div>
            )}

            <form onSubmit={handleCohortSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                  Select Fee Structure <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={selectedFeeId}
                  onChange={(e) => setSelectedFeeId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                >
                  {feeStructures.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} — ${f.amount.toFixed(2)} ({f.feeCategory} &bull; {f.programmeCode || 'ALL'} Sem {f.semester})
                    </option>
                  ))}
                </select>
                {activeFeeStructure && (
                  <div className="mt-2 p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs flex justify-between">
                    <div>
                      <span className="font-bold text-blue-900">{activeFeeStructure.name}</span>
                      <span className="text-blue-700 block">{activeFeeStructure.description || 'Standard institutional rate card'}</span>
                    </div>
                    <span className="font-mono font-bold text-sm text-[#1e3a8a]">
                      ${activeFeeStructure.amount.toFixed(2)}
                    </span>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                    Target Degree Programme <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={targetProgramme}
                    onChange={(e) => setTargetProgramme(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  >
                    <option value="ALL">All Academic Programmes</option>
                    <option value="BTECH-CSE">B.Tech Computer Science & Engineering</option>
                    <option value="BTECH-ECE">B.Tech Electronics & Communication Engineering</option>
                    <option value="BTECH-MECH">B.Tech Mechanical Engineering</option>
                    <option value="BTECH-EEE">B.Tech Electrical & Electronics Engineering</option>
                    <option value="BTECH-CIVIL">B.Tech Civil Engineering</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                    Semester <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={targetSemester}
                    onChange={(e) => setTargetSemester(Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  >
                    <option value={0}>All Semesters (0)</option>
                    <option value={1}>Semester 1</option>
                    <option value={2}>Semester 2</option>
                    <option value={3}>Semester 3</option>
                    <option value={4}>Semester 4</option>
                    <option value={5}>Semester 5</option>
                    <option value={6}>Semester 6</option>
                    <option value={7}>Semester 7</option>
                    <option value={8}>Semester 8</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                    Due Date Override (Optional)
                  </label>
                  <input
                    type="date"
                    value={dueDateOverride}
                    onChange={(e) => setDueDateOverride(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                    Billing Notes / Batch Memo
                  </label>
                  <input
                    type="text"
                    value={cohortRemarks}
                    onChange={(e) => setCohortRemarks(e.target.value)}
                    placeholder="e.g. Fall 2026 Semester 3 Tuition Billing"
                    className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <Button
                  variant="primary"
                  size="sm"
                  type="submit"
                  disabled={isSubmittingCohort || previewMatchingStudents.length === 0}
                  leftIcon={<CheckCircle2 className="w-4 h-4" />}
                  className="bg-[#1e3a8a] text-white cursor-pointer"
                >
                  {isSubmittingCohort
                    ? 'Generating Invoices...'
                    : `Generate Invoices (${previewMatchingStudents.length} Students)`}
                </Button>
              </div>
            </form>
          </div>

          {/* Right Sidebar: Cohort Preview */}
          <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs p-5 space-y-4">
            <h4 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider flex items-center justify-between">
              <span>Candidate Roster Preview</span>
              <span className="font-mono bg-blue-100 text-[#1e3a8a] px-2 py-0.5 rounded text-[11px]">
                {previewMatchingStudents.length} Students
              </span>
            </h4>
            <p className="text-[11px] text-[#64748b]">
              Students who match {targetProgramme} Semester {targetSemester}. Invoices will not duplicate if already issued.
            </p>

            <div className="space-y-2 max-h-80 overflow-y-auto">
              {previewMatchingStudents.map((s) => (
                <div key={s.student_id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
                  <div className="font-bold text-[#1e293b]">{s.first_name} {s.last_name}</div>
                  <div className="text-[11px] font-mono text-[#1e3a8a]">{s.registration_number}</div>
                  <div className="text-[10px] text-[#64748b]">{s.department} &bull; Section {s.section}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INDIVIDUAL STUDENT INVOICING */}
      {activeTab === 'student-assign' && (
        <div className="max-w-2xl bg-white border border-[#e2e8f0] rounded-2xl shadow-xs p-6 space-y-5">
          <div>
            <h3 className="text-base font-bold text-[#1e293b]">Individual Student Fee Billing</h3>
            <p className="text-xs text-[#64748b] mt-0.5">
              Issue an institutional fee invoice to a designated student with custom amounts and initial scholarship concessions.
            </p>
          </div>

          {indMessage && (
            <div
              className={`p-3.5 rounded-xl text-xs flex items-center gap-2 border ${
                indMessage.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}
            >
              {indMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{indMessage.text}</span>
            </div>
          )}

          <form onSubmit={handleIndividualSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Select Student <span className="text-red-500">*</span>
              </label>
              <div className="space-y-1.5">
                <input
                  type="text"
                  placeholder="Filter student by name or registration number..."
                  value={indStudentSearch}
                  onChange={(e) => setIndStudentSearch(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#1e3a8a]"
                />
                <select
                  required
                  value={indStudentRegNo}
                  onChange={(e) => setIndStudentRegNo(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                >
                  {filteredIndividualStudents.map((s) => (
                    <option key={s.student_id} value={s.registration_number}>
                      {s.registration_number} — {s.first_name} {s.last_name} ({s.department} Sem {s.current_semester})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                Fee Head Rate Card <span className="text-red-500">*</span>
              </label>
              <select
                required
                value={indFeeId}
                onChange={(e) => setIndFeeId(e.target.value)}
                className="w-full px-3.5 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              >
                {feeStructures.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} — ${f.amount.toFixed(2)} ({f.feeCategory})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                  Custom Invoiced Amount (USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={indCustomAmount}
                    onChange={(e) => setIndCustomAmount(e.target.value)}
                    placeholder={indActiveFeeStructure ? String(indActiveFeeStructure.amount) : '0.00'}
                    className="w-full pl-7 pr-3 py-2 text-xs font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                  Initial Concession / Waiver (USD)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">$</span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={indWaiverAmount}
                    onChange={(e) => setIndWaiverAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full pl-7 pr-3 py-2 text-xs font-mono font-bold bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={indDueDate}
                  onChange={(e) => setIndDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider mb-1">
                  Waiver Reason (if applicable)
                </label>
                <input
                  type="text"
                  value={indWaiverReason}
                  onChange={(e) => setIndWaiverReason(e.target.value)}
                  placeholder="e.g. Merit Concession 50%"
                  className="w-full px-3 py-2 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <Button
                variant="primary"
                size="sm"
                type="submit"
                disabled={isSubmittingInd}
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
                className="bg-[#1e3a8a] text-white cursor-pointer"
              >
                {isSubmittingInd ? 'Issuing...' : 'Generate Invoice'}
              </Button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: INVOICES REGISTRY LIST */}
      {activeTab === 'list' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="p-4 bg-white border border-[#e2e8f0] rounded-2xl shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-[#64748b] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by student, invoice ID, or fee head..."
                value={listSearch}
                onChange={(e) => setListSearch(e.target.value)}
                className="w-full pl-9 pr-3.5 py-2 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a]"
              />
            </div>

            <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
              <select
                value={listProgFilter}
                onChange={(e) => setListProgFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
              >
                <option value="all">All Programmes</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="MECH">Mechanical</option>
              </select>

              <select
                value={listStatusFilter}
                onChange={(e) => setListStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20"
              >
                <option value="all">All Invoices</option>
                <option value="paid">Paid</option>
                <option value="partial">Partially Paid</option>
                <option value="unpaid">Unpaid / Issued</option>
                <option value="overdue">Overdue</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#475569] font-bold border-b border-[#e2e8f0]">
                  <tr>
                    <th className="py-3 px-4">Invoice #</th>
                    <th className="py-3 px-4">Student Candidate</th>
                    <th className="py-3 px-4">Fee Head / Session</th>
                    <th className="py-3 px-4 text-right">Invoiced ($)</th>
                    <th className="py-3 px-4 text-right">Adjustments ($)</th>
                    <th className="py-3 px-4 text-right">Amount Paid ($)</th>
                    <th className="py-3 px-4 text-right">Balance Due ($)</th>
                    <th className="py-3 px-4">Due Date</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {filteredAssignments.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-[#64748b]">
                        No invoices found matching current filters.
                      </td>
                    </tr>
                  ) : (
                    filteredAssignments.map((a) => {
                      const student = students.find(
                        (s) => s.registration_number.toLowerCase() === a.studentRegistrationNumber.toLowerCase()
                      );
                      const balance = a.balanceDue ?? a.balance ?? 0;
                      return (
                        <tr key={a.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">{a.id}</td>
                          <td className="py-3 px-4">
                            <button
                              type="button"
                              onClick={() => onViewStudentProfile(a.studentRegistrationNumber)}
                              className="font-bold text-[#1e293b] hover:text-[#1e3a8a] hover:underline cursor-pointer text-left block"
                            >
                              {student ? `${student.first_name} ${student.last_name}` : a.studentRegistrationNumber}
                            </button>
                            <span className="font-mono text-[10px] text-[#64748b]">{a.studentRegistrationNumber}</span>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-semibold text-slate-800 block">{a.feeTypeName}</span>
                            <span className="text-[10px] text-slate-500">{a.academicSession || '2026-2027'}</span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                            ${a.amountDue.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-blue-700">
                            {a.discountOrWaiver > 0 ? `-$${a.discountOrWaiver.toFixed(2)}` : '—'}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800">
                            ${a.amountPaid.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-black text-sm text-[#1e293b]">
                            ${balance.toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-[#64748b] whitespace-nowrap">{a.dueDate}</td>
                          <td className="py-3 px-4 text-center">
                            <Badge
                              variant={
                                a.status === 'Paid'
                                  ? 'emerald'
                                  : a.status === 'Partial' || a.status === 'Partially Paid'
                                  ? 'amber'
                                  : a.status === 'Overdue'
                                  ? 'rose'
                                  : 'default'
                              }
                              size="sm"
                            >
                              {a.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {balance > 0 && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => onOpenPaymentModal(a.studentRegistrationNumber, a.id)}
                                  className="text-[11px] text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                                >
                                  Pay
                                </Button>
                              )}

                              {onCancelInvoice && balance === a.amountDue && (
                                <button
                                  type="button"
                                  onClick={() => setCancelModalInvoiceId(a.id)}
                                  className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                                  title="Cancel invoice"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Cancellation Modal */}
      {cancelModalInvoiceId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-5 space-y-4 border border-slate-200">
            <div className="flex items-center gap-2.5 text-red-600 font-bold">
              <AlertCircle className="w-5 h-5" />
              <span>Cancel Fee Invoice</span>
            </div>
            <p className="text-xs text-slate-600">
              Are you sure you want to cancel invoice <span className="font-mono font-bold text-slate-900">{cancelModalInvoiceId}</span>?
              If linked to a hostel charge request, the charge will revert to REQUESTED state.
            </p>
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Cancellation Reason</label>
              <textarea
                rows={2}
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="e.g. Issued in error / Course dropped during add-drop window"
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-red-500"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <Button variant="ghost" size="sm" onClick={() => setCancelModalInvoiceId(null)}>
                Close
              </Button>
              <Button
                variant="danger"
                size="sm"
                disabled={isCancelling}
                onClick={handleConfirmCancel}
              >
                {isCancelling ? 'Cancelling...' : 'Confirm Cancel'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
