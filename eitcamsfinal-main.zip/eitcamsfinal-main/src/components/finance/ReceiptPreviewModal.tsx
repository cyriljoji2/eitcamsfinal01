import React, { useRef } from 'react';
import {
  Receipt,
  Printer,
  Download,
  X,
  CheckCircle2,
  AlertCircle,
  Building2,
  Calendar,
  CreditCard,
  Hash,
  User,
  ShieldCheck,
  QrCode,
} from 'lucide-react';
import { FeeReceipt } from '../../types/finance';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface ReceiptPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: FeeReceipt | null;
}

export function ReceiptPreviewModal({ isOpen, onClose, receipt }: ReceiptPreviewModalProps) {
  const printContainerRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCsv = () => {
    const csvContent = [
      ['FIELD', 'VALUE'],
      ['Receipt Number', receipt.receiptNumber],
      ['Payment Reference ID', receipt.paymentId],
      ['Receipt Date', receipt.receiptDate],
      ['Student Registration Number', receipt.studentRegistrationNumber],
      ['Student Full Name', receipt.studentName],
      ['Degree Programme & Section', `${receipt.className} - Section ${receipt.section}`],
      ['Academic Session', receipt.academicSession],
      ['Fee Category / Description', receipt.feeTypeName],
      ['Amount Paid (USD)', receipt.amountPaid.toFixed(2)],
      ['Amount in Words', receipt.amountInWords],
      ['Payment Mode', receipt.paymentMode],
      ['Transaction Reference', receipt.transactionReference || 'N/A'],
      ['Outstanding Balance After Payment', receipt.outstandingBalanceAfterPayment.toFixed(2)],
      ['Received By', receipt.receivedBy],
      ['Receipt Status', receipt.isVoided ? `CANCELLED / VOIDED (${receipt.voidReason})` : 'OFFICIAL VALID'],
      ['Institution Name', receipt.schoolDetails?.name || 'Electrix Institute of Technology (EIT)'],
      ['Institution Address', receipt.schoolDetails?.address || 'EIT Technology Campus, Chennai, Tamil Nadu - 600127'],
    ]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Receipt_${receipt.receiptNumber}_${receipt.studentRegistrationNumber}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border border-[#cbd5e1] animate-in fade-in zoom-in-95 duration-150 my-8">
        {/* Modal Controls Bar */}
        <div className="p-4 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                <span>Official Fee Receipt</span>
                <span className="font-mono text-xs bg-blue-100 text-[#1e3a8a] px-2 py-0.5 rounded font-bold">
                  {receipt.receiptNumber}
                </span>
                {receipt.isVoided && (
                  <Badge variant="rose" size="sm">
                    VOIDED / CANCELLED
                  </Badge>
                )}
              </h3>
              <p className="text-[11px] text-[#64748b]">
                Verified university fee voucher with cryptographic audit watermark.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownloadCsv}
              leftIcon={<Download className="w-3.5 h-3.5" />}
              className="text-xs cursor-pointer"
            >
              CSV
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handlePrint}
              leftIcon={<Printer className="w-3.5 h-3.5" />}
              className="text-xs bg-[#1e3a8a] hover:bg-[#172554] cursor-pointer"
            >
              Print Receipt
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div ref={printContainerRef} className="p-6 sm:p-8 bg-white space-y-6 font-sans">
          {receipt.isVoided && (
            <div className="p-3 bg-red-100 border-2 border-red-400 rounded-xl text-center text-red-900 font-bold text-sm tracking-widest uppercase">
              *** TRANSACTION CANCELLED / VOIDED — {receipt.voidReason || 'REVERSED'} ***
            </div>
          )}

          {/* Header */}
          <div className="text-center border-b-2 border-slate-900 pb-5">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center font-black text-sm">
                EIT
              </div>
              <h2 className="text-lg font-black text-[#1e3a8a] tracking-tight">
                {receipt.schoolDetails?.name || 'Electrix Institute of Technology (EIT)'}
              </h2>
            </div>
            <p className="text-xs text-[#475569] font-medium">
              {receipt.schoolDetails?.address || 'EIT Technology Campus, Chennai, Tamil Nadu - 600127'}
            </p>
            <p className="text-[11px] text-[#64748b]">
              {receipt.schoolDetails?.affiliation || 'Approved by AICTE • Accredited Grade A++'} &bull; Phone:{' '}
              {receipt.schoolDetails?.phone || '+91 44 2839 0000'}
            </p>
            <div className="mt-3 inline-block bg-[#1e3a8a] text-white px-4 py-1 rounded-full text-xs font-bold tracking-wider uppercase">
              Official University Fee Receipt
            </div>
          </div>

          {/* Meta Table: 2 columns */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5 p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0]">
              <div className="text-[#64748b] font-bold uppercase text-[10px] tracking-wider mb-1">
                Student Identification
              </div>
              <div>
                <span className="text-[#64748b]">Student Name: </span>
                <span className="font-bold text-[#1e293b]">{receipt.studentName}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Registration No: </span>
                <span className="font-mono font-bold text-[#1e3a8a]">{receipt.studentRegistrationNumber}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Programme: </span>
                <span className="font-semibold text-[#1e293b]">{receipt.className}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Section / Cohort: </span>
                <span className="font-semibold text-[#1e293b]">Section {receipt.section}</span>
              </div>
            </div>

            <div className="space-y-1.5 p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0]">
              <div className="text-[#64748b] font-bold uppercase text-[10px] tracking-wider mb-1">
                Receipt Reference
              </div>
              <div>
                <span className="text-[#64748b]">Receipt Number: </span>
                <span className="font-mono font-bold text-[#1e3a8a]">{receipt.receiptNumber}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Payment Ref: </span>
                <span className="font-mono font-semibold text-[#1e293b]">{receipt.paymentId}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Receipt Date: </span>
                <span className="font-bold text-[#1e293b]">{receipt.receiptDate}</span>
              </div>
              <div>
                <span className="text-[#64748b]">Academic Session: </span>
                <span className="font-semibold text-[#1e293b]">{receipt.academicSession}</span>
              </div>
            </div>
          </div>

          {/* Fee Item Table */}
          <div className="border border-[#cbd5e1] rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f1f5f9] text-[#475569] font-bold border-b border-[#cbd5e1]">
                <tr>
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">Particulars / Description</th>
                  <th className="py-2.5 px-3">Mode</th>
                  <th className="py-2.5 px-3 text-right">Amount (USD)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                <tr>
                  <td className="py-3 px-3 font-mono text-[#64748b]">01</td>
                  <td className="py-3 px-3">
                    <span className="font-bold text-[#1e293b] block">{receipt.feeTypeName}</span>
                    <span className="text-[10px] text-[#64748b]">
                      Ref: {receipt.transactionReference || 'Direct Bank Settlement'}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-medium">
                      {receipt.paymentMode}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-sm text-[#1e293b]">
                    ${receipt.amountPaid.toFixed(2)}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-[#f8fafc] border-t-2 border-slate-900 font-bold">
                <tr>
                  <td colSpan={3} className="py-2.5 px-3 text-right text-xs uppercase tracking-wider text-[#475569]">
                    Total Amount Received:
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-base font-black text-emerald-800">
                    ${receipt.amountPaid.toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Amount in words & Balance */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-1">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[10px] font-bold text-[#64748b] uppercase block mb-0.5">
                Amount in Words
              </span>
              <span className="font-semibold text-[#1e293b] italic">
                {receipt.amountInWords || `${receipt.amountPaid} Dollars Only`}
              </span>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-800 uppercase block">
                  Outstanding Dues Remaining
                </span>
                <span className="text-[11px] text-amber-700">Account balance after voucher</span>
              </div>
              <span className="text-base font-mono font-black text-amber-900">
                ${receipt.outstandingBalanceAfterPayment.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Verification Footer & Signatures */}
          <div className="pt-6 border-t border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-slate-100 border border-slate-300 flex items-center justify-center text-slate-600">
                <QrCode className="w-8 h-8" />
              </div>
              <div>
                <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Digitally Generated & Verified</span>
                </div>
                <p className="text-[10px] text-[#64748b]">
                  Authentic EIT Accounts Finance Gateway document. Valid without physical stamp.
                </p>
              </div>
            </div>

            <div className="text-right">
              <div className="border-b border-slate-400 w-36 mb-1 ml-auto" />
              <span className="font-bold text-[#1e293b] block">{receipt.receivedBy}</span>
              <span className="text-[10px] text-[#64748b]">Authorized Finance Officer</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
