import React, { useState, useMemo } from 'react';
import { 
  Award, 
  Search, 
  Plus, 
  Filter, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Users, 
  DollarSign, 
  GraduationCap, 
  FileText,
  Download,
  Info
} from 'lucide-react';
import { 
  AdjustmentStatus, 
  AdjustmentType, 
  FeeAdjustmentRecord, 
  StudentRecord 
} from '../../types';

interface ScholarshipsConcessionsViewProps {
  adjustments: FeeAdjustmentRecord[];
  students: StudentRecord[];
  onOpenAwardModal: () => void;
  onRefresh: () => void;
}

export const ScholarshipsConcessionsView: React.FC<ScholarshipsConcessionsViewProps> = ({
  adjustments,
  students,
  onOpenAwardModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | AdjustmentType>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | AdjustmentStatus>('ALL');

  // Filter adjustments for scholarships and waivers
  const scholarshipRecords = useMemo(() => {
    return adjustments.filter(adj => 
      adj.adjustment_type === AdjustmentType.SCHOLARSHIP || 
      adj.adjustment_type === AdjustmentType.FEE_WAIVER ||
      adj.adjustment_type === AdjustmentType.MERIT_DISCOUNT ||
      adj.adjustment_type === AdjustmentType.FINANCIAL_AID ||
      adj.adjustment_type === AdjustmentType.CONCESSION
    );
  }, [adjustments]);

  // Compute metrics
  const stats = useMemo(() => {
    const approved = scholarshipRecords.filter(r => r.status === AdjustmentStatus.APPROVED);
    const totalDisbursed = approved.reduce((sum, r) => sum + r.amount, 0);
    const uniqueStudents = new Set(approved.map(r => r.student_id)).size;
    const pendingCount = scholarshipRecords.filter(r => r.status === AdjustmentStatus.PENDING_APPROVAL).length;
    const meritScholarships = approved.filter(r => r.adjustment_type === AdjustmentType.SCHOLARSHIP || r.adjustment_type === AdjustmentType.MERIT_DISCOUNT).length;
    const needWaivers = approved.filter(r => r.adjustment_type === AdjustmentType.FEE_WAIVER || r.adjustment_type === AdjustmentType.FINANCIAL_AID).length;

    return {
      totalDisbursed,
      uniqueStudents,
      pendingCount,
      meritScholarships,
      needWaivers,
      totalRecords: scholarshipRecords.length
    };
  }, [scholarshipRecords]);

  // Filtered list
  const filteredRecords = useMemo(() => {
    return scholarshipRecords.filter(rec => {
      const student = students.find(s => s.student_id === rec.student_id);
      const matchesSearch = 
        rec.student_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (student && `${student.first_name} ${student.last_name}`.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (student && student.program_name.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesType = typeFilter === 'ALL' || rec.adjustment_type === typeFilter;
      const matchesStatus = statusFilter === 'ALL' || rec.status === statusFilter;

      return matchesSearch && matchesType && matchesStatus;
    });
  }, [scholarshipRecords, students, searchTerm, typeFilter, statusFilter]);

  const handleExportCSV = () => {
    const headers = ['Record ID', 'Student ID', 'Student Name', 'Programme', 'Category', 'Amount', 'Status', 'Date', 'Reason'];
    const rows = filteredRecords.map(r => {
      const student = students.find(s => s.student_id === r.student_id);
      return [
        r.adjustment_id,
        r.student_id,
        student ? `"${student.first_name} ${student.last_name}"` : 'Unknown',
        student ? student.program_name : 'N/A',
        r.adjustment_type,
        r.amount,
        r.status,
        new Date(r.created_at).toLocaleDateString(),
        `"${r.reason.replace(/"/g, '""')}"`
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EIT_Scholarships_Concessions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-purple-100 text-purple-700 rounded-lg">
              <Award className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-800">Scholarships & Institutional Concessions</h1>
          </div>
          <p className="text-sm text-slate-500 mt-1">
            Manage institutional merit scholarships, economic fee waivers, affirmative endowments, and administrative concessions.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 border border-slate-300 text-slate-700 bg-white hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Export Registry
          </button>
          <button
            onClick={onOpenAwardModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-semibold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            Award Scholarship / Waiver
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Aid Disbursed</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold text-slate-800 mt-2">
            ${stats.totalDisbursed.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Approved fee remissions & bursaries
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Students Benefited</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-bold text-slate-800 mt-2">
            {stats.uniqueStudents}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Undergraduate scholars on aid
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Merit vs Need</span>
            <GraduationCap className="w-4 h-4 text-purple-600" />
          </div>
          <p className="text-2xl font-bold text-slate-800 mt-2">
            {stats.meritScholarships} / {stats.needWaivers}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Merit scholars / Economic waivers
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Pending Approvals</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-amber-600 mt-2">
            {stats.pendingCount}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Awaiting 2nd actor verification
          </p>
        </div>
      </div>

      {/* Available Schemes Card */}
      <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white rounded-xl p-6 shadow-sm">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-purple-300" />
          Approved EIT Institutional Aid Schemes (AY 2024-2025)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">Dean's Merit Scholarship</span>
              <span className="text-xs px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded font-mono">Up to $2,000</span>
            </div>
            <p className="text-xs text-purple-200 mt-1.5">
              Awarded to high academic rank holders (CGPA ≥ 9.0) in accredited B.Tech programmes.
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">EWS Educational Waiver</span>
              <span className="text-xs px-2 py-0.5 bg-blue-500/20 text-blue-300 rounded font-mono">Partial Tuition</span>
            </div>
            <p className="text-xs text-purple-200 mt-1.5">
              Economically weaker section waiver for candidates meeting state income thresholds.
            </p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">Sports & Cultural Bursary</span>
              <span className="text-xs px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded font-mono">Discretionary</span>
            </div>
            <p className="text-xs text-purple-200 mt-1.5">
              Approved concessions for university, state and national athletic tournament athletes.
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student, reg no, reason..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Filter className="w-3.5 h-3.5" />
            <span>Category:</span>
          </div>
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value as any)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          >
            <option value="ALL">All Categories</option>
            <option value={AdjustmentType.SCHOLARSHIP}>Merit Scholarship</option>
            <option value={AdjustmentType.MERIT_DISCOUNT}>Merit Discount</option>
            <option value={AdjustmentType.FEE_WAIVER}>Fee Waiver</option>
            <option value={AdjustmentType.FINANCIAL_AID}>Financial Aid</option>
            <option value={AdjustmentType.CONCESSION}>Concession</option>
          </select>

          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
            className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm focus:outline-hidden focus:ring-2 focus:ring-purple-500"
          >
            <option value="ALL">All Statuses</option>
            <option value={AdjustmentStatus.APPROVED}>Approved</option>
            <option value={AdjustmentStatus.PENDING_APPROVAL}>Pending Approval</option>
            <option value={AdjustmentStatus.REJECTED}>Rejected</option>
          </select>
        </div>
      </div>

      {/* Awards Registry Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-semibold text-slate-800">Aid & Concession Registry ({filteredRecords.length})</h3>
          <span className="text-xs text-slate-500">Authoritative adjustments ledger</span>
        </div>

        {filteredRecords.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-semibold text-slate-700">No scholarship records found</h4>
            <p className="text-sm text-slate-500 mt-1 max-w-sm mx-auto">
              There are no active scholarship or concession entries matching your current filters.
            </p>
            <button
              onClick={onOpenAwardModal}
              className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Award New Concession
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3">Student & Programme</th>
                  <th className="px-6 py-3">Type</th>
                  <th className="px-6 py-3">Amount</th>
                  <th className="px-6 py-3">Reason / Justification</th>
                  <th className="px-6 py-3">Date</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3">Requested By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredRecords.map(rec => {
                  const student = students.find(s => s.student_id === rec.student_id);
                  return (
                    <tr key={rec.adjustment_id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-900">
                          {student ? `${student.first_name} ${student.last_name}` : rec.student_id}
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="font-mono">{rec.student_id}</span>
                          {student && <span>• {student.program_name}</span>}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          rec.adjustment_type === AdjustmentType.SCHOLARSHIP
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {rec.adjustment_type}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-semibold text-slate-900">
                        ${rec.amount.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 max-w-xs truncate" title={rec.reason}>
                        {rec.reason}
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-500">
                        {new Date(rec.created_at).toLocaleDateString(undefined, {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </td>
                      <td className="px-6 py-4">
                        {rec.status === AdjustmentStatus.APPROVED ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                            <CheckCircle className="w-3 h-3" />
                            Approved
                          </span>
                        ) : rec.status === AdjustmentStatus.REJECTED ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800">
                            <AlertCircle className="w-3 h-3" />
                            Rejected
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                            <Clock className="w-3 h-3" />
                            Pending
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-xs text-slate-500">
                        {rec.requested_by}
                        {rec.approved_by && (
                          <div className="text-[10px] text-emerald-600">
                            Approved by: {rec.approved_by}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audit & Compliance notice */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-amber-800 text-xs leading-relaxed">
        <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-semibold">Institutional Governance Notice</p>
          <p className="mt-0.5 text-amber-700">
            All scholarship and waiver disbursements are bound by institutional segregation of duties. 
            Adjustments initiated by a finance officer require secondary executive confirmation before credit applies 
            to student ledger statements.
          </p>
        </div>
      </div>
    </div>
  );
};
