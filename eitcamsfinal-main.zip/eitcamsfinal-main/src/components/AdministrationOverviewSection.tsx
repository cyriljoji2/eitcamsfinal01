import { useMemo } from 'react';
import {
  ArrowRight,
  Building2,
  Shield,
  UploadCloud,
  UserCheck,
  UserPlus,
  Users,
  UserX,
} from 'lucide-react';
import {
  DepartmentRecord,
  EmployeeCategory,
  EmployeeRecord,
  EmploymentStatus,
  OfficeAssignmentRecord,
} from '../types/database';
import { SIX_PERMANENT_OFFICES } from '../config/permanentOffices';

interface AdministrationOverviewSectionProps {
  employees: EmployeeRecord[];
  officeAssignments: OfficeAssignmentRecord[];
  departments: DepartmentRecord[];
  onNavigateToEmployees: () => void;
  onNavigateToBulkImport: () => void;
  onOpenAddEmployeeModal: () => void;
}

export function AdministrationOverviewSection({
  employees,
  officeAssignments,
  departments,
  onNavigateToEmployees,
  onNavigateToBulkImport,
  onOpenAddEmployeeModal,
}: AdministrationOverviewSectionProps) {
  // 1. Metric Calculations
  const totalEmployees = employees.length;
  const activeEmployees = useMemo(
    () => employees.filter((e) => e.employment_status === EmploymentStatus.ACTIVE).length,
    [employees]
  );
  const inactiveEmployees = useMemo(
    () => employees.filter((e) => e.employment_status !== EmploymentStatus.ACTIVE).length,
    [employees]
  );
  const activePercent = totalEmployees > 0 ? Math.round((activeEmployees / totalEmployees) * 100) : 100;

  // Distinct offices and academic departments count
  const distinctDeptsCount = useMemo(() => {
    const deptCodes = new Set<string>();
    SIX_PERMANENT_OFFICES.forEach((o) => deptCodes.add(o.office_code));
    departments.forEach((d) => deptCodes.add(d.code));
    employees.forEach((e) => {
      if (e.primary_department) deptCodes.add(e.primary_department);
    });
    // Ensure standard institutional departments are accounted for
    ['CSE', 'ECE', 'MECH', 'EEE', 'CIVIL', 'IT', 'AIDS', 'BME', 'MATH', 'PHY', 'CHEM', 'HUM'].forEach((c) =>
      deptCodes.add(c)
    );
    return deptCodes.size;
  }, [departments, employees]);

  // 2. Employees by System Role Breakdown
  const roleBreakdown = useMemo(() => {
    const teachingCount = employees.filter((e) => e.category === EmployeeCategory.TEACHING).length;

    // Counts for permanent offices from active assignments + canonical seed
    const getOfficeCount = (officeId: string) => {
      const assigned = officeAssignments.filter(
        (a) => a.office_id === officeId && a.assignment_status === 'ACTIVE'
      ).length;
      return Math.max(1, assigned); // Each canonical office has at least 1 core officer
    };

    const adminOfficeCount = getOfficeCount('PO-001');
    const admissionsCount = getOfficeCount('PO-002');
    const academicCount = getOfficeCount('PO-003');
    const coeCount = getOfficeCount('PO-004');
    const financeCount = getOfficeCount('PO-005');
    const hostelCount = getOfficeCount('PO-006');

    const totalCalculated =
      adminOfficeCount +
      academicCount +
      admissionsCount +
      financeCount +
      coeCount +
      hostelCount +
      teachingCount || 1;

    const computePct = (cnt: number) => {
      const pct = Math.round((cnt / totalCalculated) * 100);
      return Math.max(1, pct);
    };

    return [
      {
        name: 'Super Admin / Administration',
        count: adminOfficeCount,
        percent: computePct(adminOfficeCount),
      },
      {
        name: 'Academic Office',
        count: academicCount,
        percent: computePct(academicCount),
      },
      {
        name: 'Admission Office',
        count: admissionsCount,
        percent: computePct(admissionsCount),
      },
      {
        name: 'Finance Office',
        count: financeCount,
        percent: computePct(financeCount),
      },
      {
        name: 'Controller of Examination',
        count: coeCount,
        percent: computePct(coeCount),
      },
      {
        name: 'Hostel & Residential Services',
        count: hostelCount,
        percent: computePct(hostelCount),
      },
      {
        name: 'Faculty Member',
        count: teachingCount,
        percent: computePct(teachingCount),
      },
    ];
  }, [employees, officeAssignments]);

  // 3. Department Headcounts List
  const departmentHeadcounts = useMemo(() => {
    // Permanent Offices
    const permanentEntries = SIX_PERMANENT_OFFICES.map((off) => {
      const staffInOffice = officeAssignments.filter(
        (a) => a.office_id === off.office_id && a.assignment_status === 'ACTIVE'
      ).length;
      return {
        id: off.office_id,
        name: off.office_name,
        code: off.office_code,
        staffCount: Math.max(1, staffInOffice),
      };
    });

    // Academic Departments
    const academicDeptNames: Record<string, string> = {
      CSE: 'Department of Computer Science & Engineering',
      ECE: 'Department of Electronics & Communication',
      MECH: 'Department of Mechanical Engineering',
      EEE: 'Department of Electrical & Electronics Engineering',
      CIVIL: 'Department of Civil Engineering',
      IT: 'Department of Information Technology',
      AIDS: 'Department of AI & Data Science',
      BME: 'Department of Biomedical Engineering',
      MATH: 'Department of Mathematics & Computing',
      PHY: 'Department of Physics & Materials',
      CHEM: 'Department of Chemical Sciences',
      HUM: 'Department of Humanities & Management',
    };

    const academicEntries = Object.entries(academicDeptNames).map(([code, name]) => {
      const facultyInDept = employees.filter(
        (e) => e.primary_department?.toUpperCase() === code
      ).length;
      return {
        id: `DEPT-${code}`,
        name,
        code,
        staffCount: facultyInDept,
      };
    });

    return [...permanentEntries, ...academicEntries];
  }, [employees, officeAssignments]);

  return (
    <div className="space-y-6">
      {/* Top Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Institutional Administration Overview
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Central dashboard for staff rosters, role provisioning, credential management, and institutional settings.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onNavigateToBulkImport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <UploadCloud className="w-4 h-4 text-slate-500" />
            <span>Import CSV</span>
          </button>

          <button
            type="button"
            onClick={onOpenAddEmployeeModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#1E3A8A] hover:bg-[#162D6E] text-white font-semibold text-sm rounded-xl shadow-sm transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* 4 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Employees */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Total Employees
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Users className="w-4 h-4 stroke-[2]" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-mono">
              {totalEmployees}
            </div>
            <p className="text-xs text-slate-500 mt-1">Registered in school roster</p>
          </div>
        </div>

        {/* Active Accounts */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Active Accounts
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <UserCheck className="w-4 h-4 stroke-[2]" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-emerald-600 tracking-tight font-mono">
              {activeEmployees}
            </div>
            <p className="text-xs text-slate-500 mt-1">{activePercent}% active access</p>
          </div>
        </div>

        {/* Inactive / Suspended */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Inactive / Suspended
            </span>
            <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center shrink-0">
              <UserX className="w-4 h-4 stroke-[2]" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-slate-900 tracking-tight font-mono">
              {inactiveEmployees}
            </div>
            <p className="text-xs text-slate-500 mt-1">Access revoked</p>
          </div>
        </div>

        {/* Departments */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#1E3A8A] uppercase tracking-wider">
              Departments
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Building2 className="w-4 h-4 stroke-[2]" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-3xl font-extrabold text-[#1E3A8A] tracking-tight font-mono">
              {distinctDeptsCount}
            </div>
            <p className="text-xs text-slate-500 mt-1">Offices &amp; divisions</p>
          </div>
        </div>
      </div>

      {/* Two Overview Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Panel: Employees by System Role */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <Shield className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
              <h2 className="text-base font-bold text-slate-900">Employees by System Role</h2>
            </div>
            <button
              type="button"
              onClick={onNavigateToEmployees}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#1E3A8A] hover:underline cursor-pointer"
            >
              <span>View Roster</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-4">
            {roleBreakdown.map((role) => (
              <div key={role.name} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800">{role.name}</span>
                  <span className="font-mono text-slate-500 font-medium">
                    {role.count} staff ({role.percent}%)
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#1E3A8A] rounded-full transition-all duration-300"
                    style={{ width: `${Math.max(2, role.percent)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Panel: Department Headcounts */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <Building2 className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
              <h2 className="text-base font-bold text-slate-900">Department Headcounts</h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              {departmentHeadcounts.length} Active Offices
            </span>
          </div>

          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {departmentHeadcounts.map((dept) => (
              <div
                key={dept.id}
                className="bg-slate-50/70 border border-slate-200/80 rounded-xl px-4 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <div className="min-w-0 pr-3">
                  <span className="text-sm font-semibold text-slate-800 block truncate">
                    {dept.name}
                  </span>
                </div>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-[#1E3A8A] border border-blue-100/80 shrink-0 font-mono">
                  {dept.staffCount} staff
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
