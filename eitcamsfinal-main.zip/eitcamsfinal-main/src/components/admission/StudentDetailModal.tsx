import React, { useState } from 'react';
import {
  X,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Building,
  User,
  Users,
  Shield,
  FileText,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  FileCheck2,
  Clock,
  Award,
  History,
  XCircle,
  Copy,
  Check,
} from 'lucide-react';
import {
  ApplicantRecord,
  ApplicationStatus,
  DocumentVerificationStatus,
  DocumentSubmissionStatus,
} from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface StudentDetailModalProps {
  isOpen: boolean;
  applicant: ApplicantRecord | null;
  onClose: () => void;
  onUpdateStatus: (applicantId: string, newStatus: ApplicationStatus, reason?: string) => Promise<void>;
  onVerifyDocument: (applicationId: string, documentId: string, status: 'VERIFIED' | 'REJECTED' | 'PENDING', notes: string) => Promise<void>;
  onConvertToStudent: (applicantId: string) => Promise<void>;
  onOpenCredentialsSlip?: (applicant: ApplicantRecord) => void;
  hasApprovePermission: boolean;
}

export function StudentDetailModal({
  isOpen,
  applicant,
  onClose,
  onUpdateStatus,
  onVerifyDocument,
  onConvertToStudent,
  onOpenCredentialsSlip,
  hasApprovePermission,
}: StudentDetailModalProps) {
  if (!isOpen || !applicant) return null;

  const [activeTab, setActiveTab] = useState<'profile' | 'guardian' | 'education' | 'programme' | 'documents' | 'lifecycle'>('profile');
  const [isProcessing, setIsProcessing] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectInput, setShowRejectInput] = useState(false);
  const [docReviewerNotes, setDocReviewerNotes] = useState<Record<string, string>>({});
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getStatusBadge = (status: ApplicationStatus, converted?: boolean) => {
    if (converted) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>Enrolled Student</span>
        </span>
      );
    }
    switch (status) {
      case ApplicationStatus.APPROVED:
        return <Badge variant="emerald">Approved</Badge>;
      case ApplicationStatus.UNDER_REVIEW:
        return <Badge variant="blue">Under Review</Badge>;
      case ApplicationStatus.DOCUMENTS_PENDING:
        return <Badge variant="amber">Docs Pending</Badge>;
      case ApplicationStatus.SUBMITTED:
        return <Badge variant="purple">Submitted</Badge>;
      case ApplicationStatus.REJECTED:
        return <Badge variant="rose">Rejected</Badge>;
      case ApplicationStatus.WITHDRAWN:
        return <Badge variant="neutral">Withdrawn</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  const handleDocDecision = async (docId: string, status: 'VERIFIED' | 'REJECTED' | 'PENDING') => {
    try {
      setIsProcessing(true);
      setActionError(null);
      const note = docReviewerNotes[docId] || (status === 'VERIFIED' ? 'Verified by Admissions Officer' : 'Decision updated');
      await onVerifyDocument(applicant.application_id, docId, status, note);
      setActionSuccess(`Checklist document status updated to ${status}.`);
      setTimeout(() => setActionSuccess(null), 3000);
    } catch (err: any) {
      setActionError(err?.message || 'Failed to update document status.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleApprove = async () => {
    try {
      setIsProcessing(true);
      setActionError(null);
      await onUpdateStatus(
        applicant.application_id,
        ApplicationStatus.APPROVED,
        'All mandatory academic and eligibility documents verified.'
      );
      setActionSuccess('Application successfully approved! It is now eligible for student enrollment.');
    } catch (err: any) {
      setActionError(err?.message || 'Failed to approve application.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRejectConfirm = async () => {
    if (!rejectReason.trim()) {
      setActionError('A valid decision reason is mandatory to reject an application.');
      return;
    }
    try {
      setIsProcessing(true);
      setActionError(null);
      await onUpdateStatus(applicant.application_id, ApplicationStatus.REJECTED, rejectReason.trim());
      setShowRejectInput(false);
      setActionSuccess('Application has been formally rejected.');
    } catch (err: any) {
      setActionError(err?.message || 'Failed to reject application.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConvert = async () => {
    try {
      setIsProcessing(true);
      setActionError(null);
      await onConvertToStudent(applicant.application_id);
      setActionSuccess('Applicant successfully converted to enrolled student! Official Registration Number allocated.');
    } catch (err: any) {
      setActionError(err?.message || 'Failed to convert applicant to student.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              {applicant.first_name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[17px] font-bold text-[#1e293b]">
                  {applicant.first_name} {applicant.last_name}
                </h3>
                {getStatusBadge(applicant.application_status, applicant.converted_to_student)}
              </div>
              <div className="flex items-center gap-3 text-xs text-[#64748b] mt-0.5">
                <span className="font-mono font-bold text-[#1e3a8a]">ID: {applicant.application_id}</span>
                <span>&bull;</span>
                <span>Intake: {applicant.admission_year}</span>
                <span>&bull;</span>
                <span>Submitted: {applicant.application_date}</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white border-b border-[#e2e8f0] px-6 flex items-center gap-4 text-xs font-semibold shrink-0 overflow-x-auto">
          {[
            { id: 'profile', label: 'Candidate Profile' },
            { id: 'guardian', label: 'Parent / Guardian' },
            { id: 'education', label: 'Education & Entrance' },
            { id: 'programme', label: 'Programme & Department' },
            { id: 'documents', label: `Documents (${applicant.documents?.length || 0})` },
            { id: 'lifecycle', label: `Audit Trail (${applicant.status_history?.length || 0})` },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-[#1e3a8a] text-[#1e3a8a] font-bold'
                  : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {actionError && (
            <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{actionError}</span>
            </div>
          )}

          {actionSuccess && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{actionSuccess}</span>
            </div>
          )}

          {/* Enrolled Student Banner if Converted */}
          {applicant.converted_to_student && (
            <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-purple-900">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">Officially Enrolled University Student</span>
                    <Badge variant="purple" size="sm">Active Account</Badge>
                  </div>
                  <div className="font-mono text-xs mt-0.5">
                    Registration Number: <strong className="text-purple-950">{applicant.student_registration_number}</strong> &bull; Student ID: {applicant.student_id}
                  </div>
                </div>
              </div>

              {onOpenCredentialsSlip && (
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-white border-purple-300 text-purple-900 hover:bg-purple-100"
                  onClick={() => onOpenCredentialsSlip(applicant)}
                  leftIcon={<KeyRound className="w-3.5 h-3.5" />}
                >
                  View Credentials Slip
                </Button>
              )}
            </div>
          )}

          {/* TAB 1: Profile */}
          {activeTab === 'profile' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-2.5">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                  Identity & Demographics
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[#64748b] block">Full Name:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.first_name} {applicant.last_name}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Date of Birth:</span>
                    <span className="font-mono text-[#1e293b]">{applicant.date_of_birth}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Gender:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.gender}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Nationality:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.nationality || 'Indian'}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-2.5">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                  Contact Information
                </span>
                <div>
                  <span className="text-[#64748b] block">Direct Email:</span>
                  <span className="font-mono font-semibold text-[#1e293b]">{applicant.email}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Mobile Phone:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.phone_number}</span>
                </div>
                {applicant.alternate_phone && (
                  <div>
                    <span className="text-[#64748b] block">Alternate Phone:</span>
                    <span className="text-[#1e293b]">{applicant.alternate_phone}</span>
                  </div>
                )}
              </div>

              <div className="sm:col-span-2 p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-2">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                  Addresses
                </span>
                <div>
                  <span className="text-[#64748b] block font-medium">Current Address:</span>
                  <span className="text-[#1e293b]">{applicant.current_address || applicant.address}</span>
                </div>
                {applicant.permanent_address && (
                  <div className="pt-2 border-t border-[#e2e8f0]">
                    <span className="text-[#64748b] block font-medium">Permanent Hometown Address:</span>
                    <span className="text-[#1e293b]">{applicant.permanent_address}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: Guardian */}
          {activeTab === 'guardian' && (
            <div className="p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-3 text-xs">
              <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                Parent & Guardian Records
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <span className="text-[#64748b] block">Guardian Full Name:</span>
                  <span className="font-semibold text-sm text-[#1e293b]">
                    {applicant.guardian_name || 'Not recorded'}
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Relationship:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.guardian_relationship || 'Parent'}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Contact Phone:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.guardian_phone || applicant.phone_number}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Contact Email:</span>
                  <span className="font-mono text-[#1e293b]">{applicant.guardian_email || 'N/A'}</span>
                </div>
              </div>
              {applicant.guardian_address && (
                <div className="pt-2 border-t border-[#e2e8f0]">
                  <span className="text-[#64748b] block">Workplace / Official Address:</span>
                  <span className="text-[#1e293b]">{applicant.guardian_address}</span>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Education & Entrance */}
          {activeTab === 'education' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-3">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                  Qualifying Education
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[#64748b] block">Previous Institution:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.previous_institution || 'Secondary School'}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Board / University:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.board_or_university || 'State/Central Board'}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Qualification:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.previous_qualification}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Passing Year:</span>
                    <span className="font-mono text-[#1e293b]">{applicant.completion_year || applicant.admission_year}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Qualifying Marks / Percentage:</span>
                    <span className="font-mono font-bold text-emerald-800 text-sm">
                      {applicant.marks_percentage}% {applicant.cgpa ? `(CGPA: ${applicant.cgpa})` : ''}
                    </span>
                  </div>
                  {applicant.exam_roll_number && (
                    <div>
                      <span className="text-[#64748b] block">Roll / Reg Number:</span>
                      <span className="font-mono text-[#1e293b]">{applicant.exam_roll_number}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Entrance Examination */}
              <div className="p-4 bg-[#eff6ff]/60 rounded-xl border border-[#dbeafe] space-y-3">
                <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                  National / State Entrance Examination Credentials
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[#64748b] block">Examination Name:</span>
                    <span className="font-semibold text-[#1e293b]">{applicant.entrance_exam_name || 'Direct Merit Intake'}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block">Score / Percentile / Rank:</span>
                    <span className="font-bold text-[#1e3a8a]">{applicant.entrance_exam_score || 'Qualifying Marks Cleared'}</span>
                  </div>
                  {applicant.entrance_exam_roll && (
                    <div>
                      <span className="text-[#64748b] block">Roll Number:</span>
                      <span className="font-mono text-[#1e293b]">{applicant.entrance_exam_roll}</span>
                    </div>
                  )}
                  {applicant.entrance_exam_year && (
                    <div>
                      <span className="text-[#64748b] block">Exam Year:</span>
                      <span className="font-mono text-[#1e293b]">{applicant.entrance_exam_year}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Programme & Department */}
          {activeTab === 'programme' && (
            <div className="p-4 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-3 text-xs">
              <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                Academic Curriculum Allocation
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <span className="text-[#64748b] block">Intended Degree Programme:</span>
                  <span className="font-bold text-sm text-[#1e293b]">{applicant.intended_program}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Department Code:</span>
                  <span className="font-mono font-bold text-[#1e3a8a] text-sm">{applicant.department}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Academic Intake Year:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.admission_year}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Admission Quota / Category:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.admission_category || 'General Merit'}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Degree Level:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.degree_level || 'UNDERGRADUATE'}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Study Mode:</span>
                  <span className="font-semibold text-[#1e293b]">{applicant.study_mode || 'Full-Time On-Campus'}</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Documents Checklist */}
          {activeTab === 'documents' && (
            <div className="space-y-3 text-xs">
              <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                Document Checklist & Verification Decision
              </span>

              <div className="space-y-2">
                {(applicant.documents || []).length === 0 ? (
                  <p className="text-center py-6 text-[#94a3b8]">No document records associated with this dossier.</p>
                ) : (
                  applicant.documents.map((doc) => {
                    const isVerified = doc.verification_status === 'VERIFIED';
                    const isRejected = doc.verification_status === 'REJECTED';

                    return (
                      <div
                        key={doc.document_id}
                        className="p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#1e293b]">{doc.document_type}</span>
                            <span className="font-mono text-[10px] text-[#64748b]">({doc.document_code})</span>
                            {doc.is_mandatory && (
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                                Mandatory
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-[#64748b] flex items-center gap-2">
                            <span>
                              Submission: <strong className={doc.submission_status === 'SUBMITTED' ? 'text-emerald-700' : 'text-amber-700'}>{doc.submission_status}</strong>
                            </span>
                            <span>&bull;</span>
                            <span>
                              Decision: <strong className={isVerified ? 'text-emerald-700' : isRejected ? 'text-rose-700' : 'text-amber-700'}>{doc.verification_status}</strong>
                            </span>
                            {doc.verified_by && (
                              <>
                                <span>&bull;</span>
                                <span>By: {doc.verified_by}</span>
                              </>
                            )}
                          </div>
                          {doc.reviewer_notes && (
                            <p className="text-[11px] text-[#334155] italic">Remarks: {doc.reviewer_notes}</p>
                          )}
                        </div>

                        {/* Verification Buttons */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <Button
                            variant={isVerified ? 'outline' : 'primary'}
                            size="sm"
                            className={isVerified ? 'text-emerald-800 border-emerald-300' : 'bg-emerald-700 hover:bg-emerald-800'}
                            onClick={() => handleDocDecision(doc.document_id, 'VERIFIED')}
                            disabled={isProcessing}
                            leftIcon={<Check className="w-3.5 h-3.5" />}
                          >
                            {isVerified ? 'Verified' : 'Verify'}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-rose-700 hover:bg-rose-50"
                            onClick={() => handleDocDecision(doc.document_id, 'REJECTED')}
                            disabled={isProcessing}
                            leftIcon={<XCircle className="w-3.5 h-3.5" />}
                          >
                            Reject
                          </Button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 6: Lifecycle History */}
          {activeTab === 'lifecycle' && (
            <div className="space-y-3 text-xs">
              <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                Application Status Audit Trail
              </span>

              <div className="space-y-2">
                {(applicant.status_history || []).length === 0 ? (
                  <p className="text-center py-6 text-[#94a3b8]">No status transition history recorded.</p>
                ) : (
                  applicant.status_history.map((hist, i) => (
                    <div
                      key={hist.history_id || i}
                      className="p-3 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] flex items-start gap-3"
                    >
                      <div className="w-7 h-7 rounded-full bg-blue-100 text-[#1e3a8a] flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs">
                        {i + 1}
                      </div>
                      <div className="flex-1 space-y-0.5">
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-[#1e293b]">
                            {hist.previous_status} &rarr; <span className="text-[#1e3a8a]">{hist.new_status}</span>
                          </div>
                          <span className="text-[10px] text-[#64748b]">
                            {new Date(hist.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-[#475569]">{hist.reason || hist.notes || 'Status updated by admissions workflow'}</p>
                        <span className="text-[10px] text-[#94a3b8] block">Actor: {hist.changed_by}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Rejection Justification Input Drawer */}
          {showRejectInput && (
            <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-rose-900">Mandatory Rejection Justification</span>
                <button
                  type="button"
                  onClick={() => setShowRejectInput(false)}
                  className="text-rose-700 hover:text-rose-900"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <textarea
                rows={2}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Specify reason for application rejection (e.g. minimum qualifying marks not met, invalid documentation)..."
                className="w-full px-3 py-2 text-xs rounded-lg border border-rose-300 bg-white text-[#1e293b] focus:border-rose-500 outline-none"
              />
              <div className="flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => setShowRejectInput(false)}>
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  className="bg-rose-700 hover:bg-rose-800 text-white"
                  onClick={handleRejectConfirm}
                  disabled={isProcessing}
                >
                  Confirm Rejection
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Workflow Actions */}
        <div className="bg-[#f8fafc] px-6 py-4 border-t border-[#e2e8f0] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            {applicant.application_status === ApplicationStatus.SUBMITTED && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdateStatus(applicant.application_id, ApplicationStatus.UNDER_REVIEW, 'Moved to under review scrutiny')}
                disabled={isProcessing}
                leftIcon={<Clock className="w-3.5 h-3.5" />}
              >
                Begin Scrutiny
              </Button>
            )}

            {applicant.application_status === ApplicationStatus.UNDER_REVIEW && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onUpdateStatus(applicant.application_id, ApplicationStatus.DOCUMENTS_PENDING, 'Further document uploads required')}
                  disabled={isProcessing}
                  leftIcon={<Clock className="w-3.5 h-3.5" />}
                >
                  Request Docs
                </Button>

                {hasApprovePermission && (
                  <Button
                    variant="primary"
                    size="sm"
                    className="bg-emerald-700 hover:bg-emerald-800"
                    onClick={handleApprove}
                    disabled={isProcessing}
                    leftIcon={<CheckCircle2 className="w-3.5 h-3.5" />}
                  >
                    Approve Application
                  </Button>
                )}

                <Button
                  variant="outline"
                  size="sm"
                  className="text-rose-700 border-rose-300 hover:bg-rose-50"
                  onClick={() => setShowRejectInput(true)}
                  disabled={isProcessing}
                  leftIcon={<XCircle className="w-3.5 h-3.5" />}
                >
                  Reject
                </Button>
              </>
            )}

            {applicant.application_status === ApplicationStatus.DOCUMENTS_PENDING && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onUpdateStatus(applicant.application_id, ApplicationStatus.UNDER_REVIEW, 'Resumed review following document submission')}
                disabled={isProcessing}
              >
                Resume Scrutiny
              </Button>
            )}

            {/* Convert to Student Button */}
            {applicant.application_status === ApplicationStatus.APPROVED && !applicant.converted_to_student && (
              <Button
                variant="primary"
                size="sm"
                className="bg-purple-700 hover:bg-purple-800"
                onClick={handleConvert}
                disabled={isProcessing}
                leftIcon={<GraduationCap className="w-3.5 h-3.5" />}
              >
                Convert to Enrolled Student
              </Button>
            )}
          </div>

          <Button variant="outline" size="sm" onClick={onClose}>
            Close Dossier
          </Button>
        </div>
      </div>
    </div>
  );
}
