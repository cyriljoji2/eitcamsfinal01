import React, { useState, useMemo } from 'react';
import {
  Search,
  KeyRound,
  Eye,
  Edit2,
  Power,
  RotateCcw,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  UserPlus,
  AlertCircle,
  FileCheck2,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Building2,
  Copy,
  Check,
} from 'lucide-react';
import { StudentRecord, DepartmentRecord, ProgrammeRecord, StudentStatus } from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface StudentManagementViewProps {
  students: StudentRecord[];
  departments: DepartmentRecord[];
  programmes: ProgrammeRecord[];
  onOpenNewAdmission: () => void;
  onSelectStudent: (student: StudentRecord) => void;
  onResetPassword: (student: StudentRecord) => Promise<void>;
  onToggleAccountStatus: (student: StudentRecord) => Promise<void>;
  onOpenCredentialsSlip: (student: StudentRecord) => void;
}

export function StudentManagementView({
  students,
  departments,
  programmes,
  onOpenNewAdmission,
  onSelectStudent,
  onResetPassword,
  onToggleAccountStatus,
  onOpenCredentialsSlip,
}: StudentManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [progFilter, setProgFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const q = searchTerm.toLowerCase().trim();
      const fullName = `${s.first_name} ${s.last_name}`.toLowerCase();
      const matchSearch =
        !q ||
        s.registration_number.toLowerCase().includes(q) ||
        s.student_id.toLowerCase().includes(q) ||
        fullName.includes(q) ||
        (s.institutional_email && s.institutional_email.toLowerCase().includes(q)) ||
        (s.personal_phone && s.personal_phone.includes(q));

      const matchDept = deptFilter === 'ALL' || s.department === deptFilter;
      const matchProg = progFilter === 'ALL' || s.program_name.toLowerCase() === progFilter.toLowerCase();
      const matchStatus = statusFilter === 'ALL' || s.enrollment_status === statusFilter;

      return matchSearch && matchDept && matchProg && matchStatus;
    });
  }, [students, searchTerm, deptFilter, progFilter, statusFilter]);

  const totalPages = Math.ceil(filteredStudents.length / pageSize) || 1;
  const paginatedStudents = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredStudents.slice(start, start + pageSize);
  }, [filteredStudents, currentPage, pageSize]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">University Enrolled Students Roster</h2>
          <p className="text-xs text-[#64748b]">
            Enrolled student cohort, canonical Registration Numbers, and Student Portal credentials management
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onOpenNewAdmission}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          New Student Admission
        </Button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by student name, Registration Number, email..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.department_id} value={d.code}>
                  {d.name} ({d.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Enrollment Statuses</option>
              <option value={StudentStatus.ENROLLED}>Enrolled (Active)</option>
              <option value={StudentStatus.SUSPENDED}>Suspended</option>
              <option value={StudentStatus.GRADUATED}>Graduated</option>
              <option value={StudentStatus.WITHDRAWN}>Withdrawn</option>
            </select>
          </div>
        </div>

        {/* Results Info */}
        <div className="flex items-center justify-between text-xs text-[#64748b] pt-1">
          <span>
            Total Enrolled: <strong className="text-[#1e293b]">{filteredStudents.length}</strong> university students
          </span>
          {(searchTerm || deptFilter !== 'ALL' || statusFilter !== 'ALL') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setDeptFilter('ALL');
                setStatusFilter('ALL');
                setCurrentPage(1);
              }}
              className="text-[#1e3a8a] hover:underline font-semibold cursor-pointer"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Registration No</th>
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Department & Programme</th>
                <th className="px-4 py-3">Intake Year / Semester</th>
                <th className="px-4 py-3">Enrollment Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {paginatedStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-[#94a3b8]">
                    No enrolled student records found. Convert approved applications to populate this directory.
                  </td>
                </tr>
              ) : (
                paginatedStudents.map((s) => {
                  const isCopied = copiedText === s.registration_number;

                  return (
                    <tr key={s.student_id} className="hover:bg-slate-50 transition-colors">
                      {/* Registration Number */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-[#1e3a8a] text-[13px]">
                            {s.registration_number}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopy(s.registration_number)}
                            className="text-[#94a3b8] hover:text-[#1e293b] p-0.5"
                            title="Copy Registration Number"
                          >
                            {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                        <span className="text-[10px] text-[#64748b] font-mono block">
                          ID: {s.student_id}
                        </span>
                      </td>

                      {/* Student Name & Institutional Email */}
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#1e293b]">
                          {s.first_name} {s.last_name}
                        </div>
                        <div className="text-[11px] text-[#64748b] font-mono flex items-center gap-1 mt-0.5">
                          <Mail className="w-3 h-3 text-[#94a3b8]" />
                          <span>{s.institutional_email}</span>
                        </div>
                      </td>

                      {/* Department & Programme */}
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#1e293b]">{s.program_name}</div>
                        <div className="text-[11px] text-[#64748b]">
                          Department: <strong className="font-mono text-[#1e3a8a]">{s.department}</strong>
                        </div>
                      </td>

                      {/* Intake Year & Semester */}
                      <td className="px-4 py-3">
                        <div className="text-[#334155] font-medium">Batch {s.admission_year}</div>
                        <div className="text-[11px] text-[#64748b]">
                          Semester {s.current_semester} &bull; Section {s.section || 'A'}
                        </div>
                      </td>

                      {/* Enrollment Status */}
                      <td className="px-4 py-3">
                        {s.enrollment_status === StudentStatus.ENROLLED ? (
                          <Badge variant="emerald">Enrolled</Badge>
                        ) : s.enrollment_status === StudentStatus.SUSPENDED ? (
                          <Badge variant="rose">Suspended</Badge>
                        ) : (
                          <Badge variant="neutral">{s.enrollment_status}</Badge>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onOpenCredentialsSlip(s)}
                            leftIcon={<KeyRound className="w-3.5 h-3.5" />}
                            title="Issue or print login credentials slip"
                          >
                            Credentials
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onSelectStudent(s)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                          >
                            Dossier
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
