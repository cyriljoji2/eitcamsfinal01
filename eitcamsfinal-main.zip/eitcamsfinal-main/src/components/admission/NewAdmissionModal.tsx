import React, { useState, useMemo } from 'react';
import {
  X,
  User,
  Users,
  GraduationCap,
  Building,
  FileText,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
  Calendar,
  Phone,
  Mail,
  MapPin,
  Award,
  ChevronRight,
  ChevronLeft,
  UploadCloud,
  FileCheck2,
} from 'lucide-react';
import {
  DepartmentRecord,
  ProgrammeRecord,
  ApplicationStatus,
} from '../../types/database';
import {
  UniversityAdmissionFormData,
  UNIVERSITY_DOCUMENT_TEMPLATES,
  UNIVERSITY_ADMISSION_CATEGORIES,
  UNIVERSITY_STUDY_MODES,
} from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { allocateNextApplicationId } from '../../services/regNumberGenerator';

export interface NewAdmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  departments: DepartmentRecord[];
  programmes: ProgrammeRecord[];
  existingApplicationIds: string[];
  onSubmit: (formData: UniversityAdmissionFormData) => Promise<void>;
}

export function NewAdmissionModal({
  isOpen,
  onClose,
  departments,
  programmes,
  existingApplicationIds,
  onSubmit,
}: NewAdmissionModalProps) {
  if (!isOpen) return null;

  const [activeStep, setActiveStep] = useState<1 | 2 | 3 | 4 | 5 | 6 | 7>(1);

  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [dob, setDob] = useState('2006-05-15');
  const [gender, setGender] = useState('MALE');
  const [nationality, setNationality] = useState('Indian');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('+91 98765 43210');
  const [alternatePhone, setAlternatePhone] = useState('');
  const [currentAddress, setCurrentAddress] = useState('Flat 402, Green Valley Enclave, Chennai');
  const [permanentAddress, setPermanentAddress] = useState('');
  const [sameAsCurrent, setSameAsCurrent] = useState(true);

  // Step 2: Guardian
  const [guardianName, setGuardianName] = useState('');
  const [guardianRelationship, setGuardianRelationship] = useState('Father');
  const [guardianMobile, setGuardianMobile] = useState('+91 98765 12345');
  const [guardianEmail, setGuardianEmail] = useState('');
  const [guardianAddress, setGuardianAddress] = useState('');

  // Step 3: Education
  const [previousInstitution, setPreviousInstitution] = useState('National Public School, Indiranagar');
  const [institutionType, setInstitutionType] = useState('Senior Secondary School');
  const [country, setCountry] = useState('India');
  const [boardOrUniversity, setBoardOrUniversity] = useState('CBSE');
  const [previousQualification, setPreviousQualification] = useState('Higher Secondary Certificate (10+2 PCM)');
  const [completionYear, setCompletionYear] = useState<number>(2026);
  const [examRollNumber, setExamRollNumber] = useState('CBSE-2026-981244');
  const [marksPercentage, setMarksPercentage] = useState<number>(89.5);
  const [cgpa, setCgpa] = useState<number>(9.0);

  // Step 4: Programme
  const [admissionAcademicYear, setAdmissionAcademicYear] = useState<number>(2026);
  const [departmentCode, setDepartmentCode] = useState<string>(departments[0]?.code || 'CSE');
  const [programmeCode, setProgrammeCode] = useState<string>('');
  const [degreeLevel, setDegreeLevel] = useState<string>('UNDERGRADUATE');
  const [admissionCategory, setAdmissionCategory] = useState<string>(UNIVERSITY_ADMISSION_CATEGORIES[0]);
  const [studyMode, setStudyMode] = useState<string>(UNIVERSITY_STUDY_MODES[0]);

  // Step 5: Entrance Exam
  const [entranceExamName, setEntranceExamName] = useState('JEE Main');
  const [entranceExamRoll, setEntranceExamRoll] = useState('JEE26-884102');
  const [entranceExamYear, setEntranceExamYear] = useState<number>(2026);
  const [entranceExamScore, setEntranceExamScore] = useState('96.8 Percentile (Rank 14,210)');
  const [eligibilityNotes, setEligibilityNotes] = useState('Qualifies PCM minimum threshold (>= 60%).');

  // Step 6: Documents
  const [documentsList, setDocumentsList] = useState(
    UNIVERSITY_DOCUMENT_TEMPLATES.map((tmpl: (typeof UNIVERSITY_DOCUMENT_TEMPLATES)[number]) => ({
      documentCode: tmpl.documentCode,
      documentType: tmpl.documentType,
      isMandatory: tmpl.isMandatory,
      fileName: tmpl.isMandatory ? `${tmpl.documentCode.toLowerCase()}_scan.pdf` : '',
      submissionStatus: tmpl.isMandatory ? ('SUBMITTED' as const) : ('PENDING' as const),
    }))
  );

  // State
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  // Filter programmes for selected department
  const filteredProgrammes = useMemo(() => {
    return programmes.filter((p: ProgrammeRecord) => p.department === departmentCode && p.status === 'ACTIVE');
  }, [programmes, departmentCode]);

  // Auto-select first matching programme if not selected
  const selectedProgramme = useMemo(() => {
    if (programmeCode) {
      const found = filteredProgrammes.find((p: ProgrammeRecord) => p.code === programmeCode);
      if (found) return found;
    }
    return filteredProgrammes[0] || programmes[0];
  }, [programmeCode, filteredProgrammes, programmes]);

  // Projected Application ID
  const projectedAppId = useMemo(() => {
    return allocateNextApplicationId(existingApplicationIds, admissionAcademicYear);
  }, [existingApplicationIds, admissionAcademicYear]);

  // Step validation
  const validateStep = (step: number): boolean => {
    const errs: Record<string, string> = {};

    if (step === 1) {
      if (!firstName.trim() || firstName.trim().length < 2) {
        errs.firstName = 'First name is required (minimum 2 characters).';
      }
      if (!lastName.trim() || lastName.trim().length < 1) {
        errs.lastName = 'Last name is required.';
      }
      if (!dob) {
        errs.dob = 'Date of birth is required.';
      } else {
        const birthDate = new Date(dob);
        const ageDifMs = Date.now() - birthDate.getTime();
        const age = Math.abs(new Date(ageDifMs).getUTCFullYear() - 1970);
        if (age < 14) {
          errs.dob = 'Applicant must be at least 14 years of age for university admission.';
        }
      }
      if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        errs.email = 'Valid applicant email address is required.';
      }
      if (!mobile.trim()) {
        errs.mobile = 'Contact phone number is required.';
      }
      if (!currentAddress.trim()) {
        errs.currentAddress = 'Current residential address is required.';
      }
    }

    if (step === 2) {
      if (!guardianName.trim()) {
        errs.guardianName = 'Parent or Guardian full name is required.';
      }
      if (!guardianMobile.trim()) {
        errs.guardianMobile = 'Guardian contact number is required.';
      }
    }

    if (step === 3) {
      if (!previousInstitution.trim()) {
        errs.previousInstitution = 'Previous institution name is required.';
      }
      if (!previousQualification.trim()) {
        errs.previousQualification = 'Previous qualification is required.';
      }
      if (isNaN(marksPercentage) || marksPercentage < 0 || marksPercentage > 100) {
        errs.marksPercentage = 'Marks percentage must be a number between 0 and 100.';
      }
    }

    if (step === 4) {
      if (!departmentCode) {
        errs.departmentCode = 'Academic department selection is required.';
      }
      if (!selectedProgramme) {
        errs.programmeCode = 'University degree programme is required.';
      }
    }

    if (step === 6) {
      // Mandatory documents check
      const missingMandatory = documentsList.filter(
        (d: any) => d.isMandatory && d.submissionStatus !== 'SUBMITTED'
      );
      if (missingMandatory.length > 0) {
        errs.documents = `Please confirm upload of all mandatory documents (${missingMandatory.map((m: any) => m.documentType).join(', ')}).`;
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep((prev: number) => Math.min(7, prev + 1) as any);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBack = () => {
    setActiveStep((prev: number) => Math.max(1, prev - 1) as any);
  };

  const handleToggleDoc = (docCode: string) => {
    setDocumentsList((prev: any[]) =>
      prev.map((d: any) => {
        if (d.documentCode === docCode) {
          const nextStatus = d.submissionStatus === 'SUBMITTED' ? 'PENDING' : 'SUBMITTED';
          return {
            ...d,
            submissionStatus: nextStatus,
            fileName: nextStatus === 'SUBMITTED' ? `${d.documentCode.toLowerCase()}_scan.pdf` : '',
          };
        }
        return d;
      })
    );
  };

  const handleSubmit = async (status: ApplicationStatus) => {
    // Validate all steps
    for (let s = 1; s <= 6; s++) {
      if (!validateStep(s)) {
        setActiveStep(s as any);
        return;
      }
    }

    try {
      setIsSubmitting(true);
      setSubmissionError(null);

      const payload: UniversityAdmissionFormData = {
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        dateOfBirth: dob,
        gender,
        nationality,
        email: email.trim().toLowerCase(),
        mobile: mobile.trim(),
        alternatePhone: alternatePhone.trim() || undefined,
        currentAddress: currentAddress.trim(),
        permanentAddress: sameAsCurrent ? currentAddress.trim() : permanentAddress.trim(),
        guardianName: guardianName.trim(),
        guardianRelationship,
        guardianMobile: guardianMobile.trim(),
        guardianEmail: guardianEmail.trim() || undefined,
        guardianAddress: guardianAddress.trim() || undefined,
        previousInstitution: previousInstitution.trim(),
        institutionType,
        country,
        boardOrUniversity,
        previousQualification: previousQualification.trim(),
        completionYear: Number(completionYear),
        examRollNumber: examRollNumber.trim() || undefined,
        marksPercentage: Number(marksPercentage),
        cgpa: cgpa ? Number(cgpa) : undefined,
        admissionAcademicYear,
        departmentCode,
        programmeCode: selectedProgramme?.code || 'BTECH-CSE',
        intendedProgram: selectedProgramme?.name || 'B.Tech Computer Science & Engineering',
        degreeLevel,
        admissionCategory,
        studyMode,
        entranceExamName: entranceExamName.trim() || undefined,
        entranceExamRoll: entranceExamRoll.trim() || undefined,
        entranceExamYear: Number(entranceExamYear) || undefined,
        entranceExamScore: entranceExamScore.trim() || undefined,
        eligibilityNotes: eligibilityNotes.trim() || undefined,
        documents: documentsList,
        applicationStatus: status,
      };

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setSubmissionError(err?.message || 'Failed to submit admission application.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-[17px] font-bold text-[#1e293b]">University Admission Application</h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-blue-50 text-[#1e3a8a] border border-blue-200">
                  {projectedAppId}
                </span>
              </div>
              <p className="text-xs text-[#64748b]">
                Electrix Institute of Technology &bull; Academic Intake {admissionAcademicYear}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progression Bar */}
        <div className="bg-white border-b border-[#e2e8f0] px-6 py-3 shrink-0 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[620px]">
            {[
              { num: 1, title: 'Personal Info' },
              { num: 2, title: 'Guardian' },
              { num: 3, title: 'Education' },
              { num: 4, title: 'Programme' },
              { num: 5, title: 'Entrance' },
              { num: 6, title: 'Documents' },
              { num: 7, title: 'Review' },
            ].map((step, idx) => {
              const isCurrent = activeStep === step.num;
              const isPast = activeStep > step.num;

              return (
                <React.Fragment key={step.num}>
                  <button
                    type="button"
                    onClick={() => {
                      if (isPast) setActiveStep(step.num as any);
                    }}
                    className={`flex items-center gap-2 text-xs font-semibold cursor-pointer ${
                      isCurrent
                        ? 'text-[#1e3a8a]'
                        : isPast
                        ? 'text-emerald-700'
                        : 'text-[#94a3b8]'
                    }`}
                  >
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                        isCurrent
                          ? 'bg-[#1e3a8a] text-white shadow-2xs'
                          : isPast
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-[#94a3b8]'
                      }`}
                    >
                      {isPast ? '✓' : step.num}
                    </span>
                    <span className="hidden sm:inline">{step.title}</span>
                  </button>
                  {idx < 6 && (
                    <div
                      className={`h-0.5 flex-1 mx-2 ${
                        activeStep > step.num ? 'bg-emerald-400' : 'bg-slate-200'
                      }`}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Modal Body / Steps */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {submissionError && (
            <div className="bg-rose-50 border border-rose-200 rounded-lg p-3.5 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{submissionError}</span>
            </div>
          )}

          {/* STEP 1: Personal Information */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 1: Applicant Personal Information</h4>
                <p className="text-xs text-[#64748b]">Identity, citizenship, and candidate direct contact</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    First Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. Rahul"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.firstName && <p className="text-[11px] text-rose-600 mt-1">{errors.firstName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Last Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Sharma"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.lastName && <p className="text-[11px] text-rose-600 mt-1">{errors.lastName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Date of Birth (YYYY-MM-DD) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                  {errors.dob && <p className="text-[11px] text-rose-600 mt-1">{errors.dob}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                    <option value="PREFER_NOT_TO_SAY">Prefer not to say</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Nationality</label>
                  <input
                    type="text"
                    value={nationality}
                    onChange={(e) => setNationality(e.target.value)}
                    placeholder="e.g. Indian"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Applicant Email Address <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. rahul.sharma@example.com"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.email && <p className="text-[11px] text-rose-600 mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Mobile Phone Number <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="tel"
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.mobile && <p className="text-[11px] text-rose-600 mt-1">{errors.mobile}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Alternate Phone</label>
                  <input
                    type="tel"
                    value={alternatePhone}
                    onChange={(e) => setAlternatePhone(e.target.value)}
                    placeholder="+91 98765 00000"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                  Current Residential Address <span className="text-rose-600">*</span>
                </label>
                <textarea
                  rows={2}
                  value={currentAddress}
                  onChange={(e) => setCurrentAddress(e.target.value)}
                  placeholder="Street, locality, city, state, postal code"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                />
                {errors.currentAddress && <p className="text-[11px] text-rose-600 mt-1">{errors.currentAddress}</p>}
              </div>

              <div>
                <label className="flex items-center gap-2 text-xs text-[#1e293b] font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sameAsCurrent}
                    onChange={(e) => setSameAsCurrent(e.target.checked)}
                    className="rounded text-[#1e3a8a]"
                  />
                  <span>Permanent address is same as current address</span>
                </label>
                {!sameAsCurrent && (
                  <div className="mt-2">
                    <label className="block text-xs font-semibold text-[#1e293b] mb-1">Permanent Address</label>
                    <textarea
                      rows={2}
                      value={permanentAddress}
                      onChange={(e) => setPermanentAddress(e.target.value)}
                      placeholder="Permanent hometown address"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 2: Guardian Information */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 2: Parent / Guardian Information</h4>
                <p className="text-xs text-[#64748b]">Emergency contacts and family linkages</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Parent / Guardian Full Name <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    placeholder="e.g. Ramesh Sharma"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.guardianName && <p className="text-[11px] text-rose-600 mt-1">{errors.guardianName}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Relationship</label>
                  <select
                    value={guardianRelationship}
                    onChange={(e) => setGuardianRelationship(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Legal Guardian">Legal Guardian</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Guardian Contact Phone <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="tel"
                    value={guardianMobile}
                    onChange={(e) => setGuardianMobile(e.target.value)}
                    placeholder="+91 98765 12345"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.guardianMobile && <p className="text-[11px] text-rose-600 mt-1">{errors.guardianMobile}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Guardian Email</label>
                  <input
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    placeholder="e.g. ramesh.sharma@example.com"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">Guardian Workplace / Address</label>
                <textarea
                  rows={2}
                  value={guardianAddress}
                  onChange={(e) => setGuardianAddress(e.target.value)}
                  placeholder="Guardian residential / office address"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                />
              </div>
            </div>
          )}

          {/* STEP 3: Previous Education */}
          {activeStep === 3 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 3: Previous Education & Qualifying Examination</h4>
                <p className="text-xs text-[#64748b]">Academic pedigree and qualifying secondary school or diploma records</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Previous School / College <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={previousInstitution}
                    onChange={(e) => setPreviousInstitution(e.target.value)}
                    placeholder="e.g. Delhi Public School"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.previousInstitution && <p className="text-[11px] text-rose-600 mt-1">{errors.previousInstitution}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Institution Type</label>
                  <select
                    value={institutionType}
                    onChange={(e) => setInstitutionType(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    <option value="Senior Secondary School">Senior Secondary School</option>
                    <option value="Junior College">Junior College</option>
                    <option value="Polytechnic Institute">Polytechnic Institute</option>
                    <option value="College / University">College / University</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Examining Board / University</label>
                  <input
                    type="text"
                    value={boardOrUniversity}
                    onChange={(e) => setBoardOrUniversity(e.target.value)}
                    placeholder="e.g. CBSE / State Board / University"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Previous Qualification <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={previousQualification}
                    onChange={(e) => setPreviousQualification(e.target.value)}
                    placeholder="e.g. Higher Secondary (10+2 PCM)"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                  {errors.previousQualification && <p className="text-[11px] text-rose-600 mt-1">{errors.previousQualification}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Completion Year</label>
                  <input
                    type="number"
                    value={completionYear}
                    onChange={(e) => setCompletionYear(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Exam Roll / Registration No</label>
                  <input
                    type="text"
                    value={examRollNumber}
                    onChange={(e) => setExamRollNumber(e.target.value)}
                    placeholder="e.g. 2026-CBSE-99124"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Aggregate Marks / Percentage (%) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="100"
                    value={marksPercentage}
                    onChange={(e) => setMarksPercentage(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                  {errors.marksPercentage && <p className="text-[11px] text-rose-600 mt-1">{errors.marksPercentage}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">CGPA (if applicable)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="10"
                    value={cgpa}
                    onChange={(e) => setCgpa(Number(e.target.value))}
                    placeholder="e.g. 9.2"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: University Programme Selection */}
          {activeStep === 4 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 4: University Programme & Department Selection</h4>
                <p className="text-xs text-[#64748b]">
                  Dynamically loaded from official Academic Office curriculum masters
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Admission Academic Year <span className="text-rose-600">*</span>
                  </label>
                  <select
                    value={admissionAcademicYear}
                    onChange={(e) => setAdmissionAcademicYear(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono font-medium"
                  >
                    <option value={2026}>Academic Year 2026–2027</option>
                    <option value={2027}>Academic Year 2027–2028</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    Academic Department <span className="text-rose-600">*</span>
                  </label>
                  <select
                    value={departmentCode}
                    onChange={(e) => {
                      setDepartmentCode(e.target.value);
                      const progsInDept = programmes.filter((p: ProgrammeRecord) => p.department === e.target.value && p.status === 'ACTIVE');
                      if (progsInDept.length > 0) {
                        setProgrammeCode(progsInDept[0].code);
                      }
                    }}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    {departments.map((d) => (
                      <option key={d.department_id} value={d.code}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">
                    University Degree Programme <span className="text-rose-600">*</span>
                  </label>
                  <select
                    value={selectedProgramme?.code || ''}
                    onChange={(e) => setProgrammeCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    {filteredProgrammes.length === 0 ? (
                      <option value="">No active programmes found for department {departmentCode}</option>
                    ) : (
                      filteredProgrammes.map((p) => (
                        <option key={p.programme_id} value={p.code}>
                          {p.name} &bull; {p.degree_level} ({p.duration_semesters} Semesters, {p.total_credits_required} Credits)
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Degree Level</label>
                  <select
                    value={degreeLevel}
                    onChange={(e) => setDegreeLevel(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    <option value="UNDERGRADUATE">Undergraduate (B.Tech / B.Sc)</option>
                    <option value="POSTGRADUATE">Postgraduate (M.Tech / MBA / MCA)</option>
                    <option value="DOCTORAL">Doctoral / Ph.D.</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Admission Category / Quota</label>
                  <select
                    value={admissionCategory}
                    onChange={(e) => setAdmissionCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    {UNIVERSITY_ADMISSION_CATEGORIES.map((cat: string) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Study Mode</label>
                  <select
                    value={studyMode}
                    onChange={(e) => setStudyMode(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
                  >
                    {UNIVERSITY_STUDY_MODES.map((mode: string) => (
                      <option key={mode} value={mode}>
                        {mode}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: Entrance Examination */}
          {activeStep === 5 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 5: Entrance Examination & Eligibility Criteria</h4>
                <p className="text-xs text-[#64748b]">National / institutional entrance testing information (optional where direct merit applies)</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Examination Name</label>
                  <input
                    type="text"
                    value={entranceExamName}
                    onChange={(e) => setEntranceExamName(e.target.value)}
                    placeholder="e.g. JEE Main / State CET / GATE / Direct Merit"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Entrance Roll / Registration No</label>
                  <input
                    type="text"
                    value={entranceExamRoll}
                    onChange={(e) => setEntranceExamRoll(e.target.value)}
                    placeholder="e.g. JEE2026-90412"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Examination Year</label>
                  <input
                    type="number"
                    value={entranceExamYear}
                    onChange={(e) => setEntranceExamYear(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#1e293b] mb-1">Score / Percentile / Rank</label>
                  <input
                    type="text"
                    value={entranceExamScore}
                    onChange={(e) => setEntranceExamScore(e.target.value)}
                    placeholder="e.g. 96.8 Percentile (AIR 14,210)"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#1e293b] mb-1">Eligibility & Scrutiny Notes</label>
                <textarea
                  rows={2}
                  value={eligibilityNotes}
                  onChange={(e) => setEligibilityNotes(e.target.value)}
                  placeholder="Special reservations, sports credentials, or academic exemptions"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
                />
              </div>
            </div>
          )}

          {/* STEP 6: Documents Checklist */}
          {activeStep === 6 && (
            <div className="space-y-4">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 6: University Admissions Document Verification Checklist</h4>
                <p className="text-xs text-[#64748b]">Record and verify candidate supporting submissions</p>
              </div>

              {errors.documents && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{errors.documents}</span>
                </div>
              )}

              <div className="space-y-2.5">
                {documentsList.map((doc: any) => {
                  const isSubmitted = doc.submissionStatus === 'SUBMITTED';

                  return (
                    <div
                      key={doc.documentCode}
                      className={`p-3.5 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                        isSubmitted ? 'bg-emerald-50/50 border-emerald-200' : 'bg-slate-50 border-[#e2e8f0]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            isSubmitted
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-200 text-[#64748b]'
                          }`}
                        >
                          <FileCheck2 className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-xs text-[#1e293b]">
                              {doc.documentType}
                            </span>
                            {doc.isMandatory ? (
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                                Mandatory
                              </span>
                            ) : (
                              <span className="text-[10px] font-medium text-[#64748b] bg-slate-100 px-1.5 py-0.2 rounded">
                                Optional
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-[#64748b] font-mono">
                            {doc.fileName || 'Pending candidate upload'}
                          </span>
                        </div>
                      </div>

                      <Button
                        type="button"
                        variant={isSubmitted ? 'outline' : 'primary'}
                        size="sm"
                        onClick={() => handleToggleDoc(doc.documentCode)}
                      >
                        {isSubmitted ? 'Mark Pending' : 'Record Upload'}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 7: Review & Final Submission */}
          {activeStep === 7 && (
            <div className="space-y-5">
              <div className="border-b border-[#e2e8f0] pb-2">
                <h4 className="text-sm font-bold text-[#1e293b]">Step 7: Application Summary & Verification Review</h4>
                <p className="text-xs text-[#64748b]">
                  Confirm all details before submitting application to the Admissions registry
                </p>
              </div>

              {/* Dossier Preview Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Personal summary */}
                <div className="p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-1.5">
                  <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                    Candidate Profile
                  </span>
                  <div className="font-semibold text-[14px] text-[#1e293b]">
                    {firstName} {lastName}
                  </div>
                  <div className="text-[#64748b]">DOB: {dob} &bull; Gender: {gender}</div>
                  <div className="text-[#64748b] font-mono">{email}</div>
                  <div className="text-[#64748b]">{mobile}</div>
                  <div className="text-[#64748b]">{currentAddress}</div>
                </div>

                {/* Programme selection */}
                <div className="p-3.5 bg-[#eff6ff]/60 rounded-xl border border-[#dbeafe] space-y-1.5">
                  <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                    Intended Programme & Department
                  </span>
                  <div className="font-bold text-[14px] text-[#1e293b]">
                    {selectedProgramme?.name}
                  </div>
                  <div className="text-[#64748b]">
                    Department: <strong className="text-[#1e3a8a] font-mono">{departmentCode}</strong>
                  </div>
                  <div className="text-[#64748b]">Intake Session: {admissionAcademicYear} &bull; {degreeLevel}</div>
                  <div className="text-[#64748b]">Quota: {admissionCategory}</div>
                </div>

                {/* Education summary */}
                <div className="p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-1.5">
                  <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                    Qualifying Credentials
                  </span>
                  <div className="font-semibold text-[#1e293b]">{previousInstitution}</div>
                  <div className="text-[#64748b]">{previousQualification} ({boardOrUniversity})</div>
                  <div className="text-[#1e293b]">
                    Aggregate: <strong>{marksPercentage}%</strong> {cgpa ? `(CGPA ${cgpa})` : ''}
                  </div>
                </div>

                {/* Entrance exam */}
                <div className="p-3.5 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-1.5">
                  <span className="font-bold text-[#1e3a8a] text-[11px] uppercase tracking-wider block">
                    Entrance & Documents
                  </span>
                  <div className="font-semibold text-[#1e293b]">{entranceExamName || 'Direct Admission'}</div>
                  <div className="text-[#64748b]">{entranceExamScore || 'N/A'}</div>
                  <div className="text-emerald-700 font-semibold pt-1">
                    Documents Uploaded: {documentsList.filter((d: any) => d.submissionStatus === 'SUBMITTED').length} / {documentsList.length}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="bg-[#f8fafc] px-6 py-4 border-t border-[#e2e8f0] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div>
            {activeStep > 1 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleBack}
                leftIcon={<ChevronLeft className="w-4 h-4" />}
                disabled={isSubmitting}
              >
                Back
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {activeStep < 7 ? (
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={handleNext}
                rightIcon={<ChevronRight className="w-4 h-4" />}
              >
                Continue to Step {activeStep + 1}
              </Button>
            ) : (
              <>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleSubmit(ApplicationStatus.DRAFT)}
                  disabled={isSubmitting}
                >
                  Save as Draft
                </Button>
                <Button
                  type="button"
                  variant="primary"
                  size="sm"
                  className="bg-[#1e3a8a] hover:bg-[#172e6e]"
                  onClick={() => handleSubmit(ApplicationStatus.SUBMITTED)}
                  disabled={isSubmitting}
                  leftIcon={<CheckCircle2 className="w-4 h-4" />}
                >
                  {isSubmitting ? 'Registering...' : 'Submit Application'}
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
