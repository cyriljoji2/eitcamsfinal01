import React from 'react';
import {
  Users,
  Clock,
  FileCheck2,
  CheckCircle2,
  XCircle,
  UserPlus,
  UploadCloud,
  ArrowRight,
  TrendingUp,
  GraduationCap,
  Eye,
  Building2,
  BookOpen,
  AlertTriangle,
  History,
  ShieldCheck,
} from 'lucide-react';
import { ApplicantRecord, ApplicationStatus, AuditLogRecord } from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { AdmissionTab } from '../../types/admission';

export interface AdmissionOverviewProps {
  applicants: ApplicantRecord[];
  auditLogs: AuditLogRecord[];
  onNavigateToTab: (tab: AdmissionTab) => void;
  onOpenNewAdmission: () => void;
  onSelectApplicant: (applicant: ApplicantRecord) => void;
}

export function AdmissionOverview({
  applicants,
  auditLogs,
  onNavigateToTab,
  onOpenNewAdmission,
  onSelectApplicant,
}: AdmissionOverviewProps) {
  const total = applicants.length;
  const newApplications = applicants.filter((a) => a.application_status === ApplicationStatus.SUBMITTED).length;
  const underReview = applicants.filter((a) => a.application_status === ApplicationStatus.UNDER_REVIEW).length;
  const docsPending = applicants.filter((a) => a.application_status === ApplicationStatus.DOCUMENTS_PENDING).length;
  const approved = applicants.filter((a) => a.application_status === ApplicationStatus.APPROVED).length;
  const rejected = applicants.filter((a) => a.application_status === ApplicationStatus.REJECTED).length;
  const waitlisted = applicants.filter((a) => a.application_status === ApplicationStatus.WITHDRAWN).length;
  const converted = applicants.filter((a) => a.converted_to_student).length;

  // Documents pending verification across all applicants
  let docsPendingCount = 0;
  applicants.forEach((a) => {
    (a.documents || []).forEach((d) => {
      if (d.submission_status === 'SUBMITTED' && d.verification_status !== 'VERIFIED') {
        docsPendingCount++;
      }
    });
  });

  // Department-wise distribution
  const deptCounts: Record<string, number> = {};
  applicants.forEach((a) => {
    const dept = a.department || 'General';
    deptCounts[dept] = (deptCounts[dept] || 0) + 1;
  });

  // Programme-wise distribution
  const progCounts: Record<string, number> = {};
  applicants.forEach((a) => {
    const prog = a.intended_program || 'Unspecified';
    progCounts[prog] = (progCounts[prog] || 0) + 1;
  });

  // Recent 6 applications
  const recentApplicants = [...applicants]
    .sort((a, b) => new Date(b.created_at || b.application_date || '').getTime() - new Date(a.created_at || a.application_date || '').getTime())
    .slice(0, 6);

  // Recent 5 admissions-related audit activities
  const recentActivities = auditLogs
    .filter((l) => l.target_worksheet === 'Applicants' || l.action.includes('ADMISSION') || l.description.toLowerCase().includes('applicant'))
    .slice(0, 5);

  const getStatusBadge = (status: ApplicationStatus, isConverted?: boolean) => {
    if (isConverted) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
          <GraduationCap className="w-3 h-3" />
          <span>Enrolled Student</span>
        </span>
      );
    }
    switch (status) {
      case ApplicationStatus.APPROVED:
        return <Badge variant="emerald">Approved</Badge>;
      case ApplicationStatus.UNDER_REVIEW:
        return <Badge variant="blue">Under Review</Badge>;
      case ApplicationStatus.DOCUMENTS_PENDING:
        return <Badge variant="amber">Docs Pending</Badge>;
      case ApplicationStatus.SUBMITTED:
        return <Badge variant="purple">Submitted</Badge>;
      case ApplicationStatus.REJECTED:
        return <Badge variant="rose">Rejected</Badge>;
      case ApplicationStatus.WITHDRAWN:
        return <Badge variant="neutral">Withdrawn / Waitlisted</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome with Quick Actions */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-[20px] font-bold text-[#1e293b]">University Admissions Control Center</h2>
            <Badge variant="blue">Intake 2026–2027</Badge>
          </div>
          <p className="text-xs text-[#64748b]">
            Manage university candidate applications, verify qualifying documentation, and convert approved applicants into enrolled students.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('import')}
            leftIcon={<UploadCloud className="w-4 h-4" />}
          >
            Bulk CSV Import
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('documents')}
            leftIcon={<FileCheck2 className="w-4 h-4" />}
          >
            Verify Documents ({docsPendingCount})
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenNewAdmission}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            New Admission Application
          </Button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Applications */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Total Applications</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-[#1e293b]">{total}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Candidate admission dossiers</span>
        </div>

        {/* Applications Under Review / New */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">In Review Pipeline</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-[#1e293b]">{underReview + newApplications}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">
            {newApplications} new &bull; {underReview} under scrutiny
          </span>
        </div>

        {/* Documents Pending Verification */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Pending Document Verification</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-[#1e293b]">{docsPendingCount}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Checklist items awaiting officer review</span>
        </div>

        {/* Approved & Enrolled */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs transition-shadow hover:shadow-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-[#64748b]">Approved & Enrolled</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-[#1e293b]">{approved}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">
            {converted} converted to registered students
          </span>
        </div>
      </div>

      {/* Secondary Row: Status Breakdown & Department Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Application Status Pipeline */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#1e3a8a]" />
              <span>Application Status Distribution</span>
            </h3>
            <span className="text-xs text-[#64748b]">{total} total</span>
          </div>

          <div className="space-y-3">
            {[
              { label: 'Submitted (New Intake)', count: newApplications, color: 'bg-purple-600', text: 'text-purple-600' },
              { label: 'Under Review', count: underReview, color: 'bg-blue-600', text: 'text-blue-600' },
              { label: 'Documents Pending', count: docsPending, color: 'bg-amber-500', text: 'text-amber-500' },
              { label: 'Approved (Eligible)', count: approved, color: 'bg-emerald-600', text: 'text-emerald-600' },
              { label: 'Converted to Student', count: converted, color: 'bg-indigo-600', text: 'text-indigo-600' },
              { label: 'Rejected', count: rejected, color: 'bg-rose-600', text: 'text-rose-600' },
              { label: 'Waitlisted / Withdrawn', count: waitlisted, color: 'bg-slate-400', text: 'text-slate-500' },
            ].map((item) => {
              const pct = total > 0 ? Math.round((item.count / total) * 100) : 0;
              return (
                <div key={item.label} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#64748b] font-medium">{item.label}</span>
                    <span className="font-semibold text-[#1e293b]">
                      {item.count} <span className="text-[11px] text-[#94a3b8]">({pct}%)</span>
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full ${item.color} rounded-full transition-all duration-300`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Department-Wise Distribution */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#1e3a8a]" />
              <span>Department Applications</span>
            </h3>
            <span className="text-xs text-[#64748b]">{Object.keys(deptCounts).length} departments</span>
          </div>

          <div className="space-y-3">
            {Object.keys(deptCounts).length === 0 ? (
              <p className="text-xs text-[#94a3b8] py-4 text-center">No departmental applications recorded.</p>
            ) : (
              Object.entries(deptCounts).map(([dept, count]) => {
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                return (
                  <div key={dept} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-[#1e293b]">{dept}</span>
                      <span className="text-[#64748b]">{count} applications ({pct}%)</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-[#1e3a8a] rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Programme-Wise Applications */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
              <span>Programme Distribution</span>
            </h3>
            <span className="text-xs text-[#64748b]">{Object.keys(progCounts).length} programmes</span>
          </div>

          <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
            {Object.keys(progCounts).length === 0 ? (
              <p className="text-xs text-[#94a3b8] py-4 text-center">No programme applications recorded.</p>
            ) : (
              Object.entries(progCounts).map(([prog, count]) => (
                <div key={prog} className="p-2.5 rounded-lg border border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#1e293b] truncate max-w-[200px]" title={prog}>
                    {prog}
                  </span>
                  <Badge variant="blue" size="sm">{count}</Badge>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Applications Table & Activity Audit Log */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Applications */}
        <div className="lg:col-span-2 bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
          <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Recent Admission Applications</h3>
              <p className="text-xs text-[#64748b]">Latest candidate submissions and pipeline updates</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigateToTab('applications')}
              rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
            >
              View All Applications
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="px-4 py-3">Application ID</th>
                  <th className="px-4 py-3">Applicant Name</th>
                  <th className="px-4 py-3">Programme</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {recentApplicants.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-[#94a3b8]">
                      No applications recorded in admissions registry.
                    </td>
                  </tr>
                ) : (
                  recentApplicants.map((app) => (
                    <tr key={app.application_id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 font-mono font-bold text-[#1e3a8a]">
                        {app.application_id}
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#1e293b]">
                          {app.first_name} {app.last_name}
                        </div>
                        <span className="text-[11px] text-[#64748b]">{app.email}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-[#1e293b]">{app.intended_program}</div>
                        <span className="text-[11px] font-mono text-[#64748b]">Dept: {app.department}</span>
                      </td>
                      <td className="px-4 py-3">
                        {getStatusBadge(app.application_status, app.converted_to_student)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onSelectApplicant(app)}
                          leftIcon={<Eye className="w-3.5 h-3.5" />}
                        >
                          Inspect
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Admissions Activities */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden flex flex-col">
          <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <History className="w-4 h-4 text-[#1e3a8a]" />
              <span>Admissions Activity Log</span>
            </h3>
            <span className="text-[11px] text-[#64748b]">Audit entries</span>
          </div>

          <div className="p-4 space-y-3.5 flex-1 overflow-y-auto max-h-96">
            {recentActivities.length === 0 ? (
              <p className="text-xs text-[#94a3b8] py-8 text-center">No recent admissions audit actions.</p>
            ) : (
              recentActivities.map((act) => (
                <div key={act.log_id} className="p-3 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-[#1e3a8a] text-[11px]">
                      {act.action}
                    </span>
                    <span className="text-[10px] text-[#94a3b8]">
                      {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-[#334155] text-xs leading-snug">{act.description}</p>
                  <div className="text-[10px] text-[#64748b] flex items-center justify-between pt-1 border-t border-[#e2e8f0]">
                    <span>Actor: {act.actor_id} ({act.actor_role})</span>
                    <span>{new Date(act.timestamp).toLocaleDateString()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
