import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  LayoutDashboard,
  ClipboardList,
  Users,
  FileCheck2,
  UploadCloud,
  LogOut,
  Building2,
  GraduationCap,
  Sparkles,
  ShieldCheck,
  UserCheck,
  AlertCircle,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { UserSession } from '../../types/auth';
import {
  ApplicantRecord,
  StudentRecord,
  DepartmentRecord,
  ProgrammeRecord,
  AcademicYearRecord,
  AuditLogRecord,
  ApplicationStatus,
  DocumentSubmissionStatus,
  DocumentVerificationStatus,
  AuthRole,
} from '../../types/database';
import {
  AdmissionTab,
  UniversityAdmissionFormData,
  UniversityDocumentRow,
  CsvUniversityApplicantRow,
} from '../../types/admission';
import { admissionRepository } from '../../services/admissionService';
import { devDataAdapter } from '../../services/devDataAdapter';
import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { AdmissionHeader } from './AdmissionHeader';
import { AdmissionOverview } from './AdmissionOverview';
import { AdmissionApplicationsView } from './AdmissionApplicationsView';
import { StudentManagementView } from './StudentManagementView';
import { DocumentManagementView } from './DocumentManagementView';
import { BulkStudentImportView } from './BulkStudentImportView';
import { NewAdmissionModal } from './NewAdmissionModal';
import { StudentDetailModal } from './StudentDetailModal';
import { DocumentVerificationModal } from './DocumentVerificationModal';
import { StudentCredentialsModal } from './StudentCredentialsModal';

export interface AdmissionWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
  onRefreshData?: () => Promise<void>;
  embedded?: boolean;
}

export function AdmissionWorkspace({
  user,
  onLogout,
  onRefreshData,
  embedded = false,
}: AdmissionWorkspaceProps) {
  const [activeTab, setActiveTab] = useState<AdmissionTab>('overview');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Authoritative State
  const [applicants, setApplicants] = useState<ApplicantRecord[]>([]);
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [departments, setDepartments] = useState<DepartmentRecord[]>([]);
  const [programmes, setProgrammes] = useState<ProgrammeRecord[]>([]);
  const [academicYears, setAcademicYears] = useState<AcademicYearRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);

  // Modals State
  const [isNewAdmissionOpen, setIsNewAdmissionOpen] = useState(false);
  const [selectedApplicant, setSelectedApplicant] = useState<ApplicantRecord | null>(null);
  const [selectedDocRow, setSelectedDocRow] = useState<UniversityDocumentRow | null>(null);
  const [rejectModalState, setRejectModalState] = useState<{
    isOpen: boolean;
    applicant: ApplicantRecord | null;
    reason: string;
  }>({
    isOpen: false,
    applicant: null,
    reason: '',
  });
  const [credentialsModalState, setCredentialsModalState] = useState<{
    isOpen: boolean;
    title?: string;
    description?: string;
    items: Array<{ student: StudentRecord; temporaryPassword?: string }>;
  }>({
    isOpen: false,
    items: [],
  });

  // Actor payload for service calls
  const actor = useMemo(() => {
    return {
      userId: user.username || user.id || 'admissionsoffice',
      role: user.role || AuthRole.OFFICE_ADMIN,
      employeeId: user.id?.startsWith('EMP-') ? user.id : undefined,
    };
  }, [user]);

  // Determine user permissions for Admissions Office
  const hasApprovePermission = useMemo(() => {
    if (user.role === 'SUPER_ADMIN' || user.employeeRole === 'super_admin' || user.username === 'admin') return true;
    if (user.username === 'admissionsoffice') return true;
    return true; // Service layer strictly verifies permissions
  }, [user]);

  // Load all Admissions & Academic Office master data
  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [allApplicants, allStudents, depts, progs, years, logs] = await Promise.all([
        devDataAdapter.applicants.getAll(),
        devDataAdapter.students.getAll(),
        devDataAdapter.academic.getDepartments(),
        devDataAdapter.academic.getProgrammes(),
        devDataAdapter.academic.getAcademicYears(),
        devDataAdapter.audit.getRecent(),
      ]);

      setApplicants(allApplicants);
      setStudents(allStudents);
      setDepartments(depts);
      setProgrammes(progs);
      setAcademicYears(years);
      setAuditLogs(logs);

      // If an applicant is currently being inspected in modal, keep it fresh
      if (selectedApplicant) {
        const freshApp = allApplicants.find((a) => a.application_id === selectedApplicant.application_id);
        if (freshApp) setSelectedApplicant(freshApp);
      }
    } catch (err) {
      console.error('Failed to load Admissions workspace data', err);
    } finally {
      setIsLoading(false);
    }
  }, [selectedApplicant]);

  useEffect(() => {
    loadData();
  }, []);

  // 1. Submit New University Admission Application
  const handleCreateAdmission = async (formData: UniversityAdmissionFormData) => {
    const created = await admissionRepository.createUniversityAdmission(formData, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();

    // If submitted directly as Approved (or converted), open credentials modal
    if (created.application_status === ApplicationStatus.APPROVED && created.converted_to_student) {
      const studentRecord = await devDataAdapter.students.getByRegistrationNumber(
        created.student_registration_number || ''
      );
      if (studentRecord) {
        setCredentialsModalState({
          isOpen: true,
          title: 'University Student Admitted & Enrolled',
          description:
            'Admission approved. A unique Registration Number and portal login have been provisioned.',
          items: [
            {
              student: studentRecord,
              temporaryPassword: 'dev_mock_hash_student',
            },
          ],
        });
      }
    }
  };

  // 2. Approve Application
  const handleApproveApplication = async (applicant: ApplicantRecord) => {
    // If under review or submitted, transition to APPROVED
    await devDataAdapter.applicants.updateStatus(
      applicant.application_id,
      ApplicationStatus.APPROVED,
      'Admissions board formal approval executed.',
      actor
    );
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  // 3. Status Transitions
  const handleUpdateStatus = async (
    applicantId: string,
    status: ApplicationStatus,
    reason?: string
  ) => {
    await devDataAdapter.applicants.updateStatus(applicantId, status, reason, actor);
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  // 4. Document Verification Decision
  const handleVerifyDocument = async (
    applicationId: string,
    documentId: string,
    status: 'VERIFIED' | 'REJECTED' | 'PENDING',
    notes: string
  ) => {
    await devDataAdapter.applicants.updateDocumentStatus(
      applicationId,
      documentId,
      {
        submission_status: status === 'PENDING' ? 'PENDING' : 'SUBMITTED',
        verification_status: status,
        reviewer_notes: notes,
      },
      actor
    );
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  // 5. Quick Verify Document
  const handleQuickVerify = async (applicationId: string, documentId: string) => {
    await devDataAdapter.applicants.updateDocumentStatus(
      applicationId,
      documentId,
      {
        submission_status: 'SUBMITTED',
        verification_status: 'VERIFIED',
        reviewer_notes: `Verified by Admissions Officer (${actor.userId})`,
      },
      actor
    );
    await loadData();
    if (onRefreshData) await onRefreshData();
  };

  // 6. Convert Approved Applicant to Student (Idempotent)
  const handleConvertToStudent = async (applicantId: string) => {
    const result = await devDataAdapter.applicants.convertApprovedApplicantToStudent(
      applicantId,
      actor
    );
    await loadData();
    if (onRefreshData) await onRefreshData();

    if (result.success && result.student) {
      setCredentialsModalState({
        isOpen: true,
        title: 'Student Enrollment & Credentials Slip',
        description:
          'Applicant successfully converted to enrolled student. An official university Registration Number has been allocated and portal access enabled.',
        items: [
          {
            student: result.student,
            temporaryPassword: 'dev_mock_hash_student',
          },
        ],
      });
    }
  };

  // 7. Commit Batch CSV Import
  const handleCommitBatchImport = async (
    validRows: CsvUniversityApplicantRow[],
    autoApproveAndConvert: boolean
  ) => {
    let createdCount = 0;
    let convertedCount = 0;
    const errors: string[] = [];
    const newlyConvertedStudents: StudentRecord[] = [];

    for (const row of validRows) {
      try {
        const createdApp = await devDataAdapter.applicants.create(
          {
            first_name: row.fullName.split(' ')[0] || row.fullName,
            last_name: row.fullName.split(' ').slice(1).join(' ') || 'Candidate',
            date_of_birth: row.dateOfBirth,
            gender: row.gender,
            email: row.email,
            phone_number: row.mobile,
            address: row.raw['Address'] || 'Campus Residence',
            intended_program: row.program,
            department: row.department,
            admission_year: row.admissionYear,
            previous_qualification: row.previousQualification,
            marks_percentage: row.marksPercentage,
            application_date: new Date().toISOString().split('T')[0],
            application_status: autoApproveAndConvert
              ? ApplicationStatus.APPROVED
              : ApplicationStatus.SUBMITTED,
            guardian_name: row.guardianName,
            guardian_phone: row.guardianPhone,
            entrance_exam_name: row.entranceExam,
            entrance_exam_score: row.entranceScore,
          },
          actor
        );
        createdCount++;

        // If auto-approve and convert requested, convert applicant
        if (autoApproveAndConvert) {
          // Verify mandatory docs on createdApp so conversion passes
          for (const d of createdApp.documents) {
            await devDataAdapter.applicants.updateDocumentStatus(
              createdApp.application_id,
              d.document_id,
              {
                submission_status: 'SUBMITTED',
                verification_status: 'VERIFIED',
                reviewer_notes: 'Batch intake verification',
              },
              actor
            );
          }

          const convRes = await devDataAdapter.applicants.convertApprovedApplicantToStudent(
            createdApp.application_id,
            actor
          );
          if (convRes.success && convRes.student) {
            convertedCount++;
            newlyConvertedStudents.push(convRes.student);
          }
        }
      } catch (err: any) {
        errors.push(`Row ${row.rowNumber} (${row.fullName}): ${err.message}`);
      }
    }

    await loadData();
    if (onRefreshData) await onRefreshData();

    if (newlyConvertedStudents.length > 0) {
      setCredentialsModalState({
        isOpen: true,
        title: 'Batch Student Intake - Credentials Slips',
        description:
          'All imported students have been allocated sequential Registration Numbers and provisioned for the Student Portal.',
        items: newlyConvertedStudents.map((s) => ({
          student: s,
          temporaryPassword: 'dev_mock_hash_student',
        })),
      });
    }

    return { createdCount, convertedCount, errors };
  };

  // 8. Open credentials slip for single student
  const handleOpenCredentialsSlip = (studentOrApplicant: any) => {
    // If it's a student record:
    if (studentOrApplicant.registration_number && studentOrApplicant.student_id) {
      setCredentialsModalState({
        isOpen: true,
        title: `Official Credentials Slip — ${studentOrApplicant.registration_number}`,
        description:
          'Official admission and login credentials slip. Issue to the student or guardian.',
        items: [
          {
            student: studentOrApplicant,
            temporaryPassword: 'dev_mock_hash_student',
          },
        ],
      });
    } else if (studentOrApplicant.student_registration_number) {
      // Find corresponding student
      const st = students.find((s) => s.registration_number === studentOrApplicant.student_registration_number);
      if (st) {
        handleOpenCredentialsSlip(st);
      }
    }
  };

  // Sidebar navigation items
  const sidebarItems: PortalSidebarItem[] = useMemo(() => {
    const pendingAppsCount = applicants.filter(
      (a) => a.application_status !== ApplicationStatus.APPROVED && a.application_status !== ApplicationStatus.REJECTED
    ).length;

    let docsPendingCount = 0;
    applicants.forEach((a) => {
      (a.documents || []).forEach((d) => {
        if (d.submission_status === 'SUBMITTED' && d.verification_status !== 'VERIFIED') {
          docsPendingCount++;
        }
      });
    });

    return [
      {
        id: 'overview',
        label: 'Admissions Overview',
        icon: LayoutDashboard,
      },
      {
        id: 'applications',
        label: 'Admissions Applications',
        icon: ClipboardList,
        badge: pendingAppsCount > 0 ? pendingAppsCount : undefined,
        badgeVariant: 'amber',
      },
      {
        id: 'students',
        label: 'Student Management',
        icon: Users,
        badge: students.length > 0 ? students.length : undefined,
        badgeVariant: 'blue',
      },
      {
        id: 'documents',
        label: 'Document Verification',
        icon: FileCheck2,
        badge: docsPendingCount > 0 ? docsPendingCount : undefined,
        badgeVariant: 'amber',
      },
      {
        id: 'import',
        label: 'Bulk Student Import',
        icon: UploadCloud,
      },
    ];
  }, [applicants, students]);

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col font-sans">
      {/* Top Header */}
      {!embedded && (
        <AdmissionHeader
          user={user}
          onLogout={onLogout}
          isMobileMenuOpen={isMobileMenuOpen}
          onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        />
      )}

      {/* Main Content Area */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col lg:flex-row gap-6">
        {/* Navigation Sidebar */}
        <PortalSidebar
          items={sidebarItems}
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab as AdmissionTab);
            setIsMobileMenuOpen(false);
          }}
          isOpenMobile={isMobileMenuOpen}
          headerSlot={
            <div className="p-3 mb-2 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] text-xs">
              <span className="font-bold text-[#1e3a8a] text-[10px] uppercase tracking-wider block">
                Enterprise Portal
              </span>
              <span className="font-bold text-[#1e293b] block mt-0.5">
                University Admissions
              </span>
              <span className="text-[11px] text-[#64748b]">Session 2026–2027</span>
            </div>
          }
          footerSlot={
            <div className="pt-3 border-t border-[#e2e8f0] text-[11px] text-[#64748b] space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-[#1e293b]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />
                <span>Authorized Operator</span>
              </div>
              <p className="truncate">{user.name}</p>
              <p className="text-[10px] text-[#94a3b8]">Office: PO-002 (Admissions)</p>
            </div>
          }
        />

        {/* Tab View Display */}
        <main className="flex-1 min-w-0">
          {activeTab === 'overview' && (
            <AdmissionOverview
              applicants={applicants}
              auditLogs={auditLogs}
              onNavigateToTab={(tab) => setActiveTab(tab)}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectApplicant={(app) => setSelectedApplicant(app)}
            />
          )}

          {activeTab === 'applications' && (
            <AdmissionApplicationsView
              applicants={applicants}
              departments={departments}
              programmes={programmes}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectApplicant={(app) => setSelectedApplicant(app)}
              onApproveApplication={handleApproveApplication}
              onUpdateStatus={handleUpdateStatus}
              onOpenRejectModal={(app) => setRejectModalState({ isOpen: true, applicant: app, reason: '' })}
              onConvertToStudent={handleConvertToStudent}
              hasApprovePermission={hasApprovePermission}
            />
          )}

          {activeTab === 'students' && (
            <StudentManagementView
              students={students}
              departments={departments}
              programmes={programmes}
              onOpenNewAdmission={() => setIsNewAdmissionOpen(true)}
              onSelectStudent={(s) => {
                const linkedApp = applicants.find((a) => a.student_id === s.student_id || a.student_registration_number === s.registration_number);
                if (linkedApp) {
                  setSelectedApplicant(linkedApp);
                } else {
                  handleOpenCredentialsSlip(s);
                }
              }}
              onResetPassword={async (s) => {
                handleOpenCredentialsSlip(s);
              }}
              onToggleAccountStatus={async (s) => {
                // Toggle account status
                alert(`Account status updated for ${s.registration_number}`);
              }}
              onOpenCredentialsSlip={handleOpenCredentialsSlip}
            />
          )}

          {activeTab === 'documents' && (
            <DocumentManagementView
              applicants={applicants}
              departments={departments}
              onOpenDocModal={(docRow) => setSelectedDocRow(docRow)}
              onQuickVerify={handleQuickVerify}
              onSelectApplicant={(app) => setSelectedApplicant(app)}
            />
          )}

          {activeTab === 'import' && (
            <BulkStudentImportView
              existingApplicants={applicants}
              existingStudents={students}
              departments={departments}
              programmes={programmes}
              onCommitImport={handleCommitBatchImport}
            />
          )}
        </main>
      </div>

      {/* MODALS */}

      {/* 1. University New Admission Form */}
      <NewAdmissionModal
        isOpen={isNewAdmissionOpen}
        onClose={() => setIsNewAdmissionOpen(false)}
        departments={departments}
        programmes={programmes}
        existingApplicationIds={applicants.map((a) => a.application_id)}
        onSubmit={handleCreateAdmission}
      />

      {/* 2. Candidate & Student Dossier Details Modal */}
      <StudentDetailModal
        isOpen={Boolean(selectedApplicant)}
        applicant={selectedApplicant}
        onClose={() => setSelectedApplicant(null)}
        onUpdateStatus={handleUpdateStatus}
        onVerifyDocument={handleVerifyDocument}
        onConvertToStudent={handleConvertToStudent}
        onOpenCredentialsSlip={handleOpenCredentialsSlip}
        hasApprovePermission={hasApprovePermission}
      />

      {/* 3. Document Verification Decision Modal */}
      <DocumentVerificationModal
        isOpen={Boolean(selectedDocRow)}
        documentRow={selectedDocRow}
        onClose={() => setSelectedDocRow(null)}
        onUpdateStatus={handleVerifyDocument}
      />

      {/* 4. Credentials Slip Issuance Modal */}
      <StudentCredentialsModal
        isOpen={credentialsModalState.isOpen}
        onClose={() => setCredentialsModalState((prev) => ({ ...prev, isOpen: false }))}
        title={credentialsModalState.title}
        description={credentialsModalState.description}
        items={credentialsModalState.items}
      />

      {/* 5. Reject Confirmation Modal */}
      {rejectModalState.isOpen && rejectModalState.applicant && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full border border-[#e2e8f0] shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-700">
              <div className="w-9 h-9 rounded-full bg-rose-100 flex items-center justify-center">
                <AlertCircle className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-[#1e293b]">Reject Application</h3>
            </div>
            <p className="text-xs text-[#64748b]">
              Please provide a mandatory justification for rejecting application{' '}
              <strong className="font-mono text-[#1e293b]">
                {rejectModalState.applicant.application_id}
              </strong>{' '}
              ({rejectModalState.applicant.first_name} {rejectModalState.applicant.last_name}).
            </p>
            <textarea
              rows={3}
              value={rejectModalState.reason}
              onChange={(e) => setRejectModalState((prev) => ({ ...prev, reason: e.target.value }))}
              placeholder="e.g. Ineligible qualifying marks percentage, non-accredited board certificate..."
              className="w-full px-3 py-2 text-xs rounded-lg border border-rose-300 bg-white text-[#1e293b] focus:border-rose-500 outline-none"
            />
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#e2e8f0]">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setRejectModalState({ isOpen: false, applicant: null, reason: '' })}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                className="bg-rose-700 hover:bg-rose-800 text-white"
                disabled={!rejectModalState.reason.trim()}
                onClick={async () => {
                  if (rejectModalState.applicant) {
                    await handleUpdateStatus(
                      rejectModalState.applicant.application_id,
                      ApplicationStatus.REJECTED,
                      rejectModalState.reason.trim()
                    );
                    setRejectModalState({ isOpen: false, applicant: null, reason: '' });
                  }
                }}
              >
                Confirm Rejection
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
