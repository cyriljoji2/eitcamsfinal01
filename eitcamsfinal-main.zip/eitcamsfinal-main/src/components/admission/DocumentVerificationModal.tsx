import React, { useState } from 'react';
import {
  FileCheck2,
  X,
  FileText,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar,
  User,
  Building2,
} from 'lucide-react';
import { UniversityDocumentRow } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface DocumentVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentRow: UniversityDocumentRow | null;
  onUpdateStatus: (
    applicationId: string,
    documentId: string,
    status: 'PENDING' | 'VERIFIED' | 'REJECTED',
    notes: string
  ) => Promise<void>;
}

export function DocumentVerificationModal({
  isOpen,
  onClose,
  documentRow,
  onUpdateStatus,
}: DocumentVerificationModalProps) {
  if (!isOpen || !documentRow) return null;

  const [selectedStatus, setSelectedStatus] = useState<'PENDING' | 'VERIFIED' | 'REJECTED'>(
    documentRow.verificationStatus
  );
  const [remarks, setRemarks] = useState<string>(documentRow.reviewerNotes || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Rule: Rejecting a document requires a mandatory reason
    if (selectedStatus === 'REJECTED' && !remarks.trim()) {
      setValidationError('A mandatory rejection reason is required when rejecting a document.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onUpdateStatus(
        documentRow.applicationId,
        documentRow.documentId,
        selectedStatus,
        remarks.trim()
      );
      onClose();
    } catch (err: any) {
      setValidationError(err?.message || 'Failed to update document verification decision.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-lg w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center border border-[#dbeafe]">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-[16px] font-bold text-[#1e293b]">Document Verification Decision</h3>
              <p className="text-xs text-[#64748b]">Review candidate submission against qualifying criteria</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {validationError && (
            <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Document Summary Card */}
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold text-[#94a3b8] uppercase tracking-wider block">
                  Document Checklist Item
                </span>
                <span className="text-[15px] font-bold text-[#1e293b]">
                  {documentRow.documentType}
                </span>
                <span className="font-mono text-xs text-[#64748b] block">{documentRow.documentCode}</span>
              </div>
              {documentRow.isMandatory ? (
                <Badge variant="rose">Mandatory</Badge>
              ) : (
                <Badge variant="neutral">Optional</Badge>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-[#e2e8f0]">
              <div>
                <span className="text-[#64748b] block font-medium">Candidate</span>
                <span className="font-semibold text-[#1e293b] flex items-center gap-1 mt-0.5">
                  <User className="w-3.5 h-3.5 text-[#64748b]" />
                  {documentRow.applicantName}
                </span>
                <span className="font-mono text-[11px] text-[#1e3a8a] block">{documentRow.applicationId}</span>
              </div>
              <div>
                <span className="text-[#64748b] block font-medium">Department</span>
                <span className="font-semibold text-[#1e293b] flex items-center gap-1 mt-0.5">
                  <Building2 className="w-3.5 h-3.5 text-[#64748b]" />
                  {documentRow.department} &bull; {documentRow.intendedProgram}
                </span>
              </div>
            </div>
          </div>

          {/* Decision Selection */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Verification Decision <span className="text-rose-600">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedStatus('VERIFIED')}
                className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  selectedStatus === 'VERIFIED'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-slate-50'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus('PENDING')}
                className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  selectedStatus === 'PENDING'
                    ? 'bg-amber-50 border-amber-500 text-amber-800 shadow-xs'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-slate-50'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                <span>Pending</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus('REJECTED')}
                className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  selectedStatus === 'REJECTED'
                    ? 'bg-rose-50 border-rose-500 text-rose-800 shadow-xs'
                    : 'bg-white border-[#e2e8f0] text-[#64748b] hover:bg-slate-50'
                }`}
              >
                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                <span>Rejected</span>
              </button>
            </div>
          </div>

          {/* Reviewer Remarks */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-[#1e293b]">
              Reviewer Notes / Document Rejection Justification
              {selectedStatus === 'REJECTED' && <span className="text-rose-600"> (Mandatory)</span>}
            </label>
            <textarea
              rows={3}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder={
                selectedStatus === 'REJECTED'
                  ? 'Specify why this document is rejected (e.g. illegible photocopy, wrong certificate uploaded, signature missing)...'
                  : 'Add internal remarks or verification notes...'
              }
              className="w-full px-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none"
            />
          </div>

          {/* Modal Footer */}
          <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2.5">
            <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
              className="bg-[#1e3a8a] hover:bg-[#172e6e]"
            >
              {isSubmitting ? 'Saving...' : 'Save Decision'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
