import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Download,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Users,
  RefreshCw,
  Sparkles,
  KeyRound,
  Trash2,
  Building2,
  Check,
} from 'lucide-react';
import {
  ApplicantRecord,
  DepartmentRecord,
  ProgrammeRecord,
  StudentRecord,
  ApplicationStatus,
} from '../../types/database';
import {
  CsvUniversityApplicantRow,
  CsvUniversityValidationResult,
} from '../../types/admission';
import {
  parseUniversityCsvText,
  validateUniversityCsvRows,
} from '../../services/admissionService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface BulkStudentImportViewProps {
  existingApplicants: ApplicantRecord[];
  existingStudents: StudentRecord[];
  departments: DepartmentRecord[];
  programmes: ProgrammeRecord[];
  onCommitImport: (
    validRows: CsvUniversityApplicantRow[],
    autoApproveAndConvert: boolean
  ) => Promise<{ createdCount: number; convertedCount: number; errors: string[] }>;
}

export function BulkStudentImportView({
  existingApplicants,
  existingStudents,
  departments,
  programmes,
  onCommitImport,
}: BulkStudentImportViewProps) {
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [validationResult, setValidationResult] = useState<CsvUniversityValidationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [autoApproveAndConvert, setAutoApproveAndConvert] = useState(false);
  const [importResult, setImportResult] = useState<{
    createdCount: number;
    convertedCount: number;
    errors: string[];
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadTemplate = () => {
    const sampleHeaders = [
      'FullName',
      'DateOfBirth',
      'Gender',
      'Email',
      'Mobile',
      'Department',
      'Program',
      'AdmissionYear',
      'PreviousQualification',
      'MarksPercentage',
      'GuardianName',
      'GuardianPhone',
      'EntranceExam',
      'EntranceScore',
    ];

    const sampleRows = [
      [
        'Vikramaditya Rao',
        '2006-04-12',
        'MALE',
        'vikram.rao@example.com',
        '+91 98450 11223',
        'CSE',
        'B.Tech Computer Science & Engineering',
        '2026',
        'CBSE Class XII (PCM)',
        '92.4',
        'K. S. Rao',
        '+91 98450 99887',
        'JEE Main',
        '98.2 Percentile',
      ],
      [
        'Ananya Sundaram',
        '2006-08-25',
        'FEMALE',
        'ananya.sundaram@example.com',
        '+91 97890 22334',
        'ECE',
        'B.Tech Electronics & Communication Engineering',
        '2026',
        'State Board Higher Secondary',
        '94.0',
        'S. Sundaram',
        '+91 97890 88776',
        'State CET',
        'Rank 412',
      ],
      [
        'Farhan Ahmed',
        '2005-11-19',
        'MALE',
        'farhan.ahmed@example.com',
        '+91 96123 33445',
        'MECH',
        'B.Tech Mechanical Engineering',
        '2026',
        'ICSE / ISC XII Science',
        '88.5',
        'Tariq Ahmed',
        '+91 96123 77665',
        'Direct Merit',
        'Qualifying Index 88.5',
      ],
    ];

    const csvText =
      sampleHeaders.join(',') +
      '\n' +
      sampleRows.map((r) => r.map((cell) => `"${cell}"`).join(',')).join('\n');

    const blob = new Blob([csvText], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'eit_university_admissions_template.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const processText = (text: string, name: string) => {
    setFileName(name);
    setCsvContent(text);
    setImportResult(null);

    const parsedRows = parseUniversityCsvText(text);
    const result = validateUniversityCsvRows(
      parsedRows,
      existingApplicants,
      existingStudents,
      departments,
      programmes
    );
    setValidationResult(result);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      processText(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    if (!file.name.endsWith('.csv')) {
      alert('Please upload a valid .csv file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      processText(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleExecuteImport = async () => {
    if (!validationResult) return;
    const validRows = validationResult.rows.filter((r) => r.isValid);
    if (validRows.length === 0) return;

    try {
      setIsProcessing(true);
      const res = await onCommitImport(validRows, autoApproveAndConvert);
      setImportResult(res);
      // Clear out the current uploaded content so duplicate clicks are prevented
      setCsvContent('');
      setValidationResult(null);
    } catch (err: any) {
      alert(err.message || 'Import execution failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadRejectedRows = () => {
    if (!validationResult) return;
    const invalidRows = validationResult.rows.filter((r) => !r.isValid);
    if (invalidRows.length === 0) return;

    const headers = Object.keys(invalidRows[0].raw).concat(['Validation_Errors']);
    const csvLines = [headers.join(',')];

    invalidRows.forEach((r) => {
      const rowVals = Object.keys(r.raw).map((k) => `"${r.raw[k] || ''}"`);
      rowVals.push(`"${r.validationErrors.join('; ')}"`);
      csvLines.push(rowVals.join(','));
    });

    const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `rejected_rows_${fileName || 'admissions'}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">Bulk Student Admissions Intake (CSV)</h2>
          <p className="text-xs text-[#64748b]">
            Batch import verified candidate applications and convert cohorts to university student records
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleDownloadTemplate}
          leftIcon={<Download className="w-4 h-4" />}
        >
          Download CSV Template
        </Button>
      </div>

      {/* Success Notification */}
      {importResult && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-xs text-emerald-900 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm">
            <CheckCircle2 className="w-5 h-5 text-emerald-700" />
            <span>Admissions Batch Import Completed Successfully!</span>
          </div>
          <p>
            Created <strong className="font-mono">{importResult.createdCount}</strong> new university candidate dossiers.
            {importResult.convertedCount > 0 && (
              <> Converted and provisioned <strong className="font-mono">{importResult.convertedCount}</strong> enrolled student accounts with registration numbers.</>
            )}
          </p>
        </div>
      )}

      {/* Upload Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all bg-white cursor-pointer ${
          isDragging ? 'border-[#1e3a8a] bg-blue-50/50' : 'border-[#cbd5e1] hover:border-slate-400'
        }`}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          className="hidden"
          onChange={handleFileChange}
        />

        <div className="max-w-md mx-auto space-y-3">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#1e3a8a] flex items-center justify-center mx-auto shadow-xs">
            <UploadCloud className="w-6 h-6" />
          </div>
          <div>
            <span className="text-sm font-bold text-[#1e293b] block">
              Upload University Admissions CSV File
            </span>
            <span className="text-xs text-[#64748b] block mt-0.5">
              Drag and drop your file here, or click to browse files
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#94a3b8] block">
            Format: RFC 4180 CSV &bull; Encoding: UTF-8 &bull; Max: 500 rows per batch
          </span>
        </div>
      </div>

      {/* Validation Results & Preview */}
      {validationResult && (
        <div className="space-y-4">
          {/* Summary Bar */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#1e3a8a]" />
                <span className="font-bold text-[#1e293b]">{fileName}</span>
              </div>
              <Badge variant="blue">{validationResult.totalRows} Total Rows</Badge>
              <Badge variant="emerald">{validationResult.validRowsCount} Valid</Badge>
              {validationResult.invalidRowsCount > 0 && (
                <Badge variant="rose">{validationResult.invalidRowsCount} Invalid</Badge>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {validationResult.invalidRowsCount > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDownloadRejectedRows}
                  leftIcon={<Download className="w-3.5 h-3.5" />}
                >
                  Export Rejected Rows
                </Button>
              )}

              <Button
                variant="primary"
                size="sm"
                disabled={validationResult.validRowsCount === 0 || isProcessing}
                onClick={handleExecuteImport}
                leftIcon={isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              >
                {isProcessing
                  ? 'Importing Dossiers...'
                  : `Commit Import (${validationResult.validRowsCount} Applicants)`}
              </Button>
            </div>
          </div>

          {/* Option: Auto-approve & convert */}
          <div className="bg-[#eff6ff] border border-[#dbeafe] rounded-xl p-3.5 flex items-center justify-between text-xs text-[#1e3a8a]">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="autoApproveConvert"
                checked={autoApproveAndConvert}
                onChange={(e) => setAutoApproveAndConvert(e.target.checked)}
                className="rounded text-[#1e3a8a]"
              />
              <label htmlFor="autoApproveConvert" className="font-semibold cursor-pointer">
                Auto-approve verified rows and convert directly to enrolled students with Registration Numbers
              </label>
            </div>
            <span className="text-[11px] text-[#3b82f6] font-medium hidden md:inline">
              Allocates official EIT-STU registration numbers & provisions portal logins
            </span>
          </div>

          {/* Preview Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#e2e8f0]">
              <h3 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                Batch Import Validation Preview
              </h3>
            </div>

            <div className="overflow-x-auto max-h-96">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] uppercase text-[10px] tracking-wider font-semibold sticky top-0">
                  <tr>
                    <th className="px-3 py-2.5">Row</th>
                    <th className="px-3 py-2.5">Applicant Name</th>
                    <th className="px-3 py-2.5">Department</th>
                    <th className="px-3 py-2.5">Intended Programme</th>
                    <th className="px-3 py-2.5">Marks %</th>
                    <th className="px-3 py-2.5">Status</th>
                    <th className="px-3 py-2.5">Validation Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {validationResult.rows.map((row) => (
                    <tr
                      key={row.rowNumber}
                      className={row.isValid ? 'hover:bg-slate-50' : 'bg-rose-50/40 hover:bg-rose-50/70'}
                    >
                      <td className="px-3 py-2 font-mono text-[#64748b]">{row.rowNumber}</td>
                      <td className="px-3 py-2 font-semibold text-[#1e293b]">
                        <div>{row.fullName}</div>
                        <span className="text-[10px] font-mono text-[#64748b]">{row.email}</span>
                      </td>
                      <td className="px-3 py-2 font-mono font-bold text-[#1e3a8a]">{row.department}</td>
                      <td className="px-3 py-2 text-[#334155]">{row.program}</td>
                      <td className="px-3 py-2 font-mono">{row.marksPercentage}%</td>
                      <td className="px-3 py-2">
                        {row.isValid ? (
                          <Badge variant="emerald" size="sm">Valid</Badge>
                        ) : (
                          <Badge variant="rose" size="sm">Rejected</Badge>
                        )}
                      </td>
                      <td className="px-3 py-2 text-[11px]">
                        {row.isValid ? (
                          <span className="text-emerald-700">Eligible for intake creation</span>
                        ) : (
                          <span className="text-rose-700 font-medium">
                            {row.validationErrors.join(' ')}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
