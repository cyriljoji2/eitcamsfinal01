import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  UserPlus,
  FileCheck2,
  CheckCircle2,
  XCircle,
  Eye,
  MoreVertical,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  Copy,
  Check,
  AlertCircle,
  Clock,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { ApplicantRecord, ApplicationStatus, DepartmentRecord, ProgrammeRecord } from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface AdmissionApplicationsViewProps {
  applicants: ApplicantRecord[];
  departments: DepartmentRecord[];
  programmes: ProgrammeRecord[];
  onOpenNewAdmission: () => void;
  onSelectApplicant: (applicant: ApplicantRecord) => void;
  onApproveApplication: (applicant: ApplicantRecord) => Promise<void>;
  onUpdateStatus: (applicantId: string, status: ApplicationStatus, reason?: string) => Promise<void>;
  onOpenRejectModal: (applicant: ApplicantRecord) => void;
  onConvertToStudent: (applicantId: string) => Promise<void>;
  hasApprovePermission: boolean;
}

export function AdmissionApplicationsView({
  applicants,
  departments,
  programmes,
  onOpenNewAdmission,
  onSelectApplicant,
  onApproveApplication,
  onUpdateStatus,
  onOpenRejectModal,
  onConvertToStudent,
  hasApprovePermission,
}: AdmissionApplicationsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [deptFilter, setDeptFilter] = useState<string>('ALL');
  const [progFilter, setProgFilter] = useState<string>('ALL');
  const [yearFilter, setYearFilter] = useState<number | 'ALL'>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredApplicants = useMemo(() => {
    return applicants.filter((app) => {
      // Search Match
      const q = searchTerm.toLowerCase().trim();
      const fullName = `${app.first_name} ${app.last_name}`.toLowerCase();
      const matchSearch =
        !q ||
        app.application_id.toLowerCase().includes(q) ||
        fullName.includes(q) ||
        app.email.toLowerCase().includes(q) ||
        app.phone_number.includes(q) ||
        (app.student_registration_number && app.student_registration_number.toLowerCase().includes(q));

      // Status Match
      let matchStatus = true;
      if (statusFilter === 'CONVERTED') {
        matchStatus = Boolean(app.converted_to_student);
      } else if (statusFilter !== 'ALL') {
        matchStatus = app.application_status === statusFilter;
      }

      // Department Match
      const matchDept = deptFilter === 'ALL' || app.department === deptFilter;

      // Programme Match
      const matchProg =
        progFilter === 'ALL' ||
        app.intended_program.toLowerCase() === progFilter.toLowerCase();

      // Year Match
      const matchYear = yearFilter === 'ALL' || app.admission_year === yearFilter;

      return matchSearch && matchStatus && matchDept && matchProg && matchYear;
    });
  }, [applicants, searchTerm, statusFilter, deptFilter, progFilter, yearFilter]);

  // Paginated records
  const totalPages = Math.ceil(filteredApplicants.length / pageSize) || 1;
  const paginatedApplicants = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredApplicants.slice(start, start + pageSize);
  }, [filteredApplicants, currentPage, pageSize]);

  const getStatusBadge = (status: ApplicationStatus, isConverted?: boolean) => {
    if (isConverted) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
          <GraduationCap className="w-3 h-3" />
          <span>Enrolled Student</span>
        </span>
      );
    }
    switch (status) {
      case ApplicationStatus.APPROVED:
        return <Badge variant="emerald">Approved</Badge>;
      case ApplicationStatus.UNDER_REVIEW:
        return <Badge variant="blue">Under Review</Badge>;
      case ApplicationStatus.DOCUMENTS_PENDING:
        return <Badge variant="amber">Docs Pending</Badge>;
      case ApplicationStatus.SUBMITTED:
        return <Badge variant="purple">Submitted</Badge>;
      case ApplicationStatus.REJECTED:
        return <Badge variant="rose">Rejected</Badge>;
      case ApplicationStatus.WITHDRAWN:
        return <Badge variant="neutral">Withdrawn</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">University Admissions Pipeline</h2>
          <p className="text-xs text-[#64748b]">
            Track candidate intake dossiers, verify entrance qualifications, and execute official admissions approvals
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onOpenNewAdmission}
          leftIcon={<UserPlus className="w-4 h-4" />}
        >
          New Admission Application
        </Button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Input */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, Application ID, email, Reg No..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.department_id} value={d.code}>
                  {d.name} ({d.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Application Statuses</option>
              <option value={ApplicationStatus.SUBMITTED}>Submitted (New)</option>
              <option value={ApplicationStatus.UNDER_REVIEW}>Under Review</option>
              <option value={ApplicationStatus.DOCUMENTS_PENDING}>Documents Pending</option>
              <option value={ApplicationStatus.APPROVED}>Approved</option>
              <option value="CONVERTED">Enrolled / Converted</option>
              <option value={ApplicationStatus.REJECTED}>Rejected</option>
              <option value={ApplicationStatus.WITHDRAWN}>Withdrawn / Waitlisted</option>
            </select>
          </div>

          {/* Admission Year Filter */}
          <div>
            <select
              value={yearFilter}
              onChange={(e) => {
                setYearFilter(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value));
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Intake Years</option>
              <option value={2026}>Academic Year 2026</option>
              <option value={2027}>Academic Year 2027</option>
            </select>
          </div>
        </div>

        {/* Results Count & Active Filters Indicator */}
        <div className="flex items-center justify-between text-xs text-[#64748b] pt-1">
          <span>
            Showing <strong className="text-[#1e293b]">{filteredApplicants.length}</strong> matching candidate dossiers
          </span>
          {(searchTerm || statusFilter !== 'ALL' || deptFilter !== 'ALL' || yearFilter !== 'ALL') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('ALL');
                setDeptFilter('ALL');
                setProgFilter('ALL');
                setYearFilter('ALL');
                setCurrentPage(1);
              }}
              className="text-[#1e3a8a] hover:underline font-semibold cursor-pointer"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Application ID</th>
                <th className="px-4 py-3">Applicant Name</th>
                <th className="px-4 py-3">Programme & Department</th>
                <th className="px-4 py-3">Previous Qual / Marks</th>
                <th className="px-4 py-3">Submission Date</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {paginatedApplicants.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-[#94a3b8]">
                    No application dossiers found matching the selected criteria.
                  </td>
                </tr>
              ) : (
                paginatedApplicants.map((app) => {
                  const verifiedDocs = (app.documents || []).filter(
                    (d) => d.verification_status === 'VERIFIED'
                  ).length;
                  const totalDocs = (app.documents || []).length;
                  const isCopied = copiedId === app.application_id;

                  return (
                    <tr key={app.application_id} className="hover:bg-slate-50 transition-colors">
                      {/* Application ID */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-bold text-[#1e3a8a]">{app.application_id}</span>
                          <button
                            type="button"
                            onClick={() => handleCopy(app.application_id)}
                            className="text-[#94a3b8] hover:text-[#1e293b] p-0.5"
                            title="Copy Application ID"
                          >
                            {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                        {app.converted_to_student && app.student_registration_number && (
                          <span className="font-mono text-[10px] text-purple-700 block">
                            Reg: {app.student_registration_number}
                          </span>
                        )}
                      </td>

                      {/* Applicant Name & Contact */}
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#1e293b]">
                          {app.first_name} {app.last_name}
                        </div>
                        <div className="text-[11px] text-[#64748b] flex items-center gap-1 mt-0.5">
                          <Mail className="w-3 h-3 text-[#94a3b8]" />
                          <span>{app.email}</span>
                        </div>
                        <div className="text-[11px] text-[#64748b] flex items-center gap-1">
                          <Phone className="w-3 h-3 text-[#94a3b8]" />
                          <span>{app.phone_number}</span>
                        </div>
                      </td>

                      {/* Programme & Department */}
                      <td className="px-4 py-3">
                        <div className="font-semibold text-[#1e293b]">{app.intended_program}</div>
                        <div className="text-[11px] text-[#64748b]">
                          Dept: <strong className="font-mono text-[#1e3a8a]">{app.department}</strong> &bull; Intake {app.admission_year}
                        </div>
                      </td>

                      {/* Previous Qualification & Marks */}
                      <td className="px-4 py-3">
                        <div className="text-[#334155] font-medium">{app.previous_qualification}</div>
                        <div className="text-[11px] text-[#64748b]">
                          Aggregate: <strong className="text-[#1e293b]">{app.marks_percentage}%</strong>
                        </div>
                      </td>

                      {/* Date & Docs Status */}
                      <td className="px-4 py-3">
                        <div className="text-[#334155]">{app.application_date}</div>
                        <div className="text-[11px] text-[#64748b] mt-0.5 flex items-center gap-1">
                          <FileCheck2 className="w-3 h-3 text-[#64748b]" />
                          <span>
                            Docs: {verifiedDocs}/{totalDocs} verified
                          </span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3">
                        {getStatusBadge(app.application_status, app.converted_to_student)}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onSelectApplicant(app)}
                            leftIcon={<Eye className="w-3.5 h-3.5" />}
                          >
                            Inspect
                          </Button>

                          {/* Quick workflow actions */}
                          {app.application_status === ApplicationStatus.SUBMITTED && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-blue-700 hover:bg-blue-50"
                              onClick={() => onUpdateStatus(app.application_id, ApplicationStatus.UNDER_REVIEW, 'Moved to under review')}
                              title="Begin review scrutiny"
                            >
                              Review
                            </Button>
                          )}

                          {app.application_status === ApplicationStatus.UNDER_REVIEW && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-emerald-700 hover:bg-emerald-50"
                                onClick={() => onApproveApplication(app)}
                                title="Approve candidate admission"
                              >
                                Approve
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-rose-700 hover:bg-rose-50"
                                onClick={() => onOpenRejectModal(app)}
                                title="Reject candidate application"
                              >
                                Reject
                              </Button>
                            </>
                          )}

                          {app.application_status === ApplicationStatus.APPROVED && !app.converted_to_student && (
                            <Button
                              variant="primary"
                              size="sm"
                              className="bg-purple-700 hover:bg-purple-800"
                              onClick={() => onConvertToStudent(app.application_id)}
                              leftIcon={<GraduationCap className="w-3.5 h-3.5" />}
                            >
                              Enrol
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
