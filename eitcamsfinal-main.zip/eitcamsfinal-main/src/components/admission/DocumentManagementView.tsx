import React, { useState, useMemo } from 'react';
import {
  Search,
  FileCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  AlertCircle,
  Calendar,
  User,
  Filter,
  Check,
  Building2,
  Eye,
} from 'lucide-react';
import { ApplicantRecord, DepartmentRecord } from '../../types/database';
import { UniversityDocumentRow } from '../../types/admission';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface DocumentManagementViewProps {
  applicants: ApplicantRecord[];
  departments: DepartmentRecord[];
  onOpenDocModal: (docRow: UniversityDocumentRow) => void;
  onQuickVerify: (applicationId: string, documentId: string) => Promise<void>;
  onSelectApplicant: (applicant: ApplicantRecord) => void;
}

export function DocumentManagementView({
  applicants,
  departments,
  onOpenDocModal,
  onQuickVerify,
  onSelectApplicant,
}: DocumentManagementViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [deptFilter, setDeptFilter] = useState('ALL');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  // Flatten all applicant documents
  const allDocRows: UniversityDocumentRow[] = useMemo(() => {
    const list: UniversityDocumentRow[] = [];
    applicants.forEach((app) => {
      (app.documents || []).forEach((doc) => {
        list.push({
          documentId: doc.document_id,
          applicationId: app.application_id,
          applicantName: `${app.first_name} ${app.last_name}`,
          applicantEmail: app.email,
          department: app.department,
          intendedProgram: app.intended_program,
          documentType: doc.document_type,
          documentCode: doc.document_code,
          isMandatory: doc.is_mandatory,
          submissionStatus: doc.submission_status as any,
          verificationStatus: doc.verification_status as any,
          reviewerNotes: doc.reviewer_notes,
          verifiedBy: doc.verified_by,
          verifiedAt: doc.verified_at,
          applicant: app,
        });
      });
    });
    return list;
  }, [applicants]);

  const uniqueDocTypes = useMemo(() => {
    return Array.from(new Set(allDocRows.map((d) => d.documentType))).sort();
  }, [allDocRows]);

  const filteredDocRows = useMemo(() => {
    return allDocRows.filter((row) => {
      const q = searchTerm.toLowerCase().trim();
      const matchSearch =
        !q ||
        row.applicantName.toLowerCase().includes(q) ||
        row.applicationId.toLowerCase().includes(q) ||
        row.documentType.toLowerCase().includes(q) ||
        row.applicantEmail.toLowerCase().includes(q);

      const matchStatus = statusFilter === 'ALL' || row.verificationStatus === statusFilter;
      const matchType = typeFilter === 'ALL' || row.documentType === typeFilter;
      const matchDept = deptFilter === 'ALL' || row.department === deptFilter;

      return matchSearch && matchStatus && matchType && matchDept;
    });
  }, [allDocRows, searchTerm, statusFilter, typeFilter, deptFilter]);

  const totalPages = Math.ceil(filteredDocRows.length / pageSize) || 1;
  const paginatedDocRows = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredDocRows.slice(start, start + pageSize);
  }, [filteredDocRows, currentPage, pageSize]);

  const pendingVerificationCount = allDocRows.filter(
    (d) => d.submissionStatus === 'SUBMITTED' && d.verificationStatus !== 'VERIFIED'
  ).length;

  const getDocStatusBadge = (status: 'PENDING' | 'VERIFIED' | 'REJECTED') => {
    switch (status) {
      case 'VERIFIED':
        return <Badge variant="emerald">Verified</Badge>;
      case 'REJECTED':
        return <Badge variant="rose">Rejected</Badge>;
      case 'PENDING':
      default:
        return <Badge variant="amber">Pending Review</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-[18px] font-bold text-[#1e293b]">University Document Verification Desk</h2>
          <p className="text-xs text-[#64748b]">
            Inspect candidate certificates, marksheets, identity credentials, and entrance scorecards
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="purple" size="md">
            {pendingVerificationCount} Pending Reviews
          </Badge>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search candidate name, App ID, doc..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Verification Decisions</option>
              <option value="PENDING">Pending Verification</option>
              <option value="VERIFIED">Verified (Approved)</option>
              <option value="REJECTED">Rejected Documents</option>
            </select>
          </div>

          {/* Document Type Filter */}
          <div>
            <select
              value={typeFilter}
              onChange={(e) => {
                setTypeFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Document Categories</option>
              {uniqueDocTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-2 px-3 text-xs rounded-lg border border-[#e2e8f0] bg-white text-[#1e293b] focus:border-[#1e3a8a] outline-none font-medium"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.department_id} value={d.code}>
                  {d.name} ({d.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Results summary */}
        <div className="flex items-center justify-between text-xs text-[#64748b] pt-1">
          <span>
            Total Checklist Items: <strong className="text-[#1e293b]">{filteredDocRows.length}</strong>
          </span>
          {(searchTerm || statusFilter !== 'ALL' || typeFilter !== 'ALL' || deptFilter !== 'ALL') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('ALL');
                setTypeFilter('ALL');
                setDeptFilter('ALL');
                setCurrentPage(1);
              }}
              className="text-[#1e3a8a] hover:underline font-semibold cursor-pointer"
            >
              Clear filters
            </button>
          )}
        </div>
      </div>

      {/* Documents Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] uppercase text-[10px] tracking-wider font-semibold">
              <tr>
                <th className="px-4 py-3">Document Category</th>
                <th className="px-4 py-3">Candidate / Application</th>
                <th className="px-4 py-3">Department & Programme</th>
                <th className="px-4 py-3">Submission Status</th>
                <th className="px-4 py-3">Verification Decision</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {paginatedDocRows.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-[#94a3b8]">
                    No document items found matching filter criteria.
                  </td>
                </tr>
              ) : (
                paginatedDocRows.map((row) => (
                  <tr key={`${row.applicationId}-${row.documentId}`} className="hover:bg-slate-50 transition-colors">
                    {/* Document Category & Mandatory Tag */}
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-[#1e3a8a] shrink-0" />
                        <div>
                          <span className="font-semibold text-[#1e293b] block">{row.documentType}</span>
                          <span className="text-[10px] font-mono text-[#64748b]">{row.documentCode}</span>
                        </div>
                      </div>
                      {row.isMandatory ? (
                        <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200 mt-1 inline-block">
                          Mandatory
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#64748b] bg-slate-100 px-1.5 py-0.2 rounded mt-1 inline-block">
                          Optional
                        </span>
                      )}
                    </td>

                    {/* Candidate & Application ID */}
                    <td className="px-4 py-3">
                      <div className="font-semibold text-[#1e293b]">{row.applicantName}</div>
                      <span className="font-mono text-[11px] text-[#1e3a8a] font-bold block">
                        {row.applicationId}
                      </span>
                      <span className="text-[10px] text-[#64748b]">{row.applicantEmail}</span>
                    </td>

                    {/* Department & Programme */}
                    <td className="px-4 py-3">
                      <div className="font-medium text-[#1e293b]">{row.intendedProgram}</div>
                      <span className="text-[10px] font-mono text-[#64748b]">Dept: {row.department}</span>
                    </td>

                    {/* Submission Status */}
                    <td className="px-4 py-3">
                      {row.submissionStatus === 'SUBMITTED' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Submitted</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-amber-700 font-medium text-[11px]">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Pending Upload</span>
                        </span>
                      )}
                      {row.reviewerNotes && (
                        <p className="text-[10px] text-[#64748b] truncate max-w-xs mt-0.5" title={row.reviewerNotes}>
                          Note: {row.reviewerNotes}
                        </p>
                      )}
                    </td>

                    {/* Verification Status */}
                    <td className="px-4 py-3">
                      {getDocStatusBadge(row.verificationStatus)}
                      {row.verifiedBy && (
                        <span className="text-[10px] text-[#64748b] block mt-0.5">
                          By: {row.verifiedBy}
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {row.verificationStatus !== 'VERIFIED' && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-emerald-700 border-emerald-300 hover:bg-emerald-50"
                            onClick={() => onQuickVerify(row.applicationId, row.documentId)}
                            leftIcon={<Check className="w-3 h-3" />}
                            title="Directly mark verified"
                          >
                            Quick Verify
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onOpenDocModal(row)}
                          leftIcon={<Eye className="w-3.5 h-3.5" />}
                        >
                          Review
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <div className="flex items-center gap-1.5">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
