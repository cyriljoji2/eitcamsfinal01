import React from 'react';
import {
  GraduationCap,
  LogOut,
  Menu,
  X,
  Sparkles,
  Building2,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Button } from '../ui/Button';
import { SyncStatusBadge } from '../common/SyncStatusBadge';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

export interface AdmissionHeaderProps {
  user: UserSession;
  onLogout: () => void;
  isMobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
}

export function AdmissionHeader({
  user,
  onLogout,
  isMobileMenuOpen,
  onToggleMobileMenu,
}: AdmissionHeaderProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo & Institute Branding */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onToggleMobileMenu}
            className="lg:hidden text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-[15px] text-[#1e293b] block leading-tight tracking-tight">
                Electrix Institute of Technology
              </span>
              <span className="text-[11px] font-bold text-[#1e3a8a] tracking-wider block uppercase">
                UNIVERSITY ADMISSIONS OFFICE
              </span>
            </div>
          </div>
        </div>

        {/* Right Header items */}
        <div className="flex items-center gap-3">
          <SyncStatusBadge />
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-[#eff6ff] rounded-md border border-[#dbeafe] text-xs font-semibold text-[#1e3a8a]">
            <span>Session:</span>
            <span className="font-mono font-bold">{activeAcademicYear || '2026–2027'}</span>
          </div>

          <div className="flex items-center gap-2.5 pl-2 border-l border-[#e2e8f0]">
            <div className="hidden md:block text-right">
              <span className="text-xs font-bold text-[#1e293b] block">{user.name}</span>
              <span className="text-[11px] text-[#64748b] block">{user.roleTitle || 'Admissions Administrator'}</span>
            </div>

            <div className="w-8 h-8 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center font-bold text-xs border border-[#dbeafe] shadow-2xs">
              {user.name?.charAt(0) || 'A'}
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="text-[#64748b] hover:text-rose-600 p-1.5"
              title="Sign out of Admissions Office"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
