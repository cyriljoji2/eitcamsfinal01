import { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { AcademicWorkspace } from './academic/AcademicWorkspace';
import { UserSession } from '../types/auth';

interface AcademicOfficeSectionProps {
  onRefreshData?: () => Promise<void>;
}

export function AcademicOfficeSection({ onRefreshData }: AcademicOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'Academic Office Admin';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-003',
      username: session?.user?.username || 'academicoffice',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'academicoffice@eit.edu',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'Academic Office Admin',
      department: emp?.primary_department || 'ACADEMIC',
      portalType: 'employee',
    };
  }, [session]);

  const handleLogout = async () => {
    await logout();
  };

  return <AcademicWorkspace user={userSession} onLogout={handleLogout} />;
}
