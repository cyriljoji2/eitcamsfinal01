import React, { useState } from 'react';
import { X, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';
import { IdCardRecord, IdCardStatus } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface IdCardReissueModalProps {
  isOpen: boolean;
  onClose: () => void;
  card: IdCardRecord | null;
  operatorId: string;
  operatorRole: string;
  onSuccess?: () => void;
}

export function IdCardReissueModal({
  isOpen,
  onClose,
  card,
  operatorId,
  operatorRole,
  onSuccess,
}: IdCardReissueModalProps) {
  const [reissueReason, setReissueReason] = useState('CARD_LOST');
  const [customReason, setCustomReason] = useState('');
  const [newStatus, setNewStatus] = useState<IdCardStatus>('ACTIVE');
  const [actionType, setActionType] = useState<'REISSUE' | 'UPDATE_STATUS'>('REISSUE');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen || !card) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalReason = reissueReason === 'OTHER' ? customReason.trim() : reissueReason;
    if (!finalReason) {
      setErrorMsg('Please specify an official reason.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      if (actionType === 'REISSUE') {
        await itRepository.reissueIdCard(card.card_id, finalReason, {
          userId: operatorId,
          role: operatorRole,
        });
      } else {
        await itRepository.updateIdCardStatus(card.card_id, newStatus, finalReason, {
          userId: operatorId,
          role: operatorRole,
        });
      }

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Operation failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in duration-200">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold tracking-tight">
              Manage ID Card &bull; {card.registration_number}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
            <p className="font-bold text-slate-800 text-sm">{card.full_name}</p>
            <p className="text-slate-500 font-mono text-[11px]">{card.registration_number} &bull; {card.card_type}</p>
            <p className="text-slate-600 text-[11px]">Current Status: <strong className="text-emerald-700">{card.status}</strong> (Reissues: {card.reissue_count})</p>
          </div>

          <div className="flex gap-2 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setActionType('REISSUE')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                actionType === 'REISSUE' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Issue Replacement Card
            </button>
            <button
              type="button"
              onClick={() => setActionType('UPDATE_STATUS')}
              className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all cursor-pointer ${
                actionType === 'UPDATE_STATUS' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Update Card Status
            </button>
          </div>

          {actionType === 'UPDATE_STATUS' && (
            <div>
              <label className="font-bold text-slate-700 block mb-1">New Status</label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as IdCardStatus)}
                className="w-full p-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="ACTIVE">ACTIVE</option>
                <option value="SUSPENDED">SUSPENDED</option>
                <option value="LOST">LOST (Reported lost by student/employee)</option>
                <option value="DAMAGED">DAMAGED (Physical wear/defaced)</option>
                <option value="EXPIRED">EXPIRED</option>
              </select>
            </div>
          )}

          <div>
            <label className="font-bold text-slate-700 block mb-1">
              {actionType === 'REISSUE' ? 'Reason for Reissue' : 'Reason for Status Change'}
            </label>
            <select
              value={reissueReason}
              onChange={(e) => setReissueReason(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg bg-white"
            >
              <option value="CARD_LOST">Original Card Lost / Misplaced</option>
              <option value="CARD_DAMAGED">Card Damaged / Barcode unreadable</option>
              <option value="NAME_DESIGNATION_CHANGE">Official Designation or Dept Update</option>
              <option value="PHOTO_UPDATE">Updated Institutional Photograph</option>
              <option value="OTHER">Other Reason (Specify below)</option>
            </select>
          </div>

          {reissueReason === 'OTHER' && (
            <div>
              <label className="font-bold text-slate-700 block mb-1">Specify Reason</label>
              <textarea
                value={customReason}
                onChange={(e) => setCustomReason(e.target.value)}
                placeholder="Details for audit logging..."
                rows={2}
                className="w-full p-2 border border-slate-300 rounded-lg"
                required
              />
            </div>
          )}

          {errorMsg && (
            <div className="p-2 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onClose}
              disabled={isSubmitting}
              className="text-xs cursor-pointer"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
              className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
            >
              {isSubmitting ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : actionType === 'REISSUE' ? (
                'Generate Reissued Card'
              ) : (
                'Update Status'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
