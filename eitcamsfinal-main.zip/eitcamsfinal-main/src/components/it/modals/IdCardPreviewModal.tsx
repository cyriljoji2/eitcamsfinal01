import React, { useRef } from 'react';
import {
  X,
  Printer,
  QrCode,
  CheckCircle2,
  ShieldCheck,
  Building2,
  GraduationCap,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { IdCardRecord } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';

interface IdCardPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  card: IdCardRecord | null;
  onReissue?: (card: IdCardRecord) => void;
}

export function IdCardPreviewModal({
  isOpen,
  onClose,
  card,
  onReissue,
}: IdCardPreviewModalProps) {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !card) return null;

  const handlePrint = () => {
    window.print();
  };

  const isStudent = card.card_type === 'STUDENT';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-bold tracking-tight">
              Official Institutional ID Card &bull; {card.card_type}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Card Body */}
        <div className="p-6 space-y-6">
          {/* Printable Card Container */}
          <div
            ref={printRef}
            className="w-full rounded-2xl overflow-hidden border-2 border-slate-800 bg-linear-to-br from-slate-900 via-[#1E3A8A] to-slate-950 text-white shadow-xl p-5 relative"
          >
            {/* Background Hologram watermark effect */}
            <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none transform translate-x-6 translate-y-6">
              <Building2 className="w-56 h-56" />
            </div>

            {/* Card Header */}
            <div className="flex items-center justify-between border-b border-white/20 pb-3 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white text-[#1e3a8a] flex items-center justify-center font-black text-sm shadow-xs">
                  EIT
                </div>
                <div>
                  <h4 className="text-xs font-black tracking-wider uppercase text-cyan-200">
                    Electrix Institute of Technology
                  </h4>
                  <p className="text-[9px] text-white/70 tracking-widest uppercase font-semibold">
                    {isStudent ? 'Student Identity Credential' : 'Faculty & Staff Credential'}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-black bg-cyan-400/20 text-cyan-200 border border-cyan-300/30 px-2 py-0.5 rounded-md uppercase">
                {card.status}
              </span>
            </div>

            {/* Card Content Row */}
            <div className="flex gap-4">
              {/* Photo & QR */}
              <div className="flex flex-col items-center gap-2 shrink-0">
                <div className="w-24 h-28 rounded-xl bg-slate-800 border-2 border-white/40 overflow-hidden shadow-inner flex items-center justify-center relative">
                  {card.photo_url ? (
                    <img
                      src={card.photo_url}
                      alt={card.full_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-3xl font-black text-white/40">
                      {card.full_name.charAt(0)}
                    </div>
                  )}
                </div>

                <div className="w-20 h-20 bg-white p-1 rounded-lg shadow-xs flex flex-col items-center justify-center">
                  <QrCode className="w-14 h-14 text-slate-900" />
                  <span className="text-[7px] text-slate-600 font-mono font-bold">VERIFIED</span>
                </div>
              </div>

              {/* Identity Details */}
              <div className="flex-1 min-w-0 space-y-2 text-xs">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-cyan-300/80 font-bold block">
                    Full Name
                  </span>
                  <p className="text-base font-black text-white leading-tight truncate">
                    {card.full_name}
                  </p>
                </div>

                <div>
                  <span className="text-[9px] uppercase tracking-wider text-cyan-300/80 font-bold block">
                    Registration / ID No.
                  </span>
                  <p className="font-mono font-bold text-cyan-300 text-sm">
                    {card.registration_number}
                  </p>
                </div>

                <div>
                  <span className="text-[9px] uppercase tracking-wider text-cyan-300/80 font-bold block">
                    {isStudent ? 'Program & Department' : 'Designation & Department'}
                  </span>
                  <p className="font-semibold text-white/90 text-[11px] leading-tight">
                    {card.designation_or_program} &bull; {card.department}
                  </p>
                </div>

                <div>
                  <span className="text-[9px] uppercase tracking-wider text-cyan-300/80 font-bold block">
                    {isStudent ? 'Cohort / Standing' : 'Office Division'}
                  </span>
                  <p className="text-[10px] text-white/80 font-medium truncate">
                    {card.office_or_year}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10 text-[10px]">
                  <div>
                    <span className="text-white/60 block text-[8px] uppercase">Issued</span>
                    <span className="font-semibold">{card.issue_date}</span>
                  </div>
                  <div>
                    <span className="text-white/60 block text-[8px] uppercase">Expires</span>
                    <span className="font-semibold text-emerald-300">{card.expiry_date}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Signature Line */}
            <div className="mt-3 pt-2 border-t border-white/20 flex items-center justify-between text-[8px] text-white/60 font-mono">
              <span>CARD: {card.card_id}</span>
              <span>REISSUE COUNT: {card.reissue_count}</span>
              <span className="text-cyan-300 uppercase">OFFICIAL REGISTRAR SEAL</span>
            </div>
          </div>

          {/* Verification Details */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1">
            <div className="flex items-center justify-between text-slate-700 font-medium">
              <span>Cryptographic QR Reference:</span>
              <span className="text-[10px] font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-800 truncate max-w-[200px]">
                {card.qr_code_payload}
              </span>
            </div>
            {card.reissue_count > 0 && (
              <p className="text-[11px] text-amber-700 flex items-center gap-1 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                This card has been reissued {card.reissue_count} times. (Last reason: {card.reissue_reason || 'N/A'})
              </p>
            )}
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div>
            {onReissue && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onReissue(card)}
                className="text-xs text-amber-700 hover:bg-amber-50 border-amber-300 cursor-pointer"
              >
                Reissue Card
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="text-xs cursor-pointer"
            >
              Close
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handlePrint}
              leftIcon={<Printer className="w-4 h-4" />}
              className="text-xs bg-[#1e3a8a] hover:bg-[#172e6e] cursor-pointer"
            >
              Print ID Card
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
