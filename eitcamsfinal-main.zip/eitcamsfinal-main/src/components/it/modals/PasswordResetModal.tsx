import React, { useState, useEffect } from 'react';
import {
  X,
  KeyRound,
  Search,
  CheckCircle2,
  AlertTriangle,
  Copy,
  ShieldAlert,
  UserCheck,
  RefreshCw,
} from 'lucide-react';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface PasswordResetModalProps {
  isOpen: boolean;
  onClose: () => void;
  operatorId: string;
  operatorName: string;
  operatorRole: string;
  onSuccess?: () => void;
}

export function PasswordResetModal({
  isOpen,
  onClose,
  operatorId,
  operatorName,
  operatorRole,
  onSuccess,
}: PasswordResetModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<any | null>(null);
  const [reason, setReason] = useState('STUDENT_REQUEST');
  const [customReason, setCustomReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successResult, setSuccessResult] = useState<{
    tempPasswordToken: string;
    message: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSearchQuery('');
      setSearchResults([]);
      setSelectedAccount(null);
      setSuccessResult(null);
      setErrorMessage(null);
      setCustomReason('');
    }
  }, [isOpen]);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setErrorMessage(null);
    try {
      const results = await itRepository.searchAccounts(searchQuery);
      setSearchResults(results);
      if (results.length === 0) {
        setErrorMessage(`No institutional account found matching "${searchQuery}".`);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to search accounts.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleExecuteReset = async () => {
    if (!selectedAccount) return;
    const finalReason = reason === 'OTHER' ? customReason.trim() : reason;
    if (!finalReason) {
      setErrorMessage('Please specify an authoritative reason for the credential reset.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const res = await itRepository.resetPassword(
        {
          usernameOrId: selectedAccount.username,
          reason: finalReason,
        },
        {
          userId: operatorId,
          role: operatorRole,
          operatorName,
        }
      );
      setSuccessResult(res);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setErrorMessage(err.message || 'Password reset failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-[#1E3A8A] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-cyan-300" />
            <h3 className="text-sm font-bold tracking-tight">
              Institutional Account Password Reset
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {successResult ? (
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-xs text-emerald-900">
                  <p className="font-bold text-sm">Temporary Credential Generated</p>
                  <p className="mt-1">{successResult.message}</p>
                </div>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl text-white space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>One-Time Temporary Credential</span>
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                    EXPIRES ON LOGIN
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 p-3 bg-black/40 rounded-lg border border-white/10 font-mono text-base font-bold text-cyan-300">
                  <span className="tracking-wider">{successResult.tempPasswordToken}</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(successResult.tempPasswordToken)}
                    className="p-1.5 hover:bg-white/10 rounded text-slate-300 hover:text-white transition-colors cursor-pointer"
                    title="Copy temporary credential"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                {copied && (
                  <p className="text-[11px] text-emerald-400 font-medium">
                    Copied credential to clipboard.
                  </p>
                )}
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-800 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  Security Enforcement Active:
                </p>
                <ul className="list-disc list-inside space-y-0.5 text-[11px]">
                  <li>All previous active sessions for this account have been invalidated.</li>
                  <li>User will be forced to change their password immediately upon login.</li>
                  <li>This reset event has been recorded in the immutable IT security audit log.</li>
                </ul>
              </div>
            </div>
          ) : (
            <>
              {/* Step 1: Search Account */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 block">
                  1. Search Authoritative Account (Username, Reg No., or Email)
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                      placeholder="e.g. EIT-STU-2026-CSE-0001, arvind.sharma, or admin"
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent outline-hidden"
                    />
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSearch}
                    disabled={isSearching || !searchQuery.trim()}
                    className="text-xs cursor-pointer"
                  >
                    {isSearching ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'Search'}
                  </Button>
                </div>
              </div>

              {/* Search Results List */}
              {searchResults.length > 0 && !selectedAccount && (
                <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-48 overflow-y-auto bg-slate-50">
                  {searchResults.map((acc) => (
                    <div
                      key={acc.user_id + acc.username}
                      onClick={() => setSelectedAccount(acc)}
                      className="p-3 hover:bg-blue-50 cursor-pointer flex items-center justify-between transition-colors text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900">{acc.full_name}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-200 text-slate-700">
                            {acc.account_type}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono">{acc.username} &bull; {acc.email}</p>
                      </div>
                      <Button size="sm" variant="outline" className="text-[10px] py-1 h-auto cursor-pointer">
                        Select
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              {/* Step 2: Selected Account & Verification */}
              {selectedAccount && (
                <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#1e3a8a] flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4 text-emerald-600" />
                      Target Account Verified
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedAccount(null)}
                      className="text-xs text-blue-600 hover:underline cursor-pointer"
                    >
                      Change
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-white p-2.5 rounded-lg border border-blue-100">
                    <div>
                      <span className="text-slate-500 block">Name:</span>
                      <span className="font-bold text-slate-900">{selectedAccount.full_name}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Username / Reg:</span>
                      <span className="font-mono font-bold text-slate-900">{selectedAccount.username}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Role / Office:</span>
                      <span className="text-slate-800">{selectedAccount.department_or_office}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Account Status:</span>
                      <span className="font-bold text-emerald-700">{selectedAccount.status}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Reason Selection */}
              {selectedAccount && (
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-700 block">
                    2. Select Reason for Password Reset
                  </label>
                  <select
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent outline-hidden bg-white"
                  >
                    <option value="STUDENT_REQUEST">User requested reset — verified identity in person / official mail</option>
                    <option value="CREDENTIAL_MISPLACED">Misplaced or lost onboarding credential document</option>
                    <option value="SUSPECTED_COMPROMISE">Security alert: Suspected unauthorized access attempt</option>
                    <option value="SEMESTER_REGISTRATION_ASSIST">Academic Office / Hostel clearance support assistance</option>
                    <option value="OTHER">Other verified institutional reason (specify below)</option>
                  </select>

                  {reason === 'OTHER' && (
                    <textarea
                      value={customReason}
                      onChange={(e) => setCustomReason(e.target.value)}
                      placeholder="Enter detailed reason for the audit log..."
                      rows={2}
                      className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-[#1E3A8A] focus:border-transparent outline-hidden"
                    />
                  )}
                </div>
              )}

              {errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
                  <p>{errorMessage}</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
          {successResult ? (
            <Button
              variant="primary"
              size="sm"
              onClick={onClose}
              className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
            >
              Done
            </Button>
          ) : (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                disabled={isSubmitting}
                className="text-xs cursor-pointer"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecuteReset}
                disabled={!selectedAccount || isSubmitting}
                className="text-xs bg-red-700 hover:bg-red-800 cursor-pointer"
              >
                {isSubmitting ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  'Reset Account Password'
                )}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
