import React, { useState } from 'react';
import {
  X,
  LifeBuoy,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Send,
} from 'lucide-react';
import { TicketCategory, TicketPriority } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface NewTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  requesterId: string;
  requesterName: string;
  requesterAccountType: 'STUDENT' | 'EMPLOYEE' | 'PARENT' | 'OFFICE';
  requesterEmail: string;
  requesterPhone?: string;
  onTicketCreated?: () => void;
}

export function NewTicketModal({
  isOpen,
  onClose,
  requesterId,
  requesterName,
  requesterAccountType,
  requesterEmail,
  requesterPhone,
  onTicketCreated,
}: NewTicketModalProps) {
  const [category, setCategory] = useState<TicketCategory>('LOGIN_ACCESS');
  const [priority, setPriority] = useState<TicketPriority>('NORMAL');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [createdTicketNumber, setCreatedTicketNumber] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) {
      setErrorMsg('Please specify a ticket subject.');
      return;
    }
    if (!description.trim()) {
      setErrorMsg('Please describe your technical issue.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      const ticket = await itRepository.createTicket({
        requester_id: requesterId,
        requester_name: requesterName,
        requester_account_type: requesterAccountType,
        requester_email: requesterEmail,
        requester_phone: requesterPhone,
        category,
        priority,
        subject: subject.trim(),
        description: description.trim(),
      });

      setCreatedTicketNumber(ticket.ticket_number);
      if (onTicketCreated) onTicketCreated();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit ticket.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetAndClose = () => {
    setSubject('');
    setDescription('');
    setCreatedTicketNumber(null);
    setErrorMsg(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-[#1E3A8A] text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-cyan-300" />
            <h3 className="text-sm font-bold tracking-tight">
              Submit Institutional IT Support Ticket
            </h3>
          </div>
          <button
            type="button"
            onClick={handleResetAndClose}
            className="text-white/70 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {createdTicketNumber ? (
          <div className="p-6 space-y-4">
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-900 space-y-1">
                <p className="font-bold text-sm">Ticket Successfully Logged!</p>
                <p>
                  Your ticket reference is{' '}
                  <strong className="font-mono text-emerald-950 text-sm">
                    {createdTicketNumber}
                  </strong>
                  .
                </p>
                <p className="text-[11px] text-emerald-700">
                  An automatic SLA response deadline has been computed. Our IT team has been notified and will assist you shortly.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button
                variant="primary"
                size="sm"
                onClick={handleResetAndClose}
                className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
              >
                Close
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Issue Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as TicketCategory)}
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
                >
                  <option value="LOGIN_ACCESS">Login & Account Access</option>
                  <option value="PASSWORD_RESET">Password Reset</option>
                  <option value="ID_CARD">Student/Employee ID Card</option>
                  <option value="PORTAL_MALFUNCTION">Portal Malfunction / Bug</option>
                  <option value="NETWORK">Campus Network / Wi-Fi</option>
                  <option value="HARDWARE">Lab / Classroom Hardware</option>
                  <option value="SOFTWARE">Software / License Request</option>
                  <option value="EMAIL">Institutional Email Service</option>
                  <option value="PERMISSION_ACCESS">Permission / Access Rights</option>
                  <option value="SECURITY_INCIDENT">Security Incident Report</option>
                  <option value="OTHER">Other Technical Query</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Urgency Priority</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as TicketPriority)}
                  className="w-full p-2 border border-slate-300 rounded-lg bg-white outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
                >
                  <option value="LOW">Low (General guidance / questions)</option>
                  <option value="NORMAL">Normal (Standard operational task)</option>
                  <option value="HIGH">High (Impacts classroom/office duties)</option>
                  <option value="CRITICAL">Critical (System down / exam block)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Brief summary of the issue..."
                className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
                required
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Detailed Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Please describe what happened, steps to reproduce, or specific assistance needed..."
                rows={4}
                className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
                required
              />
            </div>

            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-[11px] text-slate-600 space-y-0.5">
              <span className="font-bold text-slate-700">Requester Contact Confirmation:</span>
              <p>{requesterName} &bull; {requesterEmail} &bull; {requesterAccountType}</p>
            </div>

            {errorMsg && (
              <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleResetAndClose}
                disabled={isSubmitting}
                className="text-xs cursor-pointer"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="sm"
                disabled={isSubmitting}
                leftIcon={isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Ticket'}
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
