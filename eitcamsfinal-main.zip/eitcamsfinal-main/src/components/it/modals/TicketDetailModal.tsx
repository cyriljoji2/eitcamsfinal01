import React, { useState, useEffect } from 'react';
import {
  X,
  MessageSquare,
  Clock,
  ShieldAlert,
  UserCheck,
  Send,
  Lock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Building2,
  FileText,
  User,
  Star,
  Paperclip,
  History,
  Tag,
  AlertCircle,
  PauseCircle,
  PlayCircle,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';
import {
  TicketRecord,
  TicketStatus,
  TicketActivityEntry,
  ALLOWED_STATUS_TRANSITIONS,
} from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface TicketDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  ticket: TicketRecord | null;
  currentUserId: string;
  currentUserRole: string;
  currentUserName: string;
  isItStaff: boolean;
  onTicketUpdated: () => void;
}

const ALL_STATUSES: { value: TicketStatus; label: string }[] = [
  { value: 'OPEN', label: 'Open' },
  { value: 'ASSIGNED', label: 'Assigned' },
  { value: 'IN_PROGRESS', label: 'In Progress' },
  { value: 'AWAITING_REQUESTER', label: 'Awaiting Requester' },
  { value: 'AWAITING_THIRD_PARTY', label: 'Awaiting Third Party' },
  { value: 'ESCALATED', label: 'Escalated' },
  { value: 'RESOLVED', label: 'Resolved' },
  { value: 'CLOSED', label: 'Closed' },
  { value: 'REOPENED', label: 'Reopened' },
];

export function TicketDetailModal({
  isOpen,
  onClose,
  ticket,
  currentUserId,
  currentUserRole,
  currentUserName,
  isItStaff,
  onTicketUpdated,
}: TicketDetailModalProps) {
  const [activeTab, setActiveTab] = useState<'CONVERSATION' | 'ACTIVITY' | 'ATTACHMENTS'>('CONVERSATION');

  // Reply / Note State
  const [replyMessage, setReplyMessage] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Status Management State
  const [selectedStatus, setSelectedStatus] = useState<TicketStatus | ''>('');
  const [statusNote, setStatusNote] = useState('');
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [escalationReason, setEscalationReason] = useState('');
  const [reopenReason, setReopenReason] = useState('');
  const [statusIsInternal, setStatusIsInternal] = useState(false);
  const [statusSuccessMessage, setStatusSuccessMessage] = useState<string | null>(null);

  // Technician Assignment State
  const [availableTechnicians, setAvailableTechnicians] = useState<
    { id: string; name: string; title: string }[]
  >([]);
  const [assigneeId, setAssigneeId] = useState('');
  const [assigneeName, setAssigneeName] = useState('');

  // General error state
  const [actionError, setActionError] = useState<string | null>(null);

  // Reset local state when ticket changes
  useEffect(() => {
    if (ticket) {
      setSelectedStatus(ticket.status);
      setAssigneeId(ticket.assigned_to_employee_id || '');
      setAssigneeName(ticket.assigned_to_name || '');
      setResolutionNotes(ticket.resolution_notes || '');
      setEscalationReason(ticket.escalation_reason || '');
      setReopenReason(ticket.reopen_reason || '');
      setStatusNote('');
      setActionError(null);
      setStatusSuccessMessage(null);
    }
  }, [ticket?.ticket_id, ticket?.status]);

  // Load officially assigned IT technicians from Administration records
  useEffect(() => {
    if (isItStaff && isOpen) {
      itRepository
        .getItAssignedEmployees()
        .then((assigned) => {
          const list = [
            {
              id: 'itoffice',
              name: 'IT Department Pool',
              title: 'Central Helpdesk Queue',
            },
            ...assigned.map((a) => ({
              id: a.employee.employee_id,
              name: `${a.employee.first_name} ${a.employee.last_name}`,
              title: a.assignment.assigned_role_title || a.employee.designation,
            })),
          ];
          setAvailableTechnicians(list);
        })
        .catch((err) => {
          console.error('Failed to load IT technicians', err);
        });
    }
  }, [isItStaff, isOpen]);

  if (!isOpen || !ticket) return null;

  const currentAllowedTransitions = ALLOWED_STATUS_TRANSITIONS[ticket.status] || [];

  const handleSendReply = async () => {
    if (!replyMessage.trim()) return;
    setIsSubmitting(true);
    setActionError(null);
    try {
      await itRepository.addTicketResponse(
        ticket.ticket_id,
        replyMessage,
        isInternalNote,
        {
          userId: currentUserId,
          role: currentUserRole,
          authorName: currentUserName,
        }
      );
      setReplyMessage('');
      setIsInternalNote(false);
      onTicketUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to send message.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateStatus = async () => {
    if (!selectedStatus) return;
    if (selectedStatus === ticket.status && !statusNote.trim()) {
      setActionError('Please select a different status or provide a transition note.');
      return;
    }

    // Validation for specific status requirements
    if (selectedStatus === 'RESOLVED' && !resolutionNotes.trim() && !statusNote.trim()) {
      setActionError('A resolution note is required when marking a ticket as Resolved.');
      return;
    }
    if (selectedStatus === 'ESCALATED' && !escalationReason.trim() && !statusNote.trim()) {
      setActionError('An escalation reason is required when escalating a ticket.');
      return;
    }
    if (selectedStatus === 'REOPENED' && !reopenReason.trim() && !statusNote.trim()) {
      setActionError('A reason is required when reopening a ticket.');
      return;
    }

    setIsSubmitting(true);
    setActionError(null);
    setStatusSuccessMessage(null);

    try {
      await itRepository.updateTicketStatus(
        ticket.ticket_id,
        selectedStatus,
        {
          note: statusNote.trim() || undefined,
          resolutionNotes: resolutionNotes.trim() || statusNote.trim() || undefined,
          escalationReason: escalationReason.trim() || statusNote.trim() || undefined,
          reopenReason: reopenReason.trim() || statusNote.trim() || undefined,
          isInternalNote: statusIsInternal,
        },
        {
          userId: currentUserId,
          role: currentUserRole,
          authorName: currentUserName,
        }
      );

      setStatusSuccessMessage(`Ticket status successfully updated to ${selectedStatus}.`);
      setStatusNote('');
      onTicketUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to update ticket status.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAssign = async () => {
    if (!assigneeId.trim()) return;
    setIsSubmitting(true);
    setActionError(null);
    try {
      const tech = availableTechnicians.find((t) => t.id === assigneeId);
      await itRepository.assignTicket(
        ticket.ticket_id,
        assigneeId,
        tech?.name || assigneeName || assigneeId,
        {
          userId: currentUserId,
          role: currentUserRole,
          authorName: currentUserName,
        }
      );
      setStatusSuccessMessage(`Ticket successfully assigned to ${tech?.name || assigneeId}.`);
      onTicketUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to assign technician.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const priorityColors = {
    CRITICAL: 'bg-red-50 text-red-700 border-red-200',
    HIGH: 'bg-orange-50 text-orange-700 border-orange-200',
    NORMAL: 'bg-blue-50 text-blue-700 border-blue-200',
    LOW: 'bg-slate-50 text-slate-700 border-slate-200',
  };

  const statusColors: Record<TicketStatus, string> = {
    OPEN: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    ASSIGNED: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    IN_PROGRESS: 'bg-blue-50 text-blue-700 border-blue-200',
    AWAITING_REQUESTER: 'bg-amber-50 text-amber-700 border-amber-200',
    AWAITING_THIRD_PARTY: 'bg-purple-50 text-purple-700 border-purple-200',
    ESCALATED: 'bg-red-50 text-red-700 border-red-200',
    RESOLVED: 'bg-emerald-50 text-emerald-800 border-emerald-300',
    CLOSED: 'bg-slate-100 text-slate-700 border-slate-300',
    REOPENED: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  // Filter responses: if not IT staff, hide internal notes
  const visibleResponses = isItStaff
    ? ticket.responses
    : ticket.responses.filter((r) => !r.is_internal_note);

  const attachmentsList = ticket.attachments && ticket.attachments.length > 0 ? ticket.attachments : [];
  const activityList = ticket.activity_history || [];

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="font-mono text-cyan-400 font-bold text-sm tracking-wide">
              {ticket.ticket_number}
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${priorityColors[ticket.priority]}`}>
              {ticket.priority}
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${statusColors[ticket.status]}`}>
              {ticket.status.replace(/_/g, ' ')}
            </span>
            {ticket.sla_paused && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                <PauseCircle className="w-3 h-3" /> SLA Paused
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close ticket details"
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area: 2 Columns */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Column (2 spans): Ticket Body, Tabs & Status Form */}
          <div className="md:col-span-2 space-y-5">
            {/* Subject and Category */}
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                <span>Category: <strong className="text-slate-800">{ticket.category.replace(/_/g, ' ')}</strong></span>
                <span>&bull;</span>
                <span>Created {new Date(ticket.created_at).toLocaleString()}</span>
                <span>&bull;</span>
                <span>Updated {new Date(ticket.updated_at).toLocaleString()}</span>
              </div>
              <h2 className="text-lg font-bold text-slate-900 leading-snug">
                {ticket.subject}
              </h2>
            </div>

            {/* Full Description */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed shadow-2xs">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1">
                Issue Description
              </span>
              {ticket.description}
            </div>

            {/* Resolution Banner if resolved */}
            {ticket.resolution_notes && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1 text-xs">
                <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Official Resolution Summary:
                </span>
                <p className="text-emerald-950 whitespace-pre-wrap leading-relaxed pl-5">
                  {ticket.resolution_notes}
                </p>
                <p className="text-[10px] text-emerald-700 pl-5 mt-1 font-mono">
                  Resolved on {new Date(ticket.resolved_at || ticket.updated_at).toLocaleString()}
                </p>
              </div>
            )}

            {/* Escalation Banner if escalated */}
            {ticket.escalation_reason && ticket.status === 'ESCALATED' && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-xl space-y-1 text-xs">
                <span className="font-bold text-red-900 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  Active Escalation Details:
                </span>
                <p className="text-red-950 whitespace-pre-wrap pl-5">{ticket.escalation_reason}</p>
              </div>
            )}

            {/* Reopened Banner if reopened */}
            {ticket.reopen_reason && ticket.status === 'REOPENED' && (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-1 text-xs">
                <span className="font-bold text-rose-900 flex items-center gap-1.5">
                  <RefreshCw className="w-4 h-4 text-rose-600" />
                  Reopened Reason:
                </span>
                <p className="text-rose-950 whitespace-pre-wrap pl-5">{ticket.reopen_reason}</p>
              </div>
            )}

            {/* IT Staff Status Management Section */}
            {isItStaff && (
              <div className="p-4 bg-cyan-50/60 border border-cyan-200 rounded-2xl space-y-3.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-cyan-800" />
                    <span className="text-xs font-bold text-cyan-950 uppercase tracking-wide">
                      Authoritative Ticket Status Management
                    </span>
                  </div>
                  <span className="text-[11px] text-cyan-800 font-semibold">
                    Current: <strong className="font-bold">{ticket.status.replace(/_/g, ' ')}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Change Status To:
                    </label>
                    <select
                      value={selectedStatus}
                      onChange={(e) => {
                        setSelectedStatus(e.target.value as TicketStatus);
                        setActionError(null);
                        setStatusSuccessMessage(null);
                      }}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-xs font-medium text-slate-900 focus:ring-2 focus:ring-cyan-700 outline-hidden"
                    >
                      {ALL_STATUSES.map((s) => {
                        const isCurrent = s.value === ticket.status;
                        const isAllowed = isCurrent || currentAllowedTransitions.includes(s.value);
                        return (
                          <option key={s.value} value={s.value}>
                            {s.label} {isCurrent ? '(Current)' : isAllowed ? '' : '(Requires Reopen)'}
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Status Note / Reason:
                    </label>
                    {selectedStatus === 'RESOLVED' ? (
                      <textarea
                        value={resolutionNotes}
                        onChange={(e) => setResolutionNotes(e.target.value)}
                        placeholder="Resolution summary (required to resolve)..."
                        rows={2}
                        className="w-full px-3 py-1.5 border border-emerald-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                      />
                    ) : selectedStatus === 'ESCALATED' ? (
                      <textarea
                        value={escalationReason}
                        onChange={(e) => setEscalationReason(e.target.value)}
                        placeholder="Escalation reason (required to escalate)..."
                        rows={2}
                        className="w-full px-3 py-1.5 border border-red-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-red-500 outline-hidden"
                      />
                    ) : selectedStatus === 'REOPENED' ? (
                      <textarea
                        value={reopenReason}
                        onChange={(e) => setReopenReason(e.target.value)}
                        placeholder="Reopening justification (required)..."
                        rows={2}
                        className="w-full px-3 py-1.5 border border-rose-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-rose-500 outline-hidden"
                      />
                    ) : (
                      <input
                        type="text"
                        value={statusNote}
                        onChange={(e) => setStatusNote(e.target.value)}
                        placeholder="Optional status transition notes..."
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-cyan-700 outline-hidden"
                      />
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-cyan-100">
                  <label className="flex items-center gap-1.5 text-[11px] font-semibold text-amber-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={statusIsInternal}
                      onChange={(e) => setStatusIsInternal(e.target.checked)}
                      className="rounded text-amber-600 focus:ring-amber-500"
                    />
                    <Lock className="w-3 h-3 text-amber-700" />
                    Record note as Internal Staff Note
                  </label>

                  <Button
                    size="sm"
                    variant="primary"
                    onClick={handleUpdateStatus}
                    disabled={isSubmitting || selectedStatus === ticket.status && !statusNote.trim()}
                    className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
                  >
                    {isSubmitting ? 'Saving...' : 'Save & Update Status'}
                  </Button>
                </div>
              </div>
            )}

            {/* Notification Messages */}
            {statusSuccessMessage && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{statusSuccessMessage}</span>
              </div>
            )}
            {actionError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{actionError}</span>
              </div>
            )}

            {/* Tabs Bar: Conversation vs Complete Activity History vs Attachments */}
            <div className="border-b border-slate-200 flex items-center gap-4 text-xs font-bold">
              <button
                type="button"
                onClick={() => setActiveTab('CONVERSATION')}
                className={`pb-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'CONVERSATION'
                    ? 'border-b-2 border-[#1E3A8A] text-[#1E3A8A]'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                Responses ({visibleResponses.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('ACTIVITY')}
                className={`pb-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'ACTIVITY'
                    ? 'border-b-2 border-[#1E3A8A] text-[#1E3A8A]'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                Complete Activity History ({activityList.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('ATTACHMENTS')}
                className={`pb-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'ATTACHMENTS'
                    ? 'border-b-2 border-[#1E3A8A] text-[#1E3A8A]'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Paperclip className="w-3.5 h-3.5" />
                Attachments ({attachmentsList.length})
              </button>
            </div>

            {/* Tab 1: Conversation & Replies */}
            {activeTab === 'CONVERSATION' && (
              <div className="space-y-4">
                {visibleResponses.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-4">No responses posted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {visibleResponses.map((resp) => {
                      const isInternal = resp.is_internal_note;
                      return (
                        <div
                          key={resp.response_id}
                          className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                            isInternal
                              ? 'bg-amber-50/90 border-amber-300 text-amber-950 shadow-2xs'
                              : resp.author_id === ticket.requester_id
                              ? 'bg-blue-50/70 border-blue-200 text-slate-900'
                              : 'bg-white border-slate-200 text-slate-900 shadow-2xs'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[11px]">
                            <div className="flex items-center gap-2 font-bold">
                              {isInternal ? (
                                <Lock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                              ) : (
                                <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              )}
                              <span>{resp.author_name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                ({resp.author_role})
                              </span>
                              {isInternal && (
                                <span className="text-[9px] uppercase tracking-wider bg-amber-200 text-amber-900 px-1.5 py-0.2 rounded font-black border border-amber-300">
                                  Internal Staff Note
                                </span>
                              )}
                            </div>
                            <span className="text-slate-400 font-mono text-[10px]">
                              {new Date(resp.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <p className="whitespace-pre-wrap leading-relaxed pl-5">{resp.message}</p>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Reply Input Box */}
                {ticket.status !== 'CLOSED' && (
                  <div className="pt-3 border-t border-slate-200 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-slate-700">
                        Post Response {isItStaff ? 'or Internal Note' : ''}
                      </label>
                      {isItStaff && (
                        <label className="flex items-center gap-1.5 text-xs font-semibold text-amber-900 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isInternalNote}
                            onChange={(e) => setIsInternalNote(e.target.checked)}
                            className="rounded text-amber-600 focus:ring-amber-500"
                          />
                          <Lock className="w-3.5 h-3.5 text-amber-700" />
                          Internal Staff Note (Never visible to requester)
                        </label>
                      )}
                    </div>

                    <textarea
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder={
                        isInternalNote
                          ? 'Write an internal technical note (visible only to IT Department)...'
                          : 'Write an authoritative public update to the requester...'
                      }
                      rows={3}
                      className={`w-full p-3 text-xs border rounded-xl outline-hidden focus:ring-2 ${
                        isInternalNote
                          ? 'border-amber-300 bg-amber-50/50 focus:ring-amber-500'
                          : 'border-slate-300 focus:ring-[#1E3A8A]'
                      }`}
                    />

                    <div className="flex justify-end">
                      <Button
                        size="sm"
                        variant={isInternalNote ? 'outline' : 'primary'}
                        onClick={handleSendReply}
                        disabled={isSubmitting || !replyMessage.trim()}
                        leftIcon={<Send className="w-3.5 h-3.5" />}
                        className={`text-xs cursor-pointer ${
                          isInternalNote ? 'border-amber-400 text-amber-900 hover:bg-amber-100' : 'bg-[#1E3A8A]'
                        }`}
                      >
                        {isSubmitting ? 'Posting...' : isInternalNote ? 'Post Internal Note' : 'Send Public Reply'}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tab 2: Complete Activity History */}
            {activeTab === 'ACTIVITY' && (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  Authoritative audit log of all status transitions, reassignments, notes, and SLA events for ticket <span className="font-mono font-bold text-slate-700">{ticket.ticket_number}</span>.
                </p>

                {activityList.length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-4">No activity history recorded.</p>
                ) : (
                  <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                    {activityList.map((act) => (
                      <div key={act.activity_id} className="relative text-xs">
                        <div className="absolute -left-6 top-1 w-2.5 h-2.5 rounded-full bg-[#1E3A8A] ring-4 ring-white" />
                        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900">{act.actor_name}</span>
                              <span className="font-mono text-[10px] text-slate-400">({act.actor_role})</span>
                              <span className="font-bold text-[9px] uppercase px-1.5 py-0.2 rounded bg-slate-200 text-slate-700">
                                {act.action_type.replace(/_/g, ' ')}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {new Date(act.timestamp).toLocaleString()}
                            </span>
                          </div>

                          {(act.previous_status || act.new_status) && (
                            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 pt-0.5">
                              <span>Status:</span>
                              <span className="px-1.5 py-0.2 rounded bg-slate-100 border text-slate-600">
                                {act.previous_status || 'None'}
                              </span>
                              <ArrowRight className="w-3 h-3 text-slate-400" />
                              <span className="px-1.5 py-0.2 rounded bg-cyan-100 border border-cyan-200 text-cyan-800 font-bold">
                                {act.new_status}
                              </span>
                            </div>
                          )}

                          {(act.previous_assignee || act.new_assignee) && (
                            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 pt-0.5">
                              <span>Assignee:</span>
                              <span className="text-slate-500">{act.previous_assignee || 'Unassigned'}</span>
                              <ArrowRight className="w-3 h-3 text-slate-400" />
                              <span className="text-[#1E3A8A] font-bold">{act.new_assignee}</span>
                            </div>
                          )}

                          <p className="text-slate-800 leading-relaxed pt-0.5">{act.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tab 3: Attachments */}
            {activeTab === 'ATTACHMENTS' && (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  Supporting screenshots, system diagnostic logs, or files submitted with this ticket.
                </p>

                {attachmentsList.length === 0 ? (
                  <div className="p-8 border border-dashed border-slate-200 rounded-xl text-center text-xs text-slate-400">
                    No attachments attached to this ticket.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {attachmentsList.map((file, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Paperclip className="w-4 h-4 text-cyan-700 shrink-0" />
                          <span className="font-mono font-medium text-slate-800 truncate">{file}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 uppercase font-bold shrink-0">Attached</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Column (1 span): Requester Dossier, SLA Engine, Technician Assignment */}
          <div className="space-y-4 border-l border-slate-100 pl-0 md:pl-6 text-xs">
            {/* Requester Dossier */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 shadow-2xs">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                Requester Dossier
              </span>
              <p className="font-bold text-slate-900 text-sm">{ticket.requester_name}</p>
              <div className="text-[11px] text-slate-600 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Account Type:</span>
                  <span className="font-bold px-1.5 py-0.2 rounded bg-slate-200 text-slate-800 text-[10px]">
                    {ticket.requester_account_type}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">User / Reg ID:</span>
                  <span className="font-mono font-bold text-slate-800">{ticket.requester_id}</span>
                </div>
                <div className="truncate">
                  <span className="text-slate-500">Email: </span>
                  <span className="font-medium text-slate-800">{ticket.requester_email}</span>
                </div>
                {ticket.requester_phone && (
                  <div>
                    <span className="text-slate-500">Phone: </span>
                    <span className="font-medium text-slate-800">{ticket.requester_phone}</span>
                  </div>
                )}
              </div>
            </div>

            {/* SLA Engine & Breach History */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                  Authoritative SLA Engine
                </span>
                <span className="text-[10px] font-mono text-cyan-800 font-bold">
                  {ticket.sla_policy_id} (v{ticket.sla_policy_version})
                </span>
              </div>

              {ticket.sla_paused && (
                <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px] space-y-0.5">
                  <div className="flex items-center gap-1.5 font-bold">
                    <PauseCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>SLA Timer Paused</span>
                  </div>
                  <p className="text-[10px] text-amber-800 pl-5">
                    Reason: {ticket.sla_pause_reason || 'Awaiting response'}
                  </p>
                  {ticket.sla_paused_at && (
                    <p className="text-[9px] text-amber-700 pl-5 font-mono">
                      Since {new Date(ticket.sla_paused_at).toLocaleString()}
                    </p>
                  )}
                </div>
              )}

              <div className="space-y-1.5 text-[11px]">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Response Target:</span>
                  <span className={ticket.sla_response_breached ? 'text-red-600 font-bold' : 'text-slate-800'}>
                    {new Date(ticket.sla_response_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{' '}
                    ({new Date(ticket.sla_response_deadline).toLocaleDateString()})
                  </span>
                </div>

                {ticket.sla_first_responded_at && (
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span>First Responded:</span>
                    <span className="font-mono text-emerald-700 font-semibold">
                      {new Date(ticket.sla_first_responded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Resolution Target:</span>
                  <span className={ticket.sla_resolution_breached ? 'text-red-600 font-bold' : 'text-slate-800'}>
                    {new Date(ticket.sla_resolution_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}{' '}
                    ({new Date(ticket.sla_resolution_deadline).toLocaleDateString()})
                  </span>
                </div>

                {ticket.sla_resolution_breached && (
                  <div className="p-2 bg-red-50 border border-red-200 rounded-lg text-red-800 text-[10px] font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                    <span>SLA Resolution Target Breached</span>
                  </div>
                )}

                {ticket.sla_breach_history && ticket.sla_breach_history.length > 0 && (
                  <div className="pt-2 border-t border-slate-200 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">Breach Log:</span>
                    {ticket.sla_breach_history.map((b, i) => (
                      <div key={i} className="text-[10px] text-red-700 flex justify-between">
                        <span>{b.type} breach:</span>
                        <span className="font-mono">{new Date(b.breached_at).toLocaleTimeString()}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Assigned IT Technician */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 shadow-2xs">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                Assigned IT Technician
              </span>
              <p className="font-bold text-slate-900 text-sm">
                {ticket.assigned_to_name || <em className="text-slate-400 font-normal">Unassigned</em>}
              </p>

              {isItStaff && (
                <div className="pt-2 border-t border-slate-200 space-y-2">
                  <label className="block text-[11px] font-semibold text-slate-700">
                    Assign Officially to IT Staff:
                  </label>
                  <select
                    value={assigneeId}
                    onChange={(e) => {
                      setAssigneeId(e.target.value);
                      const opt = e.target.selectedOptions[0]?.text;
                      setAssigneeName(opt || '');
                    }}
                    className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white font-medium text-slate-900 focus:ring-2 focus:ring-[#1E3A8A] outline-hidden"
                  >
                    <option value="">-- Select Active IT Employee --</option>
                    {availableTechnicians.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.title})
                      </option>
                    ))}
                  </select>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleAssign}
                    disabled={!assigneeId || isSubmitting}
                    className="w-full text-xs cursor-pointer hover:bg-slate-100"
                  >
                    {isSubmitting ? 'Updating...' : 'Assign / Reassign'}
                  </Button>
                </div>
              )}
            </div>

            {/* Reopen Action for Resolved or Closed Tickets */}
            {isItStaff && (ticket.status === 'RESOLVED' || ticket.status === 'CLOSED') && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-2">
                <span className="text-xs font-bold text-rose-950 block">Reopen Ticket</span>
                <p className="text-[11px] text-rose-800">
                  This ticket has concluded. Authorized staff may reopen it with an explanation.
                </p>
                <input
                  type="text"
                  value={reopenReason}
                  onChange={(e) => setReopenReason(e.target.value)}
                  placeholder="Reason for reopening..."
                  className="w-full p-2 text-xs border border-rose-300 rounded-lg bg-white"
                />
                <Button
                  size="sm"
                  variant="primary"
                  onClick={async () => {
                    if (!reopenReason.trim()) {
                      setActionError('Please provide a reason to reopen this ticket.');
                      return;
                    }
                    try {
                      await itRepository.reopenTicket(ticket.ticket_id, reopenReason, {
                        userId: currentUserId,
                        role: currentUserRole,
                        authorName: currentUserName,
                      });
                      setStatusSuccessMessage('Ticket reopened successfully.');
                      onTicketUpdated();
                    } catch (e: any) {
                      setActionError(e.message);
                    }
                  }}
                  disabled={!reopenReason.trim() || isSubmitting}
                  className="w-full text-xs bg-rose-700 hover:bg-rose-800 cursor-pointer"
                >
                  Confirm Reopen
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer with Close / Back Action */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-mono">
            EIT CAMS &bull; Office PO-007 IT Technical Services
          </span>
          <Button
            size="sm"
            variant="outline"
            onClick={onClose}
            className="text-xs cursor-pointer hover:bg-slate-200"
          >
            Close / Back to Queue
          </Button>
        </div>
      </div>
    </div>
  );
}
