import React from 'react';
import {
  Layers,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ExternalLink,
  ShieldCheck,
  FileSpreadsheet,
  Globe,
  Sparkles,
} from 'lucide-react';
import { itRepository } from '../../../services/itService';

export function ApiIntegrationsView() {
  const integrations = itRepository.getIntegrationRegistry();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Campus API & Integration Registry
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational status and telemetry for active and planned institutional gateway integrations.
          </p>
        </div>
      </div>

      {/* Integration Registry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {integrations.map((item) => (
          <div
            key={item.integration_id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs space-y-3 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400 block font-mono">
                    {item.integration_id} &bull; {item.category}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {item.name}
                  </h3>
                </div>
                <span
                  className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                    item.status === 'HEALTHY'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-amber-50 text-amber-700 border-amber-200'
                  }`}
                >
                  {item.status === 'HEALTHY' ? 'OPERATIONAL' : 'PENDING CONFIG'}
                </span>
              </div>

              <p className="text-xs text-slate-600 mt-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                {item.purpose}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
              <div className="flex justify-between">
                <span>Target Roadmap:</span>
                <strong className="text-slate-800">{item.target_phase}</strong>
              </div>
              <div className="flex justify-between">
                <span>Responsible Handler:</span>
                <span className="font-mono text-cyan-800">{item.responsible_service}</span>
              </div>
              {item.last_successful_check && (
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>Last Verified:</span>
                  <span>{new Date(item.last_successful_check).toLocaleTimeString()}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
