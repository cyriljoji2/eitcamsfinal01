import React, { useState } from 'react';
import {
  Server,
  Activity,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Clock,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { SystemHealthMetric } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface SystemHealthViewProps {
  metrics: SystemHealthMetric[];
  onRefresh: () => void;
}

export function SystemHealthView({ metrics, onRefresh }: SystemHealthViewProps) {
  const [isPinging, setIsPinging] = useState(false);
  const [pingResult, setPingResult] = useState<string | null>(null);

  const handleRunPingTest = () => {
    setIsPinging(true);
    setTimeout(() => {
      setIsPinging(false);
      setPingResult(`Ping test completed at ${new Date().toLocaleTimeString()}: All local micro-services responding with avg 18ms latency.`);
      onRefresh();
    }, 600);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'HEALTHY':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> HEALTHY
          </span>
        );
      case 'DEGRADED':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" /> DEGRADED
          </span>
        );
      case 'NOT_CONFIGURED':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
            NOT CONFIGURED (PLANNED)
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200">
            UNAVAILABLE
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              System Health & Service Monitoring
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time status for EIT CAMS infrastructure, database adapters, and external communication gateways.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={onRefresh}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            className="text-xs cursor-pointer"
          >
            Refresh
          </Button>
          <Button
            size="sm"
            variant="primary"
            onClick={handleRunPingTest}
            disabled={isPinging}
            leftIcon={isPinging ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5 text-cyan-300" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            {isPinging ? 'Pinging Services...' : 'Execute Health Probe'}
          </Button>
        </div>
      </div>

      {pingResult && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{pingResult}</span>
        </div>
      )}

      {/* Service Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((service) => (
          <div
            key={service.service_key}
            className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-3 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400 block">
                    {service.category}
                  </span>
                  <h3 className="text-xs font-bold text-slate-900 leading-snug">
                    {service.service_name}
                  </h3>
                </div>
                {getStatusBadge(service.status)}
              </div>

              <p className="text-[11px] text-slate-600 mt-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                {service.details}
              </p>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500 font-mono">
              <span>Latency: <strong>{service.latency_ms > 0 ? `${service.latency_ms}ms` : 'N/A'}</strong></span>
              <span>Uptime: <strong>{service.uptime_percentage > 0 ? `${service.uptime_percentage}%` : 'N/A'}</strong></span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
