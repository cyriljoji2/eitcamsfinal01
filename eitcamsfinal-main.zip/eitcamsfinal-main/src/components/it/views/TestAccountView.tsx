import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Power,
  Clock,
  UserCheck,
  AlertTriangle,
  CheckCircle2,
  Lock,
  RefreshCw,
  Terminal,
} from 'lucide-react';
import { TestAccountConfig } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface TestAccountViewProps {
  currentUserId: string;
  currentUserRole: string;
  currentUserName: string;
  onRefresh: () => void;
}

export function TestAccountView({
  currentUserId,
  currentUserRole,
  currentUserName,
  onRefresh,
}: TestAccountViewProps) {
  const config = itRepository.getTestAccountConfig();
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleToggle = async (enable: boolean) => {
    if (!reason.trim()) {
      setActionError(`An authoritative reason is required to ${enable ? 'enable' : 'disable'} the test account.`);
      return;
    }

    setIsSubmitting(true);
    setActionError(null);
    setSuccessMsg(null);
    try {
      await itRepository.setTestAccountEnabled(enable, reason.trim(), {
        userId: currentUserId,
        role: currentUserRole,
        operatorName: currentUserName,
      });

      setSuccessMsg(`Test account successfully ${enable ? 'ENABLED' : 'DISABLED & active sessions terminated'}.`);
      setReason('');
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || 'Operation failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <h2 className="text-base font-bold text-slate-900">
              Test Environment & Account Management
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Safely control the designated institutional QA test account with strict production isolation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
              config.is_enabled
                ? 'bg-amber-50 text-amber-800 border-amber-300'
                : 'bg-slate-100 text-slate-700 border-slate-200'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                config.is_enabled ? 'bg-amber-500 animate-pulse' : 'bg-slate-400'
              }`}
            />
            Status: {config.is_enabled ? 'TEST ACCOUNT ACTIVE' : 'LOCKED / DISABLED'}
          </span>
        </div>
      </div>

      {/* Safety Notice Card */}
      <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 space-y-2 text-xs">
        <p className="font-bold text-cyan-300 flex items-center gap-2">
          <Lock className="w-4 h-4 text-cyan-400" />
          Strict QA Sandbox Containment Safeguards
        </p>
        <ul className="list-disc list-inside text-slate-300 space-y-1 text-[11px]">
          <li>Test account is completely isolated from real student, employee, parent, and institutional ledger records.</li>
          <li>Disabling the test account immediately invalidates all active sessions and bearer tokens.</li>
          <li>Test account cannot process real fee payments, alter officially published examination results, or edit master attendance.</li>
          <li>IT operators cannot create additional institutional accounts through this module.</li>
        </ul>
      </div>

      {/* Controls Card */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3 text-xs">
            <h3 className="font-bold text-slate-900 text-sm">Designated Account Details</h3>
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Username:</span>
                <span className="font-mono font-bold text-slate-900">{config.username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Display Name:</span>
                <span className="font-semibold text-slate-800">{config.display_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Permitted Roles:</span>
                <span className="text-slate-700 font-mono text-[10px]">{config.permitted_test_roles.join(', ')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Active Test Sessions:</span>
                <span className="font-bold text-cyan-800">{config.active_sessions_count}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 text-xs">
            <h3 className="font-bold text-slate-900 text-sm">State Control Action</h3>
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-700 block">
                Reason for State Change (Mandatory for Audit Trail)
              </label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Authorized QA testing for Semester 3 course registration..."
                className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
              />

              <div className="pt-2 flex gap-3">
                {config.is_enabled ? (
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={() => handleToggle(false)}
                    disabled={isSubmitting || !reason.trim()}
                    leftIcon={<Power className="w-4 h-4" />}
                    className="flex-1 bg-red-700 hover:bg-red-800 text-xs cursor-pointer"
                  >
                    {isSubmitting ? 'Revoking Sessions...' : 'Disable Test Account & Revoke Sessions'}
                  </Button>
                ) : (
                  <Button
                    size="sm"
                    variant="primary"
                    onClick={() => handleToggle(true)}
                    disabled={isSubmitting || !reason.trim()}
                    leftIcon={<Power className="w-4 h-4 text-emerald-300" />}
                    className="flex-1 bg-amber-700 hover:bg-amber-800 text-xs cursor-pointer"
                  >
                    {isSubmitting ? 'Enabling...' : 'Enable Test Account for QA'}
                  </Button>
                )}
              </div>
            </div>

            {actionError && (
              <p className="text-xs text-red-600 bg-red-50 p-2 rounded border border-red-200">
                {actionError}
              </p>
            )}
            {successMsg && (
              <p className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded border border-emerald-200">
                {successMsg}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Audit History */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden p-5 space-y-3">
        <h3 className="text-sm font-bold text-slate-900">
          Test Account Operational Audit Trail ({config.history.length})
        </h3>

        <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Operator</th>
                <th className="py-2.5 px-3">Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {config.history.map((h) => (
                <tr key={h.entry_id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                    {new Date(h.timestamp).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        h.action === 'ENABLED'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {h.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-900">{h.operator_name} ({h.operator_id})</td>
                  <td className="py-2.5 px-3 text-[11px] text-slate-600">{h.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
