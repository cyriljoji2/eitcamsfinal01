import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  Users,
  Lock,
  CheckCircle2,
  AlertTriangle,
  Info,
  ShieldCheck,
  RefreshCw,
  Building2,
} from 'lucide-react';
import { ItPermission } from '../../../types/itDepartment';
import { EmployeeRecord, OfficeAssignmentRecord } from '../../../types/database';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface UserAccessManagementViewProps {
  currentUserId: string;
  currentUserRole: string;
  currentEmployeeId?: string;
}

const ALL_IT_PERMISSIONS = [
  { key: ItPermission.IT_DASHBOARD_VIEW, label: 'Dashboard & Metrics View', desc: 'Read-only access to IT command center overview' },
  { key: ItPermission.IT_SYSTEM_MONITOR_VIEW, label: 'System Diagnostics & Health', desc: 'Inspect live latency, uptime, and ping probes' },
  { key: ItPermission.IT_USER_ACCESS_VIEW, label: 'View Staff Access Records', desc: 'Review permissions granted to IT staff' },
  { key: ItPermission.IT_PERMISSION_MANAGE, label: 'Manage Staff Permissions', desc: 'Grant or revoke IT permissions for assigned staff' },
  { key: ItPermission.IT_PASSWORD_RESET, label: 'Account Password Reset', desc: 'Execute password resets for verified institutional accounts' },
  { key: ItPermission.IT_ID_CARD_MANAGE, label: 'ID Card Reissue & Control', desc: 'Generate, print, and reissue student and staff ID cards' },
  { key: ItPermission.IT_TEST_ACCOUNT_MANAGE, label: 'Test Account Governance', desc: 'Enable or disable the isolated test sandbox account' },
  { key: ItPermission.IT_SECURITY_AUDIT_VIEW, label: 'Security & Audit Log Access', desc: 'View complete immutable institutional audit trail' },
  { key: ItPermission.IT_DATABASE_MONITOR, label: 'Database & Sheets Monitoring', desc: 'Inspect table statistics, counts, and Phase 11 readiness' },
  { key: ItPermission.IT_INFRASTRUCTURE_MANAGE, label: 'Infrastructure & Maintenance', desc: 'Control server maintenance mode and environment flags' },
  { key: ItPermission.IT_CONFIGURATION_MANAGE, label: 'System Configuration', desc: 'Modify institutional timeouts and feature switches' },
  { key: ItPermission.IT_INTEGRATION_MANAGE, label: 'API & Integration Registry', desc: 'Manage connections to external campus gateways' },
  { key: ItPermission.IT_SUPPORT_MANAGE, label: 'IT Support & Ticket Admin', desc: 'Assign tickets, reply, post internal notes, and resolve' },
  { key: ItPermission.IT_SLA_MANAGE, label: 'SLA Policy Configuration', desc: 'Configure response/resolution targets and calendars' },
  { key: ItPermission.IT_CONTACT_SETTINGS_MANAGE, label: 'IT Contact & Helpdesk Settings', desc: 'Update support mail, phone, and hours published in portals' },
  { key: ItPermission.IT_BACKUP_MANAGE, label: 'Backup & Recovery Control', desc: 'Trigger manual snapshots and review retention schedules' },
  { key: ItPermission.IT_REPORTS_VIEW, label: 'IT Reports & Analytics', desc: 'Generate metrics summaries and export CSV compliance data' },
];

export function UserAccessManagementView({
  currentUserId,
  currentUserRole,
  currentEmployeeId,
}: UserAccessManagementViewProps) {
  const [itEmployees, setItEmployees] = useState<{ employee: EmployeeRecord; assignment: OfficeAssignmentRecord }[]>([]);
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);
  const [selectedPermissions, setSelectedPermissions] = useState<ItPermission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadAssignedStaff = useCallback(async () => {
    try {
      setIsLoading(true);
      const staff = await itRepository.getItAssignedEmployees();
      setItEmployees(staff);
      if (staff.length > 0 && !selectedEmpId) {
        setSelectedEmpId(staff[0].employee.employee_id);
      }
    } finally {
      setIsLoading(false);
    }
  }, [selectedEmpId]);

  useEffect(() => {
    loadAssignedStaff();
  }, [loadAssignedStaff]);

  // Load permissions when selected employee changes
  useEffect(() => {
    let isMounted = true;
    const fetchPerms = async () => {
      if (!selectedEmpId) return;
      try {
        const perms = await itRepository.getItPermissions(selectedEmpId);
        if (isMounted) setSelectedPermissions(perms);
      } catch {
        // ignore
      }
    };
    fetchPerms();
    return () => {
      isMounted = false;
    };
  }, [selectedEmpId]);

  const handleTogglePermission = async (permKey: ItPermission) => {
    if (!selectedEmpId) return;
    setFeedbackMsg(null);

    // Safeguard check: Cannot modify own permissions
    if (currentEmployeeId && currentEmployeeId === selectedEmpId) {
      setFeedbackMsg({
        type: 'error',
        text: 'Safeguard Violation: An IT employee cannot modify their own permissions or self-escalate.',
      });
      return;
    }

    const hasPerm = selectedPermissions.includes(permKey);
    setIsSaving(true);
    try {
      if (hasPerm) {
        await itRepository.revokeItPermission(selectedEmpId, permKey, {
          userId: currentUserId,
          role: currentUserRole,
          employeeId: currentEmployeeId,
        });
        setSelectedPermissions((prev) => prev.filter((p) => p !== permKey));
        setFeedbackMsg({ type: 'success', text: `Revoked ${permKey} successfully.` });
      } else {
        await itRepository.grantItPermission(selectedEmpId, permKey, {
          userId: currentUserId,
          role: currentUserRole,
          employeeId: currentEmployeeId,
        });
        setSelectedPermissions((prev) => [...prev, permKey]);
        setFeedbackMsg({ type: 'success', text: `Granted ${permKey} successfully.` });
      }
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Failed to update permission.' });
    } finally {
      setIsSaving(false);
    }
  };

  const selectedStaffMember = itEmployees.find((item) => item.employee.employee_id === selectedEmpId);

  return (
    <div className="space-y-6">
      {/* Safeguards Notice Banner */}
      <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-xs flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs space-y-1">
          <p className="font-bold text-cyan-200">
            Authoritative Separation of Duties: Administration &bull; IT Department
          </p>
          <p className="text-slate-300 leading-relaxed">
            Administration remains the sole authority for employee registration, identity, activation, and office assignment.
            IT Department authority is strictly limited to assigning granular technical permissions to employees officially assigned to IT.
            IT cannot create employee accounts, assign employees to IT, or modify its own permissions.
          </p>
        </div>
      </div>

      {feedbackMsg && (
        <div
          className={`p-3 rounded-xl border text-xs flex items-center gap-2 animate-in fade-in ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-red-50 border-red-200 text-red-800'
          }`}
        >
          {feedbackMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Main Grid: Staff List & Permissions Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: IT Assigned Staff */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-[#1E3A8A]" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Assigned IT Staff ({itEmployees.length})
              </h3>
            </div>
            <button
              onClick={loadAssignedStaff}
              className="text-slate-400 hover:text-slate-700 p-1 rounded cursor-pointer"
              title="Refresh staff"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {isLoading ? (
            <div className="py-8 text-center text-xs text-slate-400">Loading assigned staff...</div>
          ) : itEmployees.length === 0 ? (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs text-slate-500 space-y-2">
              <Building2 className="w-6 h-6 text-slate-400 mx-auto" />
              <p className="font-semibold">No Staff Assigned by Administration</p>
              <p className="text-[11px] text-slate-400">
                To assign staff to the IT Department, sign in to Administration Office and allocate an employee via Office Assignments.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5 max-h-96 overflow-y-auto">
              {itEmployees.map(({ employee, assignment }) => {
                const isSelected = employee.employee_id === selectedEmpId;
                const isSelf = currentEmployeeId && employee.employee_id === currentEmployeeId;

                return (
                  <div
                    key={employee.employee_id}
                    onClick={() => setSelectedEmpId(employee.employee_id)}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-blue-50/80 border-[#1E3A8A] text-[#1E3A8A] font-bold shadow-2xs'
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="truncate">{employee.first_name} {employee.last_name}</span>
                      {isSelf && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">
                          YOU
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400 font-normal">
                      <span className="font-mono">{employee.registration_number}</span>
                      <span>{assignment.assigned_role_title}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 2 Columns: Granular Technical Permissions Matrix */}
        <div className="md:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Technical Authority & Permissions
              </h3>
              {selectedStaffMember && (
                <p className="text-xs text-slate-500 mt-0.5">
                  Configuring permissions for{' '}
                  <strong className="text-slate-800">
                    {selectedStaffMember.employee.first_name} {selectedStaffMember.employee.last_name}
                  </strong>{' '}
                  ({selectedStaffMember.employee.registration_number})
                </p>
              )}
            </div>
            {selectedStaffMember && (
              <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                {selectedPermissions.length} / {ALL_IT_PERMISSIONS.length} Granted
              </span>
            )}
          </div>

          {!selectedStaffMember ? (
            <p className="text-xs text-slate-400 italic py-8 text-center">
              Select an IT staff member from the left to configure their granular access permissions.
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
              {ALL_IT_PERMISSIONS.map((perm) => {
                const isGranted = selectedPermissions.includes(perm.key);
                const isSelf = currentEmployeeId && selectedStaffMember.employee.employee_id === currentEmployeeId;

                return (
                  <div
                    key={perm.key}
                    onClick={() => !isSaving && !isSelf && handleTogglePermission(perm.key)}
                    className={`p-3 rounded-xl border text-xs transition-all flex items-start gap-3 ${
                      isSelf
                        ? 'opacity-60 cursor-not-allowed bg-slate-50 border-slate-200'
                        : 'cursor-pointer hover:border-[#1E3A8A]'
                    } ${
                      isGranted
                        ? 'bg-blue-50/50 border-blue-200 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isGranted}
                      disabled={isSaving || Boolean(isSelf)}
                      onChange={() => {}}
                      className="mt-0.5 rounded text-[#1E3A8A] focus:ring-[#1E3A8A]"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900">{perm.label}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">{perm.desc}</p>
                      <span className="inline-block mt-1 text-[9px] font-mono text-slate-400">
                        {perm.key}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
