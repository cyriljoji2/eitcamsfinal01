import React, { useState } from 'react';
import {
  LifeBuoy,
  Mail,
  Phone,
  Clock,
  Globe,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  RefreshCw,
  Send,
  History,
} from 'lucide-react';
import { ItContactSettings } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface ItContactSettingsViewProps {
  currentUserId: string;
  currentUserRole: string;
  currentEmployeeId?: string;
  onRefresh: () => void;
}

export function ItContactSettingsView({
  currentUserId,
  currentUserRole,
  currentEmployeeId,
  onRefresh,
}: ItContactSettingsViewProps) {
  const settings = itRepository.getContactSettings();

  const [email, setEmail] = useState(settings.support_email);
  const [phone, setPhone] = useState(settings.support_phone);
  const [hours, setHours] = useState(settings.support_hours);
  const [emergencyPhone, setEmergencyPhone] = useState(settings.emergency_phone);
  const [workingDays, setWorkingDays] = useState(settings.working_days_text);
  const [timezone, setTimezone] = useState(settings.institutional_timezone);
  const [afterHours, setAfterHours] = useState(settings.after_hours_info);
  const [instructions, setInstructions] = useState(settings.public_support_instructions);
  const [reason, setReason] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setErrorMsg('An institutional audit reason is required to update central IT support contact information.');
      return;
    }

    // Validate email
    if (!email.includes('@') || !email.includes('.')) {
      setErrorMsg('Please specify a valid official support email address.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      await itRepository.updateContactSettings(
        {
          support_email: email.trim(),
          support_phone: phone.trim(),
          support_hours: hours.trim(),
          emergency_phone: emergencyPhone.trim(),
          working_days_text: workingDays.trim(),
          institutional_timezone: timezone.trim(),
          after_hours_info: afterHours.trim(),
          public_support_instructions: instructions.trim(),
        },
        reason.trim(),
        {
          userId: currentUserId,
          role: currentUserRole,
          employeeId: currentEmployeeId,
        }
      );

      setSuccessMsg('Central IT contact settings updated & published to all institutional portals in real time!');
      setReason('');
      onRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update contact settings.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Institutional IT Contact & Support Settings
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Centrally manage support channels, hours, and emergency desk contacts published across all portals.
          </p>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSave} className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-5 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Official Support Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Official Support Telephone</label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Support Operating Hours</label>
            <div className="relative">
              <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Emergency After-Hours Hotline</label>
            <div className="relative">
              <Phone className="w-4 h-4 text-red-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={emergencyPhone}
                onChange={(e) => setEmergencyPhone(e.target.value)}
                required
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
              />
            </div>
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Working Days</label>
            <input
              type="text"
              value={workingDays}
              onChange={(e) => setWorkingDays(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
            />
          </div>

          <div>
            <label className="font-bold text-slate-700 block mb-1">Institutional Time Zone</label>
            <input
              type="text"
              value={timezone}
              onChange={(e) => setTimezone(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
            />
          </div>
        </div>

        <div>
          <label className="font-bold text-slate-700 block mb-1">Public Support Guidance & Instructions</label>
          <textarea
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            rows={2}
            className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        <div>
          <label className="font-bold text-slate-700 block mb-1">After-Hours Critical Escalation Notes</label>
          <textarea
            value={afterHours}
            onChange={(e) => setAfterHours(e.target.value)}
            rows={2}
            className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        <div className="pt-2 border-t border-slate-200">
          <label className="font-bold text-slate-800 block mb-1">
            Mandatory Institutional Audit Reason for Update
          </label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g. Updated holiday schedule and expanded support desk hours..."
            required
            className="w-full p-2.5 border border-amber-300 rounded-lg bg-amber-50/40 outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button
            type="submit"
            variant="primary"
            size="sm"
            disabled={isSubmitting || !reason.trim()}
            leftIcon={isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            {isSubmitting ? 'Publishing Updates...' : 'Publish Central IT Contact Settings'}
          </Button>
        </div>
      </form>

      {/* Historical Change Ledger */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-3">
        <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
          <History className="w-4 h-4 text-[#1E3A8A]" />
          <span>Contact Settings Modification History ({settings.history.length})</span>
        </div>

        <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Field</th>
                <th className="py-2.5 px-3">Previous Value</th>
                <th className="py-2.5 px-3">New Value</th>
                <th className="py-2.5 px-3">Editor</th>
                <th className="py-2.5 px-3">Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {settings.history.map((h) => (
                <tr key={h.entry_id} className="hover:bg-slate-50">
                  <td className="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                    {new Date(h.updated_at).toLocaleString()}
                  </td>
                  <td className="py-2 px-3 font-bold text-slate-800">{h.field_name}</td>
                  <td className="py-2 px-3 text-slate-500 max-w-[150px] truncate">{h.previous_value}</td>
                  <td className="py-2 px-3 text-emerald-800 font-semibold max-w-[150px] truncate">{h.new_value}</td>
                  <td className="py-2 px-3 font-medium text-slate-800">{h.updated_by}</td>
                  <td className="py-2 px-3 text-[11px] text-slate-600">{h.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
