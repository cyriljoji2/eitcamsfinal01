import React, { useState } from 'react';
import {
  CreditCard,
  Search,
  Filter,
  Printer,
  QrCode,
  RotateCcw,
  ShieldCheck,
  Eye,
  AlertCircle,
  Building2,
  GraduationCap,
} from 'lucide-react';
import { IdCardRecord, IdCardStatus, IdCardType } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';

interface IdCardManagementViewProps {
  idCards: IdCardRecord[];
  onPreviewCard: (card: IdCardRecord) => void;
  onOpenReissue: (card: IdCardRecord) => void;
}

export function IdCardManagementView({
  idCards,
  onPreviewCard,
  onOpenReissue,
}: IdCardManagementViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | IdCardType>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | IdCardStatus>('ALL');

  const filteredCards = idCards.filter((card) => {
    if (typeFilter !== 'ALL' && card.card_type !== typeFilter) return false;
    if (statusFilter !== 'ALL' && card.status !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        card.full_name.toLowerCase().includes(q) ||
        card.registration_number.toLowerCase().includes(q) ||
        card.department.toLowerCase().includes(q) ||
        card.designation_or_program.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getStatusBadge = (status: IdCardStatus) => {
    switch (status) {
      case 'ACTIVE':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">ACTIVE</span>;
      case 'SUSPENDED':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-700 border border-red-200">SUSPENDED</span>;
      case 'REPLACED':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">REPLACED</span>;
      case 'LOST':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">LOST</span>;
      case 'DAMAGED':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-50 text-orange-700 border border-orange-200">DAMAGED</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Institutional ID Card Management & Smart Credential Center
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Automatic provisioning for student enrollments and staff registrations with cryptographic QR verification.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold px-3 py-1.5 rounded-xl bg-blue-50 text-[#1E3A8A] border border-blue-200">
            Total Cards: {idCards.length}
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, registration number, program, department..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="text-xs px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
          >
            <option value="ALL">All Card Types</option>
            <option value="STUDENT">Student ID Cards</option>
            <option value="EMPLOYEE">Faculty / Staff ID Cards</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="text-xs px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">ACTIVE</option>
            <option value="SUSPENDED">SUSPENDED</option>
            <option value="LOST">LOST</option>
            <option value="DAMAGED">DAMAGED</option>
            <option value="REPLACED">REPLACED</option>
          </select>
        </div>
      </div>

      {/* Cards Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Card / Registration</th>
                <th className="py-3 px-4">Cardholder</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Department & Program / Role</th>
                <th className="py-3 px-4">Validity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredCards.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 italic">
                    No ID cards found matching current filters.
                  </td>
                </tr>
              ) : (
                filteredCards.map((card) => (
                  <tr key={card.card_id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-slate-900">{card.registration_number}</div>
                      <div className="text-[10px] font-mono text-slate-400">{card.card_id}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden">
                          {card.photo_url ? (
                            <img src={card.photo_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            card.full_name.charAt(0)
                          )}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{card.full_name}</div>
                          {card.emergency_contact && (
                            <div className="text-[10px] text-slate-400">Emerg: {card.emergency_contact}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        card.card_type === 'STUDENT' ? 'bg-indigo-50 text-indigo-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {card.card_type === 'STUDENT' ? <GraduationCap className="w-3 h-3" /> : <Building2 className="w-3 h-3" />}
                        {card.card_type}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800 truncate max-w-xs">{card.designation_or_program}</div>
                      <div className="text-[10px] text-slate-500">{card.department} &bull; {card.office_or_year}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap text-[11px]">
                      <div>Expires: <strong className="text-slate-800">{card.expiry_date}</strong></div>
                      <div className="text-[10px] text-slate-400">Issued: {card.issue_date}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {getStatusBadge(card.status)}
                      {card.reissue_count > 0 && (
                        <div className="text-[9px] text-slate-400 mt-0.5">Reissues: {card.reissue_count}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap space-x-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onPreviewCard(card)}
                        leftIcon={<Eye className="w-3.5 h-3.5" />}
                        className="text-[11px] py-1 h-auto cursor-pointer"
                      >
                        Preview / Print
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onOpenReissue(card)}
                        leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
                        className="text-[11px] py-1 h-auto text-amber-700 hover:bg-amber-50 border-amber-200 cursor-pointer"
                      >
                        Reissue
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
