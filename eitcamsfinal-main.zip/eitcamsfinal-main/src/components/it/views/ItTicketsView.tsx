import React, { useState } from 'react';
import {
  LifeBuoy,
  Search,
  Filter,
  PlusCircle,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Download,
  Eye,
  User,
} from 'lucide-react';
import { TicketCategory, TicketPriority, TicketRecord, TicketStatus } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';

interface ItTicketsViewProps {
  tickets: TicketRecord[];
  onOpenTicketDetail: (ticket: TicketRecord) => void;
  onOpenNewTicket: () => void;
  isItStaff: boolean;
}

export function ItTicketsView({
  tickets,
  onOpenTicketDetail,
  onOpenNewTicket,
  isItStaff,
}: ItTicketsViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusTab, setStatusTab] = useState<'ALL' | 'OPEN' | 'IN_PROGRESS' | 'CRITICAL' | 'RESOLVED' | 'CLOSED'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | TicketCategory>('ALL');

  const filteredTickets = tickets.filter((t) => {
    if (statusTab === 'OPEN' && t.status !== 'OPEN' && t.status !== 'ASSIGNED' && t.status !== 'REOPENED') return false;
    if (
      statusTab === 'IN_PROGRESS' &&
      t.status !== 'IN_PROGRESS' &&
      t.status !== 'AWAITING_REQUESTER' &&
      t.status !== 'AWAITING_THIRD_PARTY' &&
      t.status !== 'ESCALATED'
    )
      return false;
    if (statusTab === 'CRITICAL' && t.priority !== 'CRITICAL') return false;
    if (statusTab === 'RESOLVED' && t.status !== 'RESOLVED') return false;
    if (statusTab === 'CLOSED' && t.status !== 'CLOSED') return false;

    if (categoryFilter !== 'ALL' && t.category !== categoryFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        t.ticket_number.toLowerCase().includes(q) ||
        t.subject.toLowerCase().includes(q) ||
        t.requester_name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportCsv = () => {
    const headers = ['Ticket Number', 'Requester', 'Account Type', 'Category', 'Priority', 'Status', 'Subject', 'Assigned To', 'Created At'];
    const rows = filteredTickets.map((t) => [
      t.ticket_number,
      `"${t.requester_name}"`,
      t.requester_account_type,
      t.category,
      t.priority,
      t.status,
      `"${t.subject.replace(/"/g, '""')}"`,
      `"${t.assigned_to_name || 'Unassigned'}"`,
      t.created_at,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EIT_IT_Tickets_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const priorityBadges = {
    CRITICAL: 'bg-red-50 text-red-700 border-red-200',
    HIGH: 'bg-orange-50 text-orange-700 border-orange-200',
    NORMAL: 'bg-blue-50 text-blue-700 border-blue-200',
    LOW: 'bg-slate-50 text-slate-700 border-slate-200',
  };

  const statusBadges: Record<TicketStatus, string> = {
    OPEN: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    ASSIGNED: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    IN_PROGRESS: 'bg-blue-50 text-blue-700 border-blue-200',
    AWAITING_REQUESTER: 'bg-amber-50 text-amber-700 border-amber-200',
    AWAITING_THIRD_PARTY: 'bg-purple-50 text-purple-700 border-purple-200',
    ESCALATED: 'bg-red-50 text-red-700 border-red-200',
    RESOLVED: 'bg-emerald-50 text-emerald-800 border-emerald-300',
    CLOSED: 'bg-slate-100 text-slate-700 border-slate-300',
    REOPENED: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Institutional IT Support & Helpdesk Tickets
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Log, track, assign, and resolve campus technology tickets under authoritative SLA targets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isItStaff && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleExportCsv}
              leftIcon={<Download className="w-3.5 h-3.5" />}
              className="text-xs cursor-pointer"
            >
              Export CSV
            </Button>
          )}
          <Button
            size="sm"
            variant="primary"
            onClick={onOpenNewTicket}
            leftIcon={<PlusCircle className="w-4 h-4" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            Log New Ticket
          </Button>
        </div>
      </div>

      {/* Status Tabs Bar */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs">
        {(['ALL', 'OPEN', 'IN_PROGRESS', 'CRITICAL', 'RESOLVED', 'CLOSED'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setStatusTab(tab)}
            className={`px-3 py-1.5 font-bold rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
              statusTab === tab
                ? 'bg-[#1E3A8A] text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {tab.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by ticket #, subject, requester..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value as any)}
          className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white w-full sm:w-auto"
        >
          <option value="ALL">All Categories</option>
          <option value="LOGIN_ACCESS">Login & Account Access</option>
          <option value="PASSWORD_RESET">Password Reset</option>
          <option value="ID_CARD">ID Card Services</option>
          <option value="PORTAL_MALFUNCTION">Portal Malfunction</option>
          <option value="NETWORK">Network / Campus Wi-Fi</option>
          <option value="HARDWARE">Lab Hardware</option>
          <option value="SOFTWARE">Software / Licenses</option>
          <option value="EMAIL">Institutional Email</option>
          <option value="SECURITY_INCIDENT">Security Incident</option>
          <option value="OTHER">Other Issues</option>
        </select>
      </div>

      {/* Tickets Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
              <tr>
                <th className="py-3 px-4">Ticket Number</th>
                <th className="py-3 px-4">Subject & Category</th>
                <th className="py-3 px-4">Requester</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Assigned To</th>
                <th className="py-3 px-4">SLA Deadline</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                    No tickets found matching current view filters.
                  </td>
                </tr>
              ) : (
                filteredTickets.map((t) => (
                  <tr
                    key={t.ticket_id}
                    onClick={() => onOpenTicketDetail(t)}
                    className="hover:bg-cyan-50/40 transition-colors cursor-pointer group"
                  >
                    <td className="py-3 px-4 whitespace-nowrap font-mono font-bold text-cyan-800 group-hover:underline">
                      {t.ticket_number}
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      <div className="font-bold text-slate-900 truncate group-hover:text-cyan-900">{t.subject}</div>
                      <div className="text-[10px] text-slate-500">{t.category.replace(/_/g, ' ')}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-medium text-slate-900">{t.requester_name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{t.requester_account_type}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${priorityBadges[t.priority]}`}>
                        {t.priority}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${statusBadges[t.status]}`}>
                          {t.status.replace(/_/g, ' ')}
                        </span>
                        {t.sla_paused && (
                          <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-black border border-amber-200">
                            Paused
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-semibold text-slate-800">
                        {t.assigned_to_name || <em className="text-slate-400 font-normal">Unassigned</em>}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap text-[11px]">
                      <div className={t.sla_resolution_breached ? 'text-red-600 font-bold' : 'text-slate-600'}>
                        {new Date(t.sla_resolution_deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(t.sla_resolution_deadline).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenTicketDetail(t);
                        }}
                        leftIcon={<Eye className="w-3.5 h-3.5" />}
                        className="text-[11px] py-1 h-auto cursor-pointer"
                      >
                        Inspect / Reply
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
