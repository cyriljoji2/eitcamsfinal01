import React from 'react';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Server,
  Zap,
  Globe,
  Radio,
} from 'lucide-react';

export function ApplicationMonitoringView() {
  const endpoints = [
    { name: 'Student Portal Gateway', path: '/#/student', status: 'HEALTHY', latency: '12ms', availability: '99.99%' },
    { name: 'Employee Portal Gateway', path: '/#/employee', status: 'HEALTHY', latency: '15ms', availability: '99.98%' },
    { name: 'Parent Portal Gateway', path: '/#/parent', status: 'HEALTHY', latency: '14ms', availability: '99.99%' },
    { name: 'Administration Office API', path: '/api/admin', status: 'HEALTHY', latency: '22ms', availability: '99.95%' },
    { name: 'Admissions Intake Service', path: '/api/admissions', status: 'HEALTHY', latency: '18ms', availability: '99.96%' },
    { name: 'Academic Office Service', path: '/api/academic', status: 'HEALTHY', latency: '20ms', availability: '99.97%' },
    { name: 'COE Examination Service', path: '/api/coe', status: 'HEALTHY', latency: '25ms', availability: '99.95%' },
    { name: 'Finance & Payments Service', path: '/api/finance', status: 'HEALTHY', latency: '19ms', availability: '99.96%' },
    { name: 'Hostel Office Service', path: '/api/hostel', status: 'HEALTHY', latency: '16ms', availability: '99.98%' },
    { name: 'IT Technical Services (PO-007)', path: '/api/it', status: 'HEALTHY', latency: '11ms', availability: '100.0%' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Application & Portal Health Monitoring
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Availability and response latency for all 3 public login gateways and 7 permanent institutional offices.
          </p>
        </div>

        <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          10 / 10 Gateways Online
        </span>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
            <tr>
              <th className="py-3 px-4">Portal / Service Endpoint</th>
              <th className="py-3 px-4">Target Route</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Avg Latency</th>
              <th className="py-3 px-4">30-Day Availability</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {endpoints.map((ep) => (
              <tr key={ep.name} className="hover:bg-slate-50">
                <td className="py-3 px-4 font-bold text-slate-900">{ep.name}</td>
                <td className="py-3 px-4 font-mono text-slate-500 text-[11px]">{ep.path}</td>
                <td className="py-3 px-4">
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> ONLINE
                  </span>
                </td>
                <td className="py-3 px-4 font-mono text-cyan-800 font-semibold">{ep.latency}</td>
                <td className="py-3 px-4 font-mono font-bold text-slate-800">{ep.availability}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
