import React, { useState } from 'react';
import {
  Sliders,
  CheckCircle2,
  Lock,
  RefreshCw,
  Clock,
  Shield,
} from 'lucide-react';
import { Button } from '../../ui/Button';

export function SystemConfigurationView() {
  const [flags, setFlags] = useState({
    enforce_strict_mfa: false,
    id_card_live_qr_verify: true,
    require_password_aging_90d: true,
    student_self_hostel_request: true,
    parent_restricted_grades_view: true,
  });
  const [savedNotice, setSavedNotice] = useState(false);

  const handleToggle = (key: keyof typeof flags) => {
    setFlags((prev) => ({ ...prev, [key]: !prev[key] }));
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              System Configuration & Feature Governance
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Institutional security policies, session longevity rules, and experimental feature flags.
          </p>
        </div>
      </div>

      {savedNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Configuration flag updated and committed to active runtime memory.</span>
        </div>
      )}

      {/* Feature Flags */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2">
          Campus Feature Flags
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="font-bold text-slate-900 block">ID Card Real-Time Cryptographic QR Verification</span>
              <span className="text-[11px] text-slate-500">Generates verifiable digital QR code payloads for institutional security gates.</span>
            </div>
            <button
              onClick={() => handleToggle('id_card_live_qr_verify')}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                flags.id_card_live_qr_verify ? 'bg-[#1E3A8A]' : 'bg-slate-300'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                flags.id_card_live_qr_verify ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="font-bold text-slate-900 block">Enforce 90-Day Password Aging Expiry</span>
              <span className="text-[11px] text-slate-500">Requires employees and students to rotate credentials every 90 days.</span>
            </div>
            <button
              onClick={() => handleToggle('require_password_aging_90d')}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                flags.require_password_aging_90d ? 'bg-[#1E3A8A]' : 'bg-slate-300'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                flags.require_password_aging_90d ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="font-bold text-slate-900 block">Student Online Hostel Allocation Requests</span>
              <span className="text-[11px] text-slate-500">Allows enrolled students to initiate room allotment requests from the student portal.</span>
            </div>
            <button
              onClick={() => handleToggle('student_self_hostel_request')}
              className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                flags.student_self_hostel_request ? 'bg-[#1E3A8A]' : 'bg-slate-300'
              }`}
            >
              <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                flags.student_self_hostel_request ? 'translate-x-5' : ''
              }`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
