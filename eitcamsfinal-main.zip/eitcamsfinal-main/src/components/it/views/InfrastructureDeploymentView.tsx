import React, { useState } from 'react';
import {
  Server,
  Cpu,
  Power,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Terminal,
  Activity,
  Layers,
} from 'lucide-react';
import { InfrastructureInfo } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface InfrastructureDeploymentViewProps {
  currentUserId: string;
  currentUserRole: string;
  onRefresh: () => void;
}

export function InfrastructureDeploymentView({
  currentUserId,
  currentUserRole,
  onRefresh,
}: InfrastructureDeploymentViewProps) {
  const infra = itRepository.getInfrastructureInfo();
  const [maintenanceMsg, setMaintenanceMsg] = useState(infra.maintenance_message || '');
  const [isTogglingMaint, setIsTogglingMaint] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleToggleMaintenance = async (enable: boolean) => {
    setIsTogglingMaint(true);
    setActionNotice(null);
    try {
      await itRepository.toggleMaintenanceMode(enable, maintenanceMsg, {
        userId: currentUserId,
        role: currentUserRole,
      });
      setActionNotice(`Maintenance mode successfully ${enable ? 'ACTIVATED' : 'DEACTIVATED'}.`);
      onRefresh();
    } finally {
      setIsTogglingMaint(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Infrastructure & Runtime Environment
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Node.js 22 runtime container parameters, process status, and maintenance mode gating.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            Port: 3000 (0.0.0.0)
          </span>
        </div>
      </div>

      {actionNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Infrastructure Details Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Application Version</span>
          <p className="text-base font-black text-slate-900">{infra.app_version}</p>
          <p className="text-[10px] text-slate-500">{infra.app_name}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Runtime Node Engine</span>
          <p className="text-base font-mono font-black text-slate-900">{infra.node_version}</p>
          <p className="text-[10px] text-slate-500">{infra.platform_os}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Deployment Target</span>
          <p className="text-sm font-bold text-slate-900">{infra.deployment_provider}</p>
          <p className="text-[10px] text-purple-700 font-semibold">Vercel Planned Phase 12</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Build Status</span>
          <p className="text-base font-black text-emerald-700 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {infra.build_status}
          </p>
          <p className="text-[10px] text-slate-500">TypeScript Zero-Emit Clean</p>
        </div>
      </div>

      {/* Maintenance Mode Governance */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Institutional Maintenance Mode Control
            </h3>
            <p className="text-xs text-slate-500">
              When activated, non-administrative portals display a scheduled maintenance screen.
            </p>
          </div>
          <span
            className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
              infra.maintenance_mode
                ? 'bg-amber-50 text-amber-800 border-amber-300'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200'
            }`}
          >
            {infra.maintenance_mode ? 'MAINTENANCE ACTIVE' : 'NORMAL OPERATIONS'}
          </span>
        </div>

        <div className="space-y-3 text-xs max-w-xl">
          <div>
            <label className="font-bold text-slate-700 block mb-1">
              Broadcast Maintenance Notice Message
            </label>
            <textarea
              value={maintenanceMsg}
              onChange={(e) => setMaintenanceMsg(e.target.value)}
              rows={2}
              className="w-full p-2.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
            />
          </div>

          <div className="flex gap-2">
            {infra.maintenance_mode ? (
              <Button
                size="sm"
                variant="primary"
                onClick={() => handleToggleMaintenance(false)}
                disabled={isTogglingMaint}
                className="text-xs bg-emerald-700 hover:bg-emerald-800 cursor-pointer"
              >
                Resume Normal Operations
              </Button>
            ) : (
              <Button
                size="sm"
                variant="primary"
                onClick={() => handleToggleMaintenance(true)}
                disabled={isTogglingMaint}
                className="text-xs bg-amber-700 hover:bg-amber-800 cursor-pointer"
              >
                Activate Maintenance Mode
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
