import React, { useState } from 'react';
import {
  KeyRound,
  Search,
  CheckCircle2,
  Clock,
  ShieldAlert,
  UserCheck,
  RotateCcw,
} from 'lucide-react';
import { PasswordResetAuditRecord } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface PasswordResetViewProps {
  onOpenResetModal: () => void;
}

export function PasswordResetView({ onOpenResetModal }: PasswordResetViewProps) {
  const [filterQuery, setFilterQuery] = useState('');
  const history = itRepository.getPasswordResetHistory();

  const filteredHistory = history.filter((rec) => {
    if (!filterQuery.trim()) return true;
    const q = filterQuery.toLowerCase();
    return (
      rec.target_username.toLowerCase().includes(q) ||
      rec.target_full_name.toLowerCase().includes(q) ||
      rec.reason.toLowerCase().includes(q) ||
      rec.reset_by_operator_name.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Password Reset Management & Credential Governance
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Reset passwords for existing student, employee, parent, and office accounts with strict identity verification.
          </p>
        </div>

        <Button
          size="sm"
          variant="primary"
          onClick={onOpenResetModal}
          leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
          className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
        >
          Execute Password Reset
        </Button>
      </div>

      {/* Security Principles Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 space-y-1">
          <p className="font-bold flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-[#1E3A8A]" />
            Existing Accounts Only
          </p>
          <p className="text-[11px] text-blue-800">
            IT can only reset credentials for accounts verified in authoritative institutional records.
          </p>
        </div>

        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 space-y-1">
          <p className="font-bold flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-emerald-700" />
            Mandatory First-Login Change
          </p>
          <p className="text-[11px] text-emerald-800">
            Temporary passwords automatically force users to establish a new password immediately upon entry.
          </p>
        </div>

        <div className="p-4 bg-slate-900 text-white rounded-xl p-4 space-y-1">
          <p className="font-bold text-cyan-300 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-cyan-400" />
            Session Invalidation
          </p>
          <p className="text-[11px] text-slate-300">
            Active browser sessions and refresh tokens are terminated across all devices upon reset.
          </p>
        </div>
      </div>

      {/* Reset Audit Trail Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden space-y-3 p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Password Reset Audit Trail ({filteredHistory.length})
            </h3>
            <p className="text-xs text-slate-500">
              Chronological ledger of authorized password resets with operator signatures.
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Search by user, reg no, operator..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
            />
          </div>
        </div>

        <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Target Account</th>
                <th className="py-2.5 px-3">Account Type</th>
                <th className="py-2.5 px-3">Reason</th>
                <th className="py-2.5 px-3">Operator</th>
                <th className="py-2.5 px-3">Security Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                    No password reset records found.
                  </td>
                </tr>
              ) : (
                filteredHistory.map((rec) => (
                  <tr key={rec.reset_id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {new Date(rec.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-slate-900">{rec.target_full_name}</div>
                      <div className="text-[10px] font-mono text-slate-500">{rec.target_username}</div>
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                        {rec.target_account_type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 max-w-xs truncate text-[11px]">
                      {rec.reason}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap font-medium text-slate-800">
                      {rec.reset_by_operator_name}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        Sessions Revoked &bull; Reset Armed
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
