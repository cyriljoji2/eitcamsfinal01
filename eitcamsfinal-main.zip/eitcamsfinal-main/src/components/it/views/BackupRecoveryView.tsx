import React, { useState } from 'react';
import {
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Clock,
  Download,
  ShieldCheck,
  PlusCircle,
  FileArchive,
} from 'lucide-react';
import { BackupRecord } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface BackupRecoveryViewProps {
  currentUserId: string;
  currentUserRole: string;
  onRefresh: () => void;
}

export function BackupRecoveryView({
  currentUserId,
  currentUserRole,
  onRefresh,
}: BackupRecoveryViewProps) {
  const backups = itRepository.getBackups();
  const [isTriggering, setIsTriggering] = useState(false);
  const [notes, setNotes] = useState('');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleTriggerSnapshot = async () => {
    setIsTriggering(true);
    setActionNotice(null);
    try {
      const res = await itRepository.triggerBackup(
        'STATE_SNAPSHOT',
        notes.trim() || 'Manual institutional state snapshot',
        { userId: currentUserId, role: currentUserRole }
      );
      setActionNotice(`Backup ${res.backup_id} created successfully (${res.size_kb} KB).`);
      setNotes('');
      onRefresh();
    } finally {
      setIsTriggering(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Disaster Recovery & Backup Readiness
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Snapshot state archives, retention policies, and institutional point-in-time recovery testing.
          </p>
        </div>

        <span className="text-xs font-bold px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
          Retention Policy: 30 Days Rolling
        </span>
      </div>

      {actionNotice && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Manual Trigger Panel */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-3">
        <h3 className="text-sm font-bold text-slate-900">
          Execute Manual State Archive Snapshot
        </h3>
        <p className="text-xs text-slate-500">
          Captures a serialized, tamper-evident snapshot of the current 24-table data adapter state.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-1">
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Audit notes (e.g. Pre-semester timetable batch publication snapshot)..."
            className="flex-1 p-2 text-xs border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
          <Button
            size="sm"
            variant="primary"
            onClick={handleTriggerSnapshot}
            disabled={isTriggering}
            leftIcon={isTriggering ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <PlusCircle className="w-3.5 h-3.5" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            {isTriggering ? 'Archiving State...' : 'Trigger Snapshot'}
          </Button>
        </div>
      </div>

      {/* Backup Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Historical Snapshots ({backups.length})
          </h3>
          <span className="text-[10px] text-slate-400 italic">Development state serialized in session memory</span>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
            <tr>
              <th className="py-2.5 px-4">Backup ID</th>
              <th className="py-2.5 px-4">Type</th>
              <th className="py-2.5 px-4">Size</th>
              <th className="py-2.5 px-4">Created Timestamp</th>
              <th className="py-2.5 px-4">Operator / Trigger</th>
              <th className="py-2.5 px-4">Notes</th>
              <th className="py-2.5 px-4">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {backups.map((b) => (
              <tr key={b.backup_id} className="hover:bg-slate-50">
                <td className="py-3 px-4 font-mono font-bold text-slate-900">{b.backup_id}</td>
                <td className="py-3 px-4 font-mono text-[10px] text-slate-600">{b.backup_type}</td>
                <td className="py-3 px-4 font-mono text-cyan-800 font-bold">{b.size_kb} KB</td>
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">{new Date(b.created_at).toLocaleString()}</td>
                <td className="py-3 px-4 font-medium text-slate-800">{b.created_by}</td>
                <td className="py-3 px-4 text-slate-500 max-w-xs truncate">{b.notes || '—'}</td>
                <td className="py-3 px-4">
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> VERIFIED
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
