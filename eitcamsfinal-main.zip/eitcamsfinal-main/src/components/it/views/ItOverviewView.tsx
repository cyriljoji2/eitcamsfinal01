import React from 'react';
import {
  Users,
  LifeBuoy,
  AlertTriangle,
  Clock,
  KeyRound,
  CreditCard,
  Server,
  Activity,
  ShieldCheck,
  CheckCircle2,
  HardDrive,
  Cpu,
  ArrowRight,
  TrendingUp,
  FileCheck,
  Sparkles,
} from 'lucide-react';
import { ItDashboardMetrics, ItTab } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';

interface ItOverviewViewProps {
  metrics: ItDashboardMetrics;
  onNavigateTab: (tab: ItTab) => void;
  onOpenPasswordReset: () => void;
  onOpenNewTicket: () => void;
}

export function ItOverviewView({
  metrics,
  onNavigateTab,
  onOpenPasswordReset,
  onOpenNewTicket,
}: ItOverviewViewProps) {
  return (
    <div className="space-y-6">
      {/* Banner / Institutional Notice */}
      <div className="bg-linear-to-r from-slate-900 via-[#1E3A8A] to-slate-900 rounded-2xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-[10px] uppercase font-bold tracking-widest bg-cyan-400/20 text-cyan-300 px-2.5 py-0.5 rounded-full border border-cyan-400/30">
              Department PO-007
            </span>
            <span className="text-[10px] text-white/70">&bull; Technical Governance & Infrastructure</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Information Technology & Support Command Center
          </h2>
          <p className="text-xs sm:text-sm text-cyan-100/90 mt-1 max-w-2xl leading-relaxed">
            Centralized technical services for Electrix Institute of Technology (EIT). Governing identity systems,
            automated ID cards, account credentials, IT helpdesk SLAs, and application reliability.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-4">
            <Button
              size="sm"
              variant="primary"
              onClick={onOpenNewTicket}
              leftIcon={<LifeBuoy className="w-4 h-4 text-cyan-300" />}
              className="text-xs bg-white text-slate-900 hover:bg-slate-100 cursor-pointer"
            >
              Log Support Ticket
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={onOpenPasswordReset}
              leftIcon={<KeyRound className="w-4 h-4" />}
              className="text-xs border-white/30 text-white hover:bg-white/10 cursor-pointer"
            >
              Reset Account Password
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => onNavigateTab('system_health')}
              leftIcon={<Activity className="w-4 h-4 text-emerald-400" />}
              className="text-xs border-white/30 text-white hover:bg-white/10 cursor-pointer"
            >
              System Health & Diagnostics
            </Button>
          </div>
        </div>

        {/* Development adapter notice badge */}
        <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-white/60">
          <span>Storage Adapter: <strong className="text-cyan-200">DevDataAdapter (In-Memory + SessionStorage)</strong></span>
          <span className="bg-blue-500/20 text-cyan-200 px-2 py-0.5 rounded border border-blue-400/30 text-[10px]">
            Phase 11 Google Sheets Integration Ready
          </span>
        </div>
      </div>

      {/* Primary KPI Grid (12 Key Indicators) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {/* Total IT Staff */}
        <div
          onClick={() => onNavigateTab('user_access')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">IT Employees</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1E3A8A] flex items-center justify-center group-hover:bg-[#1E3A8A] group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black text-slate-900">{metrics.totalItEmployees}</span>
            <span className="text-xs text-slate-400 ml-1.5">({metrics.activeItEmployees} active)</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Assigned by Administration</p>
        </div>

        {/* Open Tickets */}
        <div
          onClick={() => onNavigateTab('tickets')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Open Tickets</span>
            <div className="w-8 h-8 rounded-lg bg-cyan-50 text-cyan-700 flex items-center justify-center group-hover:bg-cyan-700 group-hover:text-white transition-colors">
              <LifeBuoy className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black text-slate-900">{metrics.openTickets}</span>
            <span className="text-xs text-slate-400 ml-1.5">pending action</span>
          </div>
          <p className="text-[10px] text-cyan-700 font-medium mt-1">IT Helpdesk Queue</p>
        </div>

        {/* Critical Tickets */}
        <div
          onClick={() => onNavigateTab('tickets')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-red-500 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Critical Tickets</span>
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center group-hover:bg-red-600 group-hover:text-white transition-colors">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className={`text-2xl font-black ${metrics.criticalTickets > 0 ? 'text-red-600' : 'text-slate-900'}`}>
              {metrics.criticalTickets}
            </span>
            <span className="text-xs text-slate-400 ml-1.5">high priority</span>
          </div>
          <p className="text-[10px] text-red-600 font-medium mt-1">15m target response</p>
        </div>

        {/* Approaching SLA & Breaches */}
        <div
          onClick={() => onNavigateTab('sla_policies')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-amber-500 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">SLA Status</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black text-slate-900">{metrics.approachingSlaTickets}</span>
            <span className="text-xs text-slate-400 ml-1.5">due soon</span>
          </div>
          <p className="text-[10px] text-amber-700 font-medium mt-1">
            {metrics.slaBreaches > 0 ? `${metrics.slaBreaches} SLA breach recorded` : '0 SLA breaches'}
          </p>
        </div>

        {/* ID Cards Generated */}
        <div
          onClick={() => onNavigateTab('id_cards')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">ID Cards Active</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black text-slate-900">{metrics.idCardsGenerated}</span>
            <span className="text-xs text-slate-400 ml-1.5">cards</span>
          </div>
          <p className="text-[10px] text-emerald-700 font-medium mt-1">Auto-provisioned with QR</p>
        </div>

        {/* Password Resets Executed */}
        <div
          onClick={() => onNavigateTab('password_reset')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Password Resets</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <KeyRound className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black text-slate-900">{metrics.passwordResetsCount}</span>
            <span className="text-xs text-slate-400 ml-1.5">operations</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Strict identity audit logged</p>
        </div>

        {/* System Health */}
        <div
          onClick={() => onNavigateTab('system_health')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">System Health</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Server className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-lg font-black text-slate-900">{metrics.overallSystemHealth}</span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Uptime: {metrics.applicationAvailability}%</p>
        </div>

        {/* Test Account Status */}
        <div
          onClick={() => onNavigateTab('test_accounts')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-[#1E3A8A] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Test Account</span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
              metrics.testAccountEnabled ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
            }`}>
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <span className={`text-base font-black ${metrics.testAccountEnabled ? 'text-amber-600' : 'text-slate-600'}`}>
              {metrics.testAccountEnabled ? 'ENABLED (TEST)' : 'DISABLED (SECURE)'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Production data isolated</p>
        </div>
      </div>

      {/* Quick Navigation Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Support & Tickets Quick View */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <LifeBuoy className="w-4 h-4 text-[#1E3A8A]" />
              <h3 className="text-sm font-bold text-slate-900">IT Helpdesk & SLA Status</h3>
            </div>
            <button
              onClick={() => onNavigateTab('tickets')}
              className="text-xs text-[#1E3A8A] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              View All <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Standard Resolution SLA:</span>
              <strong className="text-slate-800">2 Business Days</strong>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Critical Incident Target:</span>
              <strong className="text-red-700">15 min response / 4 hr resolution</strong>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Official Support Hours:</span>
              <strong className="text-slate-800">Mon–Fri, 8:00 AM – 5:00 PM EST</strong>
            </div>
          </div>
        </div>

        {/* Database & Integrations Quick View */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-[#1E3A8A]" />
              <h3 className="text-sm font-bold text-slate-900">Architecture & Future Readiness</h3>
            </div>
            <button
              onClick={() => onNavigateTab('database')}
              className="text-xs text-[#1E3A8A] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
            >
              Inspect <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Google Sheets DB:</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                Phase 11 Planned
              </span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Vercel Deployment:</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                Phase 12 Planned
              </span>
            </div>
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50">
              <span className="text-slate-600">Repository Protocol:</span>
              <span className="font-mono text-emerald-700 font-bold text-[11px]">
                IEitDataAdapter Compliant
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
