import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  Lock,
  Download,
  Calendar,
  CheckCircle2,
  RefreshCw,
  User,
} from 'lucide-react';
import { AuditLogRecord } from '../../../types/database';
import { Button } from '../../ui/Button';
import { devDataAdapter } from '../../../services/devDataAdapter';

export function SecurityAuditView() {
  const [logs, setLogs] = useState<AuditLogRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [actionFilter, setActionFilter] = useState('ALL');

  const fetchLogs = useCallback(async () => {
    try {
      setIsLoading(true);
      const allLogs = await devDataAdapter.audit.getAll();
      setLogs(allLogs);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const filteredLogs = logs.filter((log) => {
    if (roleFilter !== 'ALL' && log.actor_role !== roleFilter) return false;
    if (actionFilter !== 'ALL' && log.action !== actionFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        log.actor_id.toLowerCase().includes(q) ||
        log.action.toLowerCase().includes(q) ||
        log.target_worksheet.toLowerCase().includes(q) ||
        log.target_record_id.toLowerCase().includes(q) ||
        log.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportCsv = () => {
    const headers = ['Timestamp', 'Actor ID', 'Actor Role', 'Action', 'Target Worksheet', 'Record ID', 'Description'];
    const rows = filteredLogs.map((l) => [
      l.timestamp,
      l.actor_id,
      l.actor_role,
      l.action,
      l.target_worksheet,
      l.target_record_id,
      `"${l.description.replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EIT_Security_Audit_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Institutional Security & Compliance Audit Trail
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Immutable, append-only security journal documenting all privileged authentication and office operations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={fetchLogs}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            className="text-xs cursor-pointer"
          >
            Refresh
          </Button>
          <Button
            size="sm"
            variant="primary"
            onClick={handleExportCsv}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            Export Audit CSV
          </Button>
        </div>
      </div>

      {/* Immutability Banner */}
      <div className="p-3.5 bg-slate-900 rounded-xl text-white text-xs flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <Lock className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="text-slate-300">
            Write-Once-Read-Many (WORM) compliant ledger. Ordinary IT operators cannot modify or delete audit entries.
          </span>
        </div>
        <span className="text-[10px] font-mono text-cyan-300 bg-white/10 px-2 py-0.5 rounded shrink-0">
          Total Logs: {logs.length}
        </span>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-center gap-3 text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by actor, action, worksheet, or description..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
          >
            <option value="ALL">All Roles</option>
            <option value="SUPER_ADMIN">SUPER_ADMIN</option>
            <option value="OFFICE_ADMIN">OFFICE_ADMIN</option>
            <option value="FACULTY">FACULTY</option>
            <option value="NON_TEACHING_STAFF">NON_TEACHING_STAFF</option>
            <option value="STUDENT">STUDENT</option>
            <option value="SYSTEM">SYSTEM</option>
          </select>

          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
          >
            <option value="ALL">All Actions</option>
            <option value="LOGIN_ATTEMPT">LOGIN_ATTEMPT</option>
            <option value="IT_PASSWORD_RESET">IT_PASSWORD_RESET</option>
            <option value="IT_ID_CARD_GENERATE">IT_ID_CARD_GENERATE</option>
            <option value="IT_ID_CARD_REISSUE">IT_ID_CARD_REISSUE</option>
            <option value="IT_TEST_ACCOUNT_TOGGLE">IT_TEST_ACCOUNT_TOGGLE</option>
            <option value="IT_TICKET_CREATE">IT_TICKET_CREATE</option>
            <option value="IT_TICKET_RESOLVE">IT_TICKET_RESOLVE</option>
            <option value="IT_PERMISSION_CHANGE">IT_PERMISSION_CHANGE</option>
            <option value="IT_CONTACT_SETTINGS_UPDATE">IT_CONTACT_SETTINGS_UPDATE</option>
            <option value="CREATE">CREATE</option>
            <option value="UPDATE">UPDATE</option>
            <option value="DELETE">DELETE</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Timestamp (UTC)</th>
                <th className="py-2.5 px-3">Actor & Role</th>
                <th className="py-2.5 px-3">Action</th>
                <th className="py-2.5 px-3">Worksheet / Target</th>
                <th className="py-2.5 px-3">Description</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {isLoading ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">Loading audit records...</td>
                </tr>
              ) : filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400 italic">No audit records match filters.</td>
                </tr>
              ) : (
                filteredLogs.map((l) => (
                  <tr key={l.log_id || l.timestamp + l.target_record_id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 whitespace-nowrap font-mono text-[11px] text-slate-500">
                      {new Date(l.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-bold text-slate-900">{l.actor_id}</div>
                      <div className="text-[10px] font-mono text-slate-500">{l.actor_role}</div>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 border border-slate-200">
                        {l.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{l.target_worksheet}</div>
                      <div className="text-[10px] font-mono text-slate-400 truncate max-w-[140px]">{l.target_record_id}</div>
                    </td>
                    <td className="py-2.5 px-3 text-[11px] text-slate-600">
                      {l.description}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
