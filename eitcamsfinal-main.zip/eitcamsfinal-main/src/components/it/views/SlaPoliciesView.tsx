import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  ShieldCheck,
  RefreshCw,
  Send,
  History,
} from 'lucide-react';
import { SlaPolicyRecord, TicketPriority } from '../../../types/itDepartment';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

interface SlaPoliciesViewProps {
  currentUserId: string;
  currentUserRole: string;
  onRefresh: () => void;
}

export function SlaPoliciesView({
  currentUserId,
  currentUserRole,
  onRefresh,
}: SlaPoliciesViewProps) {
  const activePolicy = itRepository.getActiveSlaPolicy();
  const allPolicies = itRepository.getAllSlaPolicies();

  const [policyName, setPolicyName] = useState(activePolicy.policy_name);
  const [criticalResp, setCriticalResp] = useState(activePolicy.targets.CRITICAL.response_time_minutes);
  const [criticalRes, setCriticalRes] = useState(activePolicy.targets.CRITICAL.resolution_time_minutes);
  const [highResp, setHighResp] = useState(activePolicy.targets.HIGH.response_time_minutes);
  const [highRes, setHighRes] = useState(activePolicy.targets.HIGH.resolution_time_minutes);
  const [normalResp, setNormalResp] = useState(activePolicy.targets.NORMAL.response_time_minutes);
  const [normalRes, setNormalRes] = useState(activePolicy.targets.NORMAL.resolution_time_minutes);
  const [lowResp, setLowResp] = useState(activePolicy.targets.LOW.response_time_minutes);
  const [lowRes, setLowRes] = useState(activePolicy.targets.LOW.resolution_time_minutes);
  const [businessStart, setBusinessStart] = useState(activePolicy.business_hours.start);
  const [businessEnd, setBusinessEnd] = useState(activePolicy.business_hours.end);
  const [warningThreshold, setWarningThreshold] = useState(activePolicy.warning_threshold_percent);
  const [reason, setReason] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSavePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setErrorMsg('An institutional reason is required to publish a revised SLA policy version.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const updated: SlaPolicyRecord = {
        ...activePolicy,
        policy_name: policyName.trim() || 'Institutional Support SLA',
        targets: {
          CRITICAL: { response_time_minutes: Number(criticalResp), resolution_time_minutes: Number(criticalRes) },
          HIGH: { response_time_minutes: Number(highResp), resolution_time_minutes: Number(highRes) },
          NORMAL: { response_time_minutes: Number(normalResp), resolution_time_minutes: Number(normalRes) },
          LOW: { response_time_minutes: Number(lowResp), resolution_time_minutes: Number(lowRes) },
        },
        business_hours: {
          start: businessStart,
          end: businessEnd,
        },
        warning_threshold_percent: Number(warningThreshold),
      };

      const newPolicy = await itRepository.updateSlaPolicy(updated, reason.trim(), {
        userId: currentUserId,
        role: currentUserRole,
      });

      setSuccessMsg(`New SLA Policy Version ${newPolicy.version} active! Pre-existing tickets retain their historical SLA baseline.`);
      setReason('');
      onRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update SLA policy.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              Institutional SLA Policies & Response Targets
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure response and resolution thresholds for support tickets across all campus priorities.
          </p>
        </div>

        <span className="text-xs font-mono font-bold px-3 py-1.5 rounded-full bg-cyan-50 text-cyan-800 border border-cyan-200">
          Active Version: v{activePolicy.version}
        </span>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* SLA Policy Editor Form */}
      <form onSubmit={handleSavePolicy} className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6 space-y-6 text-xs">
        <div>
          <label className="font-bold text-slate-700 block mb-1">SLA Policy Title</label>
          <input
            type="text"
            value={policyName}
            onChange={(e) => setPolicyName(e.target.value)}
            className="w-full max-w-md p-2 border border-slate-300 rounded-lg outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
            required
          />
        </div>

        {/* Priority Targets Matrix */}
        <div className="space-y-3">
          <h3 className="font-bold text-slate-900 text-sm border-b border-slate-100 pb-2">
            Priority Response & Resolution Targets
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Critical */}
            <div className="p-3.5 bg-red-50/60 border border-red-200 rounded-xl space-y-2">
              <span className="font-bold text-red-700 block uppercase tracking-wider text-[11px]">
                CRITICAL
              </span>
              <div>
                <label className="text-[10px] text-slate-500 block">Response (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={criticalResp}
                  onChange={(e) => setCriticalResp(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-red-300 rounded font-mono font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block">Resolution (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={criticalRes}
                  onChange={(e) => setCriticalRes(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-red-300 rounded font-mono font-bold text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">{criticalRes / 60} hours</span>
              </div>
            </div>

            {/* High */}
            <div className="p-3.5 bg-orange-50/60 border border-orange-200 rounded-xl space-y-2">
              <span className="font-bold text-orange-700 block uppercase tracking-wider text-[11px]">
                HIGH
              </span>
              <div>
                <label className="text-[10px] text-slate-500 block">Response (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={highResp}
                  onChange={(e) => setHighResp(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-orange-300 rounded font-mono font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block">Resolution (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={highRes}
                  onChange={(e) => setHighRes(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-orange-300 rounded font-mono font-bold text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">{highRes / 60} hours</span>
              </div>
            </div>

            {/* Normal */}
            <div className="p-3.5 bg-blue-50/60 border border-blue-200 rounded-xl space-y-2">
              <span className="font-bold text-blue-700 block uppercase tracking-wider text-[11px]">
                NORMAL
              </span>
              <div>
                <label className="text-[10px] text-slate-500 block">Response (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={normalResp}
                  onChange={(e) => setNormalResp(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-blue-300 rounded font-mono font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block">Resolution (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={normalRes}
                  onChange={(e) => setNormalRes(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-blue-300 rounded font-mono font-bold text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">{normalRes / 60 / 24} business days</span>
              </div>
            </div>

            {/* Low */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="font-bold text-slate-700 block uppercase tracking-wider text-[11px]">
                LOW
              </span>
              <div>
                <label className="text-[10px] text-slate-500 block">Response (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={lowResp}
                  onChange={(e) => setLowResp(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 block">Resolution (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={lowRes}
                  onChange={(e) => setLowRes(Number(e.target.value))}
                  className="w-full p-1.5 bg-white border border-slate-300 rounded font-mono font-bold text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">{lowRes / 60 / 24} business days</span>
              </div>
            </div>
          </div>
        </div>

        {/* Business Calendar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-slate-100">
          <div>
            <label className="font-bold text-slate-700 block mb-1">Business Hours Start</label>
            <input
              type="time"
              value={businessStart}
              onChange={(e) => setBusinessStart(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg bg-white"
            />
          </div>
          <div>
            <label className="font-bold text-slate-700 block mb-1">Business Hours End</label>
            <input
              type="time"
              value={businessEnd}
              onChange={(e) => setBusinessEnd(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-lg bg-white"
            />
          </div>
          <div>
            <label className="font-bold text-slate-700 block mb-1">Warning Threshold (% Elapsed)</label>
            <input
              type="number"
              min="10"
              max="95"
              value={warningThreshold}
              onChange={(e) => setWarningThreshold(Number(e.target.value))}
              className="w-full p-2 border border-slate-300 rounded-lg bg-white font-mono font-bold"
            />
          </div>
        </div>

        <div>
          <label className="font-bold text-slate-800 block mb-1">
            Mandatory Institutional Reason for Revised Policy Version
          </label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g. Tightened critical target to 15m to support semester examination week..."
            required
            className="w-full p-2.5 border border-amber-300 rounded-lg bg-amber-50/40 outline-hidden focus:ring-2 focus:ring-[#1E3A8A]"
          />
        </div>

        {errorMsg && (
          <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 rounded-lg flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
          <Button
            type="submit"
            variant="primary"
            size="sm"
            disabled={isSubmitting || !reason.trim()}
            leftIcon={isSubmitting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            className="text-xs bg-[#1E3A8A] hover:bg-[#172E6E] cursor-pointer"
          >
            {isSubmitting ? 'Publishing Policy...' : 'Publish Revised SLA Policy Version'}
          </Button>
        </div>
      </form>

      {/* Historical Policies */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-3 text-xs">
        <h3 className="text-sm font-bold text-slate-900">
          SLA Policy Versioning History ({allPolicies.length})
        </h3>
        <p className="text-slate-500 text-[11px]">
          Existing tickets retain the policy version under which they were generated. Version changes never retrospectively modify breach logs.
        </p>

        <div className="border border-slate-200 rounded-xl overflow-hidden overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-3">Policy ID</th>
                <th className="py-2.5 px-3">Version</th>
                <th className="py-2.5 px-3">Policy Name</th>
                <th className="py-2.5 px-3">Critical Targets</th>
                <th className="py-2.5 px-3">Created</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {allPolicies.map((p) => (
                <tr key={p.policy_id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-3 font-mono text-[11px] font-bold text-slate-900">{p.policy_id}</td>
                  <td className="py-2.5 px-3 font-bold text-cyan-800">v{p.version}</td>
                  <td className="py-2.5 px-3">{p.policy_name}</td>
                  <td className="py-2.5 px-3 text-red-700 font-medium">
                    {p.targets.CRITICAL.response_time_minutes}m resp / {p.targets.CRITICAL.resolution_time_minutes / 60}h res
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                    {new Date(p.created_at).toLocaleDateString()}
                  </td>
                  <td className="py-2.5 px-3">
                    {p.is_active ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                        ACTIVE
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        ARCHIVED
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
