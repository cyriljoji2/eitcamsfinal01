import React from 'react';
import {
  BarChart3,
  Download,
  FileText,
  LifeBuoy,
  KeyRound,
  CreditCard,
  ShieldAlert,
  HardDrive,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../../ui/Button';
import { itRepository } from '../../../services/itService';

export function ItReportsView() {
  const tickets = itRepository.getTickets();
  const idCards = itRepository.getAllIdCards();
  const resets = itRepository.getPasswordResetHistory();
  const backups = itRepository.getBackups();

  const exportCsv = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportTickets = () => {
    const headers = ['Ticket ID', 'Ticket Number', 'Requester', 'Account Type', 'Category', 'Priority', 'Status', 'Assigned To', 'Created At'];
    const rows = tickets.map((t) => [
      t.ticket_id,
      t.ticket_number,
      `"${t.requester_name}"`,
      t.requester_account_type,
      t.category,
      t.priority,
      t.status,
      `"${t.assigned_to_name || 'Unassigned'}"`,
      t.created_at,
    ]);
    exportCsv('EIT_Tickets_Report', headers, rows);
  };

  const handleExportIdCards = () => {
    const headers = ['Card ID', 'Type', 'Registration Number', 'Name', 'Department', 'Designation/Program', 'Status', 'Expires'];
    const rows = idCards.map((c) => [
      c.card_id,
      c.card_type,
      c.registration_number,
      `"${c.full_name}"`,
      c.department,
      `"${c.designation_or_program}"`,
      c.status,
      c.expiry_date,
    ]);
    exportCsv('EIT_IdCards_Report', headers, rows);
  };

  const handleExportResets = () => {
    const headers = ['Reset ID', 'Target Username', 'Account Type', 'Target Name', 'Operator', 'Timestamp', 'Reason'];
    const rows = resets.map((r) => [
      r.reset_id,
      r.target_username,
      r.target_account_type,
      `"${r.target_full_name}"`,
      `"${r.reset_by_operator_name}"`,
      r.timestamp,
      `"${r.reason.replace(/"/g, '""')}"`,
    ]);
    exportCsv('EIT_Password_Resets_Report', headers, rows);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#1E3A8A]" />
            <h2 className="text-base font-bold text-slate-900">
              IT Reports, Metrics & CSV Compliance Exports
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Download institutional compliance records and operational summaries.
          </p>
        </div>
      </div>

      {/* Reports Export Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Tickets Report */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#1E3A8A] flex items-center justify-center font-bold">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900">Support Ticket Log</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export all helpdesk tickets, categories, SLA response dates, technician allocations, and resolution summaries.
            </p>
            <div className="text-[11px] font-mono text-slate-400">Total Records: {tickets.length}</div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={handleExportTickets}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="w-full text-xs cursor-pointer"
          >
            Download Tickets CSV
          </Button>
        </div>

        {/* ID Cards Report */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <CreditCard className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900">ID Card Master Registry</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export authoritative ledger of student and employee smart digital ID cards, validity terms, and reissue counts.
            </p>
            <div className="text-[11px] font-mono text-slate-400">Total Cards: {idCards.length}</div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={handleExportIdCards}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="w-full text-xs cursor-pointer"
          >
            Download ID Cards CSV
          </Button>
        </div>

        {/* Password Resets Report */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
              <KeyRound className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-sm text-slate-900">Password Reset Audit Ledger</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export verified operator actions, temporary credential dispatches, and forced password change records.
            </p>
            <div className="text-[11px] font-mono text-slate-400">Total Operations: {resets.length}</div>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={handleExportResets}
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="w-full text-xs cursor-pointer"
          >
            Download Resets CSV
          </Button>
        </div>
      </div>
    </div>
  );
}
