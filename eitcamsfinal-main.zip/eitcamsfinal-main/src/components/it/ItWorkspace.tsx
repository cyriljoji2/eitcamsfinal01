import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Terminal,
  AlertCircle,
  LayoutDashboard,
  Activity,
  Cpu,
  LifeBuoy,
  Gauge,
  Users,
  ShieldCheck,
  KeyRound,
  CreditCard,
  FlaskConical,
  Server,
  Database,
  Cloud,
  Archive,
  PlugZap,
  FileText,
  History,
  Sliders,
  Headphones,
  Clock,
  BarChart3,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { ItTab, TicketRecord, IdCardRecord, ItDashboardMetrics } from '../../types/itDepartment';
import { itRepository } from '../../services/itService';
import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { ItHeader } from './ItHeader';

// 17 Functional Views
import { ItOverviewView } from './views/ItOverviewView';
import { SystemHealthView } from './views/SystemHealthView';
import { UserAccessManagementView } from './views/UserAccessManagementView';
import { PasswordResetView } from './views/PasswordResetView';
import { IdCardManagementView } from './views/IdCardManagementView';
import { TestAccountView } from './views/TestAccountView';
import { SecurityAuditView } from './views/SecurityAuditView';
import { DatabaseManagementView } from './views/DatabaseManagementView';
import { InfrastructureDeploymentView } from './views/InfrastructureDeploymentView';
import { SystemConfigurationView } from './views/SystemConfigurationView';
import { ApiIntegrationsView } from './views/ApiIntegrationsView';
import { ApplicationMonitoringView } from './views/ApplicationMonitoringView';
import { ItTicketsView } from './views/ItTicketsView';
import { BackupRecoveryView } from './views/BackupRecoveryView';
import { ItContactSettingsView } from './views/ItContactSettingsView';
import { SlaPoliciesView } from './views/SlaPoliciesView';
import { ItReportsView } from './views/ItReportsView';

// Modals
import { PasswordResetModal } from './modals/PasswordResetModal';
import { NewTicketModal } from './modals/NewTicketModal';
import { TicketDetailModal } from './modals/TicketDetailModal';
import { IdCardPreviewModal } from './modals/IdCardPreviewModal';
import { IdCardReissueModal } from './modals/IdCardReissueModal';

export interface ItWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
  onRefreshData?: () => void;
}

const defaultMetrics: ItDashboardMetrics = {
  totalItEmployees: 1,
  activeItEmployees: 1,
  openTickets: 0,
  criticalTickets: 0,
  approachingSlaTickets: 0,
  slaBreaches: 0,
  passwordResetsCount: 0,
  idCardsGenerated: 0,
  pendingIdReissues: 0,
  testAccountEnabled: false,
  overallSystemHealth: 'HEALTHY',
  applicationAvailability: 99.98,
  latestAlertsCount: 0,
  recentActivityCount: 0,
  backupStatus: 'UP_TO_DATE',
  integrationStatus: 'OPERATIONAL',
};

export function ItWorkspace({ user, onLogout, onRefreshData }: ItWorkspaceProps) {
  // Navigation State with localStorage persistence
  const [activeTab, setActiveTab] = useState<ItTab>(() => {
    try {
      const saved = localStorage.getItem('eit_it_active_tab') as ItTab;
      return saved || 'overview';
    } catch {
      return 'overview';
    }
  });

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Loading & Error States
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Live Repositories State
  const [metrics, setMetrics] = useState<ItDashboardMetrics>(defaultMetrics);
  const [tickets, setTickets] = useState<TicketRecord[]>(() => itRepository.getTickets());
  const [idCards, setIdCards] = useState<IdCardRecord[]>(() => itRepository.getAllIdCards());

  // Modal Dialogs State
  const [isPasswordResetOpen, setIsPasswordResetOpen] = useState(false);
  const [isNewTicketOpen, setIsNewTicketOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<TicketRecord | null>(null);
  const [previewCard, setPreviewCard] = useState<IdCardRecord | null>(null);
  const [reissueCard, setReissueCard] = useState<IdCardRecord | null>(null);

  // Stable reference to onRefreshData to break circular parent/child refresh loops
  const onRefreshDataRef = useRef(onRefreshData);
  useEffect(() => {
    onRefreshDataRef.current = onRefreshData;
  }, [onRefreshData]);

  // Prevent overlapping background or user refresh requests
  const isRefreshingRef = useRef(false);

  // Pure comparators to avoid unnecessary re-renders
  const areMetricsEqual = (prev: ItDashboardMetrics, next: ItDashboardMetrics): boolean => {
    return (
      prev.totalItEmployees === next.totalItEmployees &&
      prev.activeItEmployees === next.activeItEmployees &&
      prev.openTickets === next.openTickets &&
      prev.criticalTickets === next.criticalTickets &&
      prev.approachingSlaTickets === next.approachingSlaTickets &&
      prev.slaBreaches === next.slaBreaches &&
      prev.passwordResetsCount === next.passwordResetsCount &&
      prev.idCardsGenerated === next.idCardsGenerated &&
      prev.pendingIdReissues === next.pendingIdReissues &&
      prev.testAccountEnabled === next.testAccountEnabled &&
      prev.overallSystemHealth === next.overallSystemHealth &&
      prev.applicationAvailability === next.applicationAvailability &&
      prev.latestAlertsCount === next.latestAlertsCount &&
      prev.recentActivityCount === next.recentActivityCount &&
      prev.backupStatus === next.backupStatus &&
      prev.integrationStatus === next.integrationStatus
    );
  };

  const areTicketsEqual = (prev: TicketRecord[], next: TicketRecord[]): boolean => {
    if (prev.length !== next.length) return false;
    for (let i = 0; i < prev.length; i++) {
      if (
        prev[i].ticket_id !== next[i].ticket_id ||
        prev[i].updated_at !== next[i].updated_at ||
        prev[i].status !== next[i].status ||
        prev[i].assigned_to_employee_id !== next[i].assigned_to_employee_id ||
        prev[i].responses.length !== next[i].responses.length ||
        (prev[i].activity_history?.length || 0) !== (next[i].activity_history?.length || 0)
      ) {
        return false;
      }
    }
    return true;
  };

  const areIdCardsEqual = (prev: IdCardRecord[], next: IdCardRecord[]): boolean => {
    if (prev.length !== next.length) return false;
    for (let i = 0; i < prev.length; i++) {
      if (
        prev[i].card_id !== next[i].card_id ||
        prev[i].updated_at !== next[i].updated_at ||
        prev[i].status !== next[i].status
      ) {
        return false;
      }
    }
    return true;
  };

  // 1. Initial Data Loading: Runs once when workspace mounts
  const loadInitialData = useCallback(async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const [liveMetrics, liveTickets, liveIdCards] = await Promise.all([
        itRepository.getDashboardMetrics(),
        Promise.resolve(itRepository.getTickets()),
        Promise.resolve(itRepository.getAllIdCards()),
      ]);
      setMetrics(liveMetrics);
      setTickets(liveTickets);
      setIdCards(liveIdCards);
    } catch (err: any) {
      console.error('Failed to initialize IT Workspace repositories', err);
      setLoadError(err?.message || 'Failed to initialize IT workspace.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // 2. Periodic & Action-driven Refresh: Completely decoupled from initial load and onRefreshData changes
  const refreshLocalState = useCallback(async (notifyParent = false) => {
    if (isRefreshingRef.current) {
      return; // Discard overlapping requests
    }
    isRefreshingRef.current = true;
    try {
      const liveMetrics = await itRepository.getDashboardMetrics();
      setMetrics((prev) => (areMetricsEqual(prev, liveMetrics) ? prev : liveMetrics));

      const newTickets = itRepository.getTickets();
      setTickets((prev) => (areTicketsEqual(prev, newTickets) ? prev : newTickets));

      const newCards = itRepository.getAllIdCards();
      setIdCards((prev) => (areIdCardsEqual(prev, newCards) ? prev : newCards));

      if (notifyParent && onRefreshDataRef.current) {
        await onRefreshDataRef.current();
      }
    } catch (e) {
      console.error('Failed to refresh IT workspace state', e);
    } finally {
      isRefreshingRef.current = false;
    }
  }, []);

  // Sync activeTab to localStorage
  const handleSelectTab = (tabId: string) => {
    const tab = tabId as ItTab;
    setActiveTab(tab);
    try {
      localStorage.setItem('eit_it_active_tab', tab);
    } catch {
      // ignore storage error
    }
    setIsMobileMenuOpen(false);
  };

  // 3. Periodic refresh & SLA checking: Created strictly once per workspace instance and cleaned up on unmount
  useEffect(() => {
    const interval = setInterval(() => {
      refreshLocalState(false);
    }, 60000);
    return () => clearInterval(interval);
  }, [refreshLocalState]);

  // Determine user identity
  const currentUserId = user.id || 'USR-PO-007';
  const currentUserName = user.name || user.username || 'IT Administrator';
  const currentUserRole = user.roleTitle || user.role || 'IT Administrator';
  const currentEmployeeId = user.employeeId || 'EMP-IT-001';

  // Navigation Sidebar Configuration (Single Accordion Expansion Discipline)
  const sidebarItems: PortalSidebarItem[] = [
    {
      id: 'overview',
      label: 'IT Overview',
      icon: LayoutDashboard,
    },
    {
      id: 'group_operations',
      label: 'Operations & Health',
      icon: Activity,
      subItems: [
        {
          id: 'system_health',
          label: 'System Health',
          icon: Cpu,
        },
        {
          id: 'tickets',
          label: 'IT Helpdesk Tickets',
          icon: LifeBuoy,
          badge: metrics.openTickets > 0 ? metrics.openTickets : undefined,
          badgeVariant: metrics.openTickets > 0 ? 'amber' : 'default',
        },
        {
          id: 'app_monitoring',
          label: 'Application Health',
          icon: Gauge,
        },
      ],
    },
    {
      id: 'group_identity',
      label: 'Identity & Access',
      icon: Users,
      subItems: [
        {
          id: 'user_access',
          label: 'Staff IT Permissions',
          icon: ShieldCheck,
        },
        {
          id: 'password_reset',
          label: 'Password Reset',
          icon: KeyRound,
        },
        {
          id: 'id_cards',
          label: 'ID Card Management',
          icon: CreditCard,
          badge: metrics.idCardsGenerated > 0 ? metrics.idCardsGenerated : undefined,
        },
        {
          id: 'test_accounts',
          label: 'Test Environment',
          icon: FlaskConical,
        },
      ],
    },
    {
      id: 'group_systems',
      label: 'Systems & Data',
      icon: Server,
      subItems: [
        {
          id: 'database',
          label: 'Database Management',
          icon: Database,
        },
        {
          id: 'infrastructure',
          label: 'Infrastructure & Deploy',
          icon: Cloud,
        },
        {
          id: 'backup',
          label: 'Backup & Recovery',
          icon: Archive,
        },
        {
          id: 'integrations',
          label: 'API & Integrations',
          icon: PlugZap,
        },
      ],
    },
    {
      id: 'group_governance',
      label: 'Governance & Policy',
      icon: FileText,
      subItems: [
        {
          id: 'security_audit',
          label: 'Security & Audit Log',
          icon: History,
        },
        {
          id: 'configuration',
          label: 'System Configuration',
          icon: Sliders,
        },
        {
          id: 'contact_settings',
          label: 'Contact & Support Info',
          icon: Headphones,
        },
        {
          id: 'sla_policies',
          label: 'SLA Policy Engine',
          icon: Clock,
        },
        {
          id: 'reports',
          label: 'Compliance Reports',
          icon: BarChart3,
        },
      ],
    },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-xl bg-[#0f172a] text-cyan-400 flex items-center justify-center shadow-md animate-pulse">
          <Terminal className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold text-[#1e293b] mt-4">Loading IT Department Workspace...</p>
        <p className="text-xs text-[#64748b] mt-1">Connecting to technical governance and system monitors</p>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white border border-red-200 rounded-xl p-6 text-center shadow-xs">
          <div className="w-10 h-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
            <AlertCircle className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-bold text-slate-900 mb-1">Failed to Load IT Workspace</h3>
          <p className="text-xs text-slate-600 mb-4">{loadError}</p>
          <button
            type="button"
            onClick={() => loadInitialData()}
            className="px-4 py-2 bg-[#1e3a8a] text-white text-xs font-semibold rounded-lg hover:bg-[#172e6e] cursor-pointer"
          >
            Retry Loading
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Dedicated IT Department Header */}
      <ItHeader
        user={user}
        onLogout={onLogout}
        onOpenNewTicket={() => setIsNewTicketOpen(true)}
        onOpenPasswordReset={() => setIsPasswordResetOpen(true)}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
      />

      {/* Main Content Layout */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full flex-1">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Consistent Portal Sidebar */}
          <PortalSidebar
            items={sidebarItems}
            activeTab={activeTab}
            onSelectTab={handleSelectTab}
            isOpenMobile={isMobileMenuOpen}
            idPrefix="it-nav"
            footerSlot={
              <div className="mt-4 pt-3 border-t border-slate-200 text-[10px] text-slate-500 font-mono space-y-1">
                <div className="flex justify-between">
                  <span>Office:</span>
                  <span className="font-bold text-slate-700">PO-007</span>
                </div>
                <div className="flex justify-between">
                  <span>Engine:</span>
                  <span className="font-bold text-cyan-700">EIT CAMS Core</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="text-emerald-700 font-bold">Operational</span>
                </div>
              </div>
            }
          />

          {/* Active Navigation Screen */}
          <main className="flex-1 min-w-0">
            {activeTab === 'overview' && (
              <ItOverviewView
                metrics={metrics}
                onNavigateTab={(tab) => handleSelectTab(tab)}
                onOpenPasswordReset={() => setIsPasswordResetOpen(true)}
                onOpenNewTicket={() => setIsNewTicketOpen(true)}
              />
            )}

            {activeTab === 'system_health' && (
              <SystemHealthView
                metrics={itRepository.getSystemHealthMetrics()}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'user_access' && (
              <UserAccessManagementView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                currentEmployeeId={currentEmployeeId}
              />
            )}

            {activeTab === 'password_reset' && (
              <PasswordResetView
                onOpenResetModal={() => setIsPasswordResetOpen(true)}
              />
            )}

            {activeTab === 'id_cards' && (
              <IdCardManagementView
                idCards={idCards}
                onPreviewCard={(card) => setPreviewCard(card)}
                onOpenReissue={(card) => setReissueCard(card)}
              />
            )}

            {activeTab === 'test_accounts' && (
              <TestAccountView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                currentUserName={currentUserName}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'security_audit' && <SecurityAuditView />}

            {activeTab === 'database' && <DatabaseManagementView />}

            {activeTab === 'infrastructure' && (
              <InfrastructureDeploymentView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'configuration' && <SystemConfigurationView />}

            {activeTab === 'integrations' && <ApiIntegrationsView />}

            {activeTab === 'app_monitoring' && <ApplicationMonitoringView />}

            {activeTab === 'tickets' && (
              <ItTicketsView
                tickets={tickets}
                onOpenTicketDetail={(ticket) => setSelectedTicket(ticket)}
                onOpenNewTicket={() => setIsNewTicketOpen(true)}
                isItStaff={true}
              />
            )}

            {activeTab === 'backup' && (
              <BackupRecoveryView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'contact_settings' && (
              <ItContactSettingsView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                currentEmployeeId={currentEmployeeId}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'sla_policies' && (
              <SlaPoliciesView
                currentUserId={currentUserId}
                currentUserRole={currentUserRole}
                onRefresh={refreshLocalState}
              />
            )}

            {activeTab === 'reports' && <ItReportsView />}
          </main>
        </div>
      </div>

      {/* Global IT Modals */}
      <PasswordResetModal
        isOpen={isPasswordResetOpen}
        onClose={() => setIsPasswordResetOpen(false)}
        operatorId={currentUserId}
        operatorName={currentUserName}
        operatorRole={currentUserRole}
        onSuccess={refreshLocalState}
      />

      <NewTicketModal
        isOpen={isNewTicketOpen}
        onClose={() => setIsNewTicketOpen(false)}
        requesterId={currentUserId}
        requesterName={currentUserName}
        requesterAccountType="OFFICE"
        requesterEmail={user.email || 'itoffice@eit.edu'}
        onTicketCreated={refreshLocalState}
      />

      <TicketDetailModal
        isOpen={!!selectedTicket}
        onClose={() => setSelectedTicket(null)}
        ticket={selectedTicket}
        currentUserId={currentUserId}
        currentUserRole={currentUserRole}
        currentUserName={currentUserName}
        isItStaff={true}
        onTicketUpdated={() => {
          refreshLocalState();
          if (selectedTicket) {
            const updated = itRepository.getTicketById(selectedTicket.ticket_id);
            setSelectedTicket(updated ? { ...updated } : null);
          }
        }}
      />

      <IdCardPreviewModal
        isOpen={!!previewCard}
        onClose={() => setPreviewCard(null)}
        card={previewCard}
        onReissue={(card) => {
          setPreviewCard(null);
          setReissueCard(card);
        }}
      />

      <IdCardReissueModal
        isOpen={!!reissueCard}
        onClose={() => setReissueCard(null)}
        card={reissueCard}
        operatorId={currentUserId}
        operatorRole={currentUserRole}
        onSuccess={refreshLocalState}
      />
    </div>
  );
}
