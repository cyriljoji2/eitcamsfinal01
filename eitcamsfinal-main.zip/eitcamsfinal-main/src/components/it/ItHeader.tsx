import React from 'react';
import {
  Terminal,
  LogOut,
  KeyRound,
  LifeBuoy,
  Menu,
  X,
  ShieldCheck,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Button } from '../ui/Button';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface ItHeaderProps {
  user: UserSession;
  onLogout: () => void;
  onOpenNewTicket?: () => void;
  onOpenPasswordReset?: () => void;
  onToggleMobileMenu?: () => void;
  isMobileMenuOpen?: boolean;
}

export function ItHeader({
  user,
  onLogout,
  onOpenNewTicket,
  onOpenPasswordReset,
  onToggleMobileMenu,
  isMobileMenuOpen,
}: ItHeaderProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  const todayStr = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Left: Brand & Office Title */}
          <div className="flex items-center gap-3">
            {onToggleMobileMenu && (
              <button
                type="button"
                onClick={onToggleMobileMenu}
                className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}

            <div className="w-10 h-10 rounded-xl bg-[#0f172a] text-cyan-400 flex items-center justify-center font-black shadow-xs shrink-0">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black text-[#1e293b] tracking-tight">
                  IT Department & Technical Services
                </h1>
                <span className="text-[10px] font-bold bg-cyan-50 text-cyan-800 px-2 py-0.5 rounded-full border border-cyan-200">
                  PO-007
                </span>
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" /> System Active
                </span>
              </div>
              <p className="text-[11px] text-[#64748b] hidden sm:block">
                Electrix Institute of Technology &bull; Academic Session {activeAcademicYear || '2026–2027'} &bull; {todayStr}
              </p>
            </div>
          </div>

          {/* Right: Quick Actions + User Menu */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            {onOpenNewTicket && (
              <Button
                variant="outline"
                size="sm"
                onClick={onOpenNewTicket}
                leftIcon={<LifeBuoy className="w-3.5 h-3.5 text-cyan-600" />}
                className="text-xs hidden sm:flex cursor-pointer"
              >
                Create Ticket
              </Button>
            )}

            {onOpenPasswordReset && (
              <Button
                variant="primary"
                size="sm"
                onClick={onOpenPasswordReset}
                leftIcon={<KeyRound className="w-3.5 h-3.5" />}
                className="text-xs bg-[#1e3a8a] hover:bg-[#172e6e] cursor-pointer"
              >
                Password Reset
              </Button>
            )}

            <div className="h-6 w-px bg-[#e2e8f0] hidden sm:block" />

            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-700 text-cyan-400 flex items-center justify-center font-bold text-xs shrink-0">
                {user.name ? user.name.charAt(0) : 'I'}
              </div>
              <div className="text-left hidden md:block">
                <span className="text-xs font-bold text-[#1e293b] block leading-tight">
                  {user.name || user.username}
                </span>
                <span className="text-[10px] text-[#64748b] font-medium capitalize">
                  {user.roleTitle || 'IT Administrator'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onLogout}
              className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
