import React, { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { CoeWorkspace } from './coe/CoeWorkspace';
import { UserSession } from '../types/auth';

interface CoeOfficeSectionProps {
  onRefreshData?: () => void;
}

export function CoeOfficeSection({ onRefreshData }: CoeOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'Controller of Examinations';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-004',
      username: session?.user?.username || 'coeoffice',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'coeoffice@eit.edu',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'Controller of Examinations',
      department: emp?.primary_department || 'COE',
      portalType: 'employee',
      user: session?.user || {
        user_id: 'USR-PO-004',
        username: 'coeoffice',
        role: session?.role || 'OFFICE_ADMIN',
        display_name: name,
        linked_record_type: 'PERMANENT_OFFICE',
        linked_record_id: 'PO-004',
        account_status: 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
      permanentOffice: session?.permanentOffice || {
        office_id: 'PO-004',
        office_name: 'Controller of Examinations',
        canonical_username: 'coeoffice',
        office_code: 'COE',
        is_system_reserved: true,
        primary_contact_email: 'coeoffice@eit.edu',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    };
  }, [session]);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <CoeWorkspace
      user={userSession}
      onLogout={handleLogout}
      onRefreshData={onRefreshData}
    />
  );
}
