import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  Building2,
  Calendar,
  Award,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  Save,
  Lock,
  Clock,
  Sparkles,
  MapPin,
  GraduationCap,
  CreditCard,
  LifeBuoy,
} from 'lucide-react';
import { EmployeeRecord, FacultyCourseAssignmentRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { itRepository } from '../../services/itService';
import { IdCardRecord } from '../../types/itDepartment';
import { IdCardPreviewModal } from '../it/modals/IdCardPreviewModal';
import { IdCardReissueModal } from '../it/modals/IdCardReissueModal';
import { NewTicketModal } from '../it/modals/NewTicketModal';

interface FacultyProfileViewProps {
  employee: EmployeeRecord | null;
  assignments: FacultyCourseAssignmentRecord[];
  onUpdateProfile?: (updatedData: Partial<EmployeeRecord>) => Promise<void>;
}

export function FacultyProfileView({
  employee,
  assignments,
  onUpdateProfile,
}: FacultyProfileViewProps) {
  const [phoneNumber, setPhoneNumber] = useState(employee?.phone_number || '');
  const [officeHours, setOfficeHours] = useState('Mon - Fri: 14:00 - 16:00 (Room 304, Academic Block A)');
  const [researchInterests, setResearchInterests] = useState(
    'Distributed Systems, High-Performance Computing, Graph Algorithms, Database Query Optimization'
  );
  const [qualifications, setQualifications] = useState(
    'Ph.D. in Computer Science & Engineering (2018), M.Tech. in Software Engineering (2014)'
  );
  const [bio, setBio] = useState(
    'Senior faculty member engaged in undergraduate teaching, algorithm engineering research, and curriculum development.'
  );

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [isPreviewCardOpen, setIsPreviewCardOpen] = useState(false);
  const [isReissueModalOpen, setIsReissueModalOpen] = useState(false);
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);
  const [staffCard, setStaffCard] = useState<IdCardRecord | null>(null);

  const handleViewIdCard = () => {
    if (!employee) return;
    let card =
      itRepository.getIdCardByRegistration(employee.registration_number) ||
      itRepository.getIdCardByHolderId(employee.employee_id);
    if (!card) {
      card = itRepository.generateIdCardForEmployee({
        employee_id: employee.employee_id,
        registration_number: employee.registration_number,
        full_name: `${employee.first_name} ${employee.last_name}`,
        designation: employee.designation,
        department: employee.primary_department,
        category: employee.category,
      });
    }
    setStaffCard(card);
    setIsPreviewCardOpen(true);
  };

  const initials = employee
    ? `${employee.first_name[0] || ''}${employee.last_name[0] || ''}`.toUpperCase()
    : 'FC';

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employee) return;
    setIsSaving(true);
    setSaveSuccess(null);
    setSaveError(null);

    try {
      if (onUpdateProfile) {
        await onUpdateProfile({
          phone_number: phoneNumber.trim(),
        });
      }
      setSaveSuccess('Permitted profile contact information updated successfully.');
      setIsEditing(false);
    } catch (err: any) {
      setSaveError(err?.message || 'Failed to update profile.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Institutional vs Demonstration Notice */}
      <div className="bg-slate-50 border border-slate-200 text-slate-700 px-4 py-3 rounded-2xl text-xs flex items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-[#1e3a8a] shrink-0" />
          <span>
            <strong>Institutional Governance:</strong> Official employment records, department affiliations, and teaching allocations are maintained by Academic & HR Administration. Bio, qualifications, and office hours below represent local faculty showcase fields.
          </span>
        </div>
      </div>

      {/* 1. Header Card */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#1e3a8a] to-[#3b82f6] text-white flex items-center justify-center font-bold text-2xl shadow-sm shrink-0">
              {initials}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-bold text-[#1e293b]">
                  {employee?.first_name} {employee?.last_name}
                </h1>
                <Badge variant="blue">{employee?.registration_number || employee?.employee_id}</Badge>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  {employee?.employment_status || 'ACTIVE'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#64748b] mt-1">
                {employee?.designation} &bull; Department of {employee?.primary_department} &bull; University Teaching Staff
              </p>
              <div className="flex items-center gap-4 text-xs text-slate-500 mt-2 flex-wrap">
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  {employee?.institutional_email}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  {employee?.phone_number}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 sm:justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={handleViewIdCard}
              leftIcon={<CreditCard className="w-3.5 h-3.5 text-cyan-600" />}
              className="text-xs cursor-pointer"
            >
              Digital Staff ID Card
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsTicketModalOpen(true)}
              leftIcon={<LifeBuoy className="w-3.5 h-3.5 text-blue-600" />}
              className="text-xs cursor-pointer"
            >
              IT Support Ticket
            </Button>
            {!isEditing ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="text-xs"
              >
                Edit Details
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditing(false)}
                className="text-xs text-slate-500"
              >
                Cancel
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Notifications */}
      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{saveSuccess}</span>
        </div>
      )}

      {saveError && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{saveError}</span>
        </div>
      )}

      {/* 2. Employment & Institutional Record (Protected vs Permitted) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Protected Official Details */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#f1f5f9]">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#1e3a8a]" />
              <span>Institutional Record (Protected)</span>
            </h3>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              <Lock className="w-3 h-3" />
              Authority: Academic Office
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Registration Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{employee?.registration_number}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Employee System ID:</span>
              <span className="font-mono text-slate-700">{employee?.employee_id}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Primary Department:</span>
              <span className="font-semibold text-slate-900">{employee?.primary_department}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Academic Designation:</span>
              <span className="font-semibold text-slate-900">{employee?.designation}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Employment Status:</span>
              <span className="font-semibold text-emerald-700">{employee?.employment_status}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-50">
              <span className="text-[#64748b]">Official Email:</span>
              <span className="font-mono text-slate-800">{employee?.institutional_email}</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-[#64748b]">Date of Joining:</span>
              <span className="font-medium text-slate-800">{employee?.date_of_joining}</span>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 italic">
            * Official employment and designation records are managed exclusively by the central Administration & Academic Office.
          </p>
        </div>

        {/* Permitted Contact & Faculty Details */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#f1f5f9]">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <User className="w-4 h-4 text-[#1e3a8a]" />
              <span>Contact & Office Hours</span>
            </h3>
            <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Editable by Faculty
            </span>
          </div>

          <form onSubmit={handleSave} className="space-y-3 text-xs">
            <div>
              <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
                Contact Phone Number
              </label>
              {isEditing ? (
                <Input
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="h-8 text-xs"
                />
              ) : (
                <div className="p-2 bg-slate-50 rounded border border-slate-200 font-medium text-slate-900">
                  {phoneNumber || 'Not provided'}
                </div>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
                Office Hours & Cabin Location
              </label>
              {isEditing ? (
                <Input
                  value={officeHours}
                  onChange={(e) => setOfficeHours(e.target.value)}
                  className="h-8 text-xs"
                />
              ) : (
                <div className="p-2 bg-slate-50 rounded border border-slate-200 font-medium text-slate-900">
                  {officeHours}
                </div>
              )}
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
                Faculty Bio
              </label>
              {isEditing ? (
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={2}
                  className="w-full p-2 bg-white rounded border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                />
              ) : (
                <div className="p-2 bg-slate-50 rounded border border-slate-200 text-slate-800 leading-relaxed">
                  {bio}
                </div>
              )}
            </div>

            {isEditing && (
              <div className="pt-2">
                <Button
                  type="submit"
                  size="sm"
                  disabled={isSaving}
                  className="w-full text-xs"
                  leftIcon={<Save className="w-3.5 h-3.5" />}
                >
                  {isSaving ? 'Saving Updates...' : 'Save Profile Details'}
                </Button>
              </div>
            )}
          </form>
        </div>
      </div>

      {/* 3. Academic Workload & Assigned Teaching Summary */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
          <span>Assigned Teaching Workload (Current Term)</span>
        </h3>

        <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Course Code</th>
                <th className="py-2.5 px-3.5 font-semibold">Course Title</th>
                <th className="py-2.5 px-3.5 font-semibold">Dept</th>
                <th className="py-2.5 px-3.5 font-semibold">Semester</th>
                <th className="py-2.5 px-3.5 font-semibold">Section</th>
                <th className="py-2.5 px-3.5 font-semibold">Role</th>
                <th className="py-2.5 px-3.5 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {assignments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-[#94a3b8]">
                    No active teaching assignments allocated by the Academic Office.
                  </td>
                </tr>
              ) : (
                assignments.map((asg) => (
                  <tr key={asg.faculty_assignment_id} className="hover:bg-[#f8fafc]">
                    <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                      {asg.course_code}
                    </td>
                    <td className="py-2.5 px-3.5 font-medium text-[#1e293b]">
                      {asg.course_title}
                    </td>
                    <td className="py-2.5 px-3.5 text-[#64748b]">{asg.department}</td>
                    <td className="py-2.5 px-3.5 text-[#64748b]">Semester {asg.semester}</td>
                    <td className="py-2.5 px-3.5 font-semibold text-slate-800">Section {asg.section}</td>
                    <td className="py-2.5 px-3.5">
                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">
                        {asg.role_in_course}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-right">
                      <Badge variant="emerald">Active</Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. Academic Qualifications & Research Specializations */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
          <span>Qualifications & Research Specializations</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] space-y-1">
            <span className="text-[11px] font-bold text-[#64748b] uppercase">Degrees & Accreditations</span>
            <p className="text-slate-800 font-medium mt-1">{qualifications}</p>
          </div>
          <div className="p-3.5 bg-[#f8fafc] rounded-lg border border-[#e2e8f0] space-y-1">
            <span className="text-[11px] font-bold text-[#64748b] uppercase">Research & Technical Focus</span>
            <p className="text-slate-800 font-medium mt-1">{researchInterests}</p>
          </div>
        </div>
      </div>

      {/* Digital ID Card Preview Modal */}
      <IdCardPreviewModal
        isOpen={isPreviewCardOpen}
        onClose={() => setIsPreviewCardOpen(false)}
        card={staffCard}
        onReissue={(c) => {
          setIsPreviewCardOpen(false);
          setIsReissueModalOpen(true);
        }}
      />

      {/* ID Card Reissue Modal */}
      <IdCardReissueModal
        isOpen={isReissueModalOpen}
        onClose={() => setIsReissueModalOpen(false)}
        card={staffCard}
        operatorId={employee?.employee_id || 'EMP-UNKNOWN'}
        operatorRole="EMPLOYEE"
        onSuccess={() => {
          if (employee) {
            const updated = itRepository.getIdCardByRegistration(employee.registration_number);
            setStaffCard(updated || null);
          }
        }}
      />

      {/* New IT Ticket Modal */}
      <NewTicketModal
        isOpen={isTicketModalOpen}
        onClose={() => setIsTicketModalOpen(false)}
        requesterId={employee?.employee_id || 'EMP-UNKNOWN'}
        requesterName={`${employee?.first_name || ''} ${employee?.last_name || ''}`.trim() || 'Faculty Member'}
        requesterAccountType="EMPLOYEE"
        requesterEmail={employee?.institutional_email || 'faculty@eit.edu'}
        requesterPhone={employee?.phone_number}
        onTicketCreated={() => {
          setIsTicketModalOpen(false);
        }}
      />
    </div>
  );
}
