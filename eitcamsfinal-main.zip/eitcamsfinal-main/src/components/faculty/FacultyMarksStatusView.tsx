import React, { useMemo } from 'react';
import {
  FileCheck2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  RotateCcw,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Calendar,
  Lock,
  Unlock,
  Eye,
} from 'lucide-react';
import {
  ExamLifecycleStatus,
  ExamResultRecord,
  ExamScheduleRecord,
  FacultyCourseAssignmentRecord,
} from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyMarksStatusViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  examSchedules: ExamScheduleRecord[];
  examResults: ExamResultRecord[];
  onSelectScheduleForEntry: (scheduleId: string) => void;
}

export function FacultyMarksStatusView({
  assignments,
  examSchedules,
  examResults,
  onSelectScheduleForEntry,
}: FacultyMarksStatusViewProps) {
  // Assigned course codes
  const assignedCodes = useMemo(
    () => new Set(assignments.map((a) => a.course_code)),
    [assignments]
  );

  const mySchedules = useMemo(() => {
    return examSchedules.filter((s) => assignedCodes.has(s.course_code));
  }, [examSchedules, assignedCodes]);

  // Aggregate stats
  const totalSchedules = mySchedules.length;
  const openCount = mySchedules.filter((s) => s.marks_entry_open).length;
  const submittedCount = mySchedules.filter(
    (s) => s.status === ExamLifecycleStatus.FACULTY_SUBMITTED || s.status === ExamLifecycleStatus.UNDER_COE_REVIEW
  ).length;
  const returnedCount = mySchedules.filter(
    (s) =>
      s.status === ExamLifecycleStatus.REJECTED_FOR_CORRECTION ||
      (s.notes && s.notes.includes('Rejected for correction'))
  ).length;
  const approvedCount = mySchedules.filter(
    (s) =>
      s.status === ExamLifecycleStatus.APPROVED ||
      s.status === ExamLifecycleStatus.PUBLISHED
  ).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-[#1e3a8a]" />
              <span>Marks Submission Status & COE Verification Tracker</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Live lifecycle monitoring of marks submitted to the Controller of Examinations (COE) office.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Moderating Authority:</span>
            <Badge variant="blue">COE Office</Badge>
          </div>
        </div>
      </div>

      {/* Aggregate Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-[#64748b]">Total Schedules</div>
          <div className="text-2xl font-bold text-[#1e293b] mt-1">{totalSchedules}</div>
          <div className="text-[11px] text-slate-500 mt-1">Across assigned courses</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-emerald-700">Open for Entry</div>
          <div className="text-2xl font-bold text-emerald-800 mt-1">{openCount}</div>
          <div className="text-[11px] text-emerald-600 mt-1">Faculty draft window active</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-blue-700">Submitted to COE</div>
          <div className="text-2xl font-bold text-blue-800 mt-1">{submittedCount}</div>
          <div className="text-[11px] text-blue-600 mt-1">Under moderation / review</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-amber-700">Returned for Correction</div>
          <div className="text-2xl font-bold text-amber-800 mt-1">{returnedCount}</div>
          <div className="text-[11px] text-amber-600 mt-1">
            {returnedCount > 0 ? 'Action required by faculty' : 'No revisions required'}
          </div>
        </div>
      </div>

      {/* Actionable Returned Schedules Banner */}
      {returnedCount > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-xl space-y-3">
          <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <span>Action Required: Submissions Returned by COE</span>
          </div>
          <p className="text-xs text-amber-800">
            The following evaluation schedules were returned by the Controller of Examinations with moderation notes.
            Open the schedule to review remarks, adjust student entries, and resubmit for approval.
          </p>

          <div className="space-y-2">
            {mySchedules
              .filter(
                (s) =>
                  s.status === ExamLifecycleStatus.REJECTED_FOR_CORRECTION ||
                  (s.notes && s.notes.includes('Rejected for correction'))
              )
              .map((s) => (
                <div
                  key={s.schedule_id}
                  className="p-3 bg-white border border-amber-200 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="font-bold text-slate-900">
                      {s.course_code}: {s.exam_name} (Section {s.section})
                    </div>
                    <div className="text-amber-800 text-[11px] mt-0.5">
                      <strong>COE Notes:</strong> {s.notes}
                    </div>
                  </div>
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => onSelectScheduleForEntry(s.schedule_id)}
                    className="text-xs h-7.5 bg-amber-700 hover:bg-amber-800 shrink-0"
                    leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
                  >
                    Open & Resubmit
                  </Button>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Master Schedules Tracker Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
        <h3 className="text-sm font-bold text-[#1e293b]">
          All Assigned Examination Evaluation Schedules
        </h3>

        <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Course & Component</th>
                <th className="py-2.5 px-3.5 font-semibold">Section</th>
                <th className="py-2.5 px-3.5 font-semibold">Exam Date</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Window</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">COE Status</th>
                <th className="py-2.5 px-3.5 font-semibold">COE Remarks / Notes</th>
                <th className="py-2.5 px-3.5 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {mySchedules.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#94a3b8]">
                    No examination schedules linked to your course assignments.
                  </td>
                </tr>
              ) : (
                mySchedules.map((s) => {
                  const isReturned =
                    s.status === ExamLifecycleStatus.REJECTED_FOR_CORRECTION ||
                    (s.notes && s.notes.includes('Rejected for correction'));
                  const isSubmitted =
                    s.status === ExamLifecycleStatus.FACULTY_SUBMITTED ||
                    s.status === ExamLifecycleStatus.UNDER_COE_REVIEW;
                  const isApproved =
                    s.status === ExamLifecycleStatus.APPROVED ||
                    s.status === ExamLifecycleStatus.PUBLISHED;

                  return (
                    <tr key={s.schedule_id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3.5">
                        <div className="font-mono font-bold text-[#1e3a8a]">{s.course_code}</div>
                        <div className="font-bold text-[#1e293b]">{s.exam_name}</div>
                      </td>
                      <td className="py-2.5 px-3.5 font-semibold text-slate-800">
                        Section {s.section}
                      </td>
                      <td className="py-2.5 px-3.5 text-[#64748b]">{s.exam_date}</td>
                      <td className="py-2.5 px-3.5 text-center">
                        {s.marks_entry_open ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <Unlock className="w-3 h-3 text-emerald-600" />
                            Open
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            <Lock className="w-3 h-3 text-slate-400" />
                            Closed
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        {isReturned ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                            Returned for Revision
                          </span>
                        ) : isSubmitted ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-800 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                            Under COE Review
                          </span>
                        ) : isApproved ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            Approved & Verified
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            Draft Pending
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 text-[11px] max-w-xs truncate" title={s.notes}>
                        {s.notes || '—'}
                      </td>
                      <td className="py-2.5 px-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSelectScheduleForEntry(s.schedule_id)}
                          className="h-7 text-xs"
                          leftIcon={<Eye className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                        >
                          {s.marks_entry_open ? 'Enter Marks' : 'View Entries'}
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
