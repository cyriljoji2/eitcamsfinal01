import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Plus,
  Clock,
  User,
  FlaskConical,
  Check,
  X,
  AlertTriangle,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface LabClearanceRequest {
  id: string;
  studentName: string;
  regNumber: string;
  degree: string;
  labName: string;
  requestedDates: string;
  timeSlot: string;
  purpose: string;
  safetyBriefingCompleted: boolean;
  status: 'PENDING_FACULTY_ENDORSEMENT' | 'ENDORSED' | 'REJECTED';
}

export function FacultyLabAccessView() {
  const [requests, setRequests] = useState<LabClearanceRequest[]>([
    {
      id: 'LAB-REQ-2026-018',
      studentName: 'Arjun Kumar',
      regNumber: 'EIT-STU-2026-CSE-0001',
      degree: 'B.Tech CSE (Final Year Major Project)',
      labName: 'High Performance Computing & Cloud Lab (Room 102)',
      requestedDates: '2026-11-05 to 2026-11-20',
      timeSlot: '06:00 PM – 10:00 PM (After-Hours)',
      purpose: 'Distributed graph neural network training runs requiring dedicated GPU server nodes.',
      safetyBriefingCompleted: true,
      status: 'PENDING_FACULTY_ENDORSEMENT',
    },
    {
      id: 'LAB-REQ-2026-014',
      studentName: 'Kavya Raman',
      regNumber: 'EIT-STU-2025-CSE-0042',
      degree: 'M.Tech CSE (Thesis Research)',
      labName: 'IoT & Embedded Security Lab (Room 208)',
      requestedDates: '2026-10-20 to 2026-11-10',
      timeSlot: '07:00 PM – 11:00 PM (Night Access)',
      purpose: 'Hardware-in-the-loop power analysis on FPGA evaluation boards.',
      safetyBriefingCompleted: true,
      status: 'ENDORSED',
    },
  ]);

  const [selectedReq, setSelectedReq] = useState<LabClearanceRequest | null>(null);

  const handleEndorse = (decision: 'ENDORSED' | 'REJECTED') => {
    if (!selectedReq) return;
    setRequests(
      requests.map((r) => (r.id === selectedReq.id ? { ...r, status: decision } : r))
    );
    setSelectedReq(null);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Laboratory After-Hours Access Clearances</h2>
            <Badge variant="blue">Faculty PI Endorsement Desk</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative faculty supervisor endorsement for student research scholars requesting after-hours laboratory access.
          </p>
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {requests.map((req) => (
          <div
            key={req.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {req.id}
                  </span>
                  <Badge
                    variant={
                      req.status === 'ENDORSED'
                        ? 'emerald'
                        : req.status === 'PENDING_FACULTY_ENDORSEMENT'
                        ? 'amber'
                        : 'default'
                    }
                  >
                    {req.status === 'PENDING_FACULTY_ENDORSEMENT' ? 'Pending Your Endorsement' : req.status}
                  </Badge>
                  {req.safetyBriefingCompleted && (
                    <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      Safety Induction Verified
                    </span>
                  )}
                </div>

                <h3 className="text-sm font-bold text-[#1e293b] pt-1">
                  {req.studentName}{' '}
                  <span className="font-mono text-xs font-normal text-slate-500">
                    ({req.regNumber})
                  </span>
                </h3>

                <div className="text-xs text-[#64748b]">
                  Facility: <strong className="text-slate-800">{req.labName}</strong> &bull; {req.degree}
                </div>

                <p className="text-xs text-slate-600 leading-relaxed pt-1">
                  Project Justification: <em>"{req.purpose}"</em>
                </p>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Requested Window</div>
                <div className="text-xs font-bold text-slate-800">{req.timeSlot}</div>
                <div className="text-[11px] text-slate-500 font-mono mt-0.5">{req.requestedDates}</div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-1.5 text-slate-600">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Requires Faculty PI Signature & Campus Chief Security Officer Approval</span>
              </div>

              {req.status === 'PENDING_FACULTY_ENDORSEMENT' && (
                <div className="flex items-center gap-2">
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => setSelectedReq(req)}
                    className="h-7 text-xs bg-emerald-700 hover:bg-emerald-800 text-white"
                    leftIcon={<Check className="w-3.5 h-3.5" />}
                  >
                    Review & Sign
                  </Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Endorsement Modal */}
      {selectedReq && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Endorse Laboratory After-Hours Pass</h3>
            <div className="text-xs text-[#64748b] space-y-1">
              <div>Student: <strong>{selectedReq.studentName}</strong> ({selectedReq.regNumber})</div>
              <div>Laboratory: <strong>{selectedReq.labName}</strong></div>
              <div>Access Window: <strong>{selectedReq.timeSlot}</strong></div>
              <div>Duration: <strong>{selectedReq.requestedDates}</strong></div>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                By digitally endorsing this pass, you certify that the student researcher has undertaken mandatory safety training and that the proposed work aligns with institutional academic research.
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="ghost" size="sm" onClick={() => setSelectedReq(null)}>
                Cancel
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleEndorse('REJECTED')}
                className="text-rose-700 border-rose-200 hover:bg-rose-50"
              >
                Reject Request
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => handleEndorse('ENDORSED')}
                className="bg-emerald-700 hover:bg-emerald-800 text-white"
              >
                Sign & Endorse Pass
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
