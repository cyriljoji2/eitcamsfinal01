import React, { useState, useMemo } from 'react';
import {
  Users,
  ShieldCheck,
  Search,
  Eye,
  AlertTriangle,
  CheckCircle2,
  Phone,
  Mail,
  GraduationCap,
} from 'lucide-react';
import { ProctorAssignment } from '../../types/proctor';
import { StudentRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyMenteesViewProps {
  assignments: ProctorAssignment[];
  students: StudentRecord[];
  onOpenStudentProfile: (regNo: string) => void;
  onNavigateToProctorDesk: () => void;
}

export function FacultyMenteesView({
  assignments,
  students,
  onOpenStudentProfile,
  onNavigateToProctorDesk,
}: FacultyMenteesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'ALL' | 'ATTENTION' | 'GOOD'>('ALL');

  const menteeList = useMemo(() => {
    return assignments.map((asg) => {
      const student = students.find(
        (s) => s.student_id === asg.studentId || s.registration_number === asg.studentRegistrationNumber
      );

      // Deterministic mock attendance and CGPA for mentee tracking
      const regHash = (asg.studentRegistrationNumber || '').split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
      const attendancePct = 70 + (regHash % 28); // 70% to 97%
      const cgpa = (7.0 + (regHash % 25) / 10).toFixed(2);
      const isRisk = attendancePct < 75 || Number(cgpa) < 7.5;

      return {
        assignment: asg,
        student,
        attendancePct,
        cgpa,
        isRisk,
      };
    });
  }, [assignments, students]);

  const filteredMentees = useMemo(() => {
    return menteeList.filter((m) => {
      if (riskFilter === 'ATTENTION' && !m.isRisk) return false;
      if (riskFilter === 'GOOD' && m.isRisk) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const studentFullName = m.student ? `${m.student.first_name} ${m.student.last_name}` : (m.assignment.studentName || '');
        const name = studentFullName.toLowerCase();
        const reg = (m.assignment.studentRegistrationNumber || m.student?.registration_number || '').toLowerCase();
        if (!name.includes(q) && !reg.includes(q)) return false;
      }
      return true;
    });
  }, [menteeList, riskFilter, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Student Mentee Roster & Portfolio</h2>
            <Badge variant="emerald">{assignments.length} Assigned Mentees</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Official proctee cohort allocated exclusively by the Academic Office. Continuous academic and pastoral mentorship tracking.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onNavigateToProctorDesk}
          leftIcon={<ShieldCheck className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-emerald-700 hover:bg-emerald-800 text-white"
        >
          Open Proctor Mentorship Desk
        </Button>
      </div>

      {/* Quick Filter Bar */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 max-w-md">
          <input
            type="text"
            placeholder="Search mentee name or registration number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setRiskFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
              riskFilter === 'ALL' ? 'bg-[#1e3a8a] text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Mentees ({menteeList.length})
          </button>
          <button
            onClick={() => setRiskFilter('ATTENTION')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
              riskFilter === 'ATTENTION' ? 'bg-amber-600 text-white' : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
            }`}
          >
            Needs Attention ({menteeList.filter((m) => m.isRisk).length})
          </button>
        </div>
      </div>

      {/* Mentees Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4 font-semibold">Reg Number</th>
                <th className="py-3 px-4 font-semibold">Student Name</th>
                <th className="py-3 px-4 font-semibold">Department & Year</th>
                <th className="py-3 px-4 font-semibold">Academic Standing</th>
                <th className="py-3 px-4 font-semibold">Attendance</th>
                <th className="py-3 px-4 font-semibold">Mentorship Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredMentees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#94a3b8]">
                    <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    No mentees found matching your criteria.
                  </td>
                </tr>
              ) : (
                filteredMentees.map((m) => (
                  <tr key={m.assignment.id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                      {m.assignment.studentRegistrationNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">
                        {m.student ? `${m.student.first_name} ${m.student.last_name}` : m.assignment.studentName}
                      </div>
                      <div className="text-[11px] text-[#64748b]">
                        Allocated: {m.assignment.academicYear}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="blue">{m.student?.department || 'CSE'}</Badge>
                      <span className="ml-1.5 text-[#64748b]">Sem {m.student?.current_semester || 3}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-800">CGPA: {m.cgpa}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`font-semibold ${
                          m.attendancePct < 75 ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {m.attendancePct}%
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {m.isRisk ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Advisement Required</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Good Standing</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onOpenStudentProfile(m.assignment.studentRegistrationNumber || m.student?.registration_number || '')}
                        leftIcon={<Eye className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                        className="h-7 text-xs"
                      >
                        Profile
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
