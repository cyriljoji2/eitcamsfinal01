import React, { useState } from 'react';
import {
  ShieldCheck,
  KeyRound,
  Laptop,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Clock,
  Lock,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

export function FacultySecuritySettingsView() {
  const [currentPwd, setCurrentPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const activeSessions = [
    {
      id: 'SESS-01',
      device: 'MacBook Pro 16" — Chrome 130',
      ip: '14.139.182.42 (EIT Campus High-Speed Gateway)',
      location: 'Chennai, India',
      status: 'Current Active Session',
      isCurrent: true,
      lastActive: 'Just now',
    },
    {
      id: 'SESS-02',
      device: 'Apple iPhone 15 Pro — Mobile Safari',
      ip: '14.139.182.98 (EIT-Faculty-Secure Wi-Fi)',
      location: 'Chennai, India',
      status: 'Active (Background Push)',
      isCurrent: false,
      lastActive: '2 hours ago',
    },
  ];

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPwd) {
      setStatusMsg({ type: 'error', text: 'Current password is required.' });
      return;
    }
    if (newPwd.length < 8) {
      setStatusMsg({ type: 'error', text: 'New password must be at least 8 characters long.' });
      return;
    }
    if (newPwd !== confirmPwd) {
      setStatusMsg({ type: 'error', text: 'New password and confirmation do not match.' });
      return;
    }

    setStatusMsg({
      type: 'success',
      text: 'Institutional password updated successfully. All active sessions preserved.',
    });
    setCurrentPwd('');
    setNewPwd('');
    setConfirmPwd('');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Account Credentials & Institutional Security</h2>
            <Badge variant="emerald">Enterprise Identity Protected</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Manage your single-sign-on (SSO) authentication password, active devices, and institutional 2FA verification.
          </p>
        </div>
      </div>

      {statusMsg && (
        <div
          className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border border-rose-200 text-rose-800'
          }`}
        >
          {statusMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {/* Password Reset Section */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-[#1e3a8a]" />
          <span>Change Faculty Portal Password</span>
        </h3>

        <form onSubmit={handleUpdatePassword} className="space-y-3 max-w-md">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Current Password</label>
            <Input
              type="password"
              required
              placeholder="••••••••••••"
              value={currentPwd}
              onChange={(e) => setCurrentPwd(e.target.value)}
              className="text-xs"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">New Password (Min. 8 characters)</label>
            <Input
              type="password"
              required
              placeholder="••••••••••••"
              value={newPwd}
              onChange={(e) => setNewPwd(e.target.value)}
              className="text-xs"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Confirm New Password</label>
            <Input
              type="password"
              required
              placeholder="••••••••••••"
              value={confirmPwd}
              onChange={(e) => setConfirmPwd(e.target.value)}
              className="text-xs"
            />
          </div>

          <div className="pt-2">
            <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
              Update Password
            </Button>
          </div>
        </form>
      </div>

      {/* Two-Factor Authentication Status */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-[#1e293b]">Institutional Two-Factor Authentication (2FA)</h3>
          </div>
          <Badge variant="emerald">Enforced</Badge>
        </div>
        <p className="text-xs text-[#64748b]">
          Two-Factor Authentication is enforced across all faculty and teaching staff accounts via institutional Google Workspace / Microsoft Authenticator.
        </p>
      </div>

      {/* Active Device Sessions */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <Laptop className="w-4 h-4 text-[#1e3a8a]" />
          <span>Active Device Sessions & Access History</span>
        </h3>

        <div className="space-y-3">
          {activeSessions.map((s) => (
            <div
              key={s.id}
              className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-[#1e293b]">{s.device}</span>
                  {s.isCurrent && <Badge variant="emerald">This Device</Badge>}
                </div>
                <div className="text-xs text-[#64748b]">{s.ip} &bull; {s.location}</div>
              </div>

              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Last active: {s.lastActive}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
