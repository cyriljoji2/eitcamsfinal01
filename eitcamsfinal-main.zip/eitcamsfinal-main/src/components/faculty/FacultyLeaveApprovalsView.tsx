import React, { useState, useEffect, useCallback } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Phone,
  AlertCircle,
  Check,
  X,
  ShieldCheck,
  Filter,
} from 'lucide-react';
import { proctorRepository } from '../../services/proctorService';
import { LeaveOutingRequest } from '../../types/proctor';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyLeaveApprovalsViewProps {
  facultyId: string;
  actor: { userId: string; role: string; employeeId?: string };
}

export function FacultyLeaveApprovalsView({
  facultyId,
  actor,
}: FacultyLeaveApprovalsViewProps) {
  const [requests, setRequests] = useState<LeaveOutingRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [selectedReq, setSelectedReq] = useState<LeaveOutingRequest | null>(null);
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const loadRequests = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await proctorRepository.getRequestsForProctor(facultyId, actor);
      setRequests(data);
    } catch (err: any) {
      console.error('Failed to load proctor leave requests:', err);
    } finally {
      setIsLoading(false);
    }
  }, [facultyId, actor]);

  useEffect(() => {
    loadRequests();
    const unsub = proctorRepository.subscribe(() => {
      loadRequests();
    });
    return unsub;
  }, [loadRequests]);

  const handleEndorse = async (decision: 'approve' | 'reject') => {
    if (!selectedReq) return;
    if (decision === 'reject' && !remarks.trim()) {
      setActionError('A mandatory rejection reason is required for institutional audit.');
      return;
    }

    setIsSubmitting(true);
    setActionError(null);
    try {
      const finalRemark = remarks.trim() || (decision === 'approve' ? 'Approved by Proctor upon parental verification.' : 'Rejected.');
      await proctorRepository.endorseLeaveOutingRequest(selectedReq.id, facultyId, decision, finalRemark, actor);
      setActionSuccess(`Request ${selectedReq.id} has been formally ${decision === 'approve' ? 'APPROVED' : 'REJECTED'}.`);
      setSelectedReq(null);
      setRemarks('');
      await loadRequests();
    } catch (err: any) {
      setActionError(err?.message || 'Failed to endorse leave request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredRequests = requests.filter((r) => {
    if (statusFilter !== 'ALL' && r.approvalStatus !== statusFilter) return false;
    return true;
  });

  const pendingCount = requests.filter((r) => r.approvalStatus === 'PENDING').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Mentee Leave & Campus Outing Endorsements</h2>
            {pendingCount > 0 ? (
              <Badge variant="amber">{pendingCount} Pending Decision</Badge>
            ) : (
              <Badge variant="emerald">All Reviewed</Badge>
            )}
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative faculty proctor clearance for hostel leave, emergency transit, and city outing passes.
          </p>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{actionSuccess}</span>
          </div>
          <button onClick={() => setActionSuccess(null)} className="text-emerald-600 hover:text-emerald-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setStatusFilter('ALL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
            statusFilter === 'ALL' ? 'bg-[#1e3a8a] text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          All Requests ({requests.length})
        </button>
        <button
          onClick={() => setStatusFilter('PENDING')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
            statusFilter === 'PENDING' ? 'bg-amber-600 text-white' : 'bg-white border border-slate-200 text-amber-700 hover:bg-amber-50'
          }`}
        >
          Pending Review ({pendingCount})
        </button>
        <button
          onClick={() => setStatusFilter('APPROVED')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
            statusFilter === 'APPROVED' ? 'bg-emerald-700 text-white' : 'bg-white border border-slate-200 text-emerald-700 hover:bg-emerald-50'
          }`}
        >
          Approved ({requests.filter((r) => r.approvalStatus === 'APPROVED').length})
        </button>
        <button
          onClick={() => setStatusFilter('REJECTED')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
            statusFilter === 'REJECTED' ? 'bg-rose-600 text-white' : 'bg-white border border-slate-200 text-rose-700 hover:bg-rose-50'
          }`}
        >
          Rejected ({requests.filter((r) => r.approvalStatus === 'REJECTED').length})
        </button>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="bg-white border border-[#e2e8f0] p-12 rounded-xl text-center text-xs text-slate-400">
            Loading leave and outing requests...
          </div>
        ) : filteredRequests.length === 0 ? (
          <div className="bg-white border border-[#e2e8f0] p-12 rounded-xl text-center text-xs text-slate-400">
            <CalendarCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            No leave or outing requests found in this category.
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                      {req.id}
                    </span>
                    <Badge
                      variant={
                        req.approvalStatus === 'APPROVED'
                          ? 'emerald'
                          : req.approvalStatus === 'PENDING'
                          ? 'amber'
                          : 'default'
                      }
                    >
                      {req.approvalStatus}
                    </Badge>
                    <span className="text-xs font-semibold text-slate-700 uppercase bg-slate-100 px-2 py-0.5 rounded">
                      {req.requestType}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-[#1e293b] pt-1">
                    {req.studentName}{' '}
                    <span className="font-mono text-xs font-normal text-slate-500">
                      ({req.studentRegistrationNumber})
                    </span>
                  </h3>

                  <div className="text-xs text-[#64748b]">
                    Hostel: <strong>{req.blockName} &bull; Room {req.roomNumber}</strong> &bull; Reason: <em>"{req.reason}"</em>
                  </div>
                </div>

                <div className="sm:text-right shrink-0">
                  <div className="text-[10px] text-[#64748b] uppercase">Travel Schedule</div>
                  <div className="text-xs font-bold text-slate-800">
                    {req.fromDate} ({req.fromTime}) &rarr; {req.toDate} ({req.toTime})
                  </div>
                  <div className="text-[11px] text-slate-500">Destination: {req.destination}</div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-[#64748b]">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>Emergency Phone: {req.emergencyContact || req.contactNumber}</span>
                  </div>
                  {req.proctorRemarks && (
                    <div className="text-emerald-700 font-medium">
                      Proctor Remark: <em>"{req.proctorRemarks}"</em>
                    </div>
                  )}
                </div>

                {req.approvalStatus === 'PENDING' && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="primary"
                      size="sm"
                      onClick={() => setSelectedReq(req)}
                      className="h-7 text-xs bg-emerald-700 hover:bg-emerald-800 text-white"
                      leftIcon={<Check className="w-3.5 h-3.5" />}
                    >
                      Review & Endorse
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Review Modal */}
      {selectedReq && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Endorse Mentee Leave Request</h3>
            <div className="text-xs text-[#64748b] space-y-1">
              <div>Student: <strong>{selectedReq.studentName}</strong> ({selectedReq.studentRegistrationNumber})</div>
              <div>Destination: <strong>{selectedReq.destination}</strong></div>
              <div>Duration: <strong>{selectedReq.fromDate} to {selectedReq.toDate}</strong></div>
              <div>Parent/Emergency Phone: <strong>{selectedReq.emergencyContact}</strong></div>
            </div>

            {actionError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{actionError}</span>
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Proctor Advisement & Parental Verification Remarks:
              </label>
              <textarea
                rows={3}
                placeholder="e.g., Confirmed with parents over phone; student academic performance in good standing."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button variant="ghost" size="sm" onClick={() => setSelectedReq(null)} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleEndorse('reject')}
                disabled={isSubmitting}
                className="text-rose-700 border-rose-200 hover:bg-rose-50"
              >
                Reject Request
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => handleEndorse('approve')}
                disabled={isSubmitting}
                className="bg-emerald-700 hover:bg-emerald-800 text-white"
              >
                Approve & Sign
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
