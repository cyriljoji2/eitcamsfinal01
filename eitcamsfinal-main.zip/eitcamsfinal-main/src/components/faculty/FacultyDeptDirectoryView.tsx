import React, { useState } from 'react';
import {
  Building2,
  Phone,
  Mail,
  Search,
  MapPin,
  Clock,
  UserCheck,
} from 'lucide-react';
import { Badge } from '../ui/Badge';

export function FacultyDeptDirectoryView() {
  const [searchQuery, setSearchQuery] = useState('');

  const contacts = [
    {
      unit: 'Head of Department (HoD Office)',
      name: 'Dr. Arvind Sharma',
      designation: 'HoD & Professor',
      intercom: 'Ext. 4101',
      directPhone: '+91 44 2257 4101',
      email: 'hod.cse@eit.edu',
      location: 'Academic Block 3, 4th Floor, Room 401',
      hours: '09:00 AM – 05:30 PM',
    },
    {
      unit: 'Department Administrative Office',
      name: 'Mr. P. Murugan',
      designation: 'Senior Administrative Officer',
      intercom: 'Ext. 4102',
      directPhone: '+91 44 2257 4102',
      email: 'dept.cse@eit.edu',
      location: 'Academic Block 3, Room 402',
      hours: '08:30 AM – 05:00 PM',
    },
    {
      unit: 'High Performance Computing Lab',
      name: 'Mr. Rajesh K.',
      designation: 'Senior Systems Engineer',
      intercom: 'Ext. 4150',
      directPhone: '+91 44 2257 4150',
      email: 'hpc.lab@eit.edu',
      location: 'Computing Centre, Ground Floor',
      hours: '08:00 AM – 08:00 PM',
    },
    {
      unit: 'Systems & Networking Lab',
      name: 'Ms. S. Meenakshi',
      designation: 'Technical Superintendent',
      intercom: 'Ext. 4152',
      directPhone: '+91 44 2257 4152',
      email: 'netlab.cse@eit.edu',
      location: 'Academic Block 3, Room 210',
      hours: '08:30 AM – 05:30 PM',
    },
    {
      unit: 'Undergraduate Academic Coordinator',
      name: 'Dr. Ramesh Sundaram',
      designation: 'Associate Professor',
      intercom: 'Ext. 4120',
      directPhone: '+91 44 2257 4120',
      email: 'ug.cse@eit.edu',
      location: 'Academic Block 3, Room 415',
      hours: '11:00 AM – 01:00 PM (Office Hours)',
    },
    {
      unit: 'Postgraduate & Research Coordinator',
      name: 'Dr. Priya Balasubramanian',
      designation: 'Professor',
      intercom: 'Ext. 4125',
      directPhone: '+91 44 2257 4125',
      email: 'pg.cse@eit.edu',
      location: 'Academic Block 3, Room 418',
      hours: '02:00 PM – 04:00 PM (Office Hours)',
    },
  ];

  const filteredContacts = contacts.filter((c) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.unit.toLowerCase().includes(q) ||
      c.name.toLowerCase().includes(q) ||
      c.intercom.toLowerCase().includes(q) ||
      c.location.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Department Directory & Intercom Extensions</h2>
            <Badge variant="blue">CSE Department</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional directory of departmental laboratories, technical support staff, and administrative desks.
          </p>
        </div>
      </div>

      {/* Search Input */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by desk, staff name, intercom extension, or lab room..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:bg-white"
          />
        </div>
      </div>

      {/* Directory Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredContacts.map((c, i) => (
          <div
            key={i}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                  {c.intercom}
                </span>
                <h3 className="text-sm font-bold text-[#1e293b] mt-1.5">{c.unit}</h3>
                <div className="text-xs font-medium text-slate-700">{c.name} &bull; <span className="text-slate-500">{c.designation}</span></div>
              </div>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-[#64748b]">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                <span className="font-mono">{c.directPhone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span>{c.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{c.location}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-500">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Working Hours: {c.hours}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
