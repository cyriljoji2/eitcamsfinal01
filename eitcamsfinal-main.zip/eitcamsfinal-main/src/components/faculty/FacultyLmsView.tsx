import React, { useState } from 'react';
import {
  BookOpen,
  FileText,
  UploadCloud,
  Download,
  FolderPlus,
  ExternalLink,
  CheckCircle2,
  Plus,
} from 'lucide-react';
import { FacultyCourseAssignmentRecord } from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface FacultyLmsViewProps {
  assignments: FacultyCourseAssignmentRecord[];
}

interface CourseMaterial {
  id: string;
  course_code: string;
  title: string;
  module_number: number;
  type: 'lecture_notes' | 'syllabus' | 'lab_manual' | 'assignment';
  file_name: string;
  file_size: string;
  uploaded_at: string;
}

export function FacultyLmsView({ assignments }: FacultyLmsViewProps) {
  const [selectedCourse, setSelectedCourse] = useState(assignments[0]?.course_code || 'CS201');
  const [materials, setMaterials] = useState<CourseMaterial[]>([
    {
      id: 'MAT-001',
      course_code: 'CS201',
      title: 'Module 1: Asymptotic Analysis and Recurrence Relations',
      module_number: 1,
      type: 'lecture_notes',
      file_name: 'CS201_Module1_Analysis.pdf',
      file_size: '2.4 MB',
      uploaded_at: '2026-08-10',
    },
    {
      id: 'MAT-002',
      course_code: 'CS201',
      title: 'Official Approved Course Syllabus & Outcome Mapping (2026-27)',
      module_number: 0,
      type: 'syllabus',
      file_name: 'CS201_Approved_Syllabus.pdf',
      file_size: '640 KB',
      uploaded_at: '2026-08-01',
    },
    {
      id: 'MAT-003',
      course_code: 'CS201',
      title: 'Data Structures Laboratory Manual & Problem Statements',
      module_number: 1,
      type: 'lab_manual',
      file_name: 'CS201_Lab_Manual_v2.pdf',
      file_size: '4.1 MB',
      uploaded_at: '2026-08-12',
    },
  ]);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<CourseMaterial['type']>('lecture_notes');
  const [newModule, setNewModule] = useState(1);

  const handleAddMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newMat: CourseMaterial = {
      id: `MAT-${Date.now()}`,
      course_code: selectedCourse,
      title: newTitle.trim(),
      module_number: newModule,
      type: newType,
      file_name: `${selectedCourse}_Module${newModule}_Doc.pdf`,
      file_size: '1.8 MB',
      uploaded_at: new Date().toISOString().split('T')[0],
    };

    setMaterials([newMat, ...materials]);
    setNewTitle('');
    setIsAddOpen(false);
  };

  const [notice, setNotice] = useState<string | null>(null);

  const filteredMaterials = materials.filter((m) => m.course_code === selectedCourse);

  const handleDownload = (fileName: string) => {
    setNotice(`Initiating download for course resource '${fileName}'...`);
    setTimeout(() => setNotice(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Demonstration Banner */}
      <div className="bg-blue-50 border border-blue-200 text-blue-900 px-4 py-3 rounded-2xl text-xs flex items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2.5">
          <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
          <span>
            <strong>Demonstration Learning Materials:</strong> Course syllabus, lecture notes, and lab manuals are stored in the local development session cache. Authoritative course offerings and faculty assignments are governed by the Academic Office.
          </span>
        </div>
      </div>

      {notice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-2.5 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#1e3a8a]" />
              <span>Course Materials & LMS Distribution</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Upload and manage course lecture notes, laboratory manuals, and problem sets.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
              className="h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
            >
              {assignments.map((asg) => (
                <option key={asg.faculty_assignment_id} value={asg.course_code}>
                  {asg.course_code} - {asg.course_title}
                </option>
              ))}
            </select>

            <Button
              variant="primary"
              size="sm"
              onClick={() => setIsAddOpen(true)}
              className="text-xs"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
            >
              Upload Material
            </Button>
          </div>
        </div>
      </div>

      {/* Materials List */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden p-5 space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b]">
          Published Materials for {selectedCourse}
        </h3>

        <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Title & Module</th>
                <th className="py-2.5 px-3.5 font-semibold">Category</th>
                <th className="py-2.5 px-3.5 font-semibold">File Details</th>
                <th className="py-2.5 px-3.5 font-semibold">Uploaded Date</th>
                <th className="py-2.5 px-3.5 font-semibold text-right">Access</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredMaterials.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-[#94a3b8]">
                    No learning materials uploaded for this course yet.
                  </td>
                </tr>
              ) : (
                filteredMaterials.map((item) => (
                  <tr key={item.id} className="hover:bg-[#f8fafc]">
                    <td className="py-2.5 px-3.5">
                      <div className="font-bold text-[#1e293b]">{item.title}</div>
                      <div className="text-[11px] text-slate-500">
                        Module {item.module_number === 0 ? 'General' : item.module_number}
                      </div>
                    </td>
                    <td className="py-2.5 px-3.5">
                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-50 text-blue-800 border border-blue-200 uppercase">
                        {item.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 font-mono text-[11px] text-slate-600">
                      {item.file_name} ({item.file_size})
                    </td>
                    <td className="py-2.5 px-3.5 text-slate-500">{item.uploaded_at}</td>
                    <td className="py-2.5 px-3.5 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDownload(item.file_name)}
                        className="h-7 text-xs"
                        leftIcon={<Download className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                      >
                        Download
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-[#1e293b]">Upload Course Material</h3>
            <form onSubmit={handleAddMaterial} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Material Title</label>
                <Input
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Module 2: Binary Search Trees & AVL..."
                  className="h-8 text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">Category</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                  >
                    <option value="lecture_notes">Lecture Notes</option>
                    <option value="syllabus">Syllabus</option>
                    <option value="lab_manual">Lab Manual</option>
                    <option value="assignment">Assignment Sheet</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">Module Number</label>
                  <Input
                    type="number"
                    min={0}
                    max={10}
                    value={newModule}
                    onChange={(e) => setNewModule(Number(e.target.value))}
                    className="h-8.5 text-xs"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-500">
                <UploadCloud className="w-6 h-6 text-[#1e3a8a] mx-auto mb-1" />
                <span className="text-[11px]">Select PDF, DOCX, or PPTX file to distribute</span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsAddOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs">
                  Upload & Distribute
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
