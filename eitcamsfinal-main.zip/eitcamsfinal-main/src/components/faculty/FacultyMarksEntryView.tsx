import React, { useState, useEffect, useMemo } from 'react';
import {
  Lock,
  Unlock,
  Save,
  Send,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  RotateCcw,
  BookOpen,
  Calendar,
  Clock,
  User,
  Search,
  Filter,
  ShieldAlert,
  Info,
  GraduationCap,
} from 'lucide-react';
import {
  ExamAttendanceStatus,
  ExamLifecycleStatus,
  ExamResultRecord,
  ExamScheduleRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
  StudentEligibilityDetail,
} from '../../types/database';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface FacultyMarksEntryViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  examSchedules: ExamScheduleRecord[];
  students: StudentRecord[];
  facultyId: string;
  facultyName: string;
  onGetMarks: (scheduleId: string) => Promise<ExamResultRecord[]>;
  onCheckEligibility?: (scheduleId: string) => Promise<StudentEligibilityDetail[]>;
  onSaveDraftMarks: (
    scheduleId: string,
    entries: {
      student_id: string;
      internal_marks?: number;
      external_marks?: number;
      submission_notes?: string;
    }[]
  ) => Promise<ExamResultRecord[]>;
  onSubmitMarksForReview: (scheduleId: string, notes?: string) => Promise<{ updatedCount: number; incompleteCount: number }>;
  onRefreshData?: () => Promise<void>;
}

export function FacultyMarksEntryView({
  assignments,
  examSchedules,
  students,
  facultyId,
  facultyName,
  onGetMarks,
  onCheckEligibility,
  onSaveDraftMarks,
  onSubmitMarksForReview,
  onRefreshData,
}: FacultyMarksEntryViewProps) {
  // Assigned courses filter for exam schedules
  const assignedCourseCodes = useMemo(
    () => new Set(assignments.map((a) => a.course_code)),
    [assignments]
  );

  const eligibleSchedules = useMemo(() => {
    return examSchedules.filter((s) => assignedCourseCodes.has(s.course_code));
  }, [examSchedules, assignedCourseCodes]);

  const [selectedScheduleId, setSelectedScheduleId] = useState<string>(
    eligibleSchedules[0]?.schedule_id || ''
  );

  const [marks, setMarks] = useState<ExamResultRecord[]>([]);
  const [eligibilityList, setEligibilityList] = useState<StudentEligibilityDetail[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionNotes, setSubmissionNotes] = useState('');
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | 'warning';
    text: string;
  } | null>(null);

  const [searchStudent, setSearchStudent] = useState('');

  const activeSchedule = useMemo(() => {
    return examSchedules.find((s) => s.schedule_id === selectedScheduleId);
  }, [examSchedules, selectedScheduleId]);

  // Window states
  const isWindowOpen = Boolean(activeSchedule?.marks_entry_open);
  const isSubmitted = activeSchedule?.status === ExamLifecycleStatus.FACULTY_SUBMITTED;
  const isUnderReview = activeSchedule?.status === ExamLifecycleStatus.UNDER_COE_REVIEW;
  const isApproved = activeSchedule?.status === ExamLifecycleStatus.APPROVED;
  const isPublished = activeSchedule?.status === ExamLifecycleStatus.PUBLISHED;
  const isReturned =
    activeSchedule?.status === ExamLifecycleStatus.REJECTED_FOR_CORRECTION ||
    Boolean(activeSchedule?.notes?.includes('Rejected for correction'));

  // Load marks and eligibility when schedule changes
  useEffect(() => {
    if (!selectedScheduleId) {
      setMarks([]);
      return;
    }

    let isMounted = true;
    const loadScheduleData = async () => {
      setIsLoading(true);
      setStatusMessage(null);
      try {
        const [resultsData, eligData] = await Promise.all([
          onGetMarks(selectedScheduleId),
          onCheckEligibility ? onCheckEligibility(selectedScheduleId) : Promise.resolve([]),
        ]);
        if (isMounted) {
          setMarks(resultsData || []);
          setEligibilityList(eligData || []);
        }
      } catch (err: any) {
        if (isMounted) {
          setStatusMessage({ type: 'error', text: err?.message || 'Failed to load examination marks.' });
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    loadScheduleData();
    return () => {
      isMounted = false;
    };
  }, [selectedScheduleId, onGetMarks, onCheckEligibility]);

  // Local mark editing handler
  const handleMarkChange = (
    studentId: string,
    field: 'internal_marks' | 'external_marks' | 'submission_notes',
    value: any
  ) => {
    if (!isWindowOpen) return;

    setMarks((prev) => {
      const copy = [...prev];
      const index = copy.findIndex((m) => m.student_id === studentId);
      if (index === -1) return prev;

      const entry = { ...copy[index] };
      const max = activeSchedule?.max_marks || 100;

      if (field === 'internal_marks') {
        const num = value === '' ? 0 : Number(value);
        if (num < 0 || num > max) return prev;
        entry.internal_marks = num;
        entry.total_marks = num + (entry.external_marks || 0);
        entry.percentage = Math.round((entry.total_marks / max) * 100);
      } else if (field === 'external_marks') {
        const num = value === '' ? 0 : Number(value);
        if (num < 0 || num > max) return prev;
        entry.external_marks = num;
        entry.total_marks = (entry.internal_marks || 0) + num;
        entry.percentage = Math.round((entry.total_marks / max) * 100);
      } else if (field === 'submission_notes') {
        entry.submission_notes = value;
      }

      // Re-derive projected grade
      if (entry.total_marks >= 90) entry.grade = 'S';
      else if (entry.total_marks >= 80) entry.grade = 'A';
      else if (entry.total_marks >= 70) entry.grade = 'B';
      else if (entry.total_marks >= 60) entry.grade = 'C';
      else if (entry.total_marks >= 50) entry.grade = 'D';
      else if (entry.total_marks >= 40) entry.grade = 'E';
      else entry.grade = 'F';

      copy[index] = entry;
      return copy;
    });
  };

  // Save Draft Marks handler
  const handleSaveDraft = async () => {
    if (!selectedScheduleId || !isWindowOpen) return;
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const payload = marks.map((m) => ({
        student_id: m.student_id,
        internal_marks: m.internal_marks,
        external_marks: m.external_marks,
        submission_notes: m.submission_notes,
      }));

      await onSaveDraftMarks(selectedScheduleId, payload);
      setStatusMessage({
        type: 'success',
        text: 'Draft marks saved successfully. You may continue revising marks until submitting to COE.',
      });
      if (onRefreshData) await onRefreshData();
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err?.message || 'Failed to save draft marks.' });
    } finally {
      setIsSaving(false);
    }
  };

  // Submit for Review handler
  const handleConfirmSubmit = async () => {
    if (!selectedScheduleId) return;
    setIsSubmitting(true);
    setStatusMessage(null);
    try {
      // First save current entries
      const payload = marks.map((m) => ({
        student_id: m.student_id,
        internal_marks: m.internal_marks,
        external_marks: m.external_marks,
        submission_notes: m.submission_notes,
      }));
      await onSaveDraftMarks(selectedScheduleId, payload);

      // Now formally submit to COE
      const res = await onSubmitMarksForReview(selectedScheduleId, submissionNotes.trim() || undefined);
      setShowSubmitModal(false);
      setStatusMessage({
        type: 'success',
        text: `Successfully submitted ${res.updatedCount} mark entries for Controller of Examinations (COE) verification and moderation. Marks entry is now locked for review.`,
      });
      if (onRefreshData) await onRefreshData();
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err?.message || 'Failed to submit marks for review.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtered marks list
  const filteredMarks = useMemo(() => {
    if (!searchStudent.trim()) return marks;
    const q = searchStudent.toLowerCase();
    return marks.filter(
      (m) =>
        (m.student_registration_number && m.student_registration_number.toLowerCase().includes(q)) ||
        (m.student_name && m.student_name.toLowerCase().includes(q))
    );
  }, [marks, searchStudent]);

  return (
    <div className="space-y-6">
      {/* Header & Schedule Picker */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-[#1e3a8a]" />
              <span>University Marks & Grade Entry</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Enter continuous internal evaluation (CIA) and semester-end (FAT) marks for COE verification.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {isWindowOpen ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                <Unlock className="w-3.5 h-3.5 text-emerald-600" />
                COE Entry Window Open
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                <Lock className="w-3.5 h-3.5 text-slate-500" />
                Entry Window Locked
              </span>
            )}
          </div>
        </div>

        {/* Schedule Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
          <div className="sm:col-span-2">
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Select Examination Schedule
            </label>
            <select
              value={selectedScheduleId}
              onChange={(e) => setSelectedScheduleId(e.target.value)}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {eligibleSchedules.length === 0 ? (
                <option value="">No examination schedules allocated</option>
              ) : (
                eligibleSchedules.map((s) => (
                  <option key={s.schedule_id} value={s.schedule_id}>
                    {s.course_code} - {s.exam_name} ({s.exam_type}) &bull; Sec {s.section} &bull; {s.exam_date}
                  </option>
                ))
              )}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Submission Status
            </label>
            <div className="h-9 px-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between text-xs font-semibold">
              <span>{activeSchedule?.status || 'SCHEDULED'}</span>
              {isReturned && <Badge variant="amber">Returned for Correction</Badge>}
              {isSubmitted && <Badge variant="blue">Submitted</Badge>}
              {isApproved && <Badge variant="emerald">Approved</Badge>}
            </div>
          </div>
        </div>
      </div>

      {/* Critical Separation of Duties & Returned Marks Alerts */}
      <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-900 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong>Separation of Duties Rule:</strong> Faculty instructors submit proposed marks for academic evaluation. Verification, moderation, grade sealing, and final transcript publication belong exclusively to the Controller of Examinations (COE). Instructors cannot approve their own marks.
        </div>
      </div>

      {isReturned && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-900 space-y-1.5 shadow-2xs">
          <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
            <AlertTriangle className="w-4.5 h-4.5 text-amber-600 shrink-0" />
            <span>COE Remarks: Submission Returned for Correction</span>
          </div>
          <p className="text-amber-800 pl-6.5">
            <strong>Notes from COE Office:</strong> {activeSchedule?.notes || 'Please verify student mark entries and adjust per moderation criteria.'}
          </p>
        </div>
      )}

      {statusMessage && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-slate-400 hover:text-slate-600"
          >
            &times;
          </button>
        </div>
      )}

      {/* Marks Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4">
        {/* Table Top Toolbar */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs">
            <span className="font-bold text-[#1e293b]">Max Marks:</span>
            <Badge variant="blue">{activeSchedule?.max_marks || 100} Marks</Badge>
            <span className="text-slate-400">&bull;</span>
            <span className="font-bold text-[#1e293b]">Passing Marks:</span>
            <span className="font-semibold text-slate-700">{activeSchedule?.passing_marks || 40}</span>
          </div>

          <div className="w-full sm:w-64">
            <Input
              placeholder="Search candidate or Reg. No..."
              value={searchStudent}
              onChange={(e) => setSearchStudent(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        </div>

        {/* Table Canvas */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Reg. No.</th>
                <th className="py-2.5 px-3.5 font-semibold">Student Name</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">CIA Internal</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">FAT External</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Total</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Grade</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Result Status</th>
                <th className="py-2.5 px-3.5 font-semibold">Submission Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#94a3b8]">
                    Loading candidate mark entries...
                  </td>
                </tr>
              ) : filteredMarks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-10 text-center text-[#94a3b8]">
                    No eligible enrolled candidate records found for this schedule.
                  </td>
                </tr>
              ) : (
                filteredMarks.map((entry) => {
                  const student = students.find((s) => s.student_id === entry.student_id);
                  const isFailing = (entry.total_marks || 0) < (activeSchedule?.passing_marks || 40);

                  return (
                    <tr key={entry.result_id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                        {entry.student_registration_number}
                      </td>
                      <td className="py-2.5 px-3.5 font-bold text-[#1e293b]">
                        {student?.first_name ? `${student.first_name} ${student.last_name}` : entry.student_name || 'Candidate'}
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        {isWindowOpen ? (
                          <input
                            type="number"
                            min={0}
                            max={activeSchedule?.max_marks || 100}
                            value={entry.internal_marks ?? ''}
                            onChange={(e) =>
                              handleMarkChange(entry.student_id, 'internal_marks', e.target.value)
                            }
                            className="w-16 h-7 text-center rounded border border-slate-300 font-mono font-bold text-[#1e3a8a] text-xs focus:outline-hidden focus:border-[#1e3a8a]"
                          />
                        ) : (
                          <span className="font-mono font-bold text-slate-800">
                            {entry.internal_marks ?? '—'}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        {isWindowOpen ? (
                          <input
                            type="number"
                            min={0}
                            max={activeSchedule?.max_marks || 100}
                            value={entry.external_marks ?? ''}
                            onChange={(e) =>
                              handleMarkChange(entry.student_id, 'external_marks', e.target.value)
                            }
                            className="w-16 h-7 text-center rounded border border-slate-300 font-mono font-bold text-indigo-700 text-xs focus:outline-hidden focus:border-[#1e3a8a]"
                          />
                        ) : (
                          <span className="font-mono font-bold text-slate-800">
                            {entry.external_marks ?? '—'}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3.5 text-center font-mono font-bold text-slate-900">
                        {entry.total_marks} / {activeSchedule?.max_marks || 100}
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        <span
                          className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                            entry.grade === 'S' || entry.grade === 'A'
                              ? 'bg-emerald-100 text-emerald-800'
                              : entry.grade === 'F'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {entry.grade || '—'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                            isFailing
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {isFailing ? 'FAIL' : 'PASS'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5">
                        {isWindowOpen ? (
                          <input
                            type="text"
                            placeholder="Optional remark..."
                            value={entry.submission_notes || ''}
                            onChange={(e) =>
                              handleMarkChange(entry.student_id, 'submission_notes', e.target.value)
                            }
                            className="w-full h-7 px-2 text-xs rounded border border-slate-200 focus:outline-hidden focus:border-[#1e3a8a]"
                          />
                        ) : (
                          <span className="text-slate-500 text-[11px]">
                            {entry.submission_notes || '—'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Action Bar */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-[#64748b]">
            Total Records: <strong>{marks.length}</strong> &bull; Window Status:{' '}
            <strong className={isWindowOpen ? 'text-emerald-700' : 'text-slate-700'}>
              {isWindowOpen ? 'Open for entry' : 'Closed'}
            </strong>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={isSaving || !isWindowOpen || marks.length === 0}
              onClick={handleSaveDraft}
              className="text-xs h-8"
              leftIcon={<Save className="w-3.5 h-3.5 text-[#1e3a8a]" />}
            >
              {isSaving ? 'Saving Draft...' : 'Save Draft Marks'}
            </Button>

            <Button
              variant="primary"
              size="sm"
              disabled={isSubmitting || !isWindowOpen || marks.length === 0}
              onClick={() => setShowSubmitModal(true)}
              className="text-xs h-8"
              leftIcon={<Send className="w-3.5 h-3.5" />}
            >
              Submit for COE Review
            </Button>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-50 text-[#1e3a8a] flex items-center justify-center shrink-0">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#1e293b]">
                  Submit Marks for COE Verification?
                </h3>
                <p className="text-xs text-[#64748b] mt-0.5">
                  Schedule: <strong>{activeSchedule?.course_code} - {activeSchedule?.exam_name}</strong>
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Submitting will lock marks entry and transfer records to the Controller of Examinations (COE) for moderation and verification. Once submitted, marks cannot be altered directly unless returned by COE.
            </p>

            <div>
              <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
                Optional Transmittal Remarks for COE
              </label>
              <textarea
                value={submissionNotes}
                onChange={(e) => setSubmissionNotes(e.target.value)}
                placeholder="e.g. Evaluated per standard rubric. All answer scripts accounted for..."
                rows={2}
                className="w-full p-2 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSubmitModal(false)}
                className="text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                disabled={isSubmitting}
                onClick={handleConfirmSubmit}
                className="text-xs"
              >
                {isSubmitting ? 'Transmitting...' : 'Confirm Submission to COE'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
