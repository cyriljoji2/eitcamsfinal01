import React, { useState } from 'react';
import {
  CalendarCheck,
  Plus,
  Building,
  User,
  Clock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface GuestHouseBooking {
  id: string;
  guestName: string;
  guestDesignation: string;
  organization: string;
  purpose: 'Academic Viva / Examiner' | 'Conference Guest' | 'Research Collaborator' | 'Family Personal';
  checkInDate: string;
  checkOutDate: string;
  roomType: 'Executive Suite (AC)' | 'Deluxe Room (AC)' | 'Standard Room';
  status: 'CONFIRMED' | 'UNDER_REVIEW' | 'COMPLETED';
}

export function FacultyGuestHouseView() {
  const [bookings, setBookings] = useState<GuestHouseBooking[]>([
    {
      id: 'GH-2026-042',
      guestName: 'Prof. David R. Miller',
      guestDesignation: 'Professor of Computer Science',
      organization: 'Carnegie Mellon University / IEEE Fellow',
      purpose: 'Research Collaborator',
      checkInDate: '2026-11-20',
      checkOutDate: '2026-11-24',
      roomType: 'Executive Suite (AC)',
      status: 'CONFIRMED',
    },
    {
      id: 'GH-2026-031',
      guestName: 'Dr. Sunita Deshmukh',
      guestDesignation: 'Senior Scientist',
      organization: 'TCS Innovation Labs Pune',
      purpose: 'Academic Viva / Examiner',
      checkInDate: '2026-10-15',
      checkOutDate: '2026-10-17',
      roomType: 'Deluxe Room (AC)',
      status: 'COMPLETED',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [guestOrg, setGuestOrg] = useState('');
  const [purpose, setPurpose] = useState<'Academic Viva / Examiner' | 'Conference Guest' | 'Research Collaborator' | 'Family Personal'>('Research Collaborator');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [roomType, setRoomType] = useState<'Executive Suite (AC)' | 'Deluxe Room (AC)' | 'Standard Room'>('Deluxe Room (AC)');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim() || !checkIn) return;

    const newBooking: GuestHouseBooking = {
      id: `GH-2026-${Math.floor(100 + Math.random() * 900)}`,
      guestName: guestName.trim(),
      guestDesignation: 'Academic Visitor',
      organization: guestOrg.trim() || 'Partner University',
      purpose,
      checkInDate: checkIn,
      checkOutDate: checkOut || checkIn,
      roomType,
      status: 'UNDER_REVIEW',
    };

    setBookings([newBooking, ...bookings]);
    setIsModalOpen(false);
    setGuestName('');
    setGuestOrg('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Campus Executive Guest House Requisitions</h2>
            <Badge variant="blue">EIT International Guest House</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Book executive guest suites for visiting doctoral examiners, international research scholars, and academic delegates.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Book Guest House Room
        </Button>
      </div>

      {/* Bookings List */}
      <div className="space-y-4">
        {bookings.map((b) => (
          <div
            key={b.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {b.id}
                  </span>
                  <Badge variant={b.status === 'CONFIRMED' ? 'emerald' : b.status === 'UNDER_REVIEW' ? 'amber' : 'default'}>
                    {b.status.replace(/_/g, ' ')}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {b.roomType}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{b.guestName}</h3>
                <div className="text-xs text-[#64748b]">
                  {b.guestDesignation} &bull; <strong className="text-slate-800">{b.organization}</strong>
                </div>
                <div className="text-xs text-slate-600 font-medium pt-0.5">
                  Purpose of Visit: <em>{b.purpose}</em>
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Stay Duration</div>
                <div className="text-xs font-bold text-slate-800 font-mono">
                  {b.checkInDate} &rarr; {b.checkOutDate}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">International Guest House Wing A</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Request Guest House Accommodation</h3>
            <p className="text-xs text-[#64748b]">
              Submit requisition details for Estate Manager approval.
            </p>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Guest Full Name</label>
                <Input
                  required
                  placeholder="e.g., Prof. Robert Chen"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Guest Affiliation / Organization</label>
                <Input
                  required
                  placeholder="e.g., University of Oxford / DRDO Labs"
                  value={guestOrg}
                  onChange={(e) => setGuestOrg(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Visit Purpose</label>
                  <select
                    value={purpose}
                    onChange={(e) => setPurpose(e.target.value as any)}
                    className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="Academic Viva / Examiner">Academic Viva / Examiner</option>
                    <option value="Research Collaborator">Research Collaborator</option>
                    <option value="Conference Guest">Conference Guest</option>
                    <option value="Family Personal">Family Personal</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Room Category</label>
                  <select
                    value={roomType}
                    onChange={(e) => setRoomType(e.target.value as any)}
                    className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="Executive Suite (AC)">Executive Suite (AC)</option>
                    <option value="Deluxe Room (AC)">Deluxe Room (AC)</option>
                    <option value="Standard Room">Standard Room</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Check-In Date</label>
                  <Input
                    type="date"
                    required
                    value={checkIn}
                    onChange={(e) => setCheckIn(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Check-Out Date</label>
                  <Input
                    type="date"
                    required
                    value={checkOut}
                    onChange={(e) => setCheckOut(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Submit Requisition
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
