import React from 'react';
import {
  BookOpen,
  Calendar,
  LogOut,
  User,
  Menu,
  X,
  Bell,
  Clock,
  Building2,
  GraduationCap,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface FacultyHeaderProps {
  displayName: string;
  employeeId?: string;
  registrationNumber?: string;
  designation?: string;
  department?: string;
  currentTerm?: string;
  isMobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
  onLogout: () => void;
  notificationCount?: number;
  onSelectTab?: (tab: string) => void;
}

export function FacultyHeader({
  displayName,
  employeeId,
  registrationNumber,
  designation = 'Assistant Professor',
  department = 'Computer Science & Engineering',
  currentTerm = 'Fall 2026–2027',
  isMobileMenuOpen,
  onToggleMobileMenu,
  onLogout,
  notificationCount = 0,
  onSelectTab,
}: FacultyHeaderProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  const initials = displayName
    .split(' ')
    .filter(Boolean)
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase() || 'FC';

  return (
    <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Portal Branding */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onToggleMobileMenu}
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label="Toggle navigation"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="w-10 h-10 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs shrink-0">
              <BookOpen className="w-5 h-5 stroke-[2.2]" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-[#1e293b] text-base tracking-tight">
                  Electrix Institute of Technology
                </span>
                <span className="text-xs text-[#94a3b8] hidden sm:inline">&bull;</span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                  Faculty Academic Portal
                </span>
              </div>
              <p className="text-xs text-[#64748b] hidden sm:block">
                Teaching & Classroom Management &bull; Department of {department}
              </p>
            </div>
          </div>

          {/* Right Session Switcher, Quick Profile & Logout */}
          <div className="flex items-center gap-2 sm:gap-4">
            {/* Academic Session / Term Badge */}
            <div className="hidden md:flex items-center gap-1.5 bg-[#f8fafc] border border-[#e2e8f0] px-3 py-1.5 rounded-lg text-xs">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              <span className="text-[#64748b]">Term:</span>
              <span className="font-semibold text-[#1e293b]">
                {activeAcademicYear ? `AY ${activeAcademicYear}` : currentTerm}
              </span>
            </div>

            {/* Notifications / Alerts shortcut */}
            {notificationCount > 0 && onSelectTab && (
              <button
                type="button"
                onClick={() => onSelectTab('proctor')}
                className="relative p-2 rounded-lg text-slate-500 hover:text-[#1e3a8a] hover:bg-slate-100 transition-colors cursor-pointer"
                title={`${notificationCount} pending proctor requests`}
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white"></span>
              </button>
            )}

            {/* User Profile Pill */}
            <div
              onClick={() => onSelectTab && onSelectTab('profile')}
              className="flex items-center gap-2.5 pl-2 border-l border-[#e2e8f0] cursor-pointer group"
              title="View Faculty Profile"
            >
              <div className="w-9 h-9 rounded-full bg-[#eff6ff] border border-blue-200 flex items-center justify-center text-[#1e3a8a] font-bold text-xs group-hover:border-[#1e3a8a] transition-all shrink-0">
                {initials}
              </div>
              <div className="hidden sm:block text-left">
                <div className="font-semibold text-[#1e293b] text-xs leading-tight group-hover:text-[#1e3a8a] transition-colors">
                  {displayName}
                </div>
                <div className="text-[10px] text-[#64748b] leading-tight">
                  {registrationNumber || employeeId || 'Faculty'}
                </div>
              </div>
            </div>

            {/* Logout Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={onLogout}
              className="text-xs h-8 text-rose-700 hover:text-rose-800 hover:bg-rose-50 border-rose-200 cursor-pointer ml-1"
              leftIcon={<LogOut className="w-3.5 h-3.5" />}
            >
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
