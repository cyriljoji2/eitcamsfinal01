import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Eye,
  Download,
  GraduationCap,
  BookOpen,
  Mail,
  Phone,
  ShieldCheck,
} from 'lucide-react';
import { StudentRecord, FacultyCourseAssignmentRecord, CourseEnrolmentRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyStudentRosterViewProps {
  students: StudentRecord[];
  assignments: FacultyCourseAssignmentRecord[];
  enrolments: CourseEnrolmentRecord[];
  onOpenStudentProfile: (regNo: string) => void;
}

export function FacultyStudentRosterView({
  students,
  assignments,
  enrolments,
  onOpenStudentProfile,
}: FacultyStudentRosterViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<string>('ALL');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');

  const uniqueCourses = useMemo(() => {
    const map = new Map<string, string>();
    assignments.forEach((a) => {
      map.set(a.course_code, a.course_title || a.course_code);
    });
    return Array.from(map.entries());
  }, [assignments]);

  const uniqueSections = useMemo(() => {
    return Array.from(new Set(assignments.map((a) => a.section)));
  }, [assignments]);

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      // Find enrolments for this student
      const studentEnrolments = enrolments.filter(
        (e) => e.student_id === student.student_id || e.student_registration_number === student.registration_number
      );

      // Course filter
      if (selectedCourse !== 'ALL') {
        const hasCourse = studentEnrolments.some((e) => e.course_code === selectedCourse);
        if (!hasCourse) return false;
      }

      // Section filter
      if (selectedSection !== 'ALL') {
        const hasSection = studentEnrolments.some((e) => e.section === selectedSection);
        if (!hasSection) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = `${student.first_name} ${student.last_name}`.toLowerCase().includes(q);
        const matchesReg = student.registration_number.toLowerCase().includes(q);
        const matchesEmail = (student.institutional_email || '').toLowerCase().includes(q);
        if (!matchesName && !matchesReg && !matchesEmail) return false;
      }

      return true;
    });
  }, [students, enrolments, selectedCourse, selectedSection, searchQuery]);

  const exportRosterCsv = () => {
    const headers = ['Registration Number', 'Full Name', 'Department', 'Semester', 'Section', 'Email', 'Phone'];
    const rows = filteredStudents.map((s) => [
      s.registration_number,
      `"${s.first_name} ${s.last_name}"`,
      s.department,
      s.current_semester,
      s.section,
      s.institutional_email || '',
      s.personal_phone || '',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Student_Roster_${selectedCourse}_${selectedSection}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Student Rosters & Enrolment Master</h2>
            <Badge variant="blue">{filteredStudents.length} Students</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative class roster of students enrolled in your assigned courses and instructional sections.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={exportRosterCsv}
          disabled={filteredStudents.length === 0}
          leftIcon={<Download className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto"
        >
          Export CSV Roster
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search student by name, registration number, or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-[#64748b]">
            <Filter className="w-3.5 h-3.5" />
            <span>Course:</span>
          </div>
          <select
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="text-xs py-1.5 px-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
          >
            <option value="ALL">All Courses</option>
            {uniqueCourses.map(([code, title]) => (
              <option key={code} value={code}>
                {code} — {title.length > 25 ? title.slice(0, 25) + '...' : title}
              </option>
            ))}
          </select>

          <select
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="text-xs py-1.5 px-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
          >
            <option value="ALL">All Sections</option>
            {uniqueSections.map((sec) => (
              <option key={sec} value={sec}>
                Section {sec}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-3 px-4 font-semibold">Reg Number</th>
                <th className="py-3 px-4 font-semibold">Student Name</th>
                <th className="py-3 px-4 font-semibold">Department & Sem</th>
                <th className="py-3 px-4 font-semibold">Section</th>
                <th className="py-3 px-4 font-semibold">Contact Details</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-[#94a3b8]">
                    <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    No enrolled students found matching the selected course and section criteria.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((st) => (
                  <tr key={st.student_id} className="hover:bg-[#f8fafc] transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                      {st.registration_number}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-[#1e293b]">
                        {st.first_name} {st.last_name}
                      </div>
                      <div className="text-[11px] text-[#64748b]">{st.program_name}</div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="blue">{st.department}</Badge>
                      <span className="ml-1.5 text-[#64748b]">Sem {st.current_semester}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-700">Sec {st.section}</span>
                    </td>
                    <td className="py-3 px-4 text-[#64748b]">
                      <div className="flex items-center gap-1.5">
                        <Mail className="w-3 h-3 text-slate-400" />
                        <span>{st.institutional_email || '—'}</span>
                      </div>
                      {st.personal_phone && (
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-0.5">
                          <Phone className="w-3 h-3" />
                          <span>{st.personal_phone}</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onOpenStudentProfile(st.registration_number)}
                        leftIcon={<Eye className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                        className="h-7 text-xs"
                      >
                        Academic Profile
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
