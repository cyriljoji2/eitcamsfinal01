import React, { useState } from 'react';
import {
  Sparkles,
  Calendar,
  Building,
  Plus,
  ExternalLink,
  CheckCircle2,
  MapPin,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FdpRecord {
  id: string;
  title: string;
  organizer: string;
  type: 'FDP Attended' | 'FDP Organized' | 'Conference Presentation' | 'Invited Keynote';
  dates: string;
  venue: string;
  fundingSupport?: string;
  isNptelOrAicte?: boolean;
}

export function FacultyFdpView() {
  const [fdpList, setFdpList] = useState<FdpRecord[]>([
    {
      id: 'FDP-2025-01',
      title: 'AICTE-ATAL Faculty Development Programme on Quantum Computing & Post-Quantum Cryptography',
      organizer: 'IIT Delhi & AICTE',
      type: 'FDP Attended',
      dates: '2025-08-18 to 2025-08-23',
      venue: 'Online / Blended Mode',
      fundingSupport: 'AICTE ATAL Sponsorship',
      isNptelOrAicte: true,
    },
    {
      id: 'FDP-2025-02',
      title: '5-Day National Workshop on Scalable Cloud Native Architectures using Kubernetes',
      organizer: 'Department of CSE, EIT',
      type: 'FDP Organized',
      dates: '2025-02-10 to 2025-02-14',
      venue: 'EIT High-Performance Computing Lab',
      fundingSupport: 'EIT Faculty Research & Development Council',
      isNptelOrAicte: false,
    },
    {
      id: 'CONF-2024-01',
      title: 'International Conference on High Performance Computing, Network, and Storage (SC 2024)',
      organizer: 'ACM / IEEE Computer Society',
      type: 'Conference Presentation',
      dates: '2024-11-17 to 2024-11-22',
      venue: 'Atlanta, GA, USA',
      fundingSupport: 'DST International Travel Grant & EIT Travel Subsidy',
      isNptelOrAicte: false,
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [organizer, setOrganizer] = useState('');
  const [type, setType] = useState<'FDP Attended' | 'FDP Organized' | 'Conference Presentation' | 'Invited Keynote'>('FDP Attended');
  const [dates, setDates] = useState('');
  const [venue, setVenue] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !organizer.trim()) return;

    const newRecord: FdpRecord = {
      id: `FDP-${Date.now().toString().slice(-4)}`,
      title: title.trim(),
      organizer: organizer.trim(),
      type,
      dates: dates.trim() || 'Fall 2026',
      venue: venue.trim() || 'Institutional Campus',
    };

    setFdpList([newRecord, ...fdpList]);
    setIsModalOpen(false);
    setTitle('');
    setOrganizer('');
    setDates('');
    setVenue('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Faculty Development (FDP), Workshops & Conferences</h2>
            <Badge variant="blue">{fdpList.length} Programmes</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional portfolio of AICTE/NPTEL FDPs attended, technical workshops coordinated, and peer-reviewed conference travels.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Record FDP / Conference
        </Button>
      </div>

      {/* Grid */}
      <div className="space-y-4">
        {fdpList.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {item.id}
                  </span>
                  <Badge
                    variant={
                      item.type === 'FDP Organized'
                        ? 'emerald'
                        : item.type === 'Conference Presentation'
                        ? 'amber'
                        : 'blue'
                    }
                  >
                    {item.type}
                  </Badge>
                  {item.isNptelOrAicte && (
                    <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                      AICTE / NPTEL Approved
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{item.title}</h3>
                <div className="text-xs text-[#64748b]">
                  Conducted / Hosted by: <strong className="text-slate-800">{item.organizer}</strong>
                </div>
              </div>

              <div className="sm:text-right shrink-0 text-xs text-[#64748b]">
                <div className="flex items-center gap-1.5 sm:justify-end text-slate-700 font-medium">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{item.dates}</span>
                </div>
                <div className="flex items-center gap-1.5 sm:justify-end text-slate-500 mt-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{item.venue}</span>
                </div>
              </div>
            </div>

            {item.fundingSupport && (
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-600 flex items-center justify-between">
                <span>Funding / Grant Sponsor: <strong>{item.fundingSupport}</strong></span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Verified for Annual PBAS Appraisal
                </span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Record FDP or Conference Participation</h3>
            <p className="text-xs text-[#64748b]">
              Submit details for institutional appraisal score (PBAS) validation.
            </p>

            <form onSubmit={handleAdd} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Programme Title</label>
                <Input
                  required
                  placeholder="e.g., ATAL FDP on Deep Learning Architectures"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Organizer / Institution</label>
                  <Input
                    required
                    placeholder="e.g., IIT Madras, AICTE"
                    value={organizer}
                    onChange={(e) => setOrganizer(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Activity Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="FDP Attended">FDP Attended</option>
                    <option value="FDP Organized">FDP Organized</option>
                    <option value="Conference Presentation">Conference Presentation</option>
                    <option value="Invited Keynote">Invited Keynote</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Dates / Duration</label>
                  <Input
                    placeholder="e.g., 2026-10-12 to 2026-10-16"
                    value={dates}
                    onChange={(e) => setDates(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Venue / Mode</label>
                  <Input
                    placeholder="e.g., Chennai, Online"
                    value={venue}
                    onChange={(e) => setVenue(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Save Programme
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
