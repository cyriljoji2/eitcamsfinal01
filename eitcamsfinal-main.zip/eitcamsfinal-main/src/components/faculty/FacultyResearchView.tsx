import React, { useState } from 'react';
import {
  FlaskConical,
  BookOpen,
  Award,
  Plus,
  ExternalLink,
  CheckCircle2,
  FileCheck2,
} from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface ResearchPaper {
  id: string;
  title: string;
  journal: string;
  year: number;
  doi: string;
  citations: number;
  status: 'published' | 'under_review';
}

export function FacultyResearchView() {
  const [papers, setPapers] = useState<ResearchPaper[]>([
    {
      id: 'PUB-001',
      title: 'Scalable Graph Partitioning for Heterogeneous Distributed Clusters',
      journal: 'IEEE Transactions on Parallel and Distributed Systems (TPDS)',
      year: 2025,
      doi: '10.1109/TPDS.2025.321890',
      citations: 18,
      status: 'published',
    },
    {
      id: 'PUB-002',
      title: 'Fault-Tolerant Consensus Mechanisms in Resource-Constrained Edge Networks',
      journal: 'ACM Transactions on Computer Systems (TOCS)',
      year: 2024,
      doi: '10.1145/341289.349812',
      citations: 34,
      status: 'published',
    },
  ]);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newJournal, setNewJournal] = useState('');
  const [newYear, setNewYear] = useState(2026);
  const [newDoi, setNewDoi] = useState('');

  const handleAddPaper = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newPaper: ResearchPaper = {
      id: `PUB-${Date.now()}`,
      title: newTitle.trim(),
      journal: newJournal.trim() || 'Institutional Proceedings',
      year: newYear,
      doi: newDoi.trim() || `10.1007/eit.${Date.now()}`,
      citations: 0,
      status: 'published',
    };

    setPapers([newPaper, ...papers]);
    setNewTitle('');
    setNewJournal('');
    setIsAddOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Demonstration Portfolio Notice */}
      <div className="bg-indigo-50 border border-indigo-200 text-indigo-900 px-4 py-3 rounded-2xl text-xs flex items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-2.5">
          <FlaskConical className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>
            <strong>Demonstration Scholarly Portfolio:</strong> Research publications, journal indexes, and citations are stored locally in the faculty showcase portfolio and separated from official institutional accreditation registries.
          </span>
        </div>
      </div>

      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-[#1e3a8a]" />
            <span>Research & Scholarly Publications Portfolio</span>
          </h1>
          <p className="text-xs text-[#64748b] mt-0.5">
            Faculty research output, indexed journal papers, citation tracking, and patent disclosures.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsAddOpen(true)}
          className="text-xs"
          leftIcon={<Plus className="w-3.5 h-3.5" />}
        >
          Add Publication
        </Button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs text-[#64748b] font-semibold">Indexed Publications</div>
          <div className="text-2xl font-bold text-[#1e293b] mt-1">{papers.length} Articles</div>
          <div className="text-[11px] text-emerald-600 mt-1">Scopus / Web of Science Core</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs text-[#64748b] font-semibold">Total Citations</div>
          <div className="text-2xl font-bold text-[#1e3a8a] mt-1">
            {papers.reduce((sum, p) => sum + p.citations, 0)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">h-index: 6 &bull; i10-index: 5</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs text-[#64748b] font-semibold">Sponsored Research Grants</div>
          <div className="text-2xl font-bold text-slate-800 mt-1">2 Active Projects</div>
          <div className="text-[11px] text-purple-700 mt-1">EIT Research Council Sanctioned</div>
        </div>
      </div>

      {/* Papers Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden p-5 space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b]">Peer-Reviewed Journal & Conference Papers</h3>

        <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Paper Title</th>
                <th className="py-2.5 px-3.5 font-semibold">Journal / Venue</th>
                <th className="py-2.5 px-3.5 font-semibold">Year</th>
                <th className="py-2.5 px-3.5 font-semibold">DOI Identifier</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Citations</th>
                <th className="py-2.5 px-3.5 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {papers.map((p) => (
                <tr key={p.id} className="hover:bg-[#f8fafc]">
                  <td className="py-2.5 px-3.5 font-bold text-[#1e293b] max-w-sm">
                    {p.title}
                  </td>
                  <td className="py-2.5 px-3.5 text-[#64748b]">{p.journal}</td>
                  <td className="py-2.5 px-3.5 font-semibold text-slate-800">{p.year}</td>
                  <td className="py-2.5 px-3.5 font-mono text-[11px] text-[#1e3a8a]">{p.doi}</td>
                  <td className="py-2.5 px-3.5 text-center font-bold text-slate-700">
                    {p.citations}
                  </td>
                  <td className="py-2.5 px-3.5 text-right">
                    <Badge variant="emerald">Published</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-[#1e293b]">Record New Publication</h3>
            <form onSubmit={handleAddPaper} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Article Title</label>
                <Input
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Distributed Consensus in Cloud Systems..."
                  className="h-8 text-xs"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Journal / Conference Name</label>
                <Input
                  value={newJournal}
                  onChange={(e) => setNewJournal(e.target.value)}
                  placeholder="e.g. IEEE Transactions on Computers..."
                  className="h-8 text-xs"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">Publication Year</label>
                  <Input
                    type="number"
                    value={newYear}
                    onChange={(e) => setNewYear(Number(e.target.value))}
                    className="h-8 text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">DOI / URL</label>
                  <Input
                    value={newDoi}
                    onChange={(e) => setNewDoi(e.target.value)}
                    placeholder="10.1109/..."
                    className="h-8 text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsAddOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="text-xs">
                  Record Publication
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
