import React, { useState, useMemo } from 'react';
import {
  Clock,
  Calendar,
  Building2,
  CheckCircle2,
  Filter,
  BookOpen,
  MapPin,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';
import { TimetableSlotRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyTimetableViewProps {
  slots: TimetableSlotRecord[];
  facultyName: string;
}

const WEEKDAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'] as const;
const TIME_BLOCKS = [
  '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'
];

export function FacultyTimetableView({ slots, facultyName }: FacultyTimetableViewProps) {
  const [viewMode, setViewMode] = useState<'weekly' | 'daily'>('weekly');
  const [selectedDay, setSelectedDay] = useState<typeof WEEKDAYS[number]>('MONDAY');
  const [courseFilter, setCourseFilter] = useState<string>('ALL');

  // Filter slots for active published ones
  const filteredSlots = useMemo(() => {
    return slots.filter((slot) => {
      if (courseFilter !== 'ALL' && slot.course_code !== courseFilter) return false;
      return true;
    });
  }, [slots, courseFilter]);

  // Unique courses for filter
  const uniqueCourses = useMemo(() => {
    return Array.from(new Set(slots.map((s) => s.course_code))).sort();
  }, [slots]);

  // Today's day name in uppercase
  const todayUpper = useMemo(() => {
    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    return days[new Date().getDay()] as typeof WEEKDAYS[number];
  }, []);

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
                <Clock className="w-5 h-5 text-[#1e3a8a]" />
                <span>Teaching Schedule & Official Timetable</span>
              </h1>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Published & Active
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Official institutional lecture and laboratory timetable authorized by the Academic Office.
            </p>
          </div>

          {/* View Toggles & Filter */}
          <div className="flex items-center gap-2.5">
            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('weekly')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  viewMode === 'weekly'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Weekly Grid
              </button>
              <button
                type="button"
                onClick={() => setViewMode('daily')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  viewMode === 'daily'
                    ? 'bg-white text-[#1e3a8a] shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Daily Schedule
              </button>
            </div>

            {/* Course Filter */}
            <select
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
              className="h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              <option value="ALL">All Courses ({slots.length} Slots)</option>
              {uniqueCourses.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Timetable Integrity Notice */}
        <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 flex items-center justify-between text-xs text-blue-900">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-[#1e3a8a] shrink-0" />
            <span>
              <strong>Academic Governance Rule:</strong> Timetable slots and room allocations are maintained and validated centrally by the Academic Office. Faculty members cannot publish or alter institutional schedules.
            </span>
          </div>
          <span className="font-mono text-[11px] font-semibold text-[#1e3a8a] bg-white px-2 py-0.5 rounded border border-blue-200 shrink-0">
            Version v3 (Active)
          </span>
        </div>
      </div>

      {/* Daily Mode Sub-selector */}
      {viewMode === 'daily' && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {WEEKDAYS.map((day) => {
            const isToday = day === todayUpper;
            const isSelected = day === selectedDay;
            const daySlotCount = filteredSlots.filter((s) => s.day_of_week === day).length;

            return (
              <button
                key={day}
                type="button"
                onClick={() => setSelectedDay(day)}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                  isSelected
                    ? 'bg-[#1e3a8a] text-white shadow-xs'
                    : 'bg-white border border-[#e2e8f0] text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{day.charAt(0) + day.slice(1).toLowerCase()}</span>
                {isToday && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${isSelected ? 'bg-blue-800 text-white' : 'bg-emerald-100 text-emerald-800'}`}>
                    Today
                  </span>
                )}
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-blue-900 text-blue-100' : 'bg-slate-100 text-slate-600'}`}>
                  {daySlotCount}
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Main Timetable View */}
      {viewMode === 'daily' ? (
        /* Daily View List */
        <div className="bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-[#1e293b]">
              Classes on {selectedDay.charAt(0) + selectedDay.slice(1).toLowerCase()}
            </h3>
            <span className="text-xs text-[#64748b]">
              Instructor: <strong>{facultyName}</strong>
            </span>
          </div>

          {filteredSlots.filter((s) => s.day_of_week === selectedDay).length === 0 ? (
            <div className="py-12 text-center text-xs text-[#94a3b8]">
              No teaching periods scheduled on {selectedDay}.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredSlots
                .filter((s) => s.day_of_week === selectedDay)
                .sort((a, b) => a.start_time.localeCompare(b.start_time))
                .map((slot) => (
                  <div
                    key={slot.slot_id}
                    className="p-4 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-blue-300 transition-colors"
                  >
                    <div className="flex items-start sm:items-center gap-4">
                      <div className="w-20 text-center py-1.5 bg-white border border-slate-200 rounded-lg shrink-0">
                        <div className="font-mono font-bold text-xs text-[#1e3a8a]">{slot.start_time}</div>
                        <div className="text-[10px] text-slate-400">to {slot.end_time}</div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                            {slot.course_code}
                          </span>
                          <span className="font-bold text-xs text-[#1e293b]">{slot.course_title}</span>
                        </div>
                        <p className="text-xs text-[#64748b] mt-1">
                          Programme: {slot.programme_code} &bull; Semester {slot.semester} &bull; Section {slot.section}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-xs">
                      <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-slate-700">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-semibold">{slot.room}</span>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      ) : (
        /* Weekly Grid Matrix */
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-x-auto">
          <div className="min-w-[850px]">
            {/* Header row: Days */}
            <div className="grid grid-cols-7 border-b border-[#e2e8f0] bg-[#f8fafc] text-xs font-semibold text-[#64748b]">
              <div className="p-3 text-center border-r border-[#e2e8f0]">Time Slot</div>
              {WEEKDAYS.map((day) => (
                <div
                  key={day}
                  className={`p-3 text-center border-r last:border-r-0 border-[#e2e8f0] ${
                    day === todayUpper ? 'bg-blue-50/70 text-[#1e3a8a] font-bold' : ''
                  }`}
                >
                  {day.charAt(0) + day.slice(1, 3).toLowerCase()}
                  {day === todayUpper && <span className="block text-[10px] text-emerald-600">Today</span>}
                </div>
              ))}
            </div>

            {/* Timetable Rows by Slot */}
            <div className="divide-y divide-[#f1f5f9]">
              {WEEKDAYS.map((day) => {
                const daySlots = filteredSlots
                  .filter((s) => s.day_of_week === day)
                  .sort((a, b) => a.start_time.localeCompare(b.start_time));

                return (
                  <div key={day} className="p-4 flex items-start gap-4 hover:bg-slate-50/50">
                    <div className="w-28 shrink-0 font-bold text-xs text-[#1e293b] pt-1">
                      {day.charAt(0) + day.slice(1).toLowerCase()}
                      <span className="block font-normal text-[10px] text-[#64748b]">
                        {daySlots.length} lecture period(s)
                      </span>
                    </div>

                    <div className="flex-1 flex flex-wrap gap-3">
                      {daySlots.length === 0 ? (
                        <span className="text-xs text-slate-300 italic pt-1">No classes scheduled</span>
                      ) : (
                        daySlots.map((slot) => (
                          <div
                            key={slot.slot_id}
                            className="p-3 bg-[#eff6ff]/70 border border-blue-200 rounded-xl text-xs space-y-1 hover:border-[#1e3a8a] transition-colors w-64 shadow-2xs"
                          >
                            <div className="flex items-center justify-between font-mono font-bold text-[#1e3a8a] text-[11px]">
                              <span>{slot.start_time} - {slot.end_time}</span>
                              <span className="bg-white px-2 py-0.5 rounded text-[10px] border border-blue-200 font-sans text-slate-700">
                                {slot.room}
                              </span>
                            </div>
                            <div className="font-bold text-[#1e293b] truncate" title={slot.course_title}>
                              {slot.course_code}: {slot.course_title}
                            </div>
                            <div className="text-[11px] text-[#64748b] flex justify-between items-center">
                              <span>Sec {slot.section} &bull; Sem {slot.semester}</span>
                              <span className="text-[10px] font-mono text-slate-500">{slot.programme_code}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
