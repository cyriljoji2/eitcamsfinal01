import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  AlertTriangle,
  Users,
  CheckCircle2,
  TrendingUp,
  BookOpen,
  Filter,
  Search,
  Eye,
  Award,
} from 'lucide-react';
import {
  AttendanceRecord,
  AttendanceStatus,
  CourseEnrolmentRecord,
  ExamResultRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
} from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyPerformanceViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  students: StudentRecord[];
  enrolments: CourseEnrolmentRecord[];
  attendanceRecords: AttendanceRecord[];
  examResults: ExamResultRecord[];
  onOpenStudentProfile: (regNo: string) => void;
}

export function FacultyPerformanceView({
  assignments,
  students,
  enrolments,
  attendanceRecords,
  examResults,
  onOpenStudentProfile,
}: FacultyPerformanceViewProps) {
  const [selectedCourseCode, setSelectedCourseCode] = useState<string>(
    assignments[0]?.course_code || ''
  );
  const [selectedSection, setSelectedSection] = useState<string>(
    assignments[0]?.section || 'A'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAtRiskOnly, setFilterAtRiskOnly] = useState(false);

  // Compute student metrics for selected course and section
  const studentMetrics = useMemo(() => {
    const courseEnrs = enrolments.filter(
      (e) =>
        e.course_code === selectedCourseCode &&
        e.section === selectedSection &&
        e.enrolment_status === 'ACTIVE'
    );

    return courseEnrs.map((enr) => {
      const student = students.find((s) => s.student_id === enr.student_id);

      // Attendance for this student in this course
      const studentAtt = attendanceRecords.filter(
        (a) =>
          a.course_code === selectedCourseCode &&
          (a.student_id === enr.student_id || a.registration_number === enr.student_registration_number)
      );
      const totalSessions = studentAtt.length;
      const attendedSessions = studentAtt.filter(
        (a) => a.status === AttendanceStatus.PRESENT || a.status === AttendanceStatus.LATE
      ).length;
      const attendancePct = totalSessions > 0 ? Math.round((attendedSessions / totalSessions) * 100) : 100;

      // Evaluation marks for this student in this course
      const studentResults = examResults.filter(
        (r) =>
          r.course_code === selectedCourseCode &&
          (r.student_id === enr.student_id || r.student_registration_number === enr.student_registration_number)
      );

      const latestResult = studentResults[0];
      const marksObtained = latestResult?.total_marks ?? null;
      const grade = latestResult?.grade ?? '—';
      const isFailing = marksObtained !== null && marksObtained < 40;
      const isAttendanceShortage = attendancePct < 75;
      const isAtRisk = isAttendanceShortage || isFailing;

      return {
        enrolment: enr,
        student,
        totalSessions,
        attendedSessions,
        attendancePct,
        marksObtained,
        grade,
        isFailing,
        isAttendanceShortage,
        isAtRisk,
      };
    });
  }, [enrolments, selectedCourseCode, selectedSection, students, attendanceRecords, examResults]);

  // Filtered list
  const filteredMetrics = useMemo(() => {
    return studentMetrics.filter((item) => {
      if (filterAtRiskOnly && !item.isAtRisk) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesReg = item.enrolment.student_registration_number.toLowerCase().includes(q);
        const name = `${item.student?.first_name || ''} ${item.student?.last_name || ''}`.toLowerCase();
        if (!matchesReg && !name.includes(q)) return false;
      }
      return true;
    });
  }, [studentMetrics, filterAtRiskOnly, searchQuery]);

  // Aggregate stats
  const totalClassStrength = studentMetrics.length;
  const atRiskCount = studentMetrics.filter((s) => s.isAtRisk).length;
  const avgAttendance =
    totalClassStrength > 0
      ? Math.round(studentMetrics.reduce((sum, s) => sum + s.attendancePct, 0) / totalClassStrength)
      : 100;

  return (
    <div className="space-y-6">
      {/* Header & Course Filter */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#1e3a8a]" />
              <span>Course Academic Performance & At-Risk Monitoring</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Comprehensive student academic standing, attendance rates, and early intervention indicators.
            </p>
          </div>

          {/* Course & Section Selectors */}
          <div className="flex items-center gap-3">
            <select
              value={selectedCourseCode}
              onChange={(e) => {
                setSelectedCourseCode(e.target.value);
                const matching = assignments.find((a) => a.course_code === e.target.value);
                if (matching) setSelectedSection(matching.section);
              }}
              className="h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {assignments.map((asg) => (
                <option key={asg.faculty_assignment_id} value={asg.course_code}>
                  {asg.course_code} - {asg.course_title}
                </option>
              ))}
            </select>

            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {assignments
                .filter((a) => a.course_code === selectedCourseCode)
                .map((a) => (
                  <option key={a.faculty_assignment_id} value={a.section}>
                    Section {a.section}
                  </option>
                ))}
            </select>
          </div>
        </div>
      </div>

      {/* Aggregate Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-[#64748b]">Enrolled Strength</div>
          <div className="text-2xl font-bold text-[#1e293b] mt-1">{totalClassStrength} Students</div>
          <div className="text-[11px] text-slate-500 mt-1">Section {selectedSection}</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs">
          <div className="text-xs font-semibold text-[#1e3a8a]">Cohort Average Attendance</div>
          <div className="text-2xl font-bold text-[#1e3a8a] mt-1">{avgAttendance}%</div>
          <div className="text-[11px] text-emerald-600 mt-1">
            Institutional requirement: &ge; 75%
          </div>
        </div>

        <div
          onClick={() => setFilterAtRiskOnly(!filterAtRiskOnly)}
          className={`border rounded-xl p-4 shadow-xs transition-all cursor-pointer ${
            filterAtRiskOnly
              ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-400'
              : 'bg-white border-[#e2e8f0] hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800">Students Requiring Attention</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-900 mt-1">{atRiskCount} Candidates</div>
          <div className="text-[11px] text-amber-700 mt-1">
            {filterAtRiskOnly ? 'Click to show all students' : 'Click to filter at-risk only'}
          </div>
        </div>
      </div>

      {/* Roster & Academic Standing Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-sm font-bold text-[#1e293b]">
            Student Performance Registry &bull; {selectedCourseCode} (Sec {selectedSection})
          </h3>

          <div className="w-full sm:w-64">
            <Input
              placeholder="Filter by name or Reg. No..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        </div>

        <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
              <tr>
                <th className="py-2.5 px-3.5 font-semibold">Reg. No.</th>
                <th className="py-2.5 px-3.5 font-semibold">Student Name</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Attendance %</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Marks / 100</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Grade</th>
                <th className="py-2.5 px-3.5 font-semibold text-center">Intervention Status</th>
                <th className="py-2.5 px-3.5 font-semibold text-right">Academic Profile</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredMetrics.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#94a3b8]">
                    No students match the current criteria.
                  </td>
                </tr>
              ) : (
                filteredMetrics.map((item) => (
                  <tr key={item.enrolment.enrolment_id} className="hover:bg-[#f8fafc]">
                    <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                      {item.enrolment.student_registration_number}
                    </td>
                    <td className="py-2.5 px-3.5 font-bold text-[#1e293b]">
                      {item.student?.first_name} {item.student?.last_name}
                    </td>
                    <td className="py-2.5 px-3.5 text-center">
                      <span
                        className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                          item.attendancePct < 75
                            ? 'bg-rose-100 text-rose-800'
                            : item.attendancePct < 85
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {item.attendancePct}%
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5 text-center font-mono font-bold text-slate-800">
                      {item.marksObtained !== null ? `${item.marksObtained}` : '—'}
                    </td>
                    <td className="py-2.5 px-3.5 text-center font-mono font-bold">
                      {item.grade}
                    </td>
                    <td className="py-2.5 px-3.5 text-center">
                      {item.isAtRisk ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          {item.isAttendanceShortage ? 'Attendance Shortage (<75%)' : 'Academic Attention'}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Good Standing
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3.5 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onOpenStudentProfile(item.enrolment.student_registration_number)}
                        className="h-7 text-xs"
                        leftIcon={<Eye className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                      >
                        Profile
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
