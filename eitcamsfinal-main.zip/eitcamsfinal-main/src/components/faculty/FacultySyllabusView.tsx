import React, { useState } from 'react';
import {
  FileCheck2,
  BookOpen,
  Download,
  CheckCircle2,
  ListOrdered,
  Layers,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { FacultyCourseAssignmentRecord } from '../../types/database';

interface FacultySyllabusViewProps {
  assignments: FacultyCourseAssignmentRecord[];
}

export function FacultySyllabusView({ assignments }: FacultySyllabusViewProps) {
  const [selectedCourseCode, setSelectedCourseCode] = useState<string>(
    assignments[0]?.course_code || 'CS201'
  );

  const syllabiData: Record<
    string,
    {
      courseTitle: string;
      credits: number;
      lectureHours: number;
      prerequisites: string;
      units: { unitNo: number; title: string; hours: number; topics: string }[];
      textbooks: string[];
      references: string[];
    }
  > = {
    CS201: {
      courseTitle: 'Data Structures and Algorithms',
      credits: 4,
      lectureHours: 45,
      prerequisites: 'CS101 (Programming for Problem Solving)',
      units: [
        {
          unitNo: 1,
          title: 'Linear Data Structures & Analysis of Algorithms',
          hours: 9,
          topics: 'Asymptotic notation (Big-O, Omega, Theta), Arrays, Dynamic Arrays, Linked Lists (Singly, Doubly, Circular), Stack and Queue ADTs, Applications in expression evaluation.',
        },
        {
          unitNo: 2,
          title: 'Trees & Hierarchical Structures',
          hours: 9,
          topics: 'Binary Trees, Binary Search Trees, Tree traversals, AVL Trees, Red-Black Trees, Priority Queues, Binary Heaps, HeapSort, Disjoint-Set Data Structures.',
        },
        {
          unitNo: 3,
          title: 'Graph Algorithms & Traversals',
          hours: 9,
          topics: 'Graph representations (Adjacency list, matrix), Breadth-First Search (BFS), Depth-First Search (DFS), Topological Sorting, Minimum Spanning Trees (Kruskal, Prim), Shortest Paths (Dijkstra, Bellman-Ford).',
        },
        {
          unitNo: 4,
          title: 'Algorithm Design Paradigms',
          hours: 9,
          topics: 'Divide and Conquer (MergeSort, QuickSort, Closest Pair), Greedy Algorithms (Fractional Knapsack, Huffman Coding), Dynamic Programming (0/1 Knapsack, LCS, Matrix Chain Multiplication).',
        },
        {
          unitNo: 5,
          title: 'Hashing & Advanced Complexity',
          hours: 9,
          topics: 'Hash tables, Collision resolution (Chaining, Open addressing), Universal hashing, String matching (KMP algorithm), Introduction to P, NP, and NP-Complete problems.',
        },
      ],
      textbooks: [
        'Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein, "Introduction to Algorithms", 4th Edition, MIT Press, 2022.',
        'Mark Allen Weiss, "Data Structures and Algorithm Analysis in C++", 4th Edition, Pearson, 2014.',
      ],
      references: [
        'Robert Sedgewick and Kevin Wayne, "Algorithms", 4th Edition, Addison-Wesley Professional, 2011.',
        'Jon Kleinberg and Éva Tardos, "Algorithm Design", Pearson, 2006.',
      ],
    },
    CS301: {
      courseTitle: 'Database Management Systems',
      credits: 4,
      lectureHours: 45,
      prerequisites: 'CS201 (Data Structures and Algorithms)',
      units: [
        {
          unitNo: 1,
          title: 'Database Architecture & ER Modeling',
          hours: 9,
          topics: 'Database system concepts, 3-Schema architecture, Data independence, Entity-Relationship (ER) model, Extended ER features, Relational data model.',
        },
        {
          unitNo: 2,
          title: 'Relational Algebra & SQL',
          hours: 9,
          topics: 'Tuple Relational Calculus, Domain Relational Calculus, Relational algebra operators, Advanced SQL, Subqueries, Joins, Triggers, Views, Embedded SQL.',
        },
        {
          unitNo: 3,
          title: 'Relational Schema Design & Normalization',
          hours: 9,
          topics: 'Functional dependencies, Normal forms (1NF, 2NF, 3NF, BCNF, 4NF), Lossless join decomposition, Dependency preservation, Multi-valued dependencies.',
        },
        {
          unitNo: 4,
          title: 'Transaction Processing & Concurrency',
          hours: 9,
          topics: 'ACID properties, Serializability, Concurrency control protocols (Two-phase locking, Timestamp ordering), Deadlock handling, Write-Ahead Logging (WAL).',
        },
        {
          unitNo: 5,
          title: 'Storage, Indexing & Query Optimization',
          hours: 9,
          topics: 'File organization, B+ Tree indexing, Hashing techniques, Query processing steps, Cost-based query evaluation, Introduction to NoSQL and distributed databases.',
        },
      ],
      textbooks: [
        'Abraham Silberschatz, Henry F. Korth, S. Sudarshan, "Database System Concepts", 7th Edition, McGraw-Hill, 2020.',
      ],
      references: [
        'Raghu Ramakrishnan and Johannes Gehrke, "Database Management Systems", 3rd Edition, McGraw-Hill, 2003.',
      ],
    },
  };

  const currentSyllabus = syllabiData[selectedCourseCode] || syllabiData['CS201'];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Curriculum Syllabi & Lecture Course Outlines</h2>
            <Badge variant="blue">Regulation 2026</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative university syllabus approved by the Academic Council and Board of Studies.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedCourseCode}
            onChange={(e) => setSelectedCourseCode(e.target.value)}
            className="text-xs py-1.5 px-3 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-[#1e3a8a] focus:outline-none focus:ring-1 focus:ring-blue-600"
          >
            {assignments.length > 0 ? (
              assignments.map((a) => (
                <option key={a.course_code} value={a.course_code}>
                  {a.course_code} — {a.course_title}
                </option>
              ))
            ) : (
              <>
                <option value="CS201">CS201 — Data Structures and Algorithms</option>
                <option value="CS301">CS301 — Database Management Systems</option>
              </>
            )}
          </select>

          <Button
            variant="outline"
            size="sm"
            leftIcon={<Download className="w-3.5 h-3.5" />}
            className="text-xs"
          >
            Syllabus PDF
          </Button>
        </div>
      </div>

      {/* Course Metadata Card */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                {selectedCourseCode}
              </span>
              <h3 className="text-base font-bold text-[#1e293b]">{currentSyllabus.courseTitle}</h3>
            </div>
            <div className="text-xs text-[#64748b] mt-1">
              Prerequisite: <strong>{currentSyllabus.prerequisites}</strong>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="text-right">
              <div className="text-[10px] text-[#64748b] uppercase">Credits</div>
              <div className="font-bold text-slate-800 text-sm">{currentSyllabus.credits} Credits</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-[#64748b] uppercase">Total Hours</div>
              <div className="font-bold text-[#1e3a8a] text-sm">{currentSyllabus.lectureHours} Lecture Hrs</div>
            </div>
          </div>
        </div>

        {/* Modules List */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Course Instructional Units (5 Units)
          </h4>
          <div className="space-y-3">
            {currentSyllabus.units.map((u) => (
              <div
                key={u.unitNo}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs text-[#1e293b]">
                    Unit {u.unitNo}: {u.title}
                  </div>
                  <Badge variant="blue">{u.hours} Hours</Badge>
                </div>
                <p className="text-xs text-[#64748b] leading-relaxed">{u.topics}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Reference Books */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-100">
          <div className="space-y-2">
            <h5 className="text-xs font-bold text-slate-700">Prescribed Textbooks:</h5>
            <ul className="text-xs text-[#64748b] space-y-1 list-disc pl-4">
              {currentSyllabus.textbooks.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h5 className="text-xs font-bold text-slate-700">Reference Literature:</h5>
            <ul className="text-xs text-[#64748b] space-y-1 list-disc pl-4">
              {currentSyllabus.references.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
