import React, { useState, useMemo } from 'react';
import {
  Contact,
  Search,
  Mail,
  Phone,
  Building2,
  MapPin,
  Filter,
} from 'lucide-react';
import { EmployeeRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';

interface FacultyDirectoryViewProps {
  employees: EmployeeRecord[];
}

export function FacultyDirectoryView({ employees }: FacultyDirectoryViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');

  const filtered = useMemo(() => {
    return employees.filter((e) => {
      if (selectedDept !== 'ALL' && e.primary_department !== selectedDept) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = `${e.first_name} ${e.last_name}`.toLowerCase().includes(q);
        const matchesDept = e.primary_department.toLowerCase().includes(q);
        const matchesDesig = e.designation.toLowerCase().includes(q);
        if (!matchesName && !matchesDept && !matchesDesig) return false;
      }
      return true;
    });
  }, [employees, selectedDept, searchQuery]);

  const depts = useMemo(() => {
    return Array.from(new Set(employees.map((e) => e.primary_department))).sort();
  }, [employees]);

  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <Contact className="w-5 h-5 text-[#1e3a8a]" />
              <span>Campus Faculty & Departmental Directory</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Contact information, institutional emails, and departmental extensions across all schools.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
            >
              <option value="ALL">All Departments</option>
              {depts.map((d) => (
                <option key={d} value={d}>
                  Department of {d}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100">
          <Input
            placeholder="Search colleagues by name, designation, or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8.5 text-xs max-w-md"
          />
        </div>
      </div>

      {/* Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((emp) => (
          <div
            key={emp.employee_id}
            className="bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-sm text-[#1e293b]">
                    {emp.first_name} {emp.last_name}
                  </h3>
                  <div className="text-xs text-[#1e3a8a] font-medium mt-0.5">{emp.designation}</div>
                  <div className="text-xs text-slate-500">Department of {emp.primary_department}</div>
                </div>
                <Badge variant={emp.category === 'TEACHING' ? 'emerald' : 'blue'}>
                  {emp.category === 'TEACHING' ? 'Faculty' : 'Staff'}
                </Badge>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="font-mono text-[11px] truncate">{emp.institutional_email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="text-[11px]">{emp.phone_number}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
