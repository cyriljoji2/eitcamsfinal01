import React from 'react';
import {
  Users,
  ShieldCheck,
  Award,
  Calendar,
  CheckCircle2,
  FileText,
  ExternalLink,
} from 'lucide-react';
import { Badge } from '../ui/Badge';

export function FacultyCommitteesView() {
  const committees = [
    {
      id: 'COMM-IQAC-2026',
      name: 'Internal Quality Assurance Cell (IQAC)',
      role: 'Member – Criterion 3 Lead (Research, Innovations & Extension)',
      convener: 'Prof. S. Ranganathan (Director IQAC)',
      tenure: '2024 – 2026',
      frequency: 'Quarterly Audit',
      responsibilities: [
        'Formulating research seed fund guidelines for junior faculty members',
        'Auditing academic course files and Continuous Assessment Test question papers',
        'Organizing faculty development sessions on outcome-based education (OBE)',
      ],
      status: 'ACTIVE',
    },
    {
      id: 'COMM-BOS-2026',
      name: 'Department Board of Studies (BoS - CSE)',
      role: 'Permanent Member',
      convener: 'Dr. अरविंद शर्मा (HoD CSE)',
      tenure: '2025 – 2028',
      frequency: 'Bi-Annual Meeting',
      responsibilities: [
        'Curriculum revision and textbook recommendations for B.Tech CSE',
        'Approving course syllabi and laboratory experiments for core computing papers',
        'Evaluation of student industry internship credits',
      ],
      status: 'ACTIVE',
    },
    {
      id: 'COMM-ANTIRAG-2026',
      name: 'Institute Anti-Ragging Flying Squad (Hostel Zone B)',
      role: 'Squad Member',
      convener: 'Prof. K. Narayanan (Chief Warden)',
      tenure: 'Academic Year 2026–2027',
      frequency: 'Weekly Surprise Rounds',
      responsibilities: [
        'Evening inspection of first-year residential blocks (Nilgiri and Sahyadri halls)',
        'Prompt incident escalation and student grievance redressal',
      ],
      status: 'ACTIVE',
    },
    {
      id: 'COMM-EXAM-2025',
      name: 'University End-Semester Examination Flying Squad',
      role: 'Chief Vigilance Officer (External Hall)',
      convener: 'Controller of Examinations (COE)',
      tenure: 'Term 2025–2026',
      frequency: 'Semester End Assessment Periods',
      responsibilities: [
        'Ensuring secure distribution of confidential examination answer booklets',
        'Preventing examination malpractice and enforcing university COE code',
      ],
      status: 'COMPLETED',
    },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Institutional & Statutory Committees</h2>
            <Badge variant="blue">{committees.length} Committee Appointments</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative faculty representation on university statutory councils, accreditation boards, and student welfare squads.
          </p>
        </div>
      </div>

      {/* Committees Grid */}
      <div className="space-y-4">
        {committees.map((c) => (
          <div
            key={c.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {c.id}
                  </span>
                  <Badge variant={c.status === 'ACTIVE' ? 'emerald' : 'default'}>
                    {c.status}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {c.frequency}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{c.name}</h3>
                <div className="text-xs text-slate-700 font-semibold">
                  Role: <span className="text-[#1e3a8a]">{c.role}</span>
                </div>
                <div className="text-xs text-[#64748b]">
                  Convener: <strong>{c.convener}</strong> &bull; Tenure: {c.tenure}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 space-y-1.5">
              <div className="text-[11px] font-semibold text-[#64748b] uppercase">Key Responsibilities:</div>
              <ul className="text-xs text-[#475569] space-y-1 list-disc pl-4">
                {c.responsibilities.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
