import React, { useState } from 'react';
import {
  Building2,
  Wrench,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface MaintenanceTicket {
  id: string;
  category: 'Electrical' | 'Plumbing' | 'Civil / Carpentry' | 'LAN / Internet';
  description: string;
  dateLogged: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'RESOLVED';
  resolutionNotes?: string;
}

export function FacultyHousingView() {
  const [tickets, setTickets] = useState<MaintenanceTicket[]>([
    {
      id: 'TKT-2026-081',
      category: 'LAN / Internet',
      description: 'Fiber optic LAN router in master study showing intermittent optical signal drops.',
      dateLogged: '2026-11-01',
      status: 'RESOLVED',
      resolutionNotes: 'Optical splice re-terminated by campus network engineering team.',
    },
    {
      id: 'TKT-2026-094',
      category: 'Plumbing',
      description: 'Balcony water tap pressure low in Block D Quarter.',
      dateLogged: '2026-11-03',
      status: 'IN_PROGRESS',
      resolutionNotes: 'Maintenance technician assigned for inspection.',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [category, setCategory] = useState<'Electrical' | 'Plumbing' | 'Civil / Carpentry' | 'LAN / Internet'>('Electrical');
  const [desc, setDesc] = useState('');

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc.trim()) return;

    const newTkt: MaintenanceTicket = {
      id: `TKT-2026-${Math.floor(100 + Math.random() * 900)}`,
      category,
      description: desc.trim(),
      dateLogged: new Date().toISOString().split('T')[0],
      status: 'PENDING',
    };

    setTickets([newTkt, ...tickets]);
    setIsModalOpen(false);
    setDesc('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Staff Quarters Allotment & Campus Maintenance Desk</h2>
            <Badge variant="blue">Faculty Housing</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Official staff residential quarters allotment details and campus estate maintenance service tickets.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Raise Service Request
        </Button>
      </div>

      {/* Quarters Allotment Card */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#1e3a8a]" />
            <h3 className="text-sm font-bold text-[#1e293b]">Residential Allotment Particulars</h3>
          </div>
          <Badge variant="emerald">Allotted & Occupied</Badge>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="text-[10px] text-[#64748b] uppercase">Quarter Designation</div>
            <div className="font-bold text-slate-800 text-sm mt-0.5">Type-V (Quarter D-402)</div>
          </div>
          <div>
            <div className="text-[10px] text-[#64748b] uppercase">Residential Block</div>
            <div className="font-semibold text-slate-800 mt-0.5">Kaveri Staff Enclave</div>
          </div>
          <div>
            <div className="text-[10px] text-[#64748b] uppercase">Allotment Date</div>
            <div className="font-mono text-slate-700 mt-0.5">2023-08-15</div>
          </div>
          <div>
            <div className="text-[10px] text-[#64748b] uppercase">Estate In-Charge</div>
            <div className="text-slate-700 mt-0.5">EIT Campus Works Dept</div>
          </div>
        </div>
      </div>

      {/* Maintenance Tickets Section */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Wrench className="w-4 h-4 text-[#1e3a8a]" />
            <span>Campus Maintenance & Service Work Orders</span>
          </span>
          <span className="text-xs text-[#64748b] font-normal">{tickets.length} Registered Tickets</span>
        </h3>

        <div className="space-y-3">
          {tickets.map((t) => (
            <div
              key={t.id}
              className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2 hover:border-slate-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {t.id}
                  </span>
                  <Badge
                    variant={
                      t.status === 'RESOLVED'
                        ? 'emerald'
                        : t.status === 'IN_PROGRESS'
                        ? 'amber'
                        : 'blue'
                    }
                  >
                    {t.status.replace(/_/g, ' ')}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-200/70 px-2 py-0.5 rounded">
                    {t.category}
                  </span>
                </div>

                <div className="text-[11px] text-[#64748b] font-mono">{t.dateLogged}</div>
              </div>

              <p className="text-xs text-[#1e293b]">{t.description}</p>

              {t.resolutionNotes && (
                <div className="pt-2 border-t border-slate-200 text-[11px] text-[#64748b] flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Update: <em>"{t.resolutionNotes}"</em></span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Raise Estate Maintenance Request</h3>
            <p className="text-xs text-[#64748b]">
              Submit repair or maintenance service order for your staff quarters.
            </p>

            <form onSubmit={handleCreateTicket} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Service Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="Electrical">Electrical (Power / Fixtures / AC)</option>
                  <option value="Plumbing">Plumbing (Water supply / Drainage / Taps)</option>
                  <option value="Civil / Carpentry">Civil / Carpentry (Doors / Windows / Painting)</option>
                  <option value="LAN / Internet">LAN / Internet (Campus Optical Fiber)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Issue Description</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe the nature and location of the required repair..."
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Submit Work Order
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
