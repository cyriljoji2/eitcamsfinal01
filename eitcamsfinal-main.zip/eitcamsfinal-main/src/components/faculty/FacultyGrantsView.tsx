import React, { useState } from 'react';
import {
  Layers,
  Plus,
  DollarSign,
  Calendar,
  Building,
  CheckCircle2,
  Clock,
  ExternalLink,
  Filter,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface ResearchGrant {
  id: string;
  projectTitle: string;
  fundingAgency: string;
  sanctionOrderNo: string;
  sanctionAmount: number;
  durationMonths: number;
  startDate: string;
  endDate: string;
  investigatorRole: 'Principal Investigator (PI)' | 'Co-Principal Investigator (Co-PI)';
  status: 'ACTIVE' | 'COMPLETED' | 'SUBMITTED_UNDER_REVIEW';
}

export function FacultyGrantsView() {
  const [grants, setGrants] = useState<ResearchGrant[]>([
    {
      id: 'GRANT-2025-01',
      projectTitle: 'Fault-Tolerant Distributed Consensus in Edge Computing IoT Networks',
      fundingAgency: 'Science and Engineering Research Board (SERB - CRG)',
      sanctionOrderNo: 'CRG/2025/004912',
      sanctionAmount: 3850000,
      durationMonths: 36,
      startDate: '2025-04-01',
      endDate: '2028-03-31',
      investigatorRole: 'Principal Investigator (PI)',
      status: 'ACTIVE',
    },
    {
      id: 'GRANT-2024-02',
      projectTitle: 'Automated Micro-Architecture Security Verification Using Formal Methods',
      fundingAgency: 'Department of Science and Technology (DST) & Intel Labs',
      sanctionOrderNo: 'DST/INTEL/2024/098',
      sanctionAmount: 2200000,
      durationMonths: 24,
      startDate: '2024-06-15',
      endDate: '2026-06-14',
      investigatorRole: 'Co-Principal Investigator (Co-PI)',
      status: 'ACTIVE',
    },
    {
      id: 'GRANT-2023-01',
      projectTitle: 'Graph Neural Networks for Resilient Power Grid Anomaly Classification',
      fundingAgency: 'EIT Seed Research Fund',
      sanctionOrderNo: 'EIT/SRF/2023/11',
      sanctionAmount: 500000,
      durationMonths: 18,
      startDate: '2023-01-01',
      endDate: '2024-06-30',
      investigatorRole: 'Principal Investigator (PI)',
      status: 'COMPLETED',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [agency, setAgency] = useState('');
  const [sanctionNo, setSanctionNo] = useState('');
  const [amount, setAmount] = useState('');
  const [role, setRole] = useState<'Principal Investigator (PI)' | 'Co-Principal Investigator (Co-PI)'>('Principal Investigator (PI)');
  const [duration, setDuration] = useState('36');

  const totalSanctioned = grants.reduce((sum, g) => sum + g.sanctionAmount, 0);
  const activeCount = grants.filter((g) => g.status === 'ACTIVE').length;

  const handleAddGrant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !agency.trim()) return;

    const newGrant: ResearchGrant = {
      id: `GRANT-${Date.now().toString().slice(-4)}`,
      projectTitle: title.trim(),
      fundingAgency: agency.trim(),
      sanctionOrderNo: sanctionNo.trim() || `SAN-${Date.now()}`,
      sanctionAmount: Number(amount) || 1000000,
      durationMonths: Number(duration) || 24,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + (Number(duration) || 24) * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      investigatorRole: role,
      status: 'ACTIVE',
    };

    setGrants([newGrant, ...grants]);
    setIsModalOpen(false);
    setTitle('');
    setAgency('');
    setSanctionNo('');
    setAmount('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Sponsored Research Grants & Funded Projects</h2>
            <Badge variant="blue">{grants.length} Projects</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional portfolio of sponsored research schemes, government agency funding, and industrial consultancies.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Record Grant Proposal
        </Button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Total Sanctioned Value</div>
          <div className="text-xl font-bold text-[#1e3a8a] mt-1">
            ₹{(totalSanctioned / 100000).toFixed(2)} Lakhs
          </div>
          <div className="text-[11px] text-emerald-600 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Audited & Formally Disbursed</span>
          </div>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Active Research Grants</div>
          <div className="text-xl font-bold text-emerald-700 mt-1">{activeCount} Ongoing Projects</div>
          <div className="text-[11px] text-[#64748b] mt-1">With live project staff & scholars</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Primary Funding Bodies</div>
          <div className="text-xs font-bold text-slate-800 mt-1.5 truncate">
            SERB, DST, Intel Labs, EIT Seed Fund
          </div>
          <div className="text-[11px] text-[#64748b] mt-1">Institutional R&D compliance</div>
        </div>
      </div>

      {/* Grants List */}
      <div className="space-y-4">
        {grants.map((grant) => (
          <div
            key={grant.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {grant.id}
                  </span>
                  <Badge variant={grant.status === 'ACTIVE' ? 'emerald' : 'default'}>
                    {grant.status === 'ACTIVE' ? 'Ongoing Project' : 'Completed Project'}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {grant.investigatorRole}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{grant.projectTitle}</h3>
                <div className="text-xs text-[#64748b] flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-slate-700">{grant.fundingAgency}</span>
                  <span>&bull;</span>
                  <span className="font-mono text-[11px]">Sanction No: {grant.sanctionOrderNo}</span>
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Sanctioned Budget</div>
                <div className="text-base font-bold text-[#1e3a8a]">
                  ₹{(grant.sanctionAmount).toLocaleString('en-IN')}
                </div>
                <div className="text-[11px] text-slate-500">{grant.durationMonths} Months Duration</div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Tenure: {grant.startDate} to {grant.endDate}</span>
              </div>
              <div className="flex items-center gap-1 text-blue-600 hover:text-blue-800 cursor-pointer font-medium">
                <span>View Sanction Order</span>
                <ExternalLink className="w-3 h-3" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Record Grant Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Record Funded Research Project</h3>
            <p className="text-xs text-[#64748b]">
              Submit details of sanctioned external research grant or institutional seed project.
            </p>

            <form onSubmit={handleAddGrant} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Project Title</label>
                <Input
                  required
                  placeholder="e.g., Scalable AI for Autonomous Power Systems"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Funding Agency</label>
                  <Input
                    required
                    placeholder="e.g., SERB, DST, ISRO"
                    value={agency}
                    onChange={(e) => setAgency(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Sanction Order No.</label>
                  <Input
                    placeholder="e.g., SERB/CRG/2026/012"
                    value={sanctionNo}
                    onChange={(e) => setSanctionNo(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Sanctioned Amount (₹)</label>
                  <Input
                    type="number"
                    required
                    placeholder="e.g., 2500000"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Duration (Months)</label>
                  <Input
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Faculty Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="Principal Investigator (PI)">Principal Investigator (PI)</option>
                  <option value="Co-Principal Investigator (Co-PI)">Co-Principal Investigator (Co-PI)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Save Grant Record
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
