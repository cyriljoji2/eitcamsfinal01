import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Car,
  Users,
  Plus,
  KeyRound,
  FileCheck2,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultySecurityApprovalsViewProps {
  onNavigateSubtab?: (tab: string) => void;
}

export function FacultySecurityApprovalsView({ onNavigateSubtab }: FacultySecurityApprovalsViewProps) {
  const [vehicleStickers, setVehicleStickers] = useState([
    {
      id: 'VEH-2026-091',
      vehicleType: 'Four Wheeler (Car)',
      regNumber: 'TN 09 BX 4912',
      model: 'Honda City ZX',
      tagId: 'RFID-EIT-F-0912',
      gateAccess: 'All Campus Security Gates (RFID Automated)',
      status: 'ACTIVE_RFID',
    },
  ]);

  const [visitorPasses, setVisitorPasses] = useState([
    {
      id: 'VP-2026-104',
      visitorName: 'Dr. John Mathew',
      affiliation: 'IIT Madras (External Ph.D. Examiner)',
      dateOfVisit: '2026-11-15',
      timeSlot: '10:00 AM – 04:00 PM',
      purpose: 'Doctoral Defense Evaluation',
      status: 'GATE_PRE_CLEARED',
    },
  ]);

  const [isVisitorModalOpen, setIsVisitorModalOpen] = useState(false);
  const [vName, setVName] = useState('');
  const [vAffil, setVAffil] = useState('');
  const [vDate, setVDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [vPurpose, setVPurpose] = useState('');

  const handleAddVisitor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!vName.trim()) return;

    const newPass = {
      id: `VP-2026-${Math.floor(100 + Math.random() * 900)}`,
      visitorName: vName.trim(),
      affiliation: vAffil.trim() || 'Academic Visitor',
      dateOfVisit: vDate,
      timeSlot: '09:00 AM – 06:00 PM',
      purpose: vPurpose.trim() || 'Academic Discussion',
      status: 'GATE_PRE_CLEARED',
    };

    setVisitorPasses([newPass, ...visitorPasses]);
    setIsVisitorModalOpen(false);
    setVName('');
    setVAffil('');
    setVPurpose('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Security Clearances & Campus Access Approvals</h2>
            <Badge variant="blue">Faculty Security Desk</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Faculty gate passes, vehicle RFID stickers, visitor entry authorizations, and security endorsements.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateSubtab && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateSubtab('lab-access')}
                className="text-xs"
              >
                Lab Access Clearances
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => onNavigateSubtab('event-clearance')}
                className="text-xs bg-[#1e3a8a] text-white"
              >
                Event Permissions
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Grid: Vehicle Tags & Visitors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Faculty Campus Vehicle Clearances */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Car className="w-4 h-4 text-[#1e3a8a]" />
              <span>Campus Vehicle RFID Tags</span>
            </h3>
            <Badge variant="emerald">1 Tag Active</Badge>
          </div>

          <div className="space-y-3">
            {vehicleStickers.map((v) => (
              <div
                key={v.id}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                      {v.regNumber}
                    </span>
                    <h4 className="text-xs font-bold text-[#1e293b] mt-1.5">{v.model}</h4>
                    <div className="text-xs text-[#64748b]">{v.vehicleType}</div>
                  </div>
                  <Badge variant="emerald">RFID Automated</Badge>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-[#64748b]">
                  <span>Tag: <strong className="font-mono text-slate-700">{v.tagId}</strong></span>
                  <span className="text-slate-500">{v.gateAccess}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pre-Cleared Visitor Entry Passes */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <Users className="w-4 h-4 text-[#1e3a8a]" />
              <span>Visitor Gate Pre-Clearances</span>
            </h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsVisitorModalOpen(true)}
              leftIcon={<Plus className="w-3.5 h-3.5" />}
              className="text-xs h-7"
            >
              Issue Gate Pass
            </Button>
          </div>

          <div className="space-y-3">
            {visitorPasses.map((vp) => (
              <div
                key={vp.id}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-1.5"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                      {vp.id}
                    </span>
                    <h4 className="text-xs font-bold text-[#1e293b] mt-1">{vp.visitorName}</h4>
                    <div className="text-xs text-[#64748b]">{vp.affiliation}</div>
                  </div>
                  <Badge variant="emerald">Pre-Approved</Badge>
                </div>

                <div className="text-xs text-slate-700 font-medium pt-1">
                  Purpose: <em>{vp.purpose}</em>
                </div>

                <div className="pt-1.5 border-t border-slate-200 text-[11px] text-[#64748b] flex items-center justify-between">
                  <span>Visit Date: <strong>{vp.dateOfVisit}</strong></span>
                  <span>{vp.timeSlot}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal */}
      {isVisitorModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Issue Security Gate Pre-Clearance</h3>
            <p className="text-xs text-[#64748b]">
              Authorize smooth vehicle and campus entry for your visiting academic guest.
            </p>

            <form onSubmit={handleAddVisitor} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Visitor Full Name</label>
                <Input
                  required
                  placeholder="e.g., Prof. Anand Krishna"
                  value={vName}
                  onChange={(e) => setVName(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Affiliation / Institution</label>
                <Input
                  required
                  placeholder="e.g., IISc Bangalore / Microsoft Research"
                  value={vAffil}
                  onChange={(e) => setVAffil(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Visit Date</label>
                <Input
                  type="date"
                  required
                  value={vDate}
                  onChange={(e) => setVDate(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Purpose of Visit</label>
                <Input
                  required
                  placeholder="e.g., Project Evaluation / Technical Lecture"
                  value={vPurpose}
                  onChange={(e) => setVPurpose(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsVisitorModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Send to Security Gate
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
