import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Users,
  Search,
  Filter,
  Eye,
  CalendarCheck,
  GraduationCap,
  Layers,
  ChevronRight,
  Sparkles,
  X,
  FileText,
  Mail,
  Phone,
  CheckCircle2,
} from 'lucide-react';
import {
  CourseEnrolmentRecord,
  CourseRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
} from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyCoursesViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  courses: CourseRecord[];
  students: StudentRecord[];
  enrolments: CourseEnrolmentRecord[];
  onOpenStudentProfile: (regNo: string) => void;
  onNavigateTab: (tabId: string) => void;
}

export function FacultyCoursesView({
  assignments,
  courses,
  students,
  enrolments,
  onOpenStudentProfile,
  onNavigateTab,
}: FacultyCoursesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSemester, setSelectedSemester] = useState<string>('ALL');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [selectedAssignment, setSelectedAssignment] = useState<FacultyCourseAssignmentRecord | null>(null);
  const [activeModal, setActiveModal] = useState<'roster' | 'details' | null>(null);

  // Filter assignments
  const filteredAssignments = useMemo(() => {
    return assignments.filter((asg) => {
      if (selectedSemester !== 'ALL' && String(asg.semester) !== selectedSemester) {
        return false;
      }
      if (selectedSection !== 'ALL' && asg.section !== selectedSection) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesCode = asg.course_code.toLowerCase().includes(q);
        const matchesTitle = asg.course_title.toLowerCase().includes(q);
        const matchesDept = asg.department.toLowerCase().includes(q);
        if (!matchesCode && !matchesTitle && !matchesDept) return false;
      }
      return true;
    });
  }, [assignments, selectedSemester, selectedSection, searchQuery]);

  // Unique semesters and sections for filter
  const semesterOptions = useMemo(() => {
    return Array.from(new Set(assignments.map((a) => String(a.semester)))).sort();
  }, [assignments]);

  const sectionOptions = useMemo(() => {
    return Array.from(new Set(assignments.map((a) => a.section))).sort();
  }, [assignments]);

  // Enrolled students for selected assignment
  const selectedCourseRoster = useMemo(() => {
    if (!selectedAssignment) return [];
    const courseEnrs = enrolments.filter(
      (e) =>
        e.course_code === selectedAssignment.course_code &&
        e.section === selectedAssignment.section &&
        e.enrolment_status === 'ACTIVE'
    );

    return courseEnrs
      .map((enr) => {
        const stu = students.find((s) => s.student_id === enr.student_id);
        return {
          enrolment: enr,
          student: stu,
        };
      })
      .filter((item) => item.student !== undefined);
  }, [selectedAssignment, enrolments, students]);

  // Full course master object for selected course
  const selectedCourseMaster = useMemo(() => {
    if (!selectedAssignment) return null;
    return courses.find((c) => c.course_code === selectedAssignment.course_code) || null;
  }, [selectedAssignment, courses]);

  return (
    <div className="space-y-6">
      {/* Header & Filter Controls */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#1e3a8a]" />
              <span>My Courses & Teaching Sections</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Authorized course and section allocations assigned by the Academic Office ({assignments.length} Total).
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Academic Authority:</span>
            <Badge variant="blue">Academic Office</Badge>
          </div>
        </div>

        {/* Search & Select Bars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <Input
              placeholder="Search course code or title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 text-xs"
            />
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-[#64748b] whitespace-nowrap">Semester:</label>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value)}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              <option value="ALL">All Semesters</option>
              {semesterOptions.map((sem) => (
                <option key={sem} value={sem}>
                  Semester {sem}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-[#64748b] whitespace-nowrap">Section:</label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              <option value="ALL">All Sections</option>
              {sectionOptions.map((sec) => (
                <option key={sec} value={sec}>
                  Section {sec}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Courses Grid */}
      {filteredAssignments.length === 0 ? (
        <div className="bg-white border border-[#e2e8f0] p-12 rounded-2xl text-center text-xs text-[#94a3b8] space-y-2">
          <BookOpen className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="font-medium text-slate-700">No matching teaching assignments found.</p>
          <p>Verify search filters or contact the Academic Office for course allocation adjustments.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredAssignments.map((asg) => {
            const courseMaster = courses.find((c) => c.course_code === asg.course_code);
            const courseEnrs = enrolments.filter(
              (e) =>
                e.course_code === asg.course_code &&
                e.section === asg.section &&
                e.enrolment_status === 'ACTIVE'
            );

            return (
              <div
                key={asg.faculty_assignment_id}
                className="bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-4 hover:border-blue-300 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] px-2.5 py-1 rounded-lg border border-blue-100">
                      {asg.course_code}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800 border border-slate-200">
                        Sec {asg.section}
                      </span>
                      <Badge variant="emerald">Active</Badge>
                    </div>
                  </div>

                  <h2 className="text-sm font-bold text-[#1e293b] mt-3 leading-snug">
                    {asg.course_title}
                  </h2>
                  <p className="text-xs text-[#64748b] mt-1">
                    Department of {asg.department} &bull; Semester {asg.semester}
                  </p>

                  <div className="flex items-center gap-2 mt-2.5 text-[11px] text-slate-600">
                    <span className="bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                      Credits: <strong>{courseMaster?.credits ?? 4}</strong>
                    </span>
                    <span className="bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                      Role: <strong>{asg.role_in_course}</strong>
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#64748b]">Enrolled Strength:</span>
                    <strong className="text-[#1e3a8a] font-bold">
                      {courseEnrs.length} Students
                    </strong>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedAssignment(asg);
                        setActiveModal('roster');
                      }}
                      className="text-xs h-8"
                      leftIcon={<Users className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                    >
                      View Roster
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedAssignment(asg);
                        setActiveModal('details');
                      }}
                      className="text-xs h-8 text-slate-700 hover:bg-slate-100"
                      leftIcon={<FileText className="w-3.5 h-3.5" />}
                    >
                      Syllabus
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Roster Modal */}
      {activeModal === 'roster' && selectedAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded">
                    {selectedAssignment.course_code}
                  </span>
                  <Badge variant="blue">Section {selectedAssignment.section}</Badge>
                </div>
                <h3 className="text-base font-bold text-[#1e293b] mt-1">
                  Enrolled Class Roster &bull; {selectedAssignment.course_title}
                </h3>
                <p className="text-xs text-[#64748b]">
                  Showing {selectedCourseRoster.length} students officially registered for this section.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Table */}
            <div className="flex-1 overflow-y-auto p-5">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0] sticky top-0">
                  <tr>
                    <th className="py-2.5 px-3.5 font-semibold">Reg. No.</th>
                    <th className="py-2.5 px-3.5 font-semibold">Student Name</th>
                    <th className="py-2.5 px-3.5 font-semibold">Programme & Sem</th>
                    <th className="py-2.5 px-3.5 font-semibold">Institutional Email</th>
                    <th className="py-2.5 px-3.5 font-semibold">Enrolment Date</th>
                    <th className="py-2.5 px-3.5 font-semibold text-right">Academic Profile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {selectedCourseRoster.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-[#94a3b8]">
                        No active enrolments recorded for this section.
                      </td>
                    </tr>
                  ) : (
                    selectedCourseRoster.map(({ enrolment, student }) => (
                      <tr key={enrolment.enrolment_id} className="hover:bg-[#f8fafc]">
                        <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                          {enrolment.student_registration_number}
                        </td>
                        <td className="py-2.5 px-3.5 font-bold text-[#1e293b]">
                          {student?.first_name} {student?.last_name}
                        </td>
                        <td className="py-2.5 px-3.5 text-[#64748b]">
                          {student?.program_name || student?.department || enrolment.department} &bull; Sem {enrolment.semester}
                        </td>
                        <td className="py-2.5 px-3.5 text-slate-600 font-mono text-[11px]">
                          {student?.institutional_email || `${enrolment.student_registration_number.toLowerCase()}@eit.edu`}
                        </td>
                        <td className="py-2.5 px-3.5 text-[#64748b]">
                          {enrolment.enrolled_at?.split('T')[0] || '2026-08-01'}
                        </td>
                        <td className="py-2.5 px-3.5 text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              onOpenStudentProfile(enrolment.student_registration_number);
                            }}
                            className="h-7 text-xs"
                            leftIcon={<Eye className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                          >
                            Profile
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
              <span className="text-[#64748b]">
                Total Enrolled: <strong>{selectedCourseRoster.length}</strong> students
              </span>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setActiveModal(null);
                    onNavigateTab('attendance');
                  }}
                  className="text-xs"
                  leftIcon={<CalendarCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                >
                  Mark Attendance
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => setActiveModal(null)}
                  className="text-xs"
                >
                  Done
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Course Details / Syllabus Modal */}
      {activeModal === 'details' && selectedAssignment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between border-b pb-4 border-slate-100">
              <div>
                <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] px-2.5 py-1 rounded">
                  {selectedAssignment.course_code}
                </span>
                <h3 className="text-base font-bold text-[#1e293b] mt-1.5">
                  {selectedAssignment.course_title}
                </h3>
                <p className="text-xs text-[#64748b]">
                  Department of {selectedAssignment.department} &bull; Credits: {selectedCourseMaster?.credits ?? 4}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-1">
                <span className="font-bold text-[#1e293b]">Course Description & Objectives</span>
                <p className="text-slate-600 leading-relaxed">
                  Comprehensive university course covering theoretical foundations, algorithmic complexity,
                  practical software implementations, and laboratory demonstrations.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0]">
                  <span className="text-[#64748b] block text-[11px]">Evaluation Scheme</span>
                  <span className="font-semibold text-slate-800">CIA: 50% &bull; FAT: 50%</span>
                </div>
                <div className="p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0]">
                  <span className="text-[#64748b] block text-[11px]">Contact Hours / Week</span>
                  <span className="font-semibold text-slate-800">3 Lectures + 1 Tutorial / Lab</span>
                </div>
              </div>

              <div className="p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] space-y-1">
                <span className="font-bold text-[#1e293b]">Course Learning Outcomes (CLOs)</span>
                <ul className="list-disc list-inside text-slate-600 space-y-1 pl-1">
                  <li>CLO 1: Formulate and analyze mathematical complexity of algorithms.</li>
                  <li>CLO 2: Implement robust data structures for efficient indexing and searching.</li>
                  <li>CLO 3: Evaluate graph traversal strategies and optimal path computations.</li>
                </ul>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button
                variant="primary"
                size="sm"
                onClick={() => setActiveModal(null)}
                className="text-xs"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
