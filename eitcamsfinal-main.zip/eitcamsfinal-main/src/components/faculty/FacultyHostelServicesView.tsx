import React from 'react';
import {
  Building2,
  Phone,
  Bus,
  ShieldAlert,
  Clock,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyHostelServicesViewProps {
  onNavigateSubtab?: (tab: string) => void;
}

export function FacultyHostelServicesView({ onNavigateSubtab }: FacultyHostelServicesViewProps) {
  const wardenContacts = [
    {
      block: 'Nilgiri Men’s Hall (Block A & B)',
      chiefWarden: 'Prof. K. Narayanan (Chief Warden)',
      residentWarden: 'Dr. S. Sivakumar',
      phone: '+91 98401 54321',
      intercom: 'Ext. 6101',
      emergencyDuty: 'Active Night Duty',
    },
    {
      block: 'Sahyadri Women’s Hall (Block C & D)',
      chiefWarden: 'Prof. K. Narayanan (Chief Warden)',
      residentWarden: 'Dr. Ananya Sen',
      phone: '+91 98401 54322',
      intercom: 'Ext. 6201',
      emergencyDuty: 'Active Night Duty',
    },
  ];

  const shuttleTimings = [
    { route: 'North Campus Staff Enclave &rarr; Main Academic Block', timings: '08:15, 08:45, 09:15 AM', frequency: 'Every 30 mins' },
    { route: 'Main Academic Block &rarr; Central Research Park & Library', timings: 'Every 15 mins (09:00 AM – 06:00 PM)', frequency: 'Continuous Circuit' },
    { route: 'Main Gate &rarr; Metro Station Shuttle Service', timings: '05:15, 05:45, 06:15, 07:00 PM', frequency: 'Evening Transit' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Campus Residential & Hostel Services</h2>
            <Badge variant="blue">Campus Support Desk</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Faculty residential quarters assistance, student hostel warden coordination, and campus transit shuttle networks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateSubtab && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateSubtab('faculty-housing')}
                className="text-xs"
              >
                Staff Quarters Desk
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => onNavigateSubtab('guest-house')}
                className="text-xs bg-[#1e3a8a] text-white"
              >
                Book Guest House
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Grid: Warden Contacts & Transit */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hostel Warden Emergency Contacts */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#1e3a8a]" />
            <span>Hostel Administration & Warden Duty Desk</span>
          </h3>
          <p className="text-xs text-[#64748b]">
            Direct contacts for faculty proctors coordinating medical emergency clearances or night-time hostel visits.
          </p>

          <div className="space-y-3">
            {wardenContacts.map((w, i) => (
              <div
                key={i}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-[#1e293b]">{w.block}</h4>
                    <div className="text-xs text-[#64748b]">{w.residentWarden} (Resident Warden)</div>
                  </div>
                  <Badge variant="emerald">{w.emergencyDuty}</Badge>
                </div>

                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-700">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-mono font-semibold">{w.phone}</span>
                  </div>
                  <span className="font-mono text-slate-500">{w.intercom}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Campus Transport & Shuttles */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
            <Bus className="w-4 h-4 text-[#1e3a8a]" />
            <span>Campus Transit & Faculty Shuttle Schedule</span>
          </h3>
          <p className="text-xs text-[#64748b]">
            Eco-friendly campus electric shuttle service operating across academic, residential, and transit zones.
          </p>

          <div className="space-y-3">
            {shuttleTimings.map((s, i) => (
              <div
                key={i}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div
                    className="font-bold text-xs text-[#1e293b]"
                    dangerouslySetInnerHTML={{ __html: s.route }}
                  />
                  <Badge variant="blue">{s.frequency}</Badge>
                </div>
                <div className="text-xs text-[#64748b] flex items-center gap-1.5 pt-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timings: {s.timings}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
