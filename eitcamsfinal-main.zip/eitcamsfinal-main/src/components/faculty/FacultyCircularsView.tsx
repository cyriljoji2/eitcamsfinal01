import React, { useState } from 'react';
import {
  Megaphone,
  Calendar,
  Download,
  Search,
  ExternalLink,
  FileText,
  Building,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

export function FacultyCircularsView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const circulars = [
    {
      id: 'CIRC-REG-2026-089',
      title: 'Winter Vacation Academic Calendar & End-Semester Grading Timeline',
      issuingOffice: 'Office of the Registrar',
      date: '2026-11-02',
      category: 'Academic',
      summary: 'All faculty members must complete continuous internal evaluation and submit draft marks to COE by December 10, 2026.',
      isUrgent: true,
      refNumber: 'EIT/REG/ACAD/2026/89',
    },
    {
      id: 'CIRC-DEAN-2026-042',
      title: 'Call for Proposals: EIT Seed Research Grants (Cycle 2, 2026–27)',
      issuingOffice: 'Dean (Research & Development)',
      date: '2026-10-25',
      category: 'Research',
      summary: 'Proposals invited for faculty seed research funding up to ₹5.00 Lakhs in thrust areas of computing and renewable electronics.',
      isUrgent: false,
      refNumber: 'EIT/DEAN-RND/2026/042',
    },
    {
      id: 'CIRC-COE-2026-104',
      title: 'Guidelines for Confidential Question Paper Setting — Fall 2026 End-Semester Examinations',
      issuingOffice: 'Controller of Examinations (COE)',
      date: '2026-10-18',
      category: 'Examination',
      summary: 'Mandatory Bloom taxonomy compliance, 3-tier moderation, and electronic submission deadlines for course instructors.',
      isUrgent: true,
      refNumber: 'COE/EIT/NOTIF/2026/104',
    },
    {
      id: 'CIRC-EST-2026-015',
      title: 'Institutional Medical Insurance Renewal & Family Dependent Enrollment',
      issuingOffice: 'Human Resources & Administration',
      date: '2026-10-10',
      category: 'Administrative',
      summary: 'Faculty members are requested to review and verify cashless hospital network listings and submit dependent declarations.',
      isUrgent: false,
      refNumber: 'EIT/HR/MED/2026/15',
    },
  ];

  const filteredCirculars = circulars.filter((c) => {
    if (categoryFilter !== 'ALL' && c.category !== categoryFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!c.title.toLowerCase().includes(q) && !c.refNumber.toLowerCase().includes(q) && !c.summary.toLowerCase().includes(q)) {
        return false;
      }
    }
    return true;
  });

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Official Circulars, Notifications & Memoranda</h2>
            <Badge variant="blue">{circulars.length} Active Circulars</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative university announcements from the Registrar, Academic Office, COE, and Dean of Research.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search circulars by subject, keyword or reference order..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2">
          {['ALL', 'Academic', 'Research', 'Examination', 'Administrative'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${
                categoryFilter === cat
                  ? 'bg-[#1e3a8a] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'ALL' ? 'All Notices' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Circulars List */}
      <div className="space-y-4">
        {filteredCirculars.map((circ) => (
          <div
            key={circ.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {circ.refNumber}
                  </span>
                  <Badge variant={circ.isUrgent ? 'amber' : 'default'}>
                    {circ.category}
                  </Badge>
                  {circ.isUrgent && (
                    <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                      High Priority
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{circ.title}</h3>
                <p className="text-xs text-[#64748b]">{circ.summary}</p>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Issuing Authority</div>
                <div className="text-xs font-bold text-slate-800">{circ.issuingOffice}</div>
                <div className="text-[11px] text-slate-500">{circ.date}</div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Published on {circ.date} &bull; Legally Binding Institutional Notice</span>
              </div>
              <div className="flex items-center gap-1 text-blue-600 hover:text-blue-800 cursor-pointer font-medium">
                <Download className="w-3 h-3" />
                <span>Download Gazette Copy (PDF)</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
