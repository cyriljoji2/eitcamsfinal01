import React, { useState, useMemo } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Filter,
  Save,
  RotateCcw,
  AlertCircle,
  AlertTriangle,
  History,
  FileCheck2,
  Users,
  Check,
  X,
  Edit3,
} from 'lucide-react';
import {
  AttendanceRecord,
  AttendanceStatus,
  CourseEnrolmentRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
} from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyAttendanceViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  students: StudentRecord[];
  enrolments: CourseEnrolmentRecord[];
  attendanceRecords: AttendanceRecord[];
  facultyId: string;
  facultyName: string;
  onRecordAttendance: (data: {
    student_id: string;
    registration_number: string;
    course_code: string;
    section: string;
    date: string;
    session_slot: number;
    status: AttendanceStatus;
    remarks?: string;
  }) => Promise<AttendanceRecord>;
  onCorrectAttendance?: (
    attendanceId: string,
    status: AttendanceStatus,
    reason: string
  ) => Promise<AttendanceRecord>;
  onRefreshData?: () => Promise<void>;
}

export function FacultyAttendanceView({
  assignments,
  students,
  enrolments,
  attendanceRecords,
  facultyId,
  facultyName,
  onRecordAttendance,
  onCorrectAttendance,
  onRefreshData,
}: FacultyAttendanceViewProps) {
  const [activeTab, setActiveTab] = useState<'take' | 'history'>('take');

  // Selection states
  const [selectedCourseCode, setSelectedCourseCode] = useState<string>(
    assignments[0]?.course_code || ''
  );
  const [selectedSection, setSelectedSection] = useState<string>(
    assignments[0]?.section || 'A'
  );
  const [attendanceDate, setAttendanceDate] = useState<string>(
    () => new Date().toISOString().split('T')[0]
  );
  const [sessionSlot, setSessionSlot] = useState<number>(1);
  const [attendanceRemarks, setAttendanceRemarks] = useState<string>('');

  // Attendance status mapping for students: student_id -> AttendanceStatus
  const [studentStatuses, setStudentStatuses] = useState<Record<string, AttendanceStatus>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Correction Modal State
  const [correctingRecord, setCorrectingRecord] = useState<AttendanceRecord | null>(null);
  const [revisedStatus, setRevisedStatus] = useState<AttendanceStatus>(AttendanceStatus.PRESENT);
  const [correctionReason, setCorrectionReason] = useState<string>('');
  const [isSavingCorrection, setIsSavingCorrection] = useState(false);
  const [correctionError, setCorrectionError] = useState<string | null>(null);

  // Search filter
  const [searchRoster, setSearchRoster] = useState('');

  // Active assignment object
  const activeAssignment = useMemo(() => {
    return assignments.find(
      (a) => a.course_code === selectedCourseCode && a.section === selectedSection
    );
  }, [assignments, selectedCourseCode, selectedSection]);

  // Enrolled students for selected course & section
  const roster = useMemo(() => {
    const courseEnrs = enrolments.filter(
      (e) =>
        e.course_code === selectedCourseCode &&
        e.section === selectedSection &&
        e.enrolment_status === 'ACTIVE'
    );

    return courseEnrs
      .map((enr) => {
        const student = students.find((s) => s.student_id === enr.student_id);
        return {
          enrolment: enr,
          student,
        };
      })
      .filter((item) => item.student !== undefined)
      .sort((a, b) => (a.student!.first_name || '').localeCompare(b.student!.first_name || ''));
  }, [enrolments, selectedCourseCode, selectedSection, students]);

  // Filtered roster by search
  const filteredRoster = useMemo(() => {
    if (!searchRoster.trim()) return roster;
    const q = searchRoster.toLowerCase();
    return roster.filter(
      (r) =>
        r.student!.registration_number.toLowerCase().includes(q) ||
        `${r.student!.first_name} ${r.student!.last_name}`.toLowerCase().includes(q)
    );
  }, [roster, searchRoster]);

  // Check if attendance already recorded for this exact date, course, section, and slot
  const existingRecordedAttendance = useMemo(() => {
    return attendanceRecords.filter(
      (a) =>
        a.course_code === selectedCourseCode &&
        a.date === attendanceDate &&
        String(a.session_slot) === String(sessionSlot)
    );
  }, [attendanceRecords, selectedCourseCode, attendanceDate, sessionSlot]);

  const isAlreadyRecorded = existingRecordedAttendance.length > 0;

  // Set default status to PRESENT for all when roster changes
  const handleMarkAll = (status: AttendanceStatus) => {
    const updated: Record<string, AttendanceStatus> = {};
    for (const item of roster) {
      updated[item.student!.student_id] = status;
    }
    setStudentStatuses(updated);
  };

  const handleStudentStatusChange = (studentId: string, status: AttendanceStatus) => {
    setStudentStatuses((prev) => ({
      ...prev,
      [studentId]: status,
    }));
  };

  // Submit attendance roll-call
  const handleSubmitAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAssignment) return;
    if (roster.length === 0) {
      setFeedbackMsg({ type: 'error', text: 'No students enrolled in this section to record attendance.' });
      return;
    }
    if (isAlreadyRecorded) {
      setFeedbackMsg({
        type: 'error',
        text: `Attendance for ${selectedCourseCode} (Slot ${sessionSlot}) on ${attendanceDate} has already been recorded. Use the Attendance History tab to perform an authorized correction.`,
      });
      return;
    }

    setIsSubmitting(true);
    setFeedbackMsg(null);

    try {
      let recordedCount = 0;
      for (const item of roster) {
        const student = item.student!;
        const status = studentStatuses[student.student_id] || AttendanceStatus.PRESENT;

        await onRecordAttendance({
          student_id: student.student_id,
          registration_number: student.registration_number,
          course_code: selectedCourseCode,
          section: selectedSection,
          date: attendanceDate,
          session_slot: sessionSlot,
          status,
          remarks: attendanceRemarks.trim() || undefined,
        });
        recordedCount++;
      }

      setFeedbackMsg({
        type: 'success',
        text: `Successfully recorded attendance for ${recordedCount} student(s) in ${selectedCourseCode} (Section ${selectedSection}, Slot ${sessionSlot}).`,
      });
      if (onRefreshData) await onRefreshData();
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err?.message || 'Failed to submit attendance roll-call.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Authorized correction submission
  const handleExecuteCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!correctingRecord) return;
    if (!correctionReason.trim()) {
      setCorrectionError('Mandatory justification reason is required to correct attendance.');
      return;
    }

    setIsSavingCorrection(true);
    setCorrectionError(null);

    try {
      if (onCorrectAttendance) {
        await onCorrectAttendance(correctingRecord.attendance_id, revisedStatus, correctionReason.trim());
      }
      setCorrectingRecord(null);
      setFeedbackMsg({
        type: 'success',
        text: `Attendance corrected successfully for ${correctingRecord.registration_number}.`,
      });
      if (onRefreshData) await onRefreshData();
    } catch (err: any) {
      setCorrectionError(err?.message || 'Failed to correct attendance.');
    } finally {
      setIsSavingCorrection(false);
    }
  };

  // History list for this course & section
  const courseHistory = useMemo(() => {
    return attendanceRecords.filter((a) => a.course_code === selectedCourseCode);
  }, [attendanceRecords, selectedCourseCode]);

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <CalendarCheck className="w-5 h-5 text-[#1e3a8a]" />
              <span>Attendance Management & Roll-Call</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Authoritative classroom attendance register. Restricted strictly to your assigned teaching sections.
            </p>
          </div>

          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setActiveTab('take')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'take'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Take Attendance
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Attendance History</span>
            </button>
          </div>
        </div>

        {/* Course & Section Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Assigned Course
            </label>
            <select
              value={selectedCourseCode}
              onChange={(e) => {
                setSelectedCourseCode(e.target.value);
                const matching = assignments.find((a) => a.course_code === e.target.value);
                if (matching) setSelectedSection(matching.section);
              }}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {assignments.map((asg) => (
                <option key={asg.faculty_assignment_id} value={asg.course_code}>
                  {asg.course_code} - {asg.course_title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Section
            </label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {assignments
                .filter((a) => a.course_code === selectedCourseCode)
                .map((a) => (
                  <option key={a.faculty_assignment_id} value={a.section}>
                    Section {a.section}
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Attendance Date
            </label>
            <Input
              type="date"
              value={attendanceDate}
              onChange={(e) => setAttendanceDate(e.target.value)}
              className="h-9 text-xs"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-[#64748b] mb-1">
              Lecture Session / Period
            </label>
            <select
              value={sessionSlot}
              onChange={(e) => setSessionSlot(Number(e.target.value))}
              className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              <option value={1}>Period 1 (08:30 - 09:30)</option>
              <option value={2}>Period 2 (09:45 - 10:45)</option>
              <option value={3}>Period 3 (11:00 - 12:00)</option>
              <option value={4}>Period 4 (12:15 - 13:15)</option>
              <option value={5}>Period 5 (14:00 - 15:00)</option>
              <option value={6}>Period 6 (15:15 - 16:15)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Banners */}
      {feedbackMsg && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setFeedbackMsg(null)}
            className="text-slate-400 hover:text-slate-600"
          >
            &times;
          </button>
        </div>
      )}

      {isAlreadyRecorded && activeTab === 'take' && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-bold">
              Attendance already recorded for {selectedCourseCode} on {attendanceDate} (Period {sessionSlot})
            </span>
            <p className="mt-0.5 text-amber-800">
              The institutional attendance ledger prevents duplicate submissions. To modify previously marked attendance, please use the Attendance History tab.
            </p>
          </div>
        </div>
      )}

      {/* Main Tab Content */}
      {activeTab === 'take' ? (
        <form onSubmit={handleSubmitAttendance} className="space-y-4">
          {/* Quick Actions & Roster Filter Bar */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-[#1e293b]">Quick Mark:</span>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleMarkAll(AttendanceStatus.PRESENT)}
                className="text-xs h-7.5 border-emerald-300 text-emerald-800 hover:bg-emerald-50"
                leftIcon={<Check className="w-3.5 h-3.5" />}
              >
                Mark All Present
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handleMarkAll(AttendanceStatus.ABSENT)}
                className="text-xs h-7.5 border-rose-300 text-rose-800 hover:bg-rose-50"
                leftIcon={<X className="w-3.5 h-3.5" />}
              >
                Mark All Absent
              </Button>
            </div>

            <div className="w-full sm:w-64">
              <Input
                placeholder="Filter student or Reg No..."
                value={searchRoster}
                onChange={(e) => setSearchRoster(e.target.value)}
                className="h-7.5 text-xs"
              />
            </div>
          </div>

          {/* Student Roll-Call Table */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Reg. No.</th>
                  <th className="py-3 px-4 font-semibold">Student Name</th>
                  <th className="py-3 px-4 font-semibold">Dept & Sem</th>
                  <th className="py-3 px-4 font-semibold text-center">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Toggle Attendance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredRoster.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-[#94a3b8]">
                      No enrolled students found in this course and section.
                    </td>
                  </tr>
                ) : (
                  filteredRoster.map(({ enrolment, student }) => {
                    const currentStatus =
                      studentStatuses[student!.student_id] || AttendanceStatus.PRESENT;

                    return (
                      <tr key={enrolment.enrolment_id} className="hover:bg-[#f8fafc]">
                        <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">
                          {student!.registration_number}
                        </td>
                        <td className="py-3 px-4 font-bold text-[#1e293b]">
                          {student!.first_name} {student!.last_name}
                        </td>
                        <td className="py-3 px-4 text-[#64748b]">
                          {student!.department} &bull; Sem {enrolment.semester}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                              currentStatus === AttendanceStatus.PRESENT
                                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                : currentStatus === AttendanceStatus.LATE
                                ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                : 'bg-rose-50 text-rose-800 border border-rose-200'
                            }`}
                          >
                            {currentStatus}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50">
                            <button
                              type="button"
                              onClick={() =>
                                handleStudentStatusChange(student!.student_id, AttendanceStatus.PRESENT)
                              }
                              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                                currentStatus === AttendanceStatus.PRESENT
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'text-slate-600 hover:text-emerald-700'
                              }`}
                            >
                              Present
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleStudentStatusChange(student!.student_id, AttendanceStatus.LATE)
                              }
                              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                                currentStatus === AttendanceStatus.LATE
                                  ? 'bg-amber-600 text-white shadow-xs'
                                  : 'text-slate-600 hover:text-amber-700'
                              }`}
                            >
                              Late
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleStudentStatusChange(student!.student_id, AttendanceStatus.ABSENT)
                              }
                              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                                currentStatus === AttendanceStatus.ABSENT
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'text-slate-600 hover:text-rose-700'
                              }`}
                            >
                              Absent
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Submit Action Card */}
          <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="text-xs text-[#64748b]">
              Summary: <strong>{roster.length}</strong> enrolled students &bull; Instructor:{' '}
              <strong className="text-slate-900">{facultyName}</strong>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || isAlreadyRecorded || roster.length === 0}
              className="text-xs"
              leftIcon={<Save className="w-3.5 h-3.5" />}
            >
              {isSubmitting ? 'Recording Attendance...' : 'Save & Submit Attendance'}
            </Button>
          </div>
        </form>
      ) : (
        /* Attendance History & Correction View */
        <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="text-sm font-bold text-[#1e293b]">
              Recorded Attendance Sessions for {selectedCourseCode}
            </h3>
            <span className="text-xs text-[#64748b]">
              {courseHistory.length} total entries recorded
            </span>
          </div>

          <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3.5 font-semibold">Date & Period</th>
                  <th className="py-2.5 px-3.5 font-semibold">Student Reg. No.</th>
                  <th className="py-2.5 px-3.5 font-semibold">Recorded Status</th>
                  <th className="py-2.5 px-3.5 font-semibold">Remarks & Audit</th>
                  <th className="py-2.5 px-3.5 font-semibold text-right">Correction</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {courseHistory.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#94a3b8]">
                      No historical attendance records found for this course.
                    </td>
                  </tr>
                ) : (
                  courseHistory.slice(0, 50).map((record) => (
                    <tr key={record.attendance_id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3.5 font-semibold text-slate-800">
                        {record.date} &bull; Period {record.session_slot}
                      </td>
                      <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                        {record.registration_number || record.student_id}
                      </td>
                      <td className="py-2.5 px-3.5">
                        <span
                          className={`inline-flex px-2 py-0.5 rounded text-[11px] font-semibold ${
                            record.status === AttendanceStatus.PRESENT
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : record.status === AttendanceStatus.LATE
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : 'bg-rose-50 text-rose-800 border border-rose-200'
                          }`}
                        >
                          {record.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-500 text-[11px]">
                        {record.remarks || 'Standard session entry'}
                      </td>
                      <td className="py-2.5 px-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setCorrectingRecord(record);
                            setRevisedStatus(
                              record.status === AttendanceStatus.PRESENT
                                ? AttendanceStatus.ABSENT
                                : AttendanceStatus.PRESENT
                            );
                            setCorrectionReason('');
                            setCorrectionError(null);
                          }}
                          className="h-7 text-xs"
                          leftIcon={<Edit3 className="w-3 h-3 text-[#1e3a8a]" />}
                        >
                          Correct
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Authorized Correction Modal */}
      {correctingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between border-b pb-3 border-slate-100">
              <div>
                <h3 className="text-base font-bold text-[#1e293b]">
                  Authorized Attendance Correction
                </h3>
                <p className="text-xs text-[#64748b]">
                  Student: <strong>{correctingRecord.registration_number}</strong> &bull; Date: {correctingRecord.date}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCorrectingRecord(null)}
                className="text-slate-400 hover:text-slate-600 text-lg"
              >
                &times;
              </button>
            </div>

            {correctionError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {correctionError}
              </div>
            )}

            <form onSubmit={handleExecuteCorrection} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">
                  Current Status
                </label>
                <div className="p-2 bg-slate-50 rounded border border-slate-200 font-bold text-slate-800">
                  {correctingRecord.status}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">
                  Revised Status
                </label>
                <select
                  value={revisedStatus}
                  onChange={(e) => setRevisedStatus(e.target.value as AttendanceStatus)}
                  className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
                >
                  <option value={AttendanceStatus.PRESENT}>PRESENT</option>
                  <option value={AttendanceStatus.LATE}>LATE</option>
                  <option value={AttendanceStatus.ABSENT}>ABSENT</option>
                  <option value={AttendanceStatus.EXCUSED}>EXCUSED</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">
                  Mandatory Justification Reason <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={correctionReason}
                  onChange={(e) => setCorrectionReason(e.target.value)}
                  placeholder="e.g. Student reported with sanctioned medical slip / On-Duty college representation..."
                  rows={3}
                  className="w-full p-2.5 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                  required
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px]">
                <strong>Audit Compliance:</strong> This correction will be permanently logged in the institutional audit trail with your faculty identifier.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setCorrectingRecord(null)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  disabled={isSavingCorrection}
                  className="text-xs"
                >
                  {isSavingCorrection ? 'Applying...' : 'Apply Correction'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
