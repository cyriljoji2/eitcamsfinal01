import React, { useState, useEffect, useMemo } from 'react';
import {
  Megaphone,
  Plus,
  Send,
  Calendar,
  Clock,
  BookOpen,
  Filter,
  CheckCircle2,
  AlertCircle,
  Tag,
  Trash2,
} from 'lucide-react';
import { FacultyCourseAssignmentRecord } from '../../types/database';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

export interface ClassAnnouncement {
  id: string;
  course_code: string;
  section: string;
  title: string;
  content: string;
  priority: 'normal' | 'important' | 'urgent';
  faculty_id: string;
  faculty_name: string;
  created_at: string;
}

interface FacultyAnnouncementsViewProps {
  assignments: FacultyCourseAssignmentRecord[];
  facultyId: string;
  facultyName: string;
}

const STORAGE_KEY = 'eit_class_announcements_v1';

export function FacultyAnnouncementsView({
  assignments,
  facultyId,
  facultyName,
}: FacultyAnnouncementsViewProps) {
  const [announcements, setAnnouncements] = useState<ClassAnnouncement[]>([]);
  const [selectedCourseCode, setSelectedCourseCode] = useState<string>(
    assignments[0]?.course_code || ''
  );
  const [selectedSection, setSelectedSection] = useState<string>(
    assignments[0]?.section || 'A'
  );

  // Form states
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [priority, setPriority] = useState<'normal' | 'important' | 'urgent'>('normal');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Load announcements from storage
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        setAnnouncements(JSON.parse(raw));
      } else {
        // Seed default initial announcement
        const initial: ClassAnnouncement[] = [
          {
            id: 'ANN-001',
            course_code: assignments[0]?.course_code || 'CS201',
            section: assignments[0]?.section || 'A',
            title: 'Welcome to the Course & Laboratory Rubric Announcement',
            content:
              'Welcome to the semester. Please review the detailed course syllabus, weekly lecture outlines, and laboratory assignment evaluation rubrics available under Course Materials.',
            priority: 'important',
            faculty_id: facultyId,
            faculty_name: facultyName,
            created_at: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
          },
        ];
        setAnnouncements(initial);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      }
    } catch {
      // ignore
    }
  }, [assignments, facultyId, facultyName]);

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setIsSubmitting(true);
    try {
      const newAnn: ClassAnnouncement = {
        id: `ANN-${Date.now()}`,
        course_code: selectedCourseCode,
        section: selectedSection,
        title: title.trim(),
        content: content.trim(),
        priority,
        faculty_id: facultyId,
        faculty_name: facultyName,
        created_at: new Date().toISOString(),
      };

      const next = [newAnn, ...announcements];
      setAnnouncements(next);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));

      setTitle('');
      setContent('');
      setPriority('normal');
      setIsComposeOpen(false);
      setSuccessMsg(`Announcement published to ${selectedCourseCode} (Section ${selectedSection}).`);
      setTimeout(() => setSuccessMsg(null), 4000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = (id: string) => {
    const next = announcements.filter((a) => a.id !== id);
    setAnnouncements(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  // Filtered announcements
  const filteredAnnouncements = useMemo(() => {
    return announcements.filter(
      (a) => a.course_code === selectedCourseCode && (selectedSection === 'ALL' || a.section === selectedSection)
    );
  }, [announcements, selectedCourseCode, selectedSection]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-[#1e3a8a]" />
              <span>Class Communications & Announcements</span>
            </h1>
            <p className="text-xs text-[#64748b] mt-0.5">
              Publish authoritative course notifications scoped strictly to your enrolled students.
            </p>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsComposeOpen(true)}
            className="text-xs"
            leftIcon={<Plus className="w-3.5 h-3.5" />}
          >
            New Announcement
          </Button>
        </div>

        {/* Course & Section Selectors */}
        <div className="flex items-center gap-3 pt-2 border-t border-slate-100 flex-wrap">
          <div className="flex items-center gap-2">
            <label className="text-xs text-[#64748b]">Course:</label>
            <select
              value={selectedCourseCode}
              onChange={(e) => setSelectedCourseCode(e.target.value)}
              className="h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              {assignments.map((asg) => (
                <option key={asg.faculty_assignment_id} value={asg.course_code}>
                  {asg.course_code} - {asg.course_title}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-xs text-[#64748b]">Section:</label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden focus:border-[#1e3a8a]"
            >
              <option value="ALL">All Sections</option>
              {assignments
                .filter((a) => a.course_code === selectedCourseCode)
                .map((a) => (
                  <option key={a.faculty_assignment_id} value={a.section}>
                    Section {a.section}
                  </option>
                ))}
            </select>
          </div>
        </div>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Announcements List */}
      <div className="space-y-4">
        {filteredAnnouncements.length === 0 ? (
          <div className="bg-white border border-[#e2e8f0] p-12 rounded-2xl text-center text-xs text-[#94a3b8] space-y-2">
            <Megaphone className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="font-semibold text-slate-700">No announcements for this course selection.</p>
            <p>Click "New Announcement" to broadcast a notice to enrolled students.</p>
          </div>
        ) : (
          filteredAnnouncements.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-[#e2e8f0] rounded-2xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                      {item.course_code} (Sec {item.section})
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        item.priority === 'urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : item.priority === 'important'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {item.priority}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#1e293b]">{item.title}</h3>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span>{new Date(item.created_at).toLocaleDateString()}</span>
                  <button
                    type="button"
                    onClick={() => handleDelete(item.id)}
                    className="p-1 hover:text-rose-600 rounded transition-colors"
                    title="Delete announcement"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
                {item.content}
              </p>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-[#64748b]">
                <span>Author: <strong>{item.faculty_name}</strong></span>
                <span>Audience: Enrolled students in {item.course_code} - Sec {item.section}</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Compose Announcement Modal */}
      {isComposeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-[#1e293b]">Post New Class Announcement</h3>
            <form onSubmit={handlePublish} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">Target Course</label>
                  <select
                    value={selectedCourseCode}
                    onChange={(e) => setSelectedCourseCode(e.target.value)}
                    className="w-full h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                  >
                    {assignments.map((asg) => (
                      <option key={asg.faculty_assignment_id} value={asg.course_code}>
                        {asg.course_code}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#64748b] mb-1">Target Section</label>
                  <select
                    value={selectedSection}
                    onChange={(e) => setSelectedSection(e.target.value)}
                    className="w-full h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                  >
                    {assignments
                      .filter((a) => a.course_code === selectedCourseCode)
                      .map((a) => (
                        <option key={a.faculty_assignment_id} value={a.section}>
                          Section {a.section}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Priority Level</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full h-8.5 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                >
                  <option value="normal">Normal (General information)</option>
                  <option value="important">Important (Deadlines & instructions)</option>
                  <option value="urgent">Urgent (Immediate attention)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Announcement Title</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Lab Assignment 2 Submission Deadline..."
                  className="h-8 text-xs"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Announcement Content</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Enter detailed announcement text for enrolled students..."
                  rows={4}
                  className="w-full p-2.5 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsComposeOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" disabled={isSubmitting} className="text-xs">
                  {isSubmitting ? 'Publishing...' : 'Publish Announcement'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
