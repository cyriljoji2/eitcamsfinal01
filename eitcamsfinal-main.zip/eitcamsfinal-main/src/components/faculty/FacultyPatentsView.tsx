import React, { useState } from 'react';
import {
  Award,
  Plus,
  FileCheck2,
  Calendar,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Globe,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface PatentRecord {
  id: string;
  title: string;
  applicationNumber: string;
  filingDate: string;
  jurisdiction: 'Indian Patent Office (IPO)' | 'USPTO' | 'WIPO / PCT';
  inventors: string[];
  status: 'PUBLISHED' | 'GRANTED' | 'FILED_UNDER_EXAMINATION';
  grantDate?: string;
  patentNumber?: string;
}

export function FacultyPatentsView() {
  const [patents, setPatents] = useState<PatentRecord[]>([
    {
      id: 'PAT-2025-01',
      title: 'A Method and Architecture for Low-Latency Distributed Consensus in Edge Clusters',
      applicationNumber: '202541019842 A',
      filingDate: '2025-03-12',
      jurisdiction: 'Indian Patent Office (IPO)',
      inventors: ['Dr. Arvind Sharma', 'Prof. K. Narayanan', 'Arjun Kumar'],
      status: 'PUBLISHED',
    },
    {
      id: 'PAT-2024-02',
      title: 'Hardware Acceleration Unit for Real-Time Graph Neural Network Inference',
      applicationNumber: '202441098231',
      filingDate: '2024-08-20',
      jurisdiction: 'Indian Patent Office (IPO)',
      inventors: ['Dr. Arvind Sharma', 'Dr. Ramesh Sundaram'],
      status: 'FILED_UNDER_EXAMINATION',
    },
    {
      id: 'PAT-2023-01',
      title: 'Resilient Routing Protocol for Heterogeneous Sensor Networks in Industrial IoT',
      applicationNumber: 'US 11,892,109 B2',
      filingDate: '2022-11-10',
      jurisdiction: 'USPTO',
      inventors: ['Dr. Arvind Sharma', 'Dr. John Doe'],
      status: 'GRANTED',
      grantDate: '2024-02-14',
      patentNumber: 'US 11,892,109 B2',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [appNo, setAppNo] = useState('');
  const [jurisdiction, setJurisdiction] = useState<'Indian Patent Office (IPO)' | 'USPTO' | 'WIPO / PCT'>('Indian Patent Office (IPO)');
  const [filingDate, setFilingDate] = useState(() => new Date().toISOString().split('T')[0]);

  const grantedCount = patents.filter((p) => p.status === 'GRANTED').length;
  const publishedCount = patents.filter((p) => p.status === 'PUBLISHED').length;

  const handleAddPatent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !appNo.trim()) return;

    const newPat: PatentRecord = {
      id: `PAT-${Date.now().toString().slice(-4)}`,
      title: title.trim(),
      applicationNumber: appNo.trim(),
      filingDate,
      jurisdiction,
      inventors: ['Dr. Arvind Sharma'],
      status: 'FILED_UNDER_EXAMINATION',
    };

    setPatents([newPat, ...patents]);
    setIsModalOpen(false);
    setTitle('');
    setAppNo('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Intellectual Property & Patent Disclosures</h2>
            <Badge variant="blue">{patents.length} Filings</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional portfolio of inventions, utility patents, and technology transfers filed through the EIT IPR Cell.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          File Patent Disclosure
        </Button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Granted Patents</div>
          <div className="text-xl font-bold text-emerald-700 mt-1">{grantedCount} Patents</div>
          <div className="text-[11px] text-[#64748b] mt-1">Commercialized & Protected</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Officially Published</div>
          <div className="text-xl font-bold text-[#1e3a8a] mt-1">{publishedCount} Disclosures</div>
          <div className="text-[11px] text-[#64748b] mt-1">Official Patent Gazette Journal</div>
        </div>

        <div className="bg-white border border-[#e2e8f0] p-4 rounded-xl shadow-2xs">
          <div className="text-[11px] font-semibold text-[#64748b] uppercase">Filing Office Support</div>
          <div className="text-xs font-bold text-slate-800 mt-1.5 truncate">
            EIT Dean (Research & IPR Cell)
          </div>
          <div className="text-[11px] text-[#64748b] mt-1">100% Institutional Subsidy</div>
        </div>
      </div>

      {/* Patents List */}
      <div className="space-y-4">
        {patents.map((pat) => (
          <div
            key={pat.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {pat.id}
                  </span>
                  <Badge
                    variant={
                      pat.status === 'GRANTED'
                        ? 'emerald'
                        : pat.status === 'PUBLISHED'
                        ? 'blue'
                        : 'amber'
                    }
                  >
                    {pat.status.replace(/_/g, ' ')}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    {pat.jurisdiction}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{pat.title}</h3>
                <div className="text-xs text-[#64748b]">
                  Inventors: <strong>{pat.inventors.join(', ')}</strong>
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Application No.</div>
                <div className="font-mono text-xs font-bold text-slate-800">{pat.applicationNumber}</div>
                {pat.patentNumber && (
                  <div className="text-[11px] font-semibold text-emerald-700 mt-0.5">
                    Patent No: {pat.patentNumber}
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Filing Date: {pat.filingDate} {pat.grantDate && `(Granted: ${pat.grantDate})`}</span>
              </div>
              <div className="flex items-center gap-1 text-blue-600 hover:text-blue-800 cursor-pointer font-medium">
                <span>View IPR Docket</span>
                <ExternalLink className="w-3 h-3" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Record New Patent Disclosure</h3>
            <p className="text-xs text-[#64748b]">
              Submit preliminary application details for institutional patent docketing.
            </p>

            <form onSubmit={handleAddPatent} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Invention Title</label>
                <Input
                  required
                  placeholder="e.g., Adaptive Power-Aware Microarchitecture for Edge AI"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Application Reference No.</label>
                <Input
                  required
                  placeholder="e.g., 202641019888"
                  value={appNo}
                  onChange={(e) => setAppNo(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Jurisdiction</label>
                  <select
                    value={jurisdiction}
                    onChange={(e) => setJurisdiction(e.target.value as any)}
                    className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="Indian Patent Office (IPO)">Indian Patent Office (IPO)</option>
                    <option value="USPTO">USPTO (United States)</option>
                    <option value="WIPO / PCT">WIPO / PCT (International)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Filing Date</label>
                  <Input
                    type="date"
                    value={filingDate}
                    onChange={(e) => setFilingDate(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Submit Disclosure
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
