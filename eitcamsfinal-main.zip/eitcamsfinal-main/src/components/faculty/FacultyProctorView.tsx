import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  Users,
  Calendar,
  Clock,
  MessageSquare,
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Send,
  Search,
  Filter,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  ArrowRight,
  UserCheck,
  Plus,
  Lock,
} from 'lucide-react';
import {
  ProctorAssignment,
  LeaveOutingRequest,
  ProctorMessage,
  ProctorRemark,
  ProctorRemarkCategory,
} from '../../types/proctor';
import { StudentRecord } from '../../types/database';
import { proctorRepository } from '../../services/proctorService';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyProctorViewProps {
  facultyId: string;
  facultyName: string;
  facultyEmail?: string;
  assignments: ProctorAssignment[];
  students: StudentRecord[];
  actor?: { userId?: string; role?: string; employeeId?: string };
  onOpenStudentProfile: (regNo: string) => void;
}

type ProctorSection = 'proctees' | 'leave' | 'outing' | 'messages' | 'remarks';

export function FacultyProctorView({
  facultyId,
  facultyName,
  facultyEmail,
  assignments,
  students,
  actor,
  onOpenStudentProfile,
}: FacultyProctorViewProps) {
  const [activeSection, setActiveSection] = useState<ProctorSection>('proctees');
  const [requests, setRequests] = useState<LeaveOutingRequest[]>([]);
  const [messages, setMessages] = useState<ProctorMessage[]>([]);
  const [remarks, setRemarks] = useState<ProctorRemark[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Review Modal State (for Leave / Outing Endorsement)
  const [reviewModalRequest, setReviewModalRequest] = useState<LeaveOutingRequest | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject'>('approve');
  const [reviewRemarksText, setReviewRemarksText] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  // New Message State
  const [isNewMessageOpen, setIsNewMessageOpen] = useState(false);
  const [msgTargetStudentId, setMsgTargetStudentId] = useState('ALL');
  const [msgTitle, setMsgTitle] = useState('');
  const [msgBody, setMsgBody] = useState('');
  const [isSendingMsg, setIsSendingMsg] = useState(false);

  // New Remark State
  const [isNewRemarkOpen, setIsNewRemarkOpen] = useState(false);
  const [remarkTargetStudentId, setRemarkTargetStudentId] = useState('');
  const [remarkCategory, setRemarkCategory] = useState<ProctorRemarkCategory>('academic');
  const [remarkText, setRemarkText] = useState('');
  const [remarkActionRequired, setRemarkActionRequired] = useState(false);
  const [isSavingRemark, setIsSavingRemark] = useState(false);

  // Search filter
  const [searchStudent, setSearchStudent] = useState('');

  // Load authoritative proctor data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [reqs, msgs, rems] = await Promise.all([
        proctorRepository.getRequestsForProctor(facultyId, actor),
        proctorRepository.getMessagesByProctor(facultyId, actor),
        proctorRepository.getRemarksByProctor(facultyId, actor),
      ]);
      setRequests(reqs || []);
      setMessages(msgs || []);
      setRemarks(rems || []);
    } catch (e) {
      console.error('Error loading proctor data:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsub = proctorRepository.subscribe(() => {
      loadData();
    });
    return unsub;
  }, [facultyId]);

  // My Proctees Student Objects
  const myProcteeStudents = useMemo(() => {
    return assignments.map((asg) => {
      const fullStudent = students.find(
        (s) =>
          s.student_id.toLowerCase() === asg.studentId.toLowerCase() ||
          s.registration_number.toLowerCase() === (asg.studentRegistrationNumber || '').toLowerCase()
      );

      return {
        assignment: asg,
        student: fullStudent,
        name: asg.studentName || `${fullStudent?.first_name || ''} ${fullStudent?.last_name || ''}`.trim() || 'Student',
        regNo: asg.studentRegistrationNumber || fullStudent?.registration_number || '—',
        department: fullStudent?.department || asg.facultyDepartment || '—',
        semester: fullStudent?.current_semester ?? 3,
        email: fullStudent?.institutional_email || '—',
        phone: fullStudent?.personal_phone || '—',
      };
    });
  }, [assignments, students]);

  const filteredProctees = useMemo(() => {
    const q = searchStudent.toLowerCase().trim();
    if (!q) return myProcteeStudents;
    return myProcteeStudents.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.regNo.toLowerCase().includes(q) ||
        p.department.toLowerCase().includes(q)
    );
  }, [myProcteeStudents, searchStudent]);

  // Categorized Requests
  const leaveRequests = useMemo(() => {
    return requests.filter((r) => r.requestType === 'leave');
  }, [requests]);

  const outingRequests = useMemo(() => {
    return requests.filter((r) => r.requestType === 'outing');
  }, [requests]);

  const pendingLeaveCount = useMemo(() => {
    return leaveRequests.filter((r) => r.approvalStatus === 'PENDING').length;
  }, [leaveRequests]);

  const pendingOutingCount = useMemo(() => {
    return outingRequests.filter((r) => r.approvalStatus === 'PENDING').length;
  }, [outingRequests]);

  // Execute Endorsement
  const handleExecuteEndorsement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewModalRequest) return;
    if (!reviewRemarksText.trim()) {
      setReviewError('Mandatory endorsement remarks are required.');
      return;
    }

    setIsReviewing(true);
    setReviewError(null);
    try {
      await proctorRepository.endorseLeaveOutingRequest(
        reviewModalRequest.id,
        facultyId,
        reviewAction,
        reviewRemarksText.trim(),
        actor
      );
      setReviewModalRequest(null);
      await loadData();
    } catch (err: any) {
      setReviewError(err?.message || 'Failed to submit review.');
    } finally {
      setIsReviewing(false);
    }
  };

  // Send Message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgTitle.trim() || !msgBody.trim()) return;

    setIsSendingMsg(true);
    try {
      const targetStudent = myProcteeStudents.find((s) => s.assignment.studentId === msgTargetStudentId);

      await proctorRepository.sendMessage(
        {
          studentId: targetStudent ? targetStudent.assignment.studentId : 'ALL',
          studentRegistrationNumber: targetStudent ? targetStudent.regNo : 'ALL',
          studentName: targetStudent ? targetStudent.name : 'All Proctees',
          proctorId: facultyId,
          proctorName: facultyName,
          subject: msgTitle.trim(),
          message: msgBody.trim(),
          sender: 'proctor',
        },
        actor
      );

      setMsgTitle('');
      setMsgBody('');
      setIsNewMessageOpen(false);
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSendingMsg(false);
    }
  };

  // Add Remark
  const handleSaveRemark = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!remarkTargetStudentId || !remarkText.trim()) return;

    setIsSavingRemark(true);
    try {
      const targetStudent = myProcteeStudents.find((s) => s.assignment.studentId === remarkTargetStudentId);

      await proctorRepository.addRemark(
        {
          proctorId: facultyId,
          studentId: targetStudent ? targetStudent.assignment.studentId : remarkTargetStudentId,
          studentRegistrationNumber: targetStudent ? targetStudent.regNo : 'UNKNOWN',
          studentName: targetStudent ? targetStudent.name : undefined,
          category: remarkCategory,
          remark: remarkText.trim(),
          actionRequired: remarkActionRequired,
        },
        actor
      );

      setRemarkText('');
      setIsNewRemarkOpen(false);
      await loadData();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSavingRemark(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <span>Proctor Mentorship Desk</span>
              </h1>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                {assignments.length} Mentees Assigned
              </span>
            </div>
            <p className="text-xs text-[#64748b] mt-0.5">
              Faculty mentorship, residential leave endorsement, and confidential student counseling.
            </p>
          </div>

          {/* Sub-section Navigation Pills */}
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 flex-wrap">
            <button
              type="button"
              onClick={() => setActiveSection('proctees')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeSection === 'proctees'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mentees ({assignments.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('leave')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                activeSection === 'leave'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Leave</span>
              {pendingLeaveCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {pendingLeaveCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('outing')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer flex items-center gap-1 ${
                activeSection === 'outing'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Outing</span>
              {pendingOutingCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                  {pendingOutingCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('messages')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeSection === 'messages'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Messages ({messages.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('remarks')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                activeSection === 'remarks'
                  ? 'bg-white text-[#1e3a8a] shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Remarks ({remarks.length})
            </button>
          </div>
        </div>
      </div>

      {/* 1. Mentees Section */}
      {activeSection === 'proctees' && (
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Assigned Proctee Roster</h3>
              <p className="text-xs text-[#64748b]">
                Undergraduate students officially assigned to your mentorship portfolio by the Academic Office.
              </p>
            </div>

            <div className="w-full sm:w-64">
              <Input
                placeholder="Search proctee or Reg No..."
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                className="h-8 text-xs"
              />
            </div>
          </div>

          <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3.5 font-semibold">Reg. No.</th>
                  <th className="py-2.5 px-3.5 font-semibold">Student Name</th>
                  <th className="py-2.5 px-3.5 font-semibold">Dept & Sem</th>
                  <th className="py-2.5 px-3.5 font-semibold">Email & Phone</th>
                  <th className="py-2.5 px-3.5 font-semibold text-center">Mentorship Status</th>
                  <th className="py-2.5 px-3.5 font-semibold text-right">Academic Profile</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {filteredProctees.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#94a3b8]">
                      No proctee students assigned to this faculty account.
                    </td>
                  </tr>
                ) : (
                  filteredProctees.map((p) => (
                    <tr key={p.assignment.id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3.5 font-mono font-bold text-[#1e3a8a]">
                        {p.regNo}
                      </td>
                      <td className="py-2.5 px-3.5 font-bold text-[#1e293b]">{p.name}</td>
                      <td className="py-2.5 px-3.5 text-[#64748b]">
                        {p.department} &bull; Sem {p.semester}
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 text-[11px]">
                        <div>{p.email}</div>
                        <div className="text-slate-400 font-mono">{p.phone}</div>
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        <Badge variant="emerald">Active Ward</Badge>
                      </td>
                      <td className="py-2.5 px-3.5 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onOpenStudentProfile(p.regNo)}
                          className="h-7 text-xs"
                          leftIcon={<UserCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                        >
                          View Record
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2 & 3. Leave & Outing Requests Sections */}
      {(activeSection === 'leave' || activeSection === 'outing') && (
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">
                {activeSection === 'leave' ? 'Hostel Leave Applications' : 'Hostel Outing Slips'}
              </h3>
              <p className="text-xs text-[#64748b]">
                Residential exit permissions submitted by your assigned proctee students requiring faculty endorsement.
              </p>
            </div>
          </div>

          <div className="border border-[#e2e8f0] rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] text-[#64748b] border-b border-[#e2e8f0]">
                <tr>
                  <th className="py-2.5 px-3.5 font-semibold">Student & Room</th>
                  <th className="py-2.5 px-3.5 font-semibold">Duration & Destination</th>
                  <th className="py-2.5 px-3.5 font-semibold">Reason Category</th>
                  <th className="py-2.5 px-3.5 font-semibold text-center">Endorsement Status</th>
                  <th className="py-2.5 px-3.5 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {(activeSection === 'leave' ? leaveRequests : outingRequests).length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-[#94a3b8]">
                      No {activeSection} applications currently pending review.
                    </td>
                  </tr>
                ) : (
                  (activeSection === 'leave' ? leaveRequests : outingRequests).map((req) => (
                    <tr key={req.id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3.5">
                        <div className="font-bold text-[#1e293b]">{req.studentName}</div>
                        <div className="font-mono text-[11px] text-[#1e3a8a]">{req.studentRegistrationNumber}</div>
                        <div className="text-[11px] text-slate-500">
                          {req.blockName} &bull; Room {req.roomNumber}
                        </div>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-700">
                        <div>
                          <strong>{req.fromDate}</strong> ({req.fromTime}) to <strong>{req.toDate}</strong> ({req.toTime})
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          Destination: {req.destination || req.destinationAddress || 'Home'}
                        </div>
                      </td>
                      <td className="py-2.5 px-3.5">
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-800 border border-slate-200">
                          {req.reasonCategory}
                        </span>
                        <div className="text-[11px] text-slate-600 mt-1">{req.reason || req.purpose}</div>
                      </td>
                      <td className="py-2.5 px-3.5 text-center">
                        <span
                          className={`inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                            req.approvalStatus === 'APPROVED'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : req.approvalStatus === 'REJECTED'
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {req.approvalStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-3.5 text-right">
                        {req.approvalStatus === 'PENDING' ? (
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => {
                              setReviewModalRequest(req);
                              setReviewAction('approve');
                              setReviewRemarksText('');
                              setReviewError(null);
                            }}
                            className="h-7 text-xs"
                          >
                            Endorse
                          </Button>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">Reviewed</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Messages Section */}
      {activeSection === 'messages' && (
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">Proctor & Mentee Communications</h3>
              <p className="text-xs text-[#64748b]">
                Bidirectional messages between faculty mentors and assigned students.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setIsNewMessageOpen(true)}
              className="text-xs"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
            >
              Compose Message
            </Button>
          </div>

          <div className="space-y-3">
            {messages.length === 0 ? (
              <div className="py-10 text-center text-xs text-[#94a3b8]">
                No messages logged yet. Use Compose to reach out to your proctees.
              </div>
            ) : (
              messages.map((m) => (
                <div
                  key={m.id}
                  className="p-4 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl space-y-1.5 hover:border-blue-200 transition-colors"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#1e293b]">{m.title}</span>
                      <Badge variant={m.priority === 'urgent' ? 'red' : 'blue'}>
                        {m.priority ? m.priority.toUpperCase() : 'NORMAL'}
                      </Badge>
                      <span className="text-slate-500 text-[11px]">
                        From: {m.facultyName || m.proctorName || 'Faculty Proctor'}
                      </span>
                    </div>
                    <span className="text-slate-400 text-[11px] font-mono">
                      {m.date || m.createdAt || ''}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">{m.message}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 5. Confidential Remarks Section */}
      {activeSection === 'remarks' && (
        <div className="bg-white border border-[#e2e8f0] rounded-2xl shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-[#1e293b]">
                Confidential Mentoring Remarks & Follow-Up Logs
              </h3>
              <p className="text-xs text-[#64748b]">
                Private faculty notes regarding student counseling, attendance interventions, and progress.
              </p>
            </div>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setIsNewRemarkOpen(true)}
              className="text-xs"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
            >
              Log Mentoring Note
            </Button>
          </div>

          <div className="space-y-3">
            {remarks.length === 0 ? (
              <div className="py-10 text-center text-xs text-[#94a3b8]">
                No confidential remarks recorded yet.
              </div>
            ) : (
              remarks.map((r) => (
                <div
                  key={r.id}
                  className="p-4 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl space-y-1.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-[#1e3a8a]">{r.studentRegistrationNumber}</span>
                      <span className="text-slate-700 font-semibold">{r.studentName}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-800 border border-purple-200 uppercase">
                        {r.category}
                      </span>
                    </div>
                    <span className="text-slate-400 text-[11px]">
                      {new Date(r.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">{r.remark}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Endorsement Modal */}
      {reviewModalRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between border-b pb-3 border-slate-100">
              <div>
                <h3 className="text-base font-bold text-[#1e293b]">
                  Endorse {reviewModalRequest.requestType.toUpperCase()} Request
                </h3>
                <p className="text-xs text-[#64748b]">
                  Student: <strong>{reviewModalRequest.studentName}</strong> ({reviewModalRequest.studentRegistrationNumber})
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReviewModalRequest(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                &times;
              </button>
            </div>

            {reviewError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {reviewError}
              </div>
            )}

            <form onSubmit={handleExecuteEndorsement} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">
                  Endorsement Decision
                </label>
                <div className="flex gap-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="decision"
                      value="approve"
                      checked={reviewAction === 'approve'}
                      onChange={() => setReviewAction('approve')}
                    />
                    <span className="font-bold text-emerald-800">Approve & Endorse Exit</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="decision"
                      value="reject"
                      checked={reviewAction === 'reject'}
                      onChange={() => setReviewAction('reject')}
                    />
                    <span className="font-bold text-rose-800">Reject Application</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#64748b] mb-1">
                  Mandatory Proctor Remarks <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={reviewRemarksText}
                  onChange={(e) => setReviewRemarksText(e.target.value)}
                  placeholder="e.g. Verified with parent via phone call / Approved for academic conference..."
                  rows={3}
                  className="w-full p-2.5 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setReviewModalRequest(null)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  size="sm"
                  disabled={isReviewing}
                  className="text-xs"
                >
                  {isReviewing ? 'Saving...' : 'Submit Endorsement'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Compose Message Modal */}
      {isNewMessageOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-[#1e293b]">Compose Mentorship Message</h3>
            <form onSubmit={handleSendMessage} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Target Proctee</label>
                <select
                  value={msgTargetStudentId}
                  onChange={(e) => setMsgTargetStudentId(e.target.value)}
                  className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                >
                  <option value="ALL">All Assigned Mentees ({myProcteeStudents.length})</option>
                  {myProcteeStudents.map((s) => (
                    <option key={s.assignment.studentId} value={s.assignment.studentId}>
                      {s.regNo} - {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Subject</label>
                <Input
                  value={msgTitle}
                  onChange={(e) => setMsgTitle(e.target.value)}
                  placeholder="e.g. Upcoming Semester Advising Session..."
                  className="h-8 text-xs"
                  required
                />
              </div>
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Message</label>
                <textarea
                  value={msgBody}
                  onChange={(e) => setMsgBody(e.target.value)}
                  placeholder="Enter message for mentees..."
                  rows={4}
                  className="w-full p-2.5 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsNewMessageOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" disabled={isSendingMsg} className="text-xs">
                  {isSendingMsg ? 'Sending...' : 'Send Message'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Log Remark Modal */}
      {isNewRemarkOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-[#1e293b]">Log Confidential Mentoring Note</h3>
            <form onSubmit={handleSaveRemark} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Select Student</label>
                <select
                  value={remarkTargetStudentId}
                  onChange={(e) => setRemarkTargetStudentId(e.target.value)}
                  className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                  required
                >
                  <option value="">Choose a mentee...</option>
                  {myProcteeStudents.map((s) => (
                    <option key={s.assignment.studentId} value={s.assignment.studentId}>
                      {s.regNo} - {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Category</label>
                <select
                  value={remarkCategory}
                  onChange={(e) => setRemarkCategory(e.target.value as ProctorRemarkCategory)}
                  className="w-full h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
                >
                  <option value="academic">Academic Counseling</option>
                  <option value="attendance">Attendance Intervention</option>
                  <option value="disciplinary">Disciplinary</option>
                  <option value="personal">Personal / Wellbeing</option>
                  <option value="general">General Note</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-[#64748b] mb-1">Confidential Note</label>
                <textarea
                  value={remarkText}
                  onChange={(e) => setRemarkText(e.target.value)}
                  placeholder="Record confidential remarks..."
                  rows={4}
                  className="w-full p-2.5 bg-white rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-hidden focus:border-[#1e3a8a]"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsNewRemarkOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" size="sm" disabled={isSavingRemark} className="text-xs">
                  {isSavingRemark ? 'Saving...' : 'Save Note'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
