import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  FlaskConical,
  User,
  Users,
  Landmark,
  BookOpen,
  Award,
  Contact,
  Settings,
  Building2,
  ShieldAlert,
  ShieldCheck,
  CalendarCheck,
  Clock,
  Megaphone,
  FileCheck2,
  Sparkles,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  AttendanceRecord,
  AttendanceStatus,
  AuthRole,
  CourseEnrolmentRecord,
  CourseRecord,
  DepartmentRecord,
  EmployeeRecord,
  ExamResultRecord,
  ExamScheduleRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
  TimetableSlotRecord,
} from '../../types/database';
import { proctorRepository } from '../../services/proctorService';
import { ProctorAssignment } from '../../types/proctor';

import { FacultyHeader } from './FacultyHeader';
import { FacultyOverviewView } from './FacultyOverviewView';
import { FacultyProfileView } from './FacultyProfileView';
import { FacultyCoursesView } from './FacultyCoursesView';
import { FacultyTimetableView } from './FacultyTimetableView';
import { FacultyAttendanceView } from './FacultyAttendanceView';
import { FacultyMarksEntryView } from './FacultyMarksEntryView';
import { FacultyMarksStatusView } from './FacultyMarksStatusView';
import { FacultyPerformanceView } from './FacultyPerformanceView';
import { FacultyProctorView } from './FacultyProctorView';
import { FacultyAnnouncementsView } from './FacultyAnnouncementsView';
import { FacultyLmsView } from './FacultyLmsView';
import { FacultyResearchView } from './FacultyResearchView';
import { FacultyDirectoryView } from './FacultyDirectoryView';
import { FacultySettingsView } from './FacultySettingsView';

// Submenu Views
import { FacultyStudentRosterView } from './FacultyStudentRosterView';
import { FacultyGrantsView } from './FacultyGrantsView';
import { FacultyPatentsView } from './FacultyPatentsView';
import { FacultyQualificationsView } from './FacultyQualificationsView';
import { FacultyMenteesView } from './FacultyMenteesView';
import { FacultyLeaveApprovalsView } from './FacultyLeaveApprovalsView';
import { FacultyAdminView } from './FacultyAdminView';
import { FacultyCommitteesView } from './FacultyCommitteesView';
import { FacultyCircularsView } from './FacultyCircularsView';
import { FacultySyllabusView } from './FacultySyllabusView';
import { FacultyAchievementsView } from './FacultyAchievementsView';
import { FacultyFdpView } from './FacultyFdpView';
import { FacultyDeptDirectoryView } from './FacultyDeptDirectoryView';
import { FacultySecuritySettingsView } from './FacultySecuritySettingsView';
import { FacultyHostelServicesView } from './FacultyHostelServicesView';
import { FacultyHousingView } from './FacultyHousingView';
import { FacultyGuestHouseView } from './FacultyGuestHouseView';
import { FacultySecurityApprovalsView } from './FacultySecurityApprovalsView';
import { FacultyLabAccessView } from './FacultyLabAccessView';
import { FacultyEventClearanceView } from './FacultyEventClearanceView';

import { PortalSidebar, PortalSidebarItem } from '../common/PortalSidebar';
import { StudentAcademicProfileModal } from '../academic/StudentAcademicProfileModal';

export type FacultyTab =
  // 1. Dashboard / Home
  | 'overview'
  | 'dashboard'
  // 2. Academics
  | 'courses'
  | 'classes'
  | 'timetable'
  | 'attendance'
  | 'students'
  | 'mark-entry'
  | 'marks-status'
  | 'performance'
  // 3. Research
  | 'research'
  | 'research-grants'
  | 'patents'
  // 4. Profile / Faculty Info
  | 'profile'
  | 'profile-info'
  | 'qualifications'
  // 5. Students / Proctoring
  | 'student-mentees'
  | 'proctor'
  | 'leave-approvals'
  // 6. Administration
  | 'admin'
  | 'committees'
  | 'circulars'
  // 7. Courses / LMS
  | 'courses-lms'
  | 'announcements'
  | 'syllabi'
  // 8. Achievements / Activities
  | 'achievements'
  | 'fdp-workshops'
  // 9. People / Contacts
  | 'people'
  | 'dept-directory'
  // 10. Settings / Configuration
  | 'settings'
  | 'account-security'
  // 11. Hostel / Campus Services
  | 'hostel'
  | 'faculty-housing'
  | 'guest-house'
  // 12. Security / Approvals
  | 'security'
  | 'lab-access'
  | 'event-clearance';

interface FacultyWorkspaceProps {
  onRefreshRoot?: () => Promise<void>;
}

export function FacultyWorkspace({ onRefreshRoot }: FacultyWorkspaceProps) {
  const { session, logout, dataAdapter } = useAuth();

  const [activeTab, setActiveTab] = useState<FacultyTab>('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Core Data
  const [employee, setEmployee] = useState<EmployeeRecord | null>(session?.employeeProfile || null);
  const [assignments, setAssignments] = useState<FacultyCourseAssignmentRecord[]>([]);
  const [courses, setCourses] = useState<CourseRecord[]>([]);
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [timetableSlots, setTimetableSlots] = useState<TimetableSlotRecord[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [examSchedules, setExamSchedules] = useState<ExamScheduleRecord[]>([]);
  const [examResults, setExamResults] = useState<ExamResultRecord[]>([]);
  const [allEmployees, setAllEmployees] = useState<EmployeeRecord[]>([]);
  const [proctorAssignments, setProctorAssignments] = useState<ProctorAssignment[]>([]);

  // Selected Student Modal
  const [selectedRegNo, setSelectedRegNo] = useState<string | null>(null);

  const facultyEmployeeId = session?.employeeProfile?.employee_id || session?.userId || '';
  const facultyUsername = session?.user?.username || session?.userId || '';
  const facultyDisplayName =
    session?.displayName ||
    `${employee?.first_name || ''} ${employee?.last_name || ''}`.trim() ||
    session?.user?.username ||
    'Faculty Member';

  // Load All Authoritative Data
  const loadData = useCallback(async () => {
    if (!facultyEmployeeId) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const actor = {
        userId: facultyUsername,
        role: session?.role || AuthRole.FACULTY,
        employeeId: facultyEmployeeId,
      };

      // 1. Fetch employee profile
      let emp = session?.employeeProfile || null;
      if (!emp && dataAdapter.employees?.getById) {
        emp = await dataAdapter.employees.getById(facultyEmployeeId);
      }
      if (emp) setEmployee(emp);

      // 2. Parallel queries for academic state
      const [
        myAssignments,
        allCourses,
        allStudents,
        allEnrolments,
        allTimetable,
        allAttendance,
        allSchedules,
        allEmps,
        myProctorAssignments,
      ] = await Promise.all([
        dataAdapter.facultyAssignments?.getByFaculty
          ? dataAdapter.facultyAssignments.getByFaculty(facultyEmployeeId)
          : Promise.resolve([]),
        dataAdapter.academic?.getCourses ? dataAdapter.academic.getCourses() : Promise.resolve([]),
        dataAdapter.students?.getAll ? dataAdapter.students.getAll() : Promise.resolve([]),
        dataAdapter.academic?.getEnrolments
          ? dataAdapter.academic.getEnrolments({}, actor)
          : Promise.resolve([]),
        dataAdapter.academic?.getTimetable
          ? dataAdapter.academic.getTimetable({ faculty_id: facultyEmployeeId })
          : Promise.resolve([]),
        dataAdapter.attendance?.getAll ? dataAdapter.attendance.getAll() : Promise.resolve([]),
        dataAdapter.coe?.getSchedules ? dataAdapter.coe.getSchedules() : Promise.resolve([]),
        dataAdapter.employees?.getAll ? dataAdapter.employees.getAll() : Promise.resolve([]),
        proctorRepository.getActiveAssignmentsForFaculty(facultyEmployeeId, actor),
      ]);

      const activeAssignments = (myAssignments || []).filter(
        (a) => a.assignment_status === 'ACTIVE'
      );
      setAssignments(activeAssignments);
      setCourses(allCourses || []);
      setTimetableSlots(allTimetable || []);
      setAllEmployees(allEmps || []);
      setProctorAssignments(myProctorAssignments || []);

      // Institutional Data Access Scoping:
      // Faculty members only have access to students, enrolments, attendance, and exam schedules
      // corresponding to their active course-section assignments and assigned proctees.
      const assignedCourseCodes = new Set(activeAssignments.map((a) => a.course_code));
      const assignedCourseSectionKeys = new Set(
        activeAssignments.map((a) => `${a.course_code}::${a.section}`)
      );
      const procteeStudentIds = new Set(
        (myProctorAssignments || []).map((p) => p.studentId).filter(Boolean)
      );
      const procteeRegNos = new Set(
        (myProctorAssignments || []).map((p) => p.studentRegistrationNumber).filter(Boolean)
      );

      // Scoped enrolments: Enrolled in faculty's assigned course/section OR active proctee
      const scopedEnrolments = (allEnrolments || []).filter((e) => {
        if (e.enrolment_status !== 'ACTIVE') return false;
        const matchesCourseSection =
          assignedCourseSectionKeys.has(`${e.course_code}::${e.section}`) ||
          assignedCourseSectionKeys.has(`${e.course_code}::ALL`);
        const isProctee =
          procteeStudentIds.has(e.student_id) ||
          procteeRegNos.has(e.student_registration_number);
        return matchesCourseSection || isProctee;
      });
      setEnrolments(scopedEnrolments);

      // Scoped students: Distinct set of students in faculty's courses or proctee list
      const authorizedStudentIds = new Set([
        ...scopedEnrolments.map((e) => e.student_id),
        ...procteeStudentIds,
      ]);
      const authorizedRegNos = new Set([
        ...scopedEnrolments.map((e) => e.student_registration_number),
        ...procteeRegNos,
      ]);
      const scopedStudents = (allStudents || []).filter(
        (s) =>
          authorizedStudentIds.has(s.student_id) ||
          authorizedRegNos.has(s.registration_number)
      );
      setStudents(scopedStudents);

      // Scoped attendance: Records for assigned courses/sections or proctees
      const scopedAttendance = (allAttendance || []).filter((a) => {
        const matchesCourse =
          assignedCourseSectionKeys.has(`${a.course_code}::${a.section || 'ALL'}`) ||
          assignedCourseSectionKeys.has(`${a.course_code}::ALL`) ||
          assignedCourseCodes.has(a.course_code);
        const isProctee =
          authorizedStudentIds.has(a.student_id) ||
          authorizedRegNos.has(a.registration_number || a.student_registration_number || '');
        return matchesCourse || isProctee;
      });
      setAttendanceRecords(scopedAttendance);

      // Scoped exam schedules: Only schedules for assigned courses
      const scopedSchedules = (allSchedules || []).filter((s) => {
        if (!assignedCourseCodes.has(s.course_code)) return false;
        if (s.section && s.section !== 'ALL') {
          return assignedCourseSectionKeys.has(`${s.course_code}::${s.section}`);
        }
        return true;
      });
      setExamSchedules(scopedSchedules);
    } catch (err) {
      console.error('Failed to load faculty portal data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [dataAdapter, facultyEmployeeId, facultyUsername, session]);

  useEffect(() => {
    loadData();
    const unsub = proctorRepository.subscribe(() => {
      loadData();
    });
    return unsub;
  }, [loadData]);

  // Attendance handlers
  const handleRecordAttendance = async (data: {
    student_id: string;
    registration_number: string;
    course_code: string;
    section: string;
    date: string;
    session_slot: number | string;
    status: AttendanceStatus;
    remarks?: string;
  }) => {
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    const res = await dataAdapter.attendance.record(
      {
        ...data,
        session_slot: String(data.session_slot),
        recorded_by_employee_id: facultyEmployeeId,
      },
      actor
    );
    await loadData();
    return res;
  };

  const handleCorrectAttendance = async (
    attendanceId: string,
    status: AttendanceStatus,
    reason: string
  ) => {
    if (!dataAdapter.attendance.correctAttendance) {
      throw new Error('Attendance correction service is not configured.');
    }
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    const res = await dataAdapter.attendance.correctAttendance(attendanceId, status, reason, actor);
    await loadData();
    return res;
  };

  // Marks handlers
  const handleGetMarks = async (scheduleId: string) => {
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    return dataAdapter.coe.getMarks(scheduleId, actor);
  };

  const handleCheckEligibility = async (scheduleId: string) => {
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    return dataAdapter.coe.checkEligibility(scheduleId, actor);
  };

  const handleSaveDraftMarks = async (
    scheduleId: string,
    entries: {
      student_id: string;
      internal_marks?: number;
      external_marks?: number;
      submission_notes?: string;
    }[]
  ) => {
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    const res = await dataAdapter.coe.saveDraftMarks(scheduleId, entries, actor);
    await loadData();
    return res;
  };

  const handleSubmitMarksForReview = async (scheduleId: string, notes?: string) => {
    const actor = {
      userId: session?.user?.username || facultyEmployeeId,
      role: session?.role || 'FACULTY',
      employeeId: facultyEmployeeId,
    };
    const res = await dataAdapter.coe.submitMarksForReview(scheduleId, notes, actor);
    await loadData();
    return res;
  };

  // Profile update handler
  const handleUpdateProfile = async (updatedData: Partial<EmployeeRecord>) => {
    if (!employee) return;
    const updated = await dataAdapter.employees.update(employee.employee_id, updatedData);
    setEmployee(updated);
    await loadData();
  };

  // Exactly 12 Main Sidebar Navigation Destinations in Canonical Order
  const facultyNavItems: PortalSidebarItem[] = useMemo(() => {
    const pendingMarksCount = examSchedules.filter(
      (s) => s.marks_entry_open && assignments.some((a) => a.course_code === s.course_code)
    ).length;

    return [
      // 1. Dashboard / Home
      {
        id: 'overview',
        label: 'Dashboard / Home',
        icon: LayoutDashboard,
      },
      // 2. Academics (expandable)
      {
        id: 'academics-group',
        label: 'Academics',
        icon: GraduationCap,
        subItems: [
          {
            id: 'courses',
            label: 'My Classes & Subjects',
            icon: BookOpen,
            badge: assignments.length,
            badgeVariant: 'blue',
          },
          {
            id: 'timetable',
            label: 'Teaching Timetable',
            icon: Clock,
            badge: timetableSlots.length > 0 ? timetableSlots.length : undefined,
            badgeVariant: 'default',
          },
          {
            id: 'attendance',
            label: 'Attendance Register',
            icon: CalendarCheck,
          },
          {
            id: 'students',
            label: 'Student Rosters',
            icon: Users,
            badge: students.length > 0 ? students.length : undefined,
            badgeVariant: 'default',
          },
          {
            id: 'mark-entry',
            label: 'Exam Mark Entry',
            icon: GraduationCap,
            badge: pendingMarksCount > 0 ? pendingMarksCount : undefined,
            badgeVariant: 'amber',
          },
          {
            id: 'marks-status',
            label: 'Marks Submission Status',
            icon: FileCheck2,
          },
          {
            id: 'performance',
            label: 'Student Performance',
            icon: Sparkles,
          },
        ],
      },
      // 3. Research (expandable)
      {
        id: 'research-group',
        label: 'Research',
        icon: FlaskConical,
        subItems: [
          {
            id: 'research',
            label: 'Research & Publications',
            icon: FlaskConical,
          },
          {
            id: 'research-grants',
            label: 'Funded Grants & Projects',
            icon: Layers,
          },
          {
            id: 'patents',
            label: 'Patents & Disclosures',
            icon: Award,
          },
        ],
      },
      // 4. Profile / Faculty Info (expandable)
      {
        id: 'profile-group',
        label: 'Profile / Faculty Info',
        icon: User,
        subItems: [
          {
            id: 'profile',
            label: 'Faculty Profile & Workload',
            icon: User,
          },
          {
            id: 'qualifications',
            label: 'Qualifications & Credentials',
            icon: FileCheck2,
          },
        ],
      },
      // 5. Students / Proctoring (expandable)
      {
        id: 'students-proctor-group',
        label: 'Students / Proctoring',
        icon: Users,
        badge: proctorAssignments.length > 0 ? proctorAssignments.length : undefined,
        badgeVariant: 'emerald',
        subItems: [
          {
            id: 'student-mentees',
            label: 'Student Rosters / Mentees',
            icon: Users,
            badge: proctorAssignments.length > 0 ? proctorAssignments.length : undefined,
            badgeVariant: 'emerald',
          },
          {
            id: 'proctor',
            label: 'Proctor Mentorship Desk',
            icon: ShieldCheck,
            badge: proctorAssignments.length > 0 ? proctorAssignments.length : undefined,
            badgeVariant: 'emerald',
          },
          {
            id: 'leave-approvals',
            label: 'Leave & Outing Endorsements',
            icon: CalendarCheck,
          },
        ],
      },
      // 6. Administration (expandable)
      {
        id: 'admin-group',
        label: 'Administration',
        icon: Landmark,
        subItems: [
          {
            id: 'admin',
            label: 'Departmental Administration',
            icon: Landmark,
          },
          {
            id: 'committees',
            label: 'Institutional Committees',
            icon: Users,
          },
          {
            id: 'circulars',
            label: 'Official Circulars & Orders',
            icon: Megaphone,
          },
        ],
      },
      // 7. Courses / LMS (expandable)
      {
        id: 'courses-lms-group',
        label: 'Courses / LMS',
        icon: BookOpen,
        subItems: [
          {
            id: 'courses-lms',
            label: 'Course Materials & LMS',
            icon: BookOpen,
          },
          {
            id: 'announcements',
            label: 'Class Announcements',
            icon: Megaphone,
          },
          {
            id: 'syllabi',
            label: 'Curriculum Syllabi & References',
            icon: FileCheck2,
          },
        ],
      },
      // 8. Achievements / Activities (expandable)
      {
        id: 'achievements-group',
        label: 'Achievements / Activities',
        icon: Award,
        subItems: [
          {
            id: 'achievements',
            label: 'Achievements & Recognition',
            icon: Award,
          },
          {
            id: 'fdp-workshops',
            label: 'Faculty Development & Conferences',
            icon: Sparkles,
          },
        ],
      },
      // 9. People / Contacts (expandable)
      {
        id: 'people-group',
        label: 'People / Contacts',
        icon: Contact,
        subItems: [
          {
            id: 'people',
            label: 'Campus & Faculty Directory',
            icon: Contact,
          },
          {
            id: 'dept-directory',
            label: 'Department Directory & Extensions',
            icon: Building2,
          },
        ],
      },
      // 10. Settings / Configuration (expandable)
      {
        id: 'settings-group',
        label: 'Settings / Configuration',
        icon: Settings,
        subItems: [
          {
            id: 'settings',
            label: 'Preferences & Configuration',
            icon: Settings,
          },
          {
            id: 'account-security',
            label: 'Password & Active Sessions',
            icon: ShieldCheck,
          },
        ],
      },
      // 11. Hostel / Campus Services (expandable)
      {
        id: 'hostel-group',
        label: 'Hostel / Campus Services',
        icon: Building2,
        subItems: [
          {
            id: 'hostel',
            label: 'Hostel & Campus Services',
            icon: Building2,
          },
          {
            id: 'faculty-housing',
            label: 'Staff Quarters & Maintenance',
            icon: Building2,
          },
          {
            id: 'guest-house',
            label: 'Campus Guest House Requests',
            icon: CalendarCheck,
          },
        ],
      },
      // 12. Security / Approvals (expandable)
      {
        id: 'security-group',
        label: 'Security / Approvals',
        icon: ShieldAlert,
        subItems: [
          {
            id: 'security',
            label: 'Security & Approvals',
            icon: ShieldAlert,
          },
          {
            id: 'lab-access',
            label: 'Laboratory Special Clearances',
            icon: ShieldCheck,
          },
          {
            id: 'event-clearance',
            label: 'Academic Event Permissions',
            icon: CheckCircle2,
          },
        ],
      },
    ];
  }, [assignments, timetableSlots, examSchedules, proctorAssignments, students.length]);

  if (
    !session ||
    !facultyEmployeeId ||
    (session.role !== AuthRole.FACULTY &&
      session.role !== AuthRole.SUPER_ADMIN &&
      !session.employeeProfile)
  ) {
    return (
      <div className="min-h-screen bg-[#F6F8FB] flex items-center justify-center p-6">
        <div className="bg-white border border-[#e2e8f0] rounded-2xl p-8 max-w-md w-full text-center shadow-xs">
          <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h2 className="text-lg font-bold text-slate-800 mb-2">Faculty Authentication Required</h2>
          <p className="text-sm text-slate-600 mb-6">
            A valid authenticated Employee Portal session with faculty credentials is required to access the Faculty Workspace.
          </p>
          <button
            onClick={() => logout?.()}
            className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition"
          >
            Return to Portal Selection
          </button>
        </div>
      </div>
    );
  }

  const actorContext = {
    userId: facultyUsername,
    role: session?.role || AuthRole.FACULTY,
    employeeId: facultyEmployeeId,
  };

  // Normalization for backward compatibility of tab names
  const normalizedTab =
    activeTab === 'dashboard'
      ? 'overview'
      : activeTab === 'classes'
      ? 'courses'
      : activeTab === 'profile-info'
      ? 'profile'
      : activeTab;

  return (
    <div className="min-h-screen bg-[#F6F8FB] flex flex-col">
      {/* Header */}
      <FacultyHeader
        displayName={facultyDisplayName}
        employeeId={employee?.employee_id || facultyEmployeeId}
        registrationNumber={employee?.registration_number}
        designation={employee?.designation}
        department={employee?.primary_department}
        currentTerm="Fall 2026–2027"
        isMobileMenuOpen={isMobileMenuOpen}
        onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        onLogout={logout}
        notificationCount={proctorAssignments.length}
        onSelectTab={(tabId) => setActiveTab(tabId as FacultyTab)}
      />

      {/* Main Workspace Layout (Sidebar + Canvas) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col lg:flex-row gap-6">
        {/* Left Navigation Sidebar */}
        <PortalSidebar
          items={facultyNavItems}
          activeTab={normalizedTab}
          onSelectTab={(tabId) => {
            setActiveTab(tabId as FacultyTab);
            setIsMobileMenuOpen(false);
          }}
          isOpenMobile={isMobileMenuOpen}
          idPrefix="faculty-nav"
          footerSlot={
            proctorAssignments.length > 0 ? (
              <div className="pt-2 mt-2 border-t border-[#f1f5f9] px-2">
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                  <span>Designated Proctor ({proctorAssignments.length} Wards)</span>
                </div>
              </div>
            ) : undefined
          }
        />

        {/* Main Canvas */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="py-24 text-center text-xs text-slate-400">
              Loading Faculty Workspace...
            </div>
          ) : (
            <>
              {/* ======================================================== */}
              {/* 1. Dashboard / Home */}
              {/* ======================================================== */}
              {normalizedTab === 'overview' && (
                <FacultyOverviewView
                  facultyName={facultyDisplayName}
                  employeeId={employee?.employee_id || facultyEmployeeId}
                  registrationNumber={employee?.registration_number || ''}
                  department={employee?.primary_department || 'Computer Science & Engineering'}
                  designation={employee?.designation || 'Assistant Professor'}
                  assignments={assignments}
                  students={students}
                  enrolments={enrolments}
                  timetableSlots={timetableSlots}
                  examSchedules={examSchedules}
                  proctorCount={proctorAssignments.length}
                  pendingProctorRequestsCount={0}
                  announcementsCount={1}
                  onNavigateTab={(tab) => setActiveTab(tab as FacultyTab)}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                />
              )}

              {/* ======================================================== */}
              {/* 2. Academics */}
              {/* ======================================================== */}
              {normalizedTab === 'courses' && (
                <FacultyCoursesView
                  assignments={assignments}
                  courses={courses}
                  students={students}
                  enrolments={enrolments}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                  onNavigateTab={(tab) => setActiveTab(tab as FacultyTab)}
                />
              )}

              {normalizedTab === 'timetable' && (
                <FacultyTimetableView
                  slots={timetableSlots}
                  facultyName={facultyDisplayName}
                />
              )}

              {normalizedTab === 'attendance' && (
                <FacultyAttendanceView
                  assignments={assignments}
                  students={students}
                  enrolments={enrolments}
                  attendanceRecords={attendanceRecords}
                  facultyId={facultyEmployeeId}
                  facultyName={facultyDisplayName}
                  onRecordAttendance={handleRecordAttendance}
                  onCorrectAttendance={handleCorrectAttendance}
                  onRefreshData={loadData}
                />
              )}

              {normalizedTab === 'students' && (
                <FacultyStudentRosterView
                  students={students}
                  assignments={assignments}
                  enrolments={enrolments}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                />
              )}

              {normalizedTab === 'mark-entry' && (
                <FacultyMarksEntryView
                  assignments={assignments}
                  examSchedules={examSchedules}
                  students={students}
                  facultyId={facultyEmployeeId}
                  facultyName={facultyDisplayName}
                  onGetMarks={handleGetMarks}
                  onCheckEligibility={handleCheckEligibility}
                  onSaveDraftMarks={handleSaveDraftMarks}
                  onSubmitMarksForReview={handleSubmitMarksForReview}
                  onRefreshData={loadData}
                />
              )}

              {normalizedTab === 'marks-status' && (
                <FacultyMarksStatusView
                  assignments={assignments}
                  examSchedules={examSchedules}
                  examResults={examResults}
                  onSelectScheduleForEntry={(_scheduleId) => {
                    setActiveTab('mark-entry');
                  }}
                />
              )}

              {normalizedTab === 'performance' && (
                <FacultyPerformanceView
                  assignments={assignments}
                  students={students}
                  enrolments={enrolments}
                  attendanceRecords={attendanceRecords}
                  examResults={examResults}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                />
              )}

              {/* ======================================================== */}
              {/* 3. Research */}
              {/* ======================================================== */}
              {normalizedTab === 'research' && <FacultyResearchView />}

              {normalizedTab === 'research-grants' && <FacultyGrantsView />}

              {normalizedTab === 'patents' && <FacultyPatentsView />}

              {/* ======================================================== */}
              {/* 4. Profile / Faculty Info */}
              {/* ======================================================== */}
              {normalizedTab === 'profile' && (
                <FacultyProfileView
                  employee={employee}
                  assignments={assignments}
                  onUpdateProfile={handleUpdateProfile}
                />
              )}

              {normalizedTab === 'qualifications' && (
                <FacultyQualificationsView employee={employee} />
              )}

              {/* ======================================================== */}
              {/* 5. Students / Proctoring */}
              {/* ======================================================== */}
              {normalizedTab === 'student-mentees' && (
                <FacultyMenteesView
                  assignments={proctorAssignments}
                  students={students}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                  onNavigateToProctorDesk={() => setActiveTab('proctor')}
                />
              )}

              {normalizedTab === 'proctor' && (
                <FacultyProctorView
                  facultyId={facultyEmployeeId}
                  facultyName={facultyDisplayName}
                  facultyEmail={employee?.institutional_email}
                  assignments={proctorAssignments}
                  students={students}
                  actor={actorContext}
                  onOpenStudentProfile={(regNo) => setSelectedRegNo(regNo)}
                />
              )}

              {normalizedTab === 'leave-approvals' && (
                <FacultyLeaveApprovalsView
                  facultyId={facultyEmployeeId}
                  actor={actorContext}
                />
              )}

              {/* ======================================================== */}
              {/* 6. Administration */}
              {/* ======================================================== */}
              {normalizedTab === 'admin' && (
                <FacultyAdminView
                  department={employee?.primary_department}
                  facultyName={facultyDisplayName}
                />
              )}

              {normalizedTab === 'committees' && <FacultyCommitteesView />}

              {normalizedTab === 'circulars' && <FacultyCircularsView />}

              {/* ======================================================== */}
              {/* 7. Courses / LMS */}
              {/* ======================================================== */}
              {normalizedTab === 'courses-lms' && (
                <FacultyLmsView assignments={assignments} />
              )}

              {normalizedTab === 'announcements' && (
                <FacultyAnnouncementsView
                  assignments={assignments}
                  facultyId={facultyEmployeeId}
                  facultyName={facultyDisplayName}
                />
              )}

              {normalizedTab === 'syllabi' && (
                <FacultySyllabusView assignments={assignments} />
              )}

              {/* ======================================================== */}
              {/* 8. Achievements / Activities */}
              {/* ======================================================== */}
              {normalizedTab === 'achievements' && <FacultyAchievementsView />}

              {normalizedTab === 'fdp-workshops' && <FacultyFdpView />}

              {/* ======================================================== */}
              {/* 9. People / Contacts */}
              {/* ======================================================== */}
              {normalizedTab === 'people' && (
                <FacultyDirectoryView employees={allEmployees} />
              )}

              {normalizedTab === 'dept-directory' && <FacultyDeptDirectoryView />}

              {/* ======================================================== */}
              {/* 10. Settings / Configuration */}
              {/* ======================================================== */}
              {normalizedTab === 'settings' && <FacultySettingsView />}

              {normalizedTab === 'account-security' && <FacultySecuritySettingsView />}

              {/* ======================================================== */}
              {/* 11. Hostel / Campus Services */}
              {/* ======================================================== */}
              {normalizedTab === 'hostel' && (
                <FacultyHostelServicesView
                  onNavigateSubtab={(sub) => setActiveTab(sub as FacultyTab)}
                />
              )}

              {normalizedTab === 'faculty-housing' && <FacultyHousingView />}

              {normalizedTab === 'guest-house' && <FacultyGuestHouseView />}

              {/* ======================================================== */}
              {/* 12. Security / Approvals */}
              {/* ======================================================== */}
              {normalizedTab === 'security' && (
                <FacultySecurityApprovalsView
                  onNavigateSubtab={(sub) => setActiveTab(sub as FacultyTab)}
                />
              )}

              {normalizedTab === 'lab-access' && <FacultyLabAccessView />}

              {normalizedTab === 'event-clearance' && <FacultyEventClearanceView />}
            </>
          )}

          {/* Student Academic Profile Modal */}
          {selectedRegNo && (
            <StudentAcademicProfileModal
              registrationNumber={selectedRegNo}
              actor={actorContext}
              onClose={() => setSelectedRegNo(null)}
            />
          )}
        </main>
      </div>
    </div>
  );
}
