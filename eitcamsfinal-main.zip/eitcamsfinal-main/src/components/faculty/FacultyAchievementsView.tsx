import React, { useState } from 'react';
import {
  Award,
  Plus,
  Trophy,
  Medal,
  Calendar,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface FacultyAward {
  id: string;
  title: string;
  awardingBody: string;
  year: number;
  category: 'Teaching Excellence' | 'Research Impact' | 'Institutional Leadership' | 'Best Paper';
  description: string;
}

export function FacultyAchievementsView() {
  const [achievements, setAchievements] = useState<FacultyAward[]>([
    {
      id: 'AWD-2025-01',
      title: 'Distinguished Faculty Teaching Excellence Award (2024–25)',
      awardingBody: 'Electrix Institute of Technology Senate',
      year: 2025,
      category: 'Teaching Excellence',
      description: 'Conferred in recognition of outstanding student evaluations, interactive pedagogical innovations, and mentoring outcomes in core computing courses.',
    },
    {
      id: 'AWD-2024-02',
      title: 'IEEE Senior Member Elevation (SMIEEE)',
      awardingBody: 'Institute of Electrical and Electronics Engineers (USA)',
      year: 2024,
      category: 'Institutional Leadership',
      description: 'Recognized for substantial professional achievements and 10+ years of active scholarship in distributed systems architecture.',
    },
    {
      id: 'AWD-2023-01',
      title: 'Best Research Paper Award (ICDCN 2023)',
      awardingBody: 'International Conference on Distributed Computing and Networking',
      year: 2023,
      category: 'Best Paper',
      description: 'Awarded for landmark research contribution on resilient quorum systems for partition-tolerant clouds.',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [category, setCategory] = useState<'Teaching Excellence' | 'Research Impact' | 'Institutional Leadership' | 'Best Paper'>('Teaching Excellence');
  const [year, setYear] = useState(2026);
  const [desc, setDesc] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    const newAwd: FacultyAward = {
      id: `AWD-${Date.now().toString().slice(-4)}`,
      title: title.trim(),
      awardingBody: body.trim(),
      year: Number(year) || 2026,
      category,
      description: desc.trim() || 'Conferred for professional academic merit.',
    };

    setAchievements([newAwd, ...achievements]);
    setIsModalOpen(false);
    setTitle('');
    setBody('');
    setDesc('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Faculty Honours, Awards & Institutional Recognition</h2>
            <Badge variant="blue">{achievements.length} Honors</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Institutional portfolio of academic prizes, teaching citations, external fellowships, and keynote honors.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Record New Achievement
        </Button>
      </div>

      {/* Grid of Achievements */}
      <div className="space-y-4">
        {achievements.map((awd) => (
          <div
            key={awd.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {awd.id}
                  </span>
                  <Badge variant="blue">{awd.category}</Badge>
                  <span className="font-mono text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {awd.year}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-[#1e293b] pt-1 flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{awd.title}</span>
                </h3>
                <div className="text-xs text-[#64748b]">
                  Conferred by: <strong className="text-slate-800">{awd.awardingBody}</strong>
                </div>
                <p className="text-xs text-[#64748b] leading-relaxed pt-1">{awd.description}</p>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full font-medium">
                  <Medal className="w-3.5 h-3.5 text-amber-600" />
                  <span>Honour Certified</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Record Academic Honor or Award</h3>
            <p className="text-xs text-[#64748b]">
              Submit details of award or institutional distinction for university appraisal records.
            </p>

            <form onSubmit={handleAdd} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Award / Honor Title</label>
                <Input
                  required
                  placeholder="e.g., Outstanding Young Scientist Citation"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Awarding Organization</label>
                  <Input
                    required
                    placeholder="e.g., INAE, ACM, EIT"
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    className="text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Year Conferred</label>
                  <Input
                    type="number"
                    value={year}
                    onChange={(e) => setYear(Number(e.target.value))}
                    className="text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="Teaching Excellence">Teaching Excellence</option>
                  <option value="Research Impact">Research Impact</option>
                  <option value="Institutional Leadership">Institutional Leadership</option>
                  <option value="Best Paper">Best Paper</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Citation Description</label>
                <textarea
                  rows={3}
                  placeholder="Briefly state the basis of the honor or achievement..."
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Save Award
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
