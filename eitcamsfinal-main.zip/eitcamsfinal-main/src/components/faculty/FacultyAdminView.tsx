import React, { useState } from 'react';
import {
  Landmark,
  Calendar,
  Users,
  FileText,
  Clock,
  CheckCircle2,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface FacultyAdminViewProps {
  department?: string;
  facultyName?: string;
}

export function FacultyAdminView({
  department = 'Computer Science & Engineering',
  facultyName = 'Faculty Member',
}: FacultyAdminViewProps) {
  const meetings = [
    {
      id: 'MTG-BOS-2026-02',
      title: 'Departmental Board of Studies (BoS) Curriculum Review Meeting',
      date: '2026-11-18',
      time: '02:30 PM – 04:30 PM',
      venue: 'Department Conference Hall 301',
      agenda: 'Finalizing B.Tech CSE 2027 Regulation curriculum revision and AI specialization electives.',
      status: 'UPCOMING',
    },
    {
      id: 'MTG-FAC-2026-11',
      title: 'Monthly Department Faculty Council & Academic Review',
      date: '2026-11-25',
      time: '10:00 AM – 11:30 AM',
      venue: 'Seminar Hall B',
      agenda: 'Continuous assessment review, lab equipment maintenance audit, and mid-term feedback.',
      status: 'SCHEDULED',
    },
    {
      id: 'MTG-NBA-2026-09',
      title: 'NBA Tier-1 Accreditation Criterion 4 Working Committee Session',
      date: '2026-10-28',
      time: '03:00 PM – 05:00 PM',
      venue: 'Dean Office Meeting Room',
      agenda: 'Course outcome (CO) - Programme outcome (PO) attainment calculation audit.',
      status: 'COMPLETED',
    },
  ];

  const departmentalDuties = [
    {
      role: 'Curriculum Revision Coordinator',
      committee: 'Department Board of Studies',
      period: '2025 – 2027',
      assignedBy: 'Head of Department (HOD)',
      status: 'Active Duty',
    },
    {
      role: 'Faculty In-Charge (Systems & Cloud Computing Lab)',
      committee: 'Infrastructure & Labs Committee',
      period: '2024 – 2026',
      assignedBy: 'Dean of Academic Affairs',
      status: 'Active Duty',
    },
    {
      role: 'NBA Accreditation Criteria 3 Lead',
      committee: 'Internal Quality Assurance Cell (IQAC)',
      period: '2025 – 2026',
      assignedBy: 'Principal / Director',
      status: 'Active Duty',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Departmental Administration & Governance</h2>
            <Badge variant="blue">{department}</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Department council records, Board of Studies agendas, and academic administration responsibilities.
          </p>
        </div>
      </div>

      {/* Grid: Meetings & Workload */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Meetings */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#1e3a8a]" />
              <span>Department Council & BoS Meetings</span>
            </span>
            <span className="text-xs text-slate-500 font-normal">Term 2026–27</span>
          </h3>

          <div className="space-y-3">
            {meetings.map((m) => (
              <div
                key={m.id}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs font-bold text-[#1e293b]">{m.title}</span>
                  <Badge variant={m.status === 'UPCOMING' ? 'blue' : m.status === 'SCHEDULED' ? 'amber' : 'default'}>
                    {m.status}
                  </Badge>
                </div>
                <p className="text-xs text-[#64748b]">{m.agenda}</p>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-[#64748b]">
                  <span className="font-semibold text-slate-700">{m.date} &bull; {m.time}</span>
                  <span className="text-slate-500">{m.venue}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Assigned Departmental Duties */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
            <Landmark className="w-4 h-4 text-[#1e3a8a]" />
            <span>Assigned Departmental Responsibilities</span>
          </h3>

          <div className="space-y-3">
            {departmentalDuties.map((d, i) => (
              <div
                key={i}
                className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2 hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-[#1e293b]">{d.role}</h4>
                    <div className="text-xs text-[#64748b] mt-0.5">{d.committee}</div>
                  </div>
                  <Badge variant="emerald">{d.status}</Badge>
                </div>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-[#64748b]">
                  <span>Tenure: <strong>{d.period}</strong></span>
                  <span>Authority: {d.assignedBy}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
