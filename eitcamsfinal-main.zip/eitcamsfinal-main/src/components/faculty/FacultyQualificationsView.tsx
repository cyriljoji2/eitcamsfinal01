import React from 'react';
import {
  GraduationCap,
  Award,
  Briefcase,
  BookOpen,
  Calendar,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { EmployeeRecord } from '../../types/database';

interface FacultyQualificationsViewProps {
  employee: EmployeeRecord | null;
}

export function FacultyQualificationsView({ employee }: FacultyQualificationsViewProps) {
  const degrees = [
    {
      degree: 'Ph.D. in Computer Science & Engineering',
      institution: 'Indian Institute of Technology (IIT) Madras',
      year: '2019',
      specialization: 'Distributed Systems & High-Performance Cloud Architectures',
      honors: 'Institute Best Doctoral Dissertation Gold Medal',
    },
    {
      degree: 'M.Tech in Computer Science',
      institution: 'National Institute of Technology (NIT) Trichy',
      year: '2014',
      specialization: 'Advanced Computer Networks & Cryptography',
      honors: 'First Class with Distinction (CGPA: 9.42 / 10.0)',
    },
    {
      degree: 'B.Tech in Information Technology',
      institution: 'Anna University, College of Engineering Guindy',
      year: '2012',
      specialization: 'Information Technology & Systems Engineering',
      honors: 'University 4th Rank Holder',
    },
  ];

  const experience = [
    {
      role: 'Associate Professor',
      organization: 'Electrix Institute of Technology (EIT)',
      period: 'July 2023 – Present',
      department: 'Department of Computer Science & Engineering',
      type: 'Teaching & Research',
    },
    {
      role: 'Assistant Professor (Senior Grade)',
      organization: 'Electrix Institute of Technology (EIT)',
      period: 'August 2019 – June 2023',
      department: 'Department of Computer Science & Engineering',
      type: 'Teaching & Research',
    },
    {
      role: 'Postdoctoral Research Associate',
      organization: 'Distributed Computing Lab, IIT Madras',
      period: 'January 2019 – July 2019',
      department: 'High Performance Computing Centre',
      type: 'R&D',
    },
    {
      role: 'Systems Software Engineer',
      organization: 'Cisco Systems India R&D',
      period: 'July 2014 – December 2015',
      department: 'Core Routing & SDN Division',
      type: 'Industry Experience',
    },
  ];

  const certifications = [
    {
      title: 'AWS Certified Solutions Architect – Professional',
      issuer: 'Amazon Web Services',
      validity: '2024 – 2027',
      certId: 'AWS-PSA-990142',
    },
    {
      title: 'Senior Member, IEEE Computer Society (SMIEEE)',
      issuer: 'Institute of Electrical and Electronics Engineers',
      validity: 'Lifetime Membership',
      certId: 'IEEE-92109418',
    },
    {
      title: 'ACM Professional Member',
      issuer: 'Association for Computing Machinery',
      validity: 'Active (Since 2016)',
      certId: 'ACM-098124',
    },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Academic Qualifications & Professional Experience</h2>
            <Badge variant="blue">Verified Dossier</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Authoritative university credentials, verified degrees, prior academic appointments, and chartered professional memberships.
          </p>
        </div>
      </div>

      {/* Degrees & Higher Education */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <GraduationCap className="w-4 h-4 text-[#1e3a8a]" />
          <span>Earned Degrees & Higher Education</span>
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {degrees.map((d, i) => (
            <div
              key={i}
              className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-[#1e293b]">{d.degree}</h4>
                  <span className="font-mono text-xs font-semibold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {d.year}
                  </span>
                </div>
                <div className="text-xs text-[#64748b]">
                  {d.institution} &bull; <span className="text-slate-700 font-medium">{d.specialization}</span>
                </div>
                {d.honors && (
                  <div className="text-[11px] text-emerald-700 flex items-center gap-1 font-semibold pt-0.5">
                    <Award className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{d.honors}</span>
                  </div>
                )}
              </div>

              <div className="shrink-0 flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verified by Registrar</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Academic & Professional Appointments */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-[#1e3a8a]" />
          <span>Career History & Teaching Appointments</span>
        </h3>

        <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
          {experience.map((exp, i) => (
            <div key={i} className="relative">
              <div className="absolute -left-6 top-1.5 w-2.5 h-2.5 rounded-full bg-[#1e3a8a] ring-4 ring-blue-50" />
              <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-1">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <h4 className="text-xs font-bold text-[#1e293b]">{exp.role}</h4>
                  <span className="text-[11px] font-mono text-slate-500">{exp.period}</span>
                </div>
                <div className="text-xs text-[#64748b]">{exp.organization} &bull; {exp.department}</div>
                <div className="pt-1">
                  <Badge variant="blue">{exp.type}</Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Professional Memberships & Certifications */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
          <Award className="w-4 h-4 text-[#1e3a8a]" />
          <span>Chartered Professional Memberships & Accreditations</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {certifications.map((c, i) => (
            <div key={i} className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 space-y-2">
              <div className="font-bold text-xs text-[#1e293b]">{c.title}</div>
              <div className="text-[11px] text-[#64748b]">{c.issuer}</div>
              <div className="pt-2 border-t border-slate-200 text-[10px] text-slate-500 font-mono">
                {c.certId} &bull; {c.validity}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
