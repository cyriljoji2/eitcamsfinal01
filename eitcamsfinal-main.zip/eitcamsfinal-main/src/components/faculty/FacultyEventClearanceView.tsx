import React, { useState } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Plus,
  Clock,
  MapPin,
  Users,
  Check,
  X,
  Building,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';

interface EventPermission {
  id: string;
  eventName: string;
  organizingBody: string;
  facultyCoordinator: string;
  venue: string;
  eventDate: string;
  timings: string;
  expectedAttendees: number;
  avRequirement: boolean;
  status: 'PENDING_HOD_APPROVAL' | 'APPROVED' | 'COMPLETED';
}

export function FacultyEventClearanceView() {
  const [events, setEvents] = useState<EventPermission[]>([
    {
      id: 'EVT-CLR-2026-031',
      eventName: 'Annual ACM Student Chapter Hackathon (HackEIT 2026)',
      organizingBody: 'ACM EIT Student Chapter & Dept of CSE',
      facultyCoordinator: 'Dr. Arvind Sharma (Faculty Sponsor)',
      venue: 'Main Auditorium & Computing Lab 3',
      eventDate: '2026-11-22 to 2026-11-23',
      timings: '09:00 AM (Sat) – 05:00 PM (Sun)',
      expectedAttendees: 150,
      avRequirement: true,
      status: 'APPROVED',
    },
    {
      id: 'EVT-CLR-2026-042',
      eventName: 'Distinguished Guest Lecture on Generative AI Architectures',
      organizingBody: 'Department Research Colloquium',
      facultyCoordinator: 'Dr. Arvind Sharma',
      venue: 'Seminar Hall 301',
      eventDate: '2026-11-28',
      timings: '02:00 PM – 04:00 PM',
      expectedAttendees: 75,
      avRequirement: true,
      status: 'PENDING_HOD_APPROVAL',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [venue, setVenue] = useState('Seminar Hall 301');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [attendees, setAttendees] = useState(50);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newEvt: EventPermission = {
      id: `EVT-CLR-2026-${Math.floor(100 + Math.random() * 900)}`,
      eventName: name.trim(),
      organizingBody: 'Dept of Computer Science & Engineering',
      facultyCoordinator: 'Dr. Arvind Sharma',
      venue,
      eventDate: date,
      timings: '02:00 PM – 05:00 PM',
      expectedAttendees: Number(attendees) || 50,
      avRequirement: true,
      status: 'PENDING_HOD_APPROVAL',
    };

    setEvents([newEvt, ...events]);
    setIsModalOpen(false);
    setName('');
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-[#1e293b]">Academic Event Permissions & Venue Clearances</h2>
            <Badge variant="blue">Campus Facilities Desk</Badge>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Requisitions for seminar hall bookings, external speaker security clearance, and student club workshop permissions.
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-3.5 h-3.5" />}
          className="text-xs self-start sm:self-auto bg-[#1e3a8a] text-white hover:bg-blue-900"
        >
          Request Event Clearance
        </Button>
      </div>

      {/* Events List */}
      <div className="space-y-4">
        {events.map((evt) => (
          <div
            key={evt.id}
            className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-blue-200 transition-colors"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2 py-0.5 rounded">
                    {evt.id}
                  </span>
                  <Badge variant={evt.status === 'APPROVED' ? 'emerald' : 'amber'}>
                    {evt.status === 'APPROVED' ? 'Approved & Venue Reserved' : 'Pending HOD / Estate Approval'}
                  </Badge>
                  <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                    {evt.expectedAttendees} Expected Attendees
                  </span>
                </div>

                <h3 className="text-sm font-bold text-[#1e293b] pt-1">{evt.eventName}</h3>
                <div className="text-xs text-[#64748b]">
                  Organized by: <strong className="text-slate-800">{evt.organizingBody}</strong> &bull; Coordinator: {evt.facultyCoordinator}
                </div>
              </div>

              <div className="sm:text-right shrink-0">
                <div className="text-[10px] text-[#64748b] uppercase">Venue & Schedule</div>
                <div className="text-xs font-bold text-slate-800">{evt.venue}</div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
                  {evt.eventDate} ({evt.timings})
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-[#64748b]">
              <div className="flex items-center gap-1.5 text-emerald-700 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Audio-Visual, Projector & Stage Setup Cleared</span>
              </div>
              <span className="text-slate-500">Security gate notified for visitor parking</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xl max-w-lg w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-[#1e293b]">Request Academic Event Permission</h3>
            <p className="text-xs text-[#64748b]">
              Submit requisition for institutional venue clearance and audio-visual support.
            </p>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Event Name / Workshop Title</label>
                <Input
                  required
                  placeholder="e.g., National Seminar on Edge AI"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Target Venue</label>
                  <select
                    value={venue}
                    onChange={(e) => setVenue(e.target.value)}
                    className="w-full text-xs py-2 px-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="Seminar Hall 301">Seminar Hall 301 (Capacity 100)</option>
                    <option value="Main Auditorium">Main Auditorium (Capacity 500)</option>
                    <option value="Conference Room A">Conference Room A (Capacity 40)</option>
                    <option value="Computing Lab 3">Computing Lab 3 (Capacity 60)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Event Date</label>
                  <Input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Estimated Attendees</label>
                <Input
                  type="number"
                  value={attendees}
                  onChange={(e) => setAttendees(Number(e.target.value))}
                  className="text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <Button variant="ghost" size="sm" type="button" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit" className="bg-[#1e3a8a] text-white">
                  Submit Requisition
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
