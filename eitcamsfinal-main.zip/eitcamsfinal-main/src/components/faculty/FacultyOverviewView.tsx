import React from 'react';
import {
  BookOpen,
  CalendarCheck,
  Users,
  GraduationCap,
  Clock,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Building2,
  Calendar,
  Sparkles,
  MessageSquare,
  Megaphone,
  Eye,
  FileCheck2,
} from 'lucide-react';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import {
  CourseEnrolmentRecord,
  FacultyCourseAssignmentRecord,
  StudentRecord,
  TimetableSlotRecord,
  ExamScheduleRecord,
} from '../../types/database';

interface FacultyOverviewViewProps {
  facultyName: string;
  employeeId: string;
  registrationNumber: string;
  department: string;
  designation: string;
  assignments: FacultyCourseAssignmentRecord[];
  students: StudentRecord[];
  enrolments: CourseEnrolmentRecord[];
  timetableSlots: TimetableSlotRecord[];
  examSchedules: ExamScheduleRecord[];
  proctorCount: number;
  pendingProctorRequestsCount: number;
  announcementsCount: number;
  onNavigateTab: (tabId: string) => void;
  onOpenStudentProfile: (regNo: string) => void;
}

export function FacultyOverviewView({
  facultyName,
  employeeId,
  registrationNumber,
  department,
  designation,
  assignments,
  students,
  enrolments,
  timetableSlots,
  examSchedules,
  proctorCount,
  pendingProctorRequestsCount,
  announcementsCount,
  onNavigateTab,
  onOpenStudentProfile,
}: FacultyOverviewViewProps) {
  // Compute enrolled students in faculty's assigned courses and sections
  const assignedCourseCodes = new Set(assignments.map((a) => a.course_code));
  const myEnrolments = enrolments.filter(
    (e) =>
      assignedCourseCodes.has(e.course_code) &&
      assignments.some((a) => a.course_code === e.course_code && a.section === e.section) &&
      e.enrolment_status === 'ACTIVE'
  );

  const myStudentIds = new Set(myEnrolments.map((e) => e.student_id));
  const totalAssignedStudents = myStudentIds.size;

  // Determine current day of week
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'] as const;
  const todayName = days[new Date().getDay()];
  const todayClasses = timetableSlots.filter((s) => s.day_of_week === todayName);

  // Exam schedules status
  const openMarksSchedules = examSchedules.filter((s) => s.marks_entry_open);
  const returnedSchedules = examSchedules.filter(
    (s) => s.status === 'REJECTED_FOR_CORRECTION' || (s.notes && s.notes.includes('Rejected for correction'))
  );
  const submittedSchedules = examSchedules.filter((s) => s.status === 'FACULTY_SUBMITTED');

  return (
    <div className="space-y-6">
      {/* 1. Faculty Welcome Banner */}
      <div className="bg-white border border-[#e2e8f0] p-6 rounded-2xl shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#1e3a8a] to-[#2563eb] text-white flex items-center justify-center font-bold text-xl shadow-xs shrink-0">
              {facultyName
                .split(' ')
                .filter(Boolean)
                .map((n) => n[0])
                .slice(0, 2)
                .join('')
                .toUpperCase() || 'FC'}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-bold text-[#1e293b] tracking-tight">
                  Welcome back, {facultyName}
                </h1>
                <Badge variant="blue">{registrationNumber || employeeId}</Badge>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  Teaching Faculty Active
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#64748b] mt-1">
                {designation} &bull; Department of {department} &bull; Term: <strong>Fall 2026–2027</strong>
              </p>
            </div>
          </div>

          {/* Quick Metrics Capsule */}
          <div className="flex items-center gap-4 text-xs pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-100">
            <div className="text-left sm:text-right">
              <div className="text-[10px] text-[#64748b] uppercase font-semibold">Assigned Courses</div>
              <div className="font-bold text-[#1e293b] text-base">{assignments.length} Sections</div>
            </div>
            <div className="text-left sm:text-right border-l pl-4 border-slate-200">
              <div className="text-[10px] text-[#64748b] uppercase font-semibold">Taught Students</div>
              <div className="font-bold text-[#1e3a8a] text-base">{totalAssignedStudents} Enrolled</div>
            </div>
            {proctorCount > 0 && (
              <div className="text-left sm:text-right border-l pl-4 border-slate-200">
                <div className="text-[10px] text-emerald-700 uppercase font-semibold">Proctor Mentees</div>
                <div className="font-bold text-emerald-700 text-base">{proctorCount} Students</div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Urgent Attention Banner if marks are returned */}
      {returnedSchedules.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 shadow-xs">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <div className="font-bold text-amber-900 text-sm">
              Action Required: COE Returned Marks for Correction ({returnedSchedules.length})
            </div>
            <p className="text-amber-800 mt-0.5">
              The Controller of Examinations office returned mark entries for revision with specific correction remarks.
              Please review the feedback and resubmit.
            </p>
            <div className="mt-2.5">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateTab('marks-status')}
                className="bg-white border-amber-300 text-amber-900 hover:bg-amber-100 text-xs h-7"
              >
                Review Correction Remarks
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Operational Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Assigned Courses */}
        <div
          onClick={() => onNavigateTab('courses')}
          className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-[#1e3a8a] transition-colors" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-[#1e293b]">{assignments.length}</div>
            <div className="text-xs font-medium text-[#64748b]">Active Course Sections</div>
          </div>
          <div className="mt-2 text-[11px] text-blue-700 font-semibold flex items-center gap-1">
            <span>View curriculum & roster</span>
          </div>
        </div>

        {/* Card 2: Today's Classes */}
        <div
          onClick={() => onNavigateTab('timetable')}
          className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-700 transition-colors" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-[#1e293b]">{todayClasses.length}</div>
            <div className="text-xs font-medium text-[#64748b]">Classes Scheduled Today</div>
          </div>
          <div className="mt-2 text-[11px] text-indigo-700 font-semibold flex items-center gap-1">
            <span>{todayName} teaching timetable</span>
          </div>
        </div>

        {/* Card 3: Marks Entry Window */}
        <div
          onClick={() => onNavigateTab('mark-entry')}
          className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-purple-700 transition-colors" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-[#1e293b]">
              {openMarksSchedules.length}
            </div>
            <div className="text-xs font-medium text-[#64748b]">COE Marks Window Open</div>
          </div>
          <div className="mt-2 text-[11px] text-purple-700 font-semibold flex items-center gap-1">
            <span>{submittedSchedules.length} submitted for review</span>
          </div>
        </div>

        {/* Card 4: Proctor Desk */}
        <div
          onClick={() => onNavigateTab('proctor')}
          className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-700 transition-colors" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-[#1e293b]">{proctorCount}</div>
            <div className="text-xs font-medium text-[#64748b]">Mentee Students</div>
          </div>
          <div className="mt-2 text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
            {pendingProctorRequestsCount > 0 ? (
              <span className="text-amber-700 font-bold">
                {pendingProctorRequestsCount} pending leave approvals
              </span>
            ) : (
              <span>All requests endorsed</span>
            )}
          </div>
        </div>
      </div>

      {/* 4. Quick Action Shortcuts */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#64748b] mb-3">
          Teaching Workflow Shortcuts
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            type="button"
            onClick={() => onNavigateTab('attendance')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <CalendarCheck className="w-4 h-4 text-[#1e3a8a] group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">Take Attendance</div>
            <div className="text-[10px] text-[#64748b]">Daily class roll-call</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('mark-entry')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <GraduationCap className="w-4 h-4 text-purple-700 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">Enter Marks</div>
            <div className="text-[10px] text-[#64748b]">Internal & FAT exams</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('courses')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <Users className="w-4 h-4 text-blue-700 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">Class Rosters</div>
            <div className="text-[10px] text-[#64748b]">Enrolled students</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('timetable')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <Clock className="w-4 h-4 text-indigo-700 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">My Timetable</div>
            <div className="text-[10px] text-[#64748b]">Weekly schedule</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('announcements')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <Megaphone className="w-4 h-4 text-emerald-700 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">Post Announcement</div>
            <div className="text-[10px] text-[#64748b]">Notify enrolled classes</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('performance')}
            className="p-3 bg-white border border-[#e2e8f0] rounded-xl text-left hover:border-blue-300 hover:shadow-2xs transition-all cursor-pointer group"
          >
            <Sparkles className="w-4 h-4 text-amber-700 group-hover:scale-110 transition-transform" />
            <div className="text-xs font-bold text-[#1e293b] mt-2">Performance</div>
            <div className="text-[10px] text-[#64748b]">Analytics & at-risk</div>
          </button>
        </div>
      </div>

      {/* 5. Two-Column Layout: Today's Schedule & Assigned Courses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Assigned Courses Grid */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
              <span>Assigned Teaching Duties & Courses</span>
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('courses')}
              className="text-xs font-semibold text-[#1e3a8a] hover:underline"
            >
              View all ({assignments.length}) &rarr;
            </button>
          </div>

          {assignments.length === 0 ? (
            <div className="bg-white border border-[#e2e8f0] p-8 rounded-xl text-center text-xs text-[#94a3b8]">
              No active teaching assignments currently allocated by the Academic Office.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {assignments.map((asg) => {
                const courseEnrolments = myEnrolments.filter(
                  (e) => e.course_code === asg.course_code && e.section === asg.section
                );

                return (
                  <div
                    key={asg.faculty_assignment_id}
                    className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4 hover:border-blue-300 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <span className="font-mono font-bold text-xs text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded border border-blue-100">
                          {asg.course_code}
                        </span>
                        <Badge variant="emerald">Section {asg.section || 'A'}</Badge>
                      </div>

                      <h3 className="text-sm font-bold text-[#1e293b] mt-2 leading-snug">
                        {asg.course_title}
                      </h3>
                      <p className="text-xs text-[#64748b] mt-1">
                        Dept: {asg.department} &bull; Semester {asg.semester} &bull; Role: {asg.role_in_course}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-100">
                      <div className="flex items-center justify-between text-xs text-[#64748b] mb-3">
                        <span>Class Enrollment:</span>
                        <strong className="text-[#1e293b]">
                          {courseEnrolments.length} Active Students
                        </strong>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onNavigateTab('attendance')}
                          className="text-xs h-7.5"
                          leftIcon={<CalendarCheck className="w-3.5 h-3.5 text-[#1e3a8a]" />}
                        >
                          Attendance
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onNavigateTab('courses')}
                          className="text-xs h-7.5 text-[#1e293b] hover:bg-slate-100"
                          leftIcon={<Users className="w-3.5 h-3.5" />}
                        >
                          Roster
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 1 Col: Today's Schedule & Academic Feed */}
        <div className="space-y-6">
          {/* Today's Teaching Schedule */}
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-700" />
                <span>Today's Classes ({todayName})</span>
              </h3>
              <button
                type="button"
                onClick={() => onNavigateTab('timetable')}
                className="text-[11px] font-semibold text-[#1e3a8a] hover:underline"
              >
                Full Timetable &rarr;
              </button>
            </div>

            {todayClasses.length === 0 ? (
              <div className="py-6 text-center text-xs text-[#94a3b8] bg-[#f8fafc] rounded-lg border border-dashed border-[#e2e8f0]">
                No classes scheduled for today.
              </div>
            ) : (
              <div className="space-y-2.5">
                {todayClasses.map((slot) => (
                  <div
                    key={slot.slot_id}
                    className="p-3 bg-[#f8fafc] border border-[#e2e8f0] rounded-lg text-xs space-y-1 hover:border-indigo-300 transition-colors"
                  >
                    <div className="flex items-center justify-between font-mono font-bold text-[#1e3a8a]">
                      <span>{slot.start_time} - {slot.end_time}</span>
                      <span className="text-slate-600 font-sans font-medium text-[11px] bg-white px-2 py-0.5 rounded border border-slate-200">
                        {slot.room}
                      </span>
                    </div>
                    <div className="font-bold text-[#1e293b] text-xs">
                      {slot.course_code}: {slot.course_title}
                    </div>
                    <div className="text-[11px] text-[#64748b]">
                      Section {slot.section} &bull; Sem {slot.semester} &bull; {slot.programme_code}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Proctor Mentorship Snapshot */}
          {proctorCount > 0 && (
            <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>Proctor Mentorship Desk</span>
                </h3>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {proctorCount} Mentees
                </span>
              </div>
              <p className="text-xs text-[#64748b]">
                You are the designated mentor for {proctorCount} university students.
                {pendingProctorRequestsCount > 0 ? (
                  <span className="text-amber-700 font-semibold block mt-1">
                    &bull; {pendingProctorRequestsCount} leave/outing application(s) awaiting your endorsement.
                  </span>
                ) : (
                  <span className="text-slate-600 block mt-1">
                    &bull; All pending leave requests are reviewed.
                  </span>
                )}
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateTab('proctor')}
                className="w-full text-xs text-emerald-800 border-emerald-300 hover:bg-emerald-50 h-8"
              >
                Open Proctor Desk
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
