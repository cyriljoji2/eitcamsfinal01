import React, { useState } from 'react';
import {
  Settings,
  Bell,
  Clock,
  Shield,
  Save,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../ui/Button';

export function FacultySettingsView() {
  const [notifyLeaveRequests, setNotifyLeaveRequests] = useState(true);
  const [notifyMarksDeadlines, setNotifyMarksDeadlines] = useState(true);
  const [timetableDefaultView, setTimetableDefaultView] = useState<'weekly' | 'daily'>('weekly');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="bg-white border border-[#e2e8f0] p-5 rounded-2xl shadow-xs">
        <h1 className="text-base sm:text-lg font-bold text-[#1e293b] flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#1e3a8a]" />
          <span>Faculty Portal Preferences & Configuration</span>
        </h1>
        <p className="text-xs text-[#64748b] mt-0.5">
          Configure notification preferences, timetable views, and teaching portal options.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Faculty preferences saved successfully.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="bg-white border border-[#e2e8f0] rounded-2xl p-6 shadow-xs space-y-6">
        {/* Notification Settings */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2 border-b pb-2 border-slate-100">
            <Bell className="w-4 h-4 text-[#1e3a8a]" />
            <span>Notification & Alert Preferences</span>
          </h3>

          <div className="space-y-2 text-xs">
            <label className="flex items-center justify-between p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] cursor-pointer">
              <div>
                <span className="font-semibold text-slate-900 block">Proctor Mentee Leave Requests</span>
                <span className="text-slate-500 text-[11px]">Receive in-portal notifications when wards submit residential leave requests.</span>
              </div>
              <input
                type="checkbox"
                checked={notifyLeaveRequests}
                onChange={(e) => setNotifyLeaveRequests(e.target.checked)}
                className="w-4 h-4 rounded text-[#1e3a8a]"
              />
            </label>

            <label className="flex items-center justify-between p-3 bg-[#f8fafc] rounded-xl border border-[#e2e8f0] cursor-pointer">
              <div>
                <span className="font-semibold text-slate-900 block">COE Marks Window Deadlines</span>
                <span className="text-slate-500 text-[11px]">Receive reminders 48 hours prior to marks entry closure.</span>
              </div>
              <input
                type="checkbox"
                checked={notifyMarksDeadlines}
                onChange={(e) => setNotifyMarksDeadlines(e.target.checked)}
                className="w-4 h-4 rounded text-[#1e3a8a]"
              />
            </label>
          </div>
        </div>

        {/* Timetable Preferences */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-[#1e293b] flex items-center gap-2 border-b pb-2 border-slate-100">
            <Clock className="w-4 h-4 text-indigo-700" />
            <span>Teaching Timetable Display</span>
          </h3>

          <div className="text-xs">
            <label className="block text-[#64748b] font-semibold mb-1">Default View Format</label>
            <select
              value={timetableDefaultView}
              onChange={(e) => setTimetableDefaultView(e.target.value as any)}
              className="w-full sm:w-64 h-9 rounded-lg border border-[#cbd5e1] bg-white px-2.5 text-xs text-slate-800 outline-hidden"
            >
              <option value="weekly">Weekly Grid Matrix</option>
              <option value="daily">Daily Schedule List</option>
            </select>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button type="submit" size="sm" className="text-xs" leftIcon={<Save className="w-3.5 h-3.5" />}>
            Save Preferences
          </Button>
        </div>
      </form>
    </div>
  );
}
