import { useMemo } from 'react';
import {
  Users,
  UserCheck,
  UserX,
  Building,
  UserPlus,
  UploadCloud,
  ArrowRight,
  Shield,
  ExternalLink,
} from 'lucide-react';
import { Employee } from '../../types/employee';
import { EMPLOYEE_ROLES } from '../../services/employeeService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface AdminOverviewProps {
  employees: Employee[];
  onNavigateToTab: (tab: 'employees' | 'import' | 'settings') => void;
  onOpenAddModal: () => void;
  onSelectEmployee: (employee: Employee) => void;
}

export function AdminOverview({
  employees,
  onNavigateToTab,
  onOpenAddModal,
  onSelectEmployee,
}: AdminOverviewProps) {
  // Statistics calculations
  const stats = useMemo(() => {
    const total = employees.length;
    const active = employees.filter((e) => e.status === 'active').length;
    const inactive = employees.filter((e) => e.status === 'inactive').length;

    const deptMap = new Map<string, number>();
    const roleMap = new Map<string, number>();

    employees.forEach((e) => {
      deptMap.set(e.department, (deptMap.get(e.department) || 0) + 1);
      roleMap.set(e.role, (roleMap.get(e.role) || 0) + 1);
    });

    const recentEmployees = [...employees]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);

    return {
      total,
      active,
      inactive,
      totalDepartments: deptMap.size,
      deptBreakdown: Array.from(deptMap.entries()).map(([name, count]) => ({ name, count })),
      roleBreakdown: Array.from(roleMap.entries()).map(([role, count]) => ({ role, count })),
      recentEmployees,
    };
  }, [employees]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#e2e8f0]">
        <div>
          <h2 className="text-[20px] sm:text-[22px] font-bold text-[#1e293b] tracking-tight">
            Institutional Administration Overview
          </h2>
          <p className="text-[13px] text-[#64748b] mt-0.5">
            Central dashboard for university staff rosters, role provisioning, credential management, and institutional settings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('import')}
            leftIcon={<UploadCloud className="w-4 h-4 text-[#1e3a8a]" />}
          >
            Import CSV
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={onOpenAddModal}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Add Employee
          </Button>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Employees */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#64748b] uppercase tracking-wider">
              Total Employees
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#1e293b]">{stats.total}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Registered in university roster</span>
        </div>

        {/* Active Staff */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#166534] uppercase tracking-wider">
              Active Accounts
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#dcfce7] text-[#166534] flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#166534]">{stats.active}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">
            {stats.total > 0 ? Math.round((stats.active / stats.total) * 100) : 0}% active access
          </span>
        </div>

        {/* Inactive Staff */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#64748b] uppercase tracking-wider">
              Inactive / Suspended
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#f1f5f9] text-[#64748b] flex items-center justify-center">
              <UserX className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#64748b]">{stats.inactive}</div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Access revoked</span>
        </div>

        {/* Departments */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-[#1e3a8a] uppercase tracking-wider">
              Departments
            </span>
            <div className="w-8 h-8 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#1e3a8a]">
            {stats.totalDepartments}
          </div>
          <span className="text-[11px] text-[#64748b] mt-1 block">Offices & divisions</span>
        </div>
      </div>

      {/* Role & Department Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Employees by System Role */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#f1f5f9]">
              <h3 className="text-[15px] font-bold text-[#1e293b] flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#1e3a8a]" />
                Employees by System Role
              </h3>
              <button
                type="button"
                onClick={() => onNavigateToTab('employees')}
                className="text-xs font-semibold text-[#1e3a8a] hover:underline cursor-pointer flex items-center gap-1"
              >
                View Roster <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-3">
              {Object.values(EMPLOYEE_ROLES).map((roleDef) => {
                const count =
                  stats.roleBreakdown.find((r) => r.role === roleDef.id)?.count || 0;
                const percentage = stats.total > 0 ? (count / stats.total) * 100 : 0;

                return (
                  <div key={roleDef.id} className="space-y-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-[#1e293b]">{roleDef.title}</span>
                      <span className="font-mono text-[#64748b]">
                        {count} staff ({Math.round(percentage)}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#f1f5f9] h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-[#1e3a8a] h-full rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Departments Headcount Breakdown */}
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#f1f5f9]">
              <h3 className="text-[15px] font-bold text-[#1e293b] flex items-center gap-2">
                <Building className="w-4 h-4 text-[#1e3a8a]" />
                Department Headcounts
              </h3>
              <span className="text-xs text-[#64748b]">{stats.totalDepartments} Active Offices</span>
            </div>

            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {stats.deptBreakdown.map((dept) => (
                <div
                  key={dept.name}
                  className="flex items-center justify-between p-2.5 rounded-lg border border-[#e2e8f0] bg-[#f8fafc] text-xs"
                >
                  <span className="font-medium text-[#1e293b] truncate pr-2">{dept.name}</span>
                  <Badge variant="blue" size="sm">
                    {dept.count} staff
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Employee Additions Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="p-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div>
            <h3 className="text-[15px] font-bold text-[#1e293b]">Recent Employee Additions</h3>
            <p className="text-xs text-[#64748b]">Latest staff records provisioned into the portal.</p>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigateToTab('employees')}
            rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
          >
            All Employees
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-[13px]">
            <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#475569] font-semibold">
              <tr>
                <th className="py-3 px-4">Employee ID</th>
                <th className="py-3 px-4">Full Name</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {stats.recentEmployees.map((emp) => (
                <tr
                  key={emp.id}
                  className="hover:bg-[#f8fafc] transition-colors cursor-pointer"
                  onClick={() => onSelectEmployee(emp)}
                >
                  <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">{emp.id}</td>
                  <td className="py-3 px-4 font-semibold text-[#1e293b]">{emp.fullName}</td>
                  <td className="py-3 px-4">
                    <Badge variant="blue" size="sm">
                      {emp.role}
                    </Badge>
                  </td>
                  <td className="py-3 px-4 text-[#64748b]">{emp.department}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${
                        emp.status === 'active'
                          ? 'bg-[#dcfce7] text-[#166534] border-[#bbf7d0]'
                          : 'bg-[#f1f5f9] text-[#64748b] border-[#e2e8f0]'
                      }`}
                    >
                      {emp.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectEmployee(emp);
                      }}
                      className="text-xs font-semibold text-[#1e3a8a] hover:underline inline-flex items-center gap-1 cursor-pointer"
                    >
                      View Details <ExternalLink className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
