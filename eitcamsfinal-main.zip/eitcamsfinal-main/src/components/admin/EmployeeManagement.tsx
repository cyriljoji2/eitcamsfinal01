import { useState, useMemo } from 'react';
import {
  Search,
  UserPlus,
  UploadCloud,
  Edit2,
  Eye,
  Power,
  KeyRound,
  Building,
  Calendar,
} from 'lucide-react';
import { Employee, EmployeeFormData } from '../../types/employee';
import { EmployeeRole } from '../../types/auth';
import { EMPLOYEE_ROLES } from '../../services/employeeService';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { EmployeeDetailModal } from './EmployeeDetailModal';
import { EmployeeFormModal } from './EmployeeFormModal';
import { CredentialsModal } from './CredentialsModal';

export interface EmployeeManagementProps {
  employees: Employee[];
  onRefresh: () => Promise<void>;
  onCreateEmployee: (data: EmployeeFormData) => Promise<{ employee: Employee; temporaryPassword: string }>;
  onUpdateEmployee: (id: string, updates: Partial<EmployeeFormData>) => Promise<Employee>;
  onToggleStatus: (id: string) => Promise<Employee>;
  onResetPassword: (id: string) => Promise<{ employee: Employee; temporaryPassword: string }>;
  onNavigateToImport: () => void;
}

export function EmployeeManagement({
  employees,
  onCreateEmployee,
  onUpdateEmployee,
  onToggleStatus,
  onResetPassword,
  onNavigateToImport,
}: EmployeeManagementProps) {
  // Filtering & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals state
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  const [credentialsModalOpen, setCredentialsModalOpen] = useState(false);
  const [generatedCredentials, setGeneratedCredentials] = useState<
    Array<{ employee: Employee; temporaryPassword: string }>
  >([]);

  // Unique departments for filter dropdown
  const uniqueDepartments = useMemo(() => {
    const set = new Set<string>();
    employees.forEach((e) => {
      if (e.department) set.add(e.department);
    });
    return Array.from(set).sort();
  }, [employees]);

  // Filtered and searched employee list
  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = emp.fullName.toLowerCase().includes(q);
        const matchesId = emp.id.toLowerCase().includes(q);
        const matchesEmail = emp.email.toLowerCase().includes(q);
        const matchesDept = emp.department.toLowerCase().includes(q);
        const matchesDesig = emp.designation.toLowerCase().includes(q);
        const matchesUsername = emp.username.toLowerCase().includes(q);

        if (!matchesName && !matchesId && !matchesEmail && !matchesDept && !matchesDesig && !matchesUsername) {
          return false;
        }
      }

      // Role filter
      if (roleFilter !== 'all' && emp.role !== roleFilter) {
        return false;
      }

      // Department filter
      if (departmentFilter !== 'all' && emp.department !== departmentFilter) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'all' && emp.status !== statusFilter) {
        return false;
      }

      return true;
    });
  }, [employees, searchQuery, roleFilter, departmentFilter, statusFilter]);

  // Actions Handlers
  const handleOpenAdd = () => {
    setEditingEmployee(null);
    setFormModalOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    setFormModalOpen(true);
  };

  const handleOpenDetail = (emp: Employee) => {
    setSelectedEmployee(emp);
    setIsDetailOpen(true);
  };

  const handleFormSubmit = async (
    formData: EmployeeFormData,
    isEditing: boolean,
    employeeId?: string
  ) => {
    if (isEditing && employeeId) {
      const updated = await onUpdateEmployee(employeeId, formData);
      if (selectedEmployee?.id === employeeId) {
        setSelectedEmployee(updated);
      }
    } else {
      const { employee, temporaryPassword } = await onCreateEmployee(formData);
      setGeneratedCredentials([{ employee, temporaryPassword }]);
      setCredentialsModalOpen(true);
    }
  };

  const handleToggleStatusAction = async (emp: Employee) => {
    const updated = await onToggleStatus(emp.id);
    if (selectedEmployee?.id === emp.id) {
      setSelectedEmployee(updated);
    }
  };

  const handleResetPasswordAction = async (emp: Employee) => {
    const { employee, temporaryPassword } = await onResetPassword(emp.id);
    setGeneratedCredentials([{ employee, temporaryPassword }]);
    setCredentialsModalOpen(true);
  };

  const getRoleBadgeVariant = (role: EmployeeRole | string) => {
    switch (role) {
      case 'super_admin':
        return 'purple';
      case 'academic':
        return 'blue';
      case 'admission':
        return 'amber';
      case 'finance':
        return 'emerald';
      case 'examination':
        return 'rose';
      case 'faculty':
      default:
        return 'neutral';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#e2e8f0]">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-[20px] sm:text-[22px] font-bold text-[#1e293b] tracking-tight">
              Employee Management
            </h2>
            <span className="bg-[#eff6ff] text-[#1e3a8a] border border-[#dbeafe] text-xs font-semibold px-2.5 py-0.5 rounded-full">
              {employees.length} Total Staff
            </span>
          </div>
          <p className="text-[13px] text-[#64748b] mt-0.5">
            Manage university staff roster, assign system access roles, create credentials, and configure account statuses.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            id="admin-import-csv-btn"
            variant="outline"
            size="md"
            onClick={onNavigateToImport}
            leftIcon={<UploadCloud className="w-4 h-4 text-[#1e3a8a]" />}
          >
            Import CSV
          </Button>

          <Button
            id="admin-add-employee-btn"
            variant="primary"
            size="md"
            onClick={handleOpenAdd}
            leftIcon={<UserPlus className="w-4 h-4" />}
          >
            Add Employee
          </Button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Input
              id="employee-search-input"
              placeholder="Search by Name, ID, or Email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              startIcon={<Search className="w-4 h-4" />}
            />
          </div>

          {/* Role Filter */}
          <div>
            <select
              id="employee-role-filter"
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full h-10 rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-xs font-medium px-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            >
              <option value="all">All System Roles</option>
              {Object.values(EMPLOYEE_ROLES).map((r) => (
                <option key={r.id} value={r.id}>
                  {r.title}
                </option>
              ))}
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <select
              id="employee-dept-filter"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="w-full h-10 rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-xs font-medium px-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            >
              <option value="all">All Departments ({uniqueDepartments.length})</option>
              {uniqueDepartments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              id="employee-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full h-10 rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-xs font-semibold px-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive Only</option>
            </select>
          </div>
        </div>

        {/* Active Filters Summary */}
        {(searchQuery || roleFilter !== 'all' || departmentFilter !== 'all' || statusFilter !== 'all') && (
          <div className="flex items-center justify-between pt-2 border-t border-[#f1f5f9] text-xs text-[#64748b]">
            <span>
              Showing <strong>{filteredEmployees.length}</strong> of {employees.length} employees
            </span>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setRoleFilter('all');
                setDepartmentFilter('all');
                setStatusFilter('all');
              }}
              className="text-[#1e3a8a] font-medium hover:underline cursor-pointer"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>

      {/* Employees Data Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-[13px]">
            <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#475569] font-semibold">
              <tr>
                <th className="py-3 px-4">Employee ID</th>
                <th className="py-3 px-4">Full Name & Email</th>
                <th className="py-3 px-4">Department & Designation</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Joining Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#64748b]">
                    <div className="max-w-xs mx-auto space-y-2">
                      <p className="font-semibold text-[#1e293b]">No employees found</p>
                      <p className="text-xs">
                        Try adjusting your search query or filters, or add a new employee.
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredEmployees.map((emp) => {
                  const isActive = emp.status === 'active';
                  const roleConfig = EMPLOYEE_ROLES[emp.role];

                  return (
                    <tr
                      key={emp.id}
                      className="hover:bg-[#f8fafc] transition-colors group cursor-pointer"
                      onClick={() => handleOpenDetail(emp)}
                    >
                      {/* ID */}
                      <td className="py-3.5 px-4 font-mono font-bold text-[#1e3a8a]">
                        {emp.id}
                      </td>

                      {/* Name & Email */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-[#1e293b]">{emp.fullName}</div>
                        <div className="text-[11px] text-[#64748b]">{emp.email}</div>
                      </td>

                      {/* Department & Designation */}
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-[#1e293b]">{emp.designation}</div>
                        <div className="text-[11px] text-[#64748b] flex items-center gap-1">
                          <Building className="w-3 h-3 text-[#94a3b8]" />
                          {emp.department}
                        </div>
                      </td>

                      {/* System Role */}
                      <td className="py-3.5 px-4">
                        <Badge variant={getRoleBadgeVariant(emp.role)} size="sm">
                          {roleConfig?.title || emp.role}
                        </Badge>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${
                            isActive
                              ? 'bg-[#dcfce7] text-[#166534] border-[#bbf7d0]'
                              : 'bg-[#f1f5f9] text-[#64748b] border-[#e2e8f0]'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              isActive ? 'bg-[#166534]' : 'bg-[#94a3b8]'
                            }`}
                          ></span>
                          {isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>

                      {/* Joining Date */}
                      <td className="py-3.5 px-4 text-[#64748b] text-xs">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#94a3b8]" />
                          {emp.joiningDate}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div
                          className="inline-flex items-center gap-1"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            title="View Details"
                            onClick={() => handleOpenDetail(emp)}
                            className="p-1.5 rounded text-[#64748b] hover:text-[#1e3a8a] hover:bg-[#eff6ff] transition-colors cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Edit Employee"
                            onClick={() => handleOpenEdit(emp)}
                            className="p-1.5 rounded text-[#64748b] hover:text-[#1e3a8a] hover:bg-[#eff6ff] transition-colors cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title={isActive ? 'Deactivate Employee' : 'Activate Employee'}
                            onClick={() => handleToggleStatusAction(emp)}
                            className={`p-1.5 rounded transition-colors cursor-pointer ${
                              isActive
                                ? 'text-[#64748b] hover:text-rose-600 hover:bg-rose-50'
                                : 'text-[#64748b] hover:text-emerald-600 hover:bg-emerald-50'
                            }`}
                          >
                            <Power className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            title="Reset Temporary Password"
                            onClick={() => handleResetPasswordAction(emp)}
                            className="p-1.5 rounded text-[#64748b] hover:text-amber-700 hover:bg-amber-50 transition-colors cursor-pointer"
                          >
                            <KeyRound className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      <EmployeeDetailModal
        isOpen={isDetailOpen}
        employee={selectedEmployee}
        onClose={() => setIsDetailOpen(false)}
        onEdit={(emp) => {
          setIsDetailOpen(false);
          handleOpenEdit(emp);
        }}
        onToggleStatus={handleToggleStatusAction}
        onResetPassword={handleResetPasswordAction}
      />

      <EmployeeFormModal
        isOpen={formModalOpen}
        onClose={() => setFormModalOpen(false)}
        onSubmit={handleFormSubmit}
        initialEmployee={editingEmployee}
      />

      <CredentialsModal
        isOpen={credentialsModalOpen}
        onClose={() => setCredentialsModalOpen(false)}
        items={generatedCredentials}
      />
    </div>
  );
}
