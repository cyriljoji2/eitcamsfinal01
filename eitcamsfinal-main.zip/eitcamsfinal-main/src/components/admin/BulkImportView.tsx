import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  KeyRound,
  Printer,
  Copy,
  Check,
  ArrowRight,
  Trash2,
} from 'lucide-react';
import {
  generateCsvTemplate,
  parseCsvText,
  validateCsvEmployeeRows,
  employeeRepository,
} from '../../services/employeeService';
import { Employee, CsvValidationResult } from '../../types/employee';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface BulkImportViewProps {
  onImportCompleted?: () => void;
  onNavigateToEmployees?: () => void;
}

export function BulkImportView({ onImportCompleted, onNavigateToEmployees }: BulkImportViewProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [fileName, setFileName] = useState<string | null>(null);
  const [, setCsvContent] = useState<string>('');
  const [validationResult, setValidationResult] = useState<CsvValidationResult | null>(null);
  const [, setIsValidating] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'errors' | 'valid'>('all');

  // Completed results state
  const [importSummary, setImportSummary] = useState<{
    totalRows: number;
    successfullyImported: number;
    failedRows: number;
    createdEmployees: Employee[];
    temporaryPasswords: Record<string, string>;
  } | null>(null);

  const [allCopied, setAllCopied] = useState(false);

  // 1. Download CSV template
  const handleDownloadTemplate = () => {
    const csvData = generateCsvTemplate();
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'eit_employee_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // 2. File Selection & Drag-and-Drop
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.name.endsWith('.csv') && file.type !== 'text/csv') {
      alert('Please upload a valid CSV file (.csv format).');
      return;
    }

    setFileName(file.name);
    setImportSummary(null);
    setIsValidating(true);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      setCsvContent(text);
      await runValidation(text);
      setIsValidating(false);
    };
    reader.onerror = () => {
      alert('Error reading the uploaded file.');
      setIsValidating(false);
    };
    reader.readAsText(file);
  };

  const runValidation = async (text: string) => {
    const rawRows = parseCsvText(text);
    const existingEmployees = await employeeRepository.getAll();
    const result = validateCsvEmployeeRows(rawRows, existingEmployees);
    setValidationResult(result);
  };

  const handleClearFile = () => {
    setFileName(null);
    setCsvContent('');
    setValidationResult(null);
    setImportSummary(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // 3. Confirm Import
  const handleCommitImport = async () => {
    if (!validationResult) return;

    const validItems = validationResult.items.filter((i) => i.isValid && i.parsedData);
    if (validItems.length === 0) {
      alert('No valid rows found to import.');
      return;
    }

    setIsImporting(true);
    try {
      const validPayloads = validItems.map((i) => i.parsedData!);
      const { employees, temporaryPasswords } = await employeeRepository.bulkCreate(validPayloads);

      setImportSummary({
        totalRows: validationResult.totalRows,
        successfullyImported: employees.length,
        failedRows: validationResult.invalidCount,
        createdEmployees: employees,
        temporaryPasswords,
      });

      if (onImportCompleted) {
        onImportCompleted();
      }
    } catch (err: any) {
      alert(err.message || 'Error occurred during bulk employee import.');
    } finally {
      setIsImporting(false);
    }
  };

  // Copy all imported credentials
  const handleCopyAllImported = () => {
    if (!importSummary) return;

    const text = importSummary.createdEmployees
      .map(
        (emp) =>
          `Employee ID: ${emp.id} | Username: ${emp.username} | Temp Password: ${importSummary.temporaryPasswords[emp.id]} | Name: ${emp.fullName} | Role: ${emp.role} | Department: ${emp.department}`
      )
      .join('\n');

    navigator.clipboard.writeText(text);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 2000);
  };

  // Print imported credentials
  const handlePrintImported = () => {
    if (!importSummary) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Electrix Institute of Technology (EIT) - Bulk Employee Credentials</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 24px; color: #1e293b; }
            h1 { font-size: 20px; color: #1e3a8a; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin-bottom: 12px; }
            .meta { font-size: 13px; color: #64748b; margin-bottom: 20px; }
            table { width: 100%; border-collapse: collapse; margin-top: 12px; }
            th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 8px 10px; font-size: 12px; text-align: left; }
            td { border: 1px solid #cbd5e1; padding: 8px 10px; font-size: 12px; }
            .pwd { font-family: monospace; font-weight: bold; background: #fef3c7; color: #78350f; padding: 2px 6px; border-radius: 4px; }
            .id { font-family: monospace; font-weight: bold; color: #1e3a8a; }
          </style>
        </head>
        <body>
          <h1>ELECTRIX INSTITUTE OF TECHNOLOGY (EIT) — Bulk Generated Employee Credentials</h1>
          <div class="meta">
            Total Accounts Created: <strong>${importSummary.successfullyImported}</strong> &bull; Generated on: ${new Date().toLocaleString()}
          </div>
          <table>
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Username</th>
                <th>Temporary Password</th>
                <th>Full Name</th>
                <th>Role</th>
                <th>Department</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              ${importSummary.createdEmployees
                .map(
                  (emp) => `
                <tr>
                  <td class="id">${emp.id}</td>
                  <td>${emp.username}</td>
                  <td><span class="pwd">${importSummary.temporaryPasswords[emp.id] || 'N/A'}</span></td>
                  <td><strong>${emp.fullName}</strong></td>
                  <td>${emp.role}</td>
                  <td>${emp.department}</td>
                  <td>${emp.email}</td>
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  // Filtered rows for the preview table
  const displayedItems = validationResult
    ? validationResult.items.filter((item) => {
        if (filterMode === 'errors') return !item.isValid;
        if (filterMode === 'valid') return item.isValid;
        return true;
      })
    : [];

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#e2e8f0]">
        <div>
          <h2 className="text-[20px] sm:text-[22px] font-bold text-[#1e293b] tracking-tight">
            Bulk Employee Import
          </h2>
          <p className="text-[13px] text-[#64748b] mt-0.5">
            Upload a CSV roster to batch-validate, create accounts, and generate employee IDs & temporary credentials.
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleDownloadTemplate}
          leftIcon={<Download className="w-4 h-4 text-[#1e3a8a]" />}
        >
          Download CSV Template
        </Button>
      </div>

      {/* Result Section (After Import is Finished) */}
      {importSummary && (
        <div className="bg-white border border-[#bbf7d0] rounded-xl p-6 shadow-xs space-y-5 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#e2e8f0]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#dcfce7] text-[#166534] flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-[17px] font-bold text-[#1e293b]">
                  Bulk Import Completed Successfully
                </h3>
                <p className="text-xs text-[#64748b]">
                  {importSummary.successfullyImported} employee accounts provisioned with auto-generated IDs and credentials.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopyAllImported}
                leftIcon={allCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              >
                {allCopied ? 'Copied to Clipboard' : 'Copy All Credentials'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrintImported}
                leftIcon={<Printer className="w-3.5 h-3.5" />}
              >
                Print / Export Slips
              </Button>
              {onNavigateToEmployees && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={onNavigateToEmployees}
                  rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                >
                  View All Employees
                </Button>
              )}
            </div>
          </div>

          {/* Import Metric Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0]">
              <span className="text-[#64748b] block font-medium">Total Rows Processed</span>
              <span className="text-lg font-bold text-[#1e293b]">{importSummary.totalRows}</span>
            </div>
            <div className="bg-[#f0fdf4] p-3 rounded-lg border border-[#bbf7d0]">
              <span className="text-[#166534] block font-medium">Accounts Created</span>
              <span className="text-lg font-bold text-[#166534]">{importSummary.successfullyImported}</span>
            </div>
            <div className="bg-[#fef2f2] p-3 rounded-lg border border-[#fecaca]">
              <span className="text-[#991b1b] block font-medium">Failed / Skipped</span>
              <span className="text-lg font-bold text-[#991b1b]">{importSummary.failedRows}</span>
            </div>
            <div className="bg-[#eff6ff] p-3 rounded-lg border border-[#dbeafe]">
              <span className="text-[#1e3a8a] block font-medium">Credentials Active</span>
              <span className="text-lg font-bold text-[#1e3a8a]">Temporary</span>
            </div>
          </div>

          {/* Generated Table View */}
          <div>
            <h4 className="text-xs font-bold text-[#475569] uppercase tracking-wider mb-2.5 flex items-center gap-2">
              <KeyRound className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Generated Employee Credentials:
            </h4>
            <div className="border border-[#e2e8f0] rounded-lg overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#475569] font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">Employee ID</th>
                    <th className="py-2.5 px-3">Username</th>
                    <th className="py-2.5 px-3">Temporary Password</th>
                    <th className="py-2.5 px-3">Full Name</th>
                    <th className="py-2.5 px-3">Role</th>
                    <th className="py-2.5 px-3">Department</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f1f5f9]">
                  {importSummary.createdEmployees.map((emp) => (
                    <tr key={emp.id} className="hover:bg-[#f8fafc]">
                      <td className="py-2.5 px-3 font-mono font-bold text-[#1e3a8a]">{emp.id}</td>
                      <td className="py-2.5 px-3 font-mono text-[#1e293b]">{emp.username}</td>
                      <td className="py-2.5 px-3">
                        <span className="font-mono font-bold bg-amber-50 text-amber-900 px-2 py-0.5 rounded border border-amber-200">
                          {importSummary.temporaryPasswords[emp.id]}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-[#1e293b]">{emp.fullName}</td>
                      <td className="py-2.5 px-3">
                        <Badge variant="blue" size="sm">
                          {emp.role}
                        </Badge>
                      </td>
                      <td className="py-2.5 px-3 text-[#64748b]">{emp.department}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CSV Upload Dropzone */}
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        className="bg-white border-2 border-dashed border-[#cbd5e1] hover:border-[#1e3a8a] rounded-xl p-8 text-center transition-colors cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,text/csv"
          onChange={handleFileChange}
          className="hidden"
        />

        <div className="w-12 h-12 rounded-full bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center mx-auto mb-3">
          <UploadCloud className="w-6 h-6" />
        </div>

        <h3 className="text-[15px] font-semibold text-[#1e293b] mb-1">
          {fileName ? fileName : 'Choose CSV File or Drag & Drop Here'}
        </h3>
        <p className="text-xs text-[#64748b] max-w-md mx-auto mb-4">
          Columns required: <code>FullName, DateOfBirth, Gender, Mobile, Email, Address, Department, Designation, Role, JoiningDate</code>
        </p>

        <div className="flex items-center justify-center gap-3">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              fileInputRef.current?.click();
            }}
            leftIcon={<FileSpreadsheet className="w-4 h-4 text-[#1e3a8a]" />}
          >
            {fileName ? 'Choose Different File' : 'Browse CSV Files'}
          </Button>

          {fileName && (
            <Button
              type="button"
              variant="danger"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleClearFile();
              }}
              leftIcon={<Trash2 className="w-3.5 h-3.5" />}
            >
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Validation & Preview Section */}
      {validationResult && (
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-5">
          {/* Validation Metrics Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#e2e8f0]">
            <div>
              <h3 className="text-[16px] font-bold text-[#1e293b]">
                Validation & Pre-Import Inspection
              </h3>
              <p className="text-xs text-[#64748b] mt-0.5">
                Review verified fields, duplicate alerts, and syntax warnings before committing to database.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="primary"
                size="md"
                onClick={handleCommitImport}
                isLoading={isImporting}
                disabled={validationResult.validCount === 0}
                leftIcon={<CheckCircle2 className="w-4 h-4" />}
              >
                Confirm & Import {validationResult.validCount} Valid Records
              </Button>
            </div>
          </div>

          {/* Validation Status Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <button
              type="button"
              onClick={() => setFilterMode('all')}
              className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                filterMode === 'all'
                  ? 'border-[#1e3a8a] bg-[#eff6ff]/60'
                  : 'border-[#e2e8f0] bg-[#f8fafc] hover:border-[#cbd5e1]'
              }`}
            >
              <span className="text-[#64748b] block font-medium">Total Rows in File</span>
              <span className="text-lg font-bold text-[#1e293b]">{validationResult.totalRows}</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('valid')}
              className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                filterMode === 'valid'
                  ? 'border-emerald-600 bg-emerald-50'
                  : 'border-[#bbf7d0] bg-[#f0fdf4] hover:border-emerald-400'
              }`}
            >
              <span className="text-emerald-800 block font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Ready to Import
              </span>
              <span className="text-lg font-bold text-emerald-700">{validationResult.validCount}</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterMode('errors')}
              className={`p-3 rounded-lg border text-left transition-colors cursor-pointer ${
                filterMode === 'errors'
                  ? 'border-rose-600 bg-rose-50'
                  : 'border-[#fecaca] bg-[#fef2f2] hover:border-rose-400'
              }`}
            >
              <span className="text-rose-800 block font-medium flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                Invalid / Errors
              </span>
              <span className="text-lg font-bold text-rose-700">{validationResult.invalidCount}</span>
            </button>

            <div className="p-3 rounded-lg border border-[#fef08a] bg-[#fefce8] text-left">
              <span className="text-amber-800 block font-medium flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Duplicates Flagged
              </span>
              <span className="text-lg font-bold text-amber-800">{validationResult.duplicateCount}</span>
            </div>
          </div>

          {/* Detailed Row-Level Inspection Table */}
          <div className="border border-[#e2e8f0] rounded-lg overflow-x-auto max-h-96">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#475569] font-semibold sticky top-0">
                <tr>
                  <th className="py-2.5 px-3 w-14">Row #</th>
                  <th className="py-2.5 px-3 w-28">Status</th>
                  <th className="py-2.5 px-3">Full Name</th>
                  <th className="py-2.5 px-3">Email & Phone</th>
                  <th className="py-2.5 px-3">Role & Dept</th>
                  <th className="py-2.5 px-3">Validation Issues / Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {displayedItems.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#64748b]">
                      No rows match the selected filter ({filterMode}).
                    </td>
                  </tr>
                ) : (
                  displayedItems.map((item) => (
                    <tr
                      key={item.rowNumber}
                      className={item.isValid ? 'hover:bg-[#f8fafc]' : 'bg-rose-50/30 hover:bg-rose-50/50'}
                    >
                      <td className="py-2.5 px-3 font-mono text-[#64748b] font-medium">
                        #{item.rowNumber}
                      </td>
                      <td className="py-2.5 px-3">
                        {item.isValid ? (
                          <Badge variant="emerald" size="sm">
                            Valid
                          </Badge>
                        ) : item.isDuplicate ? (
                          <Badge variant="amber" size="sm">
                            Duplicate
                          </Badge>
                        ) : (
                          <Badge variant="rose" size="sm">
                            Error
                          </Badge>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-[#1e293b]">
                        {item.parsedData?.fullName || item.raw['FullName'] || item.raw['Name'] || '-'}
                      </td>
                      <td className="py-2.5 px-3 text-[#475569]">
                        <div>{item.parsedData?.email || item.raw['Email'] || '-'}</div>
                        <div className="text-[11px] text-[#64748b]">{item.parsedData?.mobile || item.raw['Mobile'] || '-'}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-medium text-[#1e293b]">{item.parsedData?.role || item.raw['Role'] || '-'}</div>
                        <div className="text-[11px] text-[#64748b]">{item.parsedData?.department || item.raw['Department'] || '-'}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        {item.isValid ? (
                          <span className="text-emerald-700 font-medium flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                            Ready for auto-ID generation
                          </span>
                        ) : (
                          <div className="space-y-1">
                            {item.errors.map((err, idx) => (
                              <span
                                key={idx}
                                className="inline-block bg-rose-100/80 text-rose-800 text-[11px] font-medium px-2 py-0.5 rounded mr-1 mb-0.5 border border-rose-200"
                              >
                                {err}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
