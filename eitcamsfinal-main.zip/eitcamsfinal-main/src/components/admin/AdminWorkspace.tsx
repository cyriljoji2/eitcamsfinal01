import { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  UploadCloud,
  Settings,
  LogOut,
  GraduationCap,
  Menu,
  X,
  Shield,
  Calendar,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Employee, EmployeeFormData, SystemSettings } from '../../types/employee';
import { employeeRepository, settingsRepository } from '../../services/employeeService';
import { useActiveAcademicYear } from '../../services/academicCalendarService';
import { AdminOverview } from './AdminOverview';
import { EmployeeManagement } from './EmployeeManagement';
import { BulkImportView } from './BulkImportView';
import { SystemSettingsView } from './SystemSettingsView';
import { EmployeeDetailModal } from './EmployeeDetailModal';
import { EmployeeFormModal } from './EmployeeFormModal';
import { CredentialsModal } from './CredentialsModal';

export type AdminTab = 'overview' | 'employees' | 'import' | 'settings';

export function AdminWorkspace() {
  const { user, session, logout, activeOfficeKey, switchActiveOffice } = useAuth();
  const { formattedYear } = useActiveAcademicYear();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Quick modals from overview
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  const [credentialsModalOpen, setCredentialsModalOpen] = useState(false);
  const [generatedCredentials, setGeneratedCredentials] = useState<
    Array<{ employee: Employee; temporaryPassword: string }>
  >([]);

  useEffect(() => {
    loadData();
    const unsubscribe = employeeRepository.subscribe((updatedEmployees) => {
      setEmployees(updatedEmployees);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [empList, sysSettings] = await Promise.all([
        employeeRepository.getAll(),
        settingsRepository.getSettings(),
      ]);
      setEmployees(empList);
      setSettings(sysSettings);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateEmployee = async (data: EmployeeFormData) => {
    const result = await employeeRepository.create(data);
    await loadData();
    return result;
  };

  const handleUpdateEmployee = async (id: string, updates: Partial<EmployeeFormData>) => {
    const updated = await employeeRepository.update(id, updates);
    await loadData();
    return updated;
  };

  const handleToggleStatus = async (id: string) => {
    const updated = await employeeRepository.toggleStatus(id);
    await loadData();
    return updated;
  };

  const handleResetPassword = async (id: string) => {
    const result = await employeeRepository.resetPassword(id);
    await loadData();
    return result;
  };

  const handleOverviewSelectEmployee = (emp: Employee) => {
    setSelectedEmployee(emp);
    setIsDetailOpen(true);
  };

  const handleOverviewAddSubmit = async (formData: EmployeeFormData) => {
    const { employee, temporaryPassword } = await handleCreateEmployee(formData);
    setGeneratedCredentials([{ employee, temporaryPassword }]);
    setCredentialsModalOpen(true);
  };

  const navItems = [
    {
      id: 'overview' as AdminTab,
      label: 'Overview',
      icon: LayoutDashboard,
    },
    {
      id: 'employees' as AdminTab,
      label: 'Employees',
      icon: Users,
      badge: employees.length,
    },
    {
      id: 'import' as AdminTab,
      label: 'Bulk Import',
      icon: UploadCloud,
    },
    {
      id: 'settings' as AdminTab,
      label: 'Settings',
      icon: Settings,
    },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-[#1e293b] flex flex-col font-sans">
      {/* Top Main Navigation Header */}
      <header className="bg-white border-b border-[#e2e8f0] sticky top-0 z-40 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand / Logo */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-md text-[#64748b] hover:text-[#1e293b] hover:bg-[#f1f5f9] cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div className="w-9 h-9 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-[15px] text-[#1e293b] tracking-tight">
                  {settings?.schoolName || 'Electrix Institute of Technology (EIT)'}
                </span>
                <span className="hidden sm:inline-block bg-purple-50 text-purple-800 border border-purple-200 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded">
                  Administration
                </span>
              </div>
              <div className="text-[11px] text-[#64748b] hidden sm:flex items-center gap-1.5">
                <Calendar className="w-3 h-3 text-[#1e3a8a]" />
                <span>
                  Academic Year <strong>{formattedYear || '2026–2027'}</strong> &bull; Super Admin Workspace (PO-001)
                </span>
              </div>
            </div>
          </div>

          {/* User Profile & Logout */}
          <div className="flex items-center gap-3">
            {session?.availableOffices && session.availableOffices.length > 1 && (
              <div className="flex items-center gap-1.5 text-xs">
                <label htmlFor="admin-office-switcher" className="sr-only">
                  Select Active Office
                </label>
                <select
                  id="admin-office-switcher"
                  value={activeOfficeKey || 'ADMINISTRATION'}
                  onChange={(e) => switchActiveOffice(e.target.value)}
                  className="px-2.5 py-1 rounded-md text-xs font-semibold text-[#1e3a8a] bg-[#eff6ff] border border-[#dbeafe] focus:outline-none cursor-pointer"
                >
                  {session.availableOffices.map((off) => (
                    <option key={off.office_id} value={off.office_key}>
                      {off.office_name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div className="hidden md:flex flex-col text-right">
              <span className="text-xs font-bold text-[#1e293b]">{user?.name || 'Administrator'}</span>
              <span className="text-[11px] text-[#64748b] flex items-center justify-end gap-1">
                <Shield className="w-3 h-3 text-purple-700" />
                Super Admin
              </span>
            </div>

            <div className="w-8 h-8 rounded-full bg-purple-100 border border-purple-200 text-purple-900 flex items-center justify-center font-bold text-xs">
              {user?.name ? user.name[0].toUpperCase() : 'A'}
            </div>

            <div className="h-6 w-px bg-[#e2e8f0] mx-1"></div>

            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#64748b] hover:text-[#1e3a8a] hover:bg-[#f1f5f9] px-2.5 py-1.5 rounded-md transition-colors cursor-pointer"
              title="Log out of Super Admin"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer / Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-[#e2e8f0] bg-white px-4 py-3 space-y-1">
            <div className="px-3 py-1.5 mb-2 bg-[#f8fafc] rounded-md text-xs text-[#64748b] flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              <span>Academic Year: <strong>{formattedYear || '2026–2027'}</strong></span>
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium cursor-pointer ${
                    isActive
                      ? 'bg-[#eff6ff] text-[#1e3a8a] font-semibold'
                      : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </div>
                  {item.badge !== undefined && (
                    <span className="bg-[#f1f5f9] text-[#475569] text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        )}
      </header>

      {/* Main Layout Container */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 flex flex-col lg:flex-row gap-6">
        {/* Desktop Sidebar Navigation */}
        <aside className="hidden lg:block w-56 shrink-0">
          <div className="bg-white border border-[#e2e8f0] rounded-xl p-3 shadow-xs sticky top-22 space-y-1">
            <div className="px-3 py-2 mb-1">
              <span className="text-[11px] font-bold text-[#94a3b8] uppercase tracking-wider">
                Management
              </span>
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold shadow-xs'
                      : 'text-[#64748b] hover:bg-[#f8fafc] hover:text-[#1e293b]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                    {item.label}
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isActive
                          ? 'bg-[#dbeafe] text-[#1e3a8a]'
                          : 'bg-[#f1f5f9] text-[#64748b]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 min-w-0">
          {isLoading ? (
            <div className="bg-white border border-[#e2e8f0] rounded-xl p-12 text-center text-[#64748b] shadow-xs">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#1e3a8a] mb-3"></div>
              <p className="text-xs">Loading administration modules...</p>
            </div>
          ) : (
            <>
              {activeTab === 'overview' && (
                <AdminOverview
                  employees={employees}
                  onNavigateToTab={(tab) => setActiveTab(tab)}
                  onOpenAddModal={() => setAddModalOpen(true)}
                  onSelectEmployee={handleOverviewSelectEmployee}
                />
              )}

              {activeTab === 'employees' && (
                <EmployeeManagement
                  employees={employees}
                  onRefresh={loadData}
                  onCreateEmployee={handleCreateEmployee}
                  onUpdateEmployee={handleUpdateEmployee}
                  onToggleStatus={handleToggleStatus}
                  onResetPassword={handleResetPassword}
                  onNavigateToImport={() => setActiveTab('import')}
                />
              )}

              {activeTab === 'import' && (
                <BulkImportView
                  onImportCompleted={loadData}
                  onNavigateToEmployees={() => setActiveTab('employees')}
                />
              )}

              {activeTab === 'settings' && (
                <SystemSettingsView
                  onSettingsUpdated={(updated) => setSettings(updated)}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Global Modals for Overview Shortcuts */}
      <EmployeeFormModal
        isOpen={addModalOpen}
        onClose={() => setAddModalOpen(false)}
        onSubmit={async (formData) => {
          await handleOverviewAddSubmit(formData);
        }}
      />

      <EmployeeDetailModal
        isOpen={isDetailOpen}
        employee={selectedEmployee}
        onClose={() => setIsDetailOpen(false)}
        onEdit={() => {
          setIsDetailOpen(false);
          setActiveTab('employees');
        }}
        onToggleStatus={async (emp) => {
          const updated = await handleToggleStatus(emp.id);
          setSelectedEmployee(updated);
        }}
        onResetPassword={async (emp) => {
          const { employee, temporaryPassword } = await handleResetPassword(emp.id);
          setSelectedEmployee(employee);
          setGeneratedCredentials([{ employee, temporaryPassword }]);
          setCredentialsModalOpen(true);
        }}
      />

      <CredentialsModal
        isOpen={credentialsModalOpen}
        onClose={() => setCredentialsModalOpen(false)}
        items={generatedCredentials}
      />
    </div>
  );
}
