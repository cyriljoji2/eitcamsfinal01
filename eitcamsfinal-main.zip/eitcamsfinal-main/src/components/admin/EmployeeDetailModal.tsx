import { useState } from 'react';
import {
  Calendar,
  Building,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Shield,
  Edit2,
  KeyRound,
  X,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { Employee } from '../../types/employee';
import { EMPLOYEE_ROLES } from '../../services/employeeService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

export interface EmployeeDetailModalProps {
  isOpen: boolean;
  employee: Employee | null;
  onClose: () => void;
  onEdit: (employee: Employee) => void;
  onToggleStatus: (employee: Employee) => Promise<void>;
  onResetPassword: (employee: Employee) => Promise<void>;
}

export function EmployeeDetailModal({
  isOpen,
  employee,
  onClose,
  onEdit,
  onToggleStatus,
  onResetPassword,
}: EmployeeDetailModalProps) {
  const [isToggling, setIsToggling] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  if (!isOpen || !employee) return null;

  const roleInfo = EMPLOYEE_ROLES[employee.role];
  const isActive = employee.status === 'active';

  const handleStatusToggle = async () => {
    setIsToggling(true);
    try {
      await onToggleStatus(employee);
    } finally {
      setIsToggling(false);
    }
  };

  const handlePasswordReset = async () => {
    if (
      window.confirm(
        `Are you sure you want to generate a new temporary password for ${employee.fullName} (${employee.id})?`
      )
    ) {
      setIsResetting(true);
      try {
        await onResetPassword(employee);
      } finally {
        setIsResetting(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Top Header */}
        <div className="bg-[#f8fafc] px-6 py-5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#eff6ff] border border-[#dbeafe] text-[#1e3a8a] flex items-center justify-center font-bold text-lg">
              {employee.fullName
                .split(' ')
                .map((n) => n[0])
                .slice(0, 2)
                .join('')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-[18px] font-bold text-[#1e293b]">{employee.fullName}</h2>
                <Badge variant={isActive ? 'emerald' : 'neutral'} size="sm">
                  {isActive ? 'Active Staff' : 'Inactive / Suspended'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-0.5">
                <span className="font-mono font-semibold text-[#1e3a8a]">{employee.id}</span> &bull;{' '}
                {employee.designation}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Sections */}
        <div className="p-6 max-h-[70vh] overflow-y-auto space-y-6">
          {/* Institutional Assignment Card */}
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4">
            <h3 className="text-[12px] font-bold text-[#475569] uppercase tracking-wider mb-3 flex items-center gap-2">
              <Building className="w-4 h-4 text-[#1e3a8a]" />
              Institutional Profile & Role
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-[13px]">
              <div>
                <span className="text-[#64748b] block mb-0.5 font-medium">Department / Office</span>
                <span className="font-semibold text-[#1e293b]">{employee.department}</span>
              </div>

              <div>
                <span className="text-[#64748b] block mb-0.5 font-medium">Designation / Title</span>
                <span className="font-semibold text-[#1e293b]">{employee.designation}</span>
              </div>

              <div>
                <span className="text-[#64748b] block mb-0.5 font-medium">Assigned System Role</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Shield className="w-3.5 h-3.5 text-[#1e3a8a]" />
                  <span className="font-semibold text-[#1e3a8a]">
                    {roleInfo?.title || employee.role}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-[#64748b] block mb-0.5 font-medium">Joining Date</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Calendar className="w-3.5 h-3.5 text-[#64748b]" />
                  <span className="font-semibold text-[#1e293b]">{employee.joiningDate}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Personal & Contact Information */}
          <div className="space-y-3">
            <h3 className="text-[12px] font-bold text-[#475569] uppercase tracking-wider flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-[#1e3a8a]" />
              Personal & Contact Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-[13px]">
              <div className="p-3 rounded-lg border border-[#e2e8f0] bg-white">
                <span className="text-[#64748b] block mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#64748b]" />
                  Official Email Address
                </span>
                <span className="font-semibold text-[#1e293b] break-all">{employee.email}</span>
              </div>

              <div className="p-3 rounded-lg border border-[#e2e8f0] bg-white">
                <span className="text-[#64748b] block mb-1 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-[#64748b]" />
                  Mobile Contact Number
                </span>
                <span className="font-semibold text-[#1e293b]">{employee.mobile}</span>
              </div>

              <div className="p-3 rounded-lg border border-[#e2e8f0] bg-white">
                <span className="text-[#64748b] block mb-1 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#64748b]" />
                  Date of Birth
                </span>
                <span className="font-semibold text-[#1e293b]">{employee.dateOfBirth}</span>
              </div>

              <div className="p-3 rounded-lg border border-[#e2e8f0] bg-white">
                <span className="text-[#64748b] block mb-1">Gender</span>
                <span className="font-semibold text-[#1e293b]">{employee.gender || 'Not specified'}</span>
              </div>

              <div className="p-3 rounded-lg border border-[#e2e8f0] bg-white sm:col-span-2">
                <span className="text-[#64748b] block mb-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#64748b]" />
                  Residential / Postal Address
                </span>
                <span className="font-semibold text-[#1e293b]">{employee.address || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Account Authentication & Security Audit */}
          <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4">
            <h3 className="text-[12px] font-bold text-[#475569] uppercase tracking-wider mb-3 flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#1e3a8a]" />
              Account & Credentials Policy
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-2.5 rounded-lg border border-[#e2e8f0]">
                <span className="text-[#64748b] block font-medium">Portal Username</span>
                <span className="font-mono font-semibold text-[#1e293b]">{employee.username}</span>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-[#e2e8f0]">
                <span className="text-[#64748b] block font-medium">Password Policy Status</span>
                <span className="font-medium text-[#1e293b]">
                  {employee.isTemporaryPassword ? 'Temporary Password Active' : 'Permanent Password Configured'}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-[#e2e8f0]">
                <span className="text-[#64748b] block font-medium">Record Created</span>
                <span className="font-medium text-[#1e293b]">
                  {new Date(employee.createdAt).toLocaleDateString()}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-lg border border-[#e2e8f0]">
                <span className="text-[#64748b] block font-medium">System ID</span>
                <span className="font-mono font-semibold text-[#1e3a8a]">{employee.id}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="bg-[#f8fafc] px-6 py-4 border-t border-[#e2e8f0] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button
              variant={isActive ? 'danger' : 'outline'}
              size="sm"
              onClick={handleStatusToggle}
              isLoading={isToggling}
              leftIcon={isActive ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
            >
              {isActive ? 'Deactivate Employee' : 'Activate Employee'}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handlePasswordReset}
              isLoading={isResetting}
              leftIcon={<KeyRound className="w-4 h-4 text-amber-600" />}
            >
              Reset Password
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                onClose();
                onEdit(employee);
              }}
              leftIcon={<Edit2 className="w-4 h-4" />}
            >
              Edit Details
            </Button>
            <Button variant="primary" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
