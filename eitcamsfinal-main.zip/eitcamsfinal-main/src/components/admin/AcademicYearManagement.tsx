import { useState, useEffect } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Archive,
  AlertTriangle,
  ShieldAlert,
  ArrowRight,
  Plus,
  Trash2,
  History,
  FileCheck2,
  Shield,
  Info,
  RefreshCw,
  X,
} from 'lucide-react';
import { AcademicYearRecord, AcademicYearTransitionAuditRecord } from '../../types/database';
import { academicCalendarService, formatAcademicYear } from '../../services/academicCalendarService';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Badge } from '../ui/Badge';
import { Alert } from '../ui/Alert';

export function AcademicYearManagement() {
  const { user } = useAuth();

  const [academicYears, setAcademicYears] = useState<AcademicYearRecord[]>([]);
  const [transitions, setTransitions] = useState<AcademicYearTransitionAuditRecord[]>([]);
  const [activeYear, setActiveYear] = useState<AcademicYearRecord | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Modal & Form States
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newYearCode, setNewYearCode] = useState('');
  const [newStartDate, setNewStartDate] = useState('');
  const [newEndDate, setNewEndDate] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Activation Confirmation Modal
  const [activateModalOpen, setActivateModalOpen] = useState(false);
  const [targetYearToActivate, setTargetYearToActivate] = useState<AcademicYearRecord | null>(null);
  const [activationReason, setActivationReason] = useState('');
  const [activateError, setActivateError] = useState<string | null>(null);
  const [isActivating, setIsActivating] = useState(false);

  // Success Notification
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // Check if current user is Super Admin
  const isSuperAdmin =
    user?.role === 'SUPER_ADMIN' ||
    user?.role === 'super_admin' ||
    user?.username === 'admin';

  const loadCalendarData = async () => {
    setIsLoading(true);
    try {
      const [allYears, currentActive, history] = await Promise.all([
        academicCalendarService.getAllAcademicYears(),
        academicCalendarService.getActiveAcademicYear(),
        academicCalendarService.getTransitionHistory(),
      ]);
      setAcademicYears(allYears);
      setActiveYear(currentActive);
      setTransitions(history);
    } catch (err: any) {
      console.error('Failed to load academic calendar data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadCalendarData();
    const unsubscribe = academicCalendarService.subscribe(() => {
      loadCalendarData();
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Handle Create Academic Year
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!newYearCode.trim()) {
      setFormError('Academic Year code is required (e.g. 2028-2029).');
      return;
    }
    if (!newStartDate) {
      setFormError('Start date is required.');
      return;
    }
    if (!newEndDate) {
      setFormError('End date is required.');
      return;
    }
    if (new Date(newStartDate) >= new Date(newEndDate)) {
      setFormError('Start date must be strictly before End date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await academicCalendarService.createAcademicYear({
        code: newYearCode.trim(),
        name: formatAcademicYear(newYearCode.trim()),
        startDate: newStartDate,
        endDate: newEndDate,
        status: 'UPCOMING',
      });
      setCreateModalOpen(false);
      setNewYearCode('');
      setNewStartDate('');
      setNewEndDate('');
      setSuccessBanner(`Academic Year ${formatAcademicYear(newYearCode.trim())} created successfully as UPCOMING.`);
      await loadCalendarData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create academic year.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open Activation Confirmation
  const handleOpenActivate = (year: AcademicYearRecord) => {
    setTargetYearToActivate(year);
    setActivationReason('');
    setActivateError(null);
    setActivateModalOpen(true);
  };

  // Confirm Activation
  const handleConfirmActivate = async () => {
    if (!targetYearToActivate) return;
    if (!activationReason.trim()) {
      setActivateError('A mandatory institutional reason/justification is required for audit history.');
      return;
    }

    if (!isSuperAdmin) {
      setActivateError('Access Denied: Only an authorized Super Administrator can activate the global academic year.');
      return;
    }

    setIsActivating(true);
    setActivateError(null);
    try {
      await academicCalendarService.activateAcademicYear(
        targetYearToActivate.year_id,
        activationReason.trim(),
        {
          userId: user?.id || 'admin',
          name: user?.name || 'Administrator',
          role: 'SUPER_ADMIN',
        }
      );
      setActivateModalOpen(false);
      setSuccessBanner(
        `Institutional Academic Year successfully updated to ${formatAcademicYear(
          targetYearToActivate.code
        )}. Broadcasted to all offices & portals.`
      );
      await loadCalendarData();
    } catch (err: any) {
      setActivateError(err.message || 'Failed to activate academic year.');
    } finally {
      setIsActivating(false);
    }
  };

  // Handle Delete Academic Year
  const handleDeleteYear = async (year: AcademicYearRecord) => {
    if (year.status === 'ACTIVE') {
      alert('The currently ACTIVE academic year cannot be deleted. Transition to another year first.');
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to delete academic year ${formatAcademicYear(year.code)}? This operation will be blocked if any institutional records are attached.`
    );
    if (!confirmed) return;

    try {
      await academicCalendarService.deleteAcademicYear(year.year_id);
      setSuccessBanner(`Academic year ${formatAcademicYear(year.code)} removed.`);
      await loadCalendarData();
    } catch (err: any) {
      alert(`Cannot delete academic year: ${err.message || 'Institutional records exist.'}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#e2e8f0]">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-200">
              <Calendar className="w-4 h-4" />
            </div>
            <h3 className="text-[17px] font-bold text-[#1e293b]">
              Central Academic Year Management
            </h3>
          </div>
          <p className="text-xs text-[#64748b] mt-1">
            Administration Office is the single authoritative controller of the institution-wide active academic year.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={loadCalendarData}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>

          {isSuperAdmin && (
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={() => {
                setFormError(null);
                setCreateModalOpen(true);
              }}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Academic Year
            </Button>
          )}
        </div>
      </div>

      {successBanner && (
        <Alert
          type="success"
          message={successBanner}
          onDismiss={() => setSuccessBanner(null)}
        />
      )}

      {/* Hero Card: Current Authoritative Active Academic Year */}
      <div className="bg-gradient-to-br from-[#eff6ff] via-white to-[#f0fdf4] border-2 border-[#1e3a8a]/20 rounded-xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#1e3a8a] bg-[#dbeafe] px-2.5 py-0.5 rounded-full border border-[#bfdbfe]">
                Authoritative Master Year
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-full">
                <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                ACTIVE INSTITUTION-WIDE
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1e293b] tracking-tight">
                {activeYear ? formatAcademicYear(activeYear.code) : '2026–2027'}
              </h2>
              <span className="text-xs font-mono text-[#64748b]">
                ({activeYear?.start_date} to {activeYear?.end_date})
              </span>
            </div>

            <p className="text-xs text-[#475569] max-w-2xl leading-relaxed">
              All 6 permanent institutional offices (Admissions, Academic, COE, Finance, Hostel, Administration), faculty workflows, and student/parent portals are synchronized with this active academic year.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2 shrink-0 text-center">
            <div className="bg-white/90 border border-[#e2e8f0] p-3 rounded-lg shadow-2xs">
              <div className="text-xs text-[#64748b]">Total Years</div>
              <div className="text-lg font-bold text-[#1e293b]">{academicYears.length}</div>
            </div>
            <div className="bg-white/90 border border-emerald-200 p-3 rounded-lg shadow-2xs">
              <div className="text-xs text-emerald-800 font-medium">Upcoming</div>
              <div className="text-lg font-bold text-emerald-700">
                {academicYears.filter((y) => y.status === 'UPCOMING').length}
              </div>
            </div>
            <div className="bg-white/90 border border-slate-200 p-3 rounded-lg shadow-2xs">
              <div className="text-xs text-[#64748b]">Archived</div>
              <div className="text-lg font-bold text-[#64748b]">
                {academicYears.filter((y) => y.status === 'ARCHIVED').length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Historical Data & Year Transition Safety Notice */}
      <div className="bg-[#f8fafc] border border-[#e2e8f0] rounded-xl p-4 flex items-start gap-3 text-xs text-[#475569]">
        <Info className="w-4 h-4 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold text-[#1e293b]">Historical Data Integrity Guarantee:</span>
          <p>
            Changing the institutional active academic year does <strong>not</strong> alter historical records, grade transcripts, past fee receipts, hostel allocations, or student batch assignments. Historical records retain their original academic year tags and remain accessible in read-only audit views.
          </p>
        </div>
      </div>

      {/* Academic Years Master Table */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div>
            <h4 className="text-[15px] font-bold text-[#1e293b]">Institutional Academic Calendar Roster</h4>
            <p className="text-xs text-[#64748b]">Current, upcoming, and archived calendar periods.</p>
          </div>
          <span className="text-xs font-medium text-[#64748b] bg-[#f1f5f9] px-2.5 py-1 rounded-md">
            {academicYears.length} Configured Periods
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-[13px]">
            <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#475569] font-semibold">
              <tr>
                <th className="py-3 px-4">Academic Year Code</th>
                <th className="py-3 px-4">Display Label</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Start Date</th>
                <th className="py-3 px-4">End Date</th>
                <th className="py-3 px-4 text-right">Administrative Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f1f5f9]">
              {academicYears.map((ay) => {
                const isActive = ay.status === 'ACTIVE';
                const isUpcoming = ay.status === 'UPCOMING';
                const isArchived = ay.status === 'ARCHIVED';

                return (
                  <tr
                    key={ay.year_id}
                    className={`transition-colors ${
                      isActive ? 'bg-[#f0fdf4]/50 hover:bg-[#f0fdf4]' : 'hover:bg-[#f8fafc]'
                    }`}
                  >
                    <td className="py-3 px-4 font-mono font-bold text-[#1e3a8a]">{ay.code}</td>
                    <td className="py-3 px-4 font-semibold text-[#1e293b]">{ay.name}</td>
                    <td className="py-3 px-4">
                      {isActive && (
                        <span className="inline-flex items-center gap-1 bg-[#dcfce7] text-[#166534] border border-[#bbf7d0] text-[11px] font-bold px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" />
                          ACTIVE
                        </span>
                      )}
                      {isUpcoming && (
                        <span className="inline-flex items-center gap-1 bg-[#dbeafe] text-[#1e40af] border border-[#bfdbfe] text-[11px] font-bold px-2 py-0.5 rounded-full">
                          <Clock className="w-3 h-3" />
                          UPCOMING
                        </span>
                      )}
                      {isArchived && (
                        <span className="inline-flex items-center gap-1 bg-[#f1f5f9] text-[#64748b] border border-[#e2e8f0] text-[11px] font-medium px-2 py-0.5 rounded-full">
                          <Archive className="w-3 h-3" />
                          ARCHIVED
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-[#475569]">{ay.start_date}</td>
                    <td className="py-3 px-4 text-[#475569]">{ay.end_date}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-2 justify-end">
                        {isActive ? (
                          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                            Currently Active
                          </span>
                        ) : (
                          <>
                            {isSuperAdmin && (
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenActivate(ay)}
                                leftIcon={<ArrowRight className="w-3.5 h-3.5 text-indigo-600" />}
                              >
                                Activate Year
                              </Button>
                            )}

                            {isSuperAdmin && !isActive && (
                              <button
                                type="button"
                                title="Delete Academic Year"
                                onClick={() => handleDeleteYear(ay)}
                                className="p-1.5 text-[#94a3b8] hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transition Audit Trail Section */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl shadow-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-[#1e3a8a]" />
            <h4 className="text-[15px] font-bold text-[#1e293b]">
              Academic Year Transition Audit Trail
            </h4>
          </div>
          <span className="text-xs text-[#64748b]">Immutable Administrative Log</span>
        </div>

        <div className="p-5">
          {transitions.length === 0 ? (
            <div className="text-center py-6 text-xs text-[#64748b]">
              No transitions recorded yet. The system initialized with default active calendar year.
            </div>
          ) : (
            <div className="space-y-3">
              {transitions.map((item) => (
                <div
                  key={item.transition_id}
                  className="bg-[#f8fafc] border border-[#e2e8f0] rounded-lg p-3.5 text-xs space-y-2 hover:border-[#cbd5e1] transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#f1f5f9]">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[#64748b] bg-white border border-[#e2e8f0] px-2 py-0.5 rounded">
                        {item.previous_year_code}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#1e3a8a]" />
                      <span className="font-mono font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                        {item.new_year_code}
                      </span>
                      <Badge variant="purple" size="sm">
                        Super Admin Authorization
                      </Badge>
                    </div>

                    <div className="text-[11px] text-[#64748b]">
                      {new Date(item.timestamp).toLocaleString()}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[#475569]">
                    <div>
                      <span className="text-[#94a3b8] font-medium mr-1.5">Authorized By:</span>
                      <span className="font-semibold text-[#1e293b]">
                        {item.activated_by_name} ({item.activated_by_user_id})
                      </span>
                    </div>
                    <div>
                      <span className="text-[#94a3b8] font-medium mr-1.5">Role:</span>
                      <span className="font-semibold text-purple-700">{item.activated_by_role}</span>
                    </div>
                  </div>

                  <div className="bg-white p-2.5 rounded border border-[#e2e8f0]">
                    <span className="text-[#94a3b8] block font-medium mb-0.5">Transition Reason:</span>
                    <span className="italic text-[#1e293b]">{item.reason}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modal: Create Academic Year */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center border border-[#dbeafe]">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[16px] font-bold text-[#1e293b]">Add Academic Year</h3>
                  <p className="text-xs text-[#64748b]">Create an upcoming institutional academic period</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setCreateModalOpen(false)}
                className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4">
              {formError && <Alert type="error" message={formError} onDismiss={() => setFormError(null)} />}

              <div>
                <Input
                  id="ay-code"
                  label="Academic Year Code *"
                  placeholder="e.g. 2028-2029"
                  value={newYearCode}
                  onChange={(e) => setNewYearCode(e.target.value)}
                  helperText="Format: YYYY-YYYY. Will automatically format to 2028–2029."
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Input
                    id="ay-start-date"
                    label="Start Date *"
                    type="date"
                    value={newStartDate}
                    onChange={(e) => setNewStartDate(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Input
                    id="ay-end-date"
                    label="End Date *"
                    type="date"
                    value={newEndDate}
                    onChange={(e) => setNewEndDate(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-1">
                <span className="font-bold flex items-center gap-1 text-amber-950">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-700" />
                  Upcoming Status:
                </span>
                <p>
                  Newly registered years will be saved as <strong>UPCOMING</strong>. Super Administrator can initiate an authorized transition when commencing the period.
                </p>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setCreateModalOpen(false)}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmitting}
                  leftIcon={<Plus className="w-4 h-4" />}
                >
                  Create Academic Year
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Authorized Activation Confirmation */}
      {activateModalOpen && targetYearToActivate && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="bg-amber-50 px-6 py-4 border-b border-amber-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center border border-amber-300">
                  <AlertTriangle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-[16px] font-bold text-amber-950">
                    Authorize Academic Year Transition
                  </h3>
                  <p className="text-xs text-amber-800">Super Administrator Authorization Required</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActivateModalOpen(false)}
                className="text-amber-800 hover:text-amber-950 p-1.5 rounded-md hover:bg-amber-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {activateError && <Alert type="error" message={activateError} onDismiss={() => setActivateError(null)} />}

              <div className="p-3.5 bg-[#f8fafc] border border-[#e2e8f0] rounded-xl text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[#64748b]">Current Active Year:</span>
                  <span className="font-mono font-bold text-[#1e293b]">
                    {activeYear ? formatAcademicYear(activeYear.code) : '2026–2027'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-emerald-800">
                  <span className="font-semibold">New Target Active Year:</span>
                  <span className="font-mono font-extrabold text-base">
                    {formatAcademicYear(targetYearToActivate.code)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[#64748b]">
                  <span>Target Calendar Period:</span>
                  <span className="font-mono">
                    {targetYearToActivate.start_date} to {targetYearToActivate.end_date}
                  </span>
                </div>
              </div>

              <div className="bg-[#eff6ff] border border-[#dbeafe] rounded-lg p-3 text-xs text-[#1e3a8a] space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" />
                  Global CAMS Synchronization:
                </span>
                <p>
                  Confirming this transition instantly synchronizes all 6 permanent offices (Admissions, Academic, COE, Finance, Hostel, Administration), Faculty portal, and Student/Parent portals to <strong>{formatAcademicYear(targetYearToActivate.code)}</strong>.
                </p>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="ay-reason" className="block text-xs font-semibold text-[#1e293b]">
                  Institutional Transition Reason / Justification *
                </label>
                <textarea
                  id="ay-reason"
                  rows={3}
                  value={activationReason}
                  onChange={(e) => setActivationReason(e.target.value)}
                  placeholder="e.g. Commencing Fall 2027 academic session and institutional annual rollover."
                  className="w-full text-xs rounded-md border border-[#e2e8f0] p-2.5 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
                  required
                />
                <p className="text-[11px] text-[#64748b]">
                  Required for institutional compliance and permanent audit record.
                </p>
              </div>

              <div className="pt-3 border-t border-[#e2e8f0] flex items-center justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setActivateModalOpen(false)}
                  disabled={isActivating}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="primary"
                  size="sm"
                  onClick={handleConfirmActivate}
                  isLoading={isActivating}
                  leftIcon={<CheckCircle2 className="w-4 h-4" />}
                >
                  Confirm & Activate Institution-Wide
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
