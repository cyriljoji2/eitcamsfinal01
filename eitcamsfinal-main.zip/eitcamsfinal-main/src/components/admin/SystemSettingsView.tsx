import React, { useState, useEffect } from 'react';
import {
  Save,
  Building,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Database,
  FileSpreadsheet,
  Cloud,
  Clock,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { SystemSettings } from '../../types/employee';
import { settingsRepository } from '../../services/employeeService';
import { formatAcademicYear } from '../../services/academicCalendarService';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';
import { AcademicYearManagement } from './AcademicYearManagement';

export interface SystemSettingsViewProps {
  onSettingsUpdated?: (settings: SystemSettings) => void;
}

const NORMALIZED_SHEETS = [
  { key: 'SETTINGS', name: 'Settings & Calendar', desc: 'System configuration, institution profile, and academic calendar master' },
  { key: 'EMPLOYEES', name: 'Employees & Roles', desc: 'Staff directory, permanent office identities, credentials, and roles' },
  { key: 'STUDENTS', name: 'Students & Admissions', desc: 'Student admissions, enrollment registrations, and parent profiles' },
  { key: 'ACADEMICS', name: 'Academics & Courses', desc: 'Departments, programs, course offerings, and syllabus records' },
  { key: 'ATTENDANCE', name: 'Attendance Registers', desc: 'Daily lecture attendance logs and proctor evaluations' },
  { key: 'FINANCE_STRUCTURES', name: 'Fee Structures', desc: 'Fee heads, department quotas, and semester payment rules' },
  { key: 'FINANCE_LEDGER', name: 'Financial Ledger', desc: 'Student invoices, collected fee receipts, and transaction records' },
  { key: 'EXAMINATIONS', name: 'Examinations Master', desc: 'Examination schedules, hall tickets, and course timetables' },
  { key: 'MARKS_RESULTS', name: 'Marks & Results', desc: 'Marks entry control, verified grades, transcripts, and GPAs' },
];

export function SystemSettingsView({ onSettingsUpdated }: SystemSettingsViewProps) {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [schoolName, setSchoolName] = useState('');
  const [schoolAddress, setSchoolAddress] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [academicYear, setAcademicYear] = useState('');

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const data = await settingsRepository.getSettings();
      setSettings(data);
      setSchoolName(data.schoolName);
      setSchoolAddress(data.schoolAddress);
      setContactNumber(data.contactNumber);
      setEmail(data.email);
      setAcademicYear(data.academicYear);
    } catch (err: any) {
      setErrorMessage('Failed to load system settings.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    if (!schoolName.trim()) {
      setErrorMessage('Institution Name is required.');
      return;
    }

    setIsSaving(true);
    try {
      const updated = await settingsRepository.updateSettings({
        schoolName: schoolName.trim(),
        schoolAddress: schoolAddress.trim(),
        contactNumber: contactNumber.trim(),
        email: email.trim(),
        academicYear: academicYear.trim(),
      });

      setSettings(updated);
      setSuccessMessage('Institutional profile settings updated successfully.');
      if (onSettingsUpdated) {
        onSettingsUpdated(updated);
      }
    } catch (err: any) {
      setErrorMessage('Failed to save settings.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="py-16 text-center text-[#64748b]">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#1e3a8a] mb-2"></div>
        <p className="text-xs">Loading institutional settings...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#e2e8f0]">
        <div>
          <h2 className="text-[20px] sm:text-[22px] font-bold text-[#1e293b] tracking-tight">
            Institutional Settings & Calendar
          </h2>
          <p className="text-[13px] text-[#64748b] mt-0.5">
            Configure university profile, central academic calendar master, and institutional persistence architecture.
          </p>
        </div>
      </div>

      {successMessage && (
        <Alert
          type="success"
          message={successMessage}
          onDismiss={() => setSuccessMessage(null)}
        />
      )}

      {errorMessage && (
        <Alert
          type="error"
          message={errorMessage}
          onDismiss={() => setErrorMessage(null)}
        />
      )}

      {/* 1. Academic Year Management Section */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs">
        <AcademicYearManagement />
      </div>

      {/* 2. University Institutional Profile Form */}
      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#f1f5f9]">
            <Building className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-[15px] font-bold text-[#1e293b]">Institutional Information</h3>
              <p className="text-xs text-[#64748b]">
                Official branding and contact details displayed across student, employee, and parent portal interfaces.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <Input
                id="settings-school-name"
                label="Institution Name *"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                placeholder="e.g. Electrix Institute of Technology (EIT)"
                required
              />
            </div>

            <div>
              <Input
                id="settings-academic-year"
                label="Current Academic Year *"
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                placeholder="e.g. 2026–2027"
                startIcon={<Calendar className="w-4 h-4" />}
                required
              />
            </div>

            <div>
              <Input
                id="settings-contact-phone"
                label="Official University Contact Number"
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="+91 44 2235 7004"
                startIcon={<Phone className="w-4 h-4" />}
              />
            </div>

            <div>
              <Input
                id="settings-contact-email"
                label="Official Administration Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@eit.edu"
                startIcon={<Mail className="w-4 h-4" />}
              />
            </div>

            <div className="sm:col-span-2">
              <Input
                id="settings-address"
                label="Campus Physical Address"
                value={schoolAddress}
                onChange={(e) => setSchoolAddress(e.target.value)}
                placeholder="Technology Campus, Electrix Avenue, Chennai, Tamil Nadu 600025"
                startIcon={<MapPin className="w-4 h-4" />}
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <Button
              type="submit"
              variant="primary"
              size="md"
              isLoading={isSaving}
              leftIcon={<Save className="w-4 h-4" />}
            >
              Save Institutional Profile
            </Button>
          </div>
        </div>
      </form>

      {/* 3. Google Sheets Persistence Architecture & Phase 11 Deferral Notice */}
      <div className="bg-white border border-[#e2e8f0] rounded-xl p-6 shadow-xs space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-[#f1f5f9]">
          <div className="flex items-center gap-2.5">
            <Cloud className="w-5 h-5 text-[#1e3a8a]" />
            <div>
              <h3 className="text-[15px] font-bold text-[#1e293b]">
                Google Sheets Persistence Gateway
              </h3>
              <p className="text-xs text-[#64748b]">
                Cloud synchronization architecture & 9-sheet normalized schema.
              </p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1.5 bg-amber-50 text-amber-900 border border-amber-200 text-xs font-semibold px-2.5 py-1 rounded-full">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            Live Sync Deferred to Phase 11
          </span>
        </div>

        {/* Informational Banner */}
        <div className="bg-[#eff6ff] border border-[#dbeafe] rounded-xl p-4 text-xs text-[#1e3a8a] space-y-2">
          <div className="flex items-center gap-2 font-bold text-[13px]">
            <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
            Institutional Data Persistence Guarantee
          </div>
          <p className="text-[#3b82f6] leading-relaxed">
            Live Google Sheets cloud syncing is intentionally scheduled for <strong>Phase 11</strong>. All student records, employee rosters, permanent institutional offices, fee ledger items, and the central active academic year are persisted securely within the EIT CAMS architecture with verified real-time event subscriptions.
          </p>
        </div>

        {/* 9 Normalized Sheets Overview */}
        <div>
          <h4 className="text-xs font-bold text-[#475569] uppercase tracking-wider mb-3 flex items-center gap-2">
            <Database className="w-4 h-4 text-[#1e3a8a]" />
            9 Standardized Normalized Sheets Schema:
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            {NORMALIZED_SHEETS.map((sheet) => (
              <div
                key={sheet.key}
                className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] space-y-1 hover:border-[#cbd5e1] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#1e293b] flex items-center gap-1.5">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                    {sheet.name}
                  </span>
                  <span className="bg-[#dcfce7] text-[#166534] font-semibold px-1.5 py-0.5 rounded text-[10px]">
                    Schema Ready
                  </span>
                </div>
                <p className="text-[11px] text-[#64748b] leading-normal">{sheet.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
