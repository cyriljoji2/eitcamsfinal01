import React, { useState, useEffect } from 'react';
import {
  UserPlus,
  Edit,
  X,
  Shield,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  Sparkles,
} from 'lucide-react';
import { Employee, EmployeeFormData, GenderType } from '../../types/employee';
import { EmployeeRole } from '../../types/auth';
import { EMPLOYEE_ROLES } from '../../services/employeeService';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Alert } from '../ui/Alert';

export interface EmployeeFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: EmployeeFormData, isEditing: boolean, employeeId?: string) => Promise<void>;
  initialEmployee?: Employee | null;
}

const COMMON_DEPARTMENTS = [
  'Central Administration',
  'Office of Academic Affairs',
  'Student Admissions & Enrollment',
  'Finance & Accounts Office',
  'Controller of Examinations (COE)',
  'Hostel & Residential Life',
  'Department of Electrical & Electronics Engineering',
  'Department of Computer Science & Engineering',
  'Department of Mechanical Engineering',
  'Department of Applied Sciences & Mathematics',
  'Department of Humanities & Management',
];

export function EmployeeFormModal({
  isOpen,
  onClose,
  onSubmit,
  initialEmployee,
}: EmployeeFormModalProps) {
  const isEditing = !!initialEmployee;

  const [fullName, setFullName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState<GenderType>('Male');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [department, setDepartment] = useState('Department of Computer Science & Engineering');
  const [customDepartment, setCustomDepartment] = useState('');
  const [designation, setDesignation] = useState('');
  const [role, setRole] = useState<EmployeeRole>('faculty');
  const [joiningDate, setJoiningDate] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (initialEmployee) {
      setFullName(initialEmployee.fullName || '');
      setDateOfBirth(initialEmployee.dateOfBirth || '');
      setGender((initialEmployee.gender as GenderType) || 'Male');
      setMobile(initialEmployee.mobile || '');
      setEmail(initialEmployee.email || '');
      setAddress(initialEmployee.address || '');

      if (COMMON_DEPARTMENTS.includes(initialEmployee.department)) {
        setDepartment(initialEmployee.department);
        setCustomDepartment('');
      } else {
        setDepartment('Custom');
        setCustomDepartment(initialEmployee.department || '');
      }

      setDesignation(initialEmployee.designation || '');
      setRole((initialEmployee.role as EmployeeRole) || 'faculty');
      setJoiningDate(initialEmployee.joiningDate || '');
      setStatus((initialEmployee.status as 'active' | 'inactive') || 'active');
    } else {
      // Defaults for new employee
      setFullName('');
      setDateOfBirth('1990-01-01');
      setGender('Male');
      setMobile('+91 98765 43210');
      setEmail('');
      setAddress('');
      setDepartment('Office of Academic Affairs');
      setCustomDepartment('');
      setDesignation('');
      setRole('faculty');
      setJoiningDate(new Date().toISOString().split('T')[0]);
      setStatus('active');
    }
    setErrorMessage(null);
  }, [initialEmployee, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Form Validations
    if (!fullName.trim()) {
      setErrorMessage('Full Name is required.');
      return;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setErrorMessage('A valid email address is required.');
      return;
    }
    if (!mobile.trim()) {
      setErrorMessage('Mobile phone number is required.');
      return;
    }
    if (!designation.trim()) {
      setErrorMessage('Designation / Job Title is required.');
      return;
    }
    if (!dateOfBirth) {
      setErrorMessage('Date of Birth is required.');
      return;
    }

    const finalDepartment =
      department === 'Custom' ? customDepartment.trim() || 'General University Staff' : department;

    const formData: EmployeeFormData = {
      fullName: fullName.trim(),
      dateOfBirth,
      gender,
      mobile: mobile.trim(),
      email: email.trim(),
      address: address.trim(),
      department: finalDepartment,
      designation: designation.trim(),
      role,
      joiningDate: joiningDate || new Date().toISOString().split('T')[0],
      status,
    };

    setIsSubmitting(true);
    try {
      await onSubmit(formData, isEditing, initialEmployee?.id);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred while saving employee record.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full border border-[#e2e8f0] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-[#f8fafc] px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#eff6ff] text-[#1e3a8a] flex items-center justify-center border border-[#dbeafe]">
              {isEditing ? <Edit className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-[17px] font-bold text-[#1e293b]">
                {isEditing ? `Edit Staff Record: ${initialEmployee.fullName}` : 'Register New University Employee'}
              </h2>
              <p className="text-xs text-[#64748b]">
                {isEditing
                  ? `Updating record for ${initialEmployee.id}`
                  : 'System will automatically allocate institutional Employee ID, Username, and Temporary Password'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-md hover:bg-[#f1f5f9] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Form */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[75vh] overflow-y-auto space-y-5">
          {errorMessage && (
            <Alert type="error" message={errorMessage} onDismiss={() => setErrorMessage(null)} />
          )}

          {/* Automatic System Generated Fields Notice */}
          {!isEditing ? (
            <div className="bg-[#eff6ff] border border-[#dbeafe] rounded-lg p-3 flex items-start gap-2.5 text-xs text-[#1e3a8a]">
              <Sparkles className="w-4 h-4 text-[#1e3a8a] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Automated Employee ID & Credentials Generation</p>
                <p className="text-[#3b82f6] mt-0.5">
                  The system will automatically allocate a unique institutional <strong>Employee ID</strong> (e.g. EMP2026000X), set it as their portal <strong>Username</strong>, and generate a secure <strong>Temporary Password</strong> that you can view, copy, and export immediately.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0] text-xs">
              <div>
                <span className="text-[#64748b] block font-medium">Employee ID (System Assigned)</span>
                <span className="font-mono font-bold text-[#1e3a8a] text-[13px]">{initialEmployee.id}</span>
              </div>
              <div>
                <span className="text-[#64748b] block font-medium">Portal Username</span>
                <span className="font-mono font-semibold text-[#1e293b] text-[13px]">{initialEmployee.username}</span>
              </div>
            </div>
          )}

          {/* Section 1: Basic Information */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-[#475569] uppercase tracking-wider">
              1. Personal Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <Input
                  id="emp-fullname"
                  label="Full Name *"
                  placeholder="e.g. Dr. Jane Doe"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>

              <div>
                <Input
                  id="emp-dob"
                  label="Date of Birth *"
                  type="date"
                  value={dateOfBirth}
                  onChange={(e) => setDateOfBirth(e.target.value)}
                  required
                />
              </div>

              <div className="text-left space-y-1.5">
                <label htmlFor="emp-gender" className="block text-[13px] font-semibold text-[#1e293b]">
                  Gender *
                </label>
                <select
                  id="emp-gender"
                  value={gender}
                  onChange={(e) => setGender(e.target.value as GenderType)}
                  className="block w-full rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-sm py-2.5 px-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 2: Contact Details */}
          <div className="space-y-3 pt-2 border-t border-[#f1f5f9]">
            <h3 className="text-xs font-bold text-[#475569] uppercase tracking-wider">
              2. Contact & Address
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Input
                  id="emp-email"
                  label="Email Address *"
                  type="email"
                  placeholder="name@eit.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  startIcon={<Mail className="w-4 h-4" />}
                  required
                />
              </div>

              <div>
                <Input
                  id="emp-mobile"
                  label="Mobile Number *"
                  placeholder="+91 98765 43210"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  startIcon={<Phone className="w-4 h-4" />}
                  required
                />
              </div>

              <div className="sm:col-span-2">
                <Input
                  id="emp-address"
                  label="Residential Address"
                  placeholder="Street Address, City, State, PIN"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  startIcon={<MapPin className="w-4 h-4" />}
                />
              </div>
            </div>
          </div>

          {/* Section 3: Institutional Position & Role */}
          <div className="space-y-3 pt-2 border-t border-[#f1f5f9]">
            <h3 className="text-xs font-bold text-[#475569] uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-[#1e3a8a]" />
              3. Institutional Assignment & Role
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="text-left space-y-1.5">
                <label htmlFor="emp-role" className="block text-[13px] font-semibold text-[#1e293b]">
                  Assigned System Role *
                </label>
                <select
                  id="emp-role"
                  value={role}
                  onChange={(e) => setRole(e.target.value as EmployeeRole)}
                  className="block w-full rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-sm py-2.5 px-3 font-medium focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
                >
                  {Object.values(EMPLOYEE_ROLES).map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.title}
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-[#64748b]">
                  {EMPLOYEE_ROLES[role]?.description}
                </p>
              </div>

              <div>
                <Input
                  id="emp-designation"
                  label="Designation / Official Title *"
                  placeholder="e.g. Professor, Assistant Professor, Registrar"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  startIcon={<Briefcase className="w-4 h-4" />}
                  required
                />
              </div>

              <div className="text-left space-y-1.5">
                <label htmlFor="emp-department" className="block text-[13px] font-semibold text-[#1e293b]">
                  Department / Office *
                </label>
                <select
                  id="emp-department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="block w-full rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-sm py-2.5 px-3 focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
                >
                  {COMMON_DEPARTMENTS.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                  <option value="Custom">+ Other / Custom Department...</option>
                </select>
              </div>

              {department === 'Custom' ? (
                <div>
                  <Input
                    id="emp-custom-dept"
                    label="Enter Custom Department *"
                    placeholder="e.g. Centre for AI & Robotics"
                    value={customDepartment}
                    onChange={(e) => setCustomDepartment(e.target.value)}
                    required
                  />
                </div>
              ) : (
                <div>
                  <Input
                    id="emp-joining"
                    label="Joining Date *"
                    type="date"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    startIcon={<Calendar className="w-4 h-4" />}
                    required
                  />
                </div>
              )}

              {department === 'Custom' && (
                <div>
                  <Input
                    id="emp-joining-custom"
                    label="Joining Date *"
                    type="date"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    startIcon={<Calendar className="w-4 h-4" />}
                    required
                  />
                </div>
              )}

              <div className="text-left space-y-1.5">
                <label htmlFor="emp-status" className="block text-[13px] font-semibold text-[#1e293b]">
                  Employment Status *
                </label>
                <select
                  id="emp-status"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                  className="block w-full rounded-md border border-[#e2e8f0] bg-white text-[#1e293b] text-sm py-2.5 px-3 font-semibold focus:border-[#1e3a8a] focus:ring-1 focus:ring-[#1e3a8a] outline-none"
                >
                  <option value="active">Active (Access Granted)</option>
                  <option value="inactive">Inactive (Access Suspended)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-[#e2e8f0] flex items-center justify-end gap-3">
            <Button type="button" variant="outline" size="md" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="md"
              isLoading={isSubmitting}
              leftIcon={isEditing ? <Edit className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            >
              {isEditing ? 'Save Changes' : 'Create Account & Generate Password'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
