import React, { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { HostelWorkspace } from './hostel/HostelWorkspace';
import { UserSession } from '../types/auth';

interface HostelOfficeSectionProps {
  onRefreshData?: () => Promise<void> | void;
  embedded?: boolean;
}

export function HostelOfficeSection({ onRefreshData, embedded }: HostelOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'Hostel Warden';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-006',
      username: session?.user?.username || 'hosteloffice',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'hostel@eit.edu',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'Hostel Administration Warden',
      department: emp?.primary_department || 'HOSTEL',
      portalType: 'employee',
      employeeId: emp?.registration_number || 'HST-001',
      permanentOffice: session?.permanentOffice || {
        office_id: 'PO-006',
        office_name: 'Hostel Office',
        canonical_username: 'hosteloffice',
        office_code: 'HOS',
        is_system_reserved: true,
        primary_contact_email: 'hostel@eit.edu',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    };
  }, [session]);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <HostelWorkspace
      user={userSession}
      onLogout={handleLogout}
      onRefresh={onRefreshData}
    />
  );
}
