import React, { useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { AdmissionWorkspace } from './admission/AdmissionWorkspace';
import { UserSession } from '../types/auth';

interface AdmissionsOfficeSectionProps {
  onRefreshData?: () => Promise<void>;
  embedded?: boolean;
}

export function AdmissionsOfficeSection({ onRefreshData, embedded }: AdmissionsOfficeSectionProps) {
  const { session, logout } = useAuth();

  const userSession: UserSession = useMemo(() => {
    const emp = session?.employeeProfile;
    const name = emp
      ? `${emp.first_name} ${emp.last_name}`
      : session?.displayName || session?.user?.username || 'Admissions Office Admin';

    return {
      id: emp?.registration_number || session?.user?.user_id || 'PO-002',
      username: session?.user?.username || 'admissionsoffice',
      name,
      email: emp?.institutional_email || (session?.user as any)?.email || 'admissionsoffice@eit.edu',
      displayName: name,
      role: session?.role || 'OFFICE_ADMIN',
      employeeRole: session?.role === 'SUPER_ADMIN' ? 'super_admin' : 'office_admin',
      roleTitle: session?.role === 'SUPER_ADMIN' ? 'Super Administrator' : 'Admissions Officer',
      department: emp?.primary_department || 'ADMISSIONS',
      portalType: 'employee',
    };
  }, [session]);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <AdmissionWorkspace
      user={userSession}
      onLogout={handleLogout}
      onRefreshData={onRefreshData}
      embedded={embedded}
    />
  );
}
