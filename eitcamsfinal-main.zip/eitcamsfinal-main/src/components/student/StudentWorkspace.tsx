import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  GraduationCap,
  LayoutDashboard,
  User,
  BookOpen,
  CalendarCheck,
  DollarSign,
  Receipt,
  CreditCard,
  Award,
  FileText,
  LogOut,
  Menu,
  X,
  ShieldCheck,
  Bell,
  Clock,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Users,
  MessageSquare,
  Layers,
  HelpCircle,
  Calendar,
  RotateCcw,
  Monitor,
  Building,
  FileSearch,
  History,
  AlertTriangle,
  FileWarning,
  FilePlus,
  UserCheck,
  KeyRound,
  FileCheck,
  Landmark,
  Fingerprint,
  Sparkles,
  Briefcase,
  Scroll,
  Moon,
  Droplet,
  Bus,
  Home,
  Building2,
  Lock,
  LifeBuoy,
  Settings,
} from 'lucide-react';
import { UserSession } from '../../types/auth';
import { Student } from '../../types/admission';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  AttendanceRecord,
  FacultyAssignment,
} from '../../types/academic';
import { FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
  StudentSubjectMark,
} from '../../types/examination';
import { Employee } from '../../types/employee';
import { admissionRepository } from '../../services/admissionService';
import { academicRepository } from '../../services/academicService';
import { financeRepository } from '../../services/financeService';
import { examinationRepository } from '../../services/examinationService';
import { employeeRepository } from '../../services/employeeService';
import { proctorRepository } from '../../services/proctorService';
import { ProctorAssignment } from '../../types/proctor';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

import { StudentOverview } from './StudentOverview';
import { StudentProfileView } from './StudentProfileView';
import { StudentAcademicsView } from './StudentAcademicsView';
import { StudentAttendanceView } from './StudentAttendanceView';
import { StudentFeesView } from './StudentFeesView';
import { StudentReceiptsView } from './StudentReceiptsView';
import { StudentExaminationsView } from './StudentExaminationsView';
import { StudentHallTicketsView } from './StudentHallTicketsView';
import { StudentResultsView } from './StudentResultsView';

// My Info Expansion Sub-Views
import { StudentCredentialsView } from './myInfo/StudentCredentialsView';
import { StudentAcknowledgementView } from './myInfo/StudentAcknowledgementView';
import { StudentBankInfoView } from './myInfo/StudentBankInfoView';
import { StudentAaparUploadView } from './myInfo/StudentAaparUploadView';
import { StudentDigitalIdCardView } from './myInfo/StudentDigitalIdCardView';
import { StudentItSupportView } from './StudentItSupportView';

// Info Corner Sub-Views
import { StudentFaqView } from './infoCorner/StudentFaqView';
import { StudentSpotlightView } from './infoCorner/StudentSpotlightView';
import { StudentGeneralInfoView } from './infoCorner/StudentGeneralInfoView';

// Proctor Sub-Views
import { StudentProctorDetailsView } from './proctor/StudentProctorDetailsView';
import { StudentProctorMessagesView } from './proctor/StudentProctorMessagesView';

// Academics Expansion Sub-Views
import { StudentFacultyInfoView } from './academics/StudentFacultyInfoView';
import { StudentClassMessagesView } from './academics/StudentClassMessagesView';
import { StudentCurriculumView } from './academics/StudentCurriculumView';
import { StudentTimeTableView } from './academics/StudentTimeTableView';
import { StudentCoursePageView } from './academics/StudentCoursePageView';
import { StudentQCMView } from './academics/StudentQCMView';
import { StudentAcademicCalendarView } from './academics/StudentAcademicCalendarView';
import { StudentCourseWithdrawView } from './academics/StudentCourseWithdrawView';

// Examination Expansion Sub-Views
import { StudentExamScheduleView } from './examination/StudentExamScheduleView';
import { StudentOnlineExamScheduleView } from './examination/StudentOnlineExamScheduleView';
import { StudentOfflineExamScheduleView } from './examination/StudentOfflineExamScheduleView';
import { StudentMarksView } from './examination/StudentMarksView';
import { StudentGradesView } from './examination/StudentGradesView';
import { StudentPaperSeeRevView } from './examination/StudentPaperSeeRevView';
import { StudentGradeHistoryView } from './examination/StudentGradeHistoryView';
import { StudentArrearDetailsView } from './examination/StudentArrearDetailsView';
import { StudentReFatDetailsView } from './examination/StudentReFatDetailsView';
import { StudentReExamApplicationView } from './examination/StudentReExamApplicationView';
import { StudentSupplementaryRegistrationView } from './examination/StudentSupplementaryRegistrationView';

// Services Sub-Views
import { StudentPatRegistrationView } from './services/StudentPatRegistrationView';
import { StudentTranscriptRequestView } from './services/StudentTranscriptRequestView';
import { StudentLateHourRequestView } from './services/StudentLateHourRequestView';
import { StudentWaterFacilityView } from './services/StudentWaterFacilityView';
import { StudentTransportFacilityView } from './services/StudentTransportFacilityView';

// Bonafide Sub-Views
import { StudentBonafideView } from './bonafide/StudentBonafideView';

// Online Payments Sub-Views
import { StudentPaymentsView } from './finance/StudentPaymentsView';
import { StudentFeeIntimationView } from './finance/StudentFeeIntimationView';
import { StudentHostelFeeIntimationView } from './finance/StudentHostelFeeIntimationView';

// Convocation Sub-Views
import { StudentConvocationView } from './convocation/StudentConvocationView';

// Hostels Sub-Views
import { StudentHostelLeaveRequestView } from './hostels/StudentHostelLeaveRequestView';
import { StudentHostelLeaveHistoryView } from './hostels/StudentHostelLeaveHistoryView';
import { StudentHostelBiometricView } from './hostels/StudentHostelBiometricView';
import { StudentHostelRoomAllotmentView } from './hostels/StudentHostelRoomAllotmentView';
import { StudentHostelRoomMasterView } from './hostels/StudentHostelRoomMasterView';

// My Account Sub-Views
import { StudentChangePasswordView } from './account/StudentChangePasswordView';

import { ReceiptPreviewModal } from './modals/ReceiptPreviewModal';
import { HallTicketPrintModal } from './modals/HallTicketPrintModal';
import { ResultTranscriptModal } from './modals/ResultTranscriptModal';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface StudentWorkspaceProps {
  user: UserSession;
  onLogout: () => void;
}

export type StudentTab =
  | 'overview'
  // My Info
  | 'my-info-profile'
  | 'my-info-id-card'
  | 'my-info-credentials'
  | 'my-info-acknowledgement'
  | 'my-info-bank-info'
  | 'my-info-aapar'
  | 'profile'
  // Info Corner
  | 'info-faq'
  | 'info-spotlight'
  | 'info-general'
  // Proctor
  | 'proctor-details'
  | 'proctor-messages'
  // Academics
  | 'academics'
  | 'academics-faculty'
  | 'academics-messages'
  | 'academics-curriculum'
  | 'academics-timetable'
  | 'academics-attendance'
  | 'academics-course-page'
  | 'academics-qcm'
  | 'academics-calendar'
  | 'academics-withdraw'
  | 'attendance'
  // Examination
  | 'examinations'
  | 'hall-tickets'
  | 'results'
  | 'exam-schedule'
  | 'exam-online-schedule'
  | 'exam-offline-schedule'
  | 'exam-marks'
  | 'exam-grades'
  | 'exam-paper-see-rev'
  | 'exam-grade-history'
  | 'exam-arrears'
  | 'exam-refat'
  | 'exam-re-exam'
  | 'exam-supplementary'
  // Services
  | 'services-pat'
  | 'services-transcript'
  | 'services-late-hour'
  | 'services-water'
  | 'services-transport'
  // Bonafide
  | 'bonafide-apply'
  // Online Payments
  | 'payments'
  | 'payments-receipts'
  | 'payments-fees-intimation'
  | 'payments-hostel-fees-intimation'
  | 'fees'
  | 'receipts'
  | 'finance'
  | 'finance-fees'
  | 'finance-payments'
  | 'finance-receipts'
  | 'finance-fee-intimation'
  | 'finance-hostel-fee-intimation'
  // Convocation
  | 'convocation-register'
  // Hostels
  | 'hostels-leave-request'
  | 'hostels-leave-history'
  | 'hostels-biometric'
  | 'hostels-room-allotment'
  | 'hostels-room-master'
  // My Account
  | 'account-change-password'
  | 'account-it-support';

/**
 * Resolves the parent accordion group for any given StudentTab.
 */
export function getParentGroupForStudentTab(tab: string): string | null {
  if (tab.startsWith('my-info-') || tab === 'profile') return 'my-info';
  if (tab.startsWith('info-')) return 'info-corner';
  if (tab.startsWith('proctor-')) return 'proctor';
  if (tab === 'academics' || tab.startsWith('academics-') || tab === 'attendance') return 'academics';
  if (
    tab === 'examinations' ||
    tab === 'hall-tickets' ||
    tab === 'results' ||
    tab.startsWith('exam-')
  ) {
    return 'examination';
  }
  if (tab.startsWith('services-')) return 'services';
  if (tab.startsWith('bonafide-')) return 'bonafide';
  if (
    tab === 'payments' ||
    tab.startsWith('payments-') ||
    tab.startsWith('finance') ||
    tab === 'fees' ||
    tab === 'receipts'
  ) {
    return 'online-payments';
  }
  if (tab.startsWith('convocation-')) return 'convocation';
  if (tab.startsWith('hostels-')) return 'hostels';
  if (tab.startsWith('account-')) return 'my-account';
  return null;
}

export function StudentWorkspace({ user, onLogout }: StudentWorkspaceProps) {
  const { activeAcademicYear } = useActiveAcademicYear();
  // Default to My Info Profile landing
  const [activeTab, setActiveTab] = useState<StudentTab>('my-info-profile');
  const [isLoading, setIsLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // STRICT SINGLE-EXPANSION ACCORDION: exactly ONE primary group can be expanded at any time
  const [expandedMenuId, setExpandedMenuId] = useState<string | null>(() =>
    getParentGroupForStudentTab('my-info-profile')
  );
  const prevActiveTabRef = useRef<string>(activeTab);

  // Nested Arrear/ReFAT sub-toggle within Examination
  const [isArrearReFatOpen, setIsArrearReFatOpen] = useState(() =>
    activeTab === 'exam-arrears' || activeTab === 'exam-refat'
  );

  // On refresh or when activeTab switches, expand the parent group if appropriate
  useEffect(() => {
    if (prevActiveTabRef.current !== activeTab) {
      prevActiveTabRef.current = activeTab;
      const parentGroup = getParentGroupForStudentTab(activeTab);
      if (parentGroup) {
        setExpandedMenuId(parentGroup);
      }
      if (activeTab === 'exam-arrears' || activeTab === 'exam-refat') {
        setIsArrearReFatOpen(true);
      }
    }
  }, [activeTab]);

  const toggleGroup = (groupId: string) => {
    setExpandedMenuId((current) => (current === groupId ? null : groupId));
  };

  const isMyInfoOpen = expandedMenuId === 'my-info';
  const isInfoCornerOpen = expandedMenuId === 'info-corner';
  const isProctorOpen = expandedMenuId === 'proctor';
  const isAcademicsOpen = expandedMenuId === 'academics';
  const isExaminationOpen = expandedMenuId === 'examination';
  const isServicesOpen = expandedMenuId === 'services';
  const isBonafideOpen = expandedMenuId === 'bonafide';
  const isOnlinePaymentsOpen = expandedMenuId === 'online-payments';
  const isConvocationOpen = expandedMenuId === 'convocation';
  const isHostelsOpen = expandedMenuId === 'hostels';
  const isMyAccountOpen = expandedMenuId === 'my-account';

  // Authenticated Student entity
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);

  // Academic data
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<AcademicClass[]>([]);
  const [sections, setSections] = useState<AcademicSection[]>([]);
  const [subjects, setSubjects] = useState<AcademicSubject[]>([]);
  const [facultyAssignments, setFacultyAssignments] = useState<FacultyAssignment[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);

  // Filtered Student-specific data
  const [myAttendance, setMyAttendance] = useState<AttendanceRecord[]>([]);
  const [myFeeAssignments, setMyFeeAssignments] = useState<FeeAssignment[]>([]);
  const [myPayments, setMyPayments] = useState<PaymentRecord[]>([]);
  const [myReceipts, setMyReceipts] = useState<FeeReceipt[]>([]);
  const [activeProctorAssignment, setActiveProctorAssignment] = useState<ProctorAssignment | null>(null);

  // Examination data
  const [examinations, setExaminations] = useState<Examination[]>([]);
  const [schedules, setSchedules] = useState<ExamSubjectSchedule[]>([]);
  const [myHallTickets, setMyHallTickets] = useState<HallTicket[]>([]);
  const [myResults, setMyResults] = useState<StudentExamResult[]>([]);
  const [myMarks, setMyMarks] = useState<StudentSubjectMark[]>([]);

  // Modals state
  const [selectedReceipt, setSelectedReceipt] = useState<FeeReceipt | null>(null);
  const [selectedHallTicket, setSelectedHallTicket] = useState<HallTicket | null>(null);
  const [selectedResult, setSelectedResult] = useState<StudentExamResult | null>(null);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      // 1. Locate authenticated student record
      const uUsername = (user.username || '').trim();
      const uId = (user.id || '').trim();
      const uEmail = (user.email || '').trim();

      // If all identity markers are empty, strictly reject without matching any student record
      if (!uUsername && !uId && !uEmail) {
        setCurrentStudent(null);
        setMyAttendance([]);
        setMyFeeAssignments([]);
        setMyPayments([]);
        setMyReceipts([]);
        setMyHallTickets([]);
        setMyResults([]);
        setMyMarks([]);
        setActiveProctorAssignment(null);
        setIsLoading(false);
        return;
      }

      const allStudents = await admissionRepository.getAll();
      const userIdentClean = uUsername.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const userIdClean = uId.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const userEmailClean = uEmail.toLowerCase();

      const matchedStudent = allStudents.find((s) => {
        const regClean = (s.registrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        const emailClean = (s.email || '').toLowerCase().trim();
        const idClean = (s.id || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
        const sReg = (s.registrationNumber || '').trim();

        return (
          (regClean && userIdentClean && regClean === userIdentClean) ||
          (userEmailClean && emailClean && emailClean === userEmailClean) ||
          (idClean && userIdClean && idClean === userIdClean) ||
          (regClean && userIdClean && regClean === userIdClean) ||
          (idClean && userIdentClean && idClean === userIdentClean) ||
          (uUsername && sReg && sReg === uUsername)
        );
      }) || null;

      setCurrentStudent(matchedStudent);

      if (matchedStudent) {
        const studentRegNorm = (matchedStudent.registrationNumber || '')
          .replace(/[^a-zA-Z0-9]/g, '')
          .toLowerCase();

        // 2. Fetch all academic, financial, exam, and employee records in parallel
        const [
          sessionsData,
          classesData,
          sectionsData,
          subjectsData,
          assignmentsData,
          allAttendance,
          allFeeAssignments,
          allPayments,
          allReceipts,
          allExams,
          allSchedules,
          allHallTickets,
          allResults,
          allMarks,
          allEmployees,
        ] = await Promise.all([
          academicRepository.getSessions(),
          academicRepository.getClasses(),
          academicRepository.getSections(),
          academicRepository.getSubjects(),
          academicRepository.getFacultyAssignments(),
          academicRepository.getAttendanceRecords(),
          financeRepository.getFeeAssignments(),
          financeRepository.getPayments(),
          financeRepository.getReceipts(),
          examinationRepository.getExaminations(),
          examinationRepository.getSchedules(),
          examinationRepository.getHallTickets(),
          examinationRepository.getResults(),
          examinationRepository.getAllMarks(),
          employeeRepository.getAll(),
        ]);

        setSessions(sessionsData);
        setClasses(classesData);
        setSections(sectionsData);
        setSubjects(subjectsData);
        setFacultyAssignments(assignmentsData);
        setEmployees(allEmployees);

        // Filter Attendance strictly for this student
        const studentAtt = allAttendance.filter((a: any) => {
          const aReg = ((a as any).registrationNumber || a.registration_number || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return aReg === studentRegNorm || a.registration_number === matchedStudent.registrationNumber || (a as any).registrationNumber === matchedStudent.registrationNumber;
        });
        setMyAttendance(studentAtt as AttendanceRecord[]);

        // Filter Fee Assignments strictly for this student
        const studentFees = allFeeAssignments.filter((f: any) => {
          const fReg = (f.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return fReg === studentRegNorm || f.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyFeeAssignments(studentFees);

        // Filter Payments strictly for this student
        const studentPayments = allPayments.filter((p: any) => {
          const pReg = (p.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return pReg === studentRegNorm || p.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyPayments(studentPayments);

        // Filter Receipts strictly for this student
        const studentReceipts = allReceipts.filter((r: any) => {
          const rReg = (r.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return rReg === studentRegNorm || r.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyReceipts(studentReceipts);

        // Set all examinations & schedules
        setExaminations(allExams);
        setSchedules(allSchedules);

        // Filter Hall Tickets strictly for this student
        const studentHt = allHallTickets.filter((ht: any) => {
          const htReg = (ht.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return htReg === studentRegNorm || ht.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyHallTickets(studentHt);

        // Filter Results strictly for this student
        const studentRes = allResults.filter((res: any) => {
          const resReg = (res.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return resReg === studentRegNorm || res.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyResults(studentRes);

        // Filter Marks strictly for this student
        const studentMks = allMarks.filter((mk: any) => {
          const mkReg = (mk.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
          return mkReg === studentRegNorm || mk.studentRegistrationNumber === matchedStudent.registrationNumber;
        });
        setMyMarks(studentMks);

        // Load active Proctor assignment for this student
        const proctorAsg = await proctorRepository.getActiveAssignmentForStudent(
          matchedStudent.id || matchedStudent.registrationNumber
        );
        setActiveProctorAssignment(proctorAsg);
      } else {
        // Enforce strict identity isolation: clear all student-scoped state
        setMyAttendance([]);
        setMyFeeAssignments([]);
        setMyPayments([]);
        setMyReceipts([]);
        setMyHallTickets([]);
        setMyResults([]);
        setMyMarks([]);
        setActiveProctorAssignment(null);
      }
    } catch (err) {
      console.error('Failed to load student portal data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (!currentStudent) return;
    const unsub = proctorRepository.subscribe(() => {
      proctorRepository
        .getActiveAssignmentForStudent(currentStudent.id || currentStudent.registrationNumber)
        .then(setActiveProctorAssignment);
    });
    return unsub;
  }, [currentStudent?.id, currentStudent?.registrationNumber]);

  const currentSession = sessions.find((s) => s.isCurrent) || sessions[0] || null;

  // Resolve Proctor for this student:
  // 1. Primary: Direct official Proctor Assignment (Academic Office)
  // 2. Secondary fallback: Section's designated class teacher
  const matchedSection = sections.find(
    (s) => s.name === currentStudent?.section || s.id === currentStudent?.section
  );
  const fallbackProctorId = matchedSection?.classTeacherId;
  const effectiveProctorId = activeProctorAssignment?.facultyId || fallbackProctorId;

  const proctorEmployee = effectiveProctorId
    ? employees.find((e) => e.id === effectiveProctorId) ||
      (activeProctorAssignment
        ? ({
            id: activeProctorAssignment.facultyId,
            employeeId: activeProctorAssignment.facultyId,
            fullName: activeProctorAssignment.facultyName,
            email: activeProctorAssignment.facultyEmail,
            mobile: activeProctorAssignment.facultyPhone,
            department: activeProctorAssignment.facultyDepartment,
            designation: 'Faculty Proctor',
            roles: ['FACULTY'],
            status: 'ACTIVE',
            isTeachingStaff: true,
          } as unknown as Employee)
        : null)
    : null;

  // 1. My Info Sub-items
  const myInfoSubItems = [
    { id: 'my-info-profile', label: 'Profile', icon: User },
    { id: 'my-info-id-card', label: 'Digital ID Card', icon: CreditCard },
    { id: 'my-info-credentials', label: 'Credentials', icon: KeyRound },
    { id: 'my-info-acknowledgement', label: 'Acknowledgement View', icon: FileCheck },
    { id: 'my-info-bank-info', label: 'Student Bank Info', icon: Landmark },
    { id: 'my-info-aapar', label: 'AAPAR ID Upload', icon: Fingerprint },
  ];

  // 2. Info Corner Sub-items
  const infoCornerSubItems = [
    { id: 'info-faq', label: 'FAQ', icon: HelpCircle },
    { id: 'info-spotlight', label: 'Spotlight', icon: Sparkles },
    { id: 'info-general', label: 'General', icon: BookOpen },
  ];

  // 3. Proctor Sub-items
  const proctorSubItems = [
    { id: 'proctor-details', label: 'Proctor Details', icon: UserCheck },
    { id: 'proctor-messages', label: 'Proctor Message', icon: MessageSquare },
  ];

  // 4. Academics Sub-items
  const academicsSubItems = [
    { id: 'academics-faculty', label: 'Faculty Info', icon: Users },
    { id: 'academics-messages', label: 'Class Messages', icon: MessageSquare },
    { id: 'academics-curriculum', label: 'My Curriculum', icon: BookOpen },
    { id: 'academics-timetable', label: 'Time Table', icon: Clock },
    { id: 'academics-attendance', label: 'Class Attendance', icon: CalendarCheck, count: myAttendance.length },
    { id: 'academics-course-page', label: 'Course Page', icon: Layers },
    { id: 'academics-qcm', label: 'QCM View', icon: HelpCircle },
    { id: 'academics-calendar', label: 'Academics Calendar', icon: Calendar },
    { id: 'academics-withdraw', label: 'Course Withdraw', icon: RotateCcw },
  ];

  // 5. Examination Sub-items
  const examinationSubItems = [
    { id: 'exam-schedule', label: 'Exam Schedule', icon: Calendar },
    { id: 'exam-online-schedule', label: 'Online Exam Schedule', icon: Monitor },
    { id: 'exam-offline-schedule', label: 'Offline Exam Schedule', icon: Building },
    { id: 'exam-marks', label: 'Marks', icon: FileText },
    { id: 'exam-grades', label: 'Grades', icon: Award },
    { id: 'exam-paper-see-rev', label: 'Paper See/Rev', icon: FileSearch },
    { id: 'exam-grade-history', label: 'Grade History', icon: History },
    { id: 'exam-arrear-refat-group', label: 'Arrear/ReFAT Details', icon: AlertTriangle },
    { id: 'exam-re-exam', label: 'Re-Exam Application', icon: FilePlus },
    { id: 'exam-supplementary', label: 'Supplementary Registration', icon: UserCheck },
  ];

  // 7. Services Sub-items
  const servicesSubItems = [
    { id: 'services-pat', label: 'PAT Registration', icon: Briefcase },
    { id: 'services-transcript', label: 'Transcript Request', icon: Scroll },
    { id: 'services-late-hour', label: 'Late Hour Request', icon: Moon },
    { id: 'services-water', label: 'Water Facility', icon: Droplet },
    { id: 'services-transport', label: 'Transport Facility', icon: Bus },
  ];

  // 8. Bonafide Sub-items
  const bonafideSubItems = [
    { id: 'bonafide-apply', label: 'Apply Bonafide', icon: FileCheck },
  ];

  // 9. Online Payments Sub-items
  const onlinePaymentsSubItems = [
    { id: 'payments', label: 'Payments', icon: CreditCard, count: myPayments.length },
    { id: 'payments-receipts', label: 'Payment Receipts', icon: Receipt, count: myReceipts.length },
    { id: 'payments-fees-intimation', label: 'Fees Intimation', icon: Bell },
    { id: 'payments-hostel-fees-intimation', label: 'Hostel Fees Intimation', icon: Building },
  ];

  // 10. Convocation Sub-items
  const convocationSubItems = [
    { id: 'convocation-register', label: 'Convocation Registration', icon: GraduationCap },
  ];

  // 11. Hostels Sub-items
  const hostelsSubItems = [
    { id: 'hostels-leave-request', label: 'Leave Request', icon: LogOut },
    { id: 'hostels-leave-history', label: 'Leave History', icon: History },
    { id: 'hostels-biometric', label: 'Biometric Report', icon: Fingerprint },
    { id: 'hostels-room-allotment', label: 'Hostel Room Allotment', icon: Home },
    { id: 'hostels-room-master', label: 'Hostel Room Master', icon: Building2 },
  ];

  // 12. My Account Sub-items
  const myAccountSubItems = [
    { id: 'account-change-password', label: 'Change Password', icon: Lock },
    { id: 'account-it-support', label: 'IT Support & Tickets', icon: LifeBuoy },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center shadow-md animate-pulse">
          <GraduationCap className="w-6 h-6" />
        </div>
        <p className="text-sm font-semibold text-[#1e293b] mt-4">Loading Student Portal...</p>
        <p className="text-xs text-[#64748b] mt-1">Retrieving academic profile and records</p>
      </div>
    );
  }

  if (!currentStudent) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex flex-col">
        <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                    Student Portal
                  </span>
                  <span className="text-[11px] text-[#64748b] font-medium">
                    Electrix Institute of Technology
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={onLogout}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md border border-rose-200 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            </div>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center p-6">
          <div className="bg-white rounded-xl border border-rose-200 shadow-xs p-8 max-w-lg w-full text-center space-y-4">
            <div className="w-14 h-14 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#1e293b]">Student Profile Not Found</h2>
              <p className="text-xs text-[#475569] mt-2 leading-relaxed">
                No verified student enrollment record could be resolved for the authenticated account (<span className="font-mono font-semibold text-[#1e293b]">{user.username}</span>).
              </p>
              <p className="text-[11px] text-[#64748b] mt-2 leading-relaxed">
                To protect student data confidentiality, academic records, examination schedules, fee ledgers, and hostel allocations cannot be loaded. If you are an active student, please contact the Academic Office or System Administrator.
              </p>
            </div>
            <div className="pt-2 flex justify-center">
              <button
                type="button"
                onClick={onLogout}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors border border-rose-200 cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col">
      {/* Top Application Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#e2e8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left: Brand & Portal Badge */}
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-md bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="text-[17px] font-bold tracking-tight text-[#1e293b] leading-tight">
                    Student Portal
                  </span>
                  <span className="hidden sm:inline-block text-[11px] font-semibold text-[#1e3a8a] bg-[#eff6ff] px-2 py-0.5 rounded border border-[#bfdbfe]">
                    {currentStudent.admissionClass} - Sec {currentStudent.section}
                  </span>
                  <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    <Calendar className="w-3 h-3 text-emerald-700" />
                    <span>AY {activeAcademicYear || '2026–2027'}</span>
                  </span>
                </div>
                <span className="text-[11px] text-[#64748b] font-medium hidden md:inline">
                  Academic & Student Self-Service Gateway
                </span>
              </div>
            </div>

            {/* Right: Student Badge & Logout */}
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-[#e2e8f0]">
                <div className="w-7 h-7 rounded-full bg-[#f1f5f9] border border-[#e2e8f0] flex items-center justify-center text-[#1e293b]">
                  <User className="w-3.5 h-3.5" />
                </div>
                <div className="text-left leading-none">
                  <p className="text-[13px] font-semibold text-[#1e293b]">{currentStudent.fullName}</p>
                  <p className="text-[11px] text-[#64748b] font-mono mt-0.5">{currentStudent.registrationNumber}</p>
                </div>
              </div>

              <Badge variant="blue" size="sm" className="hidden md:inline-flex capitalize">
                Student
              </Badge>

              <Button
                id="student-header-logout-btn"
                variant="danger"
                size="sm"
                onClick={onLogout}
                leftIcon={<LogOut className="w-3.5 h-3.5" />}
              >
                Logout
              </Button>

              {/* Mobile menu button */}
              <button
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 rounded-lg text-[#64748b] hover:text-[#1e293b] hover:bg-slate-100 cursor-pointer"
                aria-label="Toggle navigation menu"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout (Sidebar + Content) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col lg:flex-row gap-6">
        {/* Sidebar Navigation */}
        <aside
          className={`lg:w-64 shrink-0 ${
            isMobileMenuOpen ? 'block' : 'hidden lg:block'
          }`}
        >
          <nav className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-3 space-y-1 sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto">
            {/* 1. My Info ▸ */}
            {(() => {
              const isAnyMyInfoActive =
                activeTab.startsWith('my-info-') || activeTab === 'profile';
              return (
                <div key="my-info-group" className="space-y-1">
                  <button
                    id="student-nav-my-info"
                    type="button"
                    onClick={() => toggleGroup('my-info')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyMyInfoActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isMyInfoOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <User className={`w-4 h-4 ${isAnyMyInfoActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>My Info</span>
                    </div>
                    {isMyInfoOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isMyInfoOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {myInfoSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive =
                          activeTab === sub.id ||
                          (sub.id === 'my-info-profile' && activeTab === 'profile');
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 2. Info Corner ▸ */}
            {(() => {
              const isAnyInfoCornerActive = activeTab.startsWith('info-');
              return (
                <div key="info-corner-group" className="space-y-1">
                  <button
                    id="student-nav-info-corner"
                    type="button"
                    onClick={() => toggleGroup('info-corner')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyInfoCornerActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isInfoCornerOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <HelpCircle className={`w-4 h-4 ${isAnyInfoCornerActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Info Corner</span>
                    </div>
                    {isInfoCornerOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isInfoCornerOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {infoCornerSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 3. Proctor ▸ */}
            {(() => {
              const isAnyProctorActive = activeTab.startsWith('proctor-');
              return (
                <div key="proctor-group" className="space-y-1">
                  <button
                    id="student-nav-proctor"
                    type="button"
                    onClick={() => toggleGroup('proctor')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyProctorActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isProctorOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <UserCheck className={`w-4 h-4 ${isAnyProctorActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Proctor</span>
                    </div>
                    {isProctorOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isProctorOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {proctorSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 4. Academics ▸ */}
            {(() => {
              const isAnyAcademicsActive =
                activeTab === 'academics' ||
                activeTab.startsWith('academics-') ||
                activeTab === 'attendance';
              return (
                <div key="academics-group" className="space-y-1">
                  <button
                    id="student-nav-academics"
                    type="button"
                    onClick={() => toggleGroup('academics')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyAcademicsActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isAcademicsOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <BookOpen className={`w-4 h-4 ${isAnyAcademicsActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Academics</span>
                    </div>
                    {isAcademicsOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isAcademicsOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {academicsSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive =
                          activeTab === sub.id ||
                          (sub.id === 'academics-attendance' && activeTab === 'attendance');
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                            {sub.count !== undefined && sub.count > 0 && (
                              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-100 text-[#475569]">
                                {sub.count}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 5. Examination ▸ */}
            {(() => {
              const isAnyExamActive =
                activeTab === 'examinations' ||
                activeTab === 'hall-tickets' ||
                activeTab === 'results' ||
                activeTab.startsWith('exam-');
              return (
                <div key="examination-group" className="space-y-1">
                  <button
                    id="student-nav-examination"
                    type="button"
                    onClick={() => toggleGroup('examination')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyExamActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isExaminationOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <Award className={`w-4 h-4 ${isAnyExamActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Examination</span>
                    </div>
                    {isExaminationOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isExaminationOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {examinationSubItems.map((sub) => {
                        if (sub.id === 'exam-arrear-refat-group') {
                          const isArrearChildActive =
                            activeTab === 'exam-arrears' || activeTab === 'exam-refat';
                          return (
                            <div key="arrear-refat-nested-group" className="space-y-0.5">
                              <button
                                id="student-nav-arrear-refat-toggle"
                                type="button"
                                onClick={() => setIsArrearReFatOpen(!isArrearReFatOpen)}
                                className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                                  isArrearChildActive
                                    ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold'
                                    : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                                }`}
                                aria-expanded={isArrearReFatOpen}
                              >
                                <div className="flex items-center gap-2">
                                  <AlertTriangle
                                    className={`w-3.5 h-3.5 ${
                                      isArrearChildActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'
                                    }`}
                                  />
                                  <span>Arrear/ReFAT Details</span>
                                </div>
                                {isArrearReFatOpen ? (
                                  <ChevronDown className="w-3.5 h-3.5 text-[#64748b]" />
                                ) : (
                                  <ChevronRight className="w-3.5 h-3.5 text-[#64748b]" />
                                )}
                              </button>

                              {isArrearReFatOpen && (
                                <div className="pl-3 space-y-0.5 border-l-2 border-slate-200 ml-3 my-0.5">
                                  <button
                                    id="student-nav-exam-arrears"
                                    type="button"
                                    onClick={() => {
                                      setActiveTab('exam-arrears');
                                      setIsMobileMenuOpen(false);
                                    }}
                                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
                                      activeTab === 'exam-arrears'
                                        ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a]'
                                        : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                                    }`}
                                  >
                                    <FileWarning
                                      className={`w-3 h-3 ${
                                        activeTab === 'exam-arrears' ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'
                                      }`}
                                    />
                                    <span>Arrear Details</span>
                                  </button>

                                  <button
                                    id="student-nav-exam-refat"
                                    type="button"
                                    onClick={() => {
                                      setActiveTab('exam-refat');
                                      setIsMobileMenuOpen(false);
                                    }}
                                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md text-xs transition-all cursor-pointer ${
                                      activeTab === 'exam-refat'
                                        ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a]'
                                        : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                                    }`}
                                  >
                                    <RotateCcw
                                      className={`w-3 h-3 ${
                                        activeTab === 'exam-refat' ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'
                                      }`}
                                    />
                                    <span>ReFAT Details</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        }

                        const SubIcon = sub.icon;
                        const isSubActive =
                          activeTab === sub.id ||
                          (sub.id === 'exam-schedule' && activeTab === 'examinations') ||
                          (sub.id === 'exam-grades' && activeTab === 'results');

                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 6. Services ▸ */}
            {(() => {
              const isAnyServicesActive = activeTab.startsWith('services-');
              return (
                <div key="services-group" className="space-y-1">
                  <button
                    id="student-nav-services"
                    type="button"
                    onClick={() => toggleGroup('services')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyServicesActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isServicesOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <Briefcase className={`w-4 h-4 ${isAnyServicesActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Services</span>
                    </div>
                    {isServicesOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isServicesOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {servicesSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 8. Bonafide ▸ */}
            {(() => {
              const isAnyBonafideActive = activeTab.startsWith('bonafide-');
              return (
                <div key="bonafide-group" className="space-y-1">
                  <button
                    id="student-nav-bonafide"
                    type="button"
                    onClick={() => toggleGroup('bonafide')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyBonafideActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isBonafideOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <FileCheck className={`w-4 h-4 ${isAnyBonafideActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Bonafide</span>
                    </div>
                    {isBonafideOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isBonafideOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {bonafideSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 9. Online Payments ▸ */}
            {(() => {
              const isAnyPaymentsActive =
                activeTab === 'payments' ||
                activeTab.startsWith('payments-') ||
                activeTab.startsWith('finance') ||
                activeTab === 'fees' ||
                activeTab === 'receipts';
              return (
                <div key="online-payments-group" className="space-y-1">
                  <button
                    id="student-nav-online-payments"
                    type="button"
                    onClick={() => toggleGroup('online-payments')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyPaymentsActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isOnlinePaymentsOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <CreditCard className={`w-4 h-4 ${isAnyPaymentsActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Online Payments</span>
                    </div>
                    {isOnlinePaymentsOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isOnlinePaymentsOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {onlinePaymentsSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive =
                          activeTab === sub.id ||
                          (sub.id === 'payments' && activeTab === 'finance-payments') ||
                          (sub.id === 'payments-receipts' && (activeTab === 'receipts' || activeTab === 'finance-receipts')) ||
                          (sub.id === 'payments-fees-intimation' && activeTab === 'finance-fee-intimation') ||
                          (sub.id === 'payments-hostel-fees-intimation' && activeTab === 'finance-hostel-fee-intimation');
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                            {sub.count !== undefined && sub.count > 0 && (
                              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-slate-100 text-[#475569]">
                                {sub.count}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 10. Convocation ▸ */}
            {(() => {
              const isAnyConvocationActive = activeTab.startsWith('convocation-');
              return (
                <div key="convocation-group" className="space-y-1">
                  <button
                    id="student-nav-convocation"
                    type="button"
                    onClick={() => toggleGroup('convocation')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyConvocationActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isConvocationOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <GraduationCap className={`w-4 h-4 ${isAnyConvocationActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Convocation</span>
                    </div>
                    {isConvocationOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isConvocationOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {convocationSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 11. Hostels ▸ */}
            {(() => {
              const isAnyHostelsActive = activeTab.startsWith('hostels-');
              return (
                <div key="hostels-group" className="space-y-1">
                  <button
                    id="student-nav-hostels"
                    type="button"
                    onClick={() => toggleGroup('hostels')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyHostelsActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isHostelsOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <Home className={`w-4 h-4 ${isAnyHostelsActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>Hostels</span>
                    </div>
                    {isHostelsOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isHostelsOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {hostelsSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* 12. My Account ▸ */}
            {(() => {
              const isAnyAccountActive = activeTab.startsWith('account-');
              return (
                <div key="account-group" className="space-y-1">
                  <button
                    id="student-nav-my-account"
                    type="button"
                    onClick={() => toggleGroup('my-account')}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      isAnyAccountActive
                        ? 'bg-slate-100 text-[#1e3a8a]'
                        : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                    }`}
                    aria-expanded={isMyAccountOpen}
                  >
                    <div className="flex items-center gap-2.5">
                      <Settings className={`w-4 h-4 ${isAnyAccountActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'}`} />
                      <span>My Account</span>
                    </div>
                    {isMyAccountOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </button>

                  {isMyAccountOpen && (
                    <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                      {myAccountSubItems.map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = activeTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            id={`student-nav-${sub.id}`}
                            type="button"
                            onClick={() => {
                              setActiveTab(sub.id as StudentTab);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                              isSubActive
                                ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                                : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'}`} />
                              <span>{sub.label}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}
          </nav>
        </aside>

        {/* Primary Content View */}
        <main className="flex-1 min-w-0">
          {/* Overview Dashboard */}
          {activeTab === 'overview' && (
            <StudentOverview
              student={currentStudent}
              attendanceRecords={myAttendance}
              feeAssignments={myFeeAssignments}
              payments={myPayments}
              receipts={myReceipts}
              examinations={examinations}
              schedules={schedules}
              hallTickets={myHallTickets}
              results={myResults}
              onNavigateTab={(tab) => setActiveTab(tab as StudentTab)}
              onViewReceipt={(r) => setSelectedReceipt(r)}
              onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
              onViewResult={(res) => setSelectedResult(res)}
            />
          )}

          {/* 1. My Info Views */}
          {(activeTab === 'my-info-profile' || activeTab === 'profile') && (
            <StudentProfileView student={currentStudent} />
          )}

          {activeTab === 'my-info-id-card' && (
            <StudentDigitalIdCardView student={currentStudent} />
          )}

          {activeTab === 'my-info-credentials' && (
            <StudentCredentialsView
              student={currentStudent}
              onNavigateToChangePassword={() => setActiveTab('account-change-password')}
            />
          )}

          {activeTab === 'my-info-acknowledgement' && (
            <StudentAcknowledgementView student={currentStudent} />
          )}

          {activeTab === 'my-info-bank-info' && (
            <StudentBankInfoView student={currentStudent} />
          )}

          {activeTab === 'my-info-aapar' && (
            <StudentAaparUploadView student={currentStudent} />
          )}

          {/* 2. Info Corner Views */}
          {activeTab === 'info-faq' && <StudentFaqView />}

          {activeTab === 'info-spotlight' && <StudentSpotlightView />}

          {activeTab === 'info-general' && <StudentGeneralInfoView />}

          {/* 3. Proctor Views */}
          {activeTab === 'proctor-details' && (
            <StudentProctorDetailsView
              student={currentStudent}
              proctorEmployee={proctorEmployee}
              sectionName={matchedSection?.name}
            />
          )}

          {activeTab === 'proctor-messages' && (
            <StudentProctorMessagesView
              student={currentStudent}
              proctorEmployee={proctorEmployee}
            />
          )}

          {/* 4. Academics Views */}
          {activeTab === 'academics' && (
            <StudentAcademicsView
              student={currentStudent}
              currentSession={currentSession}
              classes={classes}
              sections={sections}
              subjects={subjects}
              facultyAssignments={facultyAssignments}
            />
          )}

          {activeTab === 'academics-faculty' && (
            <StudentFacultyInfoView
              student={currentStudent}
              facultyAssignments={facultyAssignments}
            />
          )}

          {activeTab === 'academics-messages' && (
            <StudentClassMessagesView student={currentStudent} />
          )}

          {activeTab === 'academics-curriculum' && (
            <StudentCurriculumView
              student={currentStudent}
              classes={classes}
              subjects={subjects}
              results={myResults}
              examinations={examinations}
              marks={myMarks}
            />
          )}

          {activeTab === 'academics-timetable' && (
            <StudentTimeTableView student={currentStudent} />
          )}

          {(activeTab === 'attendance' || activeTab === 'academics-attendance') && (
            <StudentAttendanceView
              student={currentStudent}
              attendanceRecords={myAttendance}
            />
          )}

          {activeTab === 'academics-course-page' && (
            <StudentCoursePageView
              student={currentStudent}
              classes={classes}
              subjects={subjects}
              facultyAssignments={facultyAssignments}
            />
          )}

          {activeTab === 'academics-qcm' && <StudentQCMView student={currentStudent} />}

          {activeTab === 'academics-calendar' && (
            <StudentAcademicCalendarView
              student={currentStudent}
              sessions={sessions}
              examinations={examinations}
              schedules={schedules}
            />
          )}

          {activeTab === 'academics-withdraw' && (
            <StudentCourseWithdrawView student={currentStudent} />
          )}

          {/* 5. Examination Views */}
          {activeTab === 'examinations' && (
            <StudentExaminationsView
              student={currentStudent}
              examinations={examinations}
              schedules={schedules}
            />
          )}

          {activeTab === 'hall-tickets' && (
            <StudentHallTicketsView
              student={currentStudent}
              hallTickets={myHallTickets}
              examinations={examinations}
              onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
            />
          )}

          {activeTab === 'results' && (
            <StudentResultsView
              student={currentStudent}
              results={myResults}
              examinations={examinations}
              onViewResult={(res) => setSelectedResult(res)}
            />
          )}

          {activeTab === 'exam-schedule' && (
            <StudentExamScheduleView
              student={currentStudent}
              examinations={examinations}
              schedules={schedules}
              hallTickets={myHallTickets}
              onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
              onNavigateToHallTickets={() => setActiveTab('hall-tickets')}
            />
          )}

          {activeTab === 'exam-online-schedule' && (
            <StudentOnlineExamScheduleView
              student={currentStudent}
              examinations={examinations}
              schedules={schedules}
            />
          )}

          {activeTab === 'exam-offline-schedule' && (
            <StudentOfflineExamScheduleView
              student={currentStudent}
              examinations={examinations}
              schedules={schedules}
              hallTickets={myHallTickets}
              onViewHallTicket={(ht) => setSelectedHallTicket(ht)}
            />
          )}

          {activeTab === 'exam-marks' && (
            <StudentMarksView
              student={currentStudent}
              marks={myMarks}
              examinations={examinations}
              schedules={schedules}
              results={myResults}
            />
          )}

          {activeTab === 'exam-grades' && (
            <StudentGradesView
              student={currentStudent}
              results={myResults}
              examinations={examinations}
              subjects={subjects}
              onViewResult={(res) => setSelectedResult(res)}
            />
          )}

          {activeTab === 'exam-paper-see-rev' && (
            <StudentPaperSeeRevView student={currentStudent} examinations={examinations} />
          )}

          {activeTab === 'exam-grade-history' && (
            <StudentGradeHistoryView
              student={currentStudent}
              results={myResults}
              examinations={examinations}
              subjects={subjects}
              onViewResult={(res) => setSelectedResult(res)}
            />
          )}

          {activeTab === 'exam-arrears' && (
            <StudentArrearDetailsView
              student={currentStudent}
              results={myResults}
              examinations={examinations}
            />
          )}

          {activeTab === 'exam-refat' && (
            <StudentReFatDetailsView student={currentStudent} results={myResults} />
          )}

          {activeTab === 'exam-re-exam' && (
            <StudentReExamApplicationView student={currentStudent} />
          )}

          {activeTab === 'exam-supplementary' && (
            <StudentSupplementaryRegistrationView
              student={currentStudent}
              results={myResults}
            />
          )}

          {/* 6. Services Views */}
          {activeTab === 'services-pat' && (
            <StudentPatRegistrationView student={currentStudent} />
          )}

          {activeTab === 'services-transcript' && (
            <StudentTranscriptRequestView student={currentStudent} />
          )}

          {activeTab === 'services-late-hour' && (
            <StudentLateHourRequestView student={currentStudent} />
          )}

          {activeTab === 'services-water' && (
            <StudentWaterFacilityView student={currentStudent} />
          )}

          {activeTab === 'services-transport' && (
            <StudentTransportFacilityView student={currentStudent} />
          )}

          {/* 8. Bonafide Views */}
          {activeTab === 'bonafide-apply' && (
            <StudentBonafideView student={currentStudent} />
          )}

          {/* 9. Online Payments Views */}
          {(activeTab === 'payments' || activeTab === 'finance-payments') && (
            <StudentPaymentsView
              student={currentStudent}
              payments={myPayments}
              receipts={myReceipts}
              feeAssignments={myFeeAssignments}
              onViewReceipt={(r) => setSelectedReceipt(r)}
              onNavigateToFees={() => setActiveTab('fees')}
            />
          )}

          {(activeTab === 'payments-receipts' || activeTab === 'receipts' || activeTab === 'finance-receipts') && (
            <StudentReceiptsView
              student={currentStudent}
              receipts={myReceipts}
              payments={myPayments}
              onViewReceipt={(r) => setSelectedReceipt(r)}
            />
          )}

          {(activeTab === 'payments-fees-intimation' || activeTab === 'finance-fee-intimation') && (
            <StudentFeeIntimationView
              student={currentStudent}
              feeAssignments={myFeeAssignments}
              onNavigateToFees={() => setActiveTab('fees')}
            />
          )}

          {(activeTab === 'payments-hostel-fees-intimation' || activeTab === 'finance-hostel-fee-intimation') && (
            <StudentHostelFeeIntimationView
              student={currentStudent}
              feeAssignments={myFeeAssignments}
              onNavigateToFees={() => setActiveTab('fees')}
            />
          )}

          {(activeTab === 'fees' || activeTab === 'finance-fees' || activeTab === 'finance') && (
            <StudentFeesView
              student={currentStudent}
              feeAssignments={myFeeAssignments}
              payments={myPayments}
              receipts={myReceipts}
              onNavigateToReceipts={() => setActiveTab('payments-receipts')}
            />
          )}

          {/* 10. Convocation Views */}
          {activeTab === 'convocation-register' && (
            <StudentConvocationView student={currentStudent} />
          )}

          {/* 11. Hostels Views */}
          {activeTab === 'hostels-leave-request' && (
            <StudentHostelLeaveRequestView
              student={currentStudent}
              proctorEmployee={proctorEmployee}
              onSuccess={() => setActiveTab('hostels-leave-history')}
              onNavigateToHistory={() => setActiveTab('hostels-leave-history')}
            />
          )}

          {activeTab === 'hostels-leave-history' && (
            <StudentHostelLeaveHistoryView
              student={currentStudent}
              onNavigateToApply={() => setActiveTab('hostels-leave-request')}
            />
          )}

          {activeTab === 'hostels-biometric' && (
            <StudentHostelBiometricView student={currentStudent} />
          )}

          {activeTab === 'hostels-room-allotment' && (
            <StudentHostelRoomAllotmentView student={currentStudent} />
          )}

          {activeTab === 'hostels-room-master' && (
            <StudentHostelRoomMasterView student={currentStudent} />
          )}

          {/* 12. My Account Views */}
          {activeTab === 'account-change-password' && (
            <StudentChangePasswordView
              student={currentStudent}
              onPasswordChanged={(updated) => setCurrentStudent(updated)}
            />
          )}

          {activeTab === 'account-it-support' && (
            <StudentItSupportView student={currentStudent} />
          )}
        </main>
      </div>

      {/* Shared Modals */}
      <ReceiptPreviewModal
        isOpen={Boolean(selectedReceipt)}
        onClose={() => setSelectedReceipt(null)}
        receipt={selectedReceipt}
      />

      <HallTicketPrintModal
        isOpen={Boolean(selectedHallTicket)}
        onClose={() => setSelectedHallTicket(null)}
        hallTicket={selectedHallTicket}
      />

      <ResultTranscriptModal
        isOpen={Boolean(selectedResult)}
        onClose={() => setSelectedResult(null)}
        result={selectedResult}
      />
    </div>
  );
}
