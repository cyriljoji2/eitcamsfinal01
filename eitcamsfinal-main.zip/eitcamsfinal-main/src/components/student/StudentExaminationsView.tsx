import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  BookOpen,
  MapPin,
  Award,
  AlertCircle,
  CheckCircle2,
  FileText,
  ShieldCheck,
  Building,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Examination, ExamSubjectSchedule } from '../../types/examination';
import { Badge } from '../ui/Badge';

interface StudentExaminationsViewProps {
  student: Student;
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
}

export function StudentExaminationsView({
  student,
  examinations,
  schedules,
}: StudentExaminationsViewProps) {
  const [selectedExamId, setSelectedExamId] = useState<string>(
    examinations[0]?.id || ''
  );

  const activeExam =
    examinations.find((e) => e.id.toLowerCase() === selectedExamId.toLowerCase()) ||
    examinations[0] ||
    null;

  // Filter schedules for the active examination
  const activeSchedules = schedules
    .filter((s) => activeExam && s.examinationId.toLowerCase() === activeExam.id.toLowerCase())
    .sort((a, b) => a.examDate.localeCompare(b.examDate));

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Calendar className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Examinations & Timetables</h1>
                <Badge variant="blue" size="sm">
                  {examinations.length} Assessment Series
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass} (Sec {student.section})</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>COE Published Schedules</span>
          </div>
        </div>
      </div>

      {/* Examination Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {examinations.map((exam) => (
          <button
            key={exam.id}
            type="button"
            onClick={() => setSelectedExamId(exam.id)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
              activeExam?.id === exam.id
                ? 'bg-[#1e3a8a] text-white border-[#1e3a8a] shadow-xs'
                : 'bg-white text-[#475569] border-[#cbd5e1] hover:bg-slate-50'
            }`}
          >
            {exam.name}
          </button>
        ))}
      </div>

      {/* Active Examination Details & Timetable */}
      {activeExam ? (
        <div className="space-y-6">
          {/* Exam Overview Card */}
          <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-[#1e293b]">{activeExam.name}</h2>
                  <Badge
                    variant={
                      activeExam.status === 'Published'
                        ? 'emerald'
                        : activeExam.status === 'Active' || activeExam.status === 'Mark Entry Open'
                        ? 'blue'
                        : 'neutral'
                    }
                    size="sm"
                  >
                    {activeExam.status}
                  </Badge>
                  <span className="text-xs text-[#64748b] font-mono bg-slate-100 px-2 py-0.5 rounded">
                    {activeExam.termType}
                  </span>
                </div>
                <p className="text-xs text-[#64748b] mt-1.5 leading-relaxed">
                  {activeExam.instructions || 'Official scheduled institutional assessments and papers.'}
                </p>
              </div>

              <div className="text-xs text-[#475569] bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0] shrink-0">
                <span className="text-[#64748b] block text-[11px]">Assessment Window</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {activeExam.startDate} to {activeExam.endDate}
                </span>
                <span className="text-[11px] text-[#64748b] block mt-1">
                  Session: {activeExam.academicSession}
                </span>
              </div>
            </div>
          </div>

          {/* Subject Timetable Table */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Paper Timetable & Venue Allocations</h3>
              </div>
              <span className="text-xs text-[#64748b]">
                {activeSchedules.length} Papers Scheduled
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#1e293b]">
                <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3">Time Window</th>
                    <th className="px-5 py-3">Subject Name & Code</th>
                    <th className="px-5 py-3">Venue / Room</th>
                    <th className="px-5 py-3 text-right">Max Marks</th>
                    <th className="px-5 py-3 text-right">Pass Marks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {activeSchedules.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-[#94a3b8]">
                        No individual paper schedule entries found for this examination series.
                      </td>
                    </tr>
                  ) : (
                    activeSchedules.map((sch) => (
                      <tr key={sch.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-5 py-3.5 font-bold text-[#1e293b]">
                          {sch.examDate}
                        </td>
                        <td className="px-5 py-3.5 text-[#475569]">
                          <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-mono font-medium">
                            {sch.startTime} – {sch.endTime}
                          </span>
                        </td>
                        <td className="px-5 py-3.5">
                          <span className="font-semibold text-[#1e293b] block">
                            {sch.subjectName}
                          </span>
                          <span className="text-[10px] text-[#64748b] font-mono">
                            {sch.subjectCode}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-[#475569]">
                          <div className="flex items-center gap-1.5">
                            <Building className="w-3.5 h-3.5 text-[#94a3b8]" />
                            <span>{sch.roomVenue}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-right font-medium text-[#1e293b]">
                          {sch.maxMarks}
                        </td>
                        <td className="px-5 py-3.5 text-right font-semibold text-emerald-700">
                          {sch.passMarks}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Candidate Exam Instructions */}
          <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-[#e2e8f0]">
              <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
              <h3 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                Candidate Examination Instructions & Code of Conduct
              </h3>
            </div>
            <ul className="text-xs text-[#64748b] space-y-1.5 list-disc pl-5 leading-relaxed">
              <li>Candidates must report to the allocated exam hall at least 15 minutes before the start time.</li>
              <li>A physical or digital copy of the official Hall Ticket with valid Registration Number is mandatory.</li>
              <li>Electronic devices, smart watches, and unauthorized paper materials are strictly prohibited.</li>
              <li>Maintain complete silence and follow invigilator instructions during all assessment periods.</li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center text-xs text-[#94a3b8]">
          No examination schedules currently active.
        </div>
      )}
    </div>
  );
}
