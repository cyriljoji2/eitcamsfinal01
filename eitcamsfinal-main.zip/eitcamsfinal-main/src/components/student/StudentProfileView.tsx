import React from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Shield,
  FileText,
  School,
  CheckCircle2,
  Users,
  Lock,
  Clock,
  Award,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Badge } from '../ui/Badge';

interface StudentProfileViewProps {
  student: Student;
}

export function StudentProfileView({ student }: StudentProfileViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Profile Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-2xl font-bold shrink-0 shadow-xs">
              {student.fullName
                .split(' ')
                .map((n) => n[0])
                .join('')
                .substring(0, 2)
                .toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">{student.fullName}</h1>
                <Badge variant="blue" size="sm">
                  {student.admissionClass} - Section {student.section}
                </Badge>
                <Badge variant={student.accountStatus === 'active' ? 'emerald' : 'rose'} size="sm">
                  {student.accountStatus === 'active' ? 'Active Student' : 'Inactive'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-3">
                <span>
                  Reg No: <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong>
                </span>
                <span>•</span>
                <span>Admission Date: <strong>{student.admissionDate}</strong></span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <Lock className="w-4 h-4 text-[#94a3b8]" />
            <span>Institutional Profile (Read-Only)</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Academic & Institutional Identifiers */}
        <div className="space-y-6 lg:col-span-1">
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
              <School className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Institutional Details</h2>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[#64748b] block">Official Registration Number</span>
                <span className="font-mono font-bold text-[#1e293b] text-sm mt-0.5 block">
                  {student.registrationNumber}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Current Enrolled Class</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.admissionClass} (Section {student.section})
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Academic Session</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">2026–2027</span>
              </div>

              <div>
                <span className="text-[#64748b] block">Admission Type</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.admissionType || 'Regular'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Admission Approval Status</span>
                <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  {student.admissionStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Previous Academic Background */}
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
              <Award className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-bold text-[#1e293b]">Previous Education</h2>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-[#64748b] block">Previous Institution</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.previousSchool || 'Not Specified'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Previous Class / Grade</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.previousClass || 'N/A'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Columns: Personal Info & Guardian Info */}
        <div className="space-y-6 lg:col-span-2">
          {/* Personal Information */}
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
              <User className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Personal Information</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[#64748b] block">Full Legal Name</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.fullName}</span>
              </div>

              <div>
                <span className="text-[#64748b] block">Date of Birth</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.dateOfBirth}</span>
              </div>

              <div>
                <span className="text-[#64748b] block">Gender</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.gender}</span>
              </div>

              <div>
                <span className="text-[#64748b] block">Primary Email</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.email}</span>
              </div>

              <div>
                <span className="text-[#64748b] block">Contact Mobile</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">{student.mobile}</span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-[#64748b] block">Residential Address</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block leading-relaxed">
                  {student.address || 'Address on file with Admission Office'}
                </span>
              </div>
            </div>
          </div>

          {/* Family & Guardian Information */}
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
              <Users className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-sm font-bold text-[#1e293b]">Family & Guardian Information</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[#64748b] block">Father / Guardian 1</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.fatherName || 'Not recorded'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Mother / Guardian 2</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.motherName || 'Not recorded'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Primary Legal Guardian</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.guardianName || student.fatherName || 'Parent / Guardian'}
                </span>
              </div>

              <div>
                <span className="text-[#64748b] block">Emergency Contact Phone</span>
                <span className="font-semibold text-[#1e293b] mt-0.5 block">
                  {student.mobile}
                </span>
              </div>
            </div>
          </div>

          {/* Uploaded & Verified Documents */}
          <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-[#e2e8f0]">
              <FileText className="w-4 h-4 text-emerald-600" />
              <h2 className="text-sm font-bold text-[#1e293b]">Verified Admission Documents</h2>
            </div>

            {student.documents && student.documents.length > 0 ? (
              <div className="space-y-2.5">
                {student.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-[#e2e8f0] bg-[#f8fafc]"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-[#1e293b] block">{doc.documentType}</span>
                        <span className="text-[11px] text-[#64748b]">
                          {doc.fileName} • {doc.fileSize}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant={doc.status === 'Verified' ? 'emerald' : 'amber'} size="sm">
                        {doc.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-[#f8fafc] border border-[#e2e8f0] text-center text-xs text-[#94a3b8]">
                No document attachments recorded on file.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
