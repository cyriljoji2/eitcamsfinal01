import React, { useRef } from 'react';
import {
  Receipt,
  Printer,
  Download,
  X,
  CheckCircle2,
  AlertCircle,
  Building2,
  Calendar,
  CreditCard,
  Hash,
  User,
  ShieldCheck,
} from 'lucide-react';
import { FeeReceipt } from '../../../types/studentPortalTypes';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface ReceiptPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: FeeReceipt | null;
}

export function ReceiptPreviewModal({ isOpen, onClose, receipt }: ReceiptPreviewModalProps) {
  const printContainerRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCsv = () => {
    const csvContent = [
      ['FIELD', 'VALUE'],
      ['Receipt Number', receipt.receiptNumber],
      ['Payment Reference ID', receipt.paymentId],
      ['Receipt Date', receipt.receiptDate],
      ['Student Registration Number', receipt.studentRegistrationNumber],
      ['Student Full Name', receipt.studentName],
      ['Class & Section', `${receipt.className} - Section ${receipt.section}`],
      ['Academic Session', receipt.academicSession],
      ['Fee Type Description', receipt.feeTypeName],
      ['Amount Paid ($)', receipt.amountPaid.toFixed(2)],
      ['Amount in Words', receipt.amountInWords],
      ['Payment Mode', receipt.paymentMode],
      ['Transaction Reference', receipt.transactionReference || 'N/A'],
      ['Outstanding Balance After Payment', receipt.outstandingBalanceAfterPayment.toFixed(2)],
      ['Cashier / Received By', receipt.receivedBy],
      ['Receipt Status', receipt.isVoided ? `CANCELLED / VOIDED (${receipt.voidReason})` : 'OFFICIAL VALID'],
      ['Institution Name', receipt.schoolDetails.name],
      ['Institution Address', receipt.schoolDetails.address],
    ]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `EIT_Receipt_${receipt.receiptNumber}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-2xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Modal Top Bar (Hidden in Print) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#1e3a8a] bg-[#eff6ff] px-2.5 py-1 rounded-md">
              Receipt Preview
            </span>
            <span className="text-xs text-[#64748b] font-mono">{receipt.receiptNumber}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleDownloadCsv} className="gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV</span>
            </Button>
            <Button size="sm" variant="primary" onClick={handlePrint} className="gap-1.5">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Receipt</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Container */}
        <div
          ref={printContainerRef}
          className="p-8 space-y-6 text-[#1e293b] print:p-6"
          id="printable-receipt"
        >
          {/* Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex items-start justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xl shrink-0 shadow-xs">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-lg font-black text-[#1e3a8a] tracking-tight uppercase">
                  {receipt.schoolDetails.name}
                </h1>
                <p className="text-xs text-[#64748b]">{receipt.schoolDetails.address}</p>
                <div className="mt-1 flex items-center gap-3 text-[11px] text-[#64748b]">
                  {receipt.schoolDetails.phone && <span>Tel: {receipt.schoolDetails.phone}</span>}
                  {receipt.schoolDetails.email && <span>Email: {receipt.schoolDetails.email}</span>}
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-[#64748b] font-medium">Official EIT Receipt</div>
              <div className="text-base font-black font-mono text-[#1e3a8a] tracking-wider">
                {receipt.receiptNumber}
              </div>
              <div className="text-xs text-[#64748b] mt-0.5">Date: {receipt.receiptDate}</div>
            </div>
          </div>

          {/* Voided Alert Banner if cancelled */}
          {receipt.isVoided && (
            <div className="bg-rose-50 border-2 border-rose-300 rounded-lg p-3 flex items-center justify-between text-rose-900">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                <span className="text-xs font-bold uppercase tracking-wider">
                  VOIDED RECEIPT — TRANSACTION HAS BEEN REVERSED
                </span>
              </div>
              {receipt.voidReason && (
                <span className="text-xs italic text-rose-700">Reason: {receipt.voidReason}</span>
              )}
            </div>
          )}

          {/* Student & Session Information Grid */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50/70 border border-[#e2e8f0] rounded-lg text-xs">
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">
                Student Full Name
              </span>
              <span className="font-bold text-[#1e293b] text-sm">{receipt.studentName}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">
                Registration Number
              </span>
              <span className="font-bold font-mono text-[#1e3a8a] text-sm">
                {receipt.studentRegistrationNumber}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">
                Class / Section
              </span>
              <span className="font-medium text-[#1e293b]">
                {receipt.className} — Sec {receipt.section}
              </span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">
                Academic Session
              </span>
              <span className="font-medium text-[#1e293b]">{receipt.academicSession}</span>
            </div>
          </div>

          {/* Fee Itemization Table */}
          <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] border-b border-[#e2e8f0] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-4">#</th>
                  <th className="py-2.5 px-4">Fee Description / Account Head</th>
                  <th className="py-2.5 px-4 text-right">Amount Settled</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                <tr>
                  <td className="py-3 px-4 font-mono text-[#64748b]">1</td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#1e293b]">{receipt.feeTypeName}</div>
                    <div className="text-[11px] text-[#64748b]">Payment Ref: {receipt.paymentId}</div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-sm text-[#1e293b]">
                    ${receipt.amountPaid.toFixed(2)}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-[#f8fafc] border-t border-[#e2e8f0]">
                <tr>
                  <td colSpan={2} className="py-2.5 px-4 text-right font-bold text-[#1e293b]">
                    Total Amount Received:
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono font-black text-[#1e3a8a] text-base">
                    ${receipt.amountPaid.toFixed(2)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Amount in words */}
          <div className="bg-slate-50 border border-[#e2e8f0] rounded-lg p-3 text-xs flex items-center justify-between">
            <span className="text-[#64748b] font-medium">Amount in Words:</span>
            <span className="font-bold text-[#1e293b] italic">{receipt.amountInWords}</span>
          </div>

          {/* Transaction & Settlement Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
            <div className="p-2.5 border border-[#e2e8f0] rounded-md">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Payment Mode</span>
              <span className="font-semibold text-[#1e293b]">{receipt.paymentMode}</span>
            </div>
            <div className="p-2.5 border border-[#e2e8f0] rounded-md">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Txn Reference</span>
              <span className="font-mono text-[11px] text-[#1e293b] truncate block">
                {receipt.transactionReference || 'N/A'}
              </span>
            </div>
            <div className="p-2.5 border border-[#e2e8f0] rounded-md">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Outstanding Balance</span>
              <span
                className={`font-mono font-bold ${
                  receipt.outstandingBalanceAfterPayment > 0 ? 'text-amber-600' : 'text-emerald-700'
                }`}
              >
                ${receipt.outstandingBalanceAfterPayment.toFixed(2)}
              </span>
            </div>
            <div className="p-2.5 border border-[#e2e8f0] rounded-md">
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Authorized By</span>
              <span className="font-semibold text-[#1e293b] text-[11px] truncate block">
                {receipt.receivedBy}
              </span>
            </div>
          </div>

          {/* Footer & Signature Section */}
          <div className="pt-8 border-t border-[#cbd5e1] flex items-end justify-between text-xs text-[#64748b]">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Computer Generated Official Institutional Receipt</span>
              </div>
              <p className="text-[10px] text-[#94a3b8]">
                This is a system authenticated document issued by EIT Accounts & Finance Office.
              </p>
            </div>

            <div className="text-center w-48">
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1.5 flex items-end justify-center pb-1">
                <span className="text-[10px] text-[#94a3b8] italic">Digital System Seal</span>
              </div>
              <span className="font-bold text-[#1e293b] text-[11px] block">
                Finance & Accounts Division
              </span>
              <span className="text-[10px] text-[#64748b]">Electrix Institute of Technology</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
