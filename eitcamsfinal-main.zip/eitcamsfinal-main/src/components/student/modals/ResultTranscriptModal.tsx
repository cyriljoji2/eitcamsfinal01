import React from 'react';
import { X, Printer, Award, School, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';
import { StudentExamResult } from '../../../types/studentPortalTypes';
import { Button } from '../../ui/Button';

interface ResultTranscriptModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: StudentExamResult | null;
}

export function ResultTranscriptModal({
  isOpen,
  onClose,
  result,
}: ResultTranscriptModalProps) {
  if (!isOpen || !result) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-3xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md">
              Academic Transcript / Marksheet
            </span>
            <span className="text-xs text-[#64748b] font-mono">
              {result.studentRegistrationNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5 cursor-pointer">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Transcript</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Transcript */}
        <div className="p-8 space-y-6 text-[#1e293b] print:p-6">
          {/* Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex items-start justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-2xl shrink-0 shadow-xs">
                <School className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-lg font-black text-[#1e3a8a] tracking-tight uppercase">
                  ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)
                </h1>
                <p className="text-xs text-[#64748b]">Office of the Controller of Examinations</p>
                <div className="mt-1 inline-flex items-center gap-2 px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold rounded-md">
                  OFFICIAL GRADE STATEMENT &amp; EVALUATION RECORD
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-[#64748b] font-medium">Document ID</div>
              <div className="text-sm font-black font-mono text-[#1e3a8a]">{result.id}</div>
              <div className="text-[10px] text-[#64748b] mt-0.5">
                Published: {result.publishedAt ? new Date(result.publishedAt).toLocaleDateString() : 'Official'}
              </div>
            </div>
          </div>

          {/* Student Profile Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50/70 border border-[#cbd5e1] rounded-lg text-xs">
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Candidate Name</span>
              <span className="font-bold text-[#1e293b] text-sm">{result.studentName}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Registration Number</span>
              <span className="font-bold font-mono text-[#1e3a8a] text-sm">{result.studentRegistrationNumber}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Evaluation Type</span>
              <span className="font-bold text-[#1e293b]">Continuous &amp; End-Semester</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Overall Standing</span>
              <span className="font-bold text-emerald-800">
                {result.status === 'Passed' ? 'QUALIFIED / PASS' : result.status}
              </span>
            </div>
          </div>

          {/* Course Scores & Grade Table */}
          <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                <tr>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Course Code</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Course Title</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">Internal</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">External</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">Total Marks</th>
                  <th className="py-2.5 px-3 border-r border-[#e2e8f0] text-center">Letter Grade</th>
                  <th className="py-2.5 px-3 text-center">Result Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-3 px-3 font-mono font-bold text-[#1e3a8a] border-r border-[#e2e8f0]">
                    {result.subjectCode}
                  </td>
                  <td className="py-3 px-3 font-medium text-[#1e293b] border-r border-[#e2e8f0]">
                    {result.subjectName}
                  </td>
                  <td className="py-3 px-3 text-center font-mono border-r border-[#e2e8f0]">
                    {result.internalMarks ?? '—'}
                  </td>
                  <td className="py-3 px-3 text-center font-mono border-r border-[#e2e8f0]">
                    {result.externalMarks ?? '—'}
                  </td>
                  <td className="py-3 px-3 text-center font-mono font-bold text-[#1e293b] border-r border-[#e2e8f0]">
                    {result.marksObtained} / {result.maxMarks}
                  </td>
                  <td className="py-3 px-3 text-center border-r border-[#e2e8f0]">
                    <span className="px-2 py-0.5 rounded font-bold font-mono bg-blue-50 text-[#1e3a8a] border border-blue-200">
                      {result.grade}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        result.status === 'Passed'
                          ? 'bg-emerald-50 text-emerald-800'
                          : 'bg-rose-50 text-rose-800'
                      }`}
                    >
                      {result.status}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Grade Summary Box */}
          <div className="p-4 bg-slate-50 border border-[#e2e8f0] rounded-lg flex items-center justify-between text-xs">
            <div>
              <span className="text-[#64748b]">Grade Point Awarded:</span>
              <span className="font-mono font-black text-sm text-[#1e3a8a] ml-2">
                {result.gradePoint.toFixed(1)} / 10.0
              </span>
            </div>
            <div>
              <span className="text-[#64748b]">Percentage Equivalent:</span>
              <span className="font-mono font-bold text-sm text-slate-800 ml-2">
                {result.percentage}%
              </span>
            </div>
            <div>
              <span className="text-[#64748b]">Credits:</span>
              <span className="font-mono font-bold text-sm text-slate-800 ml-2">
                {result.credits ?? 4}
              </span>
            </div>
          </div>

          {/* Seal and Signatures */}
          <div className="pt-8 border-t border-[#cbd5e1] grid grid-cols-2 gap-4 text-xs text-[#64748b]">
            <div>
              <div className="flex items-center gap-1.5 text-emerald-800 font-semibold mb-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Verified by Academic Office &amp; Controller of Examinations</span>
              </div>
              <p className="text-[10px] text-[#94a3b8]">
                Electronically published document. Any tampering voids this certificate.
              </p>
            </div>

            <div className="text-right pr-4">
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1.5 flex items-end justify-end pb-1">
                <span className="text-[10px] text-emerald-800 font-mono font-bold">[VERIFIED COE DIGITAL SIGNATURE]</span>
              </div>
              <span className="font-bold text-[#1e293b] text-[11px] block">
                Office of the Controller of Examinations
              </span>
              <span className="text-[10px] text-[#64748b]">Electrix Institute of Technology</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
