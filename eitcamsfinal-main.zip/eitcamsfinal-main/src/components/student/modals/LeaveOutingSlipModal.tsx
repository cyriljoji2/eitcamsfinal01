import React from 'react';
import { X, Printer, Home, CheckCircle2, ShieldCheck, User, Calendar, Clock, MapPin, Phone } from 'lucide-react';
import { LeaveOutingRequest } from '../../../types/studentPortalTypes';
import { Button } from '../../ui/Button';

interface LeaveOutingSlipModalProps {
  isOpen: boolean;
  onClose: () => void;
  request: LeaveOutingRequest | null;
}

export function LeaveOutingSlipModal({
  isOpen,
  onClose,
  request,
}: LeaveOutingSlipModalProps) {
  if (!isOpen || !request) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-2xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md">
              Official Hostel Pass
            </span>
            <span className="text-xs text-[#64748b] font-mono">{request.id}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5 cursor-pointer">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Gate Pass Slip</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Slip Container */}
        <div className="p-8 space-y-6 text-[#1e293b] print:p-6" id="printable-leave-slip">
          {/* Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex items-start justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-xl shrink-0 shadow-xs">
                <Home className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-lg font-black text-[#1e3a8a] tracking-tight uppercase">
                  ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)
                </h1>
                <p className="text-xs text-[#64748b]">Hostel &amp; Residential Services Division</p>
                <div className="mt-1 inline-flex items-center gap-2 px-2.5 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold rounded-md">
                  AUTHORIZED RESIDENTIAL {request.requestType.toUpperCase()} PASS / GATE SLIP
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-[#64748b] font-medium">Pass Number</div>
              <div className="text-sm font-black font-mono text-[#1e3a8a]">{request.id}</div>
              <div className="text-[10px] text-[#64748b] mt-0.5">
                Issued: {new Date(request.createdAt).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Student Profile Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-50/70 border border-[#cbd5e1] rounded-lg text-xs">
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Student Name</span>
              <span className="font-bold text-[#1e293b] text-sm">{request.studentName}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Registration No</span>
              <span className="font-bold font-mono text-[#1e3a8a] text-sm">{request.studentRegistrationNumber}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Hostel Block &amp; Room</span>
              <span className="font-bold text-[#1e293b]">{request.blockName} — Room {request.roomNumber}</span>
            </div>
            <div>
              <span className="text-[#64748b] block text-[10px] uppercase font-bold">Approval Status</span>
              <span className="font-bold text-emerald-800 flex items-center gap-1 mt-0.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{request.approvalStatus}</span>
              </span>
            </div>
          </div>

          {/* Movement Schedule & Details */}
          <div className="border border-[#cbd5e1] rounded-lg p-4 space-y-3 text-xs bg-white">
            <div className="font-bold text-sm text-[#1e293b] border-b border-slate-100 pb-2">
              Authorized Movement Schedule
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-slate-50 rounded-lg space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Departure (Out-Time)</span>
                <div className="font-bold text-slate-900">{request.fromDate} at {request.fromTime}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Expected Return (In-Time)</span>
                <div className="font-bold text-slate-900">{request.toDate} at {request.toTime}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-1">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Destination</span>
                <span className="font-medium text-slate-900">{request.destination}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Reason &amp; Category</span>
                <span className="font-medium text-slate-900">{request.reason} ({request.reasonCategory})</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Student Contact</span>
                <span className="font-mono text-slate-900">{request.contactNumber}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Emergency / Parent Contact</span>
                <span className="font-mono text-slate-900">{request.emergencyContact}</span>
              </div>
            </div>
          </div>

          {/* Gate Verification Table */}
          <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] font-bold text-slate-800">
                <tr>
                  <th className="py-2.5 px-4 border-r border-[#e2e8f0]">Security Checkpoint</th>
                  <th className="py-2.5 px-4 border-r border-[#e2e8f0]">Biometric / Timestamp</th>
                  <th className="py-2.5 px-4 text-center">Security Guard Sign</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                <tr>
                  <td className="py-2.5 px-4 font-semibold text-slate-800 border-r border-[#e2e8f0]">Main Campus Out Gate</td>
                  <td className="py-2.5 px-4 font-mono text-slate-500 border-r border-[#e2e8f0]">Recorded Biometric [ ____ ]</td>
                  <td className="py-2.5 px-4 text-center font-mono text-slate-400">[ _____________ ]</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 font-semibold text-slate-800 border-r border-[#e2e8f0]">Main Campus In Gate</td>
                  <td className="py-2.5 px-4 font-mono text-slate-500 border-r border-[#e2e8f0]">Recorded Biometric [ ____ ]</td>
                  <td className="py-2.5 px-4 text-center font-mono text-slate-400">[ _____________ ]</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Signatures */}
          <div className="pt-6 border-t border-[#cbd5e1] grid grid-cols-3 gap-4 text-center text-xs text-[#64748b]">
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1"></div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Resident Student</span>
              <span className="text-[10px] text-[#94a3b8]">Undertaking of Conduct</span>
            </div>
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1 flex items-end justify-center pb-1">
                <span className="text-[10px] text-emerald-800 font-bold font-mono">[PROCTOR APPROVED]</span>
              </div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Faculty Proctor</span>
              <span className="text-[10px] text-[#94a3b8]">Verified Approval</span>
            </div>
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1 flex items-end justify-center pb-1">
                <span className="text-[10px] text-emerald-800 font-bold font-mono">[WARDEN AUTHORIZED]</span>
              </div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Chief Warden</span>
              <span className="text-[10px] text-[#94a3b8]">Hostel Administration</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
