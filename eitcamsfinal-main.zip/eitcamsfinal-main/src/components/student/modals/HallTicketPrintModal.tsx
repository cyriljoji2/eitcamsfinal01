import React from 'react';
import { X, Printer, Download, School, CheckCircle2, ShieldCheck, User } from 'lucide-react';
import { HallTicket } from '../../../types/studentPortalTypes';
import { Button } from '../../ui/Button';

interface HallTicketPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  hallTicket: HallTicket | null;
}

export function HallTicketPrintModal({
  isOpen,
  onClose,
  hallTicket,
}: HallTicketPrintModalProps) {
  if (!isOpen || !hallTicket) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-xl shadow-2xl border border-[#cbd5e1] w-full max-w-3xl overflow-hidden my-8 print:border-none print:shadow-none print:m-0 print:max-w-full">
        {/* Modal Top Bar (Hidden in Print) */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-[#e2e8f0] bg-[#f8fafc] print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-[#1e3a8a] bg-[#eff6ff] px-2.5 py-1 rounded-md">
              Hall Ticket Preview
            </span>
            <span className="text-xs text-[#64748b] font-mono">
              {hallTicket.hallTicketNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handlePrint} className="gap-1.5 cursor-pointer">
              <Printer className="w-3.5 h-3.5" />
              <span>Print Hall Ticket</span>
            </Button>
            <button
              type="button"
              onClick={onClose}
              className="text-[#64748b] hover:text-[#1e293b] p-1.5 rounded-lg hover:bg-slate-100 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="p-8 space-y-6 text-[#1e293b] print:p-6" id="printable-hall-ticket">
          {/* Header */}
          <div className="border-b-2 border-[#1e3a8a] pb-4 flex items-start justify-between">
            <div className="flex items-start gap-3.5">
              <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center font-bold text-2xl shrink-0 shadow-xs">
                <School className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-lg font-black text-[#1e3a8a] tracking-tight uppercase">
                  {hallTicket.schoolName || 'ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)'}
                </h1>
                <p className="text-xs text-[#64748b]">{hallTicket.schoolAddress}</p>
                <div className="mt-1 inline-flex items-center gap-2 px-2.5 py-0.5 bg-[#eff6ff] border border-blue-200 text-[#1e3a8a] text-[11px] font-bold rounded-md">
                  OFFICIAL EXAMINATION HALL TICKET / ADMIT CARD
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-[#64748b] font-medium">Hall Ticket Number</div>
              <div className="text-base font-black font-mono text-[#1e3a8a] tracking-wider">
                {hallTicket.hallTicketNumber}
              </div>
              <div className="text-[10px] text-[#64748b] mt-0.5">Session: {hallTicket.academicSession}</div>
            </div>
          </div>

          {/* Examination Name Banner */}
          <div className="bg-slate-50 border border-[#e2e8f0] rounded-lg p-3 text-center">
            <div className="text-sm font-black text-[#1e293b] uppercase tracking-wide">
              {hallTicket.examinationName}
            </div>
          </div>

          {/* Student Profile & Photo Grid */}
          <div className="grid grid-cols-4 gap-4 p-4 bg-slate-50/70 border border-[#cbd5e1] rounded-lg text-xs">
            <div className="col-span-3 grid grid-cols-2 gap-y-2.5 gap-x-4">
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Candidate Name</span>
                <span className="font-bold text-[#1e293b] text-sm">{hallTicket.studentName}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Registration Number</span>
                <span className="font-bold font-mono text-[#1e3a8a] text-sm">{hallTicket.studentRegistrationNumber}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Program & Section</span>
                <span className="font-bold text-[#1e293b]">{hallTicket.className} — Section {hallTicket.section}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Date of Birth</span>
                <span className="font-bold text-[#1e293b]">{hallTicket.dateOfBirth || 'N/A'}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Father / Guardian</span>
                <span className="font-medium text-[#1e293b]">{hallTicket.fatherName || 'N/A'}</span>
              </div>
              <div>
                <span className="text-[#64748b] block text-[10px] uppercase font-bold">Mother's Name</span>
                <span className="font-medium text-[#1e293b]">{hallTicket.motherName || 'N/A'}</span>
              </div>
            </div>

            {/* Candidate Photo Box */}
            <div className="col-span-1 flex flex-col items-center justify-center border-2 border-dashed border-[#cbd5e1] rounded-lg bg-white p-2">
              <div className="w-16 h-20 bg-slate-100 border border-[#cbd5e1] rounded flex flex-col items-center justify-center text-[#94a3b8] text-[9px] text-center p-1">
                <User className="w-6 h-6 mb-1 text-[#cbd5e1]" />
                <span>Affix Student Photo</span>
              </div>
              <span className="text-[9px] text-[#64748b] mt-1 font-medium">Attested Photograph</span>
            </div>
          </div>

          {/* Examination Schedule Table */}
          <div>
            <div className="text-xs font-bold text-[#1e293b] uppercase mb-2 flex items-center justify-between">
              <span>Examination Schedule & Paper Timings</span>
              <span className="text-[10px] font-normal text-[#64748b]">{hallTicket.schedules.length} Papers Scheduled</span>
            </div>
            <div className="border border-[#cbd5e1] rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#f8fafc] border-b border-[#cbd5e1] text-[#1e293b] font-bold">
                  <tr>
                    <th className="py-2.5 px-3 border-r border-[#e2e8f0]">#</th>
                    <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Date</th>
                    <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Time</th>
                    <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Subject Name & Code</th>
                    <th className="py-2.5 px-3 border-r border-[#e2e8f0]">Room / Venue</th>
                    <th className="py-2.5 px-3 text-center">Invigilator Sign</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {hallTicket.schedules.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-400">
                        No subject papers scheduled for this hall ticket yet.
                      </td>
                    </tr>
                  ) : (
                    hallTicket.schedules.map((sch, idx) => (
                      <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-[#fcfdfe]'}>
                        <td className="py-2 px-3 text-center font-mono text-[#64748b] border-r border-[#e2e8f0]">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-3 font-bold text-[#1e293b] border-r border-[#e2e8f0] whitespace-nowrap">
                          {sch.examDate}
                        </td>
                        <td className="py-2 px-3 font-mono text-[#475569] border-r border-[#e2e8f0] whitespace-nowrap">
                          {sch.timeSlot}
                        </td>
                        <td className="py-2 px-3 border-r border-[#e2e8f0]">
                          <span className="font-bold text-[#1e3a8a] font-mono mr-1.5">{sch.courseCode}</span>
                          <span className="text-[#334155]">{sch.courseName}</span>
                        </td>
                        <td className="py-2 px-3 text-[#475569] border-r border-[#e2e8f0]">
                          {sch.room}
                        </td>
                        <td className="py-2 px-3 text-center text-[#94a3b8] font-mono text-[10px]">
                          [ ____________ ]
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Candidate Instructions */}
          <div className="p-3.5 bg-slate-50 border border-[#e2e8f0] rounded-lg text-[11px] text-[#475569] space-y-1.5">
            <div className="font-bold text-[#1e293b] uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Instructions to Candidates</span>
            </div>
            <ol className="list-decimal pl-4 space-y-1">
              <li>Candidates must report to the allocated examination hall at least 20 minutes before the scheduled start time.</li>
              <li>This hall ticket along with the official Institute Student ID card must be presented on each day of examination.</li>
              <li>Electronic gadgets, smartwatches, calculators (unless explicitly authorized), and study materials are strictly prohibited.</li>
            </ol>
          </div>

          {/* Authentication Signatures */}
          <div className="pt-6 border-t border-[#cbd5e1] grid grid-cols-3 gap-4 text-center text-xs text-[#64748b]">
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1"></div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Candidate Signature</span>
              <span className="text-[10px] text-[#94a3b8]">To be signed in presence of invigilator</span>
            </div>
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1"></div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Centre Superintendent</span>
              <span className="text-[10px] text-[#94a3b8]">Seal & Signature</span>
            </div>
            <div>
              <div className="h-10 border-b border-[#cbd5e1] border-dashed mb-1 flex items-end justify-center pb-1">
                <span className="text-[10px] text-emerald-800 font-mono font-bold tracking-wider">[VERIFIED COE STAMP]</span>
              </div>
              <span className="font-bold text-[#1e293b] text-[11px] block">Controller of Examinations</span>
              <span className="text-[10px] text-[#94a3b8]">Electrix Institute of Technology</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
