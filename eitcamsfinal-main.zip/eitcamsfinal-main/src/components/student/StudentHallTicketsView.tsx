import React from 'react';
import {
  Award,
  Printer,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Building,
  ShieldCheck,
  Clock,
  School,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Examination, HallTicket } from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface StudentHallTicketsViewProps {
  student: Student;
  hallTickets: HallTicket[];
  examinations: Examination[];
  onViewHallTicket: (hallTicket: HallTicket) => void;
}

export function StudentHallTicketsView({
  student,
  hallTickets,
  examinations,
  onViewHallTicket,
}: StudentHallTicketsViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Examination Hall Tickets</h1>
                <Badge variant="emerald" size="sm">
                  {hallTickets.length} Issued Hall Tickets
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>COE Digitally Signed</span>
          </div>
        </div>
      </div>

      {/* Hall Tickets List */}
      {hallTickets.length === 0 ? (
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-[#1e3a8a] flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-[#1e293b]">No Hall Tickets Issued Yet</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Hall tickets for upcoming examinations are issued directly by the Controller of Examination (COE) once candidate attendance eligibility and fee accounts are confirmed.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {hallTickets.map((ht) => {
            const parentExam = examinations.find(
              (e) => e.id.toLowerCase() === ht.examinationId.toLowerCase()
            );

            return (
              <div
                key={ht.id}
                className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs hover:border-[#bfdbfe] transition-all p-6 flex flex-col justify-between space-y-5"
              >
                <div>
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-3 pb-4 border-b border-[#e2e8f0]">
                    <div>
                      <span className="text-xs font-semibold text-[#64748b] block">Official Hall Ticket</span>
                      <span className="text-base font-bold text-[#1e3a8a] font-mono mt-0.5 block">
                        {ht.hallTicketNumber}
                      </span>
                    </div>
                    <Badge variant={ht.status === 'Generated' ? 'emerald' : 'rose'} size="sm">
                      {ht.status}
                    </Badge>
                  </div>

                  {/* Body Details */}
                  <div className="grid grid-cols-2 gap-3.5 mt-4 text-xs">
                    <div>
                      <span className="text-[#64748b] block">Examination</span>
                      <span className="font-semibold text-[#1e293b] mt-0.5 block">
                        {ht.examinationName}
                      </span>
                    </div>

                    <div>
                      <span className="text-[#64748b] block">Academic Session</span>
                      <span className="font-semibold text-[#1e293b] mt-0.5 block">
                        {ht.academicSession}
                      </span>
                    </div>

                    <div>
                      <span className="text-[#64748b] block">Candidate Class & Sec</span>
                      <span className="font-semibold text-[#1e293b] mt-0.5 block">
                        {ht.className} - Section {ht.section}
                      </span>
                    </div>

                    <div>
                      <span className="text-[#64748b] block">Issue Date</span>
                      <span className="font-semibold text-[#1e293b] mt-0.5 block">
                        {ht.generatedAt?.split('T')[0] || '2026-08-15'}
                      </span>
                    </div>
                  </div>

                  {/* Paper Schedules Count */}
                  {ht.schedules && ht.schedules.length > 0 && (
                    <div className="mt-4 p-3 rounded-lg bg-[#f8fafc] border border-[#e2e8f0]">
                      <span className="text-[11px] font-semibold text-[#334155] block">
                        Scheduled Papers ({ht.schedules.length})
                      </span>
                      <div className="mt-1.5 space-y-1">
                        {ht.schedules.slice(0, 3).map((s, idx) => (
                          <div key={idx} className="flex items-center justify-between text-[11px] text-[#64748b]">
                            <span>{s.subjectName}</span>
                            <span className="font-mono">{s.examDate}</span>
                          </div>
                        ))}
                        {ht.schedules.length > 3 && (
                          <span className="text-[10px] text-[#1e3a8a] block font-medium">
                            +{ht.schedules.length - 3} more subjects included
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Print / View Button */}
                <div className="pt-4 border-t border-[#e2e8f0] flex items-center justify-between">
                  <span className="text-[11px] text-[#64748b]">
                    Present this ticket at the examination hall
                  </span>
                  <Button
                    id={`btn-view-hall-ticket-${ht.hallTicketNumber}`}
                    variant="primary"
                    size="sm"
                    onClick={() => onViewHallTicket(ht)}
                    leftIcon={<Printer className="w-4 h-4" />}
                  >
                    View & Print Ticket
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
