import React, { useState, useMemo } from 'react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  HelpCircle,
  Search,
  Filter,
  Shield,
  FileSpreadsheet,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { AttendanceRecord, AttendanceStatus } from '../../types/academic';
import { Badge } from '../ui/Badge';
import { Input } from '../ui/Input';
import { StudentSemesterSelector } from './common/StudentSemesterSelector';
import { getStudentAvailableSemesters } from '../../utils/studentSemesterUtils';

interface StudentAttendanceViewProps {
  student: Student;
  attendanceRecords: AttendanceRecord[];
}

export function StudentAttendanceView({
  student,
  attendanceRecords,
}: StudentAttendanceViewProps) {
  const [selectedSemester, setSelectedSemester] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [searchDate, setSearchDate] = useState<string>('');

  // Determine available registered semesters strictly for this student
  const availableSemesters = useMemo(() => {
    return getStudentAvailableSemesters({
      student,
      attendanceRecords,
    });
  }, [student, attendanceRecords]);

  // Filter attendance records strictly belonging to the selected semester
  const semesterRecords = useMemo(() => {
    if (!selectedSemester) return [];
    const target = selectedSemester.trim().toLowerCase();

    return attendanceRecords.filter((rec) => {
      // 1. Explicit semester property on attendance record
      if (rec.semester != null && String(rec.semester).trim()) {
        const sVal = String(rec.semester).trim().toLowerCase();
        return sVal === target || target.includes(sVal);
      }
      // 2. Remarks or session matching
      if (rec.remarks && rec.remarks.toLowerCase().includes(target)) {
        return true;
      }
      // 3. If no explicit semester tag on record, check if student's current enrolled semester matches
      if (student.currentSemester && student.currentSemester.trim().toLowerCase() === target) {
        return true;
      }
      return false;
    });
  }, [attendanceRecords, selectedSemester, student.currentSemester]);

  // Metrics derived strictly from the semester's attendance records
  const totalDays = semesterRecords.length;
  const presentCount = semesterRecords.filter((r) => r.status === 'Present' || (r.status as string) === 'PRESENT').length;
  const absentCount = semesterRecords.filter((r) => r.status === 'Absent' || (r.status as string) === 'ABSENT').length;
  const lateCount = semesterRecords.filter((r) => r.status === 'Late' || (r.status as string) === 'LATE').length;
  const leaveCount = semesterRecords.filter((r) => r.status === 'Leave' || (r.status as string) === 'EXCUSED' || (r.status as string) === 'LEAVE').length;

  // Percentage calculation: (Present + Late) / Total
  const effectivePresent = presentCount + lateCount;
  const percentage = totalDays > 0 ? Math.round((effectivePresent / totalDays) * 100) : 100;

  // Filtered attendance records within this semester by status & search
  const filteredRecords = semesterRecords.filter((rec) => {
    const statusMatch = filterStatus === 'All' || rec.status === filterStatus;
    const searchMatch = !searchDate || rec.date.includes(searchDate) || (rec.remarks && rec.remarks.toLowerCase().includes(searchDate.toLowerCase()));
    return statusMatch && searchMatch;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Calendar className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Attendance Record</h1>
                {selectedSemester && totalDays > 0 && (
                  <Badge variant={percentage >= 85 ? 'emerald' : percentage >= 75 ? 'amber' : 'rose'} size="sm">
                    {percentage}% Attendance Rate
                  </Badge>
                )}
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Enrolled: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
                </span>
                {selectedSemester && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{selectedSemester}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <Shield className="w-4 h-4 text-[#94a3b8]" />
            <span>Faculty Verified (Read-Only)</span>
          </div>
        </div>
      </div>

      {/* Semester Dropdown */}
      <StudentSemesterSelector
        id="student-attendance-semester"
        selectedSemester={selectedSemester}
        onChange={(sem) => {
          setSelectedSemester(sem);
          setSearchDate('');
          setFilterStatus('All');
        }}
        availableSemesters={availableSemesters}
        helperText="* Only Registered Semester"
      />

      {!selectedSemester ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Calendar className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Please select a semester to view attendance records
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Choose a registered semester from the dropdown above to display verified classroom attendance statistics and lecture session logs.
          </p>
        </div>
      ) : semesterRecords.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Clock className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            No attendance records available for this semester.
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            There are no attendance sessions logged for the chosen semester. Attendance entries will appear here once recorded by instruction faculty.
          </p>
        </div>
      ) : (
        <>
          {/* KPI Cards Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-[#64748b] block">Total Days</span>
              <span className="text-xl font-bold text-[#1e293b] mt-1 block">{totalDays}</span>
              <span className="text-[10px] text-[#94a3b8] mt-1 block">Recorded</span>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-emerald-700 block">Present</span>
              <span className="text-xl font-bold text-emerald-700 mt-1 block">{presentCount}</span>
              <span className="text-[10px] text-emerald-600 mt-1 block">On Time</span>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-amber-700 block">Late</span>
              <span className="text-xl font-bold text-amber-700 mt-1 block">{lateCount}</span>
              <span className="text-[10px] text-amber-600 mt-1 block">Tardy</span>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-rose-700 block">Absent</span>
              <span className="text-xl font-bold text-rose-700 mt-1 block">{absentCount}</span>
              <span className="text-[10px] text-rose-600 mt-1 block">Unexcused</span>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-blue-700 block">Leave</span>
              <span className="text-xl font-bold text-blue-700 mt-1 block">{leaveCount}</span>
              <span className="text-[10px] text-blue-600 mt-1 block">Sanctioned</span>
            </div>

            <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
              <span className="text-[11px] font-semibold text-[#1e3a8a] block">Rate</span>
              <span className="text-xl font-black text-[#1e3a8a] mt-1 block">{percentage}%</span>
              <span className="text-[10px] text-[#64748b] mt-1 block">
                {percentage >= 75 ? 'Meets Min 75%' : 'Below 75%'}
              </span>
            </div>
          </div>

          {/* Attendance Log Table Card */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            {/* Table Controls */}
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#f8fafc]">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
                  <input
                    type="text"
                    value={searchDate}
                    onChange={(e) => setSearchDate(e.target.value)}
                    placeholder="Search date (YYYY-MM-DD) or note..."
                    className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                  />
                </div>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="py-1.5 px-3 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
                >
                  <option value="All">All Statuses</option>
                  <option value="Present">Present</option>
                  <option value="Late">Late</option>
                  <option value="Absent">Absent</option>
                  <option value="Leave">Leave</option>
                </select>
              </div>

              <span className="text-xs text-[#64748b] self-end sm:self-auto">
                Showing {filteredRecords.length} of {totalDays} sessions
              </span>
            </div>

            {/* Attendance Records Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#1e293b]">
                <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3">Academic Session</th>
                    <th className="px-5 py-3">Class & Section</th>
                    <th className="px-5 py-3">Status</th>
                    <th className="px-5 py-3">Recorded By</th>
                    <th className="px-5 py-3">Remarks / Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-[#94a3b8]">
                        No attendance records found matching the specified filters.
                      </td>
                    </tr>
                  ) : (
                    filteredRecords.map((record) => (
                      <tr key={record.id || record.attendance_id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                          {record.date}
                        </td>
                        <td className="px-5 py-3.5 text-[#64748b]">
                          {record.academicSession || '2026-27'}
                        </td>
                        <td className="px-5 py-3.5 text-[#64748b]">
                          {record.className} - Section {record.sectionName}
                        </td>
                        <td className="px-5 py-3.5">
                          <Badge
                            variant={
                              record.status === 'Present' || (record.status as string) === 'PRESENT'
                                ? 'emerald'
                                : record.status === 'Late' || (record.status as string) === 'LATE'
                                ? 'amber'
                                : record.status === 'Leave' || (record.status as string) === 'EXCUSED' || (record.status as string) === 'LEAVE'
                                ? 'blue'
                                : 'rose'
                            }
                            size="sm"
                          >
                            {record.status}
                          </Badge>
                        </td>
                        <td className="px-5 py-3.5 text-[#64748b]">
                          {record.recordedBy || 'Assigned Faculty'}
                        </td>
                        <td className="px-5 py-3.5 text-[#64748b]">
                          {record.remarks || '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
