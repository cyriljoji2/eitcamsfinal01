import React, { useState, useEffect } from 'react';
import { MessageSquare, BellOff, Calendar, AlertCircle } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Employee } from '../../../types/employee';
import { ProctorMessage } from '../../../types/proctor';
import { proctorRepository } from '../../../services/proctorService';
import { Badge } from '../../ui/Badge';

interface StudentProctorMessagesViewProps {
  student: Student;
  proctorEmployee: Employee | null;
}

export function StudentProctorMessagesView({
  student,
  proctorEmployee,
}: StudentProctorMessagesViewProps) {
  const [messages, setMessages] = useState<ProctorMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadMessages = async () => {
    setIsLoading(true);
    try {
      const msgs = await proctorRepository.getMessagesForStudent(
        student.id || student.registrationNumber,
        proctorEmployee?.id
      );
      setMessages(msgs);
    } catch (e) {
      console.error('Failed to load student proctor messages:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadMessages();
    const unsub = proctorRepository.subscribe(() => {
      loadMessages();
    });
    return unsub;
  }, [student.id, student.registrationNumber, proctorEmployee?.id]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <MessageSquare className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Proctor Messages & Advisories</h1>
              <Badge variant={messages.length > 0 ? 'emerald' : 'neutral'} size="sm">
                {messages.length} Active {messages.length === 1 ? 'Notice' : 'Notices'}
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Direct mentorship communications, attendance warnings, and academic advisories
            </p>
          </div>
        </div>
      </div>

      {messages.length === 0 ? (
        /* Empty State */
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-10 text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <BellOff className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-base font-bold text-[#1e293b]">
              No Messages from Proctor
            </h2>
            <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
              There are currently no individual messages, attendance notifications, or circulars dispatched by{' '}
              {proctorEmployee ? (
                <strong className="text-[#334155]">{proctorEmployee.fullName}</strong>
              ) : (
                'your assigned Proctor'
              )}{' '}
              for student <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong>.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs text-[#475569] text-left">
            <p className="font-semibold text-[#1e293b] mb-1">Direct Communication Channel</p>
            <p className="text-[11px] leading-relaxed">
              Whenever your Proctor sends an academic reminder, schedule review notice, or attendance intervention alert,
              it will be logged chronologically on this board with official timestamps.
            </p>
          </div>
        </div>
      ) : (
        /* Messages List */
        <div className="space-y-4 max-w-3xl">
          {messages.map((m) => (
            <div
              key={m.id}
              className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold text-sm text-[#1e293b]">{m.title}</h3>
                    <Badge
                      variant={
                        m.priority === 'urgent'
                          ? 'rose'
                          : m.priority === 'important'
                          ? 'amber'
                          : 'blue'
                      }
                      size="sm"
                      className="uppercase font-bold text-[10px]"
                    >
                      {m.priority}
                    </Badge>
                  </div>
                  <div className="text-[11px] text-[#64748b] mt-0.5">
                    From: <strong className="text-[#1e293b]">{m.proctorName || m.facultyName}</strong> &bull; {(m.createdAt || m.date || '').split('T')[0]}
                  </div>
                </div>
              </div>

              <div className="text-xs text-[#334155] leading-relaxed whitespace-pre-wrap bg-[#f8fafc] p-3 rounded-lg border border-[#f1f5f9]">
                {m.message}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
