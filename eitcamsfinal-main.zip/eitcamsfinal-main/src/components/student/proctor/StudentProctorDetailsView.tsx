import React from 'react';
import {
  UserCheck,
  Mail,
  Building,
  GraduationCap,
  Calendar,
  AlertCircle,
  Phone,
  Shield,
  Clock,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Employee } from '../../../types/employee';
import { Badge } from '../../ui/Badge';

interface StudentProctorDetailsViewProps {
  student: Student;
  proctorEmployee: Employee | null;
  sectionName?: string;
}

export function StudentProctorDetailsView({
  student,
  proctorEmployee,
  sectionName,
}: StudentProctorDetailsViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <UserCheck className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Faculty Advisor / Proctor Details</h1>
              <Badge variant={proctorEmployee ? 'emerald' : 'neutral'} size="sm">
                {proctorEmployee ? 'Assigned Proctor' : 'Allocation Pending'}
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Mentorship, academic performance monitoring, and institutional student advisement
            </p>
          </div>
        </div>
      </div>

      {proctorEmployee ? (
        /* Real Proctor Information Card */
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                Assigned Faculty Mentor
              </h2>
            </div>
            <span className="text-xs font-mono text-[#64748b]">
              Batch / Section {sectionName || student.section}
            </span>
          </div>

          <div className="p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 pb-6 border-b border-[#e2e8f0]">
              <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
                {proctorEmployee.fullName
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .substring(0, 2)
                  .toUpperCase()}
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-[#1e293b]">{proctorEmployee.fullName}</h3>
                <p className="text-xs text-[#475569] font-medium">
                  {proctorEmployee.designation} • {proctorEmployee.department}
                </p>
                <p className="text-xs font-mono text-[#64748b]">
                  Staff ID: <strong className="text-[#334155]">{proctorEmployee.id}</strong>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 text-xs">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[#475569]">
                  <Mail className="w-4 h-4 text-[#64748b]" />
                  <span>Institutional Email:</span>
                  <strong className="text-[#1e293b] font-mono">{proctorEmployee.email}</strong>
                </div>

                {proctorEmployee.mobile && (
                  <div className="flex items-center gap-2 text-[#475569]">
                    <Phone className="w-4 h-4 text-[#64748b]" />
                    <span>Campus Intercom / Mobile:</span>
                    <strong className="text-[#1e293b] font-mono">{proctorEmployee.mobile}</strong>
                  </div>
                )}

                <div className="flex items-center gap-2 text-[#475569]">
                  <Building className="w-4 h-4 text-[#64748b]" />
                  <span>Department:</span>
                  <strong className="text-[#1e293b]">{proctorEmployee.department}</strong>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[#475569]">
                  <GraduationCap className="w-4 h-4 text-[#64748b]" />
                  <span>Academic Role:</span>
                  <strong className="text-[#1e293b]">Faculty Mentor / Proctor</strong>
                </div>

                <div className="flex items-center gap-2 text-[#475569]">
                  <Clock className="w-4 h-4 text-[#64748b]" />
                  <span>Mentorship Consultation:</span>
                  <strong className="text-[#1e293b]">Designated Office Hours (Mon–Fri)</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Honest Empty State */
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <UserCheck className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-base font-bold text-[#1e293b]">
              No Proctor Assigned for Current Batch
            </h2>
            <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
              A faculty mentor / proctor has not yet been designated for your enrolled section (
              <strong className="text-[#334155]">Section {student.section}</strong>) for the 2026–2027 academic session.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs text-[#475569] text-left">
            <p className="font-semibold text-[#1e293b] mb-1">Notice from Office of Academic Affairs</p>
            <p className="text-[11px] leading-relaxed">
              Faculty advisor allocations are finalized during the initial two weeks of the semester.
              Once your departmental advisor is assigned, their contact particulars and consultation schedule will appear here.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
