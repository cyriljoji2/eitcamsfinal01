import React from 'react';
import {
  Calendar,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
  FileText,
  Receipt,
  GraduationCap,
  Award,
  BookOpen,
  DollarSign,
  ArrowUpRight,
  ShieldCheck,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { AttendanceRecord, AcademicSubject } from '../../types/academic';
import { FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import { Examination, ExamSubjectSchedule, HallTicket, StudentExamResult } from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useActiveAcademicYear } from '../../services/academicCalendarService';

interface StudentOverviewProps {
  student: Student;
  attendanceRecords: AttendanceRecord[];
  feeAssignments: FeeAssignment[];
  payments: PaymentRecord[];
  receipts: FeeReceipt[];
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  hallTickets: HallTicket[];
  results: StudentExamResult[];
  onNavigateTab: (tab: string) => void;
  onViewReceipt: (receipt: FeeReceipt) => void;
  onViewHallTicket: (hallTicket: HallTicket) => void;
  onViewResult: (result: StudentExamResult) => void;
}

export function StudentOverview({
  student,
  attendanceRecords,
  feeAssignments,
  payments,
  receipts,
  examinations,
  schedules,
  hallTickets,
  results,
  onNavigateTab,
  onViewReceipt,
  onViewHallTicket,
  onViewResult,
}: StudentOverviewProps) {
  const { activeAcademicYear } = useActiveAcademicYear();

  // 1. Calculate Attendance Metrics
  const totalDays = attendanceRecords.length;
  const presentDays = attendanceRecords.filter(
    (r) =>
      (r.status as string) === 'Present' ||
      (r.status as string) === 'PRESENT' ||
      (r.status as string) === 'Late' ||
      (r.status as string) === 'LATE'
  ).length;
  const attendancePercentage = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 100;

  // 2. Calculate Fee Metrics
  const totalBilled = feeAssignments.reduce((acc, curr) => acc + (curr.amountDue || 0), 0);
  const totalPaid = feeAssignments.reduce((acc, curr) => acc + (curr.amountPaid || 0), 0);
  const totalWaived = feeAssignments.reduce((acc, curr) => acc + (curr.discountOrWaiver || 0), 0);
  const totalOutstanding = Math.max(0, totalBilled - totalPaid - totalWaived);

  // 3. Filter Upcoming Exams
  const upcomingExams = examinations.filter(
    (e) => e.status === 'Active' || e.status === 'Mark Entry Open' || e.status === 'Draft'
  );

  // Filter Upcoming Schedules
  const upcomingSchedules = schedules
    .filter((s) => {
      const exam = examinations.find((e) => e.id.toLowerCase() === s.examinationId.toLowerCase());
      return exam && exam.status !== 'Archived';
    })
    .sort((a, b) => a.examDate.localeCompare(b.examDate))
    .slice(0, 4);

  // 4. Filter Published Results Only
  const publishedResults = results.filter((r) => {
    const parentExam = examinations.find((e) => e.id.toLowerCase() === r.examinationId.toLowerCase());
    return r.verificationStatus === 'Published' || (parentExam && parentExam.status === 'Published');
  });

  const latestResult = publishedResults[0] || null;

  return (
    <div className="space-y-6">
      {/* Student Welcome Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            {student.fullName
              .split(' ')
              .map((n) => n[0])
              .join('')
              .substring(0, 2)
              .toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-xl font-bold text-[#1e293b]">{student.fullName}</h2>
              <Badge variant="blue" size="sm">
                {student.admissionClass} - Section {student.section}
              </Badge>
              <Badge variant="emerald" size="sm">
                Enrolled
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1 flex items-center gap-3">
              <span>
                Reg No: <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong>
              </span>
              <span>•</span>
              <span>Session: <strong>{activeAcademicYear || '2026–2027'}</strong></span>
              <span>•</span>
              <span>Email: <strong>{student.email}</strong></span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch md:self-auto">
          <Button
            id="student-quick-hall-ticket-btn"
            variant="outline"
            size="sm"
            onClick={() => onNavigateTab('hall-tickets')}
            leftIcon={<Award className="w-4 h-4 text-[#1e3a8a]" />}
            className="flex-1 md:flex-initial"
          >
            Hall Tickets ({hallTickets.length})
          </Button>
          <Button
            id="student-quick-results-btn"
            variant="primary"
            size="sm"
            onClick={() => onNavigateTab('results')}
            leftIcon={<FileText className="w-4 h-4" />}
            className="flex-1 md:flex-initial"
          >
            Report Cards ({publishedResults.length})
          </Button>
        </div>
      </div>

      {/* 4 Core KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Attendance KPI */}
        <div
          id="student-kpi-attendance"
          onClick={() => onNavigateTab('attendance')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#93c5fd] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b]">Overall Attendance</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-[#1e293b]">{attendancePercentage}%</span>
            <span className="text-xs text-emerald-600 font-medium flex items-center gap-0.5">
              <CheckCircle2 className="w-3 h-3" />
              {presentDays}/{totalDays || 1} Days
            </span>
          </div>
          <div className="mt-3 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${
                attendancePercentage >= 85
                  ? 'bg-emerald-500'
                  : attendancePercentage >= 75
                  ? 'bg-amber-500'
                  : 'bg-rose-500'
              }`}
              style={{ width: `${Math.min(100, attendancePercentage)}%` }}
            />
          </div>
        </div>

        {/* Fee Outstanding KPI */}
        <div
          id="student-kpi-fees"
          onClick={() => onNavigateTab('fees')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#93c5fd] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b]">Outstanding Fee</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-[#1e293b]">
              ${totalOutstanding.toLocaleString()}
            </span>
            {totalOutstanding === 0 ? (
              <span className="text-xs text-emerald-600 font-medium">All Clear</span>
            ) : (
              <span className="text-xs text-amber-600 font-medium">Due soon</span>
            )}
          </div>
          <p className="text-[11px] text-[#94a3b8] mt-2">
            Paid: ${totalPaid.toLocaleString()} of ${totalBilled.toLocaleString()}
          </p>
        </div>

        {/* Upcoming Examinations KPI */}
        <div
          id="student-kpi-exams"
          onClick={() => onNavigateTab('examinations')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#93c5fd] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b]">Upcoming Exams</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1e3a8a] flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-[#1e293b]">{upcomingExams.length}</span>
            <span className="text-xs text-[#1e3a8a] font-medium">Scheduled</span>
          </div>
          <p className="text-[11px] text-[#94a3b8] mt-2">
            {upcomingSchedules.length > 0
              ? `Next: ${upcomingSchedules[0].subjectName} (${upcomingSchedules[0].examDate})`
              : 'No upcoming papers'}
          </p>
        </div>

        {/* Published Results KPI */}
        <div
          id="student-kpi-results"
          onClick={() => onNavigateTab('results')}
          className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#93c5fd] transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748b]">Published Results</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-black text-[#1e293b]">{publishedResults.length}</span>
            {latestResult && (
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                Grade: {latestResult.overallGrade}
              </span>
            )}
          </div>
          <p className="text-[11px] text-[#94a3b8] mt-2">
            {latestResult ? latestResult.examinationName : 'No published grades yet'}
          </p>
        </div>
      </div>

      {/* Main Grid: Upcoming Exam Schedule & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Examination Schedule */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Upcoming Exam Timetable</h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('examinations')}
                className="text-xs font-semibold text-[#1e3a8a] hover:underline flex items-center gap-1 cursor-pointer"
              >
                Full Timetable
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {upcomingSchedules.length === 0 ? (
                <div className="py-8 text-center text-[#94a3b8] text-xs">
                  No upcoming examination papers scheduled.
                </div>
              ) : (
                upcomingSchedules.map((sch) => (
                  <div
                    key={sch.id}
                    className="p-3 rounded-lg border border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#1e293b]">{sch.subjectName}</span>
                        <span className="text-[10px] font-mono bg-white px-1.5 py-0.5 rounded border border-[#cbd5e1] text-[#64748b]">
                          {sch.subjectCode}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#64748b] mt-0.5">
                        {sch.examDate} • {sch.startTime} - {sch.endTime}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-[11px] font-medium text-[#475569] block">
                        {sch.roomVenue}
                      </span>
                      <span className="text-[10px] text-[#94a3b8]">Max: {sch.maxMarks} M</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {hallTickets.length > 0 && (
            <div className="mt-5 pt-4 border-t border-[#e2e8f0] flex items-center justify-between bg-blue-50/50 p-3 rounded-lg border">
              <div className="flex items-center gap-2 text-xs text-[#1e3a8a]">
                <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
                <span>Hall ticket is active for upcoming assessments</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onViewHallTicket(hallTickets[0])}
                className="text-xs h-7 px-2.5"
              >
                View Ticket
              </Button>
            </div>
          )}
        </div>

        {/* Recent Attendance Logs */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-[#1e293b]">Recent Attendance Logs</h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('attendance')}
                className="text-xs font-semibold text-[#1e3a8a] hover:underline flex items-center gap-1 cursor-pointer"
              >
                View All
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 space-y-2.5">
              {attendanceRecords.length === 0 ? (
                <div className="py-8 text-center text-[#94a3b8] text-xs">
                  No attendance entries recorded yet for this session.
                </div>
              ) : (
                attendanceRecords.slice(0, 5).map((att) => (
                  <div
                    key={att.id || att.attendance_id}
                    className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 transition-colors border-b border-[#f1f5f9] last:border-none"
                  >
                    <div>
                      <span className="text-xs font-semibold text-[#1e293b] block">{att.date}</span>
                      <span className="text-[11px] text-[#94a3b8] block">
                        {att.className || 'Academic'} - Section {att.sectionName || 'A'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {att.remarks && (
                        <span className="text-[11px] text-[#64748b] max-w-[140px] truncate hidden sm:inline">
                          {att.remarks}
                        </span>
                      )}
                      <Badge
                        variant={
                          (att.status as string) === 'Present' || (att.status as string) === 'PRESENT'
                            ? 'emerald'
                            : (att.status as string) === 'Late' || (att.status as string) === 'LATE'
                            ? 'amber'
                            : (att.status as string) === 'Leave' || (att.status as string) === 'EXCUSED' || (att.status as string) === 'LEAVE'
                            ? 'blue'
                            : 'rose'
                        }
                        size="sm"
                      >
                        {att.status}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#e2e8f0] text-center">
            <span className="text-[11px] text-[#64748b]">
              Classroom roll-call is maintained daily by assigned faculty members.
            </span>
          </div>
        </div>
      </div>

      {/* Lower Row: Latest Result Banner & Recent Receipts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Result Banner */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-[#1e293b]">Latest Published Marksheet</h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('results')}
              className="text-xs font-semibold text-[#1e3a8a] hover:underline flex items-center gap-1 cursor-pointer"
            >
              All Results
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {latestResult ? (
            <div className="mt-4 p-4 rounded-xl bg-linear-to-br from-[#eff6ff] to-[#f8fafc] border border-[#bfdbfe]">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-[#1e3a8a]">{latestResult.examinationName}</span>
                  <p className="text-[11px] text-[#64748b] mt-0.5">
                    Session: {latestResult.academicSession}
                  </p>
                </div>
                <Badge variant={latestResult.resultStatus === 'Pass' ? 'emerald' : 'rose'} size="sm">
                  {(latestResult.resultStatus || 'Published').toUpperCase()}
                </Badge>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-blue-100 text-center">
                <div>
                  <span className="text-[10px] text-[#64748b] block font-medium uppercase">Score</span>
                  <span className="text-sm font-bold text-[#1e293b]">
                    {latestResult.totalMarksObtained ?? latestResult.marksObtained} / {latestResult.totalMaxMarks ?? latestResult.maxMarks}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#64748b] block font-medium uppercase">Percentage</span>
                  <span className="text-sm font-bold text-[#1e293b]">{latestResult.percentage}%</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#64748b] block font-medium uppercase">Grade</span>
                  <span className="text-sm font-black text-[#1e3a8a]">{latestResult.overallGrade}</span>
                </div>
              </div>

              <div className="mt-4 flex justify-end">
                <Button
                  size="sm"
                  variant="primary"
                  onClick={() => onViewResult(latestResult)}
                  className="text-xs"
                >
                  View Official Transcript
                </Button>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-[#94a3b8] text-xs">
              No examination results published yet. Check back once COE finalizes grading.
            </div>
          )}
        </div>

        {/* Recent Payment Receipts */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#e2e8f0]">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-[#1e3a8a]" />
              <h3 className="text-sm font-bold text-[#1e293b]">Recent Payment Receipts</h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigateTab('receipts')}
              className="text-xs font-semibold text-[#1e3a8a] hover:underline flex items-center gap-1 cursor-pointer"
            >
              All Receipts
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 space-y-2.5">
            {receipts.length === 0 ? (
              <div className="py-12 text-center text-[#94a3b8] text-xs">
                No fee payment receipts recorded yet.
              </div>
            ) : (
              receipts.slice(0, 3).map((rec) => (
                <div
                  key={rec.receiptNumber}
                  className="p-3 rounded-lg border border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#1e293b] font-mono">
                        {rec.receiptNumber}
                      </span>
                      <Badge variant="emerald" size="sm">
                        Paid
                      </Badge>
                    </div>
                    <p className="text-[11px] text-[#64748b] mt-0.5">
                      {rec.feeTypeName} • {rec.receiptDate}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-[#1e293b]">
                      ${rec.amountPaid.toLocaleString()}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onViewReceipt(rec)}
                      className="text-xs h-7 px-2"
                    >
                      Receipt
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
