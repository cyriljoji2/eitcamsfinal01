import React from 'react';
import { Award, Clock, Info, Shield, FileText } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentBonafideViewProps {
  student: Student;
}

export function StudentBonafideView({ student }: StudentBonafideViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Award className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Bonafide Certificate Application</h1>
              <Badge variant="neutral" size="sm">
                Administrative Desk
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Official institutional certification of student status for educational loans, passport/visa, and state concessions
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Online Bonafide Portal Offline
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Automated digital issuance of Bonafide Certificates for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> is currently being configured with the institutional digital signature gateway.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>How to Obtain an In-Person Bonafide Certificate</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>
              Submit a formal request letter mentioning the purpose (e.g. Bank Education Loan, Passport, Metro Pass, Visa) at the <strong>Office of Academic Affairs (Student Services Counter 2)</strong>.
            </li>
            <li>Enclose a copy of your student ID card and latest fee receipt.</li>
            <li>Certificates with the Registrar's seal are issued within 2 working days after academic verification.</li>
          </ul>
        </div>

        <div className="pt-2 text-[11px] text-[#94a3b8] flex items-center justify-center gap-2">
          <Shield className="w-3.5 h-3.5" />
          <span>Office of the Registrar • Electrix Institute of Technology</span>
        </div>
      </div>
    </div>
  );
}
