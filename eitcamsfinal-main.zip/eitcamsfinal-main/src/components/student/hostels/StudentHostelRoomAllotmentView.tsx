import React, { useState, useEffect } from 'react';
import {
  Home,
  Clock,
  Info,
  Shield,
  Building,
  BedDouble,
  UserCheck,
  Phone,
  MapPin,
  Calendar,
  AlertCircle,
  FileCheck,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { HostelAllotment, Hostel } from '../../../types/hostel';
import { hostelRepository } from '../../../services/hostelService';
import { Badge } from '../../ui/Badge';

interface StudentHostelRoomAllotmentViewProps {
  student: Student;
}

export function StudentHostelRoomAllotmentView({
  student,
}: StudentHostelRoomAllotmentViewProps) {
  const [allotment, setAllotment] = useState<HostelAllotment | null>(null);
  const [hostelDetails, setHostelDetails] = useState<Hostel | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAllotment = async () => {
      try {
        const alt = await hostelRepository.getActiveAllotmentForStudent(
          student.id || student.registrationNumber
        );
        setAllotment(alt);

        if (alt) {
          const h = await hostelRepository.getHostelById(alt.hostelId);
          setHostelDetails(h);
        } else {
          setHostelDetails(null);
        }
      } catch (err) {
        console.error('Failed to load student hostel allotment:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchAllotment();

    // Subscribe to live changes
    const unsubscribe = hostelRepository.subscribe(() => {
      fetchAllotment();
    });

    return () => {
      unsubscribe();
    };
  }, [student.id, student.registrationNumber]);

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl p-8 border border-[#e2e8f0] shadow-xs text-center space-y-3">
        <div className="w-8 h-8 border-2 border-[#1e3a8a] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-[#64748b]">Verifying residential allotment records...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-blue-50 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-blue-100">
            <Home className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">
                Hostel Room Allotment Order
              </h1>
              <Badge variant={allotment ? 'emerald' : 'neutral'} size="sm">
                {allotment ? 'Official Resident Allocated' : 'No Allocation on File'}
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Official residential hall, block, floor, and bed allotment credentials for the academic session
            </p>
          </div>
        </div>
      </div>

      {allotment ? (
        /* Active Allotment Card */
        <div className="space-y-6">
          {/* Main Allotment Order Slip */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="bg-[#1e3a8a] text-white p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase tracking-wider font-semibold text-blue-200">
                  Residential Hall Identification
                </span>
                <h2 className="text-lg font-bold">{allotment.hostelName}</h2>
              </div>
              <div className="text-left sm:text-right">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-blue-200">
                  Academic Session
                </span>
                <div className="font-mono text-xs font-bold">{allotment.academicSession}</div>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Detailed Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-3.5 bg-[#f8fafc] border border-[#e2e8f0] rounded-lg">
                  <span className="text-[10px] font-bold text-[#64748b] uppercase tracking-wider block mb-1">
                    Building Block / Wing
                  </span>
                  <span className="text-sm font-bold text-[#1e293b]">
                    {allotment.blockName}
                  </span>
                </div>

                <div className="p-3.5 bg-[#f8fafc] border border-[#e2e8f0] rounded-lg">
                  <span className="text-[10px] font-bold text-[#64748b] uppercase tracking-wider block mb-1">
                    Floor Level
                  </span>
                  <span className="text-sm font-bold text-[#1e293b]">
                    {allotment.floorName}
                  </span>
                </div>

                <div className="p-3.5 bg-[#eff6ff] border border-[#bfdbfe] rounded-lg">
                  <span className="text-[10px] font-bold text-[#1e3a8a] uppercase tracking-wider block mb-1">
                    Room Number
                  </span>
                  <span className="text-base font-bold text-[#1e3a8a]">
                    Room {allotment.roomNumber}
                  </span>
                </div>

                <div className="p-3.5 bg-[#ecfdf5] border border-[#a7f3d0] rounded-lg">
                  <span className="text-[10px] font-bold text-[#065f46] uppercase tracking-wider block mb-1">
                    Allocated Bed / Seat
                  </span>
                  <span className="text-base font-bold text-[#065f46]">
                    Bed {allotment.bedNumber}
                  </span>
                </div>
              </div>

              {/* Student and Authorization Meta */}
              <div className="border-t border-[#e2e8f0] pt-5 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <h3 className="font-bold text-[#1e293b] flex items-center gap-1.5">
                    <UserCheck className="w-4 h-4 text-[#1e3a8a]" />
                    <span>Resident Particulars</span>
                  </h3>
                  <div className="bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0] space-y-1 text-[#334155]">
                    <div>
                      <span className="text-[#64748b]">Student Name: </span>
                      <strong className="text-[#1e293b]">{allotment.studentName}</strong>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Registration Number: </span>
                      <strong className="font-mono text-[#1e293b]">{allotment.studentRegistrationNumber}</strong>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Allotment Date: </span>
                      <span className="font-mono">{new Date(allotment.allotmentDate).toLocaleDateString()}</span>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Authorized By: </span>
                      <span>{allotment.allottedBy} (Hostel Office)</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-bold text-[#1e293b] flex items-center gap-1.5">
                    <Building className="w-4 h-4 text-[#1e3a8a]" />
                    <span>Hall Warden & Campus Contact</span>
                  </h3>
                  <div className="bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0] space-y-1 text-[#334155]">
                    <div>
                      <span className="text-[#64748b]">Chief Warden: </span>
                      <strong>{hostelDetails?.wardenName || 'Chief Warden Office'}</strong>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Warden Phone / Ext: </span>
                      <span className="font-mono">{hostelDetails?.wardenContact || 'Ext. 4001 / +91-44-2254-0000'}</span>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Hostel Category: </span>
                      <span className="capitalize">{hostelDetails?.category?.toLowerCase() || 'Standard'} Residential</span>
                    </div>
                    <div>
                      <span className="text-[#64748b]">Campus Address: </span>
                      <span>{hostelDetails?.address || 'EIT Main Campus Residential Enclave'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Guidelines & Safety Policy */}
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-800">
                  <Shield className="w-4 h-4" />
                  <span>Important Residential Hall Regulations</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-amber-800/90 leading-relaxed">
                  <li>Curfew for all undergraduate residential blocks is <strong>09:30 PM</strong> daily.</li>
                  <li>Biometric check-in is mandatory at the block security desk between 08:30 PM and 09:30 PM.</li>
                  <li>Outstations and overnight stays require an approved <strong>Leave / Outing Request</strong> via the Proctor & Hostel Office portal.</li>
                  <li>Room switching or unauthorized bed swapping without Hostel Office clearance is strictly prohibited.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Home className="w-8 h-8" />
          </div>

          <div>
            <h2 className="text-base font-bold text-[#1e293b]">
              No Hostel Room Allocated
            </h2>
            <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
              No official residence hall or room allotment is recorded on file for student{' '}
              <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> for the 2026–2027 academic session.
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-2 mt-4">
            <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
              <Info className="w-4 h-4" />
              <span>Hostel Allotment Inquiries</span>
            </div>
            <p className="text-[11px] text-[#475569] leading-relaxed">
              Students seeking fresh hostel accommodation or room renewal must contact the{' '}
              <strong>Central Hostel Allotment Committee (Chief Warden Office)</strong> with their admission verification slip and residential fee receipt.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
