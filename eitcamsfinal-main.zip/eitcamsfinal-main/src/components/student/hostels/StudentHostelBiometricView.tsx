import React from 'react';
import { Fingerprint, Clock, Info, Shield, Building } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentHostelBiometricViewProps {
  student: Student;
}

export function StudentHostelBiometricView({ student }: StudentHostelBiometricViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Fingerprint className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Hostel Biometric Attendance Report</h1>
              <Badge variant="neutral" size="sm">
                Biometric Gateway Pending
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Nightly attendance roll-call logs and hostel block access turnstile verification
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Biometric Access Logs Not Configured
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Biometric entry logs for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> have not been linked to a residential hall turnstile.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-2 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Residential Attendance Notice</span>
          </div>
          <p className="text-[11px] text-[#475569] leading-relaxed">
            Nightly residential attendance (curfew 09:30 PM) is currently recorded manually by resident floor wardens.
            Automated biometric dashboard sync will activate upon conclusion of hardware calibration.
          </p>
        </div>
      </div>
    </div>
  );
}
