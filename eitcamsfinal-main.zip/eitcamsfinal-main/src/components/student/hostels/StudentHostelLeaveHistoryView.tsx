import React, { useState, useEffect, useMemo } from 'react';
import {
  History,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar,
  FileText,
  Trash2,
  RefreshCw,
  Printer,
  ShieldCheck,
  Building,
  User,
  ArrowRight,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { LeaveOutingRequest } from '../../../types/hostel';
import { hostelLeaveService } from '../../../services/hostelLeaveService';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';
import { LeaveOutingSlipModal } from '../../hostel/LeaveOutingSlipModal';

interface StudentHostelLeaveHistoryViewProps {
  student: Student;
  onNavigateToApply?: () => void;
}

export function StudentHostelLeaveHistoryView({
  student,
  onNavigateToApply,
}: StudentHostelLeaveHistoryViewProps) {
  const [requests, setRequests] = useState<LeaveOutingRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'all' | 'pending' | 'approved' | 'history'>('all');
  const [selectedSlipRequest, setSelectedSlipRequest] = useState<LeaveOutingRequest | null>(null);
  const [isSlipOpen, setIsSlipOpen] = useState(false);

  const loadRequests = async () => {
    setIsLoading(true);
    try {
      const data = await hostelLeaveService.getRequestsForStudent(
        student.id || student.registrationNumber
      );
      setRequests(data);
    } catch (e) {
      console.error('Failed to load leave history:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadRequests();
    const unsub = hostelLeaveService.subscribe(() => {
      loadRequests();
    });
    return () => unsub();
  }, [student.id, student.registrationNumber]);

  const handleCancelRequest = async (requestId: string) => {
    if (!window.confirm('Are you sure you want to cancel this pending application?')) {
      return;
    }

    try {
      await hostelLeaveService.cancelRequestByStudent(
        requestId,
        student.id || student.registrationNumber
      );
      await loadRequests();
    } catch (err: any) {
      alert('Could not cancel request: ' + (err?.message || 'Unknown error'));
    }
  };

  const handleOpenSlip = (req: LeaveOutingRequest) => {
    if (req.status !== 'APPROVED') return;
    setSelectedSlipRequest(req);
    setIsSlipOpen(true);
  };

  const filteredRequests = useMemo(() => {
    return requests.filter((r) => {
      if (activeFilter === 'pending') {
        return r.status === 'PENDING_PROCTOR' || r.status === 'PENDING_HOSTEL';
      }
      if (activeFilter === 'approved') {
        return r.status === 'APPROVED';
      }
      if (activeFilter === 'history') {
        return r.status !== 'PENDING_PROCTOR' && r.status !== 'PENDING_HOSTEL';
      }
      return true;
    });
  }, [requests, activeFilter]);

  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'PENDING_PROCTOR':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-300">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            Stage 1: Awaiting Proctor Endorsement
          </span>
        );
      case 'PENDING_HOSTEL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-300">
            <Clock className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
            Stage 2: Proctor Approved &bull; Pending Hostel Clearance
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Approved &bull; Gate Pass Issued
          </span>
        );
      case 'REJECTED_BY_PROCTOR':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Declined by Proctor
          </span>
        );
      case 'REJECTED_BY_HOSTEL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Declined by Hostel Office
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600 border border-slate-300">
            Cancelled by Student
          </span>
        );
      default:
        return <Badge variant="neutral" size="sm">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <History className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Hostel Leave & Outing History</h1>
              <Badge variant="blue" size="sm">
                {requests.length} Total Applications
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Live status tracking: Proctor endorsement, Hostel Office clearance, and official gate slips.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToApply && (
            <Button
              variant="primary"
              size="sm"
              onClick={onNavigateToApply}
            >
              New Application
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={loadRequests}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-[#e2e8f0] bg-white rounded-t-xl px-4 text-xs font-semibold overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveFilter('all')}
          className={`py-3 px-3 border-b-2 cursor-pointer transition-all shrink-0 ${
            activeFilter === 'all'
              ? 'border-[#1e3a8a] text-[#1e3a8a]'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          All Applications ({requests.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveFilter('pending')}
          className={`py-3 px-3 border-b-2 cursor-pointer transition-all shrink-0 ${
            activeFilter === 'pending'
              ? 'border-[#1e3a8a] text-[#1e3a8a]'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          In Progress ({requests.filter((r) => r.status === 'PENDING_PROCTOR' || r.status === 'PENDING_HOSTEL').length})
        </button>
        <button
          type="button"
          onClick={() => setActiveFilter('approved')}
          className={`py-3 px-3 border-b-2 cursor-pointer transition-all shrink-0 ${
            activeFilter === 'approved'
              ? 'border-[#1e3a8a] text-[#1e3a8a]'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          Approved & Slips Issued ({requests.filter((r) => r.status === 'APPROVED').length})
        </button>
        <button
          type="button"
          onClick={() => setActiveFilter('history')}
          className={`py-3 px-3 border-b-2 cursor-pointer transition-all shrink-0 ${
            activeFilter === 'history'
              ? 'border-[#1e3a8a] text-[#1e3a8a]'
              : 'border-transparent text-[#64748b] hover:text-[#1e293b]'
          }`}
        >
          Completed / Archived
        </button>
      </div>

      {filteredRequests.length === 0 ? (
        <div className="bg-white rounded-b-xl rounded-tr-xl border border-[#e2e8f0] shadow-xs p-10 text-center max-w-xl mx-auto space-y-3">
          <Clock className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-[#1e293b]">No applications found</h3>
          <p className="text-xs text-[#64748b]">
            Submit a leave or day outing request from the "Leave Application" tab to track real-time approval progress.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredRequests.map((req) => {
            const isApproved = req.status === 'APPROVED';
            const isPendingProctor = req.status === 'PENDING_PROCTOR';
            const isPendingHostel = req.status === 'PENDING_HOSTEL';
            const isCanCancel = isPendingProctor || isPendingHostel;

            return (
              <div
                key={req.id}
                className="bg-white border border-[#e2e8f0] rounded-xl p-5 shadow-xs space-y-3 hover:border-[#1e3a8a]/30 transition-colors"
              >
                {/* Header line */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#f1f5f9] pb-3">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="font-mono text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2.5 py-1 rounded">
                      {req.id}
                    </span>
                    <span
                      className={`font-bold text-[11px] uppercase tracking-wider px-2 py-0.5 rounded ${
                        req.requestType === 'outing'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {req.requestType === 'leave' ? 'Overnight Leave' : 'Day Outing'}
                    </span>
                    {renderStatusBadge(req.status || req.approvalStatus || 'PENDING')}
                  </div>

                  <div className="text-[11px] text-[#64748b]">
                    Applied:{' '}
                    <strong>
                      {req.createdAt ? new Date(req.createdAt).toLocaleDateString() : '—'}
                    </strong>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs text-[#475569]">
                  <div>
                    <span className="text-[#94a3b8] block text-[11px]">Period / Timings</span>
                    <strong className="text-[#1e293b]">
                      {req.requestType === 'leave'
                        ? `${req.fromDate} to ${req.toDate}`
                        : `${req.fromDate} (${req.fromTime || '09:00'} - ${req.toTime || '18:00'})`}
                    </strong>
                  </div>

                  <div>
                    <span className="text-[#94a3b8] block text-[11px]">Hostel Residence</span>
                    <strong className="text-[#1e293b]">
                      {req.hostelName || 'Hostel'} &bull; Rm {req.roomNumber || '-'} (Bed {req.bedNumber || '-'})
                    </strong>
                  </div>

                  <div>
                    <span className="text-[#94a3b8] block text-[11px]">Destination</span>
                    <strong className="text-[#1e293b]">
                      {req.destination || req.destinationAddress || 'Local Area'}
                    </strong>
                  </div>

                  <div>
                    <span className="text-[#94a3b8] block text-[11px]">Faculty Proctor</span>
                    <strong className="text-[#1e293b]">{req.proctorName}</strong>
                  </div>
                </div>

                {/* Purpose */}
                <div className="text-xs text-[#334155] bg-[#f8fafc] p-3 rounded-lg border border-[#f1f5f9]">
                  <span className="font-semibold text-[#64748b]">Reason / Purpose: </span>
                  {req.reason || req.purpose}
                </div>

                {/* Stage 1: Proctor Review Remarks */}
                {req.proctorRemarks && (
                  <div
                    className={`text-xs p-3 rounded-lg border flex items-start gap-2.5 ${
                      req.status === 'REJECTED_BY_PROCTOR'
                        ? 'bg-rose-50 border-rose-200 text-rose-900'
                        : 'bg-blue-50 border-blue-200 text-blue-900'
                    }`}
                  >
                    {req.status === 'REJECTED_BY_PROCTOR' ? (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-bold">
                        Stage 1 Proctor Feedback ({req.proctorName || 'Proctor'}):{' '}
                      </span>
                      <span>{req.proctorRemarks}</span>
                      {req.proctorActionDate && (
                        <span className="block text-[10px] opacity-75 mt-0.5">
                          Action Date: {new Date(req.proctorActionDate).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Stage 2: Hostel Office Review Remarks */}
                {req.hostelRemarks && (
                  <div
                    className={`text-xs p-3 rounded-lg border flex items-start gap-2.5 ${
                      req.status === 'REJECTED_BY_HOSTEL'
                        ? 'bg-rose-50 border-rose-200 text-rose-900'
                        : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    }`}
                  >
                    {req.status === 'REJECTED_BY_HOSTEL' ? (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <span className="font-bold">
                        Stage 2 Hostel Office Clearance ({req.hostelActionBy || 'Hostel Warden'}):{' '}
                      </span>
                      <span>{req.hostelRemarks}</span>
                      {req.hostelActionDate && (
                        <span className="block text-[10px] opacity-75 mt-0.5">
                          Approved Date: {new Date(req.hostelActionDate).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {/* Action Row */}
                <div className="pt-2 flex items-center justify-between border-t border-[#f1f5f9]">
                  <div>
                    {isApproved && req.slipNumber && (
                      <span className="font-mono text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        Pass Slip: {req.slipNumber}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {isCanCancel && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCancelRequest(req.id)}
                        leftIcon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                        className="text-rose-600 hover:bg-rose-50 hover:border-rose-300 text-xs"
                      >
                        Cancel Application
                      </Button>
                    )}

                    {isApproved && (
                      <Button
                        size="sm"
                        variant="primary"
                        onClick={() => handleOpenSlip(req)}
                        leftIcon={<Printer className="w-3.5 h-3.5" />}
                        className="bg-emerald-700 hover:bg-emerald-800 text-xs"
                      >
                        View & Print Official Slip
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Official Leave Slip Modal */}
      {isSlipOpen && selectedSlipRequest && (
        <LeaveOutingSlipModal
          isOpen={isSlipOpen}
          onClose={() => {
            setIsSlipOpen(false);
            setSelectedSlipRequest(null);
          }}
          request={selectedSlipRequest}
        />
      )}
    </div>
  );
}
