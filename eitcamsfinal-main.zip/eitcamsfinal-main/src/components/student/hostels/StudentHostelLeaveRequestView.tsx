import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Send,
  UserCheck,
  AlertCircle,
  CheckCircle2,
  Building,
  Phone,
  MapPin,
  ShieldCheck,
  FileText,
  AlertTriangle,
  Info,
  Check,
  ArrowRight,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Employee } from '../../../types/employee';
import { HostelAllotment } from '../../../types/hostel';
import { ProctorAssignment, LeaveOutingRequestType, LeaveReasonCategory } from '../../../types/proctor';
import { hostelRepository } from '../../../services/hostelService';
import { proctorRepository } from '../../../services/proctorService';
import { hostelLeaveService } from '../../../services/hostelLeaveService';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentHostelLeaveRequestViewProps {
  student: Student;
  proctorEmployee?: Employee | null;
  onSuccess?: () => void;
  onNavigateToHistory?: () => void;
}

export function StudentHostelLeaveRequestView({
  student,
  proctorEmployee,
  onSuccess,
  onNavigateToHistory,
}: StudentHostelLeaveRequestViewProps) {
  const [activeAllotment, setActiveAllotment] = useState<HostelAllotment | null>(null);
  const [activeProctor, setActiveProctor] = useState<ProctorAssignment | null>(null);
  const [isCheckingEligibility, setIsCheckingEligibility] = useState(true);

  // Form fields
  const [requestType, setRequestType] = useState<LeaveOutingRequestType>('leave');
  const [fromDate, setFromDate] = useState('');
  const [fromTime, setFromTime] = useState('09:00');
  const [toDate, setToDate] = useState('');
  const [toTime, setToTime] = useState('18:00');
  const [reasonCategory, setReasonCategory] = useState<LeaveReasonCategory>('family');
  const [reason, setReason] = useState('');
  const [destination, setDestination] = useState('');
  const [contactNumber, setContactNumber] = useState(student.mobile || '');
  const [emergencyContact, setEmergencyContact] = useState(
    (student as any).parentMobile || (student as any).guardianMobile || student.mobile || ''
  );
  const [remarks, setRemarks] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Load active allotment and active proctor
  useEffect(() => {
    const checkEligibility = async () => {
      try {
        setIsCheckingEligibility(true);
        const [allotment, proctorAsg] = await Promise.all([
          hostelRepository.getActiveAllotmentForStudent(student.id || student.registrationNumber),
          proctorRepository.getActiveAssignmentForStudent(student.id || student.registrationNumber),
        ]);

        setActiveAllotment(allotment);
        setActiveProctor(proctorAsg);
      } catch (err) {
        console.error('Failed to verify hostel/proctor eligibility:', err);
      } finally {
        setIsCheckingEligibility(false);
      }
    };

    checkEligibility();

    const unsubHostel = hostelRepository.subscribe(() => checkEligibility());
    const unsubProctor = proctorRepository.subscribe(() => checkEligibility());

    return () => {
      unsubHostel();
      unsubProctor();
    };
  }, [student.id, student.registrationNumber]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    // Strict validation
    if (!activeAllotment) {
      setSubmitError('You do not have an active hostel allotment. Submission blocked.');
      return;
    }

    if (!activeProctor) {
      setSubmitError(
        'No active Faculty Proctor assigned. Institutional regulations require Proctor endorsement before hostel leave can be requested.'
      );
      return;
    }

    if (!fromDate || (requestType === 'leave' && !toDate) || !reason.trim() || !destination.trim()) {
      setSubmitError('Please complete all required fields.');
      return;
    }

    if (!contactNumber.trim()) {
      setSubmitError('Please provide a valid contact number.');
      return;
    }

    setIsSubmitting(true);

    try {
      const created = await hostelLeaveService.createRequest({
        requestType,
        studentId: student.id,
        studentRegistrationNumber: student.registrationNumber,
        studentName: student.fullName,
        studentClass: student.admissionClass,
        studentSection: student.section,
        program: student.admissionClass,
        batch: (student as any).academicSession || (student as any).batch || '2023-2027',
        hostelAllotmentId: activeAllotment.id,
        hostelId: activeAllotment.hostelId,
        hostelName: activeAllotment.hostelName,
        blockId: activeAllotment.blockId,
        blockName: activeAllotment.blockName,
        floorName: activeAllotment.floorName,
        roomId: activeAllotment.roomId,
        roomNumber: activeAllotment.roomNumber,
        bedId: activeAllotment.bedId,
        bedNumber: activeAllotment.bedNumber,
        proctorId: activeProctor.facultyId,
        proctorName: activeProctor.facultyName,
        proctorDepartment: activeProctor.facultyDepartment,
        fromDate,
        fromTime,
        toDate: requestType === 'leave' ? toDate : fromDate,
        toTime,
        reason: reason.trim(),
        reasonCategory,
        destination: destination.trim(),
        contactNumber: contactNumber.trim(),
        emergencyContact: emergencyContact.trim() || undefined,
        parentContactNumber: emergencyContact.trim() || undefined,
        remarks: remarks.trim() || undefined,
      });

      setSubmittedId(created.id);
      setIsSubmitting(false);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setSubmitError(err.message || 'Failed to submit application');
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setSubmittedId(null);
    setReason('');
    setDestination('');
    setFromDate('');
    setToDate('');
    setRemarks('');
    setSubmitError(null);
  };

  if (isCheckingEligibility) {
    return (
      <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-3">
        <div className="w-8 h-8 border-2 border-[#1e3a8a] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-[#64748b]">Verifying hostel residency and proctor mentorship status...</p>
      </div>
    );
  }

  // REQUIREMENT 2: Ineligibility - No Active Hostel Allotment
  if (!activeAllotment) {
    return (
      <div className="space-y-6">
        {/* Header Banner */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center text-xl font-bold shrink-0">
              <Building className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#1e293b]">Hostel Outing & Leave Application</h1>
              <p className="text-xs text-[#64748b] mt-1">
                Residential leave and day outing clearance gateway
              </p>
            </div>
          </div>
        </div>

        {/* Blocking Warning Card */}
        <div className="bg-white rounded-xl border border-amber-300 p-8 shadow-xs text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-lg font-bold text-slate-900">
              You do not have an active hostel allotment.
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed max-w-lg mx-auto">
              Campus leave and day outing applications are strictly restricted to resident students with a verified room and bed allotment on file. If you have secured campus accommodation, please review your status under <strong>Hostels &rarr; Hostel Room Allotment</strong> or contact the Hostel Office.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 text-left max-w-md mx-auto space-y-1">
            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-[#1e3a8a]" /> Student Verification Profile:
            </div>
            <div>Name: <strong>{student.fullName}</strong></div>
            <div>Registration Number: <strong className="font-mono">{student.registrationNumber}</strong></div>
            <div>Program: <strong>{student.admissionClass}</strong></div>
            <div>Hostel Status: <span className="text-rose-600 font-bold">No Active Room Assigned</span></div>
          </div>
        </div>
      </div>
    );
  }

  // REQUIREMENT 4: Ineligibility - No Active Proctor Assignment
  if (!activeProctor) {
    return (
      <div className="space-y-6">
        {/* Header Banner */}
        <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center text-xl font-bold shrink-0">
              <UserCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#1e293b]">Hostel Outing & Leave Application</h1>
              <p className="text-xs text-[#64748b] mt-1">
                Residential leave and day outing clearance gateway
              </p>
            </div>
          </div>
        </div>

        {/* Blocking Warning Card */}
        <div className="bg-white rounded-xl border border-blue-300 p-8 shadow-xs text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-blue-50 border border-blue-200 text-[#1e3a8a] flex items-center justify-center mx-auto">
            <UserCheck className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h2 className="text-lg font-bold text-slate-900">
              No Active Faculty Proctor Assigned
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed max-w-lg mx-auto">
              Per campus safety regulations, all student leave requests must be endorsed by your designated Faculty Proctor before Hostel Office clearance can be granted.
              No active Proctor assignment was found for your student profile. Please contact the Academic Office to complete your proctor allocation.
            </p>
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 text-left max-w-md mx-auto space-y-1">
            <div className="font-semibold text-slate-900 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-[#1e3a8a]" /> Active Residence Verified:
            </div>
            <div>Hostel: <strong>{activeAllotment.hostelName}</strong> ({activeAllotment.blockName})</div>
            <div>Room / Bed: <strong>Room {activeAllotment.roomNumber} &bull; Bed {activeAllotment.bedNumber}</strong></div>
            <div>Proctor Mentorship: <span className="text-amber-700 font-bold">Unassigned</span></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <Calendar className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Hostel Outing & Leave Application</h1>
              <Badge variant="blue" size="sm">
                Proctor &rarr; Hostel Office Gateway
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Submit residential leave or day outing pass requests. Automatically routed to your active Proctor and Hostel Office.
            </p>
          </div>
        </div>
      </div>

      {submittedId ? (
        /* Submission Confirmation Card */
        <div className="bg-white rounded-xl border border-emerald-200 shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h2 className="text-lg font-bold text-[#1e293b]">Application Submitted Successfully</h2>
            <div className="text-xs text-[#64748b]">
              Your Request Tracking ID is{' '}
              <span className="font-mono font-bold text-[#1e3a8a] text-sm">{submittedId}</span>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-xs text-blue-900 text-left space-y-2">
            <div className="flex items-center gap-2 font-bold">
              <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
              <span>Two-Stage Institutional Approval Process:</span>
            </div>
            <ol className="list-decimal pl-5 space-y-1.5 text-[11px] text-[#1e3a8a]">
              <li>
                <strong>Stage 1 (Current):</strong> Pending endorsement from your designated Proctor{' '}
                <strong>{activeProctor.facultyName}</strong> ({activeProctor.facultyDepartment || 'Faculty Mentor'}).
              </li>
              <li>
                <strong>Stage 2:</strong> Upon Proctor endorsement, your application automatically routes to the{' '}
                <strong>Hostel Administration Office</strong> for official gate clearance and slip issuance.
              </li>
            </ol>
          </div>

          <div className="flex items-center justify-center gap-3 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleResetForm}
            >
              Submit Another Request
            </Button>
            {onNavigateToHistory && (
              <Button
                variant="primary"
                size="sm"
                onClick={onNavigateToHistory}
                rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
              >
                View in Leave History
              </Button>
            )}
          </div>
        </div>
      ) : (
        /* Application Form */
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Automatically Attached Profile & Residence Details */}
          <div className="bg-white rounded-xl border border-[#cbd5e1] p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Verified Student & Residence Profile (System-Attached)
              </div>
              <span className="text-[10px] bg-emerald-50 text-emerald-800 font-bold px-2 py-0.5 rounded border border-emerald-200">
                ACTIVE HOSTELLER & PROCTOR VERIFIED
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              {/* Student Identity */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Student Identity
                </span>
                <div className="font-bold text-slate-900">{student.fullName}</div>
                <div className="font-mono text-[#1e3a8a] font-semibold">
                  {student.registrationNumber}
                </div>
                <div className="text-slate-500 text-[11px]">
                  {student.admissionClass} &bull; Section {student.section}
                </div>
              </div>

              {/* Active Hostel Residence */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Active Hostel Allotment
                </span>
                <div className="font-bold text-slate-900">{activeAllotment.hostelName}</div>
                <div className="text-slate-700">
                  {activeAllotment.blockName} &bull; {activeAllotment.floorName || 'Floor'}
                </div>
                <div className="font-mono font-bold text-[#1e3a8a] text-[11px]">
                  Room: {activeAllotment.roomNumber} &bull; Bed: {activeAllotment.bedNumber}
                </div>
              </div>

              {/* Designated Proctor */}
              <div className="p-3 bg-blue-50/50 border border-blue-200 rounded-lg space-y-1 sm:col-span-2 lg:col-span-1">
                <span className="text-[10px] font-bold text-[#1e3a8a] uppercase tracking-wider block">
                  Designated Faculty Proctor
                </span>
                <div className="font-bold text-slate-900">{activeProctor.facultyName}</div>
                <div className="text-slate-600 text-[11px]">
                  {activeProctor.facultyDepartment || 'Faculty Mentor'} &bull; ID: {activeProctor.facultyId}
                </div>
                <div className="text-[10px] text-blue-700 font-semibold pt-0.5">
                  &bull; Request will route directly to this faculty member
                </div>
              </div>
            </div>
          </div>

          {/* Request Particulars Card */}
          <div className="bg-white rounded-xl border border-[#cbd5e1] p-6 shadow-xs space-y-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2.5">
              Request Details
            </h3>

            {/* Request Type Selector */}
            <div>
              <label className="block font-semibold text-slate-800 mb-2">
                Type of Pass <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label
                  className={`p-3.5 rounded-xl border cursor-pointer flex items-start gap-3 transition-all ${
                    requestType === 'leave'
                      ? 'bg-blue-50/60 border-[#1e3a8a] ring-2 ring-[#1e3a8a]/20'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="requestType"
                    checked={requestType === 'leave'}
                    onChange={() => setRequestType('leave')}
                    className="mt-0.5 text-[#1e3a8a] focus:ring-[#1e3a8a]"
                  />
                  <div>
                    <div className="font-bold text-slate-900">Overnight / Extended Leave</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Visiting home, weekend stay, or multiple-day leave requiring night-out clearance.
                    </div>
                  </div>
                </label>

                <label
                  className={`p-3.5 rounded-xl border cursor-pointer flex items-start gap-3 transition-all ${
                    requestType === 'outing'
                      ? 'bg-purple-50/60 border-purple-600 ring-2 ring-purple-500/20'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="requestType"
                    checked={requestType === 'outing'}
                    onChange={() => setRequestType('outing')}
                    className="mt-0.5 text-purple-600 focus:ring-purple-500"
                  />
                  <div>
                    <div className="font-bold text-slate-900">Local Day Outing Pass</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Same-day pass for local errands, coaching, shopping, or town visit returning before curfew.
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* Dates & Times */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  Departure Date <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">Departure Time</label>
                <input
                  type="time"
                  value={fromTime}
                  onChange={(e) => setFromTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>

              {requestType === 'leave' && (
                <div>
                  <label className="block font-semibold text-slate-800 mb-1">
                    Return Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={toDate}
                    min={fromDate}
                    onChange={(e) => setToDate(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  {requestType === 'leave' ? 'Return Time' : 'Expected Return Time (Curfew)'}
                </label>
                <input
                  type="time"
                  value={toTime}
                  onChange={(e) => setToTime(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>
            </div>

            {/* Destination & Category */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold text-slate-800 mb-1">Reason Category</label>
                <select
                  value={reasonCategory}
                  onChange={(e) => setReasonCategory(e.target.value as LeaveReasonCategory)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                >
                  <option value="family">Family / Home Visit</option>
                  <option value="medical">Medical / Health Appointment</option>
                  <option value="academic">Academic / Competitive Exam / Conference</option>
                  <option value="weekend">Weekend Outing</option>
                  <option value="emergency">Family Emergency</option>
                  <option value="personal">Personal / Shopping / Local Errands</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-800 mb-1">
                  Destination / Place of Visit <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Home Town (Coimbatore), Local Town Market, City Hospital..."
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
                />
              </div>
            </div>

            {/* Reason / Purpose */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Detailed Reason & Purpose <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
                rows={3}
                placeholder="State the specific purpose of leave or outing for Proctor review and gate clearance..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
              />
            </div>

            {/* Contacts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  Student Mobile Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  required
                  placeholder="10-digit mobile number"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  Emergency / Parent-Guardian Contact <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  value={emergencyContact}
                  onChange={(e) => setEmergencyContact(e.target.value)}
                  required
                  placeholder="Parent or guardian phone"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20 font-mono"
                />
              </div>
            </div>

            {/* Additional Remarks */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Additional Remarks / Accompanying Persons (Optional)
              </label>
              <input
                type="text"
                placeholder="Optional notes for Proctor or Hostel Warden..."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white text-slate-800 focus:ring-2 focus:ring-[#1e3a8a]/20"
              />
            </div>

            {submitError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{submitError}</span>
              </div>
            )}

            <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
              <div className="text-[11px] text-slate-500">
                Will be submitted to Proctor <strong className="text-slate-800">{activeProctor.facultyName}</strong>
              </div>

              <Button
                type="submit"
                variant="primary"
                size="md"
                disabled={isSubmitting}
                leftIcon={<Send className="w-4 h-4" />}
              >
                {isSubmitting ? 'Submitting Application...' : 'Submit Leave Application'}
              </Button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
