import React from 'react';
import { Landmark, AlertCircle, Info, Shield, Building } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentBankInfoViewProps {
  student: Student;
}

export function StudentBankInfoView({ student }: StudentBankInfoViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Landmark className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Student Bank Account Information</h1>
              <Badge variant="neutral" size="sm">
                No Record On File
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Direct disbursement mandate for institutional scholarships, awards, and fee reimbursements
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty State Card */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Landmark className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            No Bank Account Mandate Registered
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            No institutional bank account particulars are currently linked to student profile{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> for the 2026–2027 academic session.
          </p>
        </div>

        <div className="bg-blue-50/60 border border-blue-200 rounded-lg p-4 text-left text-xs text-blue-900 space-y-2 mt-4">
          <div className="flex items-center gap-2 font-semibold">
            <Info className="w-4 h-4 text-[#1e3a8a]" />
            <span>How to Register Your Bank Account Details</span>
          </div>
          <p className="text-[11px] text-blue-800 leading-relaxed">
            Students eligible for government scholarships, merit stipends, or fee refunds must submit
            a self-attested photocopy of their bank passbook / cancelled cheque bearing their name,
            Account Number, and IFSC code to the <strong>EIT Finance & Accounts Office (Admin Block, Room 104)</strong>.
          </p>
        </div>

        <div className="pt-2 text-[11px] text-[#94a3b8] flex items-center justify-center gap-2">
          <Shield className="w-3.5 h-3.5" />
          <span>Banking information will be verified against institutional compliance mandates upon submission.</span>
        </div>
      </div>
    </div>
  );
}
