import React from 'react';
import {
  FileCheck,
  Building,
  CheckCircle2,
  Calendar,
  User,
  Clock,
  Shield,
  Printer,
  Download,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentAcknowledgementViewProps {
  student: Student;
}

export function StudentAcknowledgementView({ student }: StudentAcknowledgementViewProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <FileCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Admission Acknowledgement</h1>
                <Badge variant="emerald" size="sm">
                  Official Verification Record
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                EIT Enrollment Confirmation Slip & Document Submission Acknowledgement
              </p>
            </div>
          </div>

          <Button
            id="ack-print-btn"
            variant="outline"
            size="sm"
            onClick={handlePrint}
            leftIcon={<Printer className="w-4 h-4 text-[#1e3a8a]" />}
          >
            Print Acknowledgement
          </Button>
        </div>
      </div>

      {/* Official Acknowledgement Slip */}
      <div className="bg-white rounded-xl border border-[#cbd5e1] shadow-xs p-6 md:p-8 space-y-6 relative overflow-hidden print:border-none print:shadow-none">
        {/* Header Institution */}
        <div className="border-b-2 border-[#1e3a8a] pb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <span className="text-[10px] font-bold tracking-widest text-[#64748b] uppercase block">
              Office of Student Admissions & Enrollment
            </span>
            <h2 className="text-xl font-bold text-[#1e3a8a] tracking-tight">
              ELECTRIX INSTITUTE OF TECHNOLOGY
            </h2>
            <p className="text-xs text-[#475569]">
              Campus Institutional ERP • Official Enrolment & Document Verification Slip
            </p>
          </div>
          <div className="text-left sm:text-right">
            <span className="text-[10px] font-mono text-[#64748b] block">Acknowledgement ID</span>
            <span className="text-xs font-mono font-bold text-[#1e293b]">
              ACK-{student.registrationNumber}-2026
            </span>
            <span className="text-[10px] text-[#64748b] block mt-0.5">
              Issued Date: {student.admissionDate || '2026-06-15'}
            </span>
          </div>
        </div>

        {/* Candidate & Enrolment Particulars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#f8fafc] p-4 rounded-lg border border-[#e2e8f0]">
          <div className="space-y-2 text-xs">
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Student Full Name:</span>
              <span className="font-bold text-[#1e293b]">{student.fullName}</span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Registration Number:</span>
              <span className="font-mono font-bold text-[#1e3a8a]">{student.registrationNumber}</span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Program / Degree:</span>
              <span className="font-medium text-[#1e293b]">{student.admissionClass}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Assigned Batch / Section:</span>
              <span className="font-medium text-[#1e293b]">Section {student.section}</span>
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Admission Status:</span>
              <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                {student.admissionStatus}
              </span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Admission Category:</span>
              <span className="font-medium text-[#1e293b]">{student.admissionType}</span>
            </div>
            <div className="flex justify-between border-b border-slate-200 pb-1.5">
              <span className="text-[#64748b]">Academic Session:</span>
              <span className="font-medium text-[#1e293b]">{student.academicSession || '2026-27'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#64748b]">Guardian / Parent:</span>
              <span className="font-medium text-[#1e293b]">{student.fatherName || student.guardianName || 'On Record'}</span>
            </div>
          </div>
        </div>

        {/* Verified Documents Checklist */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
            Mandatory Institutional Documents Verified
          </h3>
          <div className="border border-[#e2e8f0] rounded-lg overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f1f5f9] text-[#475569] font-semibold border-b border-[#e2e8f0]">
                <tr>
                  <th className="p-3">#</th>
                  <th className="p-3">Document Particulars</th>
                  <th className="p-3">Verification Status</th>
                  <th className="p-3 text-right">Verification Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {(student.documents && student.documents.length > 0 ? student.documents : [
                  { documentType: 'Birth Certificate', status: 'Verified', verificationDate: student.admissionDate },
                  { documentType: 'Previous School/Transfer Certificate', status: 'Verified', verificationDate: student.admissionDate },
                  { documentType: 'Previous Marksheet', status: 'Verified', verificationDate: student.admissionDate },
                  { documentType: 'Address/Residence Proof', status: 'Verified', verificationDate: student.admissionDate },
                  { documentType: 'Student Photograph', status: 'Verified', verificationDate: student.admissionDate }
                ]).map((doc: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-3 text-[#64748b] font-mono">{idx + 1}</td>
                    <td className="p-3 font-medium text-[#1e293b]">{doc.documentType}</td>
                    <td className="p-3">
                      <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium text-[11px]">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        {doc.status || 'Verified'}
                      </span>
                    </td>
                    <td className="p-3 text-right text-[#64748b] font-mono">
                      {doc.verificationDate || student.admissionDate || '2026-06-15'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Institutional Endorsement Seal */}
        <div className="border-t border-[#e2e8f0] pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-[#64748b]">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#1e3a8a]" />
            <span>Cryptographically generated and stored in EIT Institutional Records.</span>
          </div>
          <div className="text-right">
            <span className="font-bold text-[#1e293b] block">Controller of Admissions</span>
            <span>Electrix Institute of Technology</span>
          </div>
        </div>
      </div>
    </div>
  );
}
