import React from 'react';
import {
  ShieldCheck,
  KeyRound,
  User,
  Mail,
  Lock,
  Calendar,
  AlertCircle,
  ArrowRight,
  Shield,
  CheckCircle2,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentCredentialsViewProps {
  student: Student;
  onNavigateToChangePassword?: () => void;
}

export function StudentCredentialsView({
  student,
  onNavigateToChangePassword,
}: StudentCredentialsViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <KeyRound className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Credentials</h1>
                <Badge variant={student.accountStatus === 'active' ? 'emerald' : 'neutral'} size="sm">
                  {student.accountStatus === 'active' ? 'Active Account' : 'Inactive'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass}
              </p>
            </div>
          </div>

          <Button
            id="credentials-change-pwd-btn"
            variant="outline"
            size="sm"
            onClick={onNavigateToChangePassword}
            leftIcon={<Lock className="w-4 h-4 text-[#1e3a8a]" />}
          >
            Change Password
          </Button>
        </div>
      </div>

      {/* Account Security Information Card */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
              Authentication & Security Details
            </h2>
          </div>
          <span className="text-xs font-mono text-[#64748b]">EIT Single Sign-On</span>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <span className="text-xs font-semibold text-[#64748b] block">Portal Username</span>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-sm font-mono font-bold text-[#1e293b] bg-slate-100 px-2.5 py-1 rounded border border-slate-200">
                  {student.username || student.registrationNumber}
                </span>
              </div>
              <p className="text-[11px] text-[#94a3b8] mt-1">
                Use your official registration number as your username.
              </p>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#64748b] block">Registered Institutional Email</span>
              <div className="mt-1 flex items-center gap-2 text-xs font-mono text-[#334155]">
                <Mail className="w-3.5 h-3.5 text-[#64748b]" />
                <span>{student.email || `${student.registrationNumber.toLowerCase()}@eit.edu`}</span>
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#64748b] block">Account Status</span>
              <div className="mt-1 flex items-center gap-2">
                <Badge variant={student.accountStatus === 'active' ? 'emerald' : 'neutral'} size="sm">
                  {student.accountStatus === 'active' ? 'Verified & Active' : 'Pending Verification'}
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <span className="text-xs font-semibold text-[#64748b] block">Password Status</span>
              <div className="mt-1">
                {student.isTemporaryPassword ? (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-900">
                    <p className="font-semibold flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                      Temporary Password In Use
                    </p>
                    <p className="text-[11px] text-amber-800 mt-1">
                      You are using the default admission password. It is strongly recommended to set a custom permanent password.
                    </p>
                  </div>
                ) : (
                  <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-900">
                    <p className="font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Permanent Password Active
                    </p>
                    <p className="text-[11px] text-emerald-800 mt-1">
                      Your permanent password has been established. Last changed: {student.passwordChangedAt ? new Date(student.passwordChangedAt).toLocaleDateString() : 'Active session'}.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-[#64748b] block">Portal Access Level</span>
              <span className="text-xs font-medium text-[#1e293b] mt-1 block">
                Standard Student Portal (Academics, Examination, Finance & Hostels)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Institutional Security Notice */}
      <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5">
        <Shield className="w-5 h-5 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="text-xs text-[#475569] space-y-1">
          <p className="font-semibold text-[#1e293b]">Institutional Information Security Notice</p>
          <p>
            Do not share your student portal credentials with anyone. All sessions, course selections,
            and examination activities are logged and auditable under Electrix Institute of Technology security policies.
          </p>
        </div>
      </div>
    </div>
  );
}
