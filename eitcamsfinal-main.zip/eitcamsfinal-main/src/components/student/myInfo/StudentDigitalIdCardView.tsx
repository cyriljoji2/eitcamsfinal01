import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Printer,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  Calendar,
  Building,
  User,
  QrCode,
  Sparkles,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { IdCardRecord } from '../../../types/itDepartment';
import { itRepository } from '../../../services/itService';
import { Button } from '../../ui/Button';
import { Badge } from '../../ui/Badge';

interface StudentDigitalIdCardViewProps {
  student: Student;
}

export function StudentDigitalIdCardView({ student }: StudentDigitalIdCardViewProps) {
  const [card, setCard] = useState<IdCardRecord | null>(null);
  const [isReporting, setIsReporting] = useState(false);
  const [reportReason, setReportReason] = useState<'LOST' | 'DAMAGED'>('LOST');
  const [reportNotes, setReportNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const studentId = student.student_id || student.id || student.registrationNumber || '';
  const regNumber = student.registration_number || student.registrationNumber || '';
  const fullName = student.fullName || `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
  const courseName = student.course_code || student.program || 'B.Tech Electrical & Electronics';
  const department = student.department || (courseName.includes('CSE') ? 'Computer Science & Engineering' : 'Electrical & Electronics');
  const batchYear = student.admission_batch || student.batch || '2026';
  const photoUrl = student.photo_url || student.photoUrl;

  const loadCard = () => {
    let found = itRepository.getIdCardByRegistration(regNumber);
    if (!found) {
      found = itRepository.getIdCardByHolderId(studentId);
    }
    if (!found) {
      // Auto-generate if not yet generated
      found = itRepository.generateIdCardForStudent({
        student_id: studentId,
        registration_number: regNumber,
        full_name: fullName,
        course_name: courseName,
        department: department,
        batch_year: batchYear,
        photo_url: photoUrl,
      });
    }
    setCard(found);
  };

  useEffect(() => {
    loadCard();
  }, [student, studentId, regNumber]);

  const handlePrint = () => {
    window.print();
  };

  const handleReportReissue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!card) return;

    setIsSubmitting(true);
    try {
      await itRepository.reissueIdCard({
        original_card_id: card.card_id,
        reason: reportReason,
        notes: `Student self-report: ${reportNotes || 'Reported via Student Portal'}`,
        operator_id: studentId,
        operator_role: 'STUDENT',
      });

      setMessage({
        type: 'success',
        text: `Re-issuance request for card ${card.card_id} submitted to IT Department.`,
      });
      setIsReporting(false);
      setReportNotes('');
      loadCard();
    } catch (err: any) {
      setMessage({
        type: 'error',
        text: err.message || 'Failed to submit re-issuance request.',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!card) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500">
        Loading digital ID card...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-cyan-600" />
              <h2 className="text-lg font-bold text-slate-900">Institutional Digital Identity Card</h2>
              <Badge variant={card.status === 'ACTIVE' ? 'emerald' : 'amber'} size="sm">
                {card.status}
              </Badge>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Official student digital credential issued by Electrix Institute of Technology (PO-007 IT Department).
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              leftIcon={<Printer className="w-3.5 h-3.5" />}
              className="text-xs cursor-pointer"
            >
              Print ID Card
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsReporting(true)}
              leftIcon={<AlertTriangle className="w-3.5 h-3.5 text-amber-600" />}
              className="text-xs text-amber-700 border-amber-200 hover:bg-amber-50 cursor-pointer"
            >
              Report Lost / Damaged
            </Button>
          </div>
        </div>

        {message && (
          <div
            className={`mt-4 p-3 rounded-xl text-xs flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-red-50 text-red-800 border border-red-200'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
        )}
      </div>

      {/* Printable ID Card Container */}
      <div className="flex justify-center p-4">
        <div className="w-full max-w-md bg-gradient-to-br from-slate-900 via-[#0f172a] to-[#1e1b4b] rounded-3xl shadow-2xl p-6 text-white border-2 border-cyan-500/30 relative overflow-hidden">
          {/* Background Decorative Rings */}
          <div className="absolute -right-16 -top-16 w-48 h-48 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none" />
          <div className="absolute -left-16 -bottom-16 w-48 h-48 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />

          {/* Card Header */}
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center font-black text-cyan-300">
                EIT
              </div>
              <div>
                <h3 className="text-xs font-black tracking-wider uppercase text-cyan-200">
                  Electrix Institute of Technology
                </h3>
                <p className="text-[9px] text-slate-400 tracking-tight">STUDENT IDENTITY CREDENTIAL</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                VERIFIED
              </span>
            </div>
          </div>

          {/* Main Card Body */}
          <div className="mt-5 flex gap-4">
            {/* Student Photo */}
            <div className="shrink-0 flex flex-col items-center">
              <div className="w-24 h-28 rounded-2xl bg-slate-800 border-2 border-cyan-400/30 overflow-hidden flex items-center justify-center shadow-md">
                {card.photo_url ? (
                  <img src={card.photo_url} alt={card.full_name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-cyan-900 to-slate-900 flex flex-col items-center justify-center text-cyan-300">
                    <User className="w-10 h-10 mb-1 opacity-75" />
                    <span className="text-[10px] font-mono font-bold">EIT PHOTO</span>
                  </div>
                )}
              </div>
              <span className="text-[9px] font-mono text-slate-400 mt-2">BATCH {card.batch_year || '2026'}</span>
            </div>

            {/* Student Details */}
            <div className="flex-1 min-w-0 space-y-2">
              <div>
                <span className="text-[9px] text-cyan-400 font-mono uppercase tracking-wider block">Student Name</span>
                <h4 className="text-base font-black text-white truncate tracking-tight">{card.full_name}</h4>
              </div>

              <div>
                <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider block">Registration No</span>
                <span className="text-xs font-mono font-bold text-cyan-300 bg-white/5 px-2 py-0.5 rounded-md border border-white/10">
                  {card.registration_number}
                </span>
              </div>

              <div>
                <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider block">Program / Branch</span>
                <p className="text-xs font-semibold text-slate-200 line-clamp-2">
                  {card.course_name || card.department}
                </p>
              </div>
            </div>
          </div>

          {/* Card Footer Bar */}
          <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-[10px]">
            <div>
              <span className="text-slate-400 block text-[8px] font-mono">CARD ID &bull; VALID THRU</span>
              <span className="font-mono text-slate-300 font-semibold">{card.card_id}</span>
              <span className="text-slate-400 mx-1.5">&bull;</span>
              <span className="font-mono text-cyan-300 font-bold">{card.valid_until}</span>
            </div>

            <div className="w-10 h-10 rounded-lg bg-white p-1 flex items-center justify-center shadow-xs">
              <QrCode className="w-8 h-8 text-slate-900" />
            </div>
          </div>

          {/* Security Chip Strip */}
          <div className="mt-3 text-center">
            <p className="text-[8px] text-slate-500 font-mono tracking-widest">
              OFFICIAL PROPERTY OF EIT &bull; RETURN IF FOUND TO IT DEPT PO-007
            </p>
          </div>
        </div>
      </div>

      {/* Re-Issue Report Modal Form */}
      {isReporting && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 bg-amber-50 rounded-xl text-amber-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Report ID Card Issue</h3>
                <p className="text-xs text-slate-500">Submit a re-issuance request to the IT Department</p>
              </div>
            </div>

            <form onSubmit={handleReportReissue} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Issue Type</label>
                <div className="grid grid-cols-2 gap-3">
                  <label
                    className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                      reportReason === 'LOST'
                        ? 'border-red-500 bg-red-50/50 text-red-900'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reason"
                      value="LOST"
                      checked={reportReason === 'LOST'}
                      onChange={() => setReportReason('LOST')}
                      className="sr-only"
                    />
                    <span>Card Lost / Stolen</span>
                  </label>
                  <label
                    className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                      reportReason === 'DAMAGED'
                        ? 'border-amber-500 bg-amber-50/50 text-amber-900'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reason"
                      value="DAMAGED"
                      checked={reportReason === 'DAMAGED'}
                      onChange={() => setReportReason('DAMAGED')}
                      className="sr-only"
                    />
                    <span>Physically Damaged</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Incident Details</label>
                <textarea
                  rows={3}
                  value={reportNotes}
                  onChange={(e) => setReportNotes(e.target.value)}
                  placeholder="Describe when/where the card was lost or how it was damaged..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  type="button"
                  onClick={() => setIsReporting(false)}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Report'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
