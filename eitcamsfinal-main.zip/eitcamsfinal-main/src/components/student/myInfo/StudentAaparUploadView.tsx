import React from 'react';
import { Fingerprint, Info, Shield, CheckCircle2, Clock } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentAaparUploadViewProps {
  student: Student;
}

export function StudentAaparUploadView({ student }: StudentAaparUploadViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Fingerprint className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">APAAR / ABC ID Integration</h1>
              <Badge variant="neutral" size="sm">
                Portal Verification Pending
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Automated Permanent Academic Account Registry (One Nation, One Student ID) & Academic Bank of Credits
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            APAAR Registry Upload Pending Integration
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Direct DigiLocker APAAR / ABC ID auto-sync for student record{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> is currently undergoing scheduled API configuration with the National Academic Depository (NAD).
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Important Guidelines for Enrolled Students</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>
              Students who have already generated their 12-digit APAAR ID through DigiLocker should ensure their Aadhaar name matches their institutional enrollment record (<strong>{student.fullName}</strong>).
            </li>
            <li>
              Academic credits accumulated through verified course completions will be automatically batched and submitted to the Academic Bank of Credits upon conclusion of each semester evaluation.
            </li>
            <li>
              A dedicated verification window will open once the National Depository gateway is activated for the 2026–2027 batch.
            </li>
          </ul>
        </div>

        <div className="pt-2 text-[11px] text-[#94a3b8] flex items-center justify-center gap-2">
          <Shield className="w-3.5 h-3.5" />
          <span>EIT Academic Affairs • Ministry of Education APAAR Compliance</span>
        </div>
      </div>
    </div>
  );
}
