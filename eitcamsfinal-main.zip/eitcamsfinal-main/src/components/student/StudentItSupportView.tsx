import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Search,
  ExternalLink,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { TicketRecord } from '../../types/itDepartment';
import { itRepository } from '../../services/itService';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { NewTicketModal } from '../it/modals/NewTicketModal';
import { TicketDetailModal } from '../it/modals/TicketDetailModal';

interface StudentItSupportViewProps {
  student: Student;
}

export function StudentItSupportView({ student }: StudentItSupportViewProps) {
  const [tickets, setTickets] = useState<TicketRecord[]>([]);
  const [isNewTicketOpen, setIsNewTicketOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<TicketRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const studentId = student.student_id || student.id || student.registrationNumber || '';
  const studentName = student.fullName || `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
  const studentEmail = student.institutional_email || student.email || `${student.registrationNumber || student.registration_number || 'student'}@student.eit.edu`;
  const studentPhone = student.phone || student.mobile || '';

  const loadTickets = () => {
    const list = itRepository.getTicketsByRequester(studentId);
    setTickets(list);
  };

  useEffect(() => {
    loadTickets();
  }, [student, studentId]);

  const filteredTickets = tickets.filter((t) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.ticket_number.toLowerCase().includes(q) ||
      t.subject.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q) ||
      t.status.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <LifeBuoy className="w-5 h-5 text-cyan-600" />
              <h2 className="text-lg font-bold text-slate-900">IT Helpdesk & Technical Support</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Need assistance with Wi-Fi, portal access, email, or credentials? Submit a ticket directly to the EIT IT Department (PO-007).
            </p>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsNewTicketOpen(true)}
            leftIcon={<Plus className="w-4 h-4" />}
            className="bg-[#1e3a8a] hover:bg-[#172e6e] text-xs cursor-pointer"
          >
            New Support Ticket
          </Button>
        </div>
      </div>

      {/* Tickets List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search your tickets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />
          </div>
          <div className="text-xs text-slate-500">
            Total Tickets: <span className="font-bold text-slate-700">{tickets.length}</span>
          </div>
        </div>

        {filteredTickets.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <LifeBuoy className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">No Support Tickets Found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              You haven't submitted any IT tickets yet, or no tickets match your search. Click "New Support Ticket" above if you need assistance.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredTickets.map((t) => (
              <div
                key={t.ticket_id}
                onClick={() => setSelectedTicket(t)}
                className="p-4 hover:bg-slate-50/80 transition-colors cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#1e3a8a]">{t.ticket_number}</span>
                    <Badge
                      size="sm"
                      variant={
                        t.status === 'RESOLVED' || t.status === 'CLOSED'
                          ? 'emerald'
                          : t.status === 'IN_PROGRESS'
                          ? 'blue'
                          : 'amber'
                      }
                    >
                      {t.status.replace('_', ' ')}
                    </Badge>
                    <span className="text-[10px] font-semibold text-slate-500 uppercase px-1.5 py-0.5 rounded bg-slate-100">
                      {t.category}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900">{t.subject}</h4>
                  <p className="text-xs text-slate-500 line-clamp-1">{t.description}</p>
                </div>

                <div className="text-right sm:shrink-0 text-xs text-slate-500 space-y-1">
                  <div className="flex items-center gap-1 sm:justify-end text-[11px]">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>Created: {new Date(t.created_at).toLocaleDateString()}</span>
                  </div>
                  {t.responses.length > 0 && (
                    <div className="flex items-center gap-1 sm:justify-end text-cyan-700 font-semibold text-[11px]">
                      <MessageSquare className="w-3 h-3" />
                      <span>{t.responses.length} update(s)</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Ticket Creation Dialog */}
      <NewTicketModal
        isOpen={isNewTicketOpen}
        onClose={() => setIsNewTicketOpen(false)}
        requesterId={studentId}
        requesterName={studentName}
        requesterAccountType="STUDENT"
        requesterEmail={studentEmail}
        requesterPhone={studentPhone}
        onTicketCreated={() => {
          loadTickets();
          setIsNewTicketOpen(false);
        }}
      />

      {/* Ticket Detail Dialog */}
      <TicketDetailModal
        isOpen={!!selectedTicket}
        onClose={() => setSelectedTicket(null)}
        ticket={selectedTicket}
        currentUserId={studentId}
        currentUserRole="STUDENT"
        currentUserName={studentName}
        isItStaff={false}
        onTicketUpdated={() => {
          loadTickets();
          if (selectedTicket) {
            const updated = itRepository.getTicketById(selectedTicket.ticket_id);
            setSelectedTicket(updated || null);
          }
        }}
      />
    </div>
  );
}
