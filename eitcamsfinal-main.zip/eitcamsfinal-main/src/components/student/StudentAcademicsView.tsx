import React from 'react';
import {
  BookOpen,
  GraduationCap,
  Users,
  Clock,
  Mail,
  Building,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import { Student } from '../../types/admission';
import {
  AcademicClass,
  AcademicSection,
  AcademicSubject,
  FacultyAssignment,
  AcademicSession,
} from '../../types/academic';
import { Badge } from '../ui/Badge';

interface StudentAcademicsViewProps {
  student: Student;
  currentSession: AcademicSession | null;
  classes: AcademicClass[];
  sections: AcademicSection[];
  subjects: AcademicSubject[];
  facultyAssignments: FacultyAssignment[];
}

export function StudentAcademicsView({
  student,
  currentSession,
  classes,
  sections,
  subjects,
  facultyAssignments,
}: StudentAcademicsViewProps) {
  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';

  // Find matching degree program
  const studentClass =
    classes.find(
      (c) =>
        c.name.toLowerCase() === studentProg.toLowerCase() ||
        c.id.toLowerCase() === studentProg.toLowerCase() ||
        c.name.toLowerCase().includes(studentProg.toLowerCase()) ||
        studentProg.toLowerCase().includes(c.name.toLowerCase())
    ) || null;

  // Filter courses enrolled for this program
  const classSubjects = subjects.filter((s) => {
    if (studentClass && s.classId === studentClass.id) return true;
    return (
      s.className?.toLowerCase() === studentProg.toLowerCase() ||
      s.classId?.toLowerCase() === studentProg.toLowerCase()
    );
  });

  // Fallback to all subjects if none specific match class
  const displaySubjects = classSubjects.length > 0 ? classSubjects : subjects.slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Academic Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">
                  {studentProg} &bull; {studentBatch.startsWith('Batch') ? studentBatch : `Batch ${studentBatch}`}
                </h1>
                {student.currentSemester && (
                  <Badge variant="blue" size="sm">
                    {student.currentSemester}
                  </Badge>
                )}
                <Badge variant="neutral" size="sm">
                  {currentSession?.name || '2026–2027 Academic Year'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-3">
                <span>
                  Department: <strong>{studentClass?.department || (studentClass as any)?.stream || 'Engineering & Computing'}</strong>
                </span>
                <span>•</span>
                <span>Enrolled Courses: <strong>{displaySubjects.length}</strong></span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Curriculum Active</span>
          </div>
        </div>
      </div>

      {/* Enrolled Subjects Catalog */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Enrolled Academic Courses & Faculty</h2>
          </div>
          <span className="text-xs text-[#64748b] font-medium">
            {displaySubjects.length} Courses Registered
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {displaySubjects.map((subject) => {
            // Find assigned faculty for this subject and class
            const assignment = facultyAssignments.find(
              (a) =>
                ((a.subjectId && a.subjectId.toLowerCase() === subject.id.toLowerCase()) ||
                  (a.subjectCode && a.subjectCode.toLowerCase() === subject.code.toLowerCase()) ||
                  (a.subjectName && a.subjectName.toLowerCase() === subject.name.toLowerCase())) &&
                (!a.sectionName ||
                  a.sectionName === 'All' ||
                  a.sectionName.toLowerCase() === studentBatch.toLowerCase() ||
                  studentBatch.toLowerCase().includes(a.sectionName.toLowerCase()) ||
                  a.sectionName.toLowerCase().includes(studentBatch.toLowerCase()))
            );

            return (
              <div
                key={subject.id}
                className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#bfdbfe] transition-colors space-y-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#1e293b]">{subject.name}</span>
                        <Badge variant="neutral" size="sm" className="font-mono text-[10px]">
                          {subject.code}
                        </Badge>
                      </div>
                      <p className="text-xs text-[#64748b] mt-1.5 line-clamp-2">
                        {subject.description || 'Standard academic syllabus and practical modules.'}
                      </p>
                    </div>
                    <Badge variant="blue" size="sm" className="shrink-0">
                      {subject.type || 'Core'}
                    </Badge>
                  </div>
                </div>

                {/* Faculty Assignment Footer */}
                <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-slate-100 border border-[#e2e8f0] flex items-center justify-center text-[#475569]">
                      <Users className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <span className="text-xs font-semibold text-[#1e293b] block">
                        {assignment?.facultyName || 'Department Faculty'}
                      </span>
                      <span className="text-[10px] text-[#64748b] block">
                        {assignment?.department || 'Office of Academic Affairs'}
                      </span>
                    </div>
                  </div>

                  {assignment?.facultyEmail && (
                    <a
                      href={`mailto:${assignment.facultyEmail}`}
                      className="p-1.5 rounded-lg text-[#64748b] hover:text-[#1e3a8a] hover:bg-slate-100 transition-colors"
                      title="Contact Teacher"
                    >
                      <Mail className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
