import React, { useState } from 'react';
import {
  CreditCard,
  Search,
  Receipt,
  Calendar,
  Shield,
  CheckCircle2,
  AlertCircle,
  Hash,
  ExternalLink,
  DollarSign,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { PaymentRecord, FeeReceipt, FeeAssignment } from '../../../types/finance';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentPaymentsViewProps {
  student: Student;
  payments: PaymentRecord[];
  receipts: FeeReceipt[];
  feeAssignments: FeeAssignment[];
  onViewReceipt: (receipt: FeeReceipt) => void;
  onNavigateToFees: () => void;
}

export function StudentPaymentsView({
  student,
  payments,
  receipts,
  feeAssignments,
  onViewReceipt,
  onNavigateToFees,
}: StudentPaymentsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [modeFilter, setModeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'valid' | 'voided'>('all');

  // Summary Metrics calculated from actual payment records
  const validPayments = payments.filter((p) => !p.isVoided);
  const totalAmountPaid = validPayments.reduce((acc, curr) => acc + (curr.amountPaid || 0), 0);
  const voidedCount = payments.filter((p) => p.isVoided).length;

  const filteredPayments = payments.filter((p) => {
    const term = searchTerm.toLowerCase();
    const matchesSearch =
      p.id.toLowerCase().includes(term) ||
      p.receiptNumber.toLowerCase().includes(term) ||
      p.feeTypeName.toLowerCase().includes(term) ||
      (p.transactionReference && p.transactionReference.toLowerCase().includes(term));

    const matchesMode = modeFilter === 'all' || p.paymentMode === modeFilter;
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'valid'
        ? !p.isVoided
        : p.isVoided;

    return matchesSearch && matchesMode && matchesStatus;
  });

  const handleReceiptClick = (payment: PaymentRecord) => {
    const matchedReceipt = receipts.find(
      (r) => r.receiptNumber === payment.receiptNumber || r.paymentId === payment.id
    );
    if (matchedReceipt) {
      onViewReceipt(matchedReceipt);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <CreditCard className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Payments</h1>
                <Badge variant={validPayments.length > 0 ? 'emerald' : 'neutral'} size="sm">
                  {validPayments.length} Verified {validPayments.length === 1 ? 'Payment' : 'Payments'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              id="student-payments-view-fees-btn"
              variant="outline"
              size="sm"
              onClick={onNavigateToFees}
              leftIcon={<DollarSign className="w-4 h-4 text-[#1e3a8a]" />}
            >
              Fee Account Summary
            </Button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-emerald-700 block">Total Amount Paid</span>
          <span className="text-2xl font-bold text-emerald-700 mt-1 block">
            ${totalAmountPaid.toLocaleString()}
          </span>
          <span className="text-[11px] text-emerald-600 mt-1 block">
            Across {validPayments.length} verified transactions
          </span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-[#64748b] block">Total Transactions</span>
          <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
            {payments.length}
          </span>
          <span className="text-[11px] text-[#94a3b8] mt-1 block">
            {voidedCount > 0 ? `${voidedCount} voided transaction(s)` : 'All records valid'}
          </span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-[#64748b] block">Issued Receipts</span>
          <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
            {receipts.length}
          </span>
          <span className="text-[11px] text-[#94a3b8] mt-1 block">
            Official EIT institutional receipts
          </span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-[#64748b] block">Latest Payment</span>
          <span className="text-lg font-bold text-[#1e293b] mt-1 block font-mono">
            {payments.length > 0 ? payments[0].paymentDate : 'None'}
          </span>
          <span className="text-[11px] text-[#94a3b8] mt-1 block">
            {payments.length > 0 ? payments[0].paymentMode : 'No activity on file'}
          </span>
        </div>
      </div>

      {/* Payment Transactions Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        {/* Table Filters */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-[#f8fafc]">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by receipt, fee head, ref..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] placeholder:text-[#94a3b8] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={modeFilter}
              onChange={(e) => setModeFilter(e.target.value)}
              className="py-1.5 px-3 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            >
              <option value="all">All Payment Modes</option>
              <option value="Cash">Cash</option>
              <option value="UPI">UPI</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cheque">Cheque</option>
              <option value="Other">Other</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as 'all' | 'valid' | 'voided')}
              className="py-1.5 px-3 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            >
              <option value="all">All Statuses</option>
              <option value="valid">Valid Transactions</option>
              <option value="voided">Voided Transactions</option>
            </select>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#1e293b]">
            <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3">Receipt / Payment ID</th>
                <th className="px-5 py-3">Payment Date</th>
                <th className="px-5 py-3">Fee Description</th>
                <th className="px-5 py-3 text-right">Amount Paid</th>
                <th className="px-5 py-3">Mode & Reference</th>
                <th className="px-5 py-3">Received By</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-[#94a3b8]">
                    No payment records found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((payment) => {
                  const hasMatchingReceipt = receipts.some(
                    (r) => r.receiptNumber === payment.receiptNumber || r.paymentId === payment.id
                  );

                  return (
                    <tr key={payment.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-mono text-xs">
                        <span className="font-bold text-[#1e3a8a] block">
                          {payment.receiptNumber || payment.id}
                        </span>
                        {payment.receiptNumber && payment.id !== payment.receiptNumber && (
                          <span className="text-[10px] text-[#94a3b8] block mt-0.5">
                            ID: {payment.id}
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b] font-mono">
                        {payment.paymentDate}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="font-semibold text-[#1e293b] block">
                          {payment.feeTypeName}
                        </span>
                        {payment.academicSession && (
                          <span className="text-[10px] text-[#64748b] block mt-0.5">
                            Session {payment.academicSession}
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold text-emerald-700">
                        ${payment.amountPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="font-medium text-[#334155] block">
                          {payment.paymentMode}
                        </span>
                        {payment.transactionReference && (
                          <span className="text-[10px] text-[#64748b] font-mono block mt-0.5">
                            Ref: {payment.transactionReference}
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b]">
                        {payment.receivedBy || 'Finance Office'}
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge
                          variant={payment.isVoided ? 'rose' : 'emerald'}
                          size="sm"
                        >
                          {payment.isVoided ? 'Voided' : 'Verified'}
                        </Badge>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        {hasMatchingReceipt ? (
                          <button
                            type="button"
                            onClick={() => handleReceiptClick(payment)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#1e3a8a] hover:bg-[#eff6ff] rounded transition-colors cursor-pointer"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>Receipt</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#94a3b8]">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Read-Only Notice Footer */}
        <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#94a3b8]" />
            All payment transactions are audited and settled in the EIT institutional ledger.
          </span>
        </div>
      </div>
    </div>
  );
}
