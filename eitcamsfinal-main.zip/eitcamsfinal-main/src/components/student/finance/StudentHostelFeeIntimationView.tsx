import React from 'react';
import {
  Building,
  AlertCircle,
  CheckCircle2,
  DollarSign,
  Shield,
  FileText,
  Clock,
  Home,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { FeeAssignment } from '../../../types/finance';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentHostelFeeIntimationViewProps {
  student: Student;
  feeAssignments: FeeAssignment[];
  onNavigateToFees: () => void;
}

export function StudentHostelFeeIntimationView({
  student,
  feeAssignments,
  onNavigateToFees,
}: StudentHostelFeeIntimationViewProps) {
  // Check for any actual assigned hostel fees
  const hostelFeeAssignments = feeAssignments.filter((f) =>
    f.feeTypeName.toLowerCase().includes('hostel')
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Building className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Hostel Fee Intimation</h1>
                <Badge variant={hostelFeeAssignments.length > 0 ? 'amber' : 'neutral'} size="sm">
                  {hostelFeeAssignments.length > 0
                    ? `${hostelFeeAssignments.length} Hostel Fee Head${hostelFeeAssignments.length > 1 ? 's' : ''}`
                    : 'No Residential Fee Record'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              id="student-hostel-view-fees-btn"
              variant="outline"
              size="sm"
              onClick={onNavigateToFees}
              leftIcon={<DollarSign className="w-4 h-4 text-[#1e3a8a]" />}
            >
              Fee Account Summary
            </Button>
          </div>
        </div>
      </div>

      {hostelFeeAssignments.length > 0 ? (
        /* Render actual hostel fee records if present */
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-[#1e3a8a]" />
              <h2 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                Assigned Hostel Fee Schedules
              </h2>
            </div>
            <span className="text-xs font-mono text-[#64748b]">
              {hostelFeeAssignments.length} record(s)
            </span>
          </div>

          <div className="divide-y divide-[#e2e8f0]">
            {hostelFeeAssignments.map((assignment) => (
              <div key={assignment.id} className="p-5 hover:bg-slate-50 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-sm font-bold text-[#1e293b]">
                      {assignment.feeTypeName}
                    </span>
                    <p className="text-xs text-[#64748b] mt-1">
                      Academic Session: <strong>{assignment.academicSession || '2026–2027'}</strong>
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-[#64748b] block">Balance Due</span>
                    <span className="text-lg font-bold text-amber-700 block">
                      ${(assignment.balance ?? assignment.balanceDue ?? 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Honest Non-Applicable / Empty State (strictly adhering to Requirement 14) */
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center mx-auto mb-4">
            <Building className="w-8 h-8" />
          </div>
          <h2 className="text-base font-bold text-[#1e293b]">
            No hostel fee information is currently available.
          </h2>
          <p className="text-xs text-[#64748b] mt-2 max-w-md mx-auto leading-relaxed">
            Residential hall allocation and hostel fee intimations have not been published for this
            student account for the 2026–2027 academic session. When hostel accommodations are
            assigned by the Residence Hall Administration, applicable boarding and room fee schedules
            will appear here.
          </p>
          <div className="mt-6 flex justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={onNavigateToFees}
              leftIcon={<DollarSign className="w-4 h-4 text-[#1e3a8a]" />}
            >
              Check Academic Fees
            </Button>
          </div>
        </div>
      )}

      {/* Institutional Residential Hall Guidance */}
      <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5">
        <Shield className="w-5 h-5 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="text-xs text-[#475569] space-y-1">
          <p className="font-semibold text-[#1e293b]">Campus Residence & Boarding Policy</p>
          <p>
            Hostel fee schedules and mess charges are generated only upon verified room allotment
            by the Campus Warden and Student Housing Office. No unassigned residential dues are levied
            on day-scholar or unallocated student profiles.
          </p>
        </div>
      </div>
    </div>
  );
}
