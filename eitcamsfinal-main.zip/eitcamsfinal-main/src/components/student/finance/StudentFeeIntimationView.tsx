import React from 'react';
import {
  Bell,
  Calendar,
  AlertCircle,
  CheckCircle2,
  DollarSign,
  Shield,
  FileText,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { FeeAssignment } from '../../../types/finance';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentFeeIntimationViewProps {
  student: Student;
  feeAssignments: FeeAssignment[];
  onNavigateToFees: () => void;
}

export function StudentFeeIntimationView({
  student,
  feeAssignments,
  onNavigateToFees,
}: StudentFeeIntimationViewProps) {
  // Pending fee dues requiring intimation / payment
  const pendingAssignments = feeAssignments.filter((f) => (f.balance ?? f.balanceDue ?? 0) > 0);
  const totalPendingBalance = pendingAssignments.reduce((acc, curr) => acc + (curr.balance ?? curr.balanceDue ?? 0), 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Bell className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Fee Intimation</h1>
                <Badge variant={pendingAssignments.length > 0 ? 'amber' : 'emerald'} size="sm">
                  {pendingAssignments.length > 0
                    ? `${pendingAssignments.length} Pending Notice${pendingAssignments.length > 1 ? 's' : ''}`
                    : 'Account In Good Standing'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              id="student-intimation-view-fees-btn"
              variant="outline"
              size="sm"
              onClick={onNavigateToFees}
              leftIcon={<DollarSign className="w-4 h-4 text-[#1e3a8a]" />}
            >
              View Full Fee Account
            </Button>
          </div>
        </div>
      </div>

      {/* Intimation Notices List or Clean Empty State */}
      {pendingAssignments.length > 0 ? (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900">
              <p className="font-semibold">Active Institutional Fee Intimation</p>
              <p className="mt-0.5 text-amber-800">
                You have an aggregate outstanding balance of{' '}
                <strong>${totalPendingBalance.toLocaleString()}</strong> across{' '}
                {pendingAssignments.length} assigned fee head{pendingAssignments.length > 1 ? 's' : ''}.
                Please review the intimations below and clear dues before the specified due dates.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="p-4 border-b border-[#e2e8f0] bg-[#f8fafc] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#1e3a8a]" />
                <h2 className="text-xs font-bold text-[#1e293b] uppercase tracking-wider">
                  Pending Due Intimations
                </h2>
              </div>
              <span className="text-xs font-mono text-[#64748b]">
                {pendingAssignments.length} head(s)
              </span>
            </div>

            <div className="divide-y divide-[#e2e8f0]">
              {pendingAssignments.map((assignment) => (
                <div key={assignment.id} className="p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-[#1e293b]">
                          {assignment.feeTypeName}
                        </span>
                        <Badge
                          variant={assignment.status === 'Partially Paid' ? 'amber' : 'rose'}
                          size="sm"
                        >
                          {assignment.status}
                        </Badge>
                      </div>
                      <p className="text-xs text-[#64748b] mt-1">
                        Academic Session: <strong>{assignment.academicSession || '2026–2027'}</strong>
                        {assignment.remarks && ` • Note: ${assignment.remarks}`}
                      </p>
                    </div>

                    <div className="text-right sm:shrink-0">
                      <span className="text-xs text-[#64748b] block">Outstanding Dues</span>
                      <span className="text-lg font-bold text-amber-700 block">
                        ${(assignment.balance ?? assignment.balanceDue ?? 0).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs text-[#64748b]">
                    <div className="flex items-center gap-4">
                      <span>Total Due: <strong>${assignment.amountDue.toLocaleString()}</strong></span>
                      <span>Paid: <strong className="text-emerald-700">${assignment.amountPaid.toLocaleString()}</strong></span>
                      {assignment.discountOrWaiver > 0 && (
                        <span>Waiver: <strong className="text-purple-700">${assignment.discountOrWaiver.toLocaleString()}</strong></span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 font-mono text-xs">
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      <span>Due Date: <strong>{assignment.dueDate}</strong></span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Honest Clean Empty State */
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-base font-bold text-[#1e293b]">No Pending Fee Intimations</h2>
          <p className="text-xs text-[#64748b] mt-2 max-w-md mx-auto">
            All institutional fee components assigned to your student account are fully settled or no
            active fee payment reminder notices have been issued by the Finance Office.
          </p>
          <div className="mt-6 flex justify-center">
            <Button
              variant="outline"
              size="sm"
              onClick={onNavigateToFees}
              leftIcon={<DollarSign className="w-4 h-4 text-[#1e3a8a]" />}
            >
              Open Fee Account Ledger
            </Button>
          </div>
        </div>
      )}

      {/* Institutional Guidance Card */}
      <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs flex items-start gap-3.5">
        <Shield className="w-5 h-5 text-[#1e3a8a] shrink-0 mt-0.5" />
        <div className="text-xs text-[#475569] space-y-1">
          <p className="font-semibold text-[#1e293b]">Official Institutional Fee Policy</p>
          <p>
            Fee intimations reflect official billing schedules sanctioned by Electrix Institute of Technology.
            Receipts are issued automatically upon verification of funds by the Finance Office.
            For scholarship adjustments or installment inquiries, contact the Finance & Accounts Department.
          </p>
        </div>
      </div>
    </div>
  );
}
