import React from 'react';
import { Sparkles, Calendar, ArrowUpRight, Megaphone, Info } from 'lucide-react';
import { Badge } from '../../ui/Badge';

export function StudentSpotlightView() {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <Sparkles className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Campus Spotlight</h1>
              <Badge variant="amber" size="sm">
                Active Bulletin
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Electrix Institute of Technology academic recognitions, research highlights, and official circulars
            </p>
          </div>
        </div>
      </div>

      {/* Featured Institutional Directives */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-xs space-y-4 hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <Badge variant="blue" size="sm">Academic Affairs</Badge>
            <span className="text-[11px] text-[#64748b] flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> 2026–2027 Academic Session
            </span>
          </div>
          <h2 className="text-sm font-bold text-[#1e293b]">
            Commencement of Fall 2026 Academic Term & Course Enrollments
          </h2>
          <p className="text-xs text-[#475569] leading-relaxed">
            All registered undergraduate and postgraduate students are instructed to review their
            course timetables and ensure adherence to institutional laboratory safety protocols and attendance requirements.
          </p>
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-[#1e3a8a] font-semibold">
            <span>Dean of Academic Affairs</span>
            <span className="text-slate-400 font-mono text-[10px]">CIRCULAR #ACAD-2026-01</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-xs space-y-4 hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <Badge variant="emerald" size="sm">Central Library</Badge>
            <span className="text-[11px] text-[#64748b] flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> IEEE & ACM Digital Access
            </span>
          </div>
          <h2 className="text-sm font-bold text-[#1e293b]">
            Institutional Access to IEEE Xplore, ScienceDirect, and Digital Repositories
          </h2>
          <p className="text-xs text-[#475569] leading-relaxed">
            EIT students have campus-wide and remote proxy access enabled for peer-reviewed technical journals
            and international conference proceedings via the Central Library gateway.
          </p>
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-emerald-800 font-semibold">
            <span>University Librarian</span>
            <span className="text-slate-400 font-mono text-[10px]">LIB-REP-2026</span>
          </div>
        </div>
      </div>
    </div>
  );
}
