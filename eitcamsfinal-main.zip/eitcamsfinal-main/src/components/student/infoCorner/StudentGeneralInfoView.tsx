import React from 'react';
import { BookOpen, ShieldAlert, PhoneCall, Clock, CheckCircle2, Building2 } from 'lucide-react';
import { Badge } from '../../ui/Badge';

export function StudentGeneralInfoView() {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
            <BookOpen className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">General Student Directives & Handbook</h1>
              <Badge variant="blue" size="sm">
                Code of Conduct
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Electrix Institute of Technology campus norms, academic integrity code, and essential administrative contact hours
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Working Hours & Academic Contact */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-[#1e3a8a] font-bold text-xs uppercase tracking-wider">
            <Clock className="w-4 h-4" />
            <span>Campus Office Timings</span>
          </div>
          <div className="text-xs text-[#475569] space-y-2">
            <div className="flex justify-between border-b border-slate-100 pb-1.5">
              <span>Academic Office:</span>
              <span className="font-semibold text-[#1e293b]">08:30 AM – 05:00 PM</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5">
              <span>COE Examination Cell:</span>
              <span className="font-semibold text-[#1e293b]">09:00 AM – 05:30 PM</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5">
              <span>Finance & Accounts:</span>
              <span className="font-semibold text-[#1e293b]">09:30 AM – 04:30 PM</span>
            </div>
            <div className="flex justify-between">
              <span>Central Library:</span>
              <span className="font-semibold text-[#1e293b]">08:00 AM – 10:00 PM</span>
            </div>
          </div>
        </div>

        {/* Academic Integrity Code */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-[#1e3a8a] font-bold text-xs uppercase tracking-wider">
            <CheckCircle2 className="w-4 h-4" />
            <span>Academic Code of Ethics</span>
          </div>
          <p className="text-xs text-[#475569] leading-relaxed">
            Plagiarism, unauthorized collaboration in graded evaluations, and impersonation in continuous assessments or examinations constitute serious disciplinary violations subject to review by the Academic Misconduct Board.
          </p>
        </div>

        {/* Emergency & Campus Helpline */}
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-6 shadow-xs space-y-3">
          <div className="flex items-center gap-2 text-rose-600 font-bold text-xs uppercase tracking-wider">
            <ShieldAlert className="w-4 h-4" />
            <span>Emergency & Helpdesk</span>
          </div>
          <div className="text-xs text-[#475569] space-y-2">
            <div className="flex justify-between border-b border-slate-100 pb-1.5">
              <span>Campus Security (24/7):</span>
              <span className="font-mono font-semibold text-[#1e293b]">Ext: 1000 / 1001</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-1.5">
              <span>Health Centre & Ambulance:</span>
              <span className="font-mono font-semibold text-[#1e293b]">Ext: 2000</span>
            </div>
            <div className="flex justify-between">
              <span>Anti-Ragging Helpline:</span>
              <span className="font-mono font-semibold text-[#1e293b]">1800-180-5522</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
