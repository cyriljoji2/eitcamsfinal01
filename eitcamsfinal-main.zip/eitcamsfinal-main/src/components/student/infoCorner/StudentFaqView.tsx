import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronRight, Search, BookOpen, Award, DollarSign, Calendar } from 'lucide-react';
import { Badge } from '../../ui/Badge';

interface FAQItem {
  question: string;
  answer: string;
  category: 'Academics' | 'Examinations' | 'Finance' | 'Campus Life';
}

const FAQS: FAQItem[] = [
  {
    category: 'Academics',
    question: 'What is the mandatory minimum attendance percentage required for examination eligibility?',
    answer: 'Electrix Institute of Technology mandates a strict minimum attendance of 75% across all lecture, practical, and tutorial components of every registered course. Students with attendance below 75% without authorized medical condonation are debarred from the end-semester final assessment.',
  },
  {
    category: 'Academics',
    question: 'How does academic course registration and curriculum enrolment work?',
    answer: 'Under institutional academic guidelines, students enroll in their prescribed core and elective courses each semester subject to prerequisite clearance and credit limits. Once confirmed by the Academic Office, assigned faculty and timetable schedules are reflected across your student portal.',
  },
  {
    category: 'Examinations',
    question: 'What is the procedure for applying for Paper Seeing and Revaluation?',
    answer: 'Following publication of provisional semester grades, students may submit an application for Paper See/Rev within 5 working days through the Examination menu. The Controller of Examinations coordinates script review sessions with an independent evaluation panel.',
  },
  {
    category: 'Examinations',
    question: 'When are official Hall Tickets released for end-semester examinations?',
    answer: 'Hall tickets are released by the Controller of Examinations approximately 7 to 10 days before the commencement of scheduled examinations, provided all fee dues are cleared and attendance eligibility is certified.',
  },
  {
    category: 'Finance',
    question: 'Where can I download official fee receipts for income tax or loan documentation?',
    answer: 'All verified fee transactions are recorded under the Online Payments > Payment Receipts menu. Each receipt contains an official institutional receipt number, transaction timestamp, and printable voucher formatted for educational loan and tax compliance.',
  },
  {
    category: 'Finance',
    question: 'What happens if semester tuition fees are delayed past the due date?',
    answer: 'Fee intimations with specified due dates are published under Online Payments > Fees Intimation. Payments made after the official deadline may incur late administrative charges as determined by the Finance & Accounts Office.',
  },
  {
    category: 'Campus Life',
    question: 'How do I contact my Faculty Advisor / Proctor for academic guidance?',
    answer: 'Your assigned Proctor details and cabin location are accessible under the Proctor > Proctor Details section. You may schedule appointments during designated mentor office hours or reach out via official campus email.',
  },
];

export function StudentFaqView() {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [openIndexes, setOpenIndexes] = useState<Record<number, boolean>>({ 0: true });

  const toggleFAQ = (index: number) => {
    setOpenIndexes((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const filteredFaqs = FAQS.filter((faq) => {
    const matchesCat = activeCategory === 'All' || faq.category === activeCategory;
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const categories = ['All', 'Academics', 'Examinations', 'Finance', 'Campus Life'];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <HelpCircle className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Helpdesk & FAQ</h1>
                <Badge variant="blue" size="sm">
                  Institutional Reference
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Frequently asked questions regarding academic regulations, examinations, and student services
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#1e3a8a] text-white shadow-2xs'
                  : 'text-[#64748b] hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-[#94a3b8] absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search regulations or FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full sm:w-64 pl-9 pr-3 py-1.5 text-xs rounded-lg border border-[#cbd5e1] focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] outline-hidden"
          />
        </div>
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="bg-white rounded-xl p-8 text-center border border-[#e2e8f0] shadow-xs">
            <HelpCircle className="w-8 h-8 text-[#94a3b8] mx-auto mb-2" />
            <p className="text-sm font-semibold text-[#1e293b]">No matching queries found</p>
            <p className="text-xs text-[#64748b] mt-1">Try adjusting your search terms or selecting another category.</p>
          </div>
        ) : (
          filteredFaqs.map((faq, index) => {
            const isOpen = !!openIndexes[index];
            return (
              <div
                key={index}
                className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between p-4 text-left font-semibold text-xs text-[#1e293b] hover:bg-slate-50 cursor-pointer gap-4"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-[#475569] shrink-0">
                      {faq.category}
                    </span>
                    <span>{faq.question}</span>
                  </div>
                  {isOpen ? (
                    <ChevronDown className="w-4 h-4 text-[#64748b] shrink-0" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-[#64748b] shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 pt-1 text-xs text-[#475569] leading-relaxed border-t border-slate-100 bg-[#f8fafc]/50">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
