import React, { useState } from 'react';
import {
  Receipt,
  Printer,
  Download,
  Search,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Shield,
  CreditCard,
  FileSpreadsheet,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { FeeReceipt, PaymentRecord } from '../../types/finance';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface StudentReceiptsViewProps {
  student: Student;
  receipts: FeeReceipt[];
  payments: PaymentRecord[];
  onViewReceipt: (receipt: FeeReceipt) => void;
}

export function StudentReceiptsView({
  student,
  receipts,
  payments,
  onViewReceipt,
}: StudentReceiptsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');

  // Total verified payments
  const totalPaid = receipts
    .filter((r) => !r.isVoided)
    .reduce((acc, curr) => acc + (curr.amountPaid || 0), 0);

  // Filter receipts
  const filteredReceipts = receipts.filter((r) => {
    const term = searchTerm.toLowerCase();
    return (
      r.receiptNumber.toLowerCase().includes(term) ||
      r.feeTypeName.toLowerCase().includes(term) ||
      r.receiptDate.toLowerCase().includes(term) ||
      r.paymentMode.toLowerCase().includes(term)
    );
  });

  const handleExportCsv = () => {
    const headers = [
      'Receipt Number',
      'Receipt Date',
      'Fee Description',
      'Amount Paid ($)',
      'Payment Mode',
      'Transaction Ref',
      'Status',
      'Cashier',
    ];

    const rowsInt = filteredReceipts.map((r) => [
      r.receiptNumber,
      r.receiptDate,
      r.feeTypeName,
      r.amountPaid.toFixed(2),
      r.paymentMode,
      r.transactionReference || 'N/A',
      r.isVoided ? 'VOIDED' : 'VALID',
      r.receivedBy,
    ]);

    const csvContent = [
      headers.join(','),
      ...rowsInt.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Fee_Receipts_${student.registrationNumber}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Receipt className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Fee Payment Receipts</h1>
                <Badge variant="emerald" size="sm">
                  {receipts.length} Official Receipts
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Total Settled: <strong className="text-emerald-700">${totalPaid.toLocaleString()}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              id="student-export-receipts-csv-btn"
              variant="outline"
              size="sm"
              onClick={handleExportCsv}
              disabled={receipts.length === 0}
              leftIcon={<Download className="w-4 h-4" />}
            >
              Export Statement (CSV)
            </Button>
          </div>
        </div>
      </div>

      {/* Receipts Table Card */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        {/* Table Search & Filter */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#f8fafc]">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search receipt #, fee type, date..."
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            />
          </div>

          <span className="text-xs text-[#64748b]">
            Showing {filteredReceipts.length} of {receipts.length} receipts
          </span>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#1e293b]">
            <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3">Receipt Number</th>
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Fee Description</th>
                <th className="px-5 py-3 text-right">Amount Paid</th>
                <th className="px-5 py-3">Payment Mode</th>
                <th className="px-5 py-3">Transaction Ref</th>
                <th className="px-5 py-3">Status</th>
                <th className="px-5 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-[#94a3b8]">
                    No official fee receipts found.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((receipt) => (
                  <tr key={receipt.receiptNumber} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-bold text-[#1e3a8a]">
                      {receipt.receiptNumber}
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b]">
                      {receipt.receiptDate}
                    </td>
                    <td className="px-5 py-3.5 font-medium text-[#1e293b]">
                      {receipt.feeTypeName}
                    </td>
                    <td className="px-5 py-3.5 text-right font-bold text-emerald-700">
                      ${receipt.amountPaid.toLocaleString()}
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-medium text-[#475569]">
                        {receipt.paymentMode}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b] font-mono text-[11px]">
                      {receipt.transactionReference || '—'}
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge variant={receipt.isVoided ? 'rose' : 'emerald'} size="sm">
                        {receipt.isVoided ? 'Voided' : 'Valid'}
                      </Badge>
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <Button
                        id={`btn-view-receipt-${receipt.receiptNumber}`}
                        size="sm"
                        variant="outline"
                        onClick={() => onViewReceipt(receipt)}
                        className="text-xs h-7 px-2.5"
                        leftIcon={<Printer className="w-3.5 h-3.5" />}
                      >
                        Print Receipt
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Info Footer */}
        <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#94a3b8]" />
            Official vouchers are stamped and digitally cataloged by the Finance Department.
          </span>
        </div>
      </div>
    </div>
  );
}
