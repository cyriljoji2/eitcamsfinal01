import React from 'react';
import { Briefcase, Clock, AlertCircle, Info, Building } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentPatRegistrationViewProps {
  student: Student;
}

export function StudentPatRegistrationView({ student }: StudentPatRegistrationViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Briefcase className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Placement & Training (PAT) Registration</h1>
              <Badge variant="neutral" size="sm">
                Enrollment Closed
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Centre for Career Planning, Corporate Relations & Campus Recruitment Drives
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            PAT Registration Window Closed
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            The placement and campus recruitment portal is currently not open for registrations for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> ({student.admissionClass}).
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Eligibility & Enrollment Criteria</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 text-[11px] text-[#475569]">
            <li>PAT enrollment commences during the pre-final year (Semester 6 for 4-year B.Tech programs).</li>
            <li>Eligible students must maintain a minimum CGPA of 6.0 with zero standing academic arrears.</li>
            <li>Official registration notices, company test schedules, and mock interview slots will be published through the Corporate Relations Centre upon notification.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
