import React from 'react';
import { Bus, Info, MapPin, Clock, Shield } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentTransportFacilityViewProps {
  student: Student;
}

export function StudentTransportFacilityView({ student }: StudentTransportFacilityViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Bus className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Campus Transport & Bus Pass Facility</h1>
              <Badge variant="neutral" size="sm">
                No Active Bus Subscription
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Electrix Institute of Technology Transport Division • Fleet routes, boarding points, and day-scholar shuttle passes
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Bus className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            No Transport Subscription Allocated
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            There is currently no institutional bus pass or transit route enrolled for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> for the 2026–2027 academic session.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Transport Enrollment Procedure for Day Scholars</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>Day scholars desiring institutional bus service can select designated arterial routes across the metropolitan region.</li>
            <li>Transport fees are levied annually and must be receipted by the Finance Office prior to RFID bus pass issuance.</li>
            <li>For route charts, pickup timings, and subscription forms, visit the <strong>Campus Transport Cell (Transport Yard Office)</strong>.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
