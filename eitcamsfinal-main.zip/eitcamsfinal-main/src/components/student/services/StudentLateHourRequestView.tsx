import React from 'react';
import { Moon, Clock, Info, Shield, Building } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentLateHourRequestViewProps {
  student: Student;
}

export function StudentLateHourRequestView({ student }: StudentLateHourRequestViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Moon className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Late Hour Campus / Lab Access Request</h1>
              <Badge variant="neutral" size="sm">
                In-Person Endorsement Required
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Permission for after-hours project laboratories, fabrication workshops, and central compute facilities
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Late Hour Laboratory Permission Workflow
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Late hour permissions (past 08:30 PM) for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> require physical laboratory in-charge sign-off and Campus Security clearance.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Safety & Security Regulations</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>Students working on sponsored research or capstone projects must be accompanied by a designated team member.</li>
            <li>A physical Late Entry Form endorsed by the project guide and Department Head must be submitted at the Main Campus Gate security post before 06:00 PM.</li>
            <li>Campus biometric logs are matched against security register entries upon exit.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
