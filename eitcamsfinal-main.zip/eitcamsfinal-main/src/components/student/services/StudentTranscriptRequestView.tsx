import React from 'react';
import { Scroll, Clock, Info, Shield, Award } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentTranscriptRequestViewProps {
  student: Student;
}

export function StudentTranscriptRequestView({ student }: StudentTranscriptRequestViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <Scroll className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Official Academic Transcript Request</h1>
              <Badge variant="neutral" size="sm">
                Service Governed by COE
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Controller of Examinations • Certified institutional academic transcripts for higher studies and WES verification
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Transcript Application Portal
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Direct online transcript dispatch for student{' '}
            <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> requires physical verification of completed semester grade cards at the COE office.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Application Instructions & Requirements</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>Students must clear all academic fee liabilities prior to requesting official sealed transcripts.</li>
            <li>Applications for international evaluation (WES, IQAS, ICAS) must be submitted along with the respective reference numbers.</li>
            <li>For emergency in-person issuance, visit the <strong>Controller of Examinations Office (Ground Floor, Main Academic Complex)</strong> with your student identity card.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
