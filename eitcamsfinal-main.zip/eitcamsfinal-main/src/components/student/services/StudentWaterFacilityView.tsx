import React from 'react';
import { Droplet, Info, Building, ShieldCheck } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentWaterFacilityViewProps {
  student: Student;
}

export function StudentWaterFacilityView({ student }: StudentWaterFacilityViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-blue-200">
            <Droplet className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Campus Water Facility & Dispenser Network</h1>
              <Badge variant="blue" size="sm">
                Estate Management
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Electrix Institute of Technology Estate Services • RO drinking water dispenser status and maintenance
            </p>
          </div>
        </div>
      </div>

      {/* Facility Overview & Estate Maintenance Information */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto">
          <Droplet className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Continuous RO Water Quality & Maintenance
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            All academic blocks, laboratory complexes, and dining zones at Electrix Institute of Technology are equipped
            with multi-stage Reverse Osmosis (RO) drinking water purifiers with UV disinfection.
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Water Facility Grievance & Maintenance</span>
          </div>
          <p className="text-[11px] text-[#475569] leading-relaxed">
            Routine water quality assays (TDS, pH, microbial testing) are published monthly by the Department of Civil & Environmental Engineering.
            To report an issue with any drinking water cooler or dispenser on campus, notify <strong>Estate & Physical Plant Services (Intercom Ext: 4001)</strong>.
          </p>
        </div>
      </div>
    </div>
  );
}
