import React from 'react';
import { GraduationCap, Clock, Info, Shield, Award } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentConvocationViewProps {
  student: Student;
}

export function StudentConvocationView({ student }: StudentConvocationViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-xl bg-slate-100 text-[#1e3a8a] flex items-center justify-center text-xl font-bold shrink-0 shadow-xs border border-slate-200">
            <GraduationCap className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-xl font-bold text-[#1e293b]">Annual Convocation Registration</h1>
              <Badge variant="neutral" size="sm">
                Registration Closed
              </Badge>
            </div>
            <p className="text-xs text-[#64748b] mt-1">
              Electrix Institute of Technology Annual Degree Award Ceremony & Graduation Conclave
            </p>
          </div>
        </div>
      </div>

      {/* Honest Empty / Informational State */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-8 text-center max-w-2xl mx-auto space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <Clock className="w-8 h-8" />
        </div>

        <div>
          <h2 className="text-base font-bold text-[#1e293b]">
            Convocation Registration Not Applicable
          </h2>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-2 leading-relaxed">
            Convocation registration is reserved strictly for graduating final-year candidates who have completed all required degree credits and obtained No Dues clearance.
          </p>
          <p className="text-xs text-[#64748b] max-w-md mx-auto mt-1">
            Student record <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong> is currently enrolled in ongoing coursework ({student.admissionClass}).
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 text-left text-xs text-[#334155] space-y-3 mt-4">
          <div className="flex items-center gap-2 font-bold text-[#1e3a8a]">
            <Info className="w-4 h-4" />
            <span>Graduation Eligibility Criteria</span>
          </div>
          <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-[#475569]">
            <li>Successful audit and accumulation of all program credits prescribed by the Academic Regulations.</li>
            <li>Zero outstanding fee balances, library book liabilities, or lab equipment clearances.</li>
            <li>Eligible graduates will receive an institutional notification via email and SMS when the annual registration portal goes live.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
