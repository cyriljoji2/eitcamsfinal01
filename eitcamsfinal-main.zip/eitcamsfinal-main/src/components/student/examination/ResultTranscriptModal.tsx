export { ResultTranscriptModal } from '../modals/ResultTranscriptModal';
