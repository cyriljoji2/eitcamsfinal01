import React from 'react';
import {
  UserCheck,
  ShieldCheck,
  AlertCircle,
  Clock,
  HelpCircle,
  Lock,
  BookOpen,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { StudentExamResult } from '../../../types/examination';
import { Badge } from '../../ui/Badge';

interface StudentSupplementaryRegistrationViewProps {
  student: Student;
  results: StudentExamResult[];
}

export function StudentSupplementaryRegistrationView({
  student,
  results,
}: StudentSupplementaryRegistrationViewProps) {
  // Count if student has any actual backlogs
  let backlogCount = 0;
  results.forEach((res) => {
    (res.subjectMarks || []).forEach((sm: any) => {
      if (!sm.isPassed || sm.grade === 'F' || sm.attendanceStatus === 'Absent') {
        backlogCount++;
      }
    });
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <UserCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Supplementary Registration</h1>
                <Badge variant="neutral" size="sm">
                  Registration Window Closed
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-slate-500" />
            <span>COE Arrear Clearing Portal</span>
          </div>
        </div>
      </div>

      {/* Unavailable State Card */}
      <div className="bg-white rounded-xl p-8 sm:p-12 border border-[#e2e8f0] shadow-xs text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-[#64748b] flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8 text-[#94a3b8]" />
        </div>

        <div className="space-y-2 max-w-lg mx-auto">
          <h2 className="text-base font-bold text-[#1e293b]">
            Supplementary Registration is Currently Inactive
          </h2>
          <p className="text-xs text-[#64748b] leading-relaxed">
            The supplementary and backlog examination registration window is officially closed. Supplementary cycles are announced by the Controller of Examinations (COE) following the declaration and scrutiny of regular semester examination results.
          </p>
          <div className="pt-2">
            <span className="text-xs text-[#64748b] inline-block bg-slate-100 px-3 py-1.5 rounded-lg border border-[#e2e8f0]">
              Candidate Active Backlogs: <strong className="text-[#1e293b]">{backlogCount} course(s)</strong>
            </span>
          </div>
        </div>

        <div className="pt-4 border-t border-[#f1f5f9] max-w-xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Supplementary Schedule
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              Supplementary examination slots are scheduled in vacation intervals or alongside end-semester cycles as approved by the Academic Council.
            </p>
          </div>

          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Registration Inquiries
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              For questions regarding supplementary course eligibility and fee clearances, visit the Examination Cell counter during working hours.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
