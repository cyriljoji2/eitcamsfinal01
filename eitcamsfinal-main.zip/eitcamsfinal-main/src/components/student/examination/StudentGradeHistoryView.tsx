import React from 'react';
import {
  History,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Calendar,
  Printer,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicSubject } from '../../../types/academic';
import { Examination, StudentExamResult } from '../../../types/examination';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentGradeHistoryViewProps {
  student: Student;
  results: StudentExamResult[];
  examinations: Examination[];
  subjects: AcademicSubject[];
  onViewResult?: (result: StudentExamResult) => void;
}

const GRADE_POINTS: Record<string, number> = {
  'A+': 10.0,
  A: 9.0,
  B: 8.0,
  C: 7.0,
  D: 6.0,
  E: 5.0,
  F: 0.0,
};

export function StudentGradeHistoryView({
  student,
  results,
  examinations,
  subjects,
  onViewResult,
}: StudentGradeHistoryViewProps) {
  // Published results represent authoritative recorded history
  const publishedResults = results.filter((res) => {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
    );
    return res.verificationStatus === 'Published' || (parentExam && parentExam.status === 'Published');
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <History className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Grade History</h1>
                <Badge variant="blue" size="sm">
                  {publishedResults.length} Semester Records
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Program/Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Official Academic Ledger</span>
          </div>
        </div>
      </div>

      {publishedResults.length === 0 ? (
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-[#64748b] flex items-center justify-center mx-auto">
            <History className="w-6 h-6 text-[#94a3b8]" />
          </div>
          <h3 className="text-sm font-bold text-[#1e293b]">No Historical Examination Records Found</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Historical transcript data across semesters is populated once end-semester examination results are officially closed, published, and archived into the permanent ledger.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* History Availability Notice if only 1 term is on file */}
          {publishedResults.length === 1 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-800">
                <p className="font-semibold">Showing available academic history (1 published term).</p>
                <p className="mt-0.5 text-amber-700">
                  Previous historical session records prior to the current academic year are not on file in the digital ledger for this candidate profile.
                </p>
              </div>
            </div>
          )}

          {publishedResults.map((result) => {
            const courseRows = (result.subjectMarks || []).map((sm: any) => {
              const matchedSubject = subjects.find(
                (s) => s.code.toLowerCase() === sm.subjectCode.toLowerCase()
              );
              const credits = (matchedSubject as any)?.credits || 3;
              const gradePoint = sm.grade ? (GRADE_POINTS[sm.grade] ?? 0) : 0;
              return {
                ...sm,
                credits,
                gradePoint,
              };
            });

            return (
              <div
                key={result.id}
                className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden"
              >
                {/* Session / Term Banner */}
                <div className="p-5 border-b border-[#e2e8f0] bg-[#f8fafc] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="text-sm font-bold text-[#1e293b]">
                        Academic Session: {result.academicSession || '2026-2027'}
                      </span>
                      <span className="text-xs bg-white font-mono px-2 py-0.5 rounded border border-[#e2e8f0] text-[#475569]">
                        {result.className || 'B.Tech CSE'} (Sec {result.section || 'A'})
                      </span>
                    </div>
                    <span className="text-xs text-[#64748b] mt-0.5 block">
                      {result.examinationName}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <Badge variant={(result.resultStatus || result.status) === 'Pass' || (result.resultStatus || result.status) === 'Passed' ? 'emerald' : 'rose'} size="sm">
                      {String(result.resultStatus || result.status || 'PASS').toUpperCase()}
                    </Badge>
                    <span className="text-xs font-bold text-[#1e3a8a] bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200">
                      Overall: {result.overallGrade} ({result.percentage}%)
                    </span>
                  </div>
                </div>

                {/* Subject Records Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-[#1e293b]">
                    <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                      <tr>
                        <th className="px-5 py-3">Academic Session</th>
                        <th className="px-5 py-3">Semester</th>
                        <th className="px-5 py-3">Course Code</th>
                        <th className="px-5 py-3">Course</th>
                        <th className="px-5 py-3 text-center">Credits</th>
                        <th className="px-5 py-3 text-center">Grade</th>
                        <th className="px-5 py-3 text-center">Grade Point</th>
                        <th className="px-5 py-3 text-center">Result Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#e2e8f0]">
                      {courseRows.map((course: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50 transition-colors">
                          <td className="px-5 py-3.5 font-medium text-[#475569] whitespace-nowrap">
                            {result.academicSession}
                          </td>
                          <td className="px-5 py-3.5 text-[#475569] whitespace-nowrap">
                            {result.className}
                          </td>
                          <td className="px-5 py-3.5 font-mono font-medium text-[#64748b]">
                            {course.subjectCode}
                          </td>
                          <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                            {course.subjectName}
                          </td>
                          <td className="px-5 py-3.5 text-center text-[#475569]">
                            {course.credits}
                          </td>
                          <td className="px-5 py-3.5 text-center font-bold text-[#1e3a8a]">
                            {course.grade || '—'}
                          </td>
                          <td className="px-5 py-3.5 text-center font-mono font-semibold text-[#334155]">
                            {course.gradePoint.toFixed(1)}
                          </td>
                          <td className="px-5 py-3.5 text-center">
                            <span
                              className={`inline-flex items-center gap-1 font-bold text-[11px] ${
                                course.isPassed ? 'text-emerald-700' : 'text-rose-700'
                              }`}
                            >
                              {course.isPassed ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              )}
                              {course.isPassed ? 'Pass' : 'Fail'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {onViewResult && (
                  <div className="p-3 bg-[#f8fafc] border-t border-[#e2e8f0] flex justify-end">
                    <Button
                      id={`btn-history-print-${result.id}`}
                      variant="outline"
                      size="sm"
                      onClick={() => onViewResult(result)}
                      leftIcon={<Printer className="w-4 h-4" />}
                    >
                      View Marksheet
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
