import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Building,
  ShieldCheck,
  Award,
  Filter,
  CheckCircle2,
  AlertCircle,
  FileText,
  Printer,
  ChevronRight,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Examination, ExamSubjectSchedule, HallTicket } from '../../../types/examination';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';
import { StudentSemesterSelector } from '../common/StudentSemesterSelector';
import { getStudentAvailableSemesters, doesExamMatchSemester } from '../../../utils/studentSemesterUtils';

interface StudentExamScheduleViewProps {
  student: Student;
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  hallTickets: HallTicket[];
  onViewHallTicket?: (hallTicket: HallTicket) => void;
  onNavigateToHallTickets?: () => void;
}

export function StudentExamScheduleView({
  student,
  examinations,
  schedules,
  hallTickets,
  onViewHallTicket,
  onNavigateToHallTickets,
}: StudentExamScheduleViewProps) {
  const [selectedSemester, setSelectedSemester] = useState<string>('');
  const [selectedExamId, setSelectedExamId] = useState<string>('');

  // Available registered semesters for this student
  const availableSemesters = useMemo(() => {
    return getStudentAvailableSemesters({
      student,
      examinations,
    });
  }, [student, examinations]);

  // Examinations applicable to the selected semester
  const semesterExaminations = useMemo(() => {
    if (!selectedSemester) return [];
    return examinations.filter((exam) => doesExamMatchSemester(exam, selectedSemester));
  }, [examinations, selectedSemester]);

  // Active examination within this semester
  const activeExam = useMemo(() => {
    if (semesterExaminations.length === 0) return null;
    return (
      semesterExaminations.find((e) => e.id.toLowerCase() === selectedExamId.toLowerCase()) ||
      semesterExaminations[0]
    );
  }, [semesterExaminations, selectedExamId]);

  // Filter schedules strictly for the student's class / section and active examination
  const studentClassName = (student.admissionClass || '').trim().toLowerCase();
  const studentSection = (student.section || '').trim().toLowerCase();

  const activeSchedules = useMemo(() => {
    if (!activeExam) return [];

    return schedules
      .filter((s) => {
        const isSameExam = s.examinationId.toLowerCase() === activeExam.id.toLowerCase();
        if (!isSameExam) return false;

        // Class matching
        const schedClass = (s.className || '').trim().toLowerCase();
        const isClassMatch =
          schedClass === studentClassName ||
          schedClass.includes(studentClassName) ||
          studentClassName.includes(schedClass) ||
          schedClass === 'all';

        // Section matching
        const schedSec = (s.section || '').trim().toLowerCase();
        const isSecMatch =
          schedSec === 'all' ||
          schedSec === studentSection ||
          !studentSection;

        return isClassMatch && isSecMatch;
      })
      .sort((a, b) => a.examDate.localeCompare(b.examDate));
  }, [activeExam, schedules, studentClassName, studentSection]);

  // Find candidate's issued hall ticket for this active examination
  const matchingHallTicket = useMemo(() => {
    if (!activeExam) return null;
    return (
      hallTickets.find(
        (ht) =>
          ht.examinationId.toLowerCase() === activeExam.id.toLowerCase() &&
          ht.studentRegistrationNumber.toLowerCase() === student.registrationNumber.toLowerCase()
      ) || null
    );
  }, [activeExam, hallTickets, student.registrationNumber]);

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Calendar className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Exam Schedule</h1>
                <Badge variant="blue" size="sm">
                  {examinations.length} Active Series
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass} (Sec {student.section})</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {matchingHallTicket ? (
              <Button
                id="btn-view-hallticket-schedule"
                variant="primary"
                size="sm"
                onClick={() => onViewHallTicket ? onViewHallTicket(matchingHallTicket) : onNavigateToHallTickets?.()}
                leftIcon={<Award className="w-4 h-4" />}
              >
                View Hall Ticket
              </Button>
            ) : onNavigateToHallTickets ? (
              <Button
                id="btn-nav-halltickets"
                variant="outline"
                size="sm"
                onClick={onNavigateToHallTickets}
                leftIcon={<Award className="w-4 h-4" />}
              >
                Hall Tickets
              </Button>
            ) : null}
            <div className="hidden md:flex items-center gap-2 bg-[#f8fafc] px-3 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>COE Authoritative Timetable</span>
            </div>
          </div>
        </div>
      </div>

      {/* Semester Dropdown */}
      <StudentSemesterSelector
        id="student-exam-schedule-semester"
        selectedSemester={selectedSemester}
        onChange={(sem) => {
          setSelectedSemester(sem);
          setSelectedExamId('');
        }}
        availableSemesters={availableSemesters}
        helperText="* Only Registered Semester"
      />

      {!selectedSemester ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Calendar className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Please select a semester to view exam schedule
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Choose a registered semester from the dropdown above to display official examination dates, timings, and venue allocations.
          </p>
        </div>
      ) : semesterExaminations.length === 0 || !activeExam || activeSchedules.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Clock className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            No examination schedule published for this semester.
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            The Controller of Examinations has not published paper schedules for the selected semester.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Examination Selector Tabs if multiple exams in this semester */}
          {semesterExaminations.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {semesterExaminations.map((exam) => (
                <button
                  key={exam.id}
                  id={`tab-exam-${exam.id}`}
                  type="button"
                  onClick={() => setSelectedExamId(exam.id)}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                    activeExam?.id === exam.id
                      ? 'bg-[#1e3a8a] text-white border-[#1e3a8a] shadow-xs'
                      : 'bg-white text-[#475569] border-[#cbd5e1] hover:bg-slate-50'
                  }`}
                >
                  {exam.name}
                </button>
              ))}
            </div>
          )}

          {/* Active Exam Overview */}
          <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base font-bold text-[#1e293b]">{activeExam.name}</h2>
                  <Badge
                    variant={
                      activeExam.status === 'Published'
                        ? 'emerald'
                        : activeExam.status === 'Active' || activeExam.status === 'Mark Entry Open'
                        ? 'blue'
                        : 'neutral'
                    }
                    size="sm"
                  >
                    {activeExam.status}
                  </Badge>
                  <span className="text-xs text-[#64748b] font-mono bg-slate-100 px-2 py-0.5 rounded">
                    Term: {activeExam.termType}
                  </span>
                  <span className="text-xs text-[#64748b] font-mono bg-slate-100 px-2 py-0.5 rounded">
                    Session: {activeExam.academicSession}
                  </span>
                </div>
                <p className="text-xs text-[#64748b] mt-2 leading-relaxed">
                  {activeExam.instructions || 'Official scheduled institutional assessments and papers.'}
                </p>
              </div>

              <div className="text-xs text-[#475569] bg-[#f8fafc] p-3 rounded-lg border border-[#e2e8f0] shrink-0">
                <span className="text-[#64748b] block text-[11px] font-semibold uppercase">Exam Window</span>
                <span className="font-bold text-[#1e293b] mt-0.5 block">
                  {activeExam.startDate} to {activeExam.endDate}
                </span>
                <span className="text-[11px] text-[#64748b] block mt-1">
                  Status: {activeExam.status}
                </span>
              </div>
            </div>
          </div>

          {/* Schedule Table */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#1e3a8a]" />
                <h3 className="text-sm font-bold text-[#1e293b]">Subject Schedule & Venue Details</h3>
              </div>
              <span className="text-xs text-[#64748b] font-medium">
                {activeSchedules.length} Papers Scheduled
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#1e293b]">
                <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3">Time Window</th>
                    <th className="px-5 py-3">Subject Name & Code</th>
                    <th className="px-5 py-3">Mode</th>
                    <th className="px-5 py-3">Venue / Room</th>
                    <th className="px-5 py-3 text-right">Max Marks</th>
                    <th className="px-5 py-3 text-right">Pass Marks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {activeSchedules.map((sch) => {
                    const isOnline =
                      sch.roomVenue?.toLowerCase().includes('online') ||
                      sch.roomVenue?.toLowerCase().includes('virtual') ||
                      (sch as any).mode?.toLowerCase() === 'online';

                    return (
                      <tr key={sch.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-5 py-3.5 font-bold text-[#1e293b] whitespace-nowrap">
                          {sch.examDate}
                        </td>
                        <td className="px-5 py-3.5 text-[#475569] whitespace-nowrap">
                          <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-mono font-medium">
                            {sch.startTime} – {sch.endTime}
                          </span>
                        </td>
                        <td className="px-5 py-3.5">
                          <span className="font-semibold text-[#1e293b] block">
                            {sch.subjectName}
                          </span>
                          <span className="text-[10px] text-[#64748b] font-mono">
                            {sch.subjectCode}
                          </span>
                        </td>
                        <td className="px-5 py-3.5">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                              isOnline
                                ? 'bg-purple-50 text-purple-700 border border-purple-200'
                                : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            }`}
                          >
                            {isOnline ? 'Online' : 'Offline'}
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-[#475569]">
                          <div className="flex items-center gap-1.5">
                            <Building className="w-3.5 h-3.5 text-[#94a3b8] shrink-0" />
                            <span>{sch.roomVenue || 'Examination Hall'}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-right font-medium text-[#1e293b]">
                          {sch.maxMarks}
                        </td>
                        <td className="px-5 py-3.5 text-right font-semibold text-emerald-700">
                          {sch.passMarks}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
