import React, { useState, useMemo } from 'react';
import {
  Award,
  Printer,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  TrendingUp,
  FileText,
  Clock,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicSubject } from '../../../types/academic';
import { Examination, StudentExamResult } from '../../../types/examination';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';
import { StudentSemesterSelector } from '../common/StudentSemesterSelector';
import {
  getStudentAvailableSemesters,
  doesResultMatchSemester,
} from '../../../utils/studentSemesterUtils';

interface StudentGradesViewProps {
  student: Student;
  results: StudentExamResult[];
  examinations: Examination[];
  subjects: AcademicSubject[];
  onViewResult: (result: StudentExamResult) => void;
}

const GRADE_POINTS: Record<string, number> = {
  'A+': 10.0,
  A: 9.0,
  B: 8.0,
  C: 7.0,
  D: 6.0,
  E: 5.0,
  F: 0.0,
};

export function StudentGradesView({
  student,
  results,
  examinations,
  subjects,
  onViewResult,
}: StudentGradesViewProps) {
  const [selectedSemester, setSelectedSemester] = useState<string>('');

  // Available registered semesters for this student
  const availableSemesters = useMemo(() => {
    return getStudentAvailableSemesters({
      student,
      examinations,
      results,
    });
  }, [student, examinations, results]);

  // Filter for published or verified results
  const publishedResults = useMemo(() => {
    return results.filter((res) => {
      const parentExam = examinations.find(
        (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
      );
      return res.verificationStatus === 'Published' || (parentExam && parentExam.status === 'Published');
    });
  }, [results, examinations]);

  // Filter published results strictly for the selected semester
  const semesterResults = useMemo(() => {
    if (!selectedSemester) return [];
    return publishedResults.filter((res) =>
      doesResultMatchSemester(res, selectedSemester, examinations)
    );
  }, [publishedResults, selectedSemester, examinations]);

  // Calculate semester stats across published results for the chosen semester
  const { semesterSgpa, totalCreditsAccumulated, allPassed } = useMemo(() => {
    let totalGradePointsCredits = 0;
    let totalCredits = 0;
    let passed = true;

    semesterResults.forEach((res) => {
      (res.subjectMarks || []).forEach((sm: any) => {
        const matchedSubject = subjects.find(
          (s) => s.code.toLowerCase() === sm.subjectCode.toLowerCase()
        );
        const credits = (matchedSubject as any)?.credits || 3;
        const gp = sm.grade ? (GRADE_POINTS[sm.grade] ?? 0) : 0;
        totalGradePointsCredits += credits * gp;
        totalCredits += credits;
        if (!sm.isPassed) passed = false;
      });
    });

    const sgpa =
      totalCredits > 0
        ? (Math.round((totalGradePointsCredits / totalCredits) * 100) / 100).toFixed(2)
        : null;

    return {
      semesterSgpa: sgpa,
      totalCreditsAccumulated: totalCredits,
      allPassed: passed,
    };
  }, [semesterResults, subjects]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Grades & SGPA</h1>
                {selectedSemester && (
                  <Badge variant="emerald" size="sm">
                    {semesterResults.length} Published Terms
                  </Badge>
                )}
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
                </span>
                {selectedSemester && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{selectedSemester}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>COE Verified Grades</span>
          </div>
        </div>
      </div>

      {/* Semester Dropdown */}
      <StudentSemesterSelector
        id="student-grades-semester"
        selectedSemester={selectedSemester}
        onChange={setSelectedSemester}
        availableSemesters={availableSemesters}
        helperText="* Only Registered Semester"
      />

      {!selectedSemester ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Award className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Please select a semester to view grades
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Choose a registered semester from the dropdown above to view official grade reports, earned course credits, and SGPA evaluations.
          </p>
        </div>
      ) : semesterResults.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Clock className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Grades have not been published for this semester.
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Grade reports for candidate {student.registrationNumber} are released once moderation and verification by the Controller of Examinations are formally completed.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Semester GPA Summary Banner */}
          {semesterSgpa && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Semester SGPA
                </span>
                <span className="text-2xl font-black text-[#1e3a8a] mt-1 block">
                  {semesterSgpa} <span className="text-xs text-[#64748b] font-normal">/ 10.0</span>
                </span>
              </div>

              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Earned Credits
                </span>
                <span className="text-2xl font-bold text-emerald-700 mt-1 block">
                  {totalCreditsAccumulated}
                </span>
              </div>

              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Academic Standing
                </span>
                <span className={`text-sm font-bold mt-2 block flex items-center gap-1.5 ${
                  allPassed ? 'text-emerald-700' : 'text-amber-700'
                }`}>
                  {allPassed ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      Good Standing / Passed
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" />
                      Pending Clearance
                    </>
                  )}
                </span>
              </div>
            </div>
          )}

          {/* Result Cards */}
          {semesterResults.map((result) => {
            // Compute SGPA for this specific result
            let semPoints = 0;
            let semCredits = 0;

            const courseRows = (result.subjectMarks || []).map((sm: any) => {
              const matchedSubject = subjects.find(
                (s) => s.code.toLowerCase() === sm.subjectCode.toLowerCase()
              );
              const credits = (matchedSubject as any)?.credits || 3;
              const gradePoint = sm.grade ? (GRADE_POINTS[sm.grade] ?? 0) : 0;
              semPoints += credits * gradePoint;
              semCredits += credits;

              return {
                ...sm,
                credits,
                gradePoint,
              };
            });

            const sgpa = semCredits > 0 ? (Math.round((semPoints / semCredits) * 100) / 100).toFixed(2) : '—';

            return (
              <div
                key={result.id}
                className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden"
              >
                {/* Result Card Top Banner */}
                <div className="p-5 border-b border-[#e2e8f0] bg-[#f8fafc] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <h2 className="text-base font-bold text-[#1e293b]">
                        {result.examinationName}
                      </h2>
                      <Badge variant={(result.resultStatus || result.status) === 'Passed' || (result.resultStatus || result.status) === 'Pass' ? 'emerald' : 'rose'} size="sm">
                        {String(result.resultStatus || result.status || 'PASS').toUpperCase()}
                      </Badge>
                      <span className="text-xs text-[#64748b] font-mono bg-white px-2 py-0.5 rounded border border-[#e2e8f0]">
                        Session: {result.academicSession || '2026-2027'}
                      </span>
                    </div>
                    <p className="text-xs text-[#64748b] mt-1">
                      Semester / Class: {result.className || 'B.Tech CSE'} (Sec {result.section || 'A'})
                    </p>
                  </div>

                  <div className="flex items-center gap-4 bg-white px-4 py-2 rounded-lg border border-[#e2e8f0]">
                    <div className="text-center">
                      <span className="text-[10px] text-[#64748b] block font-semibold uppercase">SGPA</span>
                      <span className="text-base font-bold text-[#1e3a8a]">{sgpa}</span>
                    </div>
                    <div className="h-6 w-px bg-slate-200" />
                    <div className="text-center">
                      <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Overall Grade</span>
                      <span className="text-base font-black text-emerald-700">{result.overallGrade || result.grade || 'A'}</span>
                    </div>
                    <div className="h-6 w-px bg-slate-200" />
                    <div className="text-center">
                      <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Percentage</span>
                      <span className="text-sm font-bold text-[#334155]">{result.percentage}%</span>
                    </div>
                  </div>
                </div>

                {/* Subject Grades Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-[#1e293b]">
                    <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                      <tr>
                        <th className="px-5 py-3">Course Code</th>
                        <th className="px-5 py-3">Course Name</th>
                        <th className="px-5 py-3 text-center">Credits</th>
                        <th className="px-5 py-3 text-center">Grade</th>
                        <th className="px-5 py-3 text-center">Grade Point</th>
                        <th className="px-5 py-3 text-center">Result Status</th>
                        <th className="px-5 py-3">Semester</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#e2e8f0]">
                      {courseRows.map((course: any, idx: number) => (
                        <tr key={idx} className="hover:bg-slate-50 transition-colors">
                          <td className="px-5 py-3.5 font-mono font-medium text-[#64748b]">
                            {course.subjectCode}
                          </td>
                          <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                            {course.subjectName}
                          </td>
                          <td className="px-5 py-3.5 text-center font-medium text-[#475569]">
                            {course.credits}
                          </td>
                          <td className="px-5 py-3.5 text-center font-bold text-[#1e3a8a] text-sm">
                            {course.grade || '—'}
                          </td>
                          <td className="px-5 py-3.5 text-center font-mono font-semibold text-[#334155]">
                            {course.gradePoint.toFixed(1)}
                          </td>
                          <td className="px-5 py-3.5 text-center">
                            <span
                              className={`inline-flex items-center gap-1 font-bold text-[11px] ${
                                course.isPassed ? 'text-emerald-700' : 'text-rose-700'
                              }`}
                            >
                              {course.isPassed ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              )}
                              {course.isPassed ? 'Pass' : 'Fail'}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 text-[#64748b]">
                            {selectedSemester}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Footer Action */}
                <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-3">
                  <span className="text-xs text-[#64748b]">
                    Transcripts certified by EIT Controller of Examination (COE).
                  </span>
                  <Button
                    id={`btn-grade-transcript-${result.id}`}
                    variant="primary"
                    size="sm"
                    onClick={() => onViewResult(result)}
                    leftIcon={<Printer className="w-4 h-4" />}
                  >
                    Print Official Marksheet
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
