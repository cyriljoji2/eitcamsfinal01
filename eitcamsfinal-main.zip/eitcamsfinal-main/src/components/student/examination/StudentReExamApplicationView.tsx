import React from 'react';
import {
  FilePlus,
  ShieldCheck,
  AlertCircle,
  Calendar,
  Clock,
  HelpCircle,
  Lock,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentReExamApplicationViewProps {
  student: Student;
}

export function StudentReExamApplicationView({
  student,
}: StudentReExamApplicationViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <FilePlus className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Re-Exam Application</h1>
                <Badge variant="neutral" size="sm">
                  Application Closed
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-slate-500" />
            <span>COE Authorization Gate</span>
          </div>
        </div>
      </div>

      {/* Unavailable State Card */}
      <div className="bg-white rounded-xl p-8 sm:p-12 border border-[#e2e8f0] shadow-xs text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-[#64748b] flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8 text-[#94a3b8]" />
        </div>

        <div className="space-y-2 max-w-lg mx-auto">
          <h2 className="text-base font-bold text-[#1e293b]">
            Re-Examination Application Window Closed
          </h2>
          <p className="text-xs text-[#64748b] leading-relaxed">
            The Controller of Examinations (COE) has not scheduled any special re-examination or make-up assessment sessions for the active academic term. Applications are strictly accepted only during designated COE notification windows for eligible candidates.
          </p>
          <p className="text-xs text-[#64748b] leading-relaxed">
            Students cannot apply for arbitrary courses outside of formally approved institutional cycles and eligibility verifications.
          </p>
        </div>

        <div className="pt-4 border-t border-[#f1f5f9] max-w-xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Eligibility Criteria
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              Re-examination applications require institutional sanction (e.g., medical leave approved by Dean of Academics, or official university sports representation).
            </p>
          </div>

          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#1e3a8a]" />
              COE Helpdesk
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              Inquiries regarding exceptional re-examination sanctions should be routed through the Office of Academic Affairs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
