import React from 'react';
import {
  FileSearch,
  ShieldCheck,
  AlertCircle,
  Clock,
  HelpCircle,
  Calendar,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Examination } from '../../../types/examination';
import { Badge } from '../../ui/Badge';

interface StudentPaperSeeRevViewProps {
  student: Student;
  examinations: Examination[];
}

export function StudentPaperSeeRevView({
  student,
  examinations,
}: StudentPaperSeeRevViewProps) {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <FileSearch className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Paper Seeing & Revaluation</h1>
                <Badge variant="neutral" size="sm">
                  Window Closed
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-[#1e3a8a]" />
            <span>COE Scrutiny Guidelines</span>
          </div>
        </div>
      </div>

      {/* Unavailable / Window Inactive State Card */}
      <div className="bg-white rounded-xl p-8 sm:p-12 border border-[#e2e8f0] shadow-xs text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-[#64748b] flex items-center justify-center mx-auto">
          <FileSearch className="w-8 h-8 text-[#94a3b8]" />
        </div>

        <div className="space-y-2 max-w-lg mx-auto">
          <h2 className="text-base font-bold text-[#1e293b]">
            Paper Seeing / Revaluation Window is Not Currently Active
          </h2>
          <p className="text-xs text-[#64748b] leading-relaxed">
            As per institutional examination regulations, requests for answer script viewing, re-totaling, and grade revaluation are formally opened for a designated 5-day window immediately following the official declaration of end-semester results.
          </p>
          <p className="text-xs text-[#64748b] leading-relaxed">
            No active revaluation window is currently scheduled for candidate registration number <strong className="text-[#334155] font-mono">{student.registrationNumber}</strong>.
          </p>
        </div>

        <div className="pt-4 border-t border-[#f1f5f9] max-w-xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
              Window Timelines
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              Window notifications are published via the Student Portal and institutional notice boards within 48 hours of result announcements.
            </p>
          </div>

          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#1e3a8a]" />
              COE Grievance Support
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              For urgent discrepancies or marksheet verification inquiries, contact the Examination Cell directly at <span className="font-mono text-[#1e3a8a]">coe@eit.edu</span>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
