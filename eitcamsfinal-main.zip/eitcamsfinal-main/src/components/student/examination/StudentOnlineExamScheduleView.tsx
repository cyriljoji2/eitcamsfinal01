import React from 'react';
import {
  Monitor,
  Calendar,
  Clock,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  Laptop,
  BookOpen,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Examination, ExamSubjectSchedule } from '../../../types/examination';
import { Badge } from '../../ui/Badge';

interface StudentOnlineExamScheduleViewProps {
  student: Student;
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
}

export function StudentOnlineExamScheduleView({
  student,
  examinations,
  schedules,
}: StudentOnlineExamScheduleViewProps) {
  const studentClassName = (student.admissionClass || '').trim().toLowerCase();
  const studentSection = (student.section || '').trim().toLowerCase();

  // Filter schedules strictly for the student's class and where mode is online
  const onlineSchedules = schedules.filter((sch) => {
    // Check class/section match
    const schedClass = (sch.className || '').trim().toLowerCase();
    const isClassMatch =
      schedClass === studentClassName ||
      schedClass.includes(studentClassName) ||
      studentClassName.includes(schedClass) ||
      schedClass === 'all';

    const schedSec = (sch.section || '').trim().toLowerCase();
    const isSecMatch =
      schedSec === 'all' ||
      schedSec === studentSection ||
      !studentSection;

    if (!isClassMatch || !isSecMatch) return false;

    // Strict online mode detection based on authoritative data
    const roomStr = (sch.roomVenue || '').toLowerCase();
    const isOnlineVenue = roomStr.includes('online') || roomStr.includes('virtual') || roomStr.includes('remote');
    const isOnlineMode = (sch as any).mode?.toLowerCase() === 'online' || (sch as any).examMode?.toLowerCase() === 'online';

    return isOnlineVenue || isOnlineMode;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-purple-700 text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Laptop className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Online Exam Schedule</h1>
                <Badge variant="purple" size="sm">
                  {onlineSchedules.length} Scheduled
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            <span>Digital Assessment Portal</span>
          </div>
        </div>
      </div>

      {/* Online Schedules List or Truthful Empty State */}
      {onlineSchedules.length === 0 ? (
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-slate-100 text-[#64748b] flex items-center justify-center mx-auto">
            <Laptop className="w-8 h-8 text-[#94a3b8]" />
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-base font-bold text-[#1e293b]">
              No online examinations are currently scheduled.
            </h3>
            <p className="text-xs text-[#64748b] leading-relaxed">
              All currently scheduled examinations for your academic cohort are conducted in-person within physical examination halls and lecture theaters. Any online proctored or remote assessments scheduled by the Controller of Examinations will appear here.
            </p>
          </div>
          <div className="pt-2 text-xs text-[#94a3b8]">
            Authoritative Status: 0 active online proctored sessions for session {examinations[0]?.academicSession || '2026-27'}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {onlineSchedules.map((sch) => {
            const parentExam = examinations.find(
              (e) => e.id.toLowerCase() === sch.examinationId.toLowerCase()
            );

            // Compute duration if start and end times are available
            let durationText = 'As per paper window';
            if (sch.startTime && sch.endTime) {
              const [sh, sm] = sch.startTime.split(':').map(Number);
              const [eh, em] = sch.endTime.split(':').map(Number);
              if (!isNaN(sh) && !isNaN(eh)) {
                const totalMins = (eh * 60 + (em || 0)) - (sh * 60 + (sm || 0));
                if (totalMins > 0) {
                  const hours = Math.floor(totalMins / 60);
                  const mins = totalMins % 60;
                  durationText = hours > 0 ? `${hours} hr${hours > 1 ? 's' : ''} ${mins > 0 ? `${mins} min` : ''}` : `${mins} mins`;
                }
              }
            }

            const existingOnlineUrl = (sch as any).onlineExamUrl || (sch as any).examUrl;

            return (
              <div
                key={sch.id}
                className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-6 space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#e2e8f0]">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-[#1e293b]">
                        {sch.subjectName}
                      </h3>
                      <span className="text-xs font-mono bg-slate-100 text-[#475569] px-2 py-0.5 rounded">
                        {sch.subjectCode}
                      </span>
                    </div>
                    <span className="text-xs text-[#64748b] mt-0.5 block">
                      Series: {parentExam?.name || sch.examinationId}
                    </span>
                  </div>

                  <Badge variant="purple" size="sm">
                    Online Proctored
                  </Badge>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-[#64748b] block text-[11px]">Examination Date</span>
                    <span className="font-bold text-[#1e293b] mt-0.5 block">{sch.examDate}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block text-[11px]">Time Window</span>
                    <span className="font-bold text-[#1e293b] mt-0.5 block">{sch.startTime} – {sch.endTime}</span>
                  </div>
                  <div>
                    <span className="text-[#64748b] block text-[11px]">Paper Duration</span>
                    <span className="font-bold text-[#1e293b] mt-0.5 block">{durationText}</span>
                  </div>
                </div>

                {/* Instructions */}
                <div className="bg-[#f8fafc] rounded-lg p-3 text-xs text-[#475569] border border-[#e2e8f0] space-y-1">
                  <span className="font-semibold text-[#1e293b] block">Online Examination Instructions:</span>
                  <p className="text-[11px] text-[#64748b] leading-relaxed">
                    {parentExam?.instructions || 'Ensure continuous high-speed internet connectivity, working webcam, and microphone. Login 10 minutes prior to paper start.'}
                  </p>
                </div>

                {/* Authoritative URL Link */}
                {existingOnlineUrl ? (
                  <div className="pt-2">
                    <a
                      href={existingOnlineUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-purple-700 text-white text-xs font-semibold hover:bg-purple-800 transition-colors"
                    >
                      <span>Access Online Examination Portal</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ) : (
                  <div className="text-[11px] text-[#94a3b8]">
                    Online testing credentials and session links will be activated by the invigilator 15 minutes prior to commencement.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
