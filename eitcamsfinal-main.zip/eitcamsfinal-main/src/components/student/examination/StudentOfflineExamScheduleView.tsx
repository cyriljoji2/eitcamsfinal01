import React from 'react';
import {
  Building,
  Calendar,
  Clock,
  ShieldCheck,
  Award,
  MapPin,
  FileText,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Examination, ExamSubjectSchedule, HallTicket } from '../../../types/examination';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentOfflineExamScheduleViewProps {
  student: Student;
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  hallTickets: HallTicket[];
  onViewHallTicket?: (hallTicket: HallTicket) => void;
}

export function StudentOfflineExamScheduleView({
  student,
  examinations,
  schedules,
  hallTickets,
  onViewHallTicket,
}: StudentOfflineExamScheduleViewProps) {
  const studentClassName = (student.admissionClass || '').trim().toLowerCase();
  const studentSection = (student.section || '').trim().toLowerCase();

  // Filter schedules strictly for the student's class and where mode is offline
  const offlineSchedules = schedules
    .filter((sch) => {
      // Check class/section match
      const schedClass = (sch.className || '').trim().toLowerCase();
      const isClassMatch =
        schedClass === studentClassName ||
        schedClass.includes(studentClassName) ||
        studentClassName.includes(schedClass) ||
        schedClass === 'all';

      const schedSec = (sch.section || '').trim().toLowerCase();
      const isSecMatch =
        schedSec === 'all' ||
        schedSec === studentSection ||
        !studentSection;

      if (!isClassMatch || !isSecMatch) return false;

      // Offline check: not flagged as online
      const roomStr = (sch.roomVenue || '').toLowerCase();
      const isOnline = roomStr.includes('online') || roomStr.includes('virtual') || (sch as any).mode?.toLowerCase() === 'online';

      return !isOnline;
    })
    .sort((a, b) => a.examDate.localeCompare(b.examDate));

  // Get student's hall ticket if available to get center/seat info
  const candidateTicket = hallTickets.find(
    (ht) => ht.studentRegistrationNumber.toLowerCase() === student.registrationNumber.toLowerCase()
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Building className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Offline Exam Schedule</h1>
                <Badge variant="emerald" size="sm">
                  {offlineSchedules.length} In-Person Papers
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass} (Sec {student.section})</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {candidateTicket && onViewHallTicket && (
              <Button
                id="btn-offline-view-hallticket"
                variant="primary"
                size="sm"
                onClick={() => onViewHallTicket(candidateTicket)}
                leftIcon={<Award className="w-4 h-4" />}
              >
                View Hall Ticket
              </Button>
            )}
            <div className="hidden sm:flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Campus Examination Halls</span>
            </div>
          </div>
        </div>
      </div>

      {/* Institutional Center Card */}
      <div className="bg-white rounded-xl p-4 sm:p-5 border border-[#e2e8f0] shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <span className="text-[#64748b] block text-[11px] font-semibold uppercase">Examination Center</span>
            <span className="font-bold text-[#1e293b] mt-0.5 block">
              {candidateTicket?.schoolName || 'Electrix Institute of Technology (EIT)'}
            </span>
            <span className="text-[11px] text-[#64748b] mt-0.5 block">
              {candidateTicket?.schoolAddress || 'Main Campus Academic Blocks'}
            </span>
          </div>

          <div>
            <span className="text-[#64748b] block text-[11px] font-semibold uppercase">Candidate Status</span>
            <span className="font-bold text-emerald-700 mt-0.5 block flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Allocated & In-Person Eligible
            </span>
            <span className="text-[11px] text-[#64748b] mt-0.5 block">
              Reg No: {student.registrationNumber}
            </span>
          </div>

          <div>
            <span className="text-[#64748b] block text-[11px] font-semibold uppercase">Seat Allotment Notice</span>
            <span className="font-semibold text-[#1e293b] mt-0.5 block">
              {(candidateTicket as any)?.seatNumber || 'Allocated at hall entrance'}
            </span>
            <span className="text-[11px] text-[#64748b] mt-0.5 block">
              Check hall display boards 15 mins prior
            </span>
          </div>
        </div>
      </div>

      {/* Offline Schedules Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#1e3a8a]" />
            <h3 className="text-sm font-bold text-[#1e293b]">Classroom & Venue Allotments</h3>
          </div>
          <span className="text-xs text-[#64748b]">
            {offlineSchedules.length} Papers
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#1e293b]">
            <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Time</th>
                <th className="px-5 py-3">Subject Name & Code</th>
                <th className="px-5 py-3">Venue / Room</th>
                <th className="px-5 py-3">Examination Center</th>
                <th className="px-5 py-3">Semester / Term</th>
                <th className="px-5 py-3 text-right">Max Marks</th>
                <th className="px-5 py-3 text-right">Pass Marks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {offlineSchedules.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-[#94a3b8]">
                    No offline examinations currently scheduled for candidate.
                  </td>
                </tr>
              ) : (
                offlineSchedules.map((sch) => {
                  const parentExam = examinations.find(
                    (e) => e.id.toLowerCase() === sch.examinationId.toLowerCase()
                  );

                  return (
                    <tr key={sch.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-[#1e293b] whitespace-nowrap">
                        {sch.examDate}
                      </td>
                      <td className="px-5 py-3.5 text-[#475569] whitespace-nowrap">
                        <span className="bg-slate-100 px-2 py-0.5 rounded text-[11px] font-mono font-medium">
                          {sch.startTime} – {sch.endTime}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="font-semibold text-[#1e293b] block">
                          {sch.subjectName}
                        </span>
                        <span className="text-[10px] text-[#64748b] font-mono">
                          {sch.subjectCode}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1.5 font-medium text-[#1e293b]">
                          <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span>{sch.roomVenue || 'Examination Hall A'}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-[#64748b]">
                        <span>{candidateTicket?.schoolName || 'EIT Main Campus'}</span>
                      </td>
                      <td className="px-5 py-3.5 text-[#475569] whitespace-nowrap">
                        <span className="text-xs">
                          {parentExam?.termType || student.admissionClass}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right font-medium text-[#1e293b]">
                        {sch.maxMarks}
                      </td>
                      <td className="px-5 py-3.5 text-right font-semibold text-emerald-700">
                        {sch.passMarks}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
