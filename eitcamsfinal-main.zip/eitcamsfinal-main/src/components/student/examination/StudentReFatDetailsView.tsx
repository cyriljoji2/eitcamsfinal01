import React from 'react';
import {
  RotateCcw,
  CheckCircle2,
  ShieldCheck,
  AlertCircle,
  HelpCircle,
  Clock,
  BookOpen,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { StudentExamResult } from '../../../types/examination';
import { Badge } from '../../ui/Badge';

interface StudentReFatDetailsViewProps {
  student: Student;
  results: StudentExamResult[];
}

export function StudentReFatDetailsView({
  student,
  results,
}: StudentReFatDetailsViewProps) {
  // ReFAT (Repeat Final Assessment Test) is for students with course debarment or repeat requirements.
  // In the authoritative EIT system, check if any course has explicit ReFAT designation.
  const refatCourses: any[] = [];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <RotateCcw className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">ReFAT Details</h1>
                <Badge variant="emerald" size="sm">
                  0 Pending Requirements
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Final Assessment Test (FAT) Status</span>
          </div>
        </div>
      </div>

      {/* Truthful Empty State */}
      <div className="bg-white rounded-xl p-10 sm:p-14 border border-[#e2e8f0] shadow-xs text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <div className="space-y-1.5 max-w-md mx-auto">
          <h2 className="text-base font-bold text-[#1e293b]">
            No ReFAT Requirements
          </h2>
          <p className="text-xs text-[#64748b] leading-relaxed">
            No registered courses are currently flagged for Repeat Final Assessment Test (ReFAT) for the current academic session. All continuous assessment clearances and lecture attendance percentages meet COE threshold criteria.
          </p>
        </div>

        <div className="pt-4 border-t border-[#f1f5f9] max-w-xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
              ReFAT Policy Overview
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              ReFAT eligibility applies to students approved for repeat final examinations due to sanctioned medical leave or COE-permitted attendance exemptions.
            </p>
          </div>

          <div className="bg-[#f8fafc] p-3.5 rounded-lg border border-[#e2e8f0] text-xs space-y-1">
            <span className="font-semibold text-[#1e293b] flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-[#1e3a8a]" />
              COE Advisory Desk
            </span>
            <p className="text-[11px] text-[#64748b] leading-relaxed">
              If an approved dean's permission or medical leave has not reflected on your portal, submit the clearance receipt to the Examination Cell.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
