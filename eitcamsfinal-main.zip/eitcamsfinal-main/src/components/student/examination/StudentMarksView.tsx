import React, { useState, useMemo } from 'react';
import {
  FileText,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  Filter,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import {
  Examination,
  ExamSubjectSchedule,
  StudentSubjectMark,
  StudentExamResult,
} from '../../../types/examination';
import { Badge } from '../../ui/Badge';
import { StudentSemesterSelector } from '../common/StudentSemesterSelector';
import {
  getStudentAvailableSemesters,
  doesExamMatchSemester,
  doesResultMatchSemester,
} from '../../../utils/studentSemesterUtils';

interface StudentMarksViewProps {
  student: Student;
  marks: StudentSubjectMark[];
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
  results: StudentExamResult[];
}

export function StudentMarksView({
  student,
  marks,
  examinations,
  schedules,
  results,
}: StudentMarksViewProps) {
  const [selectedSemester, setSelectedSemester] = useState<string>('');
  const [selectedExamId, setSelectedExamId] = useState<string>('all');

  // Available registered semesters for this student
  const availableSemesters = useMemo(() => {
    return getStudentAvailableSemesters({
      student,
      examinations,
      results,
      marks,
    });
  }, [student, examinations, results, marks]);

  // Normalize student reg
  const studentReg = (student.registrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

  // Filter marks strictly for this student
  const studentMarks = useMemo(() => {
    return marks.filter((m) => {
      const reg = (m.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return reg === studentReg || m.studentRegistrationNumber === student.registrationNumber;
    });
  }, [marks, studentReg, student.registrationNumber]);

  // Filter examinations applicable to this semester
  const semesterExaminations = useMemo(() => {
    if (!selectedSemester) return [];
    return examinations.filter((exam) => doesExamMatchSemester(exam, selectedSemester));
  }, [examinations, selectedSemester]);

  // Aggregate marks strictly for the selected semester
  const aggregatedMarks = useMemo(() => {
    if (!selectedSemester) return [];

    const list: Array<{
      id: string;
      courseCode: string;
      courseName: string;
      assessment: string;
      marksObtained: number | null;
      maxMarks: number;
      passMarks: number;
      semester: string;
      attendanceStatus: string;
      isPassed: boolean;
      grade?: string;
      examinationId: string;
    }> = [];

    const seenKeys = new Set<string>();

    studentMarks.forEach((m) => {
      const parentExam = examinations.find(
        (e) => e.id.toLowerCase() === m.examinationId.toLowerCase()
      );

      // Check if mark belongs to selected semester
      const explicitMatch = m.semester && m.semester.trim().toLowerCase() === selectedSemester.trim().toLowerCase();
      const examMatch = parentExam && doesExamMatchSemester(parentExam, selectedSemester);

      if (explicitMatch || examMatch) {
        const key = `${m.examinationId}-${m.subjectCode}`.toLowerCase();
        seenKeys.add(key);

        list.push({
          id: m.id,
          courseCode: m.subjectCode,
          courseName: m.subjectName,
          assessment: parentExam?.name || parentExam?.termType || 'Institutional Assessment',
          marksObtained: m.marksObtained,
          maxMarks: m.maxMarks,
          passMarks: m.passMarks || 40,
          semester: selectedSemester,
          attendanceStatus: m.attendanceStatus || 'Present',
          isPassed: m.isPassed !== undefined ? m.isPassed : true,
          grade: m.grade,
          examinationId: m.examinationId,
        });
      }
    });

    // Also include marks from published results if any were verified at result level
    results.forEach((res) => {
      if (doesResultMatchSemester(res, selectedSemester, examinations)) {
        const parentExam = examinations.find(
          (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
        );
        (res.subjectMarks || []).forEach((sm: any, idx: number) => {
          const key = `${res.examinationId}-${sm.subjectCode}`.toLowerCase();
          if (!seenKeys.has(key)) {
            seenKeys.add(key);
            list.push({
              id: `res-${res.id}-${idx}`,
              courseCode: sm.subjectCode,
              courseName: sm.subjectName,
              assessment: res.examinationName || parentExam?.name || 'Semester Final',
              marksObtained: sm.marksObtained,
              maxMarks: sm.maxMarks,
              passMarks: sm.passMarks,
              semester: selectedSemester,
              attendanceStatus: sm.attendanceStatus,
              isPassed: sm.isPassed,
              grade: sm.grade,
              examinationId: res.examinationId,
            });
          }
        });
      }
    });

    return list;
  }, [selectedSemester, studentMarks, examinations, results]);

  // Filter by selected exam within the semester
  const filteredMarks = useMemo(() => {
    if (selectedExamId === 'all') return aggregatedMarks;
    return aggregatedMarks.filter((m) => m.examinationId.toLowerCase() === selectedExamId.toLowerCase());
  }, [aggregatedMarks, selectedExamId]);

  // Metrics
  const evaluatedMarks = filteredMarks.filter((m) => m.marksObtained !== null && m.attendanceStatus === 'Present');
  const totalScored = evaluatedMarks.reduce((acc, curr) => acc + (curr.marksObtained || 0), 0);
  const totalMax = evaluatedMarks.reduce((acc, curr) => acc + curr.maxMarks, 0);
  const aggregatePct = totalMax > 0 ? Math.round((totalScored / totalMax) * 100) : null;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <FileText className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Marks</h1>
                <Badge variant="blue" size="sm">
                  {filteredMarks.length} Assessment Entries
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Authoritative Marks System</span>
          </div>
        </div>
      </div>

      {/* Semester Dropdown */}
      <StudentSemesterSelector
        id="student-marks-semester"
        selectedSemester={selectedSemester}
        onChange={(sem) => {
          setSelectedSemester(sem);
          setSelectedExamId('all');
        }}
        availableSemesters={availableSemesters}
        helperText="* Only Registered Semester"
      />

      {!selectedSemester ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <FileText className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Please select a semester to view marks
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Choose a registered semester from the dropdown above to view subject assessment scores, maximum marks, and clearance records.
          </p>
        </div>
      ) : filteredMarks.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Clock className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Marks have not been published for this semester.
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Marks for candidate {student.registrationNumber} have not yet been submitted or finalized by subject instructors for the selected semester.
          </p>
        </div>
      ) : (
        <>
          {/* Summary Score Metrics */}
          {aggregatePct !== null && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Total Scored Marks
                </span>
                <span className="text-xl font-bold text-[#1e293b] mt-1 block">
                  {totalScored} <span className="text-xs text-[#64748b] font-normal">/ {totalMax}</span>
                </span>
              </div>

              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Aggregate Percentage
                </span>
                <span className="text-xl font-bold text-emerald-700 mt-1 block">
                  {aggregatePct}%
                </span>
              </div>

              <div className="bg-white rounded-xl p-4 border border-[#e2e8f0] shadow-xs">
                <span className="text-[11px] font-semibold text-[#64748b] uppercase tracking-wider block">
                  Clearance Rate
                </span>
                <span className="text-xl font-bold text-indigo-700 mt-1 block">
                  {evaluatedMarks.filter((m) => m.isPassed).length} / {evaluatedMarks.length} Passed
                </span>
              </div>
            </div>
          )}

          {/* Examination Filter Tabs within selected semester */}
          {semesterExaminations.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              <button
                type="button"
                onClick={() => setSelectedExamId('all')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                  selectedExamId === 'all'
                    ? 'bg-[#1e3a8a] text-white border-[#1e3a8a] shadow-xs'
                    : 'bg-white text-[#475569] border-[#cbd5e1] hover:bg-slate-50'
                }`}
              >
                All Assessments
              </button>
              {semesterExaminations.map((exam) => (
                <button
                  key={exam.id}
                  type="button"
                  onClick={() => setSelectedExamId(exam.id)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
                    selectedExamId === exam.id
                      ? 'bg-[#1e3a8a] text-white border-[#1e3a8a] shadow-xs'
                      : 'bg-white text-[#475569] border-[#cbd5e1] hover:bg-slate-50'
                  }`}
                >
                  {exam.name}
                </button>
              ))}
            </div>
          )}

          {/* Marks Table */}
          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#1e293b]">
                <thead className="bg-[#f8fafc] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                  <tr>
                    <th className="px-5 py-3">Course Code</th>
                    <th className="px-5 py-3">Course</th>
                    <th className="px-5 py-3">Assessment</th>
                    <th className="px-5 py-3 text-right">Marks</th>
                    <th className="px-5 py-3 text-right">Maximum</th>
                    <th className="px-5 py-3">Semester</th>
                    <th className="px-5 py-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e2e8f0]">
                  {filteredMarks.map((item) => {
                    const isAbsent = item.attendanceStatus === 'Absent';
                    const isPending = item.marksObtained === null && !isAbsent;

                    return (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-5 py-3.5 font-mono font-medium text-[#64748b]">
                          {item.courseCode}
                        </td>
                        <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                          {item.courseName}
                        </td>
                        <td className="px-5 py-3.5 text-[#475569]">
                          {item.assessment}
                        </td>
                        <td className="px-5 py-3.5 text-right font-bold text-[#1e293b]">
                          {isAbsent ? (
                            <span className="text-rose-600 font-semibold">Absent</span>
                          ) : isPending ? (
                            <span className="text-[#94a3b8] font-normal">Pending</span>
                          ) : (
                            item.marksObtained
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-right text-[#64748b]">
                          {item.maxMarks}
                        </td>
                        <td className="px-5 py-3.5 text-[#475569]">
                          {item.semester}
                        </td>
                        <td className="px-5 py-3.5 text-center">
                          {isAbsent ? (
                            <Badge variant="rose" size="sm">Absent</Badge>
                          ) : isPending ? (
                            <Badge variant="neutral" size="sm">In Evaluation</Badge>
                          ) : item.isPassed ? (
                            <Badge variant="emerald" size="sm">Passed</Badge>
                          ) : (
                            <Badge variant="rose" size="sm">Needs Improvement</Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
