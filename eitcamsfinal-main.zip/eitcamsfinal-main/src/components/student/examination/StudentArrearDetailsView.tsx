import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  FileWarning,
  HelpCircle,
  Clock,
  BookOpen,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { Examination, StudentExamResult, StudentSubjectMark } from '../../../types/examination';
import { Badge } from '../../ui/Badge';

interface StudentArrearDetailsViewProps {
  student: Student;
  results: StudentExamResult[];
  examinations: Examination[];
}

export function StudentArrearDetailsView({
  student,
  results,
  examinations,
}: StudentArrearDetailsViewProps) {
  // Extract any actual failed subjects or backlogs from published results
  const arrearCourses: Array<{
    courseCode: string;
    courseName: string;
    examinationName: string;
    academicSession: string;
    marksObtained: number | null;
    maxMarks: number;
    grade?: string;
    statusReason: string;
  }> = [];

  results.forEach((res) => {
    (res.subjectMarks || []).forEach((sm: any) => {
      const isFailed = !sm.isPassed || sm.grade === 'F' || sm.attendanceStatus === 'Absent';
      if (isFailed) {
        arrearCourses.push({
          courseCode: sm.subjectCode,
          courseName: sm.subjectName,
          examinationName: res.examinationName || 'Semester Exam',
          academicSession: res.academicSession || '2026-2027',
          marksObtained: sm.marksObtained,
          maxMarks: sm.maxMarks,
          grade: sm.grade,
          statusReason: sm.attendanceStatus === 'Absent' ? 'Absent' : 'Did Not Clear (F Grade)',
        });
      }
    });
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold shrink-0 shadow-xs ${
              arrearCourses.length > 0 ? 'bg-amber-600 text-white' : 'bg-emerald-600 text-white'
            }`}>
              {arrearCourses.length > 0 ? (
                <FileWarning className="w-7 h-7" />
              ) : (
                <CheckCircle2 className="w-7 h-7" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Arrear Details</h1>
                <Badge variant={arrearCourses.length > 0 ? 'amber' : 'emerald'} size="sm">
                  {arrearCourses.length === 0 ? '0 Active Arrears' : `${arrearCourses.length} Backlog(s)`}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Candidate: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • Class: <strong>{student.admissionClass}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Academic Clearance Status</span>
          </div>
        </div>
      </div>

      {arrearCourses.length === 0 ? (
        <div className="bg-white rounded-xl p-10 sm:p-14 border border-[#e2e8f0] shadow-xs text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-100">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-1.5 max-w-md mx-auto">
            <h2 className="text-base font-bold text-[#1e293b]">
              All Cleared — No Active Arrears
            </h2>
            <p className="text-xs text-[#64748b] leading-relaxed">
              Candidate has successfully cleared all registered courses across published examination sessions. There are no outstanding backlogs or failed subjects recorded against registration number <span className="font-mono font-semibold text-[#334155]">{student.registrationNumber}</span>.
            </p>
          </div>

          <div className="pt-3 flex justify-center">
            <div className="inline-flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-4 py-2 rounded-lg border border-emerald-200">
              <ShieldCheck className="w-4 h-4" />
              <span>Full Academic Standing Maintained</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-800">
              <p className="font-semibold">Active Arrear Notice</p>
              <p className="mt-0.5 text-amber-700">
                The following course(s) require re-examination or clearance registration in subsequent academic offerings or supplementary examination series.
              </p>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs text-[#1e293b]">
              <thead className="bg-[#f8fafc] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                <tr>
                  <th className="px-5 py-3">Course Code</th>
                  <th className="px-5 py-3">Course Name</th>
                  <th className="px-5 py-3">Session & Exam</th>
                  <th className="px-5 py-3 text-right">Marks Scored</th>
                  <th className="px-5 py-3 text-center">Grade</th>
                  <th className="px-5 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#e2e8f0]">
                {arrearCourses.map((arr, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5 font-mono font-bold text-rose-700">
                      {arr.courseCode}
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-[#1e293b]">
                      {arr.courseName}
                    </td>
                    <td className="px-5 py-3.5 text-[#475569]">
                      <span className="block font-medium">{arr.examinationName}</span>
                      <span className="text-[10px] text-[#64748b]">{arr.academicSession}</span>
                    </td>
                    <td className="px-5 py-3.5 text-right font-medium text-[#1e293b]">
                      {arr.marksObtained !== null ? `${arr.marksObtained} / ${arr.maxMarks}` : '—'}
                    </td>
                    <td className="px-5 py-3.5 text-center font-bold text-rose-600">
                      {arr.grade || 'F'}
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <Badge variant="rose" size="sm">
                        {arr.statusReason}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
