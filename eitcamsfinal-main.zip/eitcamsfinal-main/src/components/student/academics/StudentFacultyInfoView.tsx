import React, { useState, useEffect } from 'react';
import {
  Users,
  Mail,
  GraduationCap,
  Building,
  BookOpen,
  Search,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { FacultyAssignment } from '../../../types/academic';
import { Employee } from '../../../types/employee';
import { employeeRepository } from '../../../services/employeeService';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { AuthRole } from '../../../types/database';
import { Badge } from '../../ui/Badge';

interface StudentFacultyInfoViewProps {
  student: Student;
  facultyAssignments: FacultyAssignment[];
}

interface ResolvedFacultyItem {
  id: string;
  name: string;
  email?: string;
  department: string;
  designation: string;
  courseTaught: string;
  courseCode?: string;
  sectionOrBatch: string;
  slot?: string;
}

export function StudentFacultyInfoView({
  student,
  facultyAssignments,
}: StudentFacultyInfoViewProps) {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [resolvedFaculty, setResolvedFaculty] = useState<ResolvedFacultyItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';
  const studentSem = student.currentSemester || '';
  const studentRegNo = student.registrationNumber || '';

  useEffect(() => {
    let isMounted = true;
    async function loadFacultyData() {
      setIsLoading(true);
      try {
        const [empList, enrolments, offerings] = await Promise.all([
          employeeRepository.getAll(),
          studentRegNo
            ? devDataAdapter.academic.getEnrolments(
                { student_id: studentRegNo },
                { role: AuthRole.STUDENT, userId: studentRegNo }
              )
            : Promise.resolve([]),
          devDataAdapter.academic.getCourseOfferings(),
        ]);

        if (!isMounted) return;
        setEmployees(empList);

        const facultyMap = new Map<string, ResolvedFacultyItem>();

        // 1. Gather from facultyAssignments matching student's academic context
        const normProg = studentProg.toLowerCase().trim();
        const normBatch = studentBatch.toLowerCase().trim();

        facultyAssignments.forEach((fa) => {
          const faClassName = fa.className || '';
          const faClassId = fa.classId || '';
          const faSectionName = fa.sectionName || '';
          const matchProg =
            !normProg ||
            faClassName.toLowerCase().includes(normProg) ||
            normProg.includes(faClassName.toLowerCase()) ||
            faClassId.toLowerCase() === normProg;

          const matchBatch =
            !normBatch ||
            faSectionName === 'All' ||
            faSectionName.toLowerCase() === normBatch ||
            faSectionName.toLowerCase().includes(normBatch) ||
            normBatch.includes(faSectionName.toLowerCase());

          if (matchProg && matchBatch) {
            const matchedEmp = empList.find(
              (e) =>
                (fa.employeeId && e.id.toLowerCase() === fa.employeeId.toLowerCase()) ||
                e.fullName.toLowerCase() === fa.facultyName.toLowerCase()
            );

            const key = `${fa.facultyName}-${fa.subjectCode || fa.subjectName}`;
            facultyMap.set(key, {
              id: fa.employeeId || matchedEmp?.id || 'FAC',
              name: fa.facultyName,
              email: fa.facultyEmail || matchedEmp?.email,
              department: fa.department || matchedEmp?.department || 'Academic Affairs',
              designation: matchedEmp?.designation || 'Faculty Member',
              courseTaught: fa.subjectName,
              courseCode: fa.subjectCode,
              sectionOrBatch: (fa.sectionName === 'All' ? studentBatch || 'All Sections' : fa.sectionName) || 'All Sections',
            });
          }
        });

        // 2. Gather from student's active Academic Office course enrolments
        enrolments
          .filter((enr) => enr.enrolment_status === 'ACTIVE')
          .forEach((enr) => {
            const matchedOffering = offerings.find(
              (o) =>
                o.course_code === enr.course_code &&
                (!enr.section || o.section === enr.section)
            );
            const facultyId = matchedOffering?.assigned_faculty_id;
            const facultyName = matchedOffering?.assigned_faculty_name;
            const matchedEmp = empList.find(
              (e) => (facultyId && e.id === facultyId) || (facultyName && e.fullName === facultyName)
            );

            if (facultyName || matchedEmp) {
              const key = `${facultyName || matchedEmp?.fullName}-${enr.course_code}`;
              if (!facultyMap.has(key)) {
                facultyMap.set(key, {
                  id: facultyId || matchedEmp?.id || 'FAC',
                  name: facultyName || matchedEmp?.fullName || 'Course Faculty',
                  email: matchedEmp?.email,
                  department: matchedEmp?.department || studentProg || 'Engineering & Technology',
                  designation: matchedEmp?.designation || 'Course Instructor',
                  courseTaught: enr.course_title,
                  courseCode: enr.course_code,
                  sectionOrBatch: enr.section || studentBatch || 'Enrolled Section',
                });
              }
            }
          });

        setResolvedFaculty(Array.from(facultyMap.values()));
      } catch (err) {
        console.error('Failed to resolve faculty information', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadFacultyData();
    return () => {
      isMounted = false;
    };
  }, [studentRegNo, studentProg, studentBatch, facultyAssignments]);

  const filteredFaculty = resolvedFaculty.filter((f) => {
    const q = searchTerm.toLowerCase().trim();
    if (!q) return true;
    return (
      f.name.toLowerCase().includes(q) ||
      f.courseTaught.toLowerCase().includes(q) ||
      (f.courseCode && f.courseCode.toLowerCase().includes(q)) ||
      f.department.toLowerCase().includes(q) ||
      f.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Users className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Faculty Information</h1>
                <Badge variant="blue" size="sm">
                  Academic Context
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Program: <strong>{studentProg || 'Enrolled Program'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Batch: <strong>{studentBatch || 'N/A'}</strong>
                </span>
                {studentSem && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{studentSem}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{resolvedFaculty.length} Instructors Assigned</span>
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by faculty, course, or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
          />
        </div>
        <span className="text-xs text-[#64748b] font-medium">
          Showing {filteredFaculty.length} of {resolvedFaculty.length}
        </span>
      </div>

      {/* Faculty Cards Grid */}
      {isLoading ? (
        <div className="p-12 text-center text-xs text-[#64748b] bg-white rounded-xl border border-[#e2e8f0]">
          Loading faculty details for your enrolled courses...
        </div>
      ) : filteredFaculty.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-dashed border-[#cbd5e1] shadow-xs space-y-2">
          <Users className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-sm font-bold text-[#1e293b]">No Faculty Records Found</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto">
            {searchTerm
              ? 'No faculty matched your search criteria.'
              : `No faculty assignments have been recorded yet for ${studentProg} (Batch ${studentBatch}). Once courses and slots are officially published by Academic Affairs, faculty contact profiles will appear here.`}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredFaculty.map((faculty, idx) => (
            <div
              key={`${faculty.id}-${idx}`}
              className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#bfdbfe] transition-all space-y-4 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-slate-100 text-[#1e3a8a] flex items-center justify-center font-bold text-sm shrink-0 border border-slate-200">
                      {faculty.name
                        .split(' ')
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join('')}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-bold text-[#1e293b]">{faculty.name}</h3>
                        <Badge variant="neutral" size="sm" className="font-mono text-[10px]">
                          {faculty.id}
                        </Badge>
                      </div>
                      <p className="text-xs text-[#64748b] mt-0.5">{faculty.designation}</p>
                    </div>
                  </div>
                  <Badge variant="blue" size="sm" className="shrink-0 text-[10px]">
                    {faculty.department}
                  </Badge>
                </div>

                <div className="mt-4 pt-3 border-t border-[#f1f5f9] space-y-2 text-xs">
                  <div className="flex items-center justify-between text-[#475569]">
                    <span className="text-[#64748b] flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-[#94a3b8]" />
                      Course:
                    </span>
                    <span className="font-semibold text-[#1e293b] text-right">
                      {faculty.courseCode ? `${faculty.courseCode} — ` : ''}
                      {faculty.courseTaught}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[#475569]">
                    <span className="text-[#64748b] flex items-center gap-1.5">
                      <GraduationCap className="w-3.5 h-3.5 text-[#94a3b8]" />
                      Section / Slot:
                    </span>
                    <span className="font-medium text-[#1e293b]">
                      {faculty.slot ? `Slot ${faculty.slot} (${faculty.sectionOrBatch})` : faculty.sectionOrBatch}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact Footer */}
              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs">
                {faculty.email ? (
                  <a
                    href={`mailto:${faculty.email}`}
                    className="inline-flex items-center gap-1.5 text-[#1e3a8a] font-medium hover:underline text-xs"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{faculty.email}</span>
                  </a>
                ) : (
                  <span className="text-[#94a3b8] italic text-[11px] flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5" /> Official email on file
                  </span>
                )}
                <span className="text-[10px] text-[#94a3b8] font-mono">Assigned</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
