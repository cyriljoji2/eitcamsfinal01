import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BookOpen,
  GraduationCap,
  Layers,
  Search,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Filter,
  Check,
  X,
  Clock,
  Circle,
  Download,
  Printer,
  Award,
  ChevronRight,
  Info,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicClass, AcademicSubject, AcademicCurriculumEntry } from '../../../types/academic';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { AuthRole, CourseEnrolmentRecord } from '../../../types/database';
import { Examination, StudentExamResult, StudentSubjectMark } from '../../../types/examination';
import { academicRepository } from '../../../services/academicService';
import { examinationRepository } from '../../../services/examinationService';
import { Badge } from '../../ui/Badge';

export type CourseResultStatus = 'PASS' | 'FAIL' | 'PENDING';

export interface StudentCurriculumViewProps {
  student: Student;
  classes: AcademicClass[];
  subjects: AcademicSubject[];
  results?: StudentExamResult[];
  examinations?: Examination[];
  marks?: StudentSubjectMark[];
}

export interface StudentCurriculumItem {
  id: string;
  code: string;
  name: string;
  credits: number;
  type: string;
  category: string;
  basket: string;
  isRegistered: boolean;
  slot?: string;
  description?: string;
  // Authoritative Examination Results
  resultStatus: CourseResultStatus;
  resultLabel: string;
  grade?: string;
  marksObtained?: number | null;
  maxMarks?: number;
  examName?: string;
  publishedAt?: string;
}

/**
 * Normalizes course codes for robust, space/hyphen-agnostic matching
 */
function normalizeCourseCode(code: string): string {
  return (code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

/**
 * Normalizes student registration numbers
 */
function normalizeRegNo(reg: string): string {
  return (reg || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Generates and triggers high-fidelity printable Curriculum PDF
 */
function printCurriculumPDF(
  student: Student,
  items: StudentCurriculumItem[],
  totalCredits: number,
  passedCredits: number,
  studentProg: string,
  studentBatch: string
) {
  // Group by category and basket for the printable document
  const categories = Array.from(new Set(items.map((i) => i.category || 'General')));
  
  let tablesHtml = '';
  for (const cat of categories) {
    const catItems = items.filter((i) => (i.category || 'General') === cat);
    const catTotalCredits = catItems.reduce((acc, c) => acc + c.credits, 0);
    const catPassedCredits = catItems
      .filter((c) => c.resultStatus === 'PASS')
      .reduce((acc, c) => acc + c.credits, 0);

    tablesHtml += `
      <div class="category-block">
        <div class="cat-header">
          <span class="cat-title">${cat}</span>
          <span class="cat-credits">Earned: ${catPassedCredits} / ${catTotalCredits} Credits</span>
        </div>
    `;

    // Group by basket
    const baskets = Array.from(new Set(catItems.map((i) => i.basket || 'General')));
    for (const b of baskets) {
      const basketItems = catItems.filter((i) => (i.basket || 'General') === b);
      const bTotalCredits = basketItems.reduce((acc, c) => acc + c.credits, 0);
      const bPassedCredits = basketItems
        .filter((c) => c.resultStatus === 'PASS')
        .reduce((acc, c) => acc + c.credits, 0);

      tablesHtml += `
        <div class="basket-header">
          <span>Basket: ${b}</span>
          <span style="font-weight: normal; font-size: 10px; color: #64748b;">${bPassedCredits} / ${bTotalCredits} Credits Completed</span>
        </div>
        <table>
          <thead>
            <tr>
              <th style="width: 45px; text-align: center;">Sl. No.</th>
              <th style="width: 110px;">Course Code</th>
              <th>Course Title</th>
              <th style="width: 90px;">Course Type</th>
              <th style="width: 60px; text-align: center;">Credits</th>
              <th style="width: 120px; text-align: center;">Status</th>
            </tr>
          </thead>
          <tbody>
      `;

      basketItems.forEach((item, idx) => {
        let rowClass = 'row-pending';
        let statusHtml = '<span class="status-pending">○ Result Awaited</span>';
        if (item.resultStatus === 'PASS') {
          rowClass = 'row-pass';
          statusHtml = `<span class="status-pass">✓ Passed ${item.grade ? `(${item.grade})` : ''}</span>`;
        } else if (item.resultStatus === 'FAIL') {
          rowClass = 'row-fail';
          statusHtml = `<span class="status-fail">✕ Failed ${item.grade ? `(${item.grade})` : ''}</span>`;
        } else if (!item.isRegistered) {
          statusHtml = '<span class="status-pending">○ Not Attempted</span>';
        }

        tablesHtml += `
          <tr class="${rowClass}">
            <td style="text-align: center; font-weight: bold; color: #64748b;">${idx + 1}</td>
            <td style="font-family: monospace; font-weight: bold;">${item.code}</td>
            <td><strong>${item.name}</strong></td>
            <td>${item.type}</td>
            <td style="text-align: center; font-weight: bold;">${item.credits}</td>
            <td style="text-align: center;">${statusHtml}</td>
          </tr>
        `;
      });

      tablesHtml += `
          </tbody>
        </table>
      `;
    }

    tablesHtml += `</div>`;
  }

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>Curriculum_${student.registrationNumber || 'Student'}</title>
        <style>
          @page { size: A4 portrait; margin: 12mm 15mm; }
          @media print {
            body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
            .no-print { display: none !important; }
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            margin: 0;
            padding: 10px;
            color: #0f172a;
            font-size: 11px;
            line-height: 1.4;
          }
          .header-box {
            border-bottom: 2px solid #1e3a8a;
            padding-bottom: 10px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
          }
          .inst-name { font-size: 18px; font-weight: 800; color: #1e3a8a; margin: 0; text-transform: uppercase; }
          .doc-title { font-size: 12px; font-weight: 700; color: #475569; margin-top: 2px; }
          .info-grid {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 10px 14px;
            margin-bottom: 14px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
          }
          .info-item { display: flex; flex-direction: column; }
          .info-label { font-size: 9px; font-weight: 700; text-transform: uppercase; color: #64748b; margin-bottom: 2px; }
          .info-val { font-size: 11.5px; font-weight: 700; color: #1e293b; }
          .stats-bar {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 6px;
            padding: 8px 12px;
            margin-bottom: 14px;
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            font-weight: 700;
            color: #1e3a8a;
          }
          .category-block { margin-bottom: 16px; page-break-inside: avoid; }
          .cat-header {
            background: #f1f5f9;
            border: 1px solid #cbd5e1;
            padding: 6px 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 800;
            font-size: 12px;
            color: #1e293b;
            border-radius: 4px 4px 0 0;
          }
          .basket-header {
            padding: 4px 8px;
            font-size: 10.5px;
            font-weight: 700;
            color: #475569;
            background: #f8fafc;
            border-left: 1px solid #cbd5e1;
            border-right: 1px solid #cbd5e1;
            display: flex;
            justify-content: space-between;
          }
          table { width: 100%; border-collapse: collapse; margin-bottom: 8px; font-size: 10px; }
          th {
            background: #f8fafc;
            color: #475569;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 9px;
            padding: 5px 8px;
            border: 1px solid #cbd5e1;
            text-align: left;
          }
          td { padding: 5px 8px; border: 1px solid #e2e8f0; vertical-align: middle; }
          tr.row-pass { background-color: #ecfdf5 !important; border-left: 3px solid #10b981; }
          tr.row-fail { background-color: #fff1f2 !important; border-left: 3px solid #f43f5e; }
          tr.row-pending { background-color: #ffffff !important; }
          .status-pass { color: #047857; font-weight: 800; }
          .status-fail { color: #b91c1c; font-weight: 800; }
          .status-pending { color: #64748b; font-weight: 500; }
          .footer {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #e2e8f0;
            font-size: 9px;
            color: #94a3b8;
            display: flex;
            justify-content: space-between;
          }
        </style>
      </head>
      <body>
        <div class="header-box">
          <div>
            <h1 class="inst-name">Eastern Institute of Technology</h1>
            <div class="doc-title">Office of Academic Affairs • Student Curriculum & Grade Report</div>
          </div>
          <div style="text-align: right; font-size: 10px; color: #64748b;">
            <div>Printed: ${new Date().toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
            <div style="font-weight: bold; color: #1e3a8a;">Official Curriculum Copy</div>
          </div>
        </div>

        <div class="info-grid">
          <div class="info-item">
            <span class="info-label">Student Name</span>
            <span class="info-val">${student.fullName || 'Student'}</span>
          </div>
          <div class="info-item">
            <span class="info-label">Registration No.</span>
            <span class="info-val" style="font-family: monospace;">${student.registrationNumber || '-'}</span>
          </div>
          <div class="info-item">
            <span class="info-label">Degree Program</span>
            <span class="info-val">${studentProg || 'Program Curriculum'}</span>
          </div>
          <div class="info-item">
            <span class="info-label">Admission Batch</span>
            <span class="info-val">${studentBatch || 'All Batches'}</span>
          </div>
        </div>

        <div class="stats-bar">
          <div>Total Curriculum Credits: ${totalCredits}</div>
          <div>Total Earned (Passed) Credits: <span style="color: #047857; font-size: 12px;">${passedCredits} Credits</span></div>
          <div>Completion: ${totalCredits > 0 ? Math.round((passedCredits / totalCredits) * 100) : 0}%</div>
        </div>

        ${tablesHtml}

        <div class="footer">
          <div>EIT Academic Management System — Generated for ${student.fullName} (${student.registrationNumber})</div>
          <div>Controller of Examinations • Verified Academic Record</div>
        </div>
      </body>
    </html>
  `;

  const printWindow = window.open('', '_blank', 'width=1100,height=850');
  if (!printWindow) {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(html);
      doc.close();
      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => document.body.removeChild(iframe), 2000);
      }, 500);
    }
    return;
  }

  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => {
    printWindow.print();
  }, 500);
}

export function StudentCurriculumView({
  student,
  classes,
  subjects,
  results: propResults,
  examinations: propExams,
  marks: propMarks,
}: StudentCurriculumViewProps) {
  const [curriculumEntries, setCurriculumEntries] = useState<AcademicCurriculumEntry[]>([]);
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [examResults, setExamResults] = useState<StudentExamResult[]>(propResults || []);
  const [examinations, setExaminations] = useState<Examination[]>(propExams || []);
  const [subjectMarks, setSubjectMarks] = useState<StudentSubjectMark[]>(propMarks || []);
  const [isLoading, setIsLoading] = useState(true);

  // Filters & State
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedBasket, setSelectedBasket] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';
  const studentRegNo = student.registrationNumber || '';
  const studentRegClean = normalizeRegNo(studentRegNo);

  // Update internal exam state when props change
  useEffect(() => {
    if (propResults) setExamResults(propResults);
  }, [propResults]);

  useEffect(() => {
    if (propExams) setExaminations(propExams);
  }, [propExams]);

  useEffect(() => {
    if (propMarks) setSubjectMarks(propMarks);
  }, [propMarks]);

  // Load all authoritative academic and examination data
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      setIsLoading(true);
      try {
        const [enrList, currEntries, allExams, allRes, allMks] = await Promise.all([
          studentRegNo
            ? devDataAdapter.academic.getEnrolments(
                { student_id: studentRegNo },
                { role: AuthRole.STUDENT, userId: studentRegNo }
              )
            : Promise.resolve([]),
          academicRepository.getCurriculumByProgramAndBatch(studentProg, studentBatch),
          examinationRepository.getExaminations(),
          examinationRepository.getResults(),
          examinationRepository.getAllMarks(),
        ]);

        if (!isMounted) return;

        setEnrolments(enrList);
        setExaminations(allExams);
        setExamResults(allRes);
        setSubjectMarks(allMks);

        if (currEntries && currEntries.length > 0) {
          setCurriculumEntries(currEntries);
        } else {
          // If no specific match, try finding by program only (strictly for this student's program)
          const allCurr = await academicRepository.getAllCurriculum();
          const normProg = studentProg.toLowerCase().trim();
          const cleanProg = normProg.replace(/[^a-z0-9]/g, '');
          const progMatched = allCurr.filter((c: any) => {
            const p = (c.program || '').toLowerCase().replace(/[^a-z0-9]/g, '');
            return (
              p === cleanProg ||
              (p.length >= 4 && cleanProg.length >= 4 && (p.includes(cleanProg) || cleanProg.includes(p)))
            );
          });
          if (isMounted) {
            setCurriculumEntries(progMatched);
          }
        }
      } catch (err) {
        console.error('Failed to load student curriculum & exam data:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [studentProg, studentBatch, studentRegNo]);

  // Build canonical curriculum items and reconcile with Examination Results and Enrolments
  const curriculumItems: StudentCurriculumItem[] = useMemo(() => {
    // 1. Map registered courses from Academic Office enrolments
    const registeredMap = new Map<string, { slot: string }>();
    enrolments
      .filter((e) => e.enrolment_status === 'ACTIVE')
      .forEach((e) => {
        registeredMap.set(normalizeCourseCode(e.course_code), { slot: e.section || 'A' });
      });

    // 2. Build set of Published Examination IDs
    const publishedExamIds = new Set<string>();
    examinations.forEach((exam) => {
      if (exam.status === 'Published') {
        publishedExamIds.add(exam.id.toLowerCase());
      }
    });

    // 3. Filter published results strictly for this student
    const studentResults = examResults.filter((res) => {
      const regClean = normalizeRegNo(res.studentRegistrationNumber);
      const isThisStudent = regClean === studentRegClean || res.studentRegistrationNumber === studentRegNo;
      if (!isThisStudent) return false;
      const isPublished = res.verificationStatus === 'Published' || publishedExamIds.has(res.examinationId.toLowerCase());
      return isPublished;
    });

    // 4. Also filter published/verified marks for this student
    const studentMarks = subjectMarks.filter((mk) => {
      const regClean = normalizeRegNo(mk.studentRegistrationNumber);
      const isThisStudent = regClean === studentRegClean || mk.studentRegistrationNumber === studentRegNo;
      if (!isThisStudent) return false;
      const isPublished = publishedExamIds.has(mk.examinationId.toLowerCase()) || (mk as any).verificationStatus === 'Verified';
      return isPublished;
    });

    // 5. Helper function to compute authoritative result for a given course code
    const resolveCourseStatus = (
      courseCode: string
    ): {
      resultStatus: CourseResultStatus;
      resultLabel: string;
      grade?: string;
      marksObtained?: number | null;
      maxMarks?: number;
      examName?: string;
      publishedAt?: string;
    } => {
      const targetCodeNorm = normalizeCourseCode(courseCode);

      // Collect all matched marks across published results and verified marks
      interface AttemptRecord {
        isPassed: boolean;
        grade?: string;
        marksObtained?: number | null;
        maxMarks?: number;
        examName: string;
        date: string;
      }
      const attempts: AttemptRecord[] = [];

      // Check in StudentExamResult records
      for (const res of studentResults) {
        for (const sm of res.subjectMarks || []) {
          const smCodeNorm = normalizeCourseCode(sm.subjectCode);
          const isMatch =
            smCodeNorm === targetCodeNorm ||
            (smCodeNorm.length >= 4 && targetCodeNorm.length >= 4 && (smCodeNorm.includes(targetCodeNorm) || targetCodeNorm.includes(smCodeNorm)));

          if (isMatch) {
            attempts.push({
              isPassed: sm.isPassed,
              grade: sm.grade,
              marksObtained: sm.marksObtained,
              maxMarks: sm.maxMarks,
              examName: res.examinationName || 'Semester Examination',
              date: res.publishedAt || res.calculatedAt || '',
            });
          }
        }
      }

      // Check in StudentSubjectMark records
      for (const mk of studentMarks) {
        const mkCodeNorm = normalizeCourseCode(mk.subjectCode);
        const isMatch =
          mkCodeNorm === targetCodeNorm ||
          (mkCodeNorm.length >= 4 && targetCodeNorm.length >= 4 && (mkCodeNorm.includes(targetCodeNorm) || targetCodeNorm.includes(mkCodeNorm)));

        if (isMatch) {
          attempts.push({
            isPassed: Boolean(mk.isPassed),
            grade: mk.grade,
            marksObtained: mk.marksObtained,
            maxMarks: mk.maxMarks,
            examName: mk.examinationId,
            date: mk.updatedAt || mk.enteredAt || '',
          });
        }
      }

      // If no published examination records exist:
      if (attempts.length === 0) {
        const isReg = registeredMap.has(targetCodeNorm);
        return {
          resultStatus: 'PENDING',
          resultLabel: isReg ? 'Result Awaited' : 'Not Attempted',
        };
      }

      // Sort attempts by timestamp descending to inspect latest attempt
      attempts.sort((a, b) => (b.date || '').localeCompare(a.date || ''));

      // If student has passed in ANY authoritative published record or the latest attempt:
      // (In university academics, clearing a course via re-exam / supplementary / revaluation marks it PASSED)
      const passedAttempt = attempts.find((att) => att.isPassed === true || (att.grade && !['F', 'RA', 'AB', 'FAIL'].includes(att.grade.toUpperCase())));

      if (passedAttempt) {
        return {
          resultStatus: 'PASS',
          resultLabel: 'Passed',
          grade: passedAttempt.grade || 'Pass',
          marksObtained: passedAttempt.marksObtained,
          maxMarks: passedAttempt.maxMarks,
          examName: passedAttempt.examName,
          publishedAt: passedAttempt.date,
        };
      }

      // Otherwise, the student failed and has not cleared it yet
      const latestFail = attempts[0];
      return {
        resultStatus: 'FAIL',
        resultLabel: 'Failed',
        grade: latestFail.grade || 'F',
        marksObtained: latestFail.marksObtained,
        maxMarks: latestFail.maxMarks,
        examName: latestFail.examName,
        publishedAt: latestFail.date,
      };
    };

    // Build items from curriculum entries
    if (curriculumEntries.length > 0) {
      return curriculumEntries.map((curr) => {
        const codeNorm = normalizeCourseCode(curr.courseCode);
        const regInfo = registeredMap.get(codeNorm);
        const result = resolveCourseStatus(curr.courseCode);

        return {
          id: curr.id,
          code: curr.courseCode,
          name: curr.courseName || curr.courseTitle || '',
          credits: Number(curr.credits) || 3,
          type: curr.type || 'Core',
          category: curr.category || 'PC',
          basket: curr.basket || (curr.category === 'PC' ? 'Program Core' : 'Program Elective'),
          isRegistered: Boolean(regInfo),
          slot: regInfo?.slot,
          description: undefined,
          ...result,
        };
      });
    }

    // Fallback: Build from subjects matching student's program
    const normProg = studentProg.toLowerCase().trim();
    const matchedSubjects = subjects.filter((s) => {
      if (!normProg) return true;
      const sClassName = s.className || '';
      const sClassId = s.classId || '';
      return (
        sClassName.toLowerCase().includes(normProg) ||
        normProg.includes(sClassName.toLowerCase()) ||
        sClassId.toLowerCase() === normProg
      );
    });

    const pool = matchedSubjects.length > 0 ? matchedSubjects : subjects;
    return pool.map((s) => {
      const codeNorm = normalizeCourseCode(s.code);
      const regInfo = registeredMap.get(codeNorm);
      const isCore = s.type === 'Core';
      const result = resolveCourseStatus(s.code);

      return {
        id: s.id,
        code: s.code,
        name: s.name,
        credits: s.credits || s.creditsOrPeriodsPerWeek || 3,
        type: s.type || 'Core',
        category: isCore ? 'PC' : 'PE',
        basket: isCore ? 'Program Core' : 'Program Elective',
        isRegistered: Boolean(regInfo),
        slot: regInfo?.slot,
        description: s.description,
        ...result,
      };
    });
  }, [curriculumEntries, subjects, studentProg, enrolments, examResults, examinations, subjectMarks, studentRegClean, studentRegNo]);

  // Unique Categories and Baskets
  const availableCategories = useMemo(() => {
    const set = new Set<string>();
    curriculumItems.forEach((c) => {
      if (c.category) set.add(c.category);
    });
    return Array.from(set);
  }, [curriculumItems]);

  const availableBaskets = useMemo(() => {
    const set = new Set<string>();
    curriculumItems.forEach((c) => {
      if (selectedCategory === 'all' || c.category === selectedCategory) {
        if (c.basket) set.add(c.basket);
      }
    });
    return Array.from(set);
  }, [curriculumItems, selectedCategory]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return curriculumItems.filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      if (selectedBasket !== 'all' && item.basket !== selectedBasket) {
        return false;
      }
      if (selectedStatus !== 'all' && item.resultStatus !== selectedStatus) {
        return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase().trim();
        return (
          item.code.toLowerCase().includes(q) ||
          item.name.toLowerCase().includes(q) ||
          item.type.toLowerCase().includes(q) ||
          item.category.toLowerCase().includes(q) ||
          item.basket.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [curriculumItems, selectedCategory, selectedBasket, selectedStatus, searchTerm]);

  // Credit Summaries
  const totalCredits = curriculumItems.reduce((acc, curr) => acc + curr.credits, 0);
  const passedCredits = curriculumItems
    .filter((c) => c.resultStatus === 'PASS')
    .reduce((acc, curr) => acc + curr.credits, 0);
  const registeredCredits = curriculumItems
    .filter((c) => c.isRegistered)
    .reduce((acc, curr) => acc + curr.credits, 0);

  // Status counts
  const passedCount = curriculumItems.filter((c) => c.resultStatus === 'PASS').length;
  const failedCount = curriculumItems.filter((c) => c.resultStatus === 'FAIL').length;
  const pendingCount = curriculumItems.filter((c) => c.resultStatus === 'PENDING').length;

  // Category specific calculations
  const categoryStats = useMemo(() => {
    const map = new Map<string, { total: number; passed: number; count: number }>();
    curriculumItems.forEach((item) => {
      const cat = item.category || 'Other';
      const curr = map.get(cat) || { total: 0, passed: 0, count: 0 };
      curr.total += item.credits;
      if (item.resultStatus === 'PASS') {
        curr.passed += item.credits;
      }
      curr.count += 1;
      map.set(cat, curr);
    });
    return map;
  }, [curriculumItems]);

  // Group items by Category, and then by Basket
  const groupedSections = useMemo(() => {
    const cats = selectedCategory === 'all' ? availableCategories : [selectedCategory];
    
    return cats.map((cat) => {
      const catItems = filteredItems.filter((i) => i.category === cat);
      const catBaskets = Array.from(new Set(catItems.map((i) => i.basket || 'General')));

      const basketGroups = catBaskets.map((bName) => {
        const bItems = catItems.filter((i) => (i.basket || 'General') === bName);
        const bTotal = bItems.reduce((acc, i) => acc + i.credits, 0);
        const bPassed = bItems
          .filter((i) => i.resultStatus === 'PASS')
          .reduce((acc, i) => acc + i.credits, 0);

        return {
          basketName: bName,
          items: bItems,
          totalCredits: bTotal,
          passedCredits: bPassed,
        };
      });

      const catTotal = catItems.reduce((acc, i) => acc + i.credits, 0);
      const catPassed = catItems
        .filter((i) => i.resultStatus === 'PASS')
        .reduce((acc, i) => acc + i.credits, 0);

      return {
        categoryName: cat,
        basketGroups,
        totalCredits: catTotal,
        passedCredits: catPassed,
        itemCount: catItems.length,
      };
    }).filter((g) => g.itemCount > 0);
  }, [filteredItems, selectedCategory, availableCategories]);

  return (
    <div className="space-y-6">
      {/* Header Banner with Program Details, Progress and PDF Export */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <BookOpen className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">My Curriculum & Course Requirements</h1>
                <Badge variant="blue" size="sm">
                  Official Syllabus
                </Badge>
                <Badge variant="neutral" size="sm">
                  VIT-Style Credit Audit
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1.5 flex items-center gap-2 flex-wrap">
                <span>
                  Degree Program: <strong className="text-[#1e293b]">{studentProg || 'Program Curriculum'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Admission Batch: <strong className="text-[#1e293b]">{studentBatch || 'All Batches'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Student: <strong className="text-[#1e293b]">{student.fullName}</strong> ({student.registrationNumber})
                </span>
              </p>
            </div>
          </div>

          {/* Action & Metric Cluster */}
          <div className="flex items-center gap-3 flex-wrap w-full lg:w-auto justify-start lg:justify-end">
            <button
              onClick={() =>
                printCurriculumPDF(
                  student,
                  curriculumItems,
                  totalCredits,
                  passedCredits,
                  studentProg,
                  studentBatch
                )
              }
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#1e3a8a] text-white hover:bg-blue-900 transition-colors shadow-2xs cursor-pointer"
              title="Download official curriculum copy as PDF"
            >
              <Download className="w-3.5 h-3.5" />
              Download Curriculum (PDF)
            </button>

            <div className="flex items-center gap-3 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs">
              <div>
                <span className="text-[10px] text-[#64748b] uppercase block font-semibold">
                  Earned Credits
                </span>
                <span className="font-extrabold text-emerald-700 text-sm">
                  {passedCredits} / {totalCredits} Cr
                </span>
              </div>
              <div className="h-6 w-px bg-[#cbd5e1]" />
              <div>
                <span className="text-[10px] text-[#64748b] uppercase block font-semibold">
                  Completion
                </span>
                <span className="font-bold text-[#1e3a8a] text-sm">
                  {totalCredits > 0 ? Math.round((passedCredits / totalCredits) * 100) : 0}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Status Indicator Bar */}
        <div className="mt-5 pt-4 border-t border-[#f1f5f9] flex items-center justify-between gap-4 flex-wrap text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-semibold text-[#475569]">Course Status Legend:</span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
              <Check className="w-3 h-3 text-emerald-600 stroke-[3]" />
              Passed ({passedCount})
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold bg-rose-50 text-rose-800 border border-rose-300">
              <X className="w-3 h-3 text-rose-600 stroke-[3]" />
              Failed ({failedCount})
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
              <Circle className="w-2.5 h-2.5 text-slate-400" />
              Pending / Result Awaited ({pendingCount})
            </span>
          </div>

          <div className="text-[11px] text-[#64748b]">
            Authoritative results synchronized with <strong>Controller of Examination (COE)</strong>
          </div>
        </div>
      </div>

      {/* Credit Category Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {['PC', 'PE', 'UC', 'OE'].map((catKey) => {
          const catLabel =
            catKey === 'PC'
              ? 'Program Core'
              : catKey === 'PE'
              ? 'Program Elective'
              : catKey === 'UC'
              ? 'University Core'
              : 'Open Elective';

          const stats = categoryStats.get(catKey) || { total: 0, passed: 0, count: 0 };
          const isSelected = selectedCategory === catKey;

          return (
            <button
              key={catKey}
              onClick={() => setSelectedCategory(isSelected ? 'all' : catKey)}
              className={`text-left p-4 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-blue-50/70 border-[#1e3a8a] shadow-xs'
                  : 'bg-white border-[#e2e8f0] hover:border-[#cbd5e1] shadow-2xs'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#64748b] block">{catLabel} ({catKey})</span>
                <Badge
                  variant={
                    catKey === 'PC'
                      ? 'blue'
                      : catKey === 'PE'
                      ? 'slate'
                      : catKey === 'UC'
                      ? 'emerald'
                      : 'amber'
                  }
                  size="sm"
                >
                  {catKey}
                </Badge>
              </div>
              <div className="flex items-baseline justify-between mt-2">
                <span className="text-lg font-bold text-[#1e293b]">
                  {stats.passed} <span className="text-xs font-normal text-[#64748b]">/ {stats.total} Cr</span>
                </span>
                <span className="text-xs font-semibold text-emerald-700">
                  {stats.total > 0 ? Math.round((stats.passed / stats.total) * 100) : 0}%
                </span>
              </div>
              {/* Mini progress bar */}
              <div className="w-full bg-[#f1f5f9] rounded-full h-1.5 mt-2.5 overflow-hidden">
                <div
                  className="bg-[#1e3a8a] h-1.5 rounded-full transition-all duration-300"
                  style={{
                    width: `${stats.total > 0 ? Math.min(100, Math.round((stats.passed / stats.total) * 100)) : 0}%`,
                  }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {/* Category Tabs (VIT Layout Style) */}
      <div className="bg-white p-2 rounded-xl border border-[#e2e8f0] shadow-2xs flex items-center gap-1.5 overflow-x-auto">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-[#1e3a8a] text-white shadow-2xs'
              : 'text-[#475569] hover:bg-[#f1f5f9]'
          }`}
        >
          All Categories ({curriculumItems.length})
        </button>
        {availableCategories.map((cat) => {
          const stats = categoryStats.get(cat);
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#1e3a8a] text-white shadow-2xs'
                  : 'text-[#475569] hover:bg-[#f1f5f9]'
              }`}
            >
              {cat === 'PC'
                ? 'Program Core (PC)'
                : cat === 'PE'
                ? 'Program Elective (PE)'
                : cat === 'UC'
                ? 'University Core (UC)'
                : cat === 'OE'
                ? 'Open Elective (OE)'
                : cat}{' '}
              ({stats?.count || 0})
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by code, title, or basket..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Status Filter */}
          <div className="flex items-center gap-1 text-xs">
            <span className="text-[#64748b] font-medium">Status:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="py-1.5 px-2.5 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            >
              <option value="all">All Statuses ({curriculumItems.length})</option>
              <option value="PASS">Passed ({passedCount})</option>
              <option value="FAIL">Failed ({failedCount})</option>
              <option value="PENDING">Pending / Awaited ({pendingCount})</option>
            </select>
          </div>

          {/* Basket Filter */}
          {availableBaskets.length > 0 && (
            <div className="flex items-center gap-1 text-xs">
              <span className="text-[#64748b] font-medium">Basket:</span>
              <select
                value={selectedBasket}
                onChange={(e) => setSelectedBasket(e.target.value)}
                className="py-1.5 px-2.5 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
              >
                <option value="all">All Baskets ({availableBaskets.length})</option>
                {availableBaskets.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
          )}

          <span className="text-xs text-[#64748b] font-medium hidden sm:inline ml-1">
            Showing {filteredItems.length} courses
          </span>
        </div>
      </div>

      {/* Curriculum Tables Grouped by Category and Basket */}
      {isLoading ? (
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-12 text-center text-xs text-[#64748b]">
          Loading curriculum structure and official examination results...
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="bg-white rounded-xl border border-[#e2e8f0] p-12 text-center text-xs text-[#64748b] space-y-2">
          <FileSpreadsheet className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="font-bold text-[#1e293b]">No Curriculum Published</h3>
          <p className="max-w-md mx-auto">
            {searchTerm || selectedCategory !== 'all' || selectedStatus !== 'all'
              ? 'No courses match the current filters. Clear filters to view full curriculum.'
              : 'No curriculum published yet for your Program and Batch.'}
          </p>
          {(searchTerm || selectedCategory !== 'all' || selectedStatus !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedStatus('all');
                setSelectedBasket('all');
              }}
              className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {groupedSections.map((section) => (
            <div
              key={section.categoryName}
              className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden"
            >
              {/* Category Header Banner */}
              <div className="p-4 bg-linear-to-r from-slate-50 to-white border-b border-[#e2e8f0] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#1e3a8a] text-white flex items-center justify-center text-xs font-bold shrink-0">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-[#1e293b]">
                      {section.categoryName === 'PC'
                        ? 'Program Core (PC)'
                        : section.categoryName === 'PE'
                        ? 'Program Elective (PE)'
                        : section.categoryName === 'UC'
                        ? 'University Core (UC)'
                        : section.categoryName === 'OE'
                        ? 'Open Elective (OE)'
                        : section.categoryName}
                    </h2>
                    <span className="text-[11px] text-[#64748b]">
                      Category requirement • {section.itemCount} courses listed
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Badge variant="blue" size="sm">
                    Earned: {section.passedCredits} / {section.totalCredits} Credits
                  </Badge>
                </div>
              </div>

              {/* Basket Groups inside this Category */}
              <div className="divide-y divide-[#e2e8f0]">
                {section.basketGroups.map((basketGroup) => (
                  <div key={basketGroup.basketName} className="p-0">
                    {/* Basket Sub-header */}
                    <div className="bg-[#f8fafc] px-5 py-2.5 border-b border-[#e2e8f0] flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[#334155]">Basket:</span>
                        <span className="font-semibold text-[#1e3a8a]">{basketGroup.basketName}</span>
                      </div>
                      <div className="text-[11px] font-semibold text-[#64748b]">
                        Completed:{' '}
                        <strong className="text-emerald-700">
                          {basketGroup.passedCredits}
                        </strong>{' '}
                        / {basketGroup.totalCredits} Credits
                      </div>
                    </div>

                    {/* Academic Courses Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs text-[#1e293b]">
                        <thead className="bg-[#fcfdfe] text-[#475569] font-bold border-b border-[#e2e8f0] uppercase text-[10px]">
                          <tr>
                            <th className="px-5 py-2.5 w-14 text-center">Sl. No.</th>
                            <th className="px-5 py-2.5 w-32">Course Code</th>
                            <th className="px-5 py-2.5">Course Name</th>
                            <th className="px-5 py-2.5 w-32">Course Type</th>
                            <th className="px-5 py-2.5 w-24 text-center">Credits</th>
                            <th className="px-5 py-2.5 text-right w-44">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#f1f5f9]">
                          {basketGroup.items.map((item, idx) => {
                            // Row styling based on authoritative exam status
                            const isPass = item.resultStatus === 'PASS';
                            const isFail = item.resultStatus === 'FAIL';

                            const rowBg = isPass
                              ? 'bg-emerald-50/60 hover:bg-emerald-100/50 border-l-4 border-l-emerald-500'
                              : isFail
                              ? 'bg-rose-50/60 hover:bg-rose-100/50 border-l-4 border-l-rose-500'
                              : 'bg-white hover:bg-slate-50 border-l-4 border-l-transparent';

                            return (
                              <tr key={item.id} className={`${rowBg} transition-colors`}>
                                <td className="px-5 py-3 text-center font-semibold text-[#64748b]">
                                  {idx + 1}
                                </td>
                                <td className="px-5 py-3 font-bold font-mono text-[#1e3a8a]">
                                  {item.code}
                                </td>
                                <td className="px-5 py-3">
                                  <div className="font-semibold text-[#1e293b]">{item.name}</div>
                                  {item.description && (
                                    <div className="text-[11px] text-[#64748b] line-clamp-1 mt-0.5">
                                      {item.description}
                                    </div>
                                  )}
                                  {item.examName && (
                                    <div className="text-[10px] text-[#64748b] mt-0.5">
                                      Exam: {item.examName}
                                    </div>
                                  )}
                                </td>
                                <td className="px-5 py-3">
                                  <Badge variant="blue" size="sm">
                                    {item.type}
                                  </Badge>
                                </td>
                                <td className="px-5 py-3 text-center font-bold text-[#1e293b]">
                                  {item.credits} cr
                                </td>
                                <td className="px-5 py-3 text-right">
                                  {isPass ? (
                                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                                      <Check className="w-3.5 h-3.5 text-emerald-700 stroke-[2.5]" />
                                      Passed
                                      {item.grade && (
                                        <span className="ml-0.5 px-1.5 py-0.2 bg-emerald-200 text-emerald-900 rounded text-[10px] font-mono">
                                          {item.grade}
                                        </span>
                                      )}
                                    </span>
                                  ) : isFail ? (
                                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300 shadow-2xs">
                                      <X className="w-3.5 h-3.5 text-rose-700 stroke-[2.5]" />
                                      Failed
                                      {item.grade && (
                                        <span className="ml-0.5 px-1.5 py-0.2 bg-rose-200 text-rose-900 rounded text-[10px] font-mono">
                                          {item.grade}
                                        </span>
                                      )}
                                    </span>
                                  ) : item.isRegistered ? (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                                      <Clock className="w-3 h-3 text-amber-600" />
                                      Result Awaited {item.slot ? `(${item.slot})` : ''}
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-600 border border-slate-200">
                                      <Circle className="w-2.5 h-2.5 text-slate-400" />
                                      Not Attempted
                                    </span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot className="bg-[#f8fafc] border-t border-[#e2e8f0] text-[11px] font-bold text-[#475569]">
                          <tr>
                            <td colSpan={4} className="px-5 py-2">
                              Basket Subtotal ({basketGroup.items.length} Courses)
                            </td>
                            <td className="px-5 py-2 text-center text-[#1e293b]">
                              {basketGroup.totalCredits} cr
                            </td>
                            <td className="px-5 py-2 text-right text-emerald-700">
                              {basketGroup.passedCredits} / {basketGroup.totalCredits} cr Cleared
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
