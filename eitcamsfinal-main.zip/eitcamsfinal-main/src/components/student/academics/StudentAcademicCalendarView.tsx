import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  Clock,
  Award,
  BookOpen,
  CheckCircle2,
  CalendarDays,
  Info,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicSession } from '../../../types/academic';
import { Examination, ExamSubjectSchedule } from '../../../types/examination';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { SemesterRecord } from '../../../types/database';
import { Badge } from '../../ui/Badge';

interface StudentAcademicCalendarViewProps {
  student: Student;
  sessions: AcademicSession[];
  examinations: Examination[];
  schedules: ExamSubjectSchedule[];
}

interface CalendarMilestone {
  id: string;
  title: string;
  category: 'Session' | 'Semester' | 'Examination';
  startDate: string;
  endDate?: string;
  description: string;
  status: 'Active' | 'Upcoming' | 'Past';
}

export function StudentAcademicCalendarView({
  student,
  sessions,
  examinations,
  schedules,
}: StudentAcademicCalendarViewProps) {
  const [semesters, setSemesters] = useState<SemesterRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';

  useEffect(() => {
    let isMounted = true;
    async function loadAcademicCalendar() {
      setIsLoading(true);
      try {
        const semList = await devDataAdapter.academic.getSemesters();
        if (isMounted) setSemesters(semList);
      } catch (err) {
        console.error('Failed to load academic semesters for calendar', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadAcademicCalendar();
    return () => {
      isMounted = false;
    };
  }, []);

  // Aggregate authoritative milestones from Academic Office and COE
  const milestones: CalendarMilestone[] = useMemo(() => {
    const list: CalendarMilestone[] = [];
    const now = new Date();

    // 1. Ingest Institutional Academic Sessions
    sessions.forEach((sess) => {
      if (!sess.startDate || !sess.endDate) return;
      const start = new Date(sess.startDate);
      const end = new Date(sess.endDate);
      const isActive = sess.isCurrent || (now >= start && now <= end);
      const isPast = now > end;

      list.push({
        id: `sess-${sess.id}`,
        title: `Academic Session: ${sess.name}`,
        category: 'Session',
        startDate: sess.startDate,
        endDate: sess.endDate,
        description: `Official institutional academic term (${sess.isCurrent ? 'Current Session' : 'Scheduled'}) governed by Academic Affairs.`,
        status: isActive ? 'Active' : isPast ? 'Past' : 'Upcoming',
      });
    });

    // 2. Ingest Official Academic Semesters
    semesters.forEach((sem) => {
      if (!sem.start_date || !sem.end_date) return;
      const start = new Date(sem.start_date);
      const end = new Date(sem.end_date);
      const isActive = sem.is_current || (now >= start && now <= end);
      const isPast = now > end;

      list.push({
        id: `sem-${sem.semester_id}`,
        title: `${sem.name} (${sem.academic_year})`,
        category: 'Semester',
        startDate: sem.start_date,
        endDate: sem.end_date,
        description: `Academic instructional term (Term ${sem.term}, Semester ${sem.semester_number}) for cohort studies, lectures, and laboratory sessions.`,
        status: isActive ? 'Active' : isPast ? 'Past' : 'Upcoming',
      });
    });

    // 3. Ingest University Examinations
    examinations.forEach((exam) => {
      if (!exam.startDate || !exam.endDate) return;
      const start = new Date(exam.startDate);
      const end = new Date(exam.endDate);
      const isActive = now >= start && now <= end && exam.status === 'Published';
      const isPast = now > end;

      list.push({
        id: `exam-${exam.id}`,
        title: exam.name,
        category: 'Examination',
        startDate: exam.startDate,
        endDate: exam.endDate,
        description: `${exam.termType || 'Term'} examination series for academic term ${exam.academicSession || exam.session || ''}. Status: ${exam.status}.`,
        status: isActive ? 'Active' : isPast ? 'Past' : 'Upcoming',
      });
    });

    // Sort chronologically by start date
    return list.sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  }, [sessions, semesters, examinations]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <CalendarIcon className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Academics Calendar</h1>
                <Badge variant="blue" size="sm">
                  Institutional Schedule
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Official calendar milestones, semester timelines, and university examination schedules governed by Academic Affairs.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <CalendarDays className="w-4 h-4 text-[#1e3a8a]" />
            <span>{milestones.length} Calendar Events</span>
          </div>
        </div>
      </div>

      {/* Milestones List */}
      {isLoading ? (
        <div className="p-12 text-center text-xs text-[#64748b] bg-white rounded-xl border border-[#e2e8f0]">
          Loading academic calendar milestones...
        </div>
      ) : milestones.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <CalendarIcon className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">No Calendar Data Found</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            No academic sessions, semesters, or examination milestones are currently scheduled.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="bg-[#f8fafc] px-5 py-3.5 border-b border-[#e2e8f0] flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#475569]">
              Academic Milestones Timeline
            </span>
            <span className="text-xs text-[#64748b] font-medium">
              Sorted Chronologically
            </span>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {milestones.map((m) => (
              <div
                key={m.id}
                className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <Badge
                      variant={
                        m.category === 'Session'
                          ? 'purple'
                          : m.category === 'Semester'
                          ? 'blue'
                          : 'amber'
                      }
                      size="sm"
                    >
                      {m.category}
                    </Badge>
                    <h3 className="text-sm font-bold text-[#1e293b]">{m.title}</h3>
                    <Badge
                      variant={
                        m.status === 'Active'
                          ? 'emerald'
                          : m.status === 'Upcoming'
                          ? 'blue'
                          : 'neutral'
                      }
                      size="sm"
                    >
                      {m.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-[#64748b] leading-relaxed">{m.description}</p>
                </div>

                <div className="text-left sm:text-right shrink-0">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 text-[#1e293b] font-mono text-xs font-semibold border border-slate-200">
                    <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
                    <span>
                      {new Date(m.startDate).toLocaleDateString()}
                      {m.endDate ? ` – ${new Date(m.endDate).toLocaleDateString()}` : ''}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Institutional Notice */}
      <div className="bg-[#eff6ff] border border-[#bfdbfe] rounded-xl p-4 flex items-start gap-3 text-xs text-[#1e3a8a]">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Official Calendar Disclaimer:</span>
          <p className="mt-0.5 text-[#3b82f6] leading-relaxed">
            All academic deadlines, semester schedules, and examination slots are strictly governed by the Academic Council. Any revisions will be reflected here and broadcast via cohort notices.
          </p>
        </div>
      </div>
    </div>
  );
}
