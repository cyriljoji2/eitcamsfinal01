import React from 'react';
import { MessageSquare, Bell, GraduationCap, Info } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentClassMessagesViewProps {
  student: Student;
}

export function StudentClassMessagesView({ student }: StudentClassMessagesViewProps) {
  const studentProg = student.program || student.admissionClass || 'Undergraduate Program';
  const studentBatch = student.batch || student.section || 'N/A';
  const studentSem = student.currentSemester || '';

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <MessageSquare className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Class Messages & Announcements</h1>
                <Badge variant="blue" size="sm">
                  Cohort Channel
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Program: <strong>{studentProg}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Batch: <strong>{studentBatch}</strong>
                </span>
                {studentSem && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{studentSem}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <Bell className="w-4 h-4 text-[#94a3b8]" />
            <span>0 Active Notices</span>
          </div>
        </div>
      </div>

      {/* Empty State Card */}
      <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center text-[#94a3b8] mx-auto">
          <MessageSquare className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h3 className="text-base font-bold text-[#1e293b]">No class messages available.</h3>
          <p className="text-xs text-[#64748b] max-w-lg mx-auto leading-relaxed">
            There are currently no active announcements or communication broadcasts targeting your academic cohort ({studentProg} &bull; Batch {studentBatch} {studentSem ? `&bull; ${studentSem}` : ''}).
          </p>
          <p className="text-xs text-[#94a3b8] mt-2">
            Messages, syllabus updates, and lecture scheduling notes posted by your department faculty or the Academic Affairs Office will be automatically routed here.
          </p>
        </div>
      </div>

      {/* Informational Guidance Notice */}
      <div className="bg-[#eff6ff] border border-[#bfdbfe] rounded-xl p-4 flex items-start gap-3 text-xs text-[#1e3a8a]">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Cohort-Targeted Notification Policy:</span>
          <p className="mt-0.5 text-[#3b82f6] leading-relaxed">
            To prevent spam, class messages are strictly segmented by Program, Registered Course Slots, and Examination Groups. Urgent institutional notices will also be reflected in the official Academic Calendar.
          </p>
        </div>
      </div>
    </div>
  );
}
