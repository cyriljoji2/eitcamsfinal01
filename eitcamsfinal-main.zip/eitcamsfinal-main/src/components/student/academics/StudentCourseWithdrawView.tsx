import React, { useState, useEffect, useMemo } from 'react';
import {
  RotateCcw,
  AlertTriangle,
  Lock,
  CheckCircle2,
  Clock,
  BookOpen,
  User,
  ShieldAlert,
  Info,
  Send,
  FileText,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { AuthRole, CourseEnrolmentRecord, SemesterRecord } from '../../../types/database';
import { studentPortalService, CourseWithdrawalRequestRecord } from '../../../services/studentPortalService';
import { Badge } from '../../ui/Badge';
import { Button } from '../../ui/Button';

interface StudentCourseWithdrawViewProps {
  student: Student;
}

export function StudentCourseWithdrawView({ student }: StudentCourseWithdrawViewProps) {
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [withdrawalRequests, setWithdrawalRequests] = useState<CourseWithdrawalRequestRecord[]>([]);
  const [currentSemesterRecord, setCurrentSemesterRecord] = useState<SemesterRecord | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [targetEnrolment, setTargetEnrolment] = useState<CourseEnrolmentRecord | null>(null);
  const [withdrawalReason, setWithdrawalReason] = useState('');
  const [reasonError, setReasonError] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';
  const studentSem = student.currentSemester || '';
  const studentRegNo = student.registrationNumber || '';

  async function loadData() {
    setIsLoading(true);
    setFeedback(null);
    try {
      const [enrList, semList] = await Promise.all([
        studentRegNo
          ? devDataAdapter.academic.getEnrolments(
              { student_id: studentRegNo },
              { role: AuthRole.STUDENT, userId: studentRegNo }
            )
          : Promise.resolve([]),
        devDataAdapter.academic.getSemesters(),
      ]);

      setEnrolments(enrList);
      const activeSem = semList.find((s) => s.is_current) || semList[0] || null;
      setCurrentSemesterRecord(activeSem);

      if (studentRegNo) {
        const reqs = studentPortalService.getCourseWithdrawalRequests(studentRegNo);
        setWithdrawalRequests(reqs);
      }
    } catch (err) {
      console.error('Failed to load course withdrawal data', err);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, [studentRegNo, studentProg, studentBatch, studentSem]);

  // Active enrolled courses
  const activeEnrolments = useMemo(() => {
    return enrolments.filter((e) => e.enrolment_status === 'ACTIVE');
  }, [enrolments]);

  // Withdrawn enrolments
  const withdrawnEnrolments = useMemo(() => {
    return enrolments.filter((e) => e.enrolment_status === 'WITHDRAWN');
  }, [enrolments]);

  const totalActiveCredits = activeEnrolments.length * 4;

  // Pending request mapping
  const pendingRequestsMap = useMemo(() => {
    const map = new Map<string, CourseWithdrawalRequestRecord>();
    withdrawalRequests.forEach((req) => {
      map.set(req.enrolmentId, req);
    });
    return map;
  }, [withdrawalRequests]);

  async function handleConfirmWithdraw() {
    if (!targetEnrolment) return;

    if (!withdrawalReason.trim()) {
      setReasonError('Please provide a specific academic or administrative reason for course withdrawal.');
      return;
    }

    setIsProcessing(true);
    setFeedback(null);
    setReasonError('');

    try {
      studentPortalService.submitCourseWithdrawalRequest({
        studentId: student.id || studentRegNo,
        studentRegistrationNumber: studentRegNo,
        studentName: student.fullName,
        enrolmentId: targetEnrolment.enrolment_id,
        courseCode: targetEnrolment.course_code,
        courseTitle: targetEnrolment.course_title,
        credits: 4,
        semester: String(targetEnrolment.semester || studentSem || 'Current Semester'),
        reason: withdrawalReason.trim(),
      });

      setFeedback({
        type: 'success',
        message: `Course withdrawal request for ${targetEnrolment.course_code} (${targetEnrolment.course_title}) submitted to Academic Affairs for faculty advisor endorsement and processing.`,
      });
      setTargetEnrolment(null);
      setWithdrawalReason('');
      await loadData();
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Failed to submit course withdrawal request. Please try again.',
      });
    } finally {
      setIsProcessing(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-rose-600 text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <RotateCcw className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Course Withdrawal Request</h1>
                <Badge variant="blue" size="sm">
                  Academic Affairs Governance
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Program: <strong>{studentProg || 'Enrolled Program'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Section: <strong>{studentBatch || 'N/A'}</strong>
                </span>
                {studentSem && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{studentSem}</strong>
                    </span>
                  </>
                )}
                {currentSemesterRecord && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Term: <strong>{currentSemesterRecord.name}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
            <span>
              Total Enrolled Credits: <strong>{totalActiveCredits} cr</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Feedback Alerts */}
      {feedback && (
        <div
          className={`p-4 rounded-xl text-xs flex items-start gap-3 border ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Institutional Policy Guidelines */}
      <div className="bg-[#eff6ff] border border-[#bfdbfe] rounded-xl p-4 flex items-start gap-3 text-xs text-[#1e3a8a] shadow-xs">
        <Info className="w-4 h-4 shrink-0 text-[#2563eb] mt-0.5" />
        <div className="space-y-1">
          <span className="font-bold">University Course Withdrawal Policy:</span>
          <p className="text-[#3b82f6] leading-relaxed">
            Course withdrawal requests are formally reviewed by your Faculty Proctor and the Academic Office. Official academic records are updated upon administrative endorsement. Withdrawn courses will not affect semester GPA calculation.
          </p>
        </div>
      </div>

      {/* Enrolled Courses Eligible for Withdrawal */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        <div className="bg-[#f8fafc] px-5 py-3.5 border-b border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#1e293b]">
              Enrolled Courses ({activeEnrolments.length})
            </h2>
          </div>
          <span className="text-xs text-[#64748b] font-medium">
            Active Registrations: <strong>{activeEnrolments.length}</strong>
          </span>
        </div>

        {isLoading ? (
          <div className="p-12 text-center text-xs text-[#64748b]">
            Loading authoritative course enrolments from Academic Office...
          </div>
        ) : activeEnrolments.length === 0 ? (
          <div className="p-12 text-center text-xs text-[#64748b] space-y-2">
            <BookOpen className="w-10 h-10 mx-auto text-[#94a3b8]" />
            <h3 className="font-bold text-[#1e293b]">No Active Course Enrolments Found</h3>
            <p className="max-w-md mx-auto">
              You do not have any active course enrollments to withdraw from. Course registrations and schedule allocations are maintained by the Academic Affairs Office.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#f1f5f9]">
            {activeEnrolments.map((enr) => {
              const pendingReq = pendingRequestsMap.get(enr.enrolment_id);

              return (
                <div
                  key={enr.enrolment_id}
                  className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span className="font-bold font-mono text-sm text-[#1e3a8a]">
                        {enr.course_code}
                      </span>
                      <span className="font-bold text-sm text-[#1e293b]">
                        {enr.course_title}
                      </span>
                      <Badge variant="blue" size="sm">
                        4 Credits
                      </Badge>
                      {enr.section && (
                        <Badge variant="neutral" size="sm" className="font-mono">
                          Section {enr.section}
                        </Badge>
                      )}
                      {pendingReq && (
                        <Badge variant="amber" size="sm">
                          Withdrawal Pending Review
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center gap-4 text-xs text-[#64748b] flex-wrap">
                      <span>Semester: {enr.semester || studentSem || 'Current'}</span>
                      <span>&bull;</span>
                      <span>Academic Year: {enr.academic_year || '2026-2027'}</span>
                      {pendingReq && (
                        <>
                          <span>&bull;</span>
                          <span className="text-amber-700 italic">
                            Reason submitted: "{pendingReq.reason}"
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0 text-left sm:text-right">
                    {pendingReq ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-800 text-xs font-semibold border border-amber-200">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        Requested ({new Date(pendingReq.submittedAt).toLocaleDateString()})
                      </span>
                    ) : (
                      <Button
                        variant="danger"
                        size="sm"
                        disabled={isProcessing}
                        onClick={() => {
                          setTargetEnrolment(enr);
                          setWithdrawalReason('');
                          setReasonError('');
                        }}
                        className="cursor-pointer"
                      >
                        Request Withdrawal
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Historical Withdrawn Courses */}
      {withdrawnEnrolments.length > 0 && (
        <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
          <div className="bg-[#f8fafc] px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#64748b]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#64748b]">
                Officially Withdrawn Courses ({withdrawnEnrolments.length})
              </h3>
            </div>
          </div>

          <div className="divide-y divide-[#f1f5f9]">
            {withdrawnEnrolments.map((enr) => (
              <div key={enr.enrolment_id} className="p-4 flex items-center justify-between text-xs">
                <div>
                  <span className="font-mono font-bold text-[#1e3a8a]">{enr.course_code}</span> — {enr.course_title}
                  {enr.withdrawal_reason && (
                    <p className="text-[11px] text-[#64748b] mt-0.5">
                      Reason: {enr.withdrawal_reason}
                    </p>
                  )}
                </div>
                <Badge variant="neutral" size="sm">
                  Withdrawn
                </Badge>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {targetEnrolment && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 space-y-4 shadow-xl border border-[#e2e8f0]">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#1e293b]">
                  Submit Course Withdrawal Request
                </h3>
                <p className="text-xs text-[#64748b] mt-1">
                  You are requesting to withdraw from{' '}
                  <strong className="text-[#1e293b]">
                    {targetEnrolment.course_code} — {targetEnrolment.course_title}
                  </strong>
                  .
                </p>
              </div>
            </div>

            <div className="bg-[#f8fafc] rounded-lg p-3 text-xs space-y-1 text-[#475569] border border-[#f1f5f9]">
              <div>Section: <strong className="text-[#1e293b]">{targetEnrolment.section || 'A'}</strong></div>
              <div>Credits to be dropped: <strong className="text-rose-600">4 cr</strong></div>
              <div>
                Enrolled credits after withdrawal:{' '}
                <strong className="text-[#1e293b]">{Math.max(0, totalActiveCredits - 4)} cr</strong>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#1e293b] block">
                Reason for Withdrawal <span className="text-rose-600">*</span>
              </label>
              <textarea
                rows={3}
                value={withdrawalReason}
                onChange={(e) => {
                  setWithdrawalReason(e.target.value);
                  if (reasonError) setReasonError('');
                }}
                placeholder="State your reason (e.g. course load reduction, medical reason, scheduling conflict)..."
                className="w-full px-3 py-2 text-xs border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] text-[#1e293b]"
              />
              {reasonError && (
                <p className="text-[11px] text-rose-600 font-medium">{reasonError}</p>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                disabled={isProcessing}
                onClick={() => {
                  setTargetEnrolment(null);
                  setWithdrawalReason('');
                  setReasonError('');
                }}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                size="sm"
                disabled={isProcessing}
                onClick={handleConfirmWithdraw}
              >
                {isProcessing ? 'Submitting...' : 'Submit Request'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
