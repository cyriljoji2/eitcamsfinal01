import React from 'react';
import { HelpCircle, CheckSquare, Info } from 'lucide-react';
import { Student } from '../../../types/admission';
import { Badge } from '../../ui/Badge';

interface StudentQCMViewProps {
  student: Student;
}

export function StudentQCMView({ student }: StudentQCMViewProps) {
  const studentProg = student.program || student.admissionClass || 'Undergraduate Program';
  const studentBatch = student.batch || student.section || 'N/A';
  const studentSem = student.currentSemester || '';

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <HelpCircle className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">QCM (Continuous Evaluation)</h1>
                <Badge variant="blue" size="sm">
                  Online Assessments
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Program: <strong>{studentProg}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Batch: <strong>{studentBatch}</strong>
                </span>
                {studentSem && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{studentSem}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <CheckSquare className="w-4 h-4 text-[#94a3b8]" />
            <span>0 Active Quizzes</span>
          </div>
        </div>
      </div>

      {/* Strict Truthful Empty State */}
      <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
        <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center text-[#94a3b8] mx-auto">
          <HelpCircle className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h3 className="text-base font-bold text-[#1e293b]">No QCM content is currently available.</h3>
          <p className="text-xs text-[#64748b] max-w-lg mx-auto leading-relaxed">
            There are currently no active multiple-choice evaluations or continuous quizzes scheduled for your enrolled courses.
          </p>
          <p className="text-xs text-[#94a3b8] mt-2">
            When course instructors schedule and publish an online quiz or continuous evaluation task, it will be listed here with syllabus topics, duration, and access windows.
          </p>
        </div>
      </div>

      {/* Assessment Guidelines Notice */}
      <div className="bg-[#eff6ff] border border-[#bfdbfe] rounded-xl p-4 flex items-start gap-3 text-xs text-[#1e3a8a]">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Continuous Evaluation Notice:</span>
          <p className="mt-0.5 text-[#3b82f6] leading-relaxed">
            Formal mid-term and semester-end examinations are administered separately by the Examination Controller. Refer to the Exam Timetable and Hall Tickets tabs for official university examination schedules.
          </p>
        </div>
      </div>
    </div>
  );
}
