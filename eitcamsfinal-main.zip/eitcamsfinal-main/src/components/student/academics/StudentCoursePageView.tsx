import React, { useState, useEffect, useMemo } from 'react';
import {
  BookOpen,
  Layers,
  Search,
  CheckCircle2,
  Clock,
  User,
  MapPin,
  FileText,
  Calendar,
  Building,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { AcademicClass, AcademicSubject, FacultyAssignment } from '../../../types/academic';
import { devDataAdapter } from '../../../services/devDataAdapter';
import { AuthRole, CourseRecord, CourseOfferingRecord, CourseEnrolmentRecord } from '../../../types/database';
import { Badge } from '../../ui/Badge';

interface StudentCoursePageViewProps {
  student: Student;
  classes: AcademicClass[];
  subjects: AcademicSubject[];
  facultyAssignments: FacultyAssignment[];
}

interface ComprehensiveCourseItem {
  id: string;
  code: string;
  name: string;
  credits: number;
  type: string;
  category: string;
  department: string;
  semester: string;
  description?: string;
  prerequisites?: string[];
  // Registration and Offering attributes
  registrationStatus: 'Registered' | 'Available' | 'Withdrawn';
  facultyName?: string;
  slot?: string;
  schedule?: string;
  room?: string;
  offeringId?: string;
}

export function StudentCoursePageView({
  student,
  classes,
  subjects,
  facultyAssignments,
}: StudentCoursePageViewProps) {
  const [academicCourses, setAcademicCourses] = useState<CourseRecord[]>([]);
  const [offerings, setOfferings] = useState<CourseOfferingRecord[]>([]);
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';
  const studentSem = student.currentSemester || '';
  const studentRegNo = student.registrationNumber || '';

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      setIsLoading(true);
      try {
        const [cList, offList, enrList] = await Promise.all([
          devDataAdapter.academic.getCourses(),
          devDataAdapter.academic.getCourseOfferings(),
          studentRegNo
            ? devDataAdapter.academic.getEnrolments(
                { student_id: studentRegNo },
                { role: AuthRole.STUDENT, userId: studentRegNo }
              )
            : Promise.resolve([]),
        ]);

        if (!isMounted) return;
        setAcademicCourses(cList);
        setOfferings(offList);
        setEnrolments(enrList);
      } catch (err) {
        console.error('Failed to load courses for course page', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [studentRegNo]);

  // Combine academic subjects, courses, and registered offerings
  const courseList: ComprehensiveCourseItem[] = useMemo(() => {
    const listMap = new Map<string, ComprehensiveCourseItem>();
    const normProg = studentProg.toLowerCase().trim();

    // Student registered enrolments map
    const enrolmentsMap = new Map<string, CourseEnrolmentRecord>();
    enrolments.forEach((e) => {
      enrolmentsMap.set(e.course_code.toLowerCase().trim(), e);
    });

    // 1. Ingest Academic Subjects
    subjects.forEach((s) => {
      const sClassName = s.className || '';
      const sClassId = s.classId || '';
      const matchProg =
        !normProg ||
        sClassName.toLowerCase().includes(normProg) ||
        normProg.includes(sClassName.toLowerCase()) ||
        sClassId.toLowerCase() === normProg;

      if (matchProg) {
        const key = s.code.toLowerCase().trim();
        const enr = enrolmentsMap.get(key);

        // Find assigned faculty for this subject
        const fa = facultyAssignments.find(
          (f) =>
            f.subjectCode?.toLowerCase().trim() === key ||
            (f.subjectId && f.subjectId === s.id)
        );

        const offering = offerings.find((o) => o.course_code.toLowerCase().trim() === key);

        listMap.set(key, {
          id: s.id,
          code: s.code,
          name: s.name,
          credits: s.credits || s.creditsOrPeriodsPerWeek || 4,
          type: s.type || 'Core',
          category: s.type === 'Core' ? 'Program Core (PC)' : 'Program Elective (PE)',
          department: s.department || 'Engineering & Technology',
          semester: String(s.semester || studentSem || 'Current Semester'),
          description: s.description,
          prerequisites: s.prerequisites,
          registrationStatus: enr?.enrolment_status === 'ACTIVE' ? 'Registered' : enr?.enrolment_status === 'WITHDRAWN' ? 'Withdrawn' : 'Available',
          facultyName: offering?.assigned_faculty_name || fa?.facultyName,
          slot: enr?.section || offering?.section,
          schedule: 'Scheduled Period',
          room: 'Academic Hall',
          offeringId: offering?.offering_id,
        });
      }
    });

    // 2. Ingest Academic Office Courses & Offerings
    academicCourses.forEach((c) => {
      const cCode = c.course_code || '';
      const key = cCode.toLowerCase().trim();
      const cDept = c.department || '';
      const matchProg =
        !normProg ||
        cDept.toLowerCase().includes(normProg) ||
        normProg.includes(cDept.toLowerCase());

      if (matchProg || !listMap.has(key)) {
        const enr = enrolmentsMap.get(key);
        const off = offerings.find((o) => o.course_code.toLowerCase().trim() === key);

        if (!listMap.has(key)) {
          listMap.set(key, {
            id: c.course_id,
            code: cCode,
            name: c.course_title,
            credits: c.credits,
            type: c.course_type,
            category: 'Program Core (PC)',
            department: c.department || 'Engineering & Technology',
            semester: String(c.semester || studentSem || 'Current Semester'),
            description: c.description,
            prerequisites: [],
            registrationStatus: enr?.enrolment_status === 'ACTIVE' ? 'Registered' : enr?.enrolment_status === 'WITHDRAWN' ? 'Withdrawn' : 'Available',
            facultyName: off?.assigned_faculty_name || 'Academic Faculty',
            slot: enr?.section || off?.section,
            schedule: 'Scheduled Cohort Hours',
            room: 'Academic Complex',
            offeringId: off?.offering_id,
          });
        }
      }
    });

    return Array.from(listMap.values());
  }, [studentProg, studentSem, subjects, academicCourses, offerings, enrolments, facultyAssignments]);

  const filteredCourses = useMemo(() => {
    return courseList.filter((item) => {
      if (filterType !== 'All' && item.type.toLowerCase() !== filterType.toLowerCase()) {
        return false;
      }
      if (filterStatus !== 'All' && item.registrationStatus !== filterStatus) {
        return false;
      }
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase().trim();
        return (
          item.code.toLowerCase().includes(q) ||
          item.name.toLowerCase().includes(q) ||
          item.department.toLowerCase().includes(q) ||
          (item.facultyName && item.facultyName.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [courseList, filterType, filterStatus, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Layers className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Course Page & Descriptions</h1>
                <Badge variant="blue" size="sm">
                  Academic Office Catalog
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Degree: <strong>{studentProg || 'Enrolled Program'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Batch: <strong>{studentBatch || 'N/A'}</strong>
                </span>
                {studentSem && (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{studentSem}</strong>
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <span>
              {courseList.filter((c) => c.registrationStatus === 'Registered').length} Enrolled Courses
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-[#e2e8f0] shadow-xs">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#94a3b8]" />
          <input
            type="text"
            placeholder="Search by code, title, or instructor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-[#f8fafc] border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="py-1.5 px-3 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
          >
            <option value="All">All Statuses</option>
            <option value="Registered">Registered</option>
            <option value="Available">Available</option>
            <option value="Withdrawn">Withdrawn</option>
          </select>

          <span className="text-xs text-[#64748b] font-medium hidden sm:inline">
            Showing {filteredCourses.length} courses
          </span>
        </div>
      </div>

      {/* Course Cards */}
      {isLoading ? (
        <div className="p-12 text-center text-xs text-[#64748b] bg-white rounded-xl border border-[#e2e8f0]">
          Loading course catalog from Academic Office...
        </div>
      ) : filteredCourses.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-dashed border-[#cbd5e1] shadow-xs space-y-2">
          <BookOpen className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-sm font-bold text-[#1e293b]">No Courses Found</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto">
            {searchTerm
              ? 'No courses matched your search query.'
              : 'No courses are currently configured for your academic cohort.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCourses.map((c) => (
            <div
              key={c.id}
              className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs hover:border-[#bfdbfe] transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold font-mono text-sm text-[#1e3a8a]">{c.code}</span>
                      <Badge
                        variant={
                          c.registrationStatus === 'Registered'
                            ? 'emerald'
                            : c.registrationStatus === 'Withdrawn'
                            ? 'rose'
                            : 'neutral'
                        }
                        size="sm"
                      >
                        {c.registrationStatus}
                      </Badge>
                      <Badge variant="blue" size="sm">
                        {c.credits} Credits
                      </Badge>
                    </div>
                    <h3 className="text-base font-bold text-[#1e293b] mt-1">{c.name}</h3>
                  </div>
                  <span className="text-[11px] font-semibold text-[#64748b] bg-slate-100 px-2 py-0.5 rounded shrink-0">
                    {c.type}
                  </span>
                </div>

                {c.description && (
                  <p className="text-xs text-[#64748b] leading-relaxed line-clamp-2">
                    {c.description}
                  </p>
                )}

                {/* Offering & Schedule Details */}
                <div className="bg-[#f8fafc] rounded-lg p-3 space-y-1.5 text-xs text-[#475569] border border-[#f1f5f9]">
                  {c.facultyName && (
                    <div className="flex items-center justify-between">
                      <span className="text-[#64748b] flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-[#94a3b8]" /> Instructor:
                      </span>
                      <span className="font-semibold text-[#1e293b]">{c.facultyName}</span>
                    </div>
                  )}

                  {c.slot && (
                    <div className="flex items-center justify-between">
                      <span className="text-[#64748b] flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#94a3b8]" /> Section / Slot:
                      </span>
                      <span className="font-mono text-[#1e293b] font-medium">
                        Section {c.slot}
                      </span>
                    </div>
                  )}

                  {c.room && (
                    <div className="flex items-center justify-between">
                      <span className="text-[#64748b] flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-[#94a3b8]" /> Room:
                      </span>
                      <span className="text-[#1e293b]">{c.room}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <span className="text-[#64748b] flex items-center gap-1.5">
                      <Building className="w-3.5 h-3.5 text-[#94a3b8]" /> Category:
                    </span>
                    <span className="text-[#1e293b]">{c.category}</span>
                  </div>
                </div>
              </div>

              {/* Prerequisites and Footer */}
              <div className="pt-3 border-t border-[#f1f5f9] flex items-center justify-between text-xs text-[#64748b]">
                <span>
                  Prerequisites:{' '}
                  <strong className="text-[#334155]">
                    {c.prerequisites && c.prerequisites.length > 0
                      ? c.prerequisites.join(', ')
                      : 'None'}
                  </strong>
                </span>
                <span className="text-[#94a3b8] font-mono text-[11px]">{c.semester}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
