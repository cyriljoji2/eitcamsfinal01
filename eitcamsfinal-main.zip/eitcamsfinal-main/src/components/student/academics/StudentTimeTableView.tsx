import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Calendar,
  MapPin,
  User,
  BookOpen,
  CheckCircle2,
  CalendarDays,
  AlertCircle,
} from 'lucide-react';
import { Student } from '../../../types/admission';
import { academicRepository } from '../../../services/academicService';
import { AuthRole, TimetableSlotRecord, CourseEnrolmentRecord } from '../../../types/database';
import { Badge } from '../../ui/Badge';
import { StudentSemesterSelector } from '../common/StudentSemesterSelector';
import { getStudentAvailableSemesters } from '../../../utils/studentSemesterUtils';
import { useAuth } from '../../../context/AuthContext';

interface StudentTimeTableViewProps {
  student: Student;
}

interface TimetableSlotEntry {
  courseCode: string;
  courseName: string;
  facultyName: string;
  slot: string;
  timeSlotLabel: string;
  day: string;
  time: string;
  room: string;
  credits: number;
}

const DAYS_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function capitalizeDay(dayStr: string): string {
  if (!dayStr) return 'Monday';
  const lower = dayStr.toLowerCase().trim();
  if (lower.startsWith('mon')) return 'Monday';
  if (lower.startsWith('tue')) return 'Tuesday';
  if (lower.startsWith('wed')) return 'Wednesday';
  if (lower.startsWith('thu')) return 'Thursday';
  if (lower.startsWith('fri')) return 'Friday';
  if (lower.startsWith('sat')) return 'Saturday';
  if (lower.startsWith('sun')) return 'Sunday';
  return 'Monday';
}

export function StudentTimeTableView({ student }: StudentTimeTableViewProps) {
  const { session } = useAuth();
  const [enrolments, setEnrolments] = useState<CourseEnrolmentRecord[]>([]);
  const [timetableSlots, setTimetableSlots] = useState<TimetableSlotRecord[]>([]);
  const [publishedInfo, setPublishedInfo] = useState<{
    published: boolean;
    message?: string;
    version?: number;
    published_at?: string;
    published_by_name?: string;
    change_notes?: string;
  } | null>(null);
  const [selectedSemester, setSelectedSemester] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [activeDay, setActiveDay] = useState<string>('All');

  const studentProg = student.program || student.admissionClass || '';
  const studentBatch = student.batch || student.section || '';

  // Derive identity from authenticated session, falling back to student record
  const authStudentIdent =
    session?.user?.username ||
    session?.user?.user_id ||
    session?.userId ||
    student.registrationNumber ||
    student.id ||
    '';

  useEffect(() => {
    let isMounted = true;
    async function loadAcademicTimetable() {
      if (!authStudentIdent) return;
      setIsLoading(true);
      try {
        const actor = { role: AuthRole.STUDENT, userId: authStudentIdent };
        const [enrList, pubResult] = await Promise.all([
          academicRepository.getEnrolments({ student_id: authStudentIdent }, actor),
          academicRepository.getPublishedTimetableForStudent(authStudentIdent, actor),
        ]);

        if (isMounted) {
          setEnrolments(enrList);
          setPublishedInfo(pubResult);
          setTimetableSlots(pubResult?.slots || []);
        }
      } catch (err: any) {
        console.error('Failed to load student timetable records', err);
        if (isMounted) {
          setPublishedInfo({
            published: false,
            message: err?.message || 'Failed to load authoritative timetable records.',
          });
          setTimetableSlots([]);
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadAcademicTimetable();
    return () => {
      isMounted = false;
    };
  }, [authStudentIdent]);

  // Determine available semesters from student's actual records
  const availableSemesters = useMemo(() => {
    const list = getStudentAvailableSemesters({ student });
    enrolments.forEach((e) => {
      if (e.semester) {
        const label = `Semester ${e.semester}`;
        if (!list.includes(label)) list.push(label);
      }
    });
    return Array.from(new Set(list)).sort();
  }, [student, enrolments]);

  // Auto-select current semester once available
  useEffect(() => {
    if (!selectedSemester && availableSemesters.length > 0) {
      const match =
        availableSemesters.find(
          (s) => student.currentSemester && s.toLowerCase() === student.currentSemester.toLowerCase()
        ) || availableSemesters[0];
      setSelectedSemester(match);
    }
  }, [selectedSemester, availableSemesters, student.currentSemester]);

  // Extract timetable entries from active enrolments matching selected semester
  const timetableEntries: TimetableSlotEntry[] = useMemo(() => {
    if (!selectedSemester) return [];

    const semMatch = selectedSemester.match(/(\d+)/);
    const selectedSemNum = semMatch ? parseInt(semMatch[1], 10) : null;

    // Filter student active enrolments
    const activeEnrolments = enrolments.filter((e) => {
      if (e.enrolment_status !== 'ACTIVE') return false;
      if (selectedSemNum && e.semester) {
        return e.semester === selectedSemNum;
      }
      return true;
    });

    if (activeEnrolments.length === 0) return [];

    const entries: TimetableSlotEntry[] = [];

    activeEnrolments.forEach((enr) => {
      // Find matching timetable slots from Academic Office
      const matchingSlots = timetableSlots.filter((slot) => {
        const matchCourse = slot.course_code.toLowerCase().trim() === enr.course_code.toLowerCase().trim();
        const matchSection = !enr.section || !slot.section || slot.section.toLowerCase() === enr.section.toLowerCase();
        return matchCourse && matchSection;
      });

      if (matchingSlots.length > 0) {
        matchingSlots.forEach((slot) => {
          entries.push({
            courseCode: enr.course_code,
            courseName: enr.course_title,
            facultyName: slot.faculty_name || 'Academic Faculty',
            slot: slot.slot_id,
            timeSlotLabel: `${slot.start_time} - ${slot.end_time}`,
            day: capitalizeDay(slot.day_of_week),
            time: `${slot.start_time} - ${slot.end_time}`,
            room: slot.room || 'Academic Block',
            credits: 4,
          });
        });
      } else {
        // Enrolled course without a specific slot scheduled yet
        entries.push({
          courseCode: enr.course_code,
          courseName: enr.course_title,
          facultyName: 'Department Faculty',
          slot: enr.section ? `Sec ${enr.section}` : 'Standard Slot',
          timeSlotLabel: 'Scheduled Cohort Hours',
          day: 'Monday',
          time: '09:00 - 10:00',
          room: 'Academic Hall',
          credits: 4,
        });
      }
    });

    return entries;
  }, [selectedSemester, enrolments, timetableSlots]);

  const filteredEntries = useMemo(() => {
    if (activeDay === 'All') return timetableEntries;
    return timetableEntries.filter((e) => e.day.toLowerCase() === activeDay.toLowerCase());
  }, [timetableEntries, activeDay]);

  // Group entries by Day for the weekly schedule
  const groupedByDay = useMemo(() => {
    const map: Record<string, TimetableSlotEntry[]> = {};
    DAYS_ORDER.forEach((d) => {
      map[d] = [];
    });

    timetableEntries.forEach((entry) => {
      if (!map[entry.day]) {
        map[entry.day] = [];
      }
      map[entry.day].push(entry);
    });

    return map;
  }, [timetableEntries]);

  const activeDaysWithClasses = useMemo(() => {
    return DAYS_ORDER.filter((d) => groupedByDay[d]?.length > 0);
  }, [groupedByDay]);

  const activeEnrolledCount = enrolments.filter((e) => e.enrolment_status === 'ACTIVE').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Clock className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Weekly Time Table</h1>
                <Badge variant={publishedInfo?.published ? "green" : "blue"} size="sm">
                  {publishedInfo?.published ? `Official Timetable v${publishedInfo.version}` : 'Academic Office Schedule'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1 flex items-center gap-2 flex-wrap">
                <span>
                  Program: <strong>{studentProg || 'Enrolled Program'}</strong>
                </span>
                <span>&bull;</span>
                <span>
                  Section / Batch: <strong>{studentBatch || 'N/A'}</strong>
                </span>
                {selectedSemester ? (
                  <>
                    <span>&bull;</span>
                    <span>
                      Semester: <strong>{selectedSemester}</strong>
                    </span>
                  </>
                ) : student.currentSemester ? (
                  <>
                    <span>&bull;</span>
                    <span>
                      Current: <strong>{student.currentSemester}</strong>
                    </span>
                  </>
                ) : null}
                {publishedInfo?.published && publishedInfo.published_at && (
                  <>
                    <span>&bull;</span>
                    <span className="text-emerald-700 font-semibold">
                      Published: {new Date(publishedInfo.published_at).toLocaleDateString()}
                    </span>
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <CalendarDays className="w-4 h-4 text-[#1e3a8a]" />
            <span>{activeEnrolledCount} Enrolled Course(s)</span>
          </div>
        </div>
      </div>

      {/* Semester Dropdown */}
      <StudentSemesterSelector
        id="student-timetable-semester"
        selectedSemester={selectedSemester}
        onChange={(sem) => {
          setSelectedSemester(sem);
          setActiveDay('All');
        }}
        availableSemesters={availableSemesters}
        helperText="* Enrolled Semesters"
      />

      {isLoading ? (
        <div className="p-12 text-center text-xs text-[#64748b] bg-white rounded-xl border border-[#e2e8f0]">
          Loading authoritative timetable records from Academic Office...
        </div>
      ) : !selectedSemester ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Calendar className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            Please select a semester to view your timetable
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Choose an enrolled semester from the dropdown above to display your official weekly class schedule and slot allocation.
          </p>
        </div>
      ) : timetableEntries.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-[#cbd5e1] p-12 text-center shadow-xs space-y-3">
          <Clock className="w-10 h-10 mx-auto text-[#94a3b8]" />
          <h3 className="text-base font-bold text-[#1e293b]">
            {publishedInfo && !publishedInfo.published
              ? 'No Official Timetable Published Yet'
              : 'No scheduled sessions found for this semester'}
          </h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            {publishedInfo?.message ||
              'Your course schedule will appear here once the authoritative timetable is confirmed and published by the Academic Affairs Office.'}
          </p>
        </div>
      ) : (
        <>
          {/* Day Selection Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setActiveDay('All')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 ${
                activeDay === 'All'
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'bg-white text-[#475569] border border-[#e2e8f0] hover:bg-slate-50'
              }`}
            >
              All Days ({timetableEntries.length} Sessions)
            </button>
            {DAYS_ORDER.map((day) => {
              const count = groupedByDay[day]?.length || 0;
              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => setActiveDay(day)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer shrink-0 flex items-center gap-1.5 ${
                    activeDay === day
                      ? 'bg-[#1e3a8a] text-white shadow-xs'
                      : 'bg-white text-[#475569] border border-[#e2e8f0] hover:bg-slate-50'
                  }`}
                >
                  <span>{day}</span>
                  {count > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                        activeDay === day ? 'bg-white/20 text-white' : 'bg-slate-100 text-[#64748b]'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Timetable Schedule Cards & Grid */}
          <div className="space-y-4">
            {activeDay === 'All' ? (
              activeDaysWithClasses.length === 0 ? (
                <div className="p-8 bg-white rounded-xl border border-[#e2e8f0] text-center text-xs text-[#64748b]">
                  No classes scheduled for the selected days.
                </div>
              ) : (
                activeDaysWithClasses.map((day) => (
                  <div key={day} className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
                    <div className="bg-[#f8fafc] px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#1e3a8a]" />
                        <h3 className="font-bold text-xs uppercase tracking-wider text-[#1e293b]">
                          {day}
                        </h3>
                      </div>
                      <span className="text-xs text-[#64748b] font-medium">
                        {groupedByDay[day].length} class(es)
                      </span>
                    </div>

                    <div className="divide-y divide-[#f1f5f9]">
                      {groupedByDay[day].map((item, idx) => (
                        <div
                          key={`${item.courseCode}-${idx}`}
                          className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                        >
                          <div className="space-y-1.5">
                            <div className="flex items-center gap-2.5 flex-wrap">
                              <Badge variant="blue" size="sm" className="font-mono">
                                {item.slot}
                              </Badge>
                              <span className="font-bold text-sm text-[#1e293b]">
                                {item.courseCode} — {item.courseName}
                              </span>
                              <span className="text-xs text-[#64748b] font-medium">
                                ({item.credits} Credits)
                              </span>
                            </div>

                            <div className="flex items-center gap-4 text-xs text-[#64748b] flex-wrap">
                              <span className="flex items-center gap-1.5 text-[#334155] font-medium">
                                <User className="w-3.5 h-3.5 text-[#94a3b8]" />
                                {item.facultyName}
                              </span>
                              <span>&bull;</span>
                              <span className="flex items-center gap-1.5">
                                <MapPin className="w-3.5 h-3.5 text-[#94a3b8]" />
                                Room: {item.room}
                              </span>
                            </div>
                          </div>

                          <div className="text-left sm:text-right shrink-0">
                            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 text-[#1e293b] font-mono text-xs font-bold border border-slate-200">
                              <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
                              {item.time}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )
            ) : (
              <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
                <div className="bg-[#f8fafc] px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#1e3a8a]" />
                    <h3 className="font-bold text-xs uppercase tracking-wider text-[#1e293b]">
                      {activeDay} Classes
                    </h3>
                  </div>
                  <span className="text-xs text-[#64748b] font-medium">
                    {filteredEntries.length} Session(s)
                  </span>
                </div>

                {filteredEntries.length === 0 ? (
                  <div className="p-8 text-center text-xs text-[#64748b]">
                    No classes scheduled for {activeDay}.
                  </div>
                ) : (
                  <div className="divide-y divide-[#f1f5f9]">
                    {filteredEntries.map((item, idx) => (
                      <div
                        key={`${item.courseCode}-${idx}`}
                        className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-2.5 flex-wrap">
                            <Badge variant="blue" size="sm" className="font-mono">
                              {item.slot}
                            </Badge>
                            <span className="font-bold text-sm text-[#1e293b]">
                              {item.courseCode} — {item.courseName}
                            </span>
                          </div>

                          <div className="flex items-center gap-4 text-xs text-[#64748b] flex-wrap">
                            <span className="flex items-center gap-1.5 text-[#334155] font-medium">
                              <User className="w-3.5 h-3.5 text-[#94a3b8]" />
                              {item.facultyName}
                            </span>
                            <span>&bull;</span>
                            <span className="flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-[#94a3b8]" />
                              Room: {item.room}
                            </span>
                          </div>
                        </div>

                        <div className="text-left sm:text-right shrink-0">
                          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 text-[#1e293b] font-mono text-xs font-bold border border-slate-200">
                            <Clock className="w-3.5 h-3.5 text-[#1e3a8a]" />
                            {item.time}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
