import React from 'react';
import { ChevronDown, Calendar } from 'lucide-react';

interface StudentSemesterSelectorProps {
  id?: string;
  selectedSemester: string;
  onChange: (semester: string) => void;
  availableSemesters: string[];
  helperText?: string;
  disabled?: boolean;
}

export function StudentSemesterSelector({
  id = 'semester-select',
  selectedSemester,
  onChange,
  availableSemesters,
  helperText = '* Only Registered Semester',
  disabled = false,
}: StudentSemesterSelectorProps) {
  return (
    <div className="bg-white rounded-xl p-4 sm:p-5 border border-[#e2e8f0] shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
          <label
            htmlFor={id}
            className="text-xs font-bold text-[#1e293b] whitespace-nowrap flex items-center gap-1.5"
          >
            <span>Semester</span>
            <span className="text-[#dc2626] font-semibold">*</span>
          </label>

          <div className="relative min-w-[260px]">
            <select
              id={id}
              value={selectedSemester}
              onChange={(e) => onChange(e.target.value)}
              disabled={disabled}
              className="w-full h-9.5 pl-3.5 pr-9 text-xs font-medium text-[#1e293b] bg-white border border-[#cbd5e1] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]/20 focus:border-[#1e3a8a] transition-colors cursor-pointer appearance-none disabled:bg-slate-50 disabled:text-slate-400"
            >
              <option value="">-- Choose Semester --</option>
              {availableSemesters.map((sem) => (
                <option key={sem} value={sem}>
                  {sem}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-[#64748b] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>

        {helperText && (
          <div className="text-[11px] text-[#dc2626] font-medium flex items-center gap-1">
            <span>{helperText}</span>
          </div>
        )}
      </div>
    </div>
  );
}
