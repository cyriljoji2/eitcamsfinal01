import React from 'react';
import {
  Award,
  Printer,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  TrendingUp,
  School,
  ShieldCheck,
  FileText,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { Examination, StudentExamResult } from '../../types/examination';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface StudentResultsViewProps {
  student: Student;
  results: StudentExamResult[];
  examinations: Examination[];
  onViewResult: (result: StudentExamResult) => void;
}

export function StudentResultsView({
  student,
  results,
  examinations,
  onViewResult,
}: StudentResultsViewProps) {
  // CRITICAL: Filter strictly for PUBLISHED results only
  const publishedResults = results.filter((res) => {
    const parentExam = examinations.find(
      (e) => e.id.toLowerCase() === res.examinationId.toLowerCase()
    );
    return res.verificationStatus === 'Published' || (parentExam && parentExam.status === 'Published');
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-indigo-600 text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Academic Results & Transcripts</h1>
                <Badge variant="emerald" size="sm">
                  {publishedResults.length} Published Marksheets
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-[#f8fafc] px-3.5 py-2 rounded-lg border border-[#e2e8f0] text-xs text-[#64748b]">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>COE Certified & Published</span>
          </div>
        </div>
      </div>

      {/* Published Results List */}
      {publishedResults.length === 0 ? (
        <div className="bg-white rounded-xl p-12 border border-[#e2e8f0] shadow-xs text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-[#1e293b]">No Examination Results Published Yet</h3>
          <p className="text-xs text-[#64748b] max-w-md mx-auto leading-relaxed">
            Examination marks and transcripts will become visible here once officially finalized, moderated, and published by the Controller of Examination (COE).
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {publishedResults.map((result) => (
            <div
              key={result.id}
              className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden"
            >
              {/* Result Card Top Banner */}
              <div className="p-6 border-b border-[#e2e8f0] bg-linear-to-r from-slate-50 to-white flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h2 className="text-lg font-bold text-[#1e293b]">
                      {result.examinationName}
                    </h2>
                    <Badge variant={result.resultStatus === 'Pass' ? 'emerald' : 'rose'} size="sm">
                      {(result.resultStatus || 'Published').toUpperCase()}
                    </Badge>
                    <Badge variant="neutral" size="sm">
                      {result.academicSession}
                    </Badge>
                  </div>
                  <p className="text-xs text-[#64748b] mt-1">
                    Published on {result.publishedAt?.split('T')[0] || '2026-08-20'} • Class: {result.className} (Section {result.section})
                  </p>
                </div>

                {/* Score Summary Badges */}
                <div className="flex items-center gap-4 bg-white p-3 rounded-xl border border-[#e2e8f0] shadow-2xs">
                  <div className="text-center px-2">
                    <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Total Score</span>
                    <span className="text-sm font-bold text-[#1e293b]">
                      {result.totalMarksObtained ?? result.marksObtained} / {result.totalMaxMarks ?? result.maxMarks}
                    </span>
                  </div>
                  <div className="h-7 w-px bg-slate-200" />
                  <div className="text-center px-2">
                    <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Percentage</span>
                    <span className="text-sm font-bold text-emerald-700">{result.percentage}%</span>
                  </div>
                  <div className="h-7 w-px bg-slate-200" />
                  <div className="text-center px-2">
                    <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Grade</span>
                    <span className="text-base font-black text-[#1e3a8a]">{result.overallGrade}</span>
                  </div>
                  {result.classRank && (
                    <>
                      <div className="h-7 w-px bg-slate-200" />
                      <div className="text-center px-2">
                        <span className="text-[10px] text-[#64748b] block font-semibold uppercase">Rank</span>
                        <span className="text-sm font-bold text-indigo-700">#{result.classRank}</span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Subject Breakdown Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-[#1e293b]">
                  <thead className="bg-[#f8fafc] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
                    <tr>
                      <th className="px-6 py-3">Subject Name</th>
                      <th className="px-6 py-3 font-mono">Code</th>
                      <th className="px-6 py-3 text-right">Marks Obtained</th>
                      <th className="px-6 py-3 text-right">Max Marks</th>
                      <th className="px-6 py-3 text-right">Percentage</th>
                      <th className="px-6 py-3 text-center">Grade</th>
                      <th className="px-6 py-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#e2e8f0]">
                    {(result.subjectMarks || []).map((sub, idx) => {
                      const subPerc = sub.percentage !== undefined ? sub.percentage : Math.round(((sub.marksObtained || 0) / (sub.maxMarks || 100)) * 100);
                      const isPassed = sub.isPassed;
                      return (
                        <tr key={idx} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-3.5 font-semibold text-[#1e293b]">
                            {sub.subjectName}
                          </td>
                          <td className="px-6 py-3.5 font-mono text-[#64748b] text-[11px]">
                            {sub.subjectCode}
                          </td>
                          <td className="px-6 py-3.5 text-right font-bold text-[#1e293b]">
                            {sub.marksObtained !== null ? sub.marksObtained : '—'}
                          </td>
                          <td className="px-6 py-3.5 text-right text-[#64748b]">
                            {sub.maxMarks}
                          </td>
                          <td className="px-6 py-3.5 text-right font-medium text-[#475569]">
                            {subPerc}%
                          </td>
                          <td className="px-6 py-3.5 text-center font-bold text-[#1e3a8a]">
                            {sub.grade || '—'}
                          </td>
                          <td className="px-6 py-3.5 text-center">
                            <span
                              className={`inline-flex items-center gap-1 font-bold text-[11px] ${
                                isPassed ? 'text-emerald-700' : 'text-rose-700'
                              }`}
                            >
                              {isPassed ? (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              )}
                              {isPassed ? 'Pass' : 'Fail'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Action Footer */}
              <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-xs text-[#64748b]">
                  Status: Officially verified and published by Controller of Examination.
                </span>
                <Button
                  id={`btn-view-transcript-${result.id}`}
                  variant="primary"
                  size="sm"
                  onClick={() => onViewResult(result)}
                  leftIcon={<Printer className="w-4 h-4" />}
                >
                  Print Official Marksheet
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
