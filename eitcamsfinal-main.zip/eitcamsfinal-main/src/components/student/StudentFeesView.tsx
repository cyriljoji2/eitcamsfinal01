import React, { useState } from 'react';
import {
  DollarSign,
  CreditCard,
  Receipt,
  CheckCircle2,
  AlertCircle,
  Clock,
  HelpCircle,
  Calendar,
  ArrowRight,
  Shield,
} from 'lucide-react';
import { Student } from '../../types/admission';
import { FeeAssignment, FeeReceipt, PaymentRecord } from '../../types/finance';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';

interface StudentFeesViewProps {
  student: Student;
  feeAssignments: FeeAssignment[];
  payments: PaymentRecord[];
  receipts: FeeReceipt[];
  onNavigateToReceipts: () => void;
}

export function StudentFeesView({
  student,
  feeAssignments,
  payments,
  receipts,
  onNavigateToReceipts,
}: StudentFeesViewProps) {
  const [filterStatus, setFilterStatus] = useState<string>('All');

  // Summary Metrics
  const totalBilled = feeAssignments.reduce((acc, curr) => acc + (curr.amountDue || 0), 0);
  const totalPaid = feeAssignments.reduce((acc, curr) => acc + (curr.amountPaid || 0), 0);
  const totalWaived = feeAssignments.reduce((acc, curr) => acc + (curr.discountOrWaiver || 0), 0);
  const totalOutstanding = Math.max(0, totalBilled - totalPaid - totalWaived);

  // Filtered Assignments
  const filteredAssignments = feeAssignments.filter((a) => {
    if (filterStatus === 'All') return true;
    return a.status.toLowerCase() === filterStatus.toLowerCase();
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-xl p-6 border border-[#e2e8f0] shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-[#1e3a8a] text-white flex items-center justify-center text-xl font-bold shrink-0 shadow-xs">
              <DollarSign className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-bold text-[#1e293b]">Student Fee Account</h1>
                <Badge variant={totalOutstanding === 0 ? 'emerald' : 'amber'} size="sm">
                  {totalOutstanding === 0 ? 'Account Clear' : 'Dues Pending'}
                </Badge>
              </div>
              <p className="text-xs text-[#64748b] mt-1">
                Student: <strong className="text-[#334155]">{student.fullName}</strong> ({student.registrationNumber}) • {student.admissionClass} - Section {student.section}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              id="student-view-receipts-btn"
              variant="outline"
              size="sm"
              onClick={onNavigateToReceipts}
              leftIcon={<Receipt className="w-4 h-4 text-[#1e3a8a]" />}
            >
              Payment Receipts ({receipts.length})
            </Button>
          </div>
        </div>
      </div>

      {/* 4 Financial Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-[#64748b] block">Total Billed Fees</span>
          <span className="text-2xl font-bold text-[#1e293b] mt-1 block">
            ${totalBilled.toLocaleString()}
          </span>
          <span className="text-[11px] text-[#94a3b8] mt-1 block">
            Across {feeAssignments.length} assigned heads
          </span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-emerald-700 block">Total Amount Paid</span>
          <span className="text-2xl font-bold text-emerald-700 mt-1 block">
            ${totalPaid.toLocaleString()}
          </span>
          <span className="text-[11px] text-emerald-600 mt-1 block">
            {payments.length} verified transactions
          </span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-purple-700 block">Concession & Waivers</span>
          <span className="text-2xl font-bold text-purple-700 mt-1 block">
            ${totalWaived.toLocaleString()}
          </span>
          <span className="text-[11px] text-purple-600 mt-1 block">Institutional grants</span>
        </div>

        <div className="bg-white rounded-xl p-5 border border-[#e2e8f0] shadow-xs">
          <span className="text-xs font-semibold text-amber-700 block">Outstanding Balance</span>
          <span className="text-2xl font-black text-amber-700 mt-1 block">
            ${totalOutstanding.toLocaleString()}
          </span>
          <span className="text-[11px] text-amber-600 mt-1 block">
            {totalOutstanding === 0 ? 'Fully settled' : 'Payment required'}
          </span>
        </div>
      </div>

      {/* Fee Assignments Ledger Table */}
      <div className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs overflow-hidden">
        {/* Table Filter Controls */}
        <div className="p-4 sm:p-5 border-b border-[#e2e8f0] flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#f8fafc]">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#1e3a8a]" />
            <h2 className="text-sm font-bold text-[#1e293b]">Fee Structure Assignments</h2>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="py-1.5 px-3 text-xs bg-white border border-[#cbd5e1] rounded-lg text-[#1e293b] focus:outline-none focus:ring-2 focus:ring-[#1e3a8a]"
            >
              <option value="All">All Fee Statuses</option>
              <option value="Paid">Paid</option>
              <option value="Partially Paid">Partially Paid</option>
              <option value="Unpaid">Unpaid</option>
              <option value="Waived">Waived</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#1e293b]">
            <thead className="bg-[#f1f5f9] text-[#475569] uppercase font-semibold text-[11px] border-b border-[#e2e8f0]">
              <tr>
                <th className="px-5 py-3">Fee Head / Description</th>
                <th className="px-5 py-3">Session</th>
                <th className="px-5 py-3 text-right">Amount Due</th>
                <th className="px-5 py-3 text-right">Paid</th>
                <th className="px-5 py-3 text-right">Waiver</th>
                <th className="px-5 py-3 text-right">Balance</th>
                <th className="px-5 py-3">Due Date</th>
                <th className="px-5 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e2e8f0]">
              {filteredAssignments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-12 text-center text-[#94a3b8]">
                    No fee assignments found matching the selected status.
                  </td>
                </tr>
              ) : (
                filteredAssignments.map((assignment) => (
                  <tr key={assignment.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3.5">
                      <span className="font-semibold text-[#1e293b] block">
                        {assignment.feeTypeName}
                      </span>
                      {assignment.remarks && (
                        <span className="text-[10px] text-[#64748b] block mt-0.5">
                          {assignment.remarks}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b]">
                      {assignment.academicSession || '2026–2027'}
                    </td>
                    <td className="px-5 py-3.5 text-right font-medium text-[#1e293b]">
                      ${assignment.amountDue.toLocaleString()}
                    </td>
                    <td className="px-5 py-3.5 text-right text-emerald-700 font-medium">
                      ${assignment.amountPaid.toLocaleString()}
                    </td>
                    <td className="px-5 py-3.5 text-right text-purple-700">
                      {assignment.discountOrWaiver > 0 ? `$${assignment.discountOrWaiver.toLocaleString()}` : '—'}
                    </td>
                    <td className="px-5 py-3.5 text-right font-bold text-[#1e293b]">
                      ${(assignment.balance ?? assignment.balanceDue ?? 0).toLocaleString()}
                    </td>
                    <td className="px-5 py-3.5 text-[#64748b] font-mono">
                      {assignment.dueDate}
                    </td>
                    <td className="px-5 py-3.5">
                      <Badge
                        variant={
                          assignment.status === 'Paid'
                            ? 'emerald'
                            : assignment.status === 'Partially Paid'
                            ? 'amber'
                            : (assignment.status as string) === 'Waived'
                            ? 'purple'
                            : 'rose'
                        }
                        size="sm"
                      >
                        {assignment.status}
                      </Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Read-Only Notice Footer */}
        <div className="p-4 bg-[#f8fafc] border-t border-[#e2e8f0] flex items-center justify-between text-xs text-[#64748b]">
          <span className="flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5 text-[#94a3b8]" />
            Fee records are issued and managed centrally by the institutional Finance Office.
          </span>
        </div>
      </div>
    </div>
  );
}
