import { useState } from 'react';
import {
  Building2,
  CheckCircle2,
  Clock,
  Database,
  Hash,
  KeyRound,
  Layers,
  Lock,
  Save,
  Shield,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { SIX_PERMANENT_OFFICES } from '../config/permanentOffices';
import { INSTITUTE_INFO } from '../config/portals';

export function AdministrationSettingsSection() {
  const [academicYear, setAcademicYear] = useState('2026–2027');
  const [sessionTimeout, setSessionTimeout] = useState('60');
  const [passwordMinLength, setPasswordMinLength] = useState('8');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSavePolicy = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Institutional Administration Settings
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            System configuration, registration schemes, access controls, and security policies governed by the Administration Office.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Settings saved successfully</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Institutional Governance */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
            <Building2 className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
            <h2 className="text-base font-bold text-slate-900">Institutional Governance &amp; Profile</h2>
          </div>

          <div className="space-y-3.5 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Institution Legal Name</label>
              <input
                type="text"
                readOnly
                value={INSTITUTE_INFO.name}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Campus Code</label>
                <input
                  type="text"
                  readOnly
                  value="EIT-BOS"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Active Academic Year</label>
                <input
                  type="text"
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]"
                />
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Accredited Degrees &amp; Programmes</label>
              <p className="text-slate-500 leading-relaxed">
                Undergraduate Bachelor of Technology (B.Tech), Master of Technology (M.Tech), and Doctoral Research Programmes.
              </p>
            </div>
          </div>
        </div>

        {/* 2. Identifier Allocation Schemes */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
            <Hash className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
            <h2 className="text-base font-bold text-slate-900">Registration Number Allocation Schemes</h2>
          </div>

          <div className="space-y-3 text-xs">
            <p className="text-slate-500 leading-relaxed">
              Monotonically generated and guaranteed collision-free identifiers for institutional identity management.
            </p>

            <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80 space-y-1">
              <span className="font-bold text-[#1E3A8A] uppercase tracking-wider text-[11px]">
                Teaching Faculty Scheme
              </span>
              <div className="font-mono text-xs font-semibold text-blue-900">
                EIT-TCH-[DEPT]-[JOIN_YEAR]-[SEQ_001]
              </div>
              <p className="text-[11px] text-blue-800/80">Example: EIT-TCH-CSE-2026-001</p>
            </div>

            <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-200/80 space-y-1">
              <span className="font-bold text-purple-900 uppercase tracking-wider text-[11px]">
                Non-Teaching Staff Scheme
              </span>
              <div className="font-mono text-xs font-semibold text-purple-950">
                EIT-NTC-[DEPT]-[JOIN_YEAR]-[SEQ_001]
              </div>
              <p className="text-[11px] text-purple-800/80">Example: EIT-NTC-ADM-2026-001</p>
            </div>

            <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-1">
              <span className="font-bold text-emerald-900 uppercase tracking-wider text-[11px]">
                Enrolled Student Scheme
              </span>
              <div className="font-mono text-xs font-semibold text-emerald-950">
                EIT-STU-[YEAR]-[DEPT]-[SEQ_0001]
              </div>
              <p className="text-[11px] text-emerald-800/80">Example: EIT-STU-2026-CSE-0001</p>
            </div>
          </div>
        </div>

        {/* 3. Security, Authentication & Session Policies */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
            <Lock className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
            <h2 className="text-base font-bold text-slate-900">Security &amp; Authentication Policies</h2>
          </div>

          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Session Inactivity Timeout</label>
                <select
                  value={sessionTimeout}
                  onChange={(e) => setSessionTimeout(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]"
                >
                  <option value="30">30 Minutes</option>
                  <option value="60">60 Minutes (Standard)</option>
                  <option value="120">120 Minutes</option>
                  <option value="240">4 Hours</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Min Password Length</label>
                <select
                  value={passwordMinLength}
                  onChange={(e) => setPasswordMinLength(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-300 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]"
                >
                  <option value="8">8 Characters</option>
                  <option value="10">10 Characters</option>
                  <option value="12">12 Characters (Strong)</option>
                </select>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 font-semibold text-slate-800">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Separation of Duties (SoD) Enforcement: ACTIVE</span>
              </div>
              <p className="text-slate-500 leading-relaxed text-[11px]">
                Enforces institutional governance rules: financial adjusters cannot approve their own discounts; non-teaching employees cannot access unassigned offices; published grades cannot be modified without audit justification.
              </p>
            </div>

            <button
              type="button"
              onClick={handleSavePolicy}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#1E3A8A] hover:bg-[#162D6E] text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Policy Settings</span>
            </button>
          </div>
        </div>

        {/* 4. Core Permanent Offices Summary */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5">
              <Shield className="w-4 h-4 text-[#1E3A8A] stroke-[2.2]" />
              <h2 className="text-base font-bold text-slate-900">Six Permanent Institutional Offices</h2>
            </div>
            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Immutable Core
            </span>
          </div>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 text-xs">
            {SIX_PERMANENT_OFFICES.map((off) => (
              <div
                key={off.office_id}
                className="p-3 rounded-xl bg-slate-50/70 border border-slate-200/80 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-slate-900">{off.office_name}</div>
                  <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                    User: <span className="font-semibold text-slate-700">{off.canonical_username}</span> · ID: {off.office_id}
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-600 bg-white border border-slate-200 px-2 py-0.5 rounded">
                  <KeyRound className="w-3 h-3 text-slate-400" />
                  <span>Reserved</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
