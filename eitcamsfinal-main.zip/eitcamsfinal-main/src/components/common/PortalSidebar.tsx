import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

export interface PortalSidebarSubItem {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  badgeVariant?: 'blue' | 'emerald' | 'amber' | 'default';
}

export interface PortalSidebarItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  badgeVariant?: 'blue' | 'emerald' | 'amber' | 'default';
  subItems?: PortalSidebarSubItem[];
}

export interface PortalSidebarProps {
  items: PortalSidebarItem[];
  activeTab: string;
  onSelectTab: (id: string) => void;
  isOpenMobile?: boolean;
  idPrefix?: string;
  headerSlot?: React.ReactNode;
  footerSlot?: React.ReactNode;
}

export function PortalSidebar({
  items,
  activeTab,
  onSelectTab,
  isOpenMobile = false,
  idPrefix = 'nav',
  headerSlot,
  footerSlot,
}: PortalSidebarProps) {
  // Shared expanded-menu state: exactly ONE primary group can be expanded at any time
  const [expandedMenuId, setExpandedMenuId] = useState<string | null>(() => {
    const matchingGroup = items.find((item) =>
      item.subItems?.some((sub) => sub.id === activeTab)
    );
    return matchingGroup ? matchingGroup.id : null;
  });

  const prevActiveTabRef = useRef(activeTab);

  // On page refresh or when activeTab switches to a different submenu group, expand that group
  useEffect(() => {
    if (prevActiveTabRef.current !== activeTab) {
      prevActiveTabRef.current = activeTab;
      const matchingGroup = items.find((item) =>
        item.subItems?.some((sub) => sub.id === activeTab)
      );
      if (matchingGroup) {
        setExpandedMenuId(matchingGroup.id);
      }
    }
  }, [activeTab, items]);

  return (
    <aside
      className={`lg:w-64 shrink-0 ${
        isOpenMobile ? 'block' : 'hidden lg:block'
      }`}
    >
      <nav className="bg-white rounded-xl border border-[#e2e8f0] shadow-xs p-3 space-y-1 sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto">
        {headerSlot}
        {items.map((item) => {
          const Icon = item.icon;
          const hasSubItems = item.subItems && item.subItems.length > 0;

          // If item is expandable parent
          if (hasSubItems) {
            const isAnyChildActive = item.subItems!.some((sub) => sub.id === activeTab);
            const isOpen = expandedMenuId === item.id;

            return (
              <div key={item.id} className="space-y-1">
                <button
                  id={`${idPrefix}-${item.id}`}
                  type="button"
                  onClick={() =>
                    setExpandedMenuId((current) => (current === item.id ? null : item.id))
                  }
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isAnyChildActive
                      ? 'bg-slate-100 text-[#1e3a8a]'
                      : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
                  }`}
                  aria-expanded={isOpen}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isAnyChildActive ? 'text-[#1e3a8a]' : 'text-[#64748b]'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {item.badge !== undefined && (
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold ${
                          item.badgeVariant === 'emerald'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-[#475569]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                    {isOpen ? (
                      <ChevronDown className="w-4 h-4 text-[#64748b]" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-[#64748b]" />
                    )}
                  </div>
                </button>

                {isOpen && (
                  <div className="pl-3.5 space-y-0.5 border-l-2 border-slate-200 ml-4 my-1">
                    {item.subItems!.map((sub) => {
                      const SubIcon = sub.icon;
                      const isSubActive = activeTab === sub.id;

                      return (
                        <button
                          key={sub.id}
                          id={`${idPrefix}-${sub.id}`}
                          type="button"
                          onClick={() => onSelectTab(sub.id)}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all cursor-pointer ${
                            isSubActive
                              ? 'bg-[#eff6ff] text-[#1e3a8a] font-bold border-l-2 border-[#1e3a8a] shadow-2xs'
                              : 'text-[#64748b] hover:bg-slate-50 hover:text-[#1e293b] font-medium'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            {SubIcon && (
                              <SubIcon
                                className={`w-3.5 h-3.5 shrink-0 ${
                                  isSubActive ? 'text-[#1e3a8a]' : 'text-[#94a3b8]'
                                }`}
                              />
                            )}
                            <span className="truncate">{sub.label}</span>
                          </div>

                          {sub.badge !== undefined && (
                            <span
                              className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full shrink-0 font-semibold ${
                                isSubActive
                                  ? 'bg-blue-100 text-[#1e3a8a]'
                                  : sub.badgeVariant === 'emerald'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-slate-100 text-[#475569]'
                              }`}
                            >
                              {sub.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          }

          // Direct navigation item (no subItems)
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`${idPrefix}-${item.id}`}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#1e3a8a] text-white shadow-xs'
                  : 'text-[#475569] hover:bg-slate-50 hover:text-[#1e293b]'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-white' : 'text-[#64748b]'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full shrink-0 font-semibold ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : item.badgeVariant === 'emerald'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-slate-100 text-[#475569]'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
        {footerSlot}
      </nav>
    </aside>
  );
}
