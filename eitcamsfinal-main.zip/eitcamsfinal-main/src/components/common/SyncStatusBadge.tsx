import React from 'react';

export function SyncStatusBadge({ className = '' }: { className?: string }) {
  // In Phase 10 / pre-Phase 11, Google Sheets sync is deferred.
  return null;
}
