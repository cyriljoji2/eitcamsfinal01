import { devDataAdapter } from './devDataAdapter';
import {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
  StudentSubjectMark,
} from '../types/studentPortalTypes';
import {
  UniversityHallTicket,
  UniversityEligibilityRecord,
} from '../types/coe';
import {
  ExamAttendanceStatus,
  ExamLifecycleStatus,
  ExamScheduleRecord,
  ExamSessionRecord,
  ExamResultRecord,
  StudentEligibilityDetail,
} from '../types/database';

// In-memory registry for administrative eligibility overrides across workflows
const eligibilityOverrides = new Map<string, { isEligible: boolean; reason?: string }>();

export const examinationRepository = {
  // Existing backward-compatible methods for Student Portal & tests
  async getExaminations(): Promise<Examination[]> {
    const sessions = await devDataAdapter.coe.getSessions();
    return sessions.map((s) => ({
      id: s.session_id,
      session_id: s.session_id,
      name: s.session_name,
      session: s.academic_year,
      academicSession: s.academic_year,
      status: ((s.status as any) === 'COMPLETED'
        ? 'Published'
        : (s.status as any) === 'IN_PROGRESS' || (s.status as any) === 'ONGOING'
        ? 'Active'
        : (s.status as any) === 'MARKS_ENTRY_OPEN'
        ? 'Mark Entry Open'
        : s.status) as any,
      startDate: s.start_date,
      endDate: s.end_date,
      termType: (s as any).term_type || `Semester ${s.semester}`,
      instructions: (s as any).instructions ? [(s as any).instructions] : undefined,
    }));
  },

  async getAllMarks(): Promise<any[]> {
    return await this.getResults();
  },

  async getSchedules(): Promise<ExamSubjectSchedule[]> {
    const schs = await devDataAdapter.coe.getSchedules();
    return schs.map((s) => ({
      id: s.schedule_id,
      schedule_id: s.schedule_id,
      examinationId: s.session_id,
      courseCode: s.course_code,
      courseName: s.course_title || 'Institutional Assessment',
      examDate: s.exam_date,
      startTime: s.start_time,
      endTime: s.end_time,
      room: s.room || 'Main Hall',
      roomVenue: s.room || 'Main Hall',
      examType: s.exam_type,
      maxMarks: s.max_marks || 100,
      passMarks: s.passing_marks || 40,
      className: s.programme_code || 'B.Tech',
      section: s.section || 'A',
      subjectName: s.course_title,
      subjectCode: s.course_code,
      assignedFacultyName: (s as any).assigned_evaluator_name || 'Assigned Instructor',
      marksEntryStatus: s.marks_entry_open
        ? 'OPEN'
        : s.status === ExamLifecycleStatus.REOPENED
        ? 'REOPENED'
        : 'LOCKED',
      markEntryStatus: s.marks_entry_open ? 'Open' : 'Closed',
      isMarksVerified: s.status === ExamLifecycleStatus.APPROVED || s.status === ExamLifecycleStatus.PUBLISHED,
      markSubmissionStatus: (s.status === ExamLifecycleStatus.FACULTY_SUBMITTED
        ? 'Submitted'
        : s.status === ExamLifecycleStatus.APPROVED || s.status === ExamLifecycleStatus.PUBLISHED
        ? 'Verified'
        : s.status === ExamLifecycleStatus.REOPENED
        ? 'Returned'
        : 'Pending') as any,
    }));
  },

  async getHallTickets(): Promise<HallTicket[]> {
    const students = await devDataAdapter.students.getAll();
    const schs = await devDataAdapter.coe.getSchedules();

    return students.map((stu) => ({
      id: `HT-${stu.registration_number}`,
      hallTicketNumber: `HT-${stu.registration_number.split('-').pop() || '101'}-2026`,
      examinationId: schs[0]?.session_id || 'EXAM-2026-ENDSEM',
      examinationName: 'End Semester Theory & Practical Examinations — Nov/Dec 2026',
      academicSession: '2026–2027',
      studentRegistrationNumber: stu.registration_number,
      studentName: `${stu.first_name} ${stu.last_name}`,
      className: stu.program_name,
      section: stu.section,
      dateOfBirth: stu.date_of_birth,
      schoolName: 'ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)',
      schoolAddress: 'Campus Avenue, Technology City, Chennai - 600127',
      schedules: schs.map((s) => ({
        courseCode: s.course_code,
        courseName: s.course_title || 'Institutional Assessment',
        examDate: s.exam_date,
        timeSlot: `${s.start_time} - ${s.end_time}`,
        room: s.room || 'Main Hall 1',
      })),
    }));
  },

  async getResults(): Promise<StudentExamResult[]> {
    const adapterAny = devDataAdapter as any;
    const state = typeof adapterAny.getState === 'function' ? adapterAny.getState() : null;
    const students = state?.students || [];
    const coeResults = state?.examResults || [];

    return coeResults.map((r: any) => {
      const stu = students.find((s: any) => s.student_id === r.student_id || s.registration_number === r.registration_number);
      const isPass = r.result_status === 'PASS';
      return {
        id: r.result_id,
        examinationId: r.schedule_id || 'EXAM-2026',
        examinationName: 'End Semester Examination',
        studentId: r.student_id,
        studentRegistrationNumber: r.registration_number,
        studentName: stu ? `${stu.first_name} ${stu.last_name}` : 'Student',
        className: stu?.program_name || 'B.Tech',
        section: stu?.section || 'A',
        gpa: r.gpa || (isPass ? 8.2 : 0.0),
        cgpa: r.cgpa || 8.1,
        totalMarks: r.total_marks || (r.internal_marks || 0) + (r.external_marks || 0),
        maxMarks: r.max_marks || 100,
        percentage: r.percentage || 78,
        status: (isPass ? 'Passed' : 'Failed') as any,
        publishedDate: r.published_at || new Date().toISOString(),
        subjectMarks: [
          {
            subjectCode: r.course_code || 'CS201',
            subjectName: r.course_title || 'Data Structures',
            theoryMarks: r.external_marks || 55,
            practicalMarks: r.internal_marks || 32,
            totalMarks: (r.internal_marks || 0) + (r.external_marks || 0),
            maxMarks: 100,
            grade: r.grade || 'A',
            gradePoint: r.grade_point || 8.0,
            status: isPass ? 'Pass' : 'Fail',
          },
        ],
      };
    });
  },

  async getStudentResult(
    studentRegistrationNumber: string,
    examinationId: string
  ): Promise<StudentExamResult | null> {
    const all = await this.getResults();
    return (
      all.find(
        (r) =>
          (r.studentRegistrationNumber === studentRegistrationNumber || r.studentId === studentRegistrationNumber) &&
          (r.examinationId === examinationId || examinationId === 'all')
      ) || null
    );
  },

  async getStudentHallTicket(
    studentRegistrationNumber: string,
    examinationId: string
  ): Promise<HallTicket | null> {
    const all = await this.getHallTickets();
    return (
      all.find(
        (t) =>
          (t.studentRegistrationNumber === studentRegistrationNumber || t.id.includes(studentRegistrationNumber)) &&
          (t.examinationId === examinationId || examinationId === 'all')
      ) || null
    );
  },

  async getStudentExaminations(studentRegistrationNumber: string): Promise<Examination[]> {
    return await this.getExaminations();
  },

  // -------------------------------------------------------------------------
  // NEW UNIVERSITY COE REDESIGN REPOSITORY API
  // -------------------------------------------------------------------------

  async getAuditLogs(): Promise<any[]> {
    const logs = await devDataAdapter.audit.getRecent();
    return logs
      .filter((l) => l.action.startsWith('EXAM_') || l.target_worksheet?.includes('Exam'))
      .map((l) => ({
        id: l.log_id,
        action: l.action,
        details: l.description,
        performedBy: l.actor_id,
        performedByName: l.actor_id === 'coeoffice' ? 'COE Officer' : l.actor_id,
        timestamp: l.timestamp,
        examinationId: l.target_record_id,
      }));
  },

  async getEligibilities(sessionId?: string): Promise<any[]> {
    const schedules = await devDataAdapter.coe.getSchedules();
    const students = await devDataAdapter.students.getAll();
    const targetSchedule = sessionId
      ? schedules.find((s) => s.session_id === sessionId) || schedules[0]
      : schedules[0];

    const currentSessionId = sessionId || targetSchedule?.session_id || 'EXAM-2026';

    if (targetSchedule) {
      const details = await devDataAdapter.coe.checkEligibility(targetSchedule.schedule_id);

      return details.map((d) => {
        const stu = students.find((s) => s.student_id === d.student_id);
        const override =
          eligibilityOverrides.get(`${currentSessionId}-${d.registration_number}`) ||
          eligibilityOverrides.get(`${targetSchedule.session_id}-${d.registration_number}`);

        const isEligible = override !== undefined ? override.isEligible : d.is_eligible;
        const ineligibilityReason =
          override !== undefined
            ? override.reason || ''
            : d.ineligibility_reasons?.join('; ') || '';

        return {
          id: `ELIG-${d.student_id}-${currentSessionId}`,
          studentId: d.student_id,
          studentRegistrationNumber: d.registration_number,
          studentName: d.name,
          className: stu?.program_name || 'B.Tech CSE',
          section: d.section || 'A',
          examinationId: currentSessionId,
          courseCode: d.course_code,
          courseTitle: targetSchedule.course_title,
          attendancePercentage: d.attendance_percentage,
          feeClearance: d.fee_clearance,
          isEligible,
          ineligibilityReasons: ineligibilityReason ? [ineligibilityReason] : [],
          ineligibilityReason,
        };
      });
    }

    // Default student synthesis when no schedule exists for exam
    return students.map((s) => {
      const override = eligibilityOverrides.get(`${currentSessionId}-${s.registration_number}`);
      const isEligible = override !== undefined ? override.isEligible : true;
      const ineligibilityReason = override !== undefined ? override.reason || '' : '';

      return {
        id: `ELIG-${s.student_id}-${currentSessionId}`,
        studentId: s.student_id,
        studentRegistrationNumber: s.registration_number,
        studentName: `${s.first_name} ${s.last_name}`,
        className: s.program_name || 'B.Tech CSE',
        section: s.section || 'A',
        examinationId: currentSessionId,
        courseCode: 'CS201',
        courseTitle: 'University Core Examination',
        attendancePercentage: 88,
        feeClearance: true,
        isEligible,
        ineligibilityReasons: ineligibilityReason ? [ineligibilityReason] : [],
        ineligibilityReason,
      };
    });
  },

  async updateStudentEligibility(
    examId: string,
    studentRegNo: string,
    isEligible: boolean,
    reason?: string,
    actorName?: string
  ): Promise<void> {
    const students = await devDataAdapter.students.getAll();
    const stu = students.find((s) => s.registration_number === studentRegNo);
    if (!stu) throw new Error(`Student ${studentRegNo} not found.`);

    eligibilityOverrides.set(`${examId}-${studentRegNo}`, { isEligible, reason });

    await devDataAdapter.audit.log({
      actor_id: actorName || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_ELIGIBILITY_OVERRIDE' as any,
      target_worksheet: 'ExamEligibility',
      target_record_id: `${examId}-${studentRegNo}`,
      description: `Eligibility overridden for ${stu.first_name} ${stu.last_name} (${studentRegNo}) in ${examId} to ${
        isEligible ? 'ELIGIBLE' : 'INELIGIBLE'
      }. Justification: ${reason || 'Administrative Review'}`,
    });
  },

  async bulkSetEligibility(
    examId: string,
    isEligible: boolean,
    programmeCode?: string,
    actorName?: string
  ): Promise<any[]> {
    const list = await this.getEligibilities(examId);
    for (const item of list) {
      eligibilityOverrides.set(`${examId}-${item.studentRegistrationNumber}`, {
        isEligible,
        reason: isEligible ? 'Bulk approval' : 'Administrative block',
      });
    }

    await devDataAdapter.audit.log({
      actor_id: actorName || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_ELIGIBILITY_BULK_APPROVE' as any,
      target_worksheet: 'ExamEligibility',
      target_record_id: examId,
      description: `Bulk eligibility set to ${isEligible ? 'ELIGIBLE' : 'INELIGIBLE'} for examination ${examId}${
        programmeCode ? ` in programme ${programmeCode}` : ''
      }.`,
    });

    return await this.getEligibilities(examId);
  },

  async syncEligibilityFromAdmission(examId: string, actorId?: string): Promise<any[]> {
    const students = await devDataAdapter.students.getAll();
    await devDataAdapter.audit.log({
      actor_id: actorId || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_ELIGIBILITY_SYNC' as any,
      target_worksheet: 'ExamEligibility',
      target_record_id: examId,
      description: `Synchronized student eligibility registry for examination ${examId}. Scanned ${students.length} academic enrolments.`,
    });
    return await this.getEligibilities(examId);
  },

  async createExamination(data: any, actorName?: string): Promise<any> {
    const created = await devDataAdapter.coe.createSession({
      session_name: data.name,
      academic_year: data.academicSession || '2026-2027',
      start_date: data.startDate,
      end_date: data.endDate,
      status: (data.status as any) || 'SCHEDULED',
      term_type: data.termType || 'Semester 3 Regular Examination',
      semester: data.semester || 3,
      instructions: data.instructions,
    } as any);

    if (data.id) {
      created.session_id = data.id;
    }

    return {
      id: created.session_id,
      session_id: created.session_id,
      name: created.session_name,
      session: created.academic_year,
      academicSession: created.academic_year,
      status: created.status,
      startDate: created.start_date,
      endDate: created.end_date,
      termType: (created as any).term_type || data.termType,
      semester: created.semester,
      instructions: (created as any).instructions ? [(created as any).instructions] : undefined,
    };
  },

  async updateExamination(examId: string, updates: any, actorName?: string): Promise<any> {
    const sessions = await devDataAdapter.coe.getSessions();
    const sess = sessions.find((s) => s.session_id === examId || (s as any).id === examId);
    if (!sess) throw new Error(`Examination session ${examId} not found.`);

    Object.assign(sess, {
      session_name: updates.name || sess.session_name,
      academic_year: updates.academicSession || sess.academic_year,
      start_date: updates.startDate || sess.start_date,
      end_date: updates.endDate || sess.end_date,
      status: updates.status || sess.status,
      term_type: updates.termType || (sess as any).term_type,
      instructions: updates.instructions || (sess as any).instructions,
    });

    await devDataAdapter.audit.log({
      actor_id: actorName || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_SESSION_UPDATE' as any,
      target_worksheet: 'ExamSessions',
      target_record_id: examId,
      description: `Updated examination session '${sess.session_name}' (${examId}).`,
    });

    return {
      id: sess.session_id,
      session_id: sess.session_id,
      name: sess.session_name,
      status: sess.status,
      termType: (sess as any).term_type || updates.termType,
      startDate: sess.start_date,
      endDate: sess.end_date,
      academicSession: sess.academic_year,
    };
  },

  async createSchedule(data: any, actorName?: string): Promise<any> {
    const created = await devDataAdapter.coe.scheduleExam(
      {
        session_id: data.examinationId,
        exam_name: data.examName || data.subjectName || data.courseName || 'Course Assessment',
        exam_type: data.examType || 'END_SEMESTER',
        course_code: data.courseCode || data.subjectCode,
        course_title: data.examName || data.subjectName || data.courseName,
        programme_code: data.programmeCode || data.className || 'BTECH-CSE',
        department: data.department || 'CSE',
        semester: Number(data.semester || 3),
        section: data.section || 'A',
        exam_date: data.examDate,
        start_time: data.startTime,
        end_time: data.endTime,
        duration_minutes: Number(data.durationMinutes || 180),
        room: data.room || data.roomVenue || 'Hall 101',
        max_marks: Number(data.maxMarks || 100),
        passing_marks: Number(data.passingMarks || data.passMarks || 40),
        notes: data.notes || '',
      },
      { userId: actorName || 'coeoffice', role: 'OFFICE_ADMIN' }
    );

    if (data.id) {
      created.schedule_id = data.id;
    }

    return {
      id: created.schedule_id,
      schedule_id: created.schedule_id,
      examinationId: created.session_id,
      courseCode: created.course_code,
      courseName: created.course_title,
      room: created.room,
      maxMarks: created.max_marks,
      passMarks: created.passing_marks,
      marksEntryStatus: 'LOCKED',
    };
  },

  async updateSchedule(scheduleId: string, data: any, actorName?: string): Promise<any> {
    const updated = await devDataAdapter.coe.updateSchedule(
      scheduleId,
      {
        exam_name: data.subjectName || data.courseName || data.examName,
        exam_date: data.examDate,
        start_time: data.startTime,
        end_time: data.endTime,
        room: data.room || data.roomVenue,
        max_marks: data.maxMarks ? Number(data.maxMarks) : undefined,
        passing_marks: data.passingMarks || data.passMarks ? Number(data.passingMarks || data.passMarks) : undefined,
      },
      { userId: actorName || 'coeoffice', role: 'OFFICE_ADMIN' }
    );

    return {
      id: updated.schedule_id,
      schedule_id: updated.schedule_id,
      room: updated.room,
      maxMarks: updated.max_marks,
      passMarks: updated.passing_marks,
    };
  },

  async deleteSchedule(scheduleId: string, actorName?: string): Promise<void> {
    await devDataAdapter.coe.deleteSchedule(scheduleId, {
      userId: actorName || 'coeoffice',
      role: 'OFFICE_ADMIN',
    });
  },

  async openMarkEntry(scheduleId: string, actorId?: string): Promise<any> {
    const res = await devDataAdapter.coe.setMarksEntryWindow(scheduleId, true, {
      userId: actorId || 'coeoffice',
      role: 'OFFICE_ADMIN',
    });
    return {
      ...res,
      id: res.schedule_id,
      marksEntryStatus: 'OPEN',
    };
  },

  async closeMarkEntry(scheduleId: string, actorId?: string): Promise<any> {
    const res = await devDataAdapter.coe.setMarksEntryWindow(scheduleId, false, {
      userId: actorId || 'coeoffice',
      role: 'OFFICE_ADMIN',
    });
    return {
      ...res,
      id: res.schedule_id,
      marksEntryStatus: 'CLOSED',
    };
  },

  async reopenMarkEntry(scheduleId: string, reason: string, actorName?: string): Promise<any> {
    if (!reason || !reason.trim()) {
      throw new Error('Validation Error: A justification reason is strictly required to reopen marks entry window.');
    }
    const res = await devDataAdapter.coe.reopenMarksEntry(scheduleId, reason, {
      userId: actorName || 'coeoffice',
      role: 'OFFICE_ADMIN',
    });
    return {
      ...res,
      id: res.schedule_id,
      marksEntryStatus: 'REOPENED',
    };
  },

  async bulkOpenMarkEntry(examId: string, actorId?: string): Promise<void> {
    const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
    for (const s of schedules) {
      await devDataAdapter.coe.setMarksEntryWindow(s.schedule_id, true, {
        userId: actorId || 'coeoffice',
        role: 'OFFICE_ADMIN',
      });
    }
  },

  async bulkCloseMarkEntry(examId: string, actorId?: string): Promise<void> {
    const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
    for (const s of schedules) {
      await devDataAdapter.coe.setMarksEntryWindow(s.schedule_id, false, {
        userId: actorId || 'coeoffice',
        role: 'OFFICE_ADMIN',
      });
    }
  },

  async verifyMarks(scheduleId: string, notes?: string, verifiedBy?: string): Promise<any> {
    const sch = await devDataAdapter.coe.getScheduleById(scheduleId);
    if (sch) {
      sch.status = ExamLifecycleStatus.APPROVED;
    }
    await devDataAdapter.audit.log({
      actor_id: verifiedBy || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_MARKS_VERIFY' as any,
      target_worksheet: 'ExamSchedules',
      target_record_id: scheduleId,
      description: `COE Auditor verified marks for ${scheduleId}. Notes: ${notes || 'Verified'}`,
    });
    return {
      scheduleId,
      isMarksVerified: true,
      status: ExamLifecycleStatus.APPROVED,
    };
  },

  async returnMarksForCorrection(scheduleId: string, reason: string, returnedBy?: string): Promise<any> {
    if (!reason || !reason.trim()) {
      throw new Error('Validation Error: Mandatory correction notes are required when returning marks to faculty.');
    }
    const res = await devDataAdapter.coe.rejectMarksForCorrection(scheduleId, reason, {
      userId: returnedBy || 'coeoffice',
      role: 'OFFICE_ADMIN',
    });
    return {
      ...res,
      id: res.schedule_id,
      marksEntryStatus: 'OPEN',
    };
  },

  async calculateResultsForExam(examId: string, actorName?: string): Promise<any[]> {
    const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
    const students = await devDataAdapter.students.getAll();
    const resultsCalculated = [];

    for (const sch of schedules) {
      const marks = await devDataAdapter.coe.getMarks(sch.schedule_id);
      for (const m of marks) {
        resultsCalculated.push(m);
      }
    }

    await devDataAdapter.audit.log({
      actor_id: actorName || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_RESULT_CALCULATE' as any,
      target_worksheet: 'ExamResults',
      target_record_id: examId,
      description: `Calculated university grade points and GPA for examination ${examId} (${resultsCalculated.length || students.length} result records).`,
    });

    return resultsCalculated.length > 0 ? resultsCalculated : students;
  },

  async publishResults(examId: string, publishedBy?: string): Promise<any[]> {
    const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
    const students = await devDataAdapter.students.getAll();
    const published = [];

    for (const sch of schedules) {
      try {
        const res = await devDataAdapter.coe.publishResults(sch.schedule_id, {
          userId: publishedBy || 'coeoffice',
          role: 'OFFICE_ADMIN',
        });
        published.push(...((res as any).results || [res]));
      } catch (err) {
        console.warn(`Could not publish schedule ${sch.schedule_id}:`, err);
      }
    }

    const sessions = await devDataAdapter.coe.getSessions();
    const s = sessions.find((x) => x.session_id === examId || (x as any).id === examId);
    if (s) {
      s.status = 'RESULTS_PUBLISHED' as any;
    }

    await devDataAdapter.audit.log({
      actor_id: publishedBy || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_RESULT_PUBLISH' as any,
      target_worksheet: 'ExamSessions',
      target_record_id: examId,
      description: `Officially published examination results for ${examId} to Student Portal.`,
    });

    return published.length > 0 ? published : students;
  },

  async generateHallTicket(examId: string, regNo: string, actorName?: string): Promise<HallTicket> {
    const students = await devDataAdapter.students.getAll();
    const stu = students.find((s) => s.registration_number === regNo);
    if (!stu) throw new Error(`Student with registration number '${regNo}' was not found.`);

    // 1. Check administrative override or debarment
    const override = eligibilityOverrides.get(`${examId}-${regNo}`);
    if (override !== undefined && !override.isEligible) {
      throw new Error(
        `Cannot generate Hall Ticket: Student '${regNo}' fails examination eligibility requirements (${
          override.reason || 'Debarred by COE Office'
        }).`
      );
    }

    // 2. Check active schedule eligibility if not explicitly overridden
    if (override === undefined) {
      const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
      const activeSchedule = schedules[0];
      if (activeSchedule) {
        const eligList = await devDataAdapter.coe.checkEligibility(activeSchedule.schedule_id);
        const studentElig = eligList.find((e) => e.registration_number === regNo);
        if (studentElig && !studentElig.is_eligible) {
          throw new Error(
            `Cannot generate Hall Ticket: Student '${regNo}' fails examination eligibility requirements (${studentElig.ineligibility_reasons.join(
              '; '
            )}).`
          );
        }
      }
    }

    const schedules = await devDataAdapter.coe.getSchedules({ session_id: examId });
    const sessions = await devDataAdapter.coe.getSessions();
    const session = sessions.find((s) => s.session_id === examId) || sessions[0];

    const ticket: HallTicket = {
      id: `HT-${regNo}-${examId}`,
      hallTicketNumber: `HT-EIT-${regNo.split('-').pop() || '101'}-2026`,
      examinationId: examId,
      examinationName: session?.session_name || 'End Semester Examinations — Autumn 2026',
      academicSession: session?.academic_year || '2026–2027',
      studentRegistrationNumber: stu.registration_number,
      studentName: `${stu.first_name} ${stu.last_name}`,
      className: stu.program_name,
      section: stu.section,
      dateOfBirth: stu.date_of_birth,
      schoolName: 'ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)',
      schoolAddress: 'Campus Avenue, Technology City, Chennai - 600127',
      schedules: schedules.map((s) => ({
        courseCode: s.course_code,
        courseName: s.course_title,
        subjectName: s.course_title,
        examDate: s.exam_date,
        timeSlot: `${s.start_time} - ${s.end_time}`,
        room: s.room,
      })),
      status: 'ISSUED',
      generatedAt: new Date().toISOString(),
    };

    await devDataAdapter.audit.log({
      actor_id: actorName || 'coeoffice',
      actor_role: 'OFFICE_ADMIN',
      action: 'EXAM_HALL_TICKET_GENERATE' as any,
      target_worksheet: 'HallTickets',
      target_record_id: ticket.hallTicketNumber,
      description: `Generated official university Hall Ticket for ${stu.first_name} ${stu.last_name} (${regNo}).`,
    });

    return ticket;
  },

  async generateClassHallTickets(examId: string, className: string, actorName?: string): Promise<HallTicket[]> {
    const students = await devDataAdapter.students.getAll();
    const matching = students.filter(
      (s) =>
        s.program_name.toLowerCase().includes(className.toLowerCase()) ||
        s.department.toLowerCase() === className.toLowerCase() ||
        s.section?.toLowerCase() === className.toLowerCase()
    );

    const generated: HallTicket[] = [];
    for (const stu of matching) {
      try {
        const t = await this.generateHallTicket(examId, stu.registration_number, actorName);
        generated.push(t);
      } catch {
        // Skip ineligible students safely without failing entire cohort
      }
    }
    return generated;
  },

  async generateAllHallTicketsForExam(examId: string, actorName?: string): Promise<HallTicket[]> {
    const students = await devDataAdapter.students.getAll();
    const generated: HallTicket[] = [];
    for (const stu of students) {
      try {
        const t = await this.generateHallTicket(examId, stu.registration_number, actorName);
        generated.push(t);
      } catch {
        // Skip ineligible students
      }
    }
    return generated;
  },
};
