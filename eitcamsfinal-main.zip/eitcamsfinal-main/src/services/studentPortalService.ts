/**
 * Student Portal Service & Integration Bridge
 * Connects the reference Student Portal views to EIT CAMS authoritative data adapter.
 * Enforces strict user session authorization and identity isolation.
 */

import { IEitDataAdapter } from './dataAdapter';
import {
  StudentRecord,
  ParentRecord,
  AttendanceRecord,
  ExamResultRecord,
  ExamScheduleRecord,
  FeeInvoiceRecord,
  PaymentRecord,
  StudentFeeStatement,
  StudentHostelDetails,
  CourseEnrolmentRecord,
  TimetableSlotRecord,
  EmployeeRecord,
  FacultyCourseAssignmentRecord,
  CourseRecord,
  PaymentMethod,
  PaymentStatus,
  StudentStatus,
} from '../types/database';
import {
  Student,
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  FacultyAssignment,
  Employee,
  ProctorAssignment,
  ProctorMessage,
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
  StudentSubjectMark,
  FeeAssignment,
  FeeReceipt,
  Hostel,
  HostelAllotment,
  LeaveOutingRequest,
  convertNumberToWords,
} from '../types/studentPortalTypes';

export function adaptStudentRecordToStudent(
  rec: StudentRecord,
  parent?: ParentRecord | null
): Student {
  return {
    id: rec.student_id,
    fullName: `${rec.first_name} ${rec.last_name}`,
    registrationNumber: rec.registration_number,
    admissionClass: rec.program_name,
    section: rec.section,
    admissionDate: `${rec.admission_year}-08-01`,
    admissionType: 'Regular (Merit)',
    admissionStatus: 'Admitted',
    academicSession: '2026–2027',
    accountStatus:
      rec.enrollment_status === StudentStatus.ENROLLED
        ? 'active'
        : 'inactive',
    email: rec.institutional_email,
    mobile: rec.personal_phone,
    emergencyContact: parent?.primary_phone || rec.personal_phone,
    dateOfBirth: rec.date_of_birth,
    gender: rec.gender,
    bloodGroup: 'O+ (Institutional Record)',
    category: 'General / Merit',
    nationality: 'Indian',
    presentAddress: parent?.residential_address || 'EIT Campus Hostel Block, Chennai, Tamil Nadu',
    permanentAddress:
      parent?.residential_address || 'Permanent Address on File with Admissions Office',
    fatherName: parent ? `${parent.first_name} ${parent.last_name}` : 'Parent/Guardian on File',
    fatherPhone: parent?.primary_phone || 'N/A',
    motherName: 'Mother on File',
    guardianName: parent ? `${parent.first_name} ${parent.last_name}` : 'Guardian on File',
    currentSemester: `Semester ${rec.current_semester}`,
    program: rec.program_name,
    batch: `${rec.admission_year}–${rec.admission_year + 4}`,
    rollNumber: rec.registration_number.split('-').pop() || '001',
    username: rec.registration_number,
    temporaryPassword: 'Password123!',
    isTemporaryPassword: false,
    passwordChangedAt: '2026-08-01T09:00:00Z',
    documents: [],
  };
}

let hostelLeaveRequests: LeaveOutingRequest[] = [
  {
    id: 'REQ-LEAVE-2026-001',
    studentId: 'STU-001',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    studentName: 'Arjun Kumar',
    studentClass: 'B.Tech Computer Science & Engineering',
    studentSection: 'A',
    program: 'B.Tech Computer Science & Engineering',
    batch: '2026',
    hostelAllotmentId: 'ALT-2026-001',
    hostelId: 'HST-001',
    hostelName: 'Nilgiri Men’s Residence Hall',
    blockId: 'BLK-001',
    blockName: 'Block A - Aryabhata Wing',
    floorName: 'Ground Floor',
    roomNumber: '101',
    bedNumber: 'A',
    requestType: 'leave',
    requestNumber: 'REQ-LEAVE-2026-001',
    fromDate: '2026-11-06',
    fromTime: '09:00 AM',
    toDate: '2026-11-09',
    toTime: '06:00 PM',
    reasonCategory: 'academic' as any,
    reason: 'Attending IEEE National Robotics Conference at Bengaluru',
    purpose: 'Attending IEEE National Robotics Conference at Bengaluru',
    destination: 'Bengaluru, Karnataka',
    destinationAddress: 'Bengaluru, Karnataka',
    contactNumber: '+91 98401 11223',
    emergencyContact: '+91 98401 99887',
    proctorName: 'Dr. Ramesh Sundaram',
    proctorRemarks: 'Recommended. Legitimate academic competition with confirmed participation registration.',
    proctorActionDate: '2026-11-04T08:30:00Z',
    approvalStatus: 'PENDING_HOSTEL',
    status: 'PENDING_HOSTEL',
    slipNumber: 'SLIP-EIT-2026-48291',
    createdAt: '2026-11-04T08:00:00Z',
  },
  {
    id: 'REQ-OUTING-2026-002',
    studentId: 'STU-002',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
    studentName: 'Rohan Verma',
    studentClass: 'B.Tech Computer Science & Engineering',
    studentSection: 'A',
    program: 'B.Tech Computer Science & Engineering',
    batch: '2026',
    hostelAllotmentId: 'ALT-2026-002',
    hostelId: 'HST-001',
    hostelName: 'Nilgiri Men’s Residence Hall',
    blockId: 'BLK-001',
    blockName: 'Block A - Aryabhata Wing',
    floorName: 'First Floor',
    roomNumber: '201',
    bedNumber: 'A',
    requestType: 'outing',
    requestNumber: 'REQ-OUTING-2026-002',
    fromDate: '2026-11-05',
    fromTime: '04:00 PM',
    toDate: '2026-11-05',
    toTime: '08:30 PM',
    reasonCategory: 'medical' as any,
    reason: 'Medical consultation and dental follow-up at City Hospital',
    purpose: 'Medical consultation and dental follow-up at City Hospital',
    destination: 'City Specialty Clinic, North Zone',
    destinationAddress: 'City Specialty Clinic, North Zone',
    contactNumber: '+91 98401 22334',
    emergencyContact: '+91 98401 88776',
    proctorName: 'Dr. Arvind Sharma',
    proctorRemarks: 'Approved medical appointment slip verified.',
    proctorActionDate: '2026-11-04T07:45:00Z',
    approvalStatus: 'APPROVED',
    status: 'APPROVED',
    hostelActionBy: 'Hostel Administration Office',
    hostelActionDate: '2026-11-04T08:15:00Z',
    hostelRemarks: 'Gate clearance authorized. Must report back by 08:30 PM.',
    slipNumber: 'SLIP-EIT-2026-19283',
    createdAt: '2026-11-04T07:30:00Z',
  },
];
let proctorMessagesStore: ProctorMessage[] = [];

export interface CourseWithdrawalRequestRecord {
  requestId: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName: string;
  enrolmentId: string;
  courseCode: string;
  courseTitle: string;
  credits: number;
  semester: string;
  reason: string;
  status: 'PENDING_ADVISOR_APPROVAL' | 'APPROVED' | 'REJECTED' | 'WITHDRAWN';
  submittedAt: string;
  reviewerNotes?: string;
}

let courseWithdrawalRequestsStore: CourseWithdrawalRequestRecord[] = [];

export const studentPortalService = {
  // Hostel Leave Requests
  getLeaveRequests(studentIdOrReg?: string): LeaveOutingRequest[] {
    if (!studentIdOrReg || !studentIdOrReg.trim() || studentIdOrReg === 'ALL') {
      return [...hostelLeaveRequests];
    }
    const clean = studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return hostelLeaveRequests.filter(
      (r) =>
        (r.studentId && r.studentId.toLowerCase() === studentIdOrReg.toLowerCase()) ||
        (r.studentRegistrationNumber &&
          r.studentRegistrationNumber.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === clean)
    );
  },

  submitLeaveRequest(
    data: Omit<LeaveOutingRequest, 'id' | 'approvalStatus' | 'createdAt'>
  ): LeaveOutingRequest {
    const newRequest: LeaveOutingRequest = {
      ...data,
      id: `REQ-${data.requestType.toUpperCase()}-${Date.now().toString().slice(-6)}`,
      requestNumber: `REQ-${data.requestType.toUpperCase()}-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`,
      approvalStatus: (data as any).approvalStatus || 'PENDING',
      status: (data as any).status || 'PENDING_HOSTEL',
      createdAt: new Date().toISOString(),
    };
    hostelLeaveRequests = [newRequest, ...hostelLeaveRequests];
    return newRequest;
  },

  updateLeaveRequest(updated: LeaveOutingRequest): LeaveOutingRequest {
    const idx = hostelLeaveRequests.findIndex((r) => r.id === updated.id);
    if (idx !== -1) {
      hostelLeaveRequests[idx] = updated;
    } else {
      hostelLeaveRequests = [updated, ...hostelLeaveRequests];
    }
    return updated;
  },

  cancelLeaveRequest(requestId: string, studentIdOrReg?: string): boolean {
    const clean = studentIdOrReg ? studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() : '';
    const target = hostelLeaveRequests.find((r) => {
      if (r.id !== requestId) return false;
      if (!clean) return true;
      const rIdClean = (r.studentId || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const rRegClean = (r.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return rIdClean === clean || rRegClean === clean;
    });

    if (target) {
      target.approvalStatus = 'CANCELLED';
      target.status = 'CANCELLED';
      return true;
    }
    return false;
  },

  // Proctor Messages
  getProctorMessages(studentIdOrReg: string): ProctorMessage[] {
    if (!studentIdOrReg || !studentIdOrReg.trim()) return [];
    const clean = studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return proctorMessagesStore.filter(
      (m) =>
        (m.studentId && m.studentId.toLowerCase() === studentIdOrReg.toLowerCase()) ||
        (m.studentId && m.studentId.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === clean)
    );
  },

  sendProctorMessage(data: {
    studentId: string;
    studentRegistrationNumber: string;
    studentName: string;
    proctorId: string;
    proctorName: string;
    subject: string;
    message: string;
    sender: 'student' | 'proctor';
  }): ProctorMessage {
    const newMsg: ProctorMessage = {
      id: `MSG-${Date.now().toString().slice(-6)}`,
      studentId: data.studentId,
      proctorId: data.proctorId,
      facultyName: data.proctorName,
      proctorName: data.proctorName,
      title: data.subject,
      message: data.message,
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      priority: 'normal',
      category: 'General Advisement',
    };
    proctorMessagesStore = [newMsg, ...proctorMessagesStore];
    return newMsg;
  },

  // Course Withdrawal Requests
  getCourseWithdrawalRequests(studentIdOrReg: string): CourseWithdrawalRequestRecord[] {
    if (!studentIdOrReg || !studentIdOrReg.trim()) return [];
    const clean = studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
    return courseWithdrawalRequestsStore.filter(
      (r) =>
        (r.studentId && r.studentId.toLowerCase() === studentIdOrReg.toLowerCase()) ||
        (r.studentRegistrationNumber &&
          r.studentRegistrationNumber.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === clean)
    );
  },

  submitCourseWithdrawalRequest(data: {
    studentId: string;
    studentRegistrationNumber: string;
    studentName: string;
    enrolmentId: string;
    courseCode: string;
    courseTitle: string;
    credits: number;
    semester: string;
    reason: string;
  }): CourseWithdrawalRequestRecord {
    if (!data.reason?.trim()) {
      throw new Error('A valid reason is required to submit a course withdrawal request.');
    }

    const newReq: CourseWithdrawalRequestRecord = {
      requestId: `CWR-${Date.now().toString().slice(-6)}`,
      studentId: data.studentId,
      studentRegistrationNumber: data.studentRegistrationNumber,
      studentName: data.studentName,
      enrolmentId: data.enrolmentId,
      courseCode: data.courseCode,
      courseTitle: data.courseTitle,
      credits: data.credits,
      semester: data.semester,
      reason: data.reason.trim(),
      status: 'PENDING_ADVISOR_APPROVAL',
      submittedAt: new Date().toISOString(),
    };

    courseWithdrawalRequestsStore = [newReq, ...courseWithdrawalRequestsStore];
    return newReq;
  },

  // Fee Receipts Builder
  buildFeeReceipts(
    student: Student,
    payments: PaymentRecord[],
    invoices: FeeInvoiceRecord[]
  ): FeeReceipt[] {
    return payments.map((p) => {
      const parentInvoice = invoices.find((inv) => inv.invoice_id === p.invoice_id);
      const remainingBalance = parentInvoice
        ? Math.max(0, parentInvoice.amount_due - parentInvoice.amount_paid)
        : 0;

      return {
        receiptNumber: p.receipt_number || `RCT-${p.payment_id}`,
        paymentId: p.payment_id,
        receiptDate: p.payment_date ? p.payment_date.split('T')[0] : '2026-10-26',
        studentRegistrationNumber: student.registrationNumber,
        studentName: student.fullName,
        className: student.admissionClass,
        section: student.section,
        academicSession: '2026–2027',
        feeTypeName: parentInvoice?.fee_category || 'Academic Tuition & Institutional Fees',
        amountPaid: p.amount,
        amountInWords: convertNumberToWords(p.amount),
        paymentMode: p.payment_method || 'Online Payment Gateway',
        transactionReference: p.transaction_reference,
        outstandingBalanceAfterPayment: remainingBalance,
        receivedBy: 'EIT Accounts Finance Gateway (Automated)',
        isVoided: p.status === ('REVERSED' as any),
        voidReason: p.status === ('REVERSED' as any) ? 'Transaction Reversed by Finance Office' : undefined,
        schoolDetails: {
          name: 'Electrix Institute of Technology (EIT)',
          address: 'EIT Technology Campus, Administrative Block, Chennai, Tamil Nadu - 600127',
          phone: '+91 44 2839 0000',
          email: 'finance.accounts@eit.edu',
          affiliation: 'Approved by AICTE • Accredited Grade A++',
        },
      };
    });
  },

  // Build Hall Tickets
  buildHallTickets(
    student: Student,
    schedules: ExamScheduleRecord[]
  ): HallTicket[] {
    return [
      {
        id: 'HT-2026-ENDSEM-001',
        hallTicketNumber: `HT-${student.registrationNumber.split('-').pop() || '101'}-2026`,
        examinationId: 'EXAM-2026-ENDSEM',
        examinationName: 'End Semester Theory & Practical Examinations — Nov/Dec 2026',
        academicSession: '2026–2027',
        studentRegistrationNumber: student.registrationNumber,
        studentName: student.fullName,
        className: student.admissionClass,
        section: student.section,
        dateOfBirth: student.dateOfBirth,
        fatherName: student.fatherName,
        motherName: student.motherName,
        schoolName: 'ELECTRIX INSTITUTE OF TECHNOLOGY (EIT)',
        schoolAddress: 'Campus Avenue, Technology City, Chennai - 600127',
        schedules: schedules.map((s) => ({
          courseCode: s.course_code,
          courseName: s.course_title || 'Institutional Assessment',
          examDate: s.exam_date,
          timeSlot: `${s.start_time} - ${s.end_time}`,
          room: s.room || 'Main Examination Complex Hall 1',
        })),
      },
    ];
  },
};
