export const ffcsReportService = {
  generateReport() {
    return null;
  },
  printStudentRegistrationSlipPDF(..._args: any[]) {
    if (typeof window !== 'undefined') {
      window.print();
    }
  },
};
