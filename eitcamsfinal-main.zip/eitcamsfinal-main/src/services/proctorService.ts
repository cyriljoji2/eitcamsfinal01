import { studentPortalService } from './studentPortalService';
import { ProctorAssignment, ProctorMessage } from '../types/studentPortalTypes';
import { AuthRole } from '../types/database';

type Listener = () => void;
const listeners = new Set<Listener>();

// Initial in-memory proctor assignments seeded with canonical data
let inMemoryProctorAssignments: ProctorAssignment[] = [
  {
    id: 'ASG-PRC-001',
    studentId: 'STU-001',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    studentName: 'Arjun Kumar',
    facultyId: 'EMP-001',
    facultyName: 'Dr. Ramesh Sundaram',
    facultyEmail: 'r.sundaram@eit.edu',
    facultyPhone: '+91 94440 12345',
    facultyDepartment: 'Computer Science & Engineering',
    academicYear: '2026–2027',
    status: 'active',
    assignedDate: '2026-07-01',
  },
  {
    id: 'ASG-PRC-002',
    studentId: 'STU-002',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
    studentName: 'Rohan Verma',
    facultyId: 'EMP-002',
    facultyName: 'Dr. Arvind Sharma',
    facultyEmail: 'arvind.sharma@faculty.eit.edu',
    facultyPhone: '+91 94440 54321',
    facultyDepartment: 'Computer Science & Engineering',
    academicYear: '2026–2027',
    status: 'active',
    assignedDate: '2026-07-01',
  },
];

let inMemoryRemarks: any[] = [];

export interface ProctorActorContext {
  userId?: string;
  role?: string | AuthRole;
  employeeId?: string;
}

export const proctorRepository = {
  subscribe(listener: Listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  async getAllAssignments(actor?: ProctorActorContext): Promise<ProctorAssignment[]> {
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const targetEmpId = actor.employeeId || actor.userId;
      if (targetEmpId) {
        return this.getActiveAssignmentsForFaculty(targetEmpId, actor);
      }
      throw new Error('Unauthorized: Faculty members may only view their own proctor assignments.');
    }
    return [...inMemoryProctorAssignments];
  },

  async getAllProctors(actor?: ProctorActorContext): Promise<ProctorAssignment[]> {
    return this.getAllAssignments(actor);
  },

  /**
   * Retrieves active proctor assignments strictly for a designated faculty member.
   * Enforces cross-proctor access control at the service layer.
   */
  async getActiveAssignmentsForFaculty(
    facultyId: string,
    actor?: ProctorActorContext
  ): Promise<ProctorAssignment[]> {
    if (!facultyId || !facultyId.trim()) return [];
    const cleanFaculty = facultyId.trim().toLowerCase();

    // Cross-proctor access check: A faculty member cannot query another faculty's assignments
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (
        actorEmpId &&
        actorEmpId !== cleanFaculty &&
        actorUserId !== cleanFaculty
      ) {
        throw new Error(
          `Unauthorized: Cross-proctor access violation. Faculty '${actor.userId || actor.employeeId}' cannot access assignments designated to '${facultyId}'.`
        );
      }
    }

    return inMemoryProctorAssignments.filter(
      (a) =>
        a.status === 'active' &&
        (a.facultyId.toLowerCase() === cleanFaculty ||
          (a.facultyEmail && a.facultyEmail.toLowerCase() === cleanFaculty) ||
          a.facultyName.toLowerCase() === cleanFaculty ||
          a.facultyName.toLowerCase().includes(cleanFaculty))
    );
  },

  /**
   * Backward-compatible active assignment getter that supports scoping by facultyId.
   */
  async getActiveAssignments(
    facultyId?: string,
    actor?: ProctorActorContext
  ): Promise<ProctorAssignment[]> {
    if (facultyId) {
      return this.getActiveAssignmentsForFaculty(facultyId, actor);
    }
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = actor.employeeId || actor.userId;
      if (actorEmpId) {
        return this.getActiveAssignmentsForFaculty(actorEmpId, actor);
      }
      throw new Error('Unauthorized: Faculty members may only access their own active proctor assignments.');
    }
    return inMemoryProctorAssignments.filter((a) => a.status === 'active');
  },

  /**
   * Official Student Portal & Academic Profile resolution.
   * Returns current active assignment, reflecting instant reassignments or deactivations.
   */
  async getActiveAssignmentForStudent(studentIdOrReg: string): Promise<ProctorAssignment | null> {
    if (!studentIdOrReg || !studentIdOrReg.trim()) return null;
    const clean = studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    const found = inMemoryProctorAssignments.find(
      (a) =>
        a.status === 'active' &&
        ((a.studentId && a.studentId.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === clean) ||
          (a.studentRegistrationNumber &&
            a.studentRegistrationNumber.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() === clean))
    );

    return found || null;
  },

  /**
   * Assign or Reassign a proctor to a student.
   * Authority: Academic Office only. Faculty members are strictly denied.
   */
  async assignProctor(
    data: {
      studentId: string;
      studentRegNo?: string;
      studentName?: string;
      studentClass?: string;
      studentSection?: string;
      facultyId: string;
      facultyName: string;
      facultyDepartment?: string;
      facultyEmail?: string;
      facultyMobile?: string;
      facultyDesignation?: string;
      academicSession?: string;
      assignedBy?: string;
      notes?: string;
    },
    actor?: ProctorActorContext
  ): Promise<ProctorAssignment> {
    // Role check: Faculty members cannot assign or reassign proctors
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      throw new Error(
        'Unauthorized: Faculty members are not permitted to assign, reassign, or remove proctees. This authority is reserved exclusively for the Office of Academic Affairs.'
      );
    }
    if (actor && (actor.role === AuthRole.STUDENT || actor.role === 'STUDENT' || actor.role === AuthRole.PARENT || actor.role === 'PARENT')) {
      throw new Error('Unauthorized: Only the Academic Office has authority to assign or modify proctor allocations.');
    }

    const assignedBy = data.assignedBy || actor?.userId || 'Academic Office';
    const nowIso = new Date().toISOString();
    const today = nowIso.split('T')[0];

    // Deactivate previous active assignment for this student if any (Reassignment workflow)
    inMemoryProctorAssignments = inMemoryProctorAssignments.map((a) =>
      (a.studentId === data.studentId || (data.studentRegNo && a.studentRegistrationNumber === data.studentRegNo)) &&
      a.status === 'active'
        ? {
            ...a,
            status: 'deactivated',
            deactivatedDate: today,
            deactivatedBy: assignedBy,
            deactivationReason: `Reassigned to ${data.facultyName} (${data.facultyId}) by Academic Office`,
          }
        : a
    );

    const newId = `ASG-PRC-${String(inMemoryProctorAssignments.length + 1).padStart(3, '0')}`;
    const newAssignment: ProctorAssignment = {
      id: newId,
      studentId: data.studentId,
      studentRegistrationNumber: data.studentRegNo,
      studentName: data.studentName,
      studentClass: data.studentClass,
      studentSection: data.studentSection,
      facultyId: data.facultyId,
      facultyName: data.facultyName,
      facultyEmail: data.facultyEmail || '',
      facultyPhone: data.facultyMobile || '',
      facultyDepartment: data.facultyDepartment || 'Engineering',
      academicYear: data.academicSession || '2026–2027',
      status: 'active',
      assignedDate: today,
      assignedBy,
      notes: data.notes,
    };

    inMemoryProctorAssignments.unshift(newAssignment);
    listeners.forEach((fn) => fn());
    return newAssignment;
  },

  /**
   * Deactivate an assignment.
   * Authority: Academic Office only.
   */
  async deactivateAssignment(
    id: string,
    reasonOrActor?: string | ProctorActorContext,
    actorArg?: ProctorActorContext
  ): Promise<boolean> {
    const actor =
      typeof reasonOrActor === 'object' && reasonOrActor !== null
        ? reasonOrActor
        : actorArg;
    const reason = typeof reasonOrActor === 'string' ? reasonOrActor : undefined;

    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      throw new Error(
        'Unauthorized: Faculty members are not permitted to assign, reassign, or remove proctees. This authority is reserved exclusively for the Office of Academic Affairs.'
      );
    }
    if (actor && (actor.role === AuthRole.STUDENT || actor.role === 'STUDENT' || actor.role === AuthRole.PARENT || actor.role === 'PARENT')) {
      throw new Error('Unauthorized: Only the Academic Office has authority to assign or modify proctor allocations.');
    }

    inMemoryProctorAssignments = inMemoryProctorAssignments.map((a) =>
      a.id === id
        ? {
            ...a,
            status: 'deactivated',
            deactivatedDate: new Date().toISOString().split('T')[0],
            deactivatedBy: actor?.userId || 'Academic Office',
            deactivationReason: reason || 'Deactivated by Academic Office',
          }
        : a
    );
    listeners.forEach((fn) => fn());
    return true;
  },

  async bulkAssignProctors(
    items: {
      studentId: string;
      studentRegNo?: string;
      studentName?: string;
      studentClass?: string;
      studentSection?: string;
      facultyId: string;
      facultyName: string;
      facultyDepartment?: string;
      facultyEmail?: string;
      facultyMobile?: string;
      facultyDesignation?: string;
      academicSession?: string;
      assignedBy?: string;
      notes?: string;
    }[],
    actor?: ProctorActorContext
  ): Promise<ProctorAssignment[]> {
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      throw new Error(
        'Unauthorized: Faculty members are not permitted to assign, reassign, or remove proctees. This authority is reserved exclusively for the Office of Academic Affairs.'
      );
    }
    const results: ProctorAssignment[] = [];
    for (const item of items) {
      const asg = await this.assignProctor(item, actor);
      results.push(asg);
    }
    return results;
  },

  /**
   * Retrieves leave and outing requests submitted by students assigned to this proctor.
   * Enforces cross-proctor access controls.
   */
  async getRequestsForProctor(
    facultyId: string,
    actor?: ProctorActorContext
  ): Promise<any[]> {
    if (!facultyId) return [];
    const cleanFaculty = facultyId.trim().toLowerCase();

    // Cross-proctor access check
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanFaculty && actorUserId !== cleanFaculty) {
        throw new Error(
          `Unauthorized: Cross-proctor access violation. Faculty cannot access leave requests for proctees assigned to '${facultyId}'.`
        );
      }
    }

    const myWards = inMemoryProctorAssignments.filter(
      (a) =>
        a.status === 'active' &&
        (a.facultyId.toLowerCase() === cleanFaculty ||
          (a.facultyEmail && a.facultyEmail.toLowerCase() === cleanFaculty) ||
          a.facultyName.toLowerCase() === cleanFaculty ||
          a.facultyName.toLowerCase().includes(cleanFaculty))
    );
    const wardRegs = new Set(myWards.map((w) => (w.studentRegistrationNumber || '').toLowerCase()));
    const wardIds = new Set(myWards.map((w) => (w.studentId || '').toLowerCase()));

    const allRequests = studentPortalService.getLeaveRequests('');
    return allRequests
      .filter((r) => {
        const rReg = (r.studentRegistrationNumber || '').toLowerCase();
        const rId = (r.studentId || '').toLowerCase();
        return wardRegs.has(rReg) || wardIds.has(rId);
      })
      .map((r) => ({
        ...r,
        status: r.approvalStatus,
        destinationAddress: r.destination,
        purpose: r.reason,
      }));
  },

  async endorseLeaveOutingRequest(
    requestId: string,
    proctorId: string,
    action: 'approve' | 'reject',
    remarks: string,
    actor?: ProctorActorContext
  ): Promise<any> {
    if (!remarks?.trim()) {
      throw new Error('Mandatory proctor review remarks are required.');
    }
    const cleanProctor = proctorId.trim().toLowerCase();

    // Cross-proctor validation
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanProctor && actorUserId !== cleanProctor) {
        throw new Error('Unauthorized: Cannot endorse leave requests on behalf of another faculty proctor.');
      }
    }

    const allRequests = studentPortalService.getLeaveRequests('');
    const target = allRequests.find((r) => r.id === requestId);
    if (!target) {
      throw new Error(`Leave/Outing request '${requestId}' not found.`);
    }

    // Verify the target student is currently an active proctee of this proctor
    const isStudentProctee = inMemoryProctorAssignments.some(
      (a) =>
        a.status === 'active' &&
        (a.facultyId.toLowerCase() === cleanProctor ||
          (a.facultyEmail && a.facultyEmail.toLowerCase() === cleanProctor) ||
          a.facultyName.toLowerCase() === cleanProctor ||
          a.facultyName.toLowerCase().includes(cleanProctor)) &&
        ((target.studentId && a.studentId.toLowerCase() === target.studentId.toLowerCase()) ||
          (target.studentRegistrationNumber &&
            (a.studentRegistrationNumber || '').toLowerCase() ===
              target.studentRegistrationNumber.toLowerCase()))
    );

    if (!isStudentProctee) {
      throw new Error(
        `Unauthorized: Faculty member '${proctorId}' is not the designated active proctor for student '${target.studentRegistrationNumber}'.`
      );
    }

    const proctor = inMemoryProctorAssignments.find(
      (a) =>
        a.facultyId.toLowerCase() === cleanProctor ||
        a.id.toLowerCase() === cleanProctor ||
        a.facultyName.toLowerCase().includes(cleanProctor)
    );

    target.approvalStatus = action === 'approve' ? 'APPROVED' : 'REJECTED';
    target.status = target.approvalStatus;
    target.proctorRemarks = remarks.trim();
    target.proctorActionDate = new Date().toISOString();
    target.proctorName = proctor?.facultyName || 'Faculty Proctor';

    listeners.forEach((fn) => fn());
    return target;
  },

  async getRemarksByProctor(
    facultyId: string,
    actor?: ProctorActorContext
  ): Promise<any[]> {
    if (!facultyId) return [];
    const cleanFaculty = facultyId.trim().toLowerCase();

    // Cross-proctor access check: Confidential remarks restricted to authoring proctor
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanFaculty && actorUserId !== cleanFaculty) {
        throw new Error(
          `Unauthorized: Cross-proctor access violation. Confidential mentoring remarks are restricted to the authoring proctor.`
        );
      }
    }

    try {
      const stored = typeof localStorage !== 'undefined' ? localStorage.getItem('eit_proctor_remarks_v1') : null;
      const all: any[] = stored ? JSON.parse(stored) : inMemoryRemarks;
      return all.filter((r) => (r.proctorId || '').toLowerCase() === cleanFaculty);
    } catch {
      return inMemoryRemarks.filter((r) => (r.proctorId || '').toLowerCase() === cleanFaculty);
    }
  },

  async addRemark(
    data: {
      proctorId: string;
      studentId: string;
      studentRegistrationNumber: string;
      studentName?: string;
      category: string;
      remark: string;
      actionRequired?: boolean;
    },
    actor?: ProctorActorContext
  ): Promise<any> {
    if (!data.remark?.trim()) {
      throw new Error('Remark text cannot be empty.');
    }
    const cleanProctor = data.proctorId.trim().toLowerCase();

    // Cross-proctor verification
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanProctor && actorUserId !== cleanProctor) {
        throw new Error('Unauthorized: Cannot log mentoring remarks on behalf of another faculty member.');
      }
    }

    // Verify student is an active proctee of this proctor
    const isProctee = inMemoryProctorAssignments.some(
      (a) =>
        a.status === 'active' &&
        (a.facultyId.toLowerCase() === cleanProctor ||
          (a.facultyEmail && a.facultyEmail.toLowerCase() === cleanProctor) ||
          a.facultyName.toLowerCase() === cleanProctor ||
          a.facultyName.toLowerCase().includes(cleanProctor)) &&
        ((data.studentId && a.studentId.toLowerCase() === data.studentId.toLowerCase()) ||
          (data.studentRegistrationNumber &&
            (a.studentRegistrationNumber || '').toLowerCase() ===
              data.studentRegistrationNumber.toLowerCase()))
    );

    if (!isProctee) {
      throw new Error(
        `Unauthorized: Cannot log mentoring remarks for student '${data.studentRegistrationNumber || data.studentId}' who is not an active mentee in your proctor portfolio.`
      );
    }

    const newRemark = {
      ...data,
      id: `REM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      status: 'open',
      createdAt: new Date().toISOString(),
    };
    inMemoryRemarks.unshift(newRemark);
    try {
      if (typeof localStorage !== 'undefined') {
        const stored = localStorage.getItem('eit_proctor_remarks_v1');
        const all: any[] = stored ? JSON.parse(stored) : [];
        all.unshift(newRemark);
        localStorage.setItem('eit_proctor_remarks_v1', JSON.stringify(all));
      }
    } catch {}
    listeners.forEach((fn) => fn());
    return newRemark;
  },

  async getMessagesByProctor(
    facultyId: string,
    actor?: ProctorActorContext
  ): Promise<ProctorMessage[]> {
    if (!facultyId) return [];
    const cleanFaculty = facultyId.trim().toLowerCase();

    // Cross-proctor access check
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanFaculty && actorUserId !== cleanFaculty) {
        throw new Error('Unauthorized: Cross-proctor access violation. Mentorship messages are restricted to the assigned proctor.');
      }
    }

    const myWards = inMemoryProctorAssignments.filter(
      (a) =>
        a.status === 'active' &&
        (a.facultyId.toLowerCase() === cleanFaculty ||
          (a.facultyEmail && a.facultyEmail.toLowerCase() === cleanFaculty) ||
          a.facultyName.toLowerCase() === cleanFaculty ||
          a.facultyName.toLowerCase().includes(cleanFaculty))
    );
    const wardIds = new Set(myWards.map((w) => (w.studentId || '').toLowerCase()));
    const wardRegs = new Set(myWards.map((w) => (w.studentRegistrationNumber || '').toLowerCase()));

    const all = studentPortalService.getProctorMessages('');
    return all.filter(
      (m) =>
        (m.proctorId && m.proctorId.toLowerCase() === cleanFaculty) ||
        (m.studentId && (wardIds.has(m.studentId.toLowerCase()) || wardRegs.has(m.studentId.toLowerCase())))
    );
  },

  async getMessagesForStudent(studentIdOrReg: string, _proctorId?: string): Promise<ProctorMessage[]> {
    if (!studentIdOrReg || !studentIdOrReg.trim()) return [];
    return studentPortalService.getProctorMessages(studentIdOrReg);
  },

  async sendMessage(
    data: {
      studentId: string;
      studentRegistrationNumber: string;
      studentName: string;
      proctorId: string;
      proctorName: string;
      subject: string;
      message: string;
      sender?: 'student' | 'proctor';
    },
    actor?: ProctorActorContext
  ): Promise<ProctorMessage> {
    const cleanProctor = data.proctorId.trim().toLowerCase();
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const actorEmpId = (actor.employeeId || '').trim().toLowerCase();
      const actorUserId = (actor.userId || '').trim().toLowerCase();
      if (actorEmpId && actorEmpId !== cleanProctor && actorUserId !== cleanProctor) {
        throw new Error('Unauthorized: Cannot send proctor messages as another faculty member.');
      }
    }

    const msg = studentPortalService.sendProctorMessage({
      ...data,
      sender: data.sender || 'proctor',
    });
    listeners.forEach((fn) => fn());
    return msg;
  },
};

