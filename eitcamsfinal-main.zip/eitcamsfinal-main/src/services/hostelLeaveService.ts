/**
 * EIT CAMS — Hostel Leave & Outing Service
 * Manages Leave Applications, Proctor Endorsements, Hostel Office Approvals,
 * Gate Movements, and Official Slip Generation.
 */

import { studentPortalService } from './studentPortalService';
import { LeaveOutingRequest, HostelLeaveMetrics } from '../types/hostel';

type Listener = () => void;
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch (e) {
      console.error('Hostel leave listener error:', e);
    }
  });
}

export const hostelLeaveService = {
  subscribe(listener: Listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  async getAllRequests(): Promise<LeaveOutingRequest[]> {
    const list = studentPortalService.getLeaveRequests('');
    return list.map((r) => ({
      ...r,
      status: r.status || r.approvalStatus || 'PENDING_HOSTEL',
      approvalStatus: r.approvalStatus || r.status || 'PENDING_HOSTEL',
      destinationAddress: r.destinationAddress || r.destination,
      purpose: r.purpose || r.reason,
    }));
  },

  async getDashboardMetrics(): Promise<HostelLeaveMetrics> {
    const all = await this.getAllRequests();
    const todayStr = new Date().toISOString().split('T')[0];

    const pendingHostel = all.filter(
      (r) =>
        r.status === 'PENDING_HOSTEL' ||
        r.approvalStatus === 'PENDING_HOSTEL' ||
        (r.approvalStatus === 'PENDING' && !r.hostelActionDate)
    ).length;

    const approvedToday = all.filter(
      (r) =>
        (r.status === 'APPROVED' || r.approvalStatus === 'APPROVED') &&
        (r.hostelActionDate?.startsWith(todayStr) || r.createdAt?.startsWith(todayStr))
    ).length;

    const rejected = all.filter(
      (r) =>
        r.status === 'REJECTED_BY_HOSTEL' ||
        r.status === 'REJECTED_BY_PROCTOR' ||
        r.status === 'REJECTED' ||
        r.approvalStatus === 'REJECTED'
    ).length;

    const activeLeaveOuting = all.filter(
      (r) =>
        (r.status === 'APPROVED' || r.approvalStatus === 'APPROVED') &&
        (!r.gateInTime || r.toDate >= todayStr)
    ).length;

    return {
      pendingHostel,
      approvedToday,
      rejected,
      activeLeaveOuting,
      totalRequests: all.length,
    };
  },

  async reviewRequestByHostel(
    requestId: string,
    employeeName: string,
    employeeId: string,
    action: 'approve' | 'reject',
    remarks: string
  ): Promise<LeaveOutingRequest> {
    const all = studentPortalService.getLeaveRequests('');
    const target = all.find((r) => r.id === requestId);
    if (!target) {
      throw new Error(`Leave/Outing request '${requestId}' not found.`);
    }

    if (action === 'reject' && !remarks?.trim()) {
      throw new Error('A detailed reason is mandatory when rejecting a leave/outing request.');
    }

    const nowIso = new Date().toISOString();
    const updated: LeaveOutingRequest = {
      ...target,
      status: action === 'approve' ? 'APPROVED' : 'REJECTED_BY_HOSTEL',
      approvalStatus: action === 'approve' ? 'APPROVED' : 'REJECTED',
      hostelRemarks: remarks?.trim() || (action === 'approve' ? 'Hostel gate clearance approved.' : 'Rejected by Hostel Office.'),
      hostelActionBy: employeeName || 'Hostel Office Authority',
      hostelActionDate: nowIso,
      rejectionReason: action === 'reject' ? remarks.trim() : undefined,
      slipNumber:
        action === 'approve'
          ? target.slipNumber || `SLIP-EIT-2026-${Math.floor(10000 + Math.random() * 90000)}`
          : undefined,
    };

    studentPortalService.updateLeaveRequest(updated);
    notify();
    return updated;
  },

  async recordGateOut(
    requestId: string,
    gateOutTime: string,
    securityGuardName: string
  ): Promise<LeaveOutingRequest> {
    const all = studentPortalService.getLeaveRequests('');
    const target = all.find((r) => r.id === requestId);
    if (!target) throw new Error(`Request '${requestId}' not found.`);

    const updated: LeaveOutingRequest = {
      ...target,
      gateOutTime: gateOutTime || new Date().toLocaleTimeString(),
      securityGuardName: securityGuardName || 'Campus Main Gate Security',
    };

    studentPortalService.updateLeaveRequest(updated);
    notify();
    return updated;
  },

  async recordGateIn(
    requestId: string,
    gateInTime: string,
    securityGuardName: string
  ): Promise<LeaveOutingRequest> {
    const all = studentPortalService.getLeaveRequests('');
    const target = all.find((r) => r.id === requestId);
    if (!target) throw new Error(`Request '${requestId}' not found.`);

    const updated: LeaveOutingRequest = {
      ...target,
      gateInTime: gateInTime || new Date().toLocaleTimeString(),
      securityGuardName: securityGuardName || target.securityGuardName || 'Campus Main Gate Security',
    };

    studentPortalService.updateLeaveRequest(updated);
    notify();
    return updated;
  },

  async getRequestsForStudent(studentIdOrReg: string): Promise<LeaveOutingRequest[]> {
    const list = studentPortalService.getLeaveRequests(studentIdOrReg);
    return list.map((r) => ({
      ...r,
      status: r.status || r.approvalStatus || 'PENDING_HOSTEL',
      approvalStatus: r.approvalStatus || r.status || 'PENDING_HOSTEL',
      destinationAddress: r.destinationAddress || r.destination,
      purpose: r.purpose || r.reason,
    }));
  },

  async submitRequest(data: any): Promise<LeaveOutingRequest> {
    const res = studentPortalService.submitLeaveRequest({
      ...data,
      reasonCategory: data.reasonCategory || 'academic',
      reason: data.reason || data.purpose || 'Student leave application',
      destination: data.destination || data.destinationAddress || 'Local City Area',
      destinationAddress: data.destinationAddress || data.destination || 'Local City Area',
      contactNumber: data.contactNumber || '9999999999',
      emergencyContact: data.emergencyContact || '9999999999',
    });
    notify();
    return {
      ...res,
      approvalStatus: res.approvalStatus || 'PENDING',
      status: res.status || 'PENDING_HOSTEL',
      destinationAddress: res.destination,
      purpose: res.reason,
    };
  },

  async createRequest(data: any): Promise<LeaveOutingRequest> {
    return this.submitRequest(data);
  },

  async cancelRequestByStudent(requestId: string, studentId?: string): Promise<void> {
    studentPortalService.cancelLeaveRequest(requestId, studentId);
    notify();
  },
};
