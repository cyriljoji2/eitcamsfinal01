import { devDataAdapter } from './devDataAdapter';
import {
  AdjustmentStatus,
  AdjustmentType,
  FeeAdjustmentRecord,
  FeeCategory,
  FeeInvoiceRecord,
  FeeStructureRecord,
  HostelChargeRequestRecord,
  InvoiceStatus,
  PaymentLedgerStatus,
  PaymentMethod,
  PaymentRecord as DbPaymentRecord,
  StudentRecord,
  StudentStatus,
} from '../types/database';
import {
  FeeAssignment,
  FeeReceipt,
  FeeStructureItem,
  FinanceDashboardMetrics,
  PaymentMode,
  PaymentRecordItem,
  StudentFeeSummary,
} from '../types/finance';

const SCHOOL_DETAILS = {
  name: 'Electrix Institute of Technology (EIT)',
  address: 'EIT Technology Campus, Chennai, Tamil Nadu - 600127',
  phone: '+91 44 2839 0000',
  email: 'finance.accounts@eit.edu',
  affiliation: 'Approved by AICTE • Accredited Grade A++',
};

function mapPaymentMethodToMode(method: PaymentMethod | string): PaymentMode {
  switch (method) {
    case PaymentMethod.CASH:
      return 'Cash';
    case PaymentMethod.BANK_TRANSFER:
      return 'Bank Transfer';
    case PaymentMethod.CARD:
      return 'Credit Card';
    case PaymentMethod.ONLINE_GATEWAY:
      return 'Online Gateway';
    default:
      return (method as string) || 'Online Gateway';
  }
}

function mapModeToPaymentMethod(mode: PaymentMode): PaymentMethod {
  const normalized = String(mode).toLowerCase();
  if (normalized.includes('cash')) return PaymentMethod.CASH;
  if (normalized.includes('bank') || normalized.includes('transfer') || normalized.includes('neft') || normalized.includes('rtgs'))
    return PaymentMethod.BANK_TRANSFER;
  if (normalized.includes('card') || normalized.includes('debit') || normalized.includes('credit'))
    return PaymentMethod.CARD;
  if (normalized.includes('online') || normalized.includes('gateway') || normalized.includes('upi'))
    return PaymentMethod.ONLINE_GATEWAY;
  return PaymentMethod.OTHER;
}

export const financeRepository = {
  // Backward compatible methods
  async getFeeAssignments(): Promise<FeeAssignment[]> {
    const invoices = await devDataAdapter.finance.getInvoices();
    return invoices.map((inv) => ({
      id: inv.invoice_id,
      studentRegistrationNumber: inv.registration_number,
      feeTypeName: inv.fee_category,
      amountDue: inv.amount_due,
      amountPaid: inv.amount_paid,
      discountOrWaiver: inv.adjustments_total || 0,
      balanceDue: Math.max(0, inv.amount_due - inv.amount_paid),
      balance: Math.max(0, inv.amount_due - inv.amount_paid),
      dueDate: inv.due_date,
      status:
        inv.status === InvoiceStatus.PAID
          ? 'Paid'
          : inv.status === InvoiceStatus.PARTIALLY_PAID
          ? 'Partial'
          : inv.status === InvoiceStatus.OVERDUE
          ? 'Overdue'
          : 'Unpaid',
      category: inv.fee_category,
      academicSession: inv.academic_year,
      remarks: inv.notes,
    }));
  },

  async getPayments(): Promise<PaymentRecordItem[]> {
    const payments = await devDataAdapter.finance.getPayments();
    const invoices = await devDataAdapter.finance.getInvoices();
    const invoiceMap = new Map(invoices.map((i) => [i.invoice_id, i]));

    return payments.map((p) => {
      const inv = invoiceMap.get(p.invoice_id);
      return {
        id: p.payment_id,
        studentRegistrationNumber: p.registration_number,
        studentName: p.student_name,
        receiptNumber: p.receipt_number,
        feeTypeName: inv ? inv.fee_category : p.invoice_id,
        academicSession: inv ? inv.academic_year : '2026-2027',
        amountPaid: p.amount,
        paymentMode: mapPaymentMethodToMode(p.payment_method),
        paymentDate: p.payment_date ? p.payment_date.split('T')[0] : new Date().toISOString().split('T')[0],
        transactionReference: p.transaction_reference,
        receivedBy: p.receiving_officer_id || 'Finance Officer',
        isVoided: p.status === PaymentLedgerStatus.REVERSED || p.status === PaymentLedgerStatus.REFUNDED,
        voidReason:
          p.status === PaymentLedgerStatus.REVERSED
            ? p.reversal_reason || 'Transaction Reversed'
            : p.status === PaymentLedgerStatus.REFUNDED
            ? p.refund_reason || 'Fully Refunded'
            : undefined,
        notes: p.notes,
      };
    });
  },

  async getReceipts(): Promise<FeeReceipt[]> {
    const payments = await devDataAdapter.finance.getPayments();
    const students = await devDataAdapter.students.getAll();
    const invoices = await devDataAdapter.finance.getInvoices();

    return payments.map((p) => {
      const student = students.find(
        (s) => s.student_id === p.student_id || s.registration_number === p.registration_number
      );
      const invoice = invoices.find((i) => i.invoice_id === p.invoice_id);

      return {
        receiptNumber: p.receipt_number || `RCT-${p.payment_id}`,
        paymentId: p.payment_id,
        receiptDate: p.payment_date ? p.payment_date.split('T')[0] : '2026-10-26',
        studentRegistrationNumber: p.registration_number,
        studentName: student ? `${student.first_name} ${student.last_name}` : p.student_name || 'Student Candidate',
        className: student ? student.program_name : 'B.Tech CSE',
        section: student ? student.section : 'A',
        academicSession: invoice ? invoice.academic_year : '2026–2027',
        feeTypeName: invoice ? invoice.fee_category : 'Tuition & Academic Fees',
        amountPaid: p.amount,
        amountInWords: `${p.amount} Dollars Only`,
        paymentMode: mapPaymentMethodToMode(p.payment_method),
        transactionReference: p.transaction_reference,
        outstandingBalanceAfterPayment: invoice ? Math.max(0, invoice.amount_due - invoice.amount_paid) : 0,
        receivedBy: p.receiving_officer_id || 'EIT Accounts Finance Gateway',
        isVoided: p.status === PaymentLedgerStatus.REVERSED || p.status === PaymentLedgerStatus.REFUNDED,
        voidReason:
          p.status === PaymentLedgerStatus.REVERSED
            ? p.reversal_reason || 'Transaction Reversed'
            : p.status === PaymentLedgerStatus.REFUNDED
            ? p.refund_reason || 'Refunded'
            : undefined,
        schoolDetails: SCHOOL_DETAILS,
      };
    });
  },

  // 1. Fee Structures Management
  async getFeeStructures(
    filters?: { academic_year?: string; semester?: number; programme_code?: string; status?: string },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeStructureItem[]> {
    const records = await devDataAdapter.finance.getFeeStructures(filters, actor);
    return records.map((r) => ({
      id: r.structure_id,
      name: r.fee_name || r.name || 'Academic Fee',
      feeCategory: r.fee_category,
      amount: r.amount,
      currency: r.currency || 'USD',
      academicSession: r.academic_year,
      semester: r.semester,
      programmeCode: r.programme_code,
      applicableClassNames: [r.programme_code === 'ALL' ? 'All Programmes' : r.programme_code],
      frequency: r.semester === 0 ? 'Annual' : 'Per Semester',
      dueDate: r.due_date,
      status: r.status.toLowerCase() as any,
      description: r.applicability,
      applicability: r.applicability,
    }));
  },

  async createFeeStructure(
    data: {
      name: string;
      feeCategory: FeeCategory | string;
      amount: number;
      academicSession: string;
      semester: number;
      programmeCode: string;
      dueDate: string;
      description?: string;
      status?: 'active' | 'inactive' | 'ACTIVE' | 'INACTIVE';
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeStructureRecord> {
    const statusVal = data.status?.toUpperCase() === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE';
    return await devDataAdapter.finance.createFeeStructure(
      {
        academic_year: data.academicSession,
        semester: Number(data.semester),
        programme_code: data.programmeCode,
        fee_category: data.feeCategory,
        fee_name: data.name,
        name: data.name,
        amount: Number(data.amount),
        currency: 'USD',
        due_date: data.dueDate,
        applicability: data.description || `${data.programmeCode} Semester ${data.semester}`,
        status: statusVal,
      },
      actor
    );
  },

  async updateFeeStructure(
    id: string,
    data: Partial<FeeStructureRecord>,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeStructureRecord> {
    return await devDataAdapter.finance.updateFeeStructure(id, data, actor);
  },

  async toggleFeeStructureStatus(
    id: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeStructureRecord> {
    const structures = await devDataAdapter.finance.getFeeStructures(undefined, actor);
    const existing = structures.find((s) => s.structure_id === id);
    if (!existing) throw new Error(`Fee structure ${id} not found.`);
    const nextStatus = existing.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    return await devDataAdapter.finance.updateFeeStructure(id, { status: nextStatus }, actor);
  },

  async deleteFeeStructure(
    id: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeStructureRecord> {
    return await devDataAdapter.finance.updateFeeStructure(id, { status: 'INACTIVE' }, actor);
  },

  // 2. Invoices & Fee Assignments
  async getInvoices(
    filters?: {
      invoice_id?: string;
      student_id?: string;
      registration_number?: string;
      academic_year?: string;
      semester?: number;
      status?: InvoiceStatus;
      category?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord[]> {
    return await devDataAdapter.finance.getInvoices(filters, actor);
  },

  async getInvoiceById(
    invoiceId: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord | null> {
    return await devDataAdapter.finance.getInvoiceById(invoiceId, actor);
  },

  async generateInvoice(
    data: {
      student_id: string;
      academic_year: string;
      semester: number;
      fee_category?: string;
      due_date?: string;
      line_items: { fee_structure_id?: string; category: string; description: string; amount: number }[];
      notes?: string;
      hostel_charge_id?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord> {
    return await devDataAdapter.finance.generateInvoice(data, actor);
  },

  async cancelInvoice(
    invoiceId: string,
    reason: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord> {
    return await devDataAdapter.finance.cancelInvoice(invoiceId, reason, actor);
  },

  // Assign fee head to cohort (programme + semester)
  async assignToProgramme(
    params: {
      feeStructureId: string;
      programmeCode: string;
      semester: number;
      academicYear?: string;
      dueDate?: string;
      remarks?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<{ created: FeeInvoiceRecord[]; skippedCount: number }> {
    const structures = await devDataAdapter.finance.getFeeStructures(undefined, actor);
    const structure = structures.find((s) => s.structure_id === params.feeStructureId);
    if (!structure) throw new Error(`Fee structure ${params.feeStructureId} not found.`);

    const allStudents = await devDataAdapter.students.getAll();
    const candidateStudents = allStudents.filter((s) => {
      const progMatch =
        params.programmeCode === 'ALL' ||
        s.department === params.programmeCode ||
        s.program_name.toLowerCase().includes(params.programmeCode.toLowerCase());
      const semMatch = params.semester === 0 || s.current_semester === params.semester;
      return progMatch && semMatch && (s.enrollment_status === StudentStatus.ENROLLED || (s as any).status === 'ACTIVE');
    });

    const existingInvoices = await devDataAdapter.finance.getInvoices(undefined, actor);
    const created: FeeInvoiceRecord[] = [];
    let skippedCount = 0;

    for (const student of candidateStudents) {
      // Check if already invoiced for same academic year, semester, and fee structure
      const alreadyInvoiced = existingInvoices.some(
        (inv) =>
          inv.student_id === student.student_id &&
          inv.academic_year === (params.academicYear || structure.academic_year) &&
          inv.semester === (params.semester || structure.semester) &&
          inv.status !== InvoiceStatus.CANCELLED &&
          inv.line_items.some((li) => li.fee_structure_id === structure.structure_id)
      );

      if (alreadyInvoiced) {
        skippedCount++;
        continue;
      }

      try {
        const inv = await devDataAdapter.finance.generateInvoice(
          {
            student_id: student.student_id,
            academic_year: params.academicYear || structure.academic_year,
            semester: params.semester || structure.semester,
            fee_category: String(structure.fee_category),
            due_date: params.dueDate || structure.due_date,
            line_items: [
              {
                fee_structure_id: structure.structure_id,
                category: String(structure.fee_category),
                description: structure.fee_name || `${structure.programme_code} ${structure.fee_category}`,
                amount: structure.amount,
              },
            ],
            notes: params.remarks || `Cohort billing for ${params.programmeCode} Semester ${params.semester}`,
          },
          actor
        );
        created.push(inv);
      } catch (err) {
        skippedCount++;
      }
    }

    return { created, skippedCount };
  },

  async assignToStudent(
    params: {
      feeStructureId: string;
      studentRegistrationNumber: string;
      customAmount?: number;
      discountOrWaiver?: number;
      waiverReason?: string;
      dueDate?: string;
      remarks?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord> {
    const student = await devDataAdapter.students.getByRegistrationNumber(params.studentRegistrationNumber);
    if (!student) throw new Error(`Student ${params.studentRegistrationNumber} not found.`);

    const structures = await devDataAdapter.finance.getFeeStructures(undefined, actor);
    const structure = structures.find((s) => s.structure_id === params.feeStructureId);
    if (!structure) throw new Error(`Fee structure ${params.feeStructureId} not found.`);

    const amount = params.customAmount !== undefined ? params.customAmount : structure.amount;

    const invoice = await devDataAdapter.finance.generateInvoice(
      {
        student_id: student.student_id,
        academic_year: structure.academic_year,
        semester: student.current_semester || structure.semester || 1,
        fee_category: String(structure.fee_category),
        due_date: params.dueDate || structure.due_date,
        line_items: [
          {
            fee_structure_id: structure.structure_id,
            category: String(structure.fee_category),
            description: structure.fee_name || `${structure.programme_code} ${structure.fee_category}`,
            amount,
          },
        ],
        notes: params.remarks,
      },
      actor
    );

    // Apply waiver if specified
    if (params.discountOrWaiver && params.discountOrWaiver > 0) {
      await devDataAdapter.finance.requestAdjustment(
        {
          invoice_id: invoice.invoice_id,
          adjustment_type: AdjustmentType.CONCESSION,
          amount: params.discountOrWaiver,
          reason: params.waiverReason || 'Initial concession applied on assignment',
        },
        actor
      );
    }

    return invoice;
  },

  // 3. Payments & Receipts
  async recordPayment(
    data: {
      studentRegistrationNumber: string;
      feeAssignmentId?: string;
      feeTypeName?: string;
      amountPaid: number;
      paymentDate?: string;
      paymentMode: PaymentMode;
      transactionReference?: string;
      remarks?: string;
      receivedBy?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<{ payment: PaymentRecordItem; receipt: FeeReceipt }> {
    const invoices = await devDataAdapter.finance.getInvoices(undefined, actor);
    let targetInvoice: FeeInvoiceRecord | undefined;

    if (data.feeAssignmentId) {
      targetInvoice = invoices.find((i) => i.invoice_id === data.feeAssignmentId);
    }

    if (!targetInvoice) {
      targetInvoice = invoices.find(
        (i) =>
          i.registration_number.toLowerCase() === data.studentRegistrationNumber.toLowerCase() &&
          i.outstanding_balance > 0 &&
          i.status !== InvoiceStatus.CANCELLED
      );
    }

    if (!targetInvoice) {
      throw new Error(
        `No outstanding invoice found for student ${data.studentRegistrationNumber} to apply payment.`
      );
    }

    const cleanRef = data.transactionReference?.trim() || `TXN-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const method = mapModeToPaymentMethod(data.paymentMode);

    const paymentRecord = await devDataAdapter.finance.recordPayment(
      targetInvoice.invoice_id,
      Number(data.amountPaid),
      cleanRef,
      method,
      data.remarks,
      actor
    );

    const receiptData = await devDataAdapter.finance.getReceipt(paymentRecord.payment_id, actor);
    const students = await devDataAdapter.students.getAll();
    const student = students.find((s) => s.student_id === targetInvoice!.student_id);

    const receipt: FeeReceipt = {
      receiptNumber: receiptData?.payment.receipt_number || paymentRecord.receipt_number,
      paymentId: paymentRecord.payment_id,
      receiptDate: paymentRecord.payment_date.split('T')[0],
      studentRegistrationNumber: targetInvoice.registration_number,
      studentName: targetInvoice.student_name,
      className: student ? student.program_name : targetInvoice.programme_code || 'B.Tech CSE',
      section: student ? student.section : 'A',
      academicSession: targetInvoice.academic_year,
      feeTypeName: targetInvoice.fee_category,
      amountPaid: paymentRecord.amount,
      amountInWords: `${paymentRecord.amount} Dollars Only`,
      paymentMode: mapPaymentMethodToMode(paymentRecord.payment_method),
      transactionReference: paymentRecord.transaction_reference,
      outstandingBalanceAfterPayment: receiptData?.invoice.outstanding_balance ?? 0,
      receivedBy: data.receivedBy || actor?.userId || 'Finance Officer',
      isVoided: false,
      schoolDetails: SCHOOL_DETAILS,
    };

    const paymentItem: PaymentRecordItem = {
      id: paymentRecord.payment_id,
      studentRegistrationNumber: paymentRecord.registration_number,
      studentName: paymentRecord.student_name,
      receiptNumber: paymentRecord.receipt_number,
      feeTypeName: targetInvoice.fee_category,
      academicSession: targetInvoice.academic_year,
      amountPaid: paymentRecord.amount,
      paymentMode: mapPaymentMethodToMode(paymentRecord.payment_method),
      paymentDate: paymentRecord.payment_date.split('T')[0],
      transactionReference: paymentRecord.transaction_reference,
      receivedBy: paymentRecord.receiving_officer_id,
      isVoided: false,
      notes: paymentRecord.notes,
    };

    return { payment: paymentItem, receipt };
  },

  async voidPayment(
    paymentId: string,
    reason: string,
    voidedBy: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<DbPaymentRecord> {
    const effectiveActor = actor || { userId: voidedBy, role: 'OFFICE_ADMIN' };
    return await devDataAdapter.finance.reversePayment(paymentId, reason, effectiveActor);
  },

  async refundPayment(
    paymentId: string,
    amount: number,
    reason: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<DbPaymentRecord> {
    return await devDataAdapter.finance.refundPayment(paymentId, amount, reason, actor);
  },

  // 4. Adjustments, Waivers, Scholarships
  async waiveFee(
    assignmentOrInvoiceId: string,
    waiverAmount: number,
    reason: string,
    requestedBy: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeAdjustmentRecord> {
    const effectiveActor = actor || { userId: requestedBy, role: 'OFFICE_ADMIN' };
    const adj = await devDataAdapter.finance.requestAdjustment(
      {
        invoice_id: assignmentOrInvoiceId,
        adjustment_type: AdjustmentType.FEE_WAIVER,
        amount: waiverAmount,
        reason,
      },
      effectiveActor
    );

    // Auto-approve if permitted
    try {
      return await devDataAdapter.finance.approveAdjustment(adj.adjustment_id, 'Administrative approval', {
        userId: 'admin',
        role: 'SUPER_ADMIN',
      });
    } catch {
      return adj;
    }
  },

  async requestAdjustment(
    data: { invoice_id: string; adjustment_type: AdjustmentType; amount: number; reason: string },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeAdjustmentRecord> {
    return await devDataAdapter.finance.requestAdjustment(data, actor);
  },

  async approveAdjustment(
    adjustmentId: string,
    notes?: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeAdjustmentRecord> {
    return await devDataAdapter.finance.approveAdjustment(adjustmentId, notes, actor);
  },

  async rejectAdjustment(
    adjustmentId: string,
    reason: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeAdjustmentRecord> {
    return await devDataAdapter.finance.rejectAdjustment(adjustmentId, reason, actor);
  },

  async getAdjustments(
    filters?: { invoice_id?: string; student_id?: string; status?: AdjustmentStatus },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeAdjustmentRecord[]> {
    return await devDataAdapter.finance.getAdjustments(filters, actor);
  },

  // 5. Student Summaries & Ledgers
  async getAllStudentSummaries(): Promise<StudentFeeSummary[]> {
    const students = await devDataAdapter.students.getAll();
    const allAssignments = await this.getFeeAssignments();
    const allPayments = await this.getPayments();
    const allReceipts = await this.getReceipts();

    return students.map((s) => {
      const studentAssignments = allAssignments.filter(
        (a) => a.studentRegistrationNumber.toLowerCase() === s.registration_number.toLowerCase()
      );
      const studentPayments = allPayments.filter(
        (p) => p.studentRegistrationNumber.toLowerCase() === s.registration_number.toLowerCase()
      );
      const studentReceipts = allReceipts.filter(
        (r) => r.studentRegistrationNumber.toLowerCase() === s.registration_number.toLowerCase()
      );

      const totalDue = studentAssignments.reduce((sum, a) => sum + a.amountDue, 0);
      const totalPaid = studentAssignments.reduce((sum, a) => sum + a.amountPaid, 0);
      const totalWaived = studentAssignments.reduce((sum, a) => sum + a.discountOrWaiver, 0);
      const totalOutstanding = Math.max(0, totalDue - totalPaid - totalWaived);

      let status: 'Paid' | 'Partial' | 'Partially Paid' | 'Unpaid' | 'Overdue' = 'Unpaid';
      if (totalDue === 0) status = 'Paid';
      else if (totalOutstanding === 0) status = 'Paid';
      else if (totalPaid > 0) status = 'Partial';
      else status = 'Unpaid';

      return {
        studentRegistrationNumber: s.registration_number,
        studentName: `${s.first_name} ${s.last_name}`,
        className: s.program_name,
        programName: s.program_name,
        department: s.department,
        semester: s.current_semester,
        section: s.section,
        academicSession: '2026–2027',
        totalDue,
        totalPaid,
        totalWaived,
        totalOutstanding,
        status,
        assignments: studentAssignments,
        payments: studentPayments,
        receipts: studentReceipts,
      };
    });
  },

  async getStudentFeeSummary(studentRegNo: string): Promise<StudentFeeSummary | null> {
    const summaries = await this.getAllStudentSummaries();
    return (
      summaries.find(
        (s) => s.studentRegistrationNumber.toLowerCase() === studentRegNo.toLowerCase()
      ) || null
    );
  },

  // 6. Hostel Office Integration
  async getHostelChargeRequests(
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<HostelChargeRequestRecord[]> {
    return await devDataAdapter.hostel.getChargeRequests(undefined, actor);
  },

  async issueInvoiceForHostelCharge(
    chargeRequestId: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FeeInvoiceRecord> {
    return await devDataAdapter.finance.issueInvoiceForHostelCharge(chargeRequestId, actor);
  },

  // 7. Dashboard Metrics
  async getDashboardMetrics(
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<FinanceDashboardMetrics> {
    const dbMetrics = await devDataAdapter.finance.getFinanceDashboardMetrics(actor);
    const recentPayments = await this.getPayments();
    const recentReceipts = await this.getReceipts();
    const assignments = await this.getFeeAssignments();
    const students = await devDataAdapter.students.getAll();

    const todayStr = new Date().toISOString().split('T')[0];
    const todayCollection = recentPayments
      .filter((p) => !p.isVoided && p.paymentDate === todayStr)
      .reduce((sum, p) => sum + p.amountPaid, 0);

    // Category breakdown
    const catMap = new Map<string, { count: number; total: number }>();
    for (const a of assignments) {
      const cat = a.category || 'Tuition';
      const current = catMap.get(cat) || { count: 0, total: 0 };
      current.count++;
      current.total += a.amountPaid;
      catMap.set(cat, current);
    }

    const totalCollected = dbMetrics.totalCollected;
    const categoryCollectionBreakdown = Array.from(catMap.entries()).map(([name, data]) => ({
      name,
      count: data.count,
      total: data.total,
      percentage: totalCollected > 0 ? (data.total / totalCollected) * 100 : 0,
    }));

    // Payment mode breakdown
    const modeMap = new Map<string, { count: number; total: number }>();
    for (const p of recentPayments.filter((p) => !p.isVoided)) {
      const mode = p.paymentMode;
      const current = modeMap.get(mode) || { count: 0, total: 0 };
      current.count++;
      current.total += p.amountPaid;
      modeMap.set(mode, current);
    }

    const paymentModeBreakdown = Array.from(modeMap.entries()).map(([name, data]) => ({
      name,
      count: data.count,
      total: data.total,
      percentage: totalCollected > 0 ? (data.total / totalCollected) * 100 : 0,
    }));

    const outstandingStudentsCount = assignments.filter((a) => (a.balance ?? a.balanceDue ?? 0) > 0).length;

    return {
      totalFeesAssigned: dbMetrics.totalInvoiced,
      totalAmountCollected: dbMetrics.totalCollected,
      totalOutstanding: dbMetrics.totalOutstanding,
      totalWaived: dbMetrics.totalDiscountsApproved,
      studentsWithOutstandingCount: outstandingStudentsCount,
      totalStudentsAssignedCount: students.length,
      todayCollection,
      recentPayments: recentPayments.slice(0, 10),
      recentReceipts: recentReceipts.slice(0, 10),
      categoryCollectionBreakdown,
      paymentModeBreakdown,
    };
  },

  // 8. Audit Logs
  async getAuditLogs(): Promise<any[]> {
    const logs = await devDataAdapter.audit.getRecent();
    return logs.filter(
      (l) =>
        l.target_worksheet === 'FeeStructures' ||
        l.target_worksheet === 'FeeInvoices' ||
        l.target_worksheet === 'PaymentLedger' ||
        l.target_worksheet === 'FeeAdjustments' ||
        l.target_worksheet === 'HostelCharges' ||
        l.actor_id === 'finance'
    );
  },
};

export const financeService = financeRepository;
export default financeRepository;

