import { useState, useEffect, useCallback } from 'react';
import { devDataAdapter } from './devDataAdapter';
import { AcademicYearRecord, AcademicYearTransitionAuditRecord } from '../types/database';

/**
 * Standardizes academic year strings into consistent en-dash format (e.g. "2026–2027")
 */
export function formatAcademicYear(yearStr?: string | null): string {
  if (!yearStr) return '2026–2027';
  const clean = yearStr.trim().replace(/^AY-/, '');
  const parts = clean.split(/[-–—/]/);
  if (parts.length === 2) {
    return `${parts[0].trim()}–${parts[1].trim()}`;
  }
  return yearStr;
}

export const academicCalendarService = {
  async getActiveAcademicYear(): Promise<AcademicYearRecord> {
    return devDataAdapter.academicCalendar.getActiveAcademicYear();
  },

  async getAllAcademicYears(): Promise<AcademicYearRecord[]> {
    return devDataAdapter.academicCalendar.getAllAcademicYears();
  },

  async getAcademicYearById(yearId: string): Promise<AcademicYearRecord | null> {
    return devDataAdapter.academicCalendar.getAcademicYearById(yearId);
  },

  async createAcademicYear(
    data: {
      code: string;
      name: string;
      startDate: string;
      endDate: string;
      status?: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<AcademicYearRecord> {
    return devDataAdapter.academicCalendar.createAcademicYear(data, actor);
  },

  async updateAcademicYear(
    yearId: string,
    updates: Partial<{
      code: string;
      name: string;
      startDate: string;
      endDate: string;
      status: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
    }>,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<AcademicYearRecord> {
    return devDataAdapter.academicCalendar.updateAcademicYear(yearId, updates, actor);
  },

  async activateAcademicYear(
    yearId: string,
    reason: string,
    actor: { userId: string; role: string; name?: string; employeeId?: string }
  ): Promise<{
    success: boolean;
    activeYear: AcademicYearRecord;
    transition: AcademicYearTransitionAuditRecord;
  }> {
    return devDataAdapter.academicCalendar.activateAcademicYear(yearId, reason, actor);
  },

  async deleteAcademicYear(
    yearId: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<{ success: boolean; message: string }> {
    return devDataAdapter.academicCalendar.deleteAcademicYear(yearId, actor);
  },

  async getTransitionHistory(): Promise<AcademicYearTransitionAuditRecord[]> {
    return devDataAdapter.academicCalendar.getTransitionHistory();
  },

  subscribe(callback: (activeYear: AcademicYearRecord) => void): () => void {
    return devDataAdapter.academicCalendar.subscribeToChanges(callback);
  },
};

/**
 * Shared hook for all portal interfaces & office workspaces to retrieve and
 * subscribe to the central authoritative active academic year.
 */
export function useActiveAcademicYear() {
  const [activeYearRecord, setActiveYearRecord] = useState<AcademicYearRecord | null>(null);
  const [activeAcademicYear, setActiveAcademicYear] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCurrent = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const current = await academicCalendarService.getActiveAcademicYear();
      if (!current || !current.code) {
        throw new Error('Authoritative academic year record could not be found.');
      }
      setActiveYearRecord(current);
      setActiveAcademicYear(formatAcademicYear(current.code));
    } catch (err: any) {
      console.error('Failed to load authoritative academic year:', err);
      setError(err?.message || 'Failed to load authoritative academic year.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCurrent();

    // Subscribe to live global updates across open components
    const unsubscribe = academicCalendarService.subscribe((updatedYear) => {
      if (updatedYear && updatedYear.code) {
        setActiveYearRecord(updatedYear);
        setActiveAcademicYear(formatAcademicYear(updatedYear.code));
        setError(null);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [fetchCurrent]);

  return {
    activeAcademicYear,
    formattedYear: activeAcademicYear,
    activeYearRecord,
    isLoading,
    error,
    refresh: fetchCurrent,
  };
}
