import { devDataAdapter } from './devDataAdapter';
import {
  FFCSRegisteredCourse,
  FFCSStudentRegistration,
  FFCSRegistrationWindow,
  FFCSCourse,
  FFCSCourseOffering,
  FFCSWindowBasket,
  FFCSWindowCourse,
} from '../types/ffcs';

export const ffcsRepository = {
  async getStudentRegistrations(studentRegNo: string): Promise<FFCSStudentRegistration[]> {
    try {
      const enrolments = await devDataAdapter.academic.getEnrolments({ student_id: studentRegNo });
      const timetable = await devDataAdapter.academic.getTimetable();

      const registeredCourses: FFCSRegisteredCourse[] = enrolments.map((enr) => {
        const slot = timetable.find((t) => t.course_code === enr.course_code);
        return {
          offeringId: enr.enrolment_id,
          id: enr.enrolment_id,
          courseCode: enr.course_code,
          courseName: enr.course_title,
          credits: 4,
          slot: slot ? `${slot.day_of_week.slice(0, 3).toUpperCase()}` : 'SLOT-A',
          slotCode: slot ? `${slot.day_of_week.slice(0, 3).toUpperCase()}` : 'SLOT-A',
          timeSlotLabel: slot ? `${slot.start_time} - ${slot.end_time}` : '09:00 - 10:00',
          room: slot ? slot.room : 'Room 101',
          status: 'Registered',
          courseType: 'Core',
          category: 'Program Core',
        };
      });

      return [
        {
          registrationId: `REG-${studentRegNo}`,
          studentRegistrationNumber: studentRegNo,
          totalCredits: registeredCourses.length * 4,
          status: 'Submitted',
          registeredCourses,
        },
      ];
    } catch {
      return [];
    }
  },

  async getStudentRegistration(studentRegNo: string): Promise<FFCSStudentRegistration | null> {
    const list = await this.getStudentRegistrations(studentRegNo);
    return list[0] || null;
  },

  async getWindows(): Promise<FFCSRegistrationWindow[]> {
    return [
      {
        windowId: 'WIN-2026-FALL',
        id: 'WIN-2026-FALL',
        name: 'Fall 2026 Regular Course Registration Window',
        program: 'B.Tech CSE',
        batch: '2026-2030',
        semester: 'Semester 3',
        startDate: '2026-08-01T00:00:00Z',
        endDate: '2026-08-15T23:59:59Z',
        minCredits: 16,
        maxCredits: 27,
      },
    ];
  },

  async findMatchingWindow(_prog: string, _batch: string, _sem: string): Promise<FFCSRegistrationWindow | null> {
    const windows = await this.getWindows();
    return windows[0] || null;
  },

  async getWindowBaskets(..._args: any[]): Promise<FFCSWindowBasket[]> {
    return [
      {
        id: 'BASKET-PC',
        name: 'Program Core (PC)',
        basketCode: 'PC',
        shortCode: 'PC',
        minCredits: 12,
        maxCredits: 18,
        required: true,
        isMandatory: true,
        selectionRule: 'All Courses Compulsory',
      },
      {
        id: 'BASKET-PE',
        name: 'Program Electives (PE)',
        basketCode: 'PE',
        shortCode: 'PE',
        minCredits: 3,
        maxCredits: 8,
        required: false,
        isMandatory: false,
        selectionRule: 'Min 1 Course',
      },
      {
        id: 'BASKET-OE',
        name: 'Open Electives (OE)',
        basketCode: 'OE',
        shortCode: 'OE',
        minCredits: 0,
        maxCredits: 4,
        required: false,
        isMandatory: false,
        selectionRule: 'Optional',
      },
    ];
  },

  async getWindowCourses(..._args: any[]): Promise<FFCSWindowCourse[]> {
    const courses = await this.getCourses();
    return courses.map((c) => ({
      id: `WC-${c.courseId}`,
      windowId: _args[0] || 'WIN-2026-FALL',
      courseId: c.courseId,
      basketId: c.type === 'Core' ? 'BASKET-PC' : 'BASKET-PE',
      courseCode: c.courseCode,
      courseTitle: c.courseTitle,
      credits: c.credits,
    }));
  },

  async validateStudentBasketSelection(
    ..._args: any[]
  ): Promise<{ valid: boolean; errors: string[]; basketStatuses: any[] }> {
    return {
      valid: true,
      errors: [],
      basketStatuses: [],
    };
  },

  async getCourses(): Promise<FFCSCourse[]> {
    const courses = await devDataAdapter.academic.getCourses();
    return courses.map((c) => ({
      courseId: c.course_id,
      id: c.course_id,
      courseCode: c.course_code,
      code: c.course_code,
      courseTitle: c.course_title,
      name: c.course_title,
      credits: c.credits,
      courseType: c.course_type,
      type: c.course_type,
      department: c.department,
      description: c.description,
      program: c.department || '',
      prerequisites: [],
      coRequisites: [],
      antiRequisites: [],
    }));
  },

  async getCourseOfferings(): Promise<FFCSCourseOffering[]> {
    const offerings = await devDataAdapter.academic.getCourseOfferings();
    return offerings.map((o) => ({
      offeringId: o.offering_id,
      id: o.offering_id,
      courseCode: o.course_code,
      courseName: o.course_title,
      facultyName: o.assigned_faculty_name || o.assigned_faculty_id || 'Department Faculty',
      slot: o.section || 'A',
      slotCode: o.section || 'A',
      room: 'Academic Hall',
      credits: 4,
      registeredCount: 38,
      capacity: 60,
    }));
  },

  async getOfferings(): Promise<FFCSCourseOffering[]> {
    return this.getCourseOfferings();
  },

  async addCourseOffering(..._args: any[]): Promise<any> {
    return { success: true };
  },

  async removeCourseOffering(..._args: any[]): Promise<any> {
    return { success: true };
  },

  async changeCourseOffering(..._args: any[]): Promise<any> {
    return { success: true };
  },

  async submitRegistration(..._args: any[]): Promise<any> {
    return { success: true, status: 'Submitted' };
  },

  async withdrawCourseOffering(studentRegNo: string, offeringId: string, actor: any): Promise<void> {
    await devDataAdapter.academic.withdrawStudent(offeringId, 'Student portal course withdrawal', actor);
  },
};
