/**
 * Development Data Adapter (Phase 2 & Phase 3 Testing Layer)
 *
 * NOTE: This is a clearly separated, temporary mock data adapter for UI, workflow,
 * and role-routing testing. It DOES NOT connect to Google Sheets or require Google
 * Cloud credentials. It is NOT claimed to be production-secure.
 *
 * A real Google Sheets repository will implement the identical `IEitDataAdapter`
 * interface when all workflows are complete.
 */

import { PortalType } from '../types/portal';
import {
  AccountStatus,
  AuditAction,
  AuditLogRecord,
  AuthRole,
  AuthUserRecord,
  EmployeeCategory,
  EmployeeRecord,
  EmploymentStatus,
  FacultyCourseAssignmentRecord,
  FacultyCourseRole,
  FinanceRecord,
  HostelAllocationStatus,
  HostelRecord,
  LinkedRecordType,
  OfficeAssignmentRecord,
  OfficeAssignmentStatus,
  OfficePermissionRecord,
  ParentRecord,
  ParentRelationship,
  ParentStudentLinkRecord,
  PermanentOfficeKey,
  PermanentOfficeRecord,
  PermissionScope,
  StudentRecord,
  StudentStatus,
  AcademicRecord,
  AcademicStanding,
  AttendanceRecord,
  AttendanceStatus,
  ExaminationRecord,
  ExamStatus,
  PaymentStatus,
  ApplicantRecord,
  ApplicantDocumentRecord,
  ApplicationStatus,
  DocumentSubmissionStatus,
  DocumentVerificationStatus,
  ApplicationStatusHistoryEntry,
  AcademicYearRecord,
  AcademicYearTransitionAuditRecord,
  SystemSettingsRecord,
  SemesterRecord,
  DepartmentRecord,
  ProgrammeRecord,
  CourseRecord,
  ClassSectionRecord,
  CourseOfferingRecord,
  CourseEnrolmentRecord,
  TimetableSlotRecord,
  TimetableLifecycleStatus,
  TimetableVersionRecord,
  CsvImportBatchRecord,
  ExamType,
  ExamSessionStatus,
  ExamLifecycleStatus,
  ExamAttendanceStatus,
  ExamResultStatus,
  ExamSessionRecord,
  ExamScheduleRecord,
  ExamAttendanceEntryRecord,
  ExamMarkCorrectionRecord,
  ExamResultRecord,
  StudentEligibilityDetail,
  COEDashboardMetrics,
  StudentTranscriptSummary,
  FeeCategory,
  FeeStructureRecord,
  InvoiceStatus,
  InvoiceLineItem,
  FeeInvoiceRecord,
  PaymentMethod,
  PaymentLedgerStatus,
  PaymentRecord,
  AdjustmentType,
  AdjustmentStatus,
  FeeAdjustmentRecord,
  FinanceDashboardMetrics,
  StudentFeeStatement,
  HostelGenderType,
  RoomType,
  RoomOperationalStatus,
  BedOccupancyStatus,
  HostelBedRecord,
  HostelRoomRecord,
  HostelBlockRecord,
  HostelAllocationLifecycleStatus,
  AllocationMovementRecord,
  HostelAllocationRecord,
  HostelChargeStatus,
  HostelChargeRequestRecord,
  HostelDashboardMetrics,
  StudentHostelDetails,
} from '../types/database';
import { SIX_PERMANENT_OFFICES, getPermanentOfficeByUsername, isReservedOfficeIdentifier } from '../config/permanentOffices';
import {
  allocateNextEmployeeRegistrationNumber,
  allocateNextStudentRegistrationNumber,
  allocateNextApplicationId,
} from './regNumberGenerator';
import { AuthSession, IEitDataAdapter, LoginResult } from './dataAdapter';
import {
  BulkEnrolmentRequest,
  BulkEnrolmentPreReview,
  BulkEnrolmentResult,
  CsvImportPreviewReport,
  CsvImportValidationRow,
  TimetableValidationResult,
  TimetableConflictDetail,
} from '../types/academic';
import { proctorRepository } from './proctorService';

const DEV_STORAGE_KEY = 'eit_dev_data_v9';
const DEV_SESSION_KEY = 'eit_auth_session_v9';

interface DevStoreState {
  users: AuthUserRecord[];
  employees: EmployeeRecord[];
  facultyAssignments: FacultyCourseAssignmentRecord[];
  officeAssignments: OfficeAssignmentRecord[];
  officePermissions: OfficePermissionRecord[];
  applicants: ApplicantRecord[];
  students: StudentRecord[];
  parents: ParentRecord[];
  parentStudentLinks: ParentStudentLinkRecord[];
  finance: FinanceRecord[];
  hostel: HostelRecord[];
  auditLogs: AuditLogRecord[];
  examinations: ExaminationRecord[];
  attendance: AttendanceRecord[];
  academics: AcademicRecord[];
  academicYears: AcademicYearRecord[];
  semesters: SemesterRecord[];
  departments: DepartmentRecord[];
  programmes: ProgrammeRecord[];
  courses: CourseRecord[];
  sections: ClassSectionRecord[];
  courseOfferings: CourseOfferingRecord[];
  enrolments: CourseEnrolmentRecord[];
  timetableSlots: TimetableSlotRecord[];
  timetableVersions: TimetableVersionRecord[];
  csvImportBatches: CsvImportBatchRecord[];
  examSessions: ExamSessionRecord[];
  examSchedules: ExamScheduleRecord[];
  examAttendance: ExamAttendanceEntryRecord[];
  examResults: ExamResultRecord[];
  // Phase 9 Finance & Hostel
  feeStructures: FeeStructureRecord[];
  feeInvoices: FeeInvoiceRecord[];
  payments: PaymentRecord[];
  feeAdjustments: FeeAdjustmentRecord[];
  hostelBlocks: HostelBlockRecord[];
  hostelRooms: HostelRoomRecord[];
  hostelAllocations: HostelAllocationRecord[];
  hostelCharges: HostelChargeRequestRecord[];
  // Central Institutional Governance & Academic Calendar
  systemSettings: SystemSettingsRecord;
  academicYearTransitions: AcademicYearTransitionAuditRecord[];
}

function initializeDefaultDevState(): DevStoreState {
  const users: AuthUserRecord[] = [
    // Six Permanent Office Accounts
    {
      user_id: 'USR-PO-001',
      username: 'admin',
      password_hash: 'dev_mock_hash_admin',
      portal_type: PortalType.Employee,
      role: AuthRole.SUPER_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-001',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      user_id: 'USR-PO-002',
      username: 'admissionsoffice',
      password_hash: 'dev_mock_hash_admissions',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-002',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      user_id: 'USR-PO-003',
      username: 'academicoffice',
      password_hash: 'dev_mock_hash_academic',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-003',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      user_id: 'USR-PO-004',
      username: 'coeoffice',
      password_hash: 'dev_mock_hash_coe',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-004',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      user_id: 'USR-PO-005',
      username: 'finance',
      password_hash: 'dev_mock_hash_finance',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-005',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      user_id: 'USR-PO-006',
      username: 'hosteloffice',
      password_hash: 'dev_mock_hash_hostel',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-006',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Seventh Permanent Office: IT Department (PO-007)
    {
      user_id: 'USR-PO-007',
      username: 'itoffice',
      password_hash: 'dev_mock_hash_it',
      portal_type: PortalType.Employee,
      role: AuthRole.OFFICE_ADMIN,
      linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
      linked_record_id: 'PO-007',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Faculty User
    {
      user_id: 'USR-EMP-001',
      username: 'dr.sharma',
      password_hash: 'dev_mock_hash_faculty',
      portal_type: PortalType.Employee,
      role: AuthRole.FACULTY,
      linked_record_type: LinkedRecordType.EMPLOYEE,
      linked_record_id: 'EMP-001',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Student User
    {
      user_id: 'USR-STU-001',
      username: 'EIT-STU-2026-CSE-0001',
      password_hash: 'dev_mock_hash_student',
      portal_type: PortalType.Student,
      role: AuthRole.STUDENT,
      linked_record_type: LinkedRecordType.STUDENT,
      linked_record_id: 'STU-001',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Parent User
    {
      user_id: 'USR-PAR-001',
      username: 'rajesh.kumar',
      password_hash: 'dev_mock_hash_parent',
      portal_type: PortalType.Parent,
      role: AuthRole.PARENT,
      linked_record_type: LinkedRecordType.PARENT,
      linked_record_id: 'PAR-001',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Non-Teaching Employee: Robert Vance (Administration Officer)
    {
      user_id: 'USR-EMP-003',
      username: 'robert.vance',
      password_hash: 'dev_mock_hash_staff',
      portal_type: PortalType.Employee,
      role: AuthRole.NON_TEACHING_STAFF,
      linked_record_type: LinkedRecordType.EMPLOYEE,
      linked_record_id: 'EMP-003',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    // Non-Teaching Employee: Sunita Rao (Finance Accounts Reconciler)
    {
      user_id: 'USR-EMP-004',
      username: 'sunita.rao',
      password_hash: 'dev_mock_hash_staff',
      portal_type: PortalType.Employee,
      role: AuthRole.NON_TEACHING_STAFF,
      linked_record_type: LinkedRecordType.EMPLOYEE,
      linked_record_id: 'EMP-004',
      account_status: AccountStatus.ACTIVE,
      failed_login_attempts: 0,
      password_updated_at: '2026-01-01T00:00:00Z',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const employees: EmployeeRecord[] = [
    {
      employee_id: 'EMP-001',
      registration_number: 'EIT-TCH-CSE-2026-001',
      category: EmployeeCategory.TEACHING,
      first_name: 'Arvind',
      last_name: 'Sharma',
      institutional_email: 'arvind.sharma@eit.edu',
      phone_number: '+1 (555) 234-5678',
      primary_department: 'CSE',
      designation: 'Professor & Head of CSE',
      employment_status: EmploymentStatus.ACTIVE,
      date_of_joining: '2022-08-01',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      employee_id: 'EMP-002',
      registration_number: 'EIT-TCH-ECE-2026-002',
      category: EmployeeCategory.TEACHING,
      first_name: 'Priya',
      last_name: 'Menon',
      institutional_email: 'priya.menon@eit.edu',
      phone_number: '+1 (555) 345-6789',
      primary_department: 'ECE',
      designation: 'Associate Professor',
      employment_status: EmploymentStatus.ACTIVE,
      date_of_joining: '2023-01-15',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      employee_id: 'EMP-003',
      registration_number: 'EIT-NTC-ADM-2026-001',
      category: EmployeeCategory.NON_TEACHING,
      first_name: 'Robert',
      last_name: 'Vance',
      institutional_email: 'robert.vance@eit.edu',
      phone_number: '+1 (555) 456-7890',
      primary_department: 'ADM',
      designation: 'Senior Registrar & Admin Officer',
      employment_status: EmploymentStatus.ACTIVE,
      date_of_joining: '2021-05-10',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      employee_id: 'EMP-004',
      registration_number: 'EIT-NTC-FIN-2026-002',
      category: EmployeeCategory.NON_TEACHING,
      first_name: 'Sunita',
      last_name: 'Rao',
      institutional_email: 'sunita.rao@eit.edu',
      phone_number: '+1 (555) 567-8901',
      primary_department: 'FIN',
      designation: 'Accounts Executive',
      employment_status: EmploymentStatus.ACTIVE,
      date_of_joining: '2023-09-01',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const facultyAssignments: FacultyCourseAssignmentRecord[] = [
    {
      faculty_assignment_id: 'FCA-2026-001',
      employee_id: 'EMP-001',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      department: 'CSE',
      semester: 3,
      academic_year: '2026-2027',
      section: 'A',
      role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
      assignment_status: 'ACTIVE',
      assigned_by_office_id: 'PO-003',
      effective_from: '2026-08-01',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      faculty_assignment_id: 'FCA-2026-002',
      employee_id: 'EMP-002',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      department: 'ECE',
      semester: 4,
      academic_year: '2026-2027',
      section: 'B',
      role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
      assignment_status: 'ACTIVE',
      assigned_by_office_id: 'PO-003',
      effective_from: '2026-08-01',
      created_at: '2026-08-01T00:00:00Z',
    },
  ];

  const officeAssignments: OfficeAssignmentRecord[] = [
    {
      assignment_id: 'OAS-2026-001',
      employee_id: 'EMP-003',
      office_id: 'PO-001',
      assigned_role_title: 'Administration Officer',
      assignment_status: OfficeAssignmentStatus.ACTIVE,
      assigned_by_employee_id: 'EMP-003',
      effective_from: '2026-01-01',
      created_at: '2026-01-01T00:00:00Z',
    },
    {
      assignment_id: 'OAS-2026-002',
      employee_id: 'EMP-004',
      office_id: 'PO-005',
      assigned_role_title: 'Accounts Reconciler',
      assignment_status: OfficeAssignmentStatus.ACTIVE,
      assigned_by_employee_id: 'EMP-003',
      effective_from: '2026-01-01',
      created_at: '2026-01-01T00:00:00Z',
    },
    {
      assignment_id: 'OAS-2026-003',
      employee_id: 'EMP-003',
      office_id: 'PO-007',
      assigned_role_title: 'Senior Systems Administrator',
      assignment_status: OfficeAssignmentStatus.ACTIVE,
      assigned_by_employee_id: 'EMP-003',
      effective_from: '2026-01-01',
      created_at: '2026-01-01T00:00:00Z',
    },
  ];

  const officePermissions: OfficePermissionRecord[] = [
    {
      permission_id: 'OPM-2026-001',
      assignment_id: 'OAS-2026-002',
      office_id: 'PO-005',
      employee_id: 'EMP-004',
      module_name: 'FeeCollections',
      permission_scope: PermissionScope.WRITE,
      granted_by_employee_id: 'EMP-003',
      granted_at: '2026-01-01T00:00:00Z',
      status: 'ACTIVE',
    },
    {
      permission_id: 'OPM-2026-002',
      assignment_id: 'OAS-2026-001',
      office_id: 'PO-001',
      employee_id: 'EMP-003',
      module_name: 'StaffAssignments',
      permission_scope: PermissionScope.READ,
      granted_by_employee_id: 'USR-PO-001',
      granted_at: '2026-01-01T00:00:00Z',
      status: 'ACTIVE',
    },
  ];

  const students: StudentRecord[] = [
    {
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      first_name: 'Arjun',
      last_name: 'Kumar',
      date_of_birth: '2005-04-12',
      gender: 'MALE',
      institutional_email: 'arjun.kumar@student.eit.edu',
      personal_phone: '+1 (555) 789-0123',
      program_name: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      current_semester: 3,
      section: 'A',
      enrollment_status: StudentStatus.ENROLLED,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      first_name: 'Neha',
      last_name: 'Verma',
      date_of_birth: '2005-09-20',
      gender: 'FEMALE',
      institutional_email: 'neha.verma@student.eit.edu',
      personal_phone: '+1 (555) 890-1234',
      program_name: 'B.Tech Electronics & Communication',
      department: 'ECE',
      admission_year: 2026,
      current_semester: 3,
      section: 'B',
      enrollment_status: StudentStatus.ENROLLED,
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const parents: ParentRecord[] = [
    {
      parent_id: 'PAR-001',
      first_name: 'Rajesh',
      last_name: 'Kumar',
      email: 'rajesh.kumar@example.com',
      primary_phone: '+1 (555) 901-2345',
      residential_address: '42 Academic Way, Cambridge, MA',
      status: 'ACTIVE',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const parentStudentLinks: ParentStudentLinkRecord[] = [
    {
      link_id: 'PSL-2026-001',
      parent_id: 'PAR-001',
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      relationship: ParentRelationship.FATHER,
      is_primary_contact: true,
      can_view_grades: true,
      can_view_attendance: true,
      can_view_finance: true,
      emergency_priority: 1,
      status: 'ACTIVE',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const finance: FinanceRecord[] = [
    {
      invoice_id: 'INV-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      fee_category: 'TUITION',
      academic_year: '2026-2027',
      semester: 3,
      amount_due: 3500.0,
      amount_paid: 3500.0,
      currency: 'USD',
      payment_status: PaymentStatus.PAID,
      transaction_reference: 'TXN-9847291',
      payment_method: 'ONLINE_GATEWAY',
      payment_date: '2026-08-10T14:30:00Z',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-10T14:30:00Z',
    },
    {
      invoice_id: 'INV-2026-002',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      fee_category: 'HOSTEL',
      academic_year: '2026-2027',
      semester: 3,
      amount_due: 1200.0,
      amount_paid: 1200.0,
      currency: 'USD',
      payment_status: PaymentStatus.PAID,
      transaction_reference: 'TXN-9847292',
      payment_method: 'BANK_TRANSFER',
      payment_date: '2026-08-11T10:15:00Z',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-11T10:15:00Z',
    },
    {
      invoice_id: 'INV-2026-003',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      fee_category: 'TUITION',
      academic_year: '2026-2027',
      semester: 3,
      amount_due: 3500.0,
      amount_paid: 1750.0,
      currency: 'USD',
      payment_status: PaymentStatus.PARTIAL,
      transaction_reference: 'TXN-9847295',
      payment_method: 'ONLINE_GATEWAY',
      payment_date: '2026-08-15T09:20:00Z',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-15T09:20:00Z',
    },
  ];

  const hostel: HostelRecord[] = [
    {
      allocation_id: 'HST-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      hostel_block_name: 'Block A - Aryabhata Hall',
      room_number: '304',
      bed_identifier: 'A',
      status: HostelAllocationStatus.OCCUPIED,
      check_in_date: '2026-08-15',
      allocated_by_employee_id: 'EMP-003',
      approved_by_office_id: 'PO-006',
      emergency_contact_phone: '+1 (555) 901-2345',
      created_at: '2026-08-10T00:00:00Z',
    },
    {
      allocation_id: 'HST-2026-002',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      hostel_block_name: 'Block B - Ramanujan Hall',
      room_number: '208',
      bed_identifier: 'B',
      status: HostelAllocationStatus.OCCUPIED,
      check_in_date: '2026-08-16',
      allocated_by_employee_id: 'EMP-003',
      approved_by_office_id: 'PO-006',
      emergency_contact_phone: '+1 (555) 890-1234',
      created_at: '2026-08-10T00:00:00Z',
    },
  ];

  const auditLogs: AuditLogRecord[] = [
    {
      log_id: 'LOG-001',
      timestamp: '2026-10-25T08:00:00Z',
      actor_id: 'admin',
      actor_role: 'SUPER_ADMIN',
      action: AuditAction.CREATE,
      target_worksheet: 'PermanentOffices',
      target_record_id: 'PO-001',
      description: 'System seeded with the six permanent institutional offices.',
    },
  ];

  const academics: AcademicRecord[] = [
    {
      record_id: 'ACR-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      semester: 3,
      academic_year: '2026-2027',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      credits: 4,
      grade_point: 9.5,
      letter_grade: 'A+',
      sgpa: 9.25,
      cgpa: 9.12,
      academic_standing: AcademicStanding.DEANS_LIST,
      published_by_office_id: 'PO-004',
      updated_at: '2026-10-15T00:00:00Z',
    },
    {
      record_id: 'ACR-2026-002',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      semester: 3,
      academic_year: '2026-2027',
      course_code: 'CS202',
      course_title: 'Computer Architecture & Organization',
      credits: 4,
      grade_point: 9.0,
      letter_grade: 'A',
      sgpa: 9.25,
      cgpa: 9.12,
      academic_standing: AcademicStanding.DEANS_LIST,
      published_by_office_id: 'PO-004',
      updated_at: '2026-10-15T00:00:00Z',
    },
    {
      record_id: 'ACR-2026-003',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      semester: 3,
      academic_year: '2026-2027',
      course_code: 'MA201',
      course_title: 'Discrete Mathematics & Probability',
      credits: 3,
      grade_point: 8.5,
      letter_grade: 'B+',
      sgpa: 9.25,
      cgpa: 9.12,
      academic_standing: AcademicStanding.DEANS_LIST,
      published_by_office_id: 'PO-004',
      updated_at: '2026-10-15T00:00:00Z',
    },
    {
      record_id: 'ACR-2026-004',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      semester: 3,
      academic_year: '2026-2027',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      credits: 4,
      grade_point: 8.8,
      letter_grade: 'A-',
      sgpa: 8.8,
      cgpa: 8.75,
      academic_standing: AcademicStanding.GOOD_STANDING,
      published_by_office_id: 'PO-004',
      updated_at: '2026-10-15T00:00:00Z',
    },
  ];

  const attendance: AttendanceRecord[] = [
    {
      attendance_id: 'ATT-2026-001',
      date: '2026-10-24',
      course_code: 'CS201',
      session_slot: '09:00 - 10:00 AM',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      status: AttendanceStatus.PRESENT,
      recorded_by_employee_id: 'EMP-001',
      created_at: '2026-10-24T09:15:00Z',
    },
    {
      attendance_id: 'ATT-2026-002',
      date: '2026-10-23',
      course_code: 'CS201',
      session_slot: '09:00 - 10:00 AM',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      status: AttendanceStatus.PRESENT,
      recorded_by_employee_id: 'EMP-001',
      created_at: '2026-10-23T09:10:00Z',
    },
    {
      attendance_id: 'ATT-2026-003',
      date: '2026-10-22',
      course_code: 'MA201',
      session_slot: '11:00 - 12:00 PM',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      status: AttendanceStatus.LATE,
      recorded_by_employee_id: 'EMP-002',
      remarks: 'Arrived 10 minutes late due to transit',
      created_at: '2026-10-22T11:12:00Z',
    },
    {
      attendance_id: 'ATT-2026-004',
      date: '2026-10-21',
      course_code: 'CS201',
      session_slot: '09:00 - 10:00 AM',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      status: AttendanceStatus.PRESENT,
      recorded_by_employee_id: 'EMP-001',
      created_at: '2026-10-21T09:05:00Z',
    },
  ];

  const examinations: ExaminationRecord[] = [
    {
      exam_id: 'EXM-2026-001',
      exam_session: 'MID_SEM_FALL_2026',
      course_code: 'CS201',
      student_id: 'STU-001',
      hall_ticket_number: 'HT-FALL26-0042',
      internal_marks: 38,
      external_marks: 54,
      total_marks: 92,
      max_marks: 100,
      exam_status: ExamStatus.DECLARED,
      evaluated_by_employee_id: 'EMP-001',
      moderated_by_office_id: 'PO-004',
      published_at: '2026-10-15T00:00:00Z',
    },
    {
      exam_id: 'EXM-2026-002',
      exam_session: 'MID_SEM_FALL_2026',
      course_code: 'CS202',
      student_id: 'STU-001',
      hall_ticket_number: 'HT-FALL26-0042',
      internal_marks: 35,
      external_marks: 52,
      total_marks: 87,
      max_marks: 100,
      exam_status: ExamStatus.DECLARED,
      evaluated_by_employee_id: 'EMP-001',
      moderated_by_office_id: 'PO-004',
      published_at: '2026-10-15T00:00:00Z',
    },
    {
      exam_id: 'EXM-2026-003',
      exam_session: 'MID_SEM_FALL_2026',
      course_code: 'EC304',
      student_id: 'STU-002',
      hall_ticket_number: 'HT-FALL26-0089',
      internal_marks: 34,
      external_marks: 48,
      total_marks: 82,
      max_marks: 100,
      exam_status: ExamStatus.WITHHELD,
      evaluated_by_employee_id: 'EMP-002',
      moderated_by_office_id: 'PO-004',
      published_at: '2026-10-15T00:00:00Z',
    },
  ];

  const applicants: ApplicantRecord[] = [
    {
      application_id: 'EIT-APP-2026-0001',
      first_name: 'Rohan',
      last_name: 'Verma',
      date_of_birth: '2006-03-15',
      gender: 'MALE',
      email: 'rohan.verma@example.com',
      phone_number: '+1 (555) 342-9988',
      address: '104 Lakeview Enclave, Tech Park Road',
      intended_program: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      previous_qualification: 'CBSE Class XII Science (PCM)',
      marks_percentage: 92.5,
      application_date: '2026-08-10',
      application_status: ApplicationStatus.APPROVED,
      documents: [
        {
          document_id: 'DOC-APP-001-1',
          application_id: 'EIT-APP-2026-0001',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Original board marksheet verified with QR digest.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-12T10:00:00Z',
        },
        {
          document_id: 'DOC-APP-001-2',
          application_id: 'EIT-APP-2026-0001',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Science / Math cutoff 94% verified.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-12T10:15:00Z',
        },
        {
          document_id: 'DOC-APP-001-3',
          application_id: 'EIT-APP-2026-0001',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'School counter-signed transfer certificate received.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-12T10:20:00Z',
        },
        {
          document_id: 'DOC-APP-001-4',
          application_id: 'EIT-APP-2026-0001',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Identity confirmed via passport ID verification.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-12T10:25:00Z',
        },
        {
          document_id: 'DOC-APP-001-5',
          application_id: 'EIT-APP-2026-0001',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Good conduct certificate.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-12T10:30:00Z',
        },
      ],
      status_history: [
        {
          history_id: 'HST-001-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-08-10T09:00:00Z',
          reason: 'Initial submission with preliminary credentials',
        },
        {
          history_id: 'HST-001-2',
          previous_status: ApplicationStatus.SUBMITTED,
          new_status: ApplicationStatus.UNDER_REVIEW,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-11T14:30:00Z',
          reason: 'Application taken up for admissions committee review',
        },
        {
          history_id: 'HST-001-3',
          previous_status: ApplicationStatus.UNDER_REVIEW,
          new_status: ApplicationStatus.APPROVED,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-12T11:00:00Z',
          reason: 'All credentials verified and merit criteria met.',
        },
      ],
      review_notes: 'Excellent academic record; merit scholarship recommended.',
      reviewed_by: 'admissionsoffice',
      reviewed_at: '2026-08-12T11:00:00Z',
      converted_to_student: false,
      created_at: '2026-08-10T09:00:00Z',
      updated_at: '2026-08-12T11:00:00Z',
    },
    {
      application_id: 'EIT-APP-2026-0002',
      first_name: 'Ananya',
      last_name: 'Sen',
      date_of_birth: '2006-07-22',
      gender: 'FEMALE',
      email: 'ananya.sen@example.com',
      phone_number: '+1 (555) 456-7812',
      address: 'Flat 4B, Emerald Heights, MG Road',
      intended_program: 'B.Tech Electronics & Communication',
      department: 'ECE',
      admission_year: 2026,
      previous_qualification: 'ISC Board XII Science',
      marks_percentage: 89.0,
      application_date: '2026-08-14',
      application_status: ApplicationStatus.UNDER_REVIEW,
      documents: [
        {
          document_id: 'DOC-APP-002-1',
          application_id: 'EIT-APP-2026-0002',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Verified against ISC portal.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-15T11:00:00Z',
        },
        {
          document_id: 'DOC-APP-002-2',
          application_id: 'EIT-APP-2026-0002',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Math & Physics marks verified.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-15T11:10:00Z',
        },
        {
          document_id: 'DOC-APP-002-3',
          application_id: 'EIT-APP-2026-0002',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
          reviewer_notes: 'Awaiting counter-signature check.',
        },
        {
          document_id: 'DOC-APP-002-4',
          application_id: 'EIT-APP-2026-0002',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Photo ID verified.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-15T11:20:00Z',
        },
        {
          document_id: 'DOC-APP-002-5',
          application_id: 'EIT-APP-2026-0002',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
      ],
      status_history: [
        {
          history_id: 'HST-002-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-08-14T10:15:00Z',
          reason: 'Application submitted',
        },
        {
          history_id: 'HST-002-2',
          previous_status: ApplicationStatus.SUBMITTED,
          new_status: ApplicationStatus.UNDER_REVIEW,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-15T09:30:00Z',
          reason: 'Admissions staff reviewing documents',
        },
      ],
      review_notes: 'Candidate eligible; waiting on migration certificate verification.',
      reviewed_by: 'admissionsoffice',
      reviewed_at: '2026-08-15T09:30:00Z',
      converted_to_student: false,
      created_at: '2026-08-14T10:15:00Z',
      updated_at: '2026-08-15T09:30:00Z',
    },
    {
      application_id: 'EIT-APP-2026-0003',
      first_name: 'Kavita',
      last_name: 'Reddy',
      date_of_birth: '2005-11-05',
      gender: 'FEMALE',
      email: 'kavita.reddy@example.com',
      phone_number: '+1 (555) 678-1234',
      address: '28 Jubilee Hills, Sector 4',
      intended_program: 'B.Tech Mechanical Engineering',
      department: 'MECH',
      admission_year: 2026,
      previous_qualification: 'State Higher Secondary Board (HSC)',
      marks_percentage: 84.5,
      application_date: '2026-08-20',
      application_status: ApplicationStatus.DOCUMENTS_PENDING,
      documents: [
        {
          document_id: 'DOC-APP-003-1',
          application_id: 'EIT-APP-2026-0003',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
          reviewer_notes: 'Missing 10th grade marksheet; requested from applicant.',
        },
        {
          document_id: 'DOC-APP-003-2',
          application_id: 'EIT-APP-2026-0003',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'HSC marksheet verified.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-21T14:00:00Z',
        },
        {
          document_id: 'DOC-APP-003-3',
          application_id: 'EIT-APP-2026-0003',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.REJECTED,
          reviewer_notes: 'Document lacks official institutional seal. Re-submission required.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-21T14:15:00Z',
        },
        {
          document_id: 'DOC-APP-003-4',
          application_id: 'EIT-APP-2026-0003',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          reviewer_notes: 'Aadhaar copy verified.',
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-21T14:20:00Z',
        },
        {
          document_id: 'DOC-APP-003-5',
          application_id: 'EIT-APP-2026-0003',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
      ],
      status_history: [
        {
          history_id: 'HST-003-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-08-20T11:00:00Z',
          reason: 'Application submitted online',
        },
        {
          history_id: 'HST-003-2',
          previous_status: ApplicationStatus.SUBMITTED,
          new_status: ApplicationStatus.UNDER_REVIEW,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-21T10:00:00Z',
          reason: 'Scrutiny started',
        },
        {
          history_id: 'HST-003-3',
          previous_status: ApplicationStatus.UNDER_REVIEW,
          new_status: ApplicationStatus.DOCUMENTS_PENDING,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-21T14:30:00Z',
          reason: 'Transfer certificate rejected and 10th marksheet pending',
        },
      ],
      review_notes: 'Notification queued to candidate to re-upload sealed transfer certificate.',
      reviewed_by: 'admissionsoffice',
      reviewed_at: '2026-08-21T14:30:00Z',
      converted_to_student: false,
      created_at: '2026-08-20T11:00:00Z',
      updated_at: '2026-08-21T14:30:00Z',
    },
    {
      application_id: 'EIT-APP-2026-0004',
      first_name: 'Aditya',
      last_name: 'Joshi',
      date_of_birth: '2006-01-30',
      gender: 'MALE',
      email: 'aditya.joshi@example.com',
      phone_number: '+1 (555) 890-4321',
      address: '56 Orchid Boulevard, Pune Expressway',
      intended_program: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      previous_qualification: 'CBSE Class XII Science (PCM)',
      marks_percentage: 95.2,
      application_date: '2026-09-01',
      application_status: ApplicationStatus.SUBMITTED,
      documents: [
        {
          document_id: 'DOC-APP-004-1',
          application_id: 'EIT-APP-2026-0004',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: 'DOC-APP-004-2',
          application_id: 'EIT-APP-2026-0004',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: 'DOC-APP-004-3',
          application_id: 'EIT-APP-2026-0004',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: 'DOC-APP-004-4',
          application_id: 'EIT-APP-2026-0004',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: 'DOC-APP-004-5',
          application_id: 'EIT-APP-2026-0004',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.PENDING,
        },
      ],
      status_history: [
        {
          history_id: 'HST-004-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-09-01T15:20:00Z',
          reason: 'Initial submission completed',
        },
      ],
      converted_to_student: false,
      created_at: '2026-09-01T15:20:00Z',
      updated_at: '2026-09-01T15:20:00Z',
    },
    {
      application_id: 'EIT-APP-2026-0005',
      first_name: 'Pooja',
      last_name: 'Hegde',
      date_of_birth: '2006-08-12',
      gender: 'FEMALE',
      email: 'pooja.hegde@example.com',
      phone_number: '+1 (555) 234-8765',
      address: '12 Residency Road, Civil Lines',
      intended_program: 'B.Tech Electronics & Communication',
      department: 'ECE',
      admission_year: 2026,
      previous_qualification: 'State Secondary Certificate',
      marks_percentage: 52.0,
      application_date: '2026-08-25',
      application_status: ApplicationStatus.REJECTED,
      documents: [
        {
          document_id: 'DOC-APP-005-1',
          application_id: 'EIT-APP-2026-0005',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-26T10:00:00Z',
        },
        {
          document_id: 'DOC-APP-005-2',
          application_id: 'EIT-APP-2026-0005',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-26T10:05:00Z',
        },
        {
          document_id: 'DOC-APP-005-3',
          application_id: 'EIT-APP-2026-0005',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-26T10:10:00Z',
        },
        {
          document_id: 'DOC-APP-005-4',
          application_id: 'EIT-APP-2026-0005',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-26T10:15:00Z',
        },
        {
          document_id: 'DOC-APP-005-5',
          application_id: 'EIT-APP-2026-0005',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-08-26T10:20:00Z',
        },
      ],
      status_history: [
        {
          history_id: 'HST-005-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-08-25T12:00:00Z',
          reason: 'Application submitted',
        },
        {
          history_id: 'HST-005-2',
          previous_status: ApplicationStatus.SUBMITTED,
          new_status: ApplicationStatus.UNDER_REVIEW,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-26T09:45:00Z',
          reason: 'Review initiated',
        },
        {
          history_id: 'HST-005-3',
          previous_status: ApplicationStatus.UNDER_REVIEW,
          new_status: ApplicationStatus.REJECTED,
          changed_by: 'admissionsoffice',
          timestamp: '2026-08-26T11:00:00Z',
          reason: 'Candidate aggregate percentage (52%) is below the minimum institutional eligibility threshold (60%).',
        },
      ],
      decision_reason: 'Candidate aggregate percentage (52%) is below the minimum institutional eligibility threshold (60%).',
      reviewed_by: 'admissionsoffice',
      reviewed_at: '2026-08-26T11:00:00Z',
      converted_to_student: false,
      created_at: '2026-08-25T12:00:00Z',
      updated_at: '2026-08-26T11:00:00Z',
    },
    {
      application_id: 'EIT-APP-2026-0006',
      first_name: 'Arjun',
      last_name: 'Kumar',
      date_of_birth: '2005-04-12',
      gender: 'MALE',
      email: 'arjun.applicant@example.com',
      phone_number: '+1 (555) 789-0123',
      address: '42 Green Glen Layout, Outer Ring Road',
      intended_program: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      admission_year: 2026,
      previous_qualification: 'CBSE Class XII Science',
      marks_percentage: 96.5,
      application_date: '2026-07-15',
      application_status: ApplicationStatus.APPROVED,
      documents: [
        {
          document_id: 'DOC-APP-006-1',
          application_id: 'EIT-APP-2026-0006',
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-07-16T10:00:00Z',
        },
        {
          document_id: 'DOC-APP-006-2',
          application_id: 'EIT-APP-2026-0006',
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-07-16T10:10:00Z',
        },
        {
          document_id: 'DOC-APP-006-3',
          application_id: 'EIT-APP-2026-0006',
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-07-16T10:15:00Z',
        },
        {
          document_id: 'DOC-APP-006-4',
          application_id: 'EIT-APP-2026-0006',
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-07-16T10:20:00Z',
        },
        {
          document_id: 'DOC-APP-006-5',
          application_id: 'EIT-APP-2026-0006',
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.SUBMITTED,
          verification_status: DocumentVerificationStatus.VERIFIED,
          verified_by: 'admissionsoffice',
          verified_at: '2026-07-16T10:25:00Z',
        },
      ],
      status_history: [
        {
          history_id: 'HST-006-1',
          previous_status: ApplicationStatus.DRAFT,
          new_status: ApplicationStatus.SUBMITTED,
          changed_by: 'applicant',
          timestamp: '2026-07-15T10:00:00Z',
          reason: 'Application submitted',
        },
        {
          history_id: 'HST-006-2',
          previous_status: ApplicationStatus.SUBMITTED,
          new_status: ApplicationStatus.UNDER_REVIEW,
          changed_by: 'admissionsoffice',
          timestamp: '2026-07-16T09:00:00Z',
          reason: 'Review commenced',
        },
        {
          history_id: 'HST-006-3',
          previous_status: ApplicationStatus.UNDER_REVIEW,
          new_status: ApplicationStatus.APPROVED,
          changed_by: 'admissionsoffice',
          timestamp: '2026-07-16T11:00:00Z',
          reason: 'Approved for admission',
        },
      ],
      review_notes: 'Admitted in CSE cohort 2026.',
      reviewed_by: 'admissionsoffice',
      reviewed_at: '2026-07-16T11:00:00Z',
      converted_to_student: true,
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      created_at: '2026-07-15T10:00:00Z',
      updated_at: '2026-07-16T12:00:00Z',
    },
  ];

  const academicYears: AcademicYearRecord[] = [
    {
      year_id: 'AY-2025-2026',
      code: '2025-2026',
      name: 'Academic Year 2025–2026',
      start_date: '2025-08-01',
      end_date: '2026-05-31',
      is_current: false,
      status: 'ARCHIVED',
    },
    {
      year_id: 'AY-2026-2027',
      code: '2026-2027',
      name: 'Academic Year 2026–2027',
      start_date: '2026-08-01',
      end_date: '2027-05-31',
      is_current: true,
      status: 'ACTIVE',
    },
    {
      year_id: 'AY-2027-2028',
      code: '2027-2028',
      name: 'Academic Year 2027–2028',
      start_date: '2027-08-01',
      end_date: '2028-05-31',
      is_current: false,
      status: 'UPCOMING',
    },
  ];

  const systemSettings: SystemSettingsRecord = {
    institution_name: 'Electrix Institute of Technology (EIT)',
    campus_code: 'EIT-BOS',
    campus_address: '1000 Academic Parkway, Boston, MA 02115',
    contact_phone: '+1 (555) 019-2830',
    contact_email: 'administration@eit.edu',
    active_academic_year_code: '2026-2027',
    active_academic_year_id: 'AY-2026-2027',
    session_timeout: '60',
    password_min_length: '8',
    updated_at: '2026-08-01T00:00:00Z',
    updated_by: 'admin',
  };

  const academicYearTransitions: AcademicYearTransitionAuditRecord[] = [
    {
      transition_id: 'AYT-INIT-001',
      previous_year_code: '2025-2026',
      new_year_code: '2026-2027',
      activated_by_user_id: 'admin',
      activated_by_name: 'Institutional Administrator',
      activated_by_role: 'SUPER_ADMIN',
      timestamp: '2026-08-01T00:00:00Z',
      reason: 'Initial institutional activation of Academic Year 2026–2027.',
      status: 'SUCCESS',
    },
  ];


  const semesters: SemesterRecord[] = [
    {
      semester_id: 'SEM-2026-F3',
      academic_year: '2026-2027',
      semester_number: 3,
      term: 'FALL',
      name: 'Fall 2026 (Semester 3)',
      start_date: '2026-08-01',
      end_date: '2026-12-15',
      is_current: true,
      status: 'ACTIVE',
    },
    {
      semester_id: 'SEM-2027-S4',
      academic_year: '2026-2027',
      semester_number: 4,
      term: 'SPRING',
      name: 'Spring 2027 (Semester 4)',
      start_date: '2027-01-05',
      end_date: '2027-05-20',
      is_current: false,
      status: 'ACTIVE',
    },
  ];

  const departments: DepartmentRecord[] = [
    { department_id: 'DEPT-CSE', code: 'CSE', name: 'Computer Science & Engineering', head_of_department_id: 'EMP-001', status: 'ACTIVE' },
    { department_id: 'DEPT-ECE', code: 'ECE', name: 'Electronics & Communication Engineering', head_of_department_id: 'EMP-002', status: 'ACTIVE' },
    { department_id: 'DEPT-MECH', code: 'MECH', name: 'Mechanical Engineering', status: 'ACTIVE' },
    { department_id: 'DEPT-EEE', code: 'EEE', name: 'Electrical & Electronics Engineering', status: 'ACTIVE' },
    { department_id: 'DEPT-CIVIL', code: 'CIVIL', name: 'Civil Engineering', status: 'ACTIVE' },
  ];

  const programmes: ProgrammeRecord[] = [
    {
      programme_id: 'PROG-BTECH-CSE',
      code: 'BTECH-CSE',
      name: 'B.Tech Computer Science & Engineering',
      department: 'CSE',
      degree_level: 'UNDERGRADUATE',
      duration_semesters: 8,
      total_credits_required: 160,
      status: 'ACTIVE',
    },
    {
      programme_id: 'PROG-BTECH-ECE',
      code: 'BTECH-ECE',
      name: 'B.Tech Electronics & Communication',
      department: 'ECE',
      degree_level: 'UNDERGRADUATE',
      duration_semesters: 8,
      total_credits_required: 160,
      status: 'ACTIVE',
    },
    {
      programme_id: 'PROG-BTECH-MECH',
      code: 'BTECH-MECH',
      name: 'B.Tech Mechanical Engineering',
      department: 'MECH',
      degree_level: 'UNDERGRADUATE',
      duration_semesters: 8,
      total_credits_required: 160,
      status: 'ACTIVE',
    },
  ];

  const courses: CourseRecord[] = [
    {
      course_id: 'CRS-CS201',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      semester: 3,
      credits: 4,
      course_type: 'INTEGRATED',
      description: 'Core fundamental algorithms, complexity analysis, trees, graphs, and dynamic programming.',
      status: 'ACTIVE',
    },
    {
      course_id: 'CRS-CS301',
      course_code: 'CS301',
      course_title: 'Database Management Systems',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      semester: 3,
      credits: 4,
      course_type: 'THEORY',
      description: 'Relational algebra, SQL, normalization, concurrency control, and index structures.',
      status: 'ACTIVE',
    },
    {
      course_id: 'CRS-EC304',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      department: 'ECE',
      programme_code: 'BTECH-ECE',
      semester: 3,
      credits: 4,
      course_type: 'THEORY',
      description: 'Continuous and discrete-time signals, Fourier transforms, Laplace transforms, and z-transforms.',
      status: 'ACTIVE',
    },
    {
      course_id: 'CRS-ME202',
      course_code: 'ME202',
      course_title: 'Applied Thermodynamics',
      department: 'MECH',
      programme_code: 'BTECH-MECH',
      semester: 3,
      credits: 3,
      course_type: 'THEORY',
      description: 'First and second laws of thermodynamics, entropy, power cycles, and refrigeration.',
      status: 'ACTIVE',
    },
  ];

  const sections: ClassSectionRecord[] = [
    {
      section_id: 'SEC-CSE-3A',
      section_name: 'A',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      max_capacity: 60,
      status: 'ACTIVE',
    },
    {
      section_id: 'SEC-CSE-3B',
      section_name: 'B',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      max_capacity: 60,
      status: 'ACTIVE',
    },
    {
      section_id: 'SEC-ECE-3A',
      section_name: 'A',
      department: 'ECE',
      programme_code: 'BTECH-ECE',
      academic_year: '2026-2027',
      semester: 3,
      max_capacity: 60,
      status: 'ACTIVE',
    },
  ];

  const courseOfferings: CourseOfferingRecord[] = [
    {
      offering_id: 'OFF-2026-CS201-A',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      section: 'A',
      assigned_faculty_id: 'EMP-001',
      assigned_faculty_reg: 'EIT-TCH-CSE-2026-001',
      assigned_faculty_name: 'Arvind Sharma',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      offering_id: 'OFF-2026-CS201-B',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      section: 'B',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      offering_id: 'OFF-2026-CS301-A',
      course_code: 'CS301',
      course_title: 'Database Management Systems',
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      section: 'A',
      assigned_faculty_id: 'EMP-001',
      assigned_faculty_reg: 'EIT-TCH-CSE-2026-001',
      assigned_faculty_name: 'Arvind Sharma',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      offering_id: 'OFF-2026-EC304-A',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      department: 'ECE',
      programme_code: 'BTECH-ECE',
      academic_year: '2026-2027',
      semester: 3,
      section: 'A',
      assigned_faculty_id: 'EMP-002',
      assigned_faculty_reg: 'EIT-TCH-ECE-2026-002',
      assigned_faculty_name: 'Priya Menon',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
  ];

  const enrolments: CourseEnrolmentRecord[] = [
    {
      enrolment_id: 'ENR-2026-0001',
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Arjun Kumar',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      offering_id: 'OFF-2026-CS201-A',
      department: 'CSE',
      semester: 3,
      academic_year: '2026-2027',
      section: 'A',
      enrolment_status: 'ACTIVE',
      enrolled_at: '2026-08-10T09:00:00Z',
      updated_at: '2026-08-10T09:00:00Z',
    },
    {
      enrolment_id: 'ENR-2026-0002',
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Arjun Kumar',
      course_code: 'CS301',
      course_title: 'Database Management Systems',
      offering_id: 'OFF-2026-CS301-A',
      department: 'CSE',
      semester: 3,
      academic_year: '2026-2027',
      section: 'A',
      enrolment_status: 'ACTIVE',
      enrolled_at: '2026-08-10T09:15:00Z',
      updated_at: '2026-08-10T09:15:00Z',
    },
    {
      enrolment_id: 'ENR-2026-0003',
      student_id: 'STU-002',
      student_registration_number: 'EIT-STU-2026-ECE-0002',
      student_name: 'Neha Verma',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      offering_id: 'OFF-2026-EC304-A',
      department: 'ECE',
      semester: 3,
      academic_year: '2026-2027',
      section: 'A',
      enrolment_status: 'ACTIVE',
      enrolled_at: '2026-08-10T10:00:00Z',
      updated_at: '2026-08-10T10:00:00Z',
    },
  ];

  const timetableSlots: TimetableSlotRecord[] = [
    {
      slot_id: 'TTS-2026-0001',
      academic_year: '2026-2027',
      semester: 3,
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      day_of_week: 'MONDAY',
      start_time: '09:00',
      end_time: '10:00',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      section: 'A',
      faculty_id: 'EMP-001',
      faculty_reg_number: 'EIT-TCH-CSE-2026-001',
      faculty_name: 'Arvind Sharma',
      room: 'LH-101',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      slot_id: 'TTS-2026-0002',
      academic_year: '2026-2027',
      semester: 3,
      department: 'CSE',
      programme_code: 'BTECH-CSE',
      day_of_week: 'MONDAY',
      start_time: '10:00',
      end_time: '11:00',
      course_code: 'CS301',
      course_title: 'Database Management Systems',
      section: 'A',
      faculty_id: 'EMP-001',
      faculty_reg_number: 'EIT-TCH-CSE-2026-001',
      faculty_name: 'Arvind Sharma',
      room: 'LH-101',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
    {
      slot_id: 'TTS-2026-0003',
      academic_year: '2026-2027',
      semester: 3,
      department: 'ECE',
      programme_code: 'BTECH-ECE',
      day_of_week: 'MONDAY',
      start_time: '09:00',
      end_time: '10:00',
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      section: 'A',
      faculty_id: 'EMP-002',
      faculty_reg_number: 'EIT-TCH-ECE-2026-002',
      faculty_name: 'Priya Menon',
      room: 'LH-201',
      status: 'ACTIVE',
      created_at: '2026-08-01T00:00:00Z',
    },
  ];

  const timetableVersions: TimetableVersionRecord[] = [
    {
      timetable_id: 'TT-2026-BTECH-CSE-S3-A-V1',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'BTECH-CSE',
      batch: '2026',
      section: 'A',
      version: 1,
      status: 'PUBLISHED',
      slot_ids: ['TTS-2026-0001', 'TTS-2026-0002'],
      published_at: '2026-08-01T10:00:00Z',
      published_by: 'EMP-001',
      published_by_name: 'Arvind Sharma',
      change_notes: 'Initial official timetable publication for B.Tech CSE Semester 3 Section A.',
      created_at: '2026-08-01T09:00:00Z',
      updated_at: '2026-08-01T10:00:00Z',
    },
  ];

  const csvImportBatches: CsvImportBatchRecord[] = [];

  const examSessions: ExamSessionRecord[] = [
    {
      session_id: 'EXS-2026-FALL',
      session_name: 'Fall 2026 Regular Examination Session',
      academic_year: '2026-2027',
      semester: 3,
      start_date: '2026-11-15',
      end_date: '2026-12-05',
      status: ExamSessionStatus.ONGOING,
      created_at: '2026-09-01T00:00:00Z',
    },
    {
      session_id: 'EXS-2027-SPRING',
      session_name: 'Spring 2027 Regular Examination Session',
      academic_year: '2026-2027',
      semester: 4,
      start_date: '2027-04-15',
      end_date: '2027-05-10',
      status: ExamSessionStatus.UPCOMING,
      created_at: '2026-09-01T00:00:00Z',
    },
  ];

  const examSchedules: ExamScheduleRecord[] = [
    {
      schedule_id: 'EXSCH-2026-CS201',
      session_id: 'EXS-2026-FALL',
      exam_name: 'Data Structures & Algorithms - End Semester',
      exam_type: ExamType.END_SEMESTER,
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      programme_code: 'BTECH-CSE',
      department: 'CSE',
      semester: 3,
      section: 'A',
      exam_date: '2026-11-20',
      start_time: '09:30',
      end_time: '12:30',
      duration_minutes: 180,
      room: 'Exam Hall 101',
      max_marks: 100,
      passing_marks: 40,
      marks_entry_open: true,
      status: ExamLifecycleStatus.MARKS_ENTRY_OPEN,
      notes: 'Standard 3-hour theoretical examination covering modules 1-5.',
      created_at: '2026-09-15T00:00:00Z',
      updated_at: '2026-09-15T00:00:00Z',
    },
    {
      schedule_id: 'EXSCH-2026-CS301',
      session_id: 'EXS-2026-FALL',
      exam_name: 'Database Management Systems - End Semester',
      exam_type: ExamType.END_SEMESTER,
      course_code: 'CS301',
      course_title: 'Database Management Systems',
      programme_code: 'BTECH-CSE',
      department: 'CSE',
      semester: 3,
      section: 'A',
      exam_date: '2026-11-23',
      start_time: '09:30',
      end_time: '12:30',
      duration_minutes: 180,
      room: 'Exam Hall 102',
      max_marks: 100,
      passing_marks: 40,
      marks_entry_open: false,
      status: ExamLifecycleStatus.SCHEDULED,
      notes: 'Relational algebra, SQL, normal forms, transaction processing.',
      created_at: '2026-09-15T00:00:00Z',
      updated_at: '2026-09-15T00:00:00Z',
    },
    {
      schedule_id: 'EXSCH-2026-EC304',
      session_id: 'EXS-2026-FALL',
      exam_name: 'Signals and Systems - End Semester',
      exam_type: ExamType.END_SEMESTER,
      course_code: 'EC304',
      course_title: 'Signals and Systems',
      programme_code: 'BTECH-ECE',
      department: 'ECE',
      semester: 3,
      section: 'A',
      exam_date: '2026-11-25',
      start_time: '14:00',
      end_time: '17:00',
      duration_minutes: 180,
      room: 'Exam Hall 201',
      max_marks: 100,
      passing_marks: 40,
      marks_entry_open: false,
      status: ExamLifecycleStatus.SCHEDULED,
      notes: 'Fourier, Laplace, and Z-transforms.',
      created_at: '2026-09-15T00:00:00Z',
      updated_at: '2026-09-15T00:00:00Z',
    },
  ];

  const examAttendance: ExamAttendanceEntryRecord[] = [
    {
      attendance_id: 'EXATT-2026-0001',
      schedule_id: 'EXSCH-2026-CS201',
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Arjun Kumar',
      status: ExamAttendanceStatus.PRESENT,
      marked_by: 'coeoffice',
      marked_at: '2026-11-20T09:15:00Z',
      remarks: 'Verified at entry desk with hall ticket.',
    },
  ];

  const examResults: ExamResultRecord[] = [
    {
      result_id: 'EXRES-2026-0001',
      schedule_id: 'EXSCH-2026-CS201',
      session_id: 'EXS-2026-FALL',
      student_id: 'STU-001',
      student_registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Arjun Kumar',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      programme_code: 'BTECH-CSE',
      semester: 3,
      academic_year: '2026-2027',
      internal_marks: 38,
      external_marks: 54,
      total_marks: 92,
      max_marks: 100,
      percentage: 92.0,
      grade: 'O',
      grade_point: 10.0,
      result_status: ExamResultStatus.PASS,
      lifecycle_status: ExamLifecycleStatus.PUBLISHED,
      submission_notes: 'Initial regular evaluation completed.',
      faculty_submitted_by: 'EMP-001',
      faculty_submitted_at: '2026-10-10T12:00:00Z',
      reviewed_by: 'coeoffice',
      reviewed_at: '2026-10-12T14:00:00Z',
      approved_by: 'coeoffice',
      approved_at: '2026-10-14T10:00:00Z',
      published_at: '2026-10-15T00:00:00Z',
      created_at: '2026-10-10T12:00:00Z',
      updated_at: '2026-10-15T00:00:00Z',
    },
    {
      result_id: 'EXRES-2026-0002',
      schedule_id: 'EXSCH-2026-CS201',
      session_id: 'EXS-2026-FALL',
      student_id: 'STU-002',
      student_registration_number: 'EIT-STU-2026-CSE-0002',
      student_name: 'Meera Nair',
      course_code: 'CS201',
      course_title: 'Data Structures & Algorithms',
      programme_code: 'BTECH-CSE',
      semester: 3,
      academic_year: '2026-2027',
      internal_marks: 35,
      external_marks: 48,
      total_marks: 83,
      max_marks: 100,
      percentage: 83.0,
      grade: 'A+',
      grade_point: 9.0,
      result_status: ExamResultStatus.PASS,
      lifecycle_status: ExamLifecycleStatus.PUBLISHED,
      submission_notes: 'Regular evaluation completed.',
      faculty_submitted_by: 'EMP-001',
      faculty_submitted_at: '2026-10-10T12:00:00Z',
      reviewed_by: 'coeoffice',
      reviewed_at: '2026-10-12T14:00:00Z',
      approved_by: 'coeoffice',
      approved_at: '2026-10-14T10:00:00Z',
      published_at: '2026-10-15T00:00:00Z',
      created_at: '2026-10-10T12:00:00Z',
      updated_at: '2026-10-15T00:00:00Z',
    },
  ];

  const feeStructures: FeeStructureRecord[] = [
    {
      structure_id: 'FST-2026-TUITION-CSE',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'BTECH-CSE',
      fee_category: FeeCategory.TUITION,
      fee_name: 'Tuition Fee - Semester 3 (CSE)',
      amount: 3500.0,
      currency: 'USD',
      due_date: '2026-08-31',
      applicability: 'B.Tech CSE Semester 3 standard tuition fee (Demonstration value)',
      status: 'ACTIVE',
      created_at: '2026-07-01T00:00:00Z',
      updated_at: '2026-07-01T00:00:00Z',
    },
    {
      structure_id: 'FST-2026-TUITION-ECE',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'BTECH-ECE',
      fee_category: FeeCategory.TUITION,
      fee_name: 'Tuition Fee - Semester 3 (ECE)',
      amount: 3500.0,
      currency: 'USD',
      due_date: '2026-08-31',
      applicability: 'B.Tech ECE Semester 3 standard tuition fee (Demonstration value)',
      status: 'ACTIVE',
      created_at: '2026-07-01T00:00:00Z',
      updated_at: '2026-07-01T00:00:00Z',
    },
    {
      structure_id: 'FST-2026-HOSTEL-ALL',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'ALL',
      fee_category: FeeCategory.HOSTEL,
      fee_name: 'Hostel Accommodation & Facilities',
      amount: 1200.0,
      currency: 'USD',
      due_date: '2026-08-31',
      applicability: 'All resident boarders in Institute Hostels (Demonstration value)',
      status: 'ACTIVE',
      created_at: '2026-07-01T00:00:00Z',
      updated_at: '2026-07-01T00:00:00Z',
    },
    {
      structure_id: 'FST-2026-EXAM-ALL',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'ALL',
      fee_category: FeeCategory.EXAMINATION,
      fee_name: 'COE Examination Registration Fee',
      amount: 200.0,
      currency: 'USD',
      due_date: '2026-10-15',
      applicability: 'End-semester evaluation & moderation dues (Demonstration value)',
      status: 'ACTIVE',
      created_at: '2026-07-01T00:00:00Z',
      updated_at: '2026-07-01T00:00:00Z',
    },
    {
      structure_id: 'FST-2026-LAB-CSE',
      academic_year: '2026-2027',
      semester: 3,
      programme_code: 'BTECH-CSE',
      fee_category: FeeCategory.LABORATORY,
      fee_name: 'Computing & Hardware Lab Infrastructure',
      amount: 300.0,
      currency: 'USD',
      due_date: '2026-08-31',
      applicability: 'CSE Advanced Systems and Algorithm Lab (Demonstration value)',
      status: 'ACTIVE',
      created_at: '2026-07-01T00:00:00Z',
      updated_at: '2026-07-01T00:00:00Z',
    },
  ];

  const feeInvoices: FeeInvoiceRecord[] = [
    {
      invoice_id: 'INV-2026-001',
      invoice_number: 'EIT-INV-2026-0001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      fee_category: 'TUITION',
      issue_date: '2026-08-01',
      due_date: '2026-08-31',
      line_items: [
        {
          line_id: 'L-001',
          fee_structure_id: 'FST-2026-TUITION-CSE',
          category: 'TUITION',
          description: 'Tuition Fee - Semester 3 (CSE)',
          amount: 3500.0,
        },
      ],
      subtotal: 3500.0,
      adjustments_total: 0.0,
      total_amount: 3500.0,
      amount_due: 3500.0,
      amount_paid: 3500.0,
      outstanding_balance: 0.0,
      currency: 'USD',
      status: InvoiceStatus.PAID,
      payment_status: PaymentStatus.PAID,
      transaction_reference: 'TXN-9847291',
      payment_method: 'ONLINE_GATEWAY',
      payment_date: '2026-08-10T14:30:00Z',
      created_by: 'finance',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-10T14:30:00Z',
    },
    {
      invoice_id: 'INV-2026-002',
      invoice_number: 'EIT-INV-2026-0002',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      programme_code: 'BTECH-CSE',
      academic_year: '2026-2027',
      semester: 3,
      fee_category: 'HOSTEL',
      issue_date: '2026-08-01',
      due_date: '2026-08-31',
      hostel_charge_id: 'HCR-2026-0001',
      line_items: [
        {
          line_id: 'L-002',
          fee_structure_id: 'FST-2026-HOSTEL-ALL',
          category: 'HOSTEL',
          description: 'Hostel Accommodation & Facilities - Semester 3',
          amount: 1200.0,
        },
      ],
      subtotal: 1200.0,
      adjustments_total: 0.0,
      total_amount: 1200.0,
      amount_due: 1200.0,
      amount_paid: 1200.0,
      outstanding_balance: 0.0,
      currency: 'USD',
      status: InvoiceStatus.PAID,
      payment_status: PaymentStatus.PAID,
      transaction_reference: 'TXN-9847292',
      payment_method: 'BANK_TRANSFER',
      payment_date: '2026-08-11T10:15:00Z',
      created_by: 'finance',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-11T10:15:00Z',
    },
    {
      invoice_id: 'INV-2026-003',
      invoice_number: 'EIT-INV-2026-0003',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      student_name: 'Priya Sharma',
      programme_code: 'BTECH-ECE',
      academic_year: '2026-2027',
      semester: 3,
      fee_category: 'TUITION',
      issue_date: '2026-08-01',
      due_date: '2026-08-31',
      line_items: [
        {
          line_id: 'L-003',
          fee_structure_id: 'FST-2026-TUITION-ECE',
          category: 'TUITION',
          description: 'Tuition Fee - Semester 3 (ECE)',
          amount: 3500.0,
        },
      ],
      subtotal: 3500.0,
      adjustments_total: 0.0,
      total_amount: 3500.0,
      amount_due: 3500.0,
      amount_paid: 1750.0,
      outstanding_balance: 1750.0,
      currency: 'USD',
      status: InvoiceStatus.PARTIALLY_PAID,
      payment_status: PaymentStatus.PARTIAL,
      transaction_reference: 'TXN-9847295',
      payment_method: 'ONLINE_GATEWAY',
      payment_date: '2026-08-15T09:20:00Z',
      created_by: 'finance',
      created_at: '2026-08-01T00:00:00Z',
      updated_at: '2026-08-15T09:20:00Z',
    },
  ];

  const payments: PaymentRecord[] = [
    {
      payment_id: 'PAY-2026-0001',
      receipt_number: 'REC-2026-0001',
      invoice_id: 'INV-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      amount: 3500.0,
      currency: 'USD',
      payment_date: '2026-08-10T14:30:00Z',
      payment_method: PaymentMethod.CASH,
      transaction_reference: 'TXN-9847291',
      receiving_officer_id: 'finance',
      status: PaymentLedgerStatus.VERIFIED,
      notes: 'Initial full tuition payment received and verified.',
      created_at: '2026-08-10T14:30:00Z',
    },
    {
      payment_id: 'PAY-2026-0002',
      receipt_number: 'REC-2026-0002',
      invoice_id: 'INV-2026-002',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      amount: 1200.0,
      currency: 'USD',
      payment_date: '2026-08-11T10:15:00Z',
      payment_method: PaymentMethod.BANK_TRANSFER,
      transaction_reference: 'TXN-9847292',
      receiving_officer_id: 'finance',
      status: PaymentLedgerStatus.VERIFIED,
      notes: 'Hostel accommodation dues verified against bank counterfoil.',
      created_at: '2026-08-11T10:15:00Z',
    },
    {
      payment_id: 'PAY-2026-0003',
      receipt_number: 'REC-2026-0003',
      invoice_id: 'INV-2026-003',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      student_name: 'Priya Sharma',
      amount: 1750.0,
      currency: 'USD',
      payment_date: '2026-08-15T09:20:00Z',
      payment_method: PaymentMethod.CARD,
      transaction_reference: 'TXN-9847295',
      receiving_officer_id: 'finance',
      status: PaymentLedgerStatus.VERIFIED,
      notes: 'First installment payment recorded.',
      created_at: '2026-08-15T09:20:00Z',
    },
  ];

  const feeAdjustments: FeeAdjustmentRecord[] = [];

  const hostelBlocks: HostelBlockRecord[] = [
    {
      block_id: 'HST-BLK-A',
      block_name: 'Block A - Aryabhata Hall',
      gender_type: HostelGenderType.BOYS,
      total_floors: 4,
      status: 'ACTIVE',
      warden_name: 'Dr. Vikram Seth',
      contact_phone: '+1 (555) 789-0101',
      created_at: '2026-01-01T00:00:00Z',
    },
    {
      block_id: 'HST-BLK-B',
      block_name: 'Block B - Ramanujan Hall',
      gender_type: HostelGenderType.BOYS,
      total_floors: 4,
      status: 'ACTIVE',
      warden_name: 'Prof. Rajesh Rao',
      contact_phone: '+1 (555) 789-0102',
      created_at: '2026-01-01T00:00:00Z',
    },
    {
      block_id: 'HST-BLK-C',
      block_name: 'Block C - Sarabhai Hall',
      gender_type: HostelGenderType.GIRLS,
      total_floors: 4,
      status: 'ACTIVE',
      warden_name: 'Dr. Ananya Roy',
      contact_phone: '+1 (555) 789-0103',
      created_at: '2026-01-01T00:00:00Z',
    },
  ];

  const hostelRooms: HostelRoomRecord[] = [
    {
      room_id: 'HST-RM-A-101',
      block_id: 'HST-BLK-A',
      block_name: 'Block A - Aryabhata Hall',
      room_number: '101',
      floor: 1,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['Air Conditioning', 'High-Speed Wi-Fi', 'Study Desks', 'Attached Bath'],
      status: RoomOperationalStatus.ACTIVE,
      beds: [
        { bed_id: 'BED-A-101-A', room_id: 'HST-RM-A-101', bed_identifier: 'A', status: BedOccupancyStatus.AVAILABLE },
        { bed_id: 'BED-A-101-B', room_id: 'HST-RM-A-101', bed_identifier: 'B', status: BedOccupancyStatus.AVAILABLE },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      room_id: 'HST-RM-A-201',
      block_id: 'HST-BLK-A',
      block_name: 'Block A - Aryabhata Hall',
      room_number: '201',
      floor: 2,
      room_type: RoomType.SINGLE,
      capacity: 1,
      amenities: ['Air Conditioning', 'High-Speed Wi-Fi', 'Balcony', 'En-Suite'],
      status: RoomOperationalStatus.ACTIVE,
      beds: [
        { bed_id: 'BED-A-201-A', room_id: 'HST-RM-A-201', bed_identifier: 'A', status: BedOccupancyStatus.AVAILABLE },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      room_id: 'HST-RM-A-304',
      block_id: 'HST-BLK-A',
      block_name: 'Block A - Aryabhata Hall',
      room_number: '304',
      floor: 3,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['Ceiling Fans', 'High-Speed Wi-Fi', 'Study Desks'],
      status: RoomOperationalStatus.ACTIVE,
      beds: [
        { bed_id: 'BED-A-304-A', room_id: 'HST-RM-A-304', bed_identifier: 'A', status: BedOccupancyStatus.OCCUPIED, current_allocation_id: 'HST-2026-001' },
        { bed_id: 'BED-A-304-B', room_id: 'HST-RM-A-304', bed_identifier: 'B', status: BedOccupancyStatus.AVAILABLE },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      room_id: 'HST-RM-B-208',
      block_id: 'HST-BLK-B',
      block_name: 'Block B - Ramanujan Hall',
      room_number: '208',
      floor: 2,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['Ceiling Fans', 'Study Desks', 'Wi-Fi'],
      status: RoomOperationalStatus.ACTIVE,
      beds: [
        { bed_id: 'BED-B-208-A', room_id: 'HST-RM-B-208', bed_identifier: 'A', status: BedOccupancyStatus.AVAILABLE },
        { bed_id: 'BED-B-208-B', room_id: 'HST-RM-B-208', bed_identifier: 'B', status: BedOccupancyStatus.OCCUPIED, current_allocation_id: 'HST-2026-002' },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      room_id: 'HST-RM-B-310',
      block_id: 'HST-BLK-B',
      block_name: 'Block B - Ramanujan Hall',
      room_number: '310',
      floor: 3,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['High-Speed Wi-Fi'],
      status: RoomOperationalStatus.UNDER_MAINTENANCE,
      beds: [
        { bed_id: 'BED-B-310-A', room_id: 'HST-RM-B-310', bed_identifier: 'A', status: BedOccupancyStatus.MAINTENANCE },
        { bed_id: 'BED-B-310-B', room_id: 'HST-RM-B-310', bed_identifier: 'B', status: BedOccupancyStatus.MAINTENANCE },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
    {
      room_id: 'HST-RM-C-101',
      block_id: 'HST-BLK-C',
      block_name: 'Block C - Sarabhai Hall',
      room_number: '101',
      floor: 1,
      room_type: RoomType.DOUBLE,
      capacity: 2,
      amenities: ['Air Conditioning', 'High-Speed Wi-Fi', 'Attached Bath'],
      status: RoomOperationalStatus.ACTIVE,
      beds: [
        { bed_id: 'BED-C-101-A', room_id: 'HST-RM-C-101', bed_identifier: 'A', status: BedOccupancyStatus.AVAILABLE },
        { bed_id: 'BED-C-101-B', room_id: 'HST-RM-C-101', bed_identifier: 'B', status: BedOccupancyStatus.AVAILABLE },
      ],
      created_at: '2026-01-01T00:00:00Z',
      updated_at: '2026-01-01T00:00:00Z',
    },
  ];

  const hostelAllocations: HostelAllocationRecord[] = [
    {
      allocation_id: 'HST-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      block_id: 'HST-BLK-A',
      block_name: 'Block A - Aryabhata Hall',
      room_id: 'HST-RM-A-304',
      room_number: '304',
      bed_id: 'BED-A-304-A',
      bed_identifier: 'A',
      academic_year: '2026-2027',
      semester: 3,
      start_date: '2026-08-15',
      status: HostelAllocationLifecycleStatus.CHECKED_IN,
      allocated_by: 'hosteloffice',
      allocated_at: '2026-08-10T00:00:00Z',
      checked_in_at: '2026-08-15T10:00:00Z',
      emergency_contact_phone: '+1 (555) 901-2345',
      created_at: '2026-08-10T00:00:00Z',
      updated_at: '2026-08-15T10:00:00Z',
    },
    {
      allocation_id: 'HST-2026-002',
      student_id: 'STU-002',
      registration_number: 'EIT-STU-2026-ECE-0002',
      student_name: 'Priya Sharma',
      block_id: 'HST-BLK-B',
      block_name: 'Block B - Ramanujan Hall',
      room_id: 'HST-RM-B-208',
      room_number: '208',
      bed_id: 'BED-B-208-B',
      bed_identifier: 'B',
      academic_year: '2026-2027',
      semester: 3,
      start_date: '2026-08-16',
      status: HostelAllocationLifecycleStatus.CHECKED_IN,
      allocated_by: 'hosteloffice',
      allocated_at: '2026-08-10T00:00:00Z',
      checked_in_at: '2026-08-16T11:30:00Z',
      emergency_contact_phone: '+1 (555) 890-1234',
      created_at: '2026-08-10T00:00:00Z',
      updated_at: '2026-08-16T11:30:00Z',
    },
  ];

  const hostelCharges: HostelChargeRequestRecord[] = [
    {
      charge_request_id: 'HCR-2026-0001',
      allocation_id: 'HST-2026-001',
      student_id: 'STU-001',
      registration_number: 'EIT-STU-2026-CSE-0001',
      student_name: 'Aditya Verma',
      billing_period: '2026-2027-SEM3',
      fee_category: 'HOSTEL',
      amount: 1200.0,
      description: 'Hostel Accommodation & Facilities - Semester 3',
      requested_by: 'hosteloffice',
      requested_at: '2026-08-01T00:00:00Z',
      status: HostelChargeStatus.INVOICED,
      invoice_id: 'INV-2026-002',
      invoiced_by: 'finance',
      invoiced_at: '2026-08-01T00:00:00Z',
      created_at: '2026-08-01T00:00:00Z',
    },
  ];

  return {
    users,
    employees,
    facultyAssignments,
    officeAssignments,
    officePermissions,
    applicants,
    students,
    parents,
    parentStudentLinks,
    finance,
    hostel,
    auditLogs,
    examinations,
    attendance,
    academics,
    academicYears,
    semesters,
    departments,
    programmes,
    courses,
    sections,
    courseOfferings,
    enrolments,
    timetableSlots,
    timetableVersions,
    csvImportBatches,
    examSessions,
    examSchedules,
    examAttendance,
    examResults,
    feeStructures,
    feeInvoices,
    payments,
    feeAdjustments,
    hostelBlocks,
    hostelRooms,
    hostelAllocations,
    hostelCharges,
    systemSettings,
    academicYearTransitions,
  };
}

class DevDataAdapterImpl implements IEitDataAdapter {
  private state: DevStoreState;
  private academicYearSubscribers = new Set<(activeYear: AcademicYearRecord) => void>();

  constructor() {
    this.state = this.loadState();
  }

  private notifyAcademicYearSubscribers(activeYear: AcademicYearRecord) {
    this.academicYearSubscribers.forEach((cb) => {
      try {
        cb(activeYear);
      } catch (e) {
        console.error('Error notifying academic year subscriber:', e);
      }
    });
  }

  private loadState(): DevStoreState {
    if (typeof window === 'undefined') {
      return initializeDefaultDevState();
    }
    try {
      const saved = window.sessionStorage.getItem(DEV_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const fresh = initializeDefaultDevState();
        return {
          ...fresh,
          ...parsed,
          users: (() => {
            const list = [...(parsed.users || [])];
            for (const fu of fresh.users) {
              if (!list.some((u: any) => u.user_id === fu.user_id || u.username === fu.username)) {
                list.push(fu);
              }
            }
            return list;
          })(),
          applicants: parsed.applicants?.length ? parsed.applicants : fresh.applicants,
          academicYears: parsed.academicYears?.length ? parsed.academicYears : fresh.academicYears,
          systemSettings: parsed.systemSettings || fresh.systemSettings,
          academicYearTransitions: parsed.academicYearTransitions?.length
            ? parsed.academicYearTransitions
            : fresh.academicYearTransitions,
          semesters: parsed.semesters?.length ? parsed.semesters : fresh.semesters,
          departments: parsed.departments?.length ? parsed.departments : fresh.departments,
          programmes: parsed.programmes?.length ? parsed.programmes : fresh.programmes,
          courses: parsed.courses?.length ? parsed.courses : fresh.courses,
          sections: parsed.sections?.length ? parsed.sections : fresh.sections,
          courseOfferings: parsed.courseOfferings?.length ? parsed.courseOfferings : fresh.courseOfferings,
          enrolments: parsed.enrolments?.length ? parsed.enrolments : fresh.enrolments,
          timetableSlots: parsed.timetableSlots?.length ? parsed.timetableSlots : fresh.timetableSlots,
          timetableVersions: parsed.timetableVersions?.length ? parsed.timetableVersions : fresh.timetableVersions,
          csvImportBatches: parsed.csvImportBatches?.length ? parsed.csvImportBatches : fresh.csvImportBatches,
          examSessions: parsed.examSessions?.length ? parsed.examSessions : fresh.examSessions,
          examSchedules: parsed.examSchedules?.length ? parsed.examSchedules : fresh.examSchedules,
          examAttendance: parsed.examAttendance?.length ? parsed.examAttendance : fresh.examAttendance,
          examResults: parsed.examResults?.length ? parsed.examResults : fresh.examResults,
          feeStructures: parsed.feeStructures?.length ? parsed.feeStructures : fresh.feeStructures,
          feeInvoices: parsed.feeInvoices?.length ? parsed.feeInvoices : fresh.feeInvoices,
          payments: parsed.payments?.length ? parsed.payments : fresh.payments,
          feeAdjustments: parsed.feeAdjustments?.length ? parsed.feeAdjustments : fresh.feeAdjustments,
          hostelBlocks: parsed.hostelBlocks?.length ? parsed.hostelBlocks : fresh.hostelBlocks,
          hostelRooms: parsed.hostelRooms?.length ? parsed.hostelRooms : fresh.hostelRooms,
          hostelAllocations: parsed.hostelAllocations?.length ? parsed.hostelAllocations : fresh.hostelAllocations,
          hostelCharges: parsed.hostelCharges?.length ? parsed.hostelCharges : fresh.hostelCharges,
        };
      }
    } catch {
      // Fallback to default
    }
    const fresh = initializeDefaultDevState();
    this.saveState(fresh);
    return fresh;
  }

  public getState(): DevStoreState {
    return this.state;
  }

  public saveState(state: DevStoreState) {
    this.state = state;
    if (typeof window !== 'undefined') {
      try {
        window.sessionStorage.setItem(DEV_STORAGE_KEY, JSON.stringify(state));
      } catch {
        // Storage limit handled safely
      }
    }
  }

  // ---------------------------------------------------------------------------
  // AUTHENTICATION
  // ---------------------------------------------------------------------------
  public auth = {
    login: async (usernameInput: string, passwordAttempt: string, portalType: PortalType): Promise<LoginResult> => {
      // Simulate minor network latency
      await new Promise((resolve) => setTimeout(resolve, 250));

      const raw = usernameInput.trim().toLowerCase();
      const normalizedUsername = raw;

      if (!passwordAttempt) {
        return { success: false, error: 'Password is required.' };
      }

      // Check if matches permanent office
      const permanentOffice = getPermanentOfficeByUsername(normalizedUsername);

      // Find user by username or employee registration number
      let user = this.state.users.find(
        (u) => u.username.toLowerCase() === normalizedUsername
      );

      if (!user) {
        const empByReg = this.state.employees.find(
          (e) => e.registration_number.toLowerCase() === normalizedUsername
        );
        if (empByReg) {
          user = this.state.users.find(
            (u) => u.linked_record_type === LinkedRecordType.EMPLOYEE && u.linked_record_id === empByReg.employee_id
          );
        }
      }

      if (!user) {
        const stuByReg = this.state.students.find(
          (s) => s.registration_number.toLowerCase() === normalizedUsername
        );
        if (stuByReg) {
          if (stuByReg.enrollment_status === StudentStatus.SUSPENDED || stuByReg.enrollment_status === StudentStatus.WITHDRAWN) {
            return {
              success: false,
              error: `This student account is ${stuByReg.enrollment_status}. Authentication denied.`,
            };
          }
          user = this.state.users.find(
            (u) =>
              u.linked_record_type === LinkedRecordType.STUDENT &&
              (u.linked_record_id === stuByReg.student_id || u.username.toLowerCase() === stuByReg.registration_number.toLowerCase())
          );
        }
      }

      if (!user && !permanentOffice) {
        return {
          success: false,
          error: `Account '${usernameInput}' not found. Please verify your username.`,
        };
      }

      // Validate portal match
      const expectedPortal = user ? user.portal_type : PortalType.Employee;
      if (expectedPortal !== portalType) {
        return {
          success: false,
          error: `This account is registered for the ${expectedPortal.toUpperCase()} gateway. Please use the ${expectedPortal} portal.`,
        };
      }

      // Check account status
      if (user && user.account_status !== AccountStatus.ACTIVE) {
        return {
          success: false,
          error: `This account is currently ${user.account_status}. Please contact the Administration Office.`,
        };
      }

      // Check linked employee status (suspended, terminated, resigned accounts cannot authenticate)
      if (user?.linked_record_type === LinkedRecordType.EMPLOYEE) {
        const emp = this.state.employees.find((e) => e.employee_id === user.linked_record_id);
        if (emp && (emp.employment_status === EmploymentStatus.TERMINATED || emp.employment_status === EmploymentStatus.RESIGNED || emp.employment_status === EmploymentStatus.RETIRED)) {
          return {
            success: false,
            error: `This employee account is ${emp.employment_status}. Authentication denied.`,
          };
        }
      }

      // Check linked student status
      if (user?.linked_record_type === LinkedRecordType.STUDENT) {
        const stu = this.state.students.find((s) => s.student_id === user.linked_record_id);
        if (stu && (stu.enrollment_status === StudentStatus.SUSPENDED || stu.enrollment_status === StudentStatus.WITHDRAWN)) {
          return {
            success: false,
            error: `This student account is ${stu.enrollment_status}. Authentication denied.`,
          };
        }
      }

      // Create session
      let role = user ? user.role : AuthRole.OFFICE_ADMIN;
      if (permanentOffice?.is_super_admin) {
        role = AuthRole.SUPER_ADMIN;
      }

      let employeeProfile: EmployeeRecord | undefined;
      let studentProfile: StudentRecord | undefined;
      let parentProfile: ParentRecord | undefined;
      const availableOffices: PermanentOfficeRecord[] = [];

      if (permanentOffice) {
        availableOffices.push(permanentOffice);
      }

      if (user?.linked_record_type === LinkedRecordType.EMPLOYEE) {
        employeeProfile = this.state.employees.find((e) => e.employee_id === user.linked_record_id);
        // Find assigned offices for non-teaching staff
        const assignments = this.state.officeAssignments.filter(
          (a) => a.employee_id === user.linked_record_id && a.assignment_status === OfficeAssignmentStatus.ACTIVE
        );
        for (const assign of assignments) {
          const off = SIX_PERMANENT_OFFICES.find((o) => o.office_id === assign.office_id);
          if (off && !availableOffices.some((ao) => ao.office_id === off.office_id)) {
            availableOffices.push(off);
          }
        }
      } else if (user?.linked_record_type === LinkedRecordType.STUDENT) {
        studentProfile = this.state.students.find((s) => s.student_id === user.linked_record_id);
      } else if (user?.linked_record_type === LinkedRecordType.PARENT) {
        parentProfile = this.state.parents.find((p) => p.parent_id === user.linked_record_id);
      }

      const displayName =
        permanentOffice?.office_name ||
        (employeeProfile ? `${employeeProfile.first_name} ${employeeProfile.last_name}` : undefined) ||
        (studentProfile ? `${studentProfile.first_name} ${studentProfile.last_name}` : undefined) ||
        (parentProfile ? `${parentProfile.first_name} ${parentProfile.last_name}` : undefined) ||
        usernameInput;

      const session: AuthSession = {
        user: user || {
          user_id: `USR-${permanentOffice!.office_code}`,
          username: permanentOffice!.canonical_username,
          password_hash: 'mock_hash',
          portal_type: PortalType.Employee,
          role,
          linked_record_type: LinkedRecordType.PERMANENT_OFFICE,
          linked_record_id: permanentOffice!.office_id,
          account_status: AccountStatus.ACTIVE,
          failed_login_attempts: 0,
          password_updated_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        token: `dev_token_${Date.now()}`,
        displayName,
        portalType,
        role,
        permanentOffice,
        employeeProfile,
        studentProfile,
        parentProfile,
        availableOffices,
        activeOfficeKey: permanentOffice?.office_key || availableOffices[0]?.office_key,
        userId: studentProfile?.student_id || employeeProfile?.employee_id || user?.linked_record_id || user?.user_id || permanentOffice?.office_id,
        username: user?.username || permanentOffice?.canonical_username || normalizedUsername,
      };

      if (typeof window !== 'undefined') {
        window.sessionStorage.setItem(DEV_SESSION_KEY, JSON.stringify(session));
      }

      await this.audit.log({
        actor_id: session.user.username,
        actor_role: session.role,
        action: AuditAction.LOGIN_ATTEMPT,
        target_worksheet: 'AuthUsers',
        target_record_id: session.user.user_id,
        description: `Successful login to ${portalType} portal in development mode.`,
      });

      return { success: true, session };
    },

    getCurrentSession: async (): Promise<AuthSession | null> => {
      if (typeof window === 'undefined') return null;
      try {
        const item = window.sessionStorage.getItem(DEV_SESSION_KEY);
        if (item) {
          return JSON.parse(item);
        }
      } catch {
        return null;
      }
      return null;
    },

    logout: async (): Promise<void> => {
      if (typeof window !== 'undefined') {
        window.sessionStorage.removeItem(DEV_SESSION_KEY);
      }
    },
  };

  // ---------------------------------------------------------------------------
  // OFFICES
  // ---------------------------------------------------------------------------
  public offices = {
    getAllPermanent: async (): Promise<PermanentOfficeRecord[]> => {
      return [...SIX_PERMANENT_OFFICES];
    },
    getByUsername: async (username: string): Promise<PermanentOfficeRecord | null> => {
      return getPermanentOfficeByUsername(username) || null;
    },
  };

  // ---------------------------------------------------------------------------
  // EMPLOYEES
  // ---------------------------------------------------------------------------
  public employees = {
    getAll: async (): Promise<EmployeeRecord[]> => {
      return [...this.state.employees];
    },
    getById: async (id: string): Promise<EmployeeRecord | null> => {
      return this.state.employees.find((e) => e.employee_id === id) || null;
    },
    create: async (data: Omit<EmployeeRecord, 'employee_id' | 'created_at' | 'updated_at'>): Promise<EmployeeRecord> => {
      // 1. Validation for personal & employment details
      if (!data.first_name?.trim() || !data.last_name?.trim()) {
        throw new Error('First name and last name are required.');
      }
      if (!data.phone_number?.trim()) {
        throw new Error('Phone number is required.');
      }
      if (!data.institutional_email?.trim()) {
        throw new Error('Institutional email is required.');
      }
      if (!data.primary_department?.trim()) {
        throw new Error('Primary department is required.');
      }
      if (!data.designation?.trim()) {
        throw new Error('Designation is required.');
      }
      if (!data.date_of_joining?.trim()) {
        throw new Error('Date of joining is required.');
      }

      // 2. Protect Permanent Offices against spoofing
      const fullName = `${data.first_name} ${data.last_name}`.trim();
      if (
        isReservedOfficeIdentifier(fullName) ||
        isReservedOfficeIdentifier(data.institutional_email) ||
        isReservedOfficeIdentifier(data.first_name)
      ) {
        throw new Error('Registration conflicts with a reserved Permanent Office identity.');
      }

      // 3. Email Uniqueness Check
      const existingEmail = this.state.employees.find(
        (e) => e.institutional_email.toLowerCase() === data.institutional_email.trim().toLowerCase()
      );
      if (existingEmail) {
        throw new Error(`Employee with email '${data.institutional_email}' is already registered.`);
      }

      // 4. Generate/Allocate Registration Number
      const existingRegs = this.state.employees.map((e) => e.registration_number);
      const joiningYear = parseInt(data.date_of_joining.split('-')[0], 10) || 2026;
      const regNumber =
        data.registration_number ||
        allocateNextEmployeeRegistrationNumber(existingRegs, data.category, data.primary_department, joiningYear);

      // Verify registration number uniqueness
      if (this.state.employees.some((e) => e.registration_number === regNumber)) {
        throw new Error(`Registration number conflict: ${regNumber} is already allocated.`);
      }

      const newId = `EMP-${String(this.state.employees.length + 1).padStart(3, '0')}`;

      const record: EmployeeRecord = {
        ...data,
        first_name: data.first_name.trim(),
        last_name: data.last_name.trim(),
        institutional_email: data.institutional_email.trim().toLowerCase(),
        phone_number: data.phone_number.trim(),
        employee_id: newId,
        registration_number: regNumber,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // 5. Explicit, Repeat-Safe Account Provisioning (No plaintext password stored)
      const existingUser = this.state.users.find(
        (u) =>
          u.username.toLowerCase() === regNumber.toLowerCase() ||
          (u.linked_record_type === LinkedRecordType.EMPLOYEE && u.linked_record_id === newId)
      );

      const nextUsers = [...this.state.users];
      if (!existingUser) {
        const newUser: AuthUserRecord = {
          user_id: `USR-${newId}`,
          username: regNumber,
          password_hash: `dev_mock_hash_${data.category === EmployeeCategory.TEACHING ? 'faculty' : 'staff'}`,
          portal_type: PortalType.Employee,
          role: data.category === EmployeeCategory.TEACHING ? AuthRole.FACULTY : AuthRole.NON_TEACHING_STAFF,
          linked_record_type: LinkedRecordType.EMPLOYEE,
          linked_record_id: newId,
          account_status: AccountStatus.ACTIVE,
          failed_login_attempts: 0,
          password_updated_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        nextUsers.push(newUser);
      }

      const nextState = {
        ...this.state,
        employees: [...this.state.employees, record],
        users: nextUsers,
      };
      this.saveState(nextState);

      // Trigger automatic employee ID card generation (Requirement 6B)
      import('./itService').then(({ itRepository }) => {
        itRepository.autoGenerateEmployeeIdCard(record).catch(() => {});
      }).catch(() => {});

      await this.audit.log({
        actor_id: 'admin',
        actor_role: AuthRole.SUPER_ADMIN,
        action: AuditAction.CREATE,
        target_worksheet: 'Employees',
        target_record_id: newId,
        description: `Registered ${data.category} employee ${record.first_name} ${record.last_name} with registration number ${regNumber}.`,
      });

      return record;
    },
    update: async (
      id: string,
      data: Partial<Omit<EmployeeRecord, 'employee_id' | 'registration_number' | 'category' | 'created_at'>>
    ): Promise<EmployeeRecord> => {
      const emp = this.state.employees.find((e) => e.employee_id === id);
      if (!emp) {
        throw new Error(`Employee ${id} not found.`);
      }

      if (data.institutional_email && data.institutional_email.trim().toLowerCase() !== emp.institutional_email.toLowerCase()) {
        const emailConflict = this.state.employees.find(
          (e) => e.employee_id !== id && e.institutional_email.toLowerCase() === data.institutional_email!.trim().toLowerCase()
        );
        if (emailConflict) {
          throw new Error(`Email '${data.institutional_email}' is already in use by another employee.`);
        }
      }

      const updated: EmployeeRecord = {
        ...emp,
        first_name: data.first_name ? data.first_name.trim() : emp.first_name,
        last_name: data.last_name ? data.last_name.trim() : emp.last_name,
        phone_number: data.phone_number ? data.phone_number.trim() : emp.phone_number,
        primary_department: data.primary_department ? data.primary_department.trim() : emp.primary_department,
        designation: data.designation ? data.designation.trim() : emp.designation,
        employment_status: data.employment_status ?? emp.employment_status,
        institutional_email: data.institutional_email ? data.institutional_email.trim().toLowerCase() : emp.institutional_email,
        updated_at: new Date().toISOString(),
      };

      // Sync user login status based on employment status
      let nextUsers = [...this.state.users];
      if (data.employment_status) {
        const isDeactivated = [
          EmploymentStatus.TERMINATED,
          EmploymentStatus.RESIGNED,
          EmploymentStatus.RETIRED,
        ].includes(data.employment_status);

        nextUsers = nextUsers.map((u) => {
          if (u.linked_record_type === LinkedRecordType.EMPLOYEE && u.linked_record_id === id) {
            return {
              ...u,
              account_status: isDeactivated ? AccountStatus.SUSPENDED : AccountStatus.ACTIVE,
              updated_at: new Date().toISOString(),
            };
          }
          return u;
        });
      }

      const nextState = {
        ...this.state,
        employees: this.state.employees.map((e) => (e.employee_id === id ? updated : e)),
        users: nextUsers,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: 'admin',
        actor_role: AuthRole.SUPER_ADMIN,
        action: AuditAction.UPDATE,
        target_worksheet: 'Employees',
        target_record_id: id,
        description: `Updated employee profile for ${updated.first_name} ${updated.last_name} (${updated.registration_number}). Status: ${updated.employment_status}.`,
      });

      return updated;
    },
    provisionAccount: async (
      employeeId: string
    ): Promise<{ success: boolean; user?: AuthUserRecord; message?: string; error?: string }> => {
      const emp = this.state.employees.find((e) => e.employee_id === employeeId);
      if (!emp) {
        return { success: false, error: `Employee ${employeeId} not found.` };
      }

      // Check for existing account - repeat-safe
      const existingUser = this.state.users.find(
        (u) =>
          u.username.toLowerCase() === emp.registration_number.toLowerCase() ||
          (u.linked_record_type === LinkedRecordType.EMPLOYEE && u.linked_record_id === employeeId)
      );

      if (existingUser) {
        return {
          success: true,
          user: existingUser,
          message: `Account is already provisioned for ${emp.registration_number} (repeat-safe).`,
        };
      }

      const newUser: AuthUserRecord = {
        user_id: `USR-${emp.employee_id}`,
        username: emp.registration_number,
        password_hash: `dev_mock_hash_${emp.category === EmployeeCategory.TEACHING ? 'faculty' : 'staff'}`,
        portal_type: PortalType.Employee,
        role: emp.category === EmployeeCategory.TEACHING ? AuthRole.FACULTY : AuthRole.NON_TEACHING_STAFF,
        linked_record_type: LinkedRecordType.EMPLOYEE,
        linked_record_id: emp.employee_id,
        account_status: AccountStatus.ACTIVE,
        failed_login_attempts: 0,
        password_updated_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        users: [...this.state.users, newUser],
      };
      this.saveState(nextState);

      return {
        success: true,
        user: newUser,
        message: `Account successfully provisioned for ${emp.registration_number}.`,
      };
    },
  };

  // ---------------------------------------------------------------------------
  // FACULTY COURSE ASSIGNMENTS (TEACHING ONLY)
  // ---------------------------------------------------------------------------
  public facultyAssignments = {
    getAll: async (): Promise<FacultyCourseAssignmentRecord[]> => {
      return [...this.state.facultyAssignments];
    },
    getByFaculty: async (employeeId: string): Promise<FacultyCourseAssignmentRecord[]> => {
      return this.state.facultyAssignments.filter((f) => f.employee_id === employeeId && f.assignment_status === 'ACTIVE');
    },
    assign: async (
      data: Omit<FacultyCourseAssignmentRecord, 'faculty_assignment_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord> => {
      if (actor) {
        this.verifyAcademicAccess(actor, PermissionScope.WRITE);
      }

      const faculty = this.state.employees.find((e) => e.employee_id === data.employee_id);
      if (!faculty) {
        throw new Error(`Employee '${data.employee_id}' does not exist.`);
      }
      if (faculty.category !== EmployeeCategory.TEACHING) {
        throw new Error(
          `Cannot assign non-teaching staff as faculty. Employee '${faculty.registration_number}' belongs to '${faculty.category}' category.`
        );
      }
      if (faculty.employment_status !== EmploymentStatus.ACTIVE) {
        throw new Error(`Cannot assign faculty with employment status '${faculty.employment_status}'.`);
      }

      // Check duplicate active assignment for same faculty, course, section, semester, academic_year
      const duplicate = this.state.facultyAssignments.find(
        (f) =>
          f.employee_id === data.employee_id &&
          f.course_code === data.course_code &&
          f.section === data.section &&
          f.semester === data.semester &&
          f.academic_year === data.academic_year &&
          f.assignment_status === 'ACTIVE'
      );
      if (duplicate) {
        throw new Error(
          `Duplicate Assignment: Faculty member '${faculty.first_name} ${faculty.last_name}' already has an active assignment for ${data.course_code} (Section ${data.section}) in semester ${data.semester}.`
        );
      }

      const newId = `FCA-2026-${String(this.state.facultyAssignments.length + 1).padStart(3, '0')}`;
      const record: FacultyCourseAssignmentRecord = {
        ...data,
        faculty_assignment_id: newId,
        assignment_status: data.assignment_status || 'ACTIVE',
        created_at: new Date().toISOString(),
      };

      // Also update or sync course offering if matching
      const updatedOfferings = this.state.courseOfferings.map((off) => {
        if (
          off.course_code === data.course_code &&
          off.section === data.section &&
          off.semester === data.semester &&
          off.academic_year === data.academic_year
        ) {
          return {
            ...off,
            assigned_faculty_id: faculty.employee_id,
            assigned_faculty_reg: faculty.registration_number,
            assigned_faculty_name: `${faculty.first_name} ${faculty.last_name}`,
          };
        }
        return off;
      });

      const nextState = {
        ...this.state,
        facultyAssignments: [...this.state.facultyAssignments, record],
        courseOfferings: updatedOfferings,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.COURSE_ASSIGN,
        target_worksheet: 'FacultyCourseAssignments',
        target_record_id: newId,
        description: `Faculty ${faculty.registration_number} (${faculty.first_name} ${faculty.last_name}) assigned to course ${data.course_code} (Section ${data.section}), Semester ${data.semester}.`,
      });

      return record;
    },
  };

  // ---------------------------------------------------------------------------
  // OFFICE ASSIGNMENTS (NON-TEACHING ONLY)
  // ---------------------------------------------------------------------------
  public officeAssignments = {
    getAll: async (): Promise<OfficeAssignmentRecord[]> => {
      return [...this.state.officeAssignments];
    },
    getByEmployee: async (employeeId: string): Promise<OfficeAssignmentRecord[]> => {
      return this.state.officeAssignments.filter((a) => a.employee_id === employeeId);
    },
    getByOffice: async (officeId: string): Promise<OfficeAssignmentRecord[]> => {
      return this.state.officeAssignments.filter((a) => a.office_id === officeId);
    },
    assign: async (data: Omit<OfficeAssignmentRecord, 'assignment_id' | 'created_at'>): Promise<OfficeAssignmentRecord> => {
      const emp = this.state.employees.find((e) => e.employee_id === data.employee_id);
      if (!emp) {
        throw new Error(`Employee with ID ${data.employee_id} not found.`);
      }

      // REQUIREMENT 2: Teaching faculty are managed through Academic Office course assignments, not non-teaching office assignments
      if (emp.category === EmployeeCategory.TEACHING) {
        throw new Error('Teaching faculty cannot be assigned to administrative offices. Teaching faculty are allocated to courses via Academic Office.');
      }

      // REQUIREMENT 8: Protect permanent offices
      const targetOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id === data.office_id);
      if (!targetOffice) {
        throw new Error(`Target office '${data.office_id}' is not a valid Permanent Office.`);
      }

      // REQUIREMENT 6: Prevent duplicate active assignments
      const existingActive = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === data.employee_id &&
          a.office_id === data.office_id &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (existingActive) {
        throw new Error(`Staff member ${emp.first_name} ${emp.last_name} already has an active assignment in ${targetOffice.office_name}.`);
      }

      const newId = `OAS-2026-${String(this.state.officeAssignments.length + 1).padStart(3, '0')}`;
      const record: OfficeAssignmentRecord = {
        ...data,
        assignment_id: newId,
        assignment_status: OfficeAssignmentStatus.ACTIVE,
        effective_from: data.effective_from || new Date().toISOString().split('T')[0],
        created_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        officeAssignments: [...this.state.officeAssignments, record],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: 'admin',
        actor_role: AuthRole.SUPER_ADMIN,
        action: AuditAction.OFFICE_ASSIGN,
        target_worksheet: 'OfficeAssignments',
        target_record_id: newId,
        description: `Assigned non-teaching staff ${emp.first_name} ${emp.last_name} to ${targetOffice.office_name} as ${data.assigned_role_title}.`,
      });

      return record;
    },
    transfer: async (assignmentId: string, newOfficeId: string, newRoleTitle?: string): Promise<OfficeAssignmentRecord> => {
      const assignment = this.state.officeAssignments.find((a) => a.assignment_id === assignmentId);
      if (!assignment) {
        throw new Error(`Assignment with ID ${assignmentId} not found.`);
      }
      if (assignment.assignment_status !== OfficeAssignmentStatus.ACTIVE) {
        throw new Error('Only active assignments can be transferred.');
      }

      const targetOffice = SIX_PERMANENT_OFFICES.find((o) => o.office_id === newOfficeId);
      if (!targetOffice) {
        throw new Error(`Target office '${newOfficeId}' is not a valid Permanent Office.`);
      }

      const emp = this.state.employees.find((e) => e.employee_id === assignment.employee_id);
      if (!emp) {
        throw new Error(`Employee not found for assignment ${assignmentId}.`);
      }

      // Check duplicate in target office
      const existingInTarget = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === assignment.employee_id &&
          a.office_id === newOfficeId &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE &&
          a.assignment_id !== assignmentId
      );
      if (existingInTarget) {
        throw new Error(`Staff member ${emp.first_name} ${emp.last_name} already has an active assignment in ${targetOffice.office_name}.`);
      }

      const today = new Date().toISOString().split('T')[0];

      // Mark old assignment as TRANSFERRED
      const updatedOld: OfficeAssignmentRecord = {
        ...assignment,
        assignment_status: OfficeAssignmentStatus.TRANSFERRED,
        effective_to: today,
      };

      // Create new assignment in destination office
      const newId = `OAS-2026-${String(this.state.officeAssignments.length + 1).padStart(3, '0')}`;
      const newAssignment: OfficeAssignmentRecord = {
        assignment_id: newId,
        employee_id: assignment.employee_id,
        office_id: newOfficeId,
        assigned_role_title: newRoleTitle?.trim() || assignment.assigned_role_title,
        assignment_status: OfficeAssignmentStatus.ACTIVE,
        assigned_by_employee_id: assignment.assigned_by_employee_id,
        effective_from: today,
        created_at: new Date().toISOString(),
      };

      const nextAssignments = this.state.officeAssignments.map((a) =>
        a.assignment_id === assignmentId ? updatedOld : a
      );
      nextAssignments.push(newAssignment);

      const nextState = {
        ...this.state,
        officeAssignments: nextAssignments,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: 'admin',
        actor_role: AuthRole.SUPER_ADMIN,
        action: AuditAction.OFFICE_ASSIGN,
        target_worksheet: 'OfficeAssignments',
        target_record_id: newId,
        description: `Transferred staff member ${emp.first_name} ${emp.last_name} from ${assignment.office_id} to ${targetOffice.office_name}.`,
      });

      return newAssignment;
    },
    revoke: async (assignmentId: string): Promise<void> => {
      const assignment = this.state.officeAssignments.find((a) => a.assignment_id === assignmentId);
      if (!assignment) {
        throw new Error(`Assignment with ID ${assignmentId} not found.`);
      }

      const today = new Date().toISOString().split('T')[0];
      const nextState = {
        ...this.state,
        officeAssignments: this.state.officeAssignments.map((a) =>
          a.assignment_id === assignmentId
            ? { ...a, assignment_status: OfficeAssignmentStatus.REVOKED, effective_to: today }
            : a
        ),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: 'admin',
        actor_role: AuthRole.SUPER_ADMIN,
        action: AuditAction.OFFICE_ASSIGN,
        target_worksheet: 'OfficeAssignments',
        target_record_id: assignmentId,
        description: `Revoked office assignment ${assignmentId} for employee ${assignment.employee_id}.`,
      });
    },
  };

  // ---------------------------------------------------------------------------
  // OFFICE PERMISSIONS
  // ---------------------------------------------------------------------------
  public officePermissions = {
    getByOffice: async (officeId: string): Promise<OfficePermissionRecord[]> => {
      return this.state.officePermissions.filter((p) => p.office_id === officeId && p.status === 'ACTIVE');
    },
    getByEmployee: async (employeeId: string): Promise<OfficePermissionRecord[]> => {
      return this.state.officePermissions.filter((p) => p.employee_id === employeeId && p.status === 'ACTIVE');
    },
    grant: async (data: Omit<OfficePermissionRecord, 'permission_id' | 'granted_at'>): Promise<OfficePermissionRecord> => {
      const newId = `OPM-2026-${String(this.state.officePermissions.length + 1).padStart(3, '0')}`;
      const record: OfficePermissionRecord = {
        ...data,
        permission_id: newId,
        granted_at: new Date().toISOString(),
      };
      const nextState = {
        ...this.state,
        officePermissions: [...this.state.officePermissions, record],
      };
      this.saveState(nextState);
      return record;
    },
    revoke: async (permissionId: string): Promise<void> => {
      const nextState = {
        ...this.state,
        officePermissions: this.state.officePermissions.map((p) =>
          p.permission_id === permissionId ? { ...p, status: 'REVOKED' as const } : p
        ),
      };
      this.saveState(nextState);
    },
  };

  // ---------------------------------------------------------------------------
  // ACADEMIC OFFICE AUTHORIZATION & VALIDATION HELPERS (Phase 7)
  // ---------------------------------------------------------------------------
  private verifyAcademicAccess(
    actor?: { userId?: string; role?: string; employeeId?: string },
    requiredScope?: PermissionScope
  ): void {
    if (!actor) return; // Permitted if called without explicit actor in internal dev flows

    // 1. Super Admin universal institutional oversight
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin') {
      return;
    }

    // 2. Permanent Academic Office account
    if (
      actor.userId === 'academicoffice' ||
      (actor.role === AuthRole.OFFICE_ADMIN && actor.userId === 'academicoffice')
    ) {
      return;
    }

    // 2b. Block other permanent office accounts without Academic Office assignment
    if (['admissionsoffice', 'coeoffice', 'finance', 'financeoffice', 'hosteloffice'].includes(actor.userId || '')) {
      throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Academic Office.`);
    }

    // 3. Reject faculty, student, parent from managing Academic Office
    if (
      actor.role === AuthRole.FACULTY ||
      actor.role === AuthRole.STUDENT ||
      actor.role === AuthRole.PARENT
    ) {
      throw new Error(`Unauthorized: Role '${actor.role}' cannot access Academic Office administration.`);
    }

    // 4. Non-teaching employee: must have active assignment to Academic Office (PO-003)
    if (actor.employeeId) {
      const activeAssignment = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === actor.employeeId &&
          a.office_id === 'PO-003' &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (!activeAssignment) {
        throw new Error('Access Denied: Staff member is not assigned to Academic Office.');
      }

      // Check required scope if specified
      if (requiredScope) {
        const hasPerm = this.state.officePermissions.some((p) => {
          if (p.employee_id !== actor.employeeId || p.office_id !== 'PO-003' || p.status !== 'ACTIVE') {
            return false;
          }
          if (p.permission_scope === PermissionScope.ADMIN) return true;
          if (p.permission_scope === requiredScope) return true;
          if (
            requiredScope === PermissionScope.READ &&
            [PermissionScope.WRITE, PermissionScope.APPROVE, PermissionScope.AUDIT].includes(p.permission_scope)
          ) {
            return true;
          }
          if (requiredScope === PermissionScope.WRITE && [PermissionScope.APPROVE].includes(p.permission_scope)) {
            return true;
          }
          return false;
        });

        if (!hasPerm) {
          throw new Error(`Access Denied: Missing required '${requiredScope}' permission scope for Academic Office.`);
        }
      }
      return;
    }

    throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Academic Office.`);
  }

  private normalizeDepartment(dept?: string): string {
    if (!dept) return '';
    const upper = dept.trim().toUpperCase();
    const map: Record<string, string> = {
      'CSE': 'CSE',
      'COMPUTER SCIENCE & ENGINEERING': 'CSE',
      'COMPUTER SCIENCE AND ENGINEERING': 'CSE',
      'ECE': 'ECE',
      'ELECTRONICS & COMMUNICATION': 'ECE',
      'ELECTRONICS & COMMUNICATION ENGINEERING': 'ECE',
      'MECH': 'MECH',
      'MECHANICAL ENGINEERING': 'MECH',
      'CIVIL': 'CIVIL',
      'CIVIL ENGINEERING': 'CIVIL',
      'IT': 'IT',
      'INFORMATION TECHNOLOGY': 'IT',
      'MATH': 'MATH',
      'MATHEMATICS': 'MATH',
      'HUMANITIES': 'HUMANITIES',
    };
    return map[upper] || upper;
  }

  private validateOfferingCurriculumAndData(
    data: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>
  ): { course: CourseRecord; capacity: number } {
    if (!data.course_code?.trim()) {
      throw new Error('Course code is required.');
    }
    if (!data.academic_year?.trim()) {
      throw new Error('Academic year is required.');
    }
    if (!data.section?.trim()) {
      throw new Error('Section is required.');
    }
    if (typeof data.semester !== 'number' || data.semester < 1 || data.semester > 8) {
      throw new Error('Valid semester (1-8) is required.');
    }

    const course = this.state.courses.find((c) => c.course_code === data.course_code);
    if (!course) {
      throw new Error(`Course with code '${data.course_code}' does not exist in curriculum.`);
    }
    if (course.status !== 'ACTIVE' && (course as any).status !== 'active') {
      throw new Error(`Course '${data.course_code}' is archived or inactive in curriculum.`);
    }

    // Department compatibility
    if (data.department) {
      const normCourseDept = this.normalizeDepartment(course.department);
      const normDataDept = this.normalizeDepartment(data.department);
      if (normCourseDept && normDataDept && normCourseDept !== normDataDept) {
        throw new Error(`Course department '${course.department}' does not match offering department '${data.department}'.`);
      }
    }

    // Semester compatibility
    if (typeof course.semester === 'number' && course.semester !== data.semester) {
      throw new Error(`Course '${data.course_code}' belongs to Semester ${course.semester}, but offering was requested for Semester ${data.semester}.`);
    }

    // Capacity validation: default to 60 if omitted, but if passed must be positive
    let capacity = 60;
    if (data.max_capacity !== undefined && data.max_capacity !== null) {
      capacity = Number(data.max_capacity);
      if (isNaN(capacity) || capacity <= 0) {
        throw new Error('Offering capacity must be a positive integer greater than zero.');
      }
    }

    return { course, capacity };
  }

  private validateFacultyForOffering(
    facultyId?: string,
    offeringDept?: string,
    offeringStatus?: string
  ): EmployeeRecord | null {
    if (!facultyId || facultyId.trim() === '') {
      if (offeringStatus === 'PUBLISHED') {
        throw new Error('A valid teaching faculty member is required to publish an offering. Select an instructor or save as DRAFT.');
      }
      return null;
    }

    const faculty = this.state.employees.find(
      (e) => e.employee_id === facultyId || e.registration_number === facultyId
    );
    if (!faculty) {
      throw new Error(`Faculty employee '${facultyId}' does not exist.`);
    }

    if (faculty.category !== EmployeeCategory.TEACHING && (faculty as any).category !== 'TEACHING') {
      throw new Error(`Assigned faculty '${faculty.first_name} ${faculty.last_name}' must be an active teaching faculty member.`);
    }

    if (faculty.employment_status !== EmploymentStatus.ACTIVE && (faculty as any).employment_status !== 'ACTIVE') {
      throw new Error(`Cannot assign faculty '${faculty.first_name} ${faculty.last_name}': Employment status is ${faculty.employment_status}.`);
    }

    if (offeringDept) {
      const normFacDept = this.normalizeDepartment(faculty.primary_department);
      const normOffDept = this.normalizeDepartment(offeringDept);
      if (normFacDept && normOffDept && normFacDept !== normOffDept) {
        throw new Error(
          `Faculty department '${faculty.primary_department}' is incompatible with offering department '${offeringDept}'.`
        );
      }
    }

    return faculty;
  }

  private checkOfferingTimetableConflicts(
    slotData: {
      academic_year: string;
      semester: number;
      day_of_week: string;
      start_time: string;
      end_time: string;
      room: string;
      course_code: string;
      section: string;
      department: string;
      faculty_id?: string;
      faculty_name?: string;
    },
    excludeSlotId?: string
  ): void {
    if (!slotData.start_time || !slotData.end_time) {
      throw new Error('Start time and end time are required for timetable scheduling.');
    }
    if (slotData.start_time >= slotData.end_time) {
      throw new Error(`Invalid timetable slot: start_time ('${slotData.start_time}') must be earlier than end_time ('${slotData.end_time}').`);
    }
    if (!slotData.room?.trim()) {
      throw new Error('Classroom / laboratory room is required for timetable scheduling.');
    }

    const candidateSlots = this.state.timetableSlots.filter(
      (s) =>
        (s.status === 'ACTIVE' || s.status === 'SCHEDULED') &&
        s.academic_year === slotData.academic_year &&
        s.semester === slotData.semester &&
        s.day_of_week === slotData.day_of_week &&
        (!excludeSlotId || s.slot_id !== excludeSlotId)
    );

    for (const existing of candidateSlots) {
      const overlaps = slotData.start_time < existing.end_time && existing.start_time < slotData.end_time;
      if (overlaps) {
        // 1. Room conflict
        if (
          existing.room.trim().toLowerCase() === slotData.room.trim().toLowerCase() ||
          (existing.room_number && existing.room_number.trim().toLowerCase() === slotData.room.trim().toLowerCase())
        ) {
          throw new Error(
            `Timetable Conflict (Room): Room '${slotData.room}' is already booked on ${slotData.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code} (Section ${existing.section}).`
          );
        }

        // 2. Faculty conflict
        if (slotData.faculty_id && existing.faculty_id === slotData.faculty_id) {
          throw new Error(
            `Timetable Conflict (Faculty): Faculty '${slotData.faculty_name || 'Assigned Instructor'}' is already scheduled on ${slotData.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code} (Section ${existing.section}).`
          );
        }

        // 3. Section conflict
        if (
          (existing.course_code === slotData.course_code || this.normalizeDepartment(existing.department) === this.normalizeDepartment(slotData.department)) &&
          existing.section === slotData.section
        ) {
          throw new Error(
            `Timetable Conflict (Section): Section '${slotData.section}' is already scheduled on ${slotData.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code}.`
          );
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // COE OFFICE AUTHORIZATION & VALIDATION HELPERS (Phase 8)
  // ---------------------------------------------------------------------------
  private verifyCoeAccess(
    actor?: { userId?: string; role?: string; employeeId?: string },
    requiredScope?: PermissionScope
  ): void {
    if (!actor) return; // Permitted if called without explicit actor in internal dev flows

    // 1. Super Admin universal institutional oversight
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin') {
      return;
    }

    // 2. Permanent COE Office account
    if (
      actor.userId === 'coeoffice' ||
      (actor.role === AuthRole.OFFICE_ADMIN && actor.userId === 'coeoffice')
    ) {
      return;
    }

    // 3. Other office accounts explicitly blocked without COE assignment
    if (['admissionsoffice', 'academicoffice', 'finance', 'hosteloffice'].includes(actor.userId || '')) {
      throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access COE Office.`);
    }

    // 4. Reject faculty, student, parent from managing COE Office administration
    if (
      actor.role === AuthRole.FACULTY ||
      actor.role === AuthRole.STUDENT ||
      actor.role === AuthRole.PARENT
    ) {
      throw new Error(`Unauthorized: Role '${actor.role}' cannot access COE Office administration.`);
    }

    // 5. Non-teaching employee: must have active assignment to COE Office (PO-004)
    if (actor.employeeId) {
      const activeAssignment = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === actor.employeeId &&
          a.office_id === 'PO-004' &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (!activeAssignment) {
        throw new Error('Access Denied: Staff member is not assigned to Controller of Examinations (COE) Office.');
      }

      // Check required scope if specified
      if (requiredScope) {
        const hasPerm = this.state.officePermissions.some((p) => {
          if (p.employee_id !== actor.employeeId || p.office_id !== 'PO-004' || p.status !== 'ACTIVE') {
            return false;
          }
          if (p.permission_scope === PermissionScope.ADMIN) return true;
          if (p.permission_scope === requiredScope) return true;
          if (
            requiredScope === PermissionScope.READ &&
            [PermissionScope.WRITE, PermissionScope.APPROVE, PermissionScope.AUDIT].includes(p.permission_scope)
          ) {
            return true;
          }
          if (requiredScope === PermissionScope.WRITE && [PermissionScope.APPROVE].includes(p.permission_scope)) {
            return true;
          }
          return false;
        });

        if (!hasPerm) {
          throw new Error(`Access Denied: Missing required '${requiredScope}' permission scope for COE Office.`);
        }
      }
      return;
    }

    throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access COE Office.`);
  }

  // ---------------------------------------------------------------------------
  // FINANCE OFFICE AUTHORIZATION & VALIDATION HELPERS (Phase 9)
  // ---------------------------------------------------------------------------
  private verifyFinanceAccess(
    actor?: { userId?: string; role?: string; employeeId?: string },
    requiredScope?: PermissionScope,
    moduleName?: string
  ): void {
    if (!actor) return; // Dev internal bypass

    // 1. Super Admin universal institutional oversight
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin') {
      return;
    }

    // 2. Canonical Finance Office account (finance / financeoffice)
    if (
      actor.userId === 'finance' ||
      actor.userId === 'financeoffice' ||
      (actor.role === AuthRole.OFFICE_ADMIN && (actor.userId === 'finance' || actor.userId === 'financeoffice'))
    ) {
      return;
    }

    // 3. Other permanent offices explicitly blocked from Finance Office
    if (['admissionsoffice', 'academicoffice', 'coeoffice', 'hosteloffice'].includes(actor.userId || '')) {
      throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Finance Office.`);
    }

    // 4. Reject faculty, student, parent from Finance Office administration
    if (
      actor.role === AuthRole.FACULTY ||
      actor.role === AuthRole.STUDENT ||
      actor.role === AuthRole.PARENT
    ) {
      throw new Error(`Unauthorized: Role '${actor.role}' cannot access Finance Office administration.`);
    }

    // 5. Non-teaching employee: must have active assignment to Finance Office (PO-005)
    if (actor.employeeId) {
      const activeAssignment = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === actor.employeeId &&
          a.office_id === 'PO-005' &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (!activeAssignment) {
        throw new Error('Access Denied: Staff member is not assigned to Finance Office.');
      }

      // Check required scope / module if specified
      if (requiredScope || moduleName) {
        const hasPerm = this.state.officePermissions.some((p) => {
          if (p.employee_id !== actor.employeeId || p.office_id !== 'PO-005' || p.status !== 'ACTIVE') {
            return false;
          }
          if (moduleName && p.module_name && p.module_name !== moduleName && p.permission_scope !== PermissionScope.ADMIN) {
            return false;
          }
          if (p.permission_scope === PermissionScope.ADMIN) return true;
          if (requiredScope && p.permission_scope === requiredScope) return true;
          if (
            requiredScope === PermissionScope.READ &&
            [PermissionScope.WRITE, PermissionScope.APPROVE, PermissionScope.AUDIT].includes(p.permission_scope)
          ) {
            return true;
          }
          if (requiredScope === PermissionScope.WRITE && [PermissionScope.APPROVE].includes(p.permission_scope)) {
            return true;
          }
          return false;
        });

        if (!hasPerm) {
          throw new Error(
            `Access Denied: Missing required '${requiredScope || moduleName}' permission scope for Finance Office.`
          );
        }
      }
      return;
    }

    throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Finance Office.`);
  }

  // ---------------------------------------------------------------------------
  // HOSTEL OFFICE AUTHORIZATION & VALIDATION HELPERS (Phase 9)
  // ---------------------------------------------------------------------------
  private verifyHostelAccess(
    actor?: { userId?: string; role?: string; employeeId?: string },
    requiredScope?: PermissionScope,
    moduleName?: string
  ): void {
    if (!actor) return; // Dev internal bypass

    // 1. Super Admin universal institutional oversight
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin') {
      return;
    }

    // 2. Canonical Hostel Office account (hosteloffice)
    if (
      actor.userId === 'hosteloffice' ||
      actor.userId === 'Hostel Administration Office' ||
      (actor.role === AuthRole.OFFICE_ADMIN && (actor.userId === 'hosteloffice' || actor.userId === 'Hostel Administration Office'))
    ) {
      return;
    }

    // 3. Other permanent offices explicitly blocked from Hostel Office
    if (['admissionsoffice', 'academicoffice', 'coeoffice', 'finance', 'financeoffice'].includes(actor.userId || '')) {
      throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Hostel Office.`);
    }

    // 4. Reject faculty, student, parent from Hostel Office administration
    if (
      actor.role === AuthRole.FACULTY ||
      actor.role === AuthRole.STUDENT ||
      actor.role === AuthRole.PARENT
    ) {
      throw new Error(`Unauthorized: Role '${actor.role}' cannot access Hostel Office administration.`);
    }

    // 5. Non-teaching employee: must have active assignment to Hostel Office (PO-006)
    if (actor.employeeId) {
      const activeAssignment = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === actor.employeeId &&
          a.office_id === 'PO-006' &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (!activeAssignment) {
        throw new Error('Access Denied: Staff member is not assigned to Hostel Office.');
      }

      // Check required scope / module if specified
      if (requiredScope || moduleName) {
        const hasPerm = this.state.officePermissions.some((p) => {
          if (p.employee_id !== actor.employeeId || p.office_id !== 'PO-006' || p.status !== 'ACTIVE') {
            return false;
          }
          if (moduleName && p.module_name && p.module_name !== moduleName && p.permission_scope !== PermissionScope.ADMIN) {
            return false;
          }
          if (p.permission_scope === PermissionScope.ADMIN) return true;
          if (requiredScope && p.permission_scope === requiredScope) return true;
          if (
            requiredScope === PermissionScope.READ &&
            [PermissionScope.WRITE, PermissionScope.APPROVE, PermissionScope.AUDIT].includes(p.permission_scope)
          ) {
            return true;
          }
          if (requiredScope === PermissionScope.WRITE && [PermissionScope.APPROVE].includes(p.permission_scope)) {
            return true;
          }
          return false;
        });

        if (!hasPerm) {
          throw new Error(
            `Access Denied: Missing required '${requiredScope || moduleName}' permission scope for Hostel Office.`
          );
        }
      }
      return;
    }

    throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Hostel Office.`);
  }

  private roundCurrencyAmount(val: number): number {
    return Math.round((val + Number.EPSILON) * 100) / 100;
  }

  private verifyFacultyExamCourseAccess(
    courseCode: string,
    section: string | undefined,
    actor?: { userId?: string; role?: string; employeeId?: string }
  ): void {
    if (!actor) return;
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin' || actor.userId === 'coeoffice') {
      return;
    }

    const empId =
      actor.employeeId ||
      this.state.employees.find((e) => e.registration_number === actor.userId)?.employee_id ||
      actor.userId;

    const assignment = this.state.facultyAssignments.find(
      (f) =>
        f.employee_id === empId &&
        f.course_code === courseCode &&
        f.assignment_status === 'ACTIVE' &&
        (!section || section === 'ALL' || f.section === section)
    );

    if (!assignment) {
      throw new Error(
        `Unauthorized: Faculty member '${empId}' is not assigned to course '${courseCode}'${
          section && section !== 'ALL' ? ` (Section ${section})` : ''
        }.`
      );
    }
  }

  private calculateDemonstrationGrade(
    totalMarks: number,
    maxMarks: number,
    passingMarks: number,
    isAbsent: boolean = false,
    isExempted: boolean = false
  ): {
    percentage: number;
    grade: string;
    grade_point: number;
    resultStatus: ExamResultStatus;
  } {
    if (isAbsent) {
      return { percentage: 0, grade: 'AB', grade_point: 0.0, resultStatus: ExamResultStatus.ABSENT };
    }
    if (isExempted) {
      return { percentage: 0, grade: 'EX', grade_point: 0.0, resultStatus: ExamResultStatus.EXEMPTED };
    }
    if (maxMarks <= 0) {
      return { percentage: 0, grade: 'F', grade_point: 0.0, resultStatus: ExamResultStatus.FAIL };
    }

    const percentage = Number(((totalMarks / maxMarks) * 100).toFixed(1));
    const passed = totalMarks >= passingMarks;

    if (!passed) {
      return { percentage, grade: 'F', grade_point: 0.0, resultStatus: ExamResultStatus.FAIL };
    }

    // Configured demonstration grading scale
    if (percentage >= 90) return { percentage, grade: 'O', grade_point: 10.0, resultStatus: ExamResultStatus.PASS };
    if (percentage >= 80) return { percentage, grade: 'A+', grade_point: 9.0, resultStatus: ExamResultStatus.PASS };
    if (percentage >= 70) return { percentage, grade: 'A', grade_point: 8.0, resultStatus: ExamResultStatus.PASS };
    if (percentage >= 60) return { percentage, grade: 'B+', grade_point: 7.0, resultStatus: ExamResultStatus.PASS };
    if (percentage >= 50) return { percentage, grade: 'B', grade_point: 6.0, resultStatus: ExamResultStatus.PASS };
    if (percentage >= 40) return { percentage, grade: 'C', grade_point: 5.0, resultStatus: ExamResultStatus.PASS };
    return { percentage, grade: 'F', grade_point: 0.0, resultStatus: ExamResultStatus.FAIL };
  }

  // ---------------------------------------------------------------------------
  // ADMISSIONS OFFICE AUTHORIZATION & VALIDATION HELPERS (Phase 6)
  // ---------------------------------------------------------------------------
  private verifyAdmissionsAccess(
    actor?: { userId?: string; role?: string; employeeId?: string },
    requiredScope?: PermissionScope
  ): void {
    if (!actor) return; // Permitted if called without explicit actor in internal dev flows

    // 1. Super Admin universal access
    if (actor.role === AuthRole.SUPER_ADMIN || actor.userId === 'admin') {
      return;
    }

    // 2. Permanent Admissions Office account
    if (actor.userId === 'admissionsoffice' || (actor.role === AuthRole.OFFICE_ADMIN && actor.userId === 'admissionsoffice')) {
      return;
    }

    // 3. Reject faculty, student, parent
    if (
      actor.role === AuthRole.FACULTY ||
      actor.role === AuthRole.STUDENT ||
      actor.role === AuthRole.PARENT
    ) {
      throw new Error(`Unauthorized: Role '${actor.role}' cannot access Admissions Office administration.`);
    }

    // 4. Non-teaching employee: must have active assignment to Admissions Office (PO-002)
    if (actor.employeeId) {
      const activeAssignment = this.state.officeAssignments.find(
        (a) =>
          a.employee_id === actor.employeeId &&
          a.office_id === 'PO-002' &&
          a.assignment_status === OfficeAssignmentStatus.ACTIVE
      );
      if (!activeAssignment) {
        throw new Error('Access Denied: Staff member is not assigned to Admissions Office.');
      }

      // Check required scope if specified
      if (requiredScope) {
        const hasPerm = this.state.officePermissions.some((p) => {
          if (p.employee_id !== actor.employeeId || p.office_id !== 'PO-002' || p.status !== 'ACTIVE') {
            return false;
          }
          if (p.permission_scope === PermissionScope.ADMIN) return true;
          if (p.permission_scope === requiredScope) return true;
          if (
            requiredScope === PermissionScope.READ &&
            [PermissionScope.WRITE, PermissionScope.APPROVE, PermissionScope.AUDIT].includes(p.permission_scope)
          ) {
            return true;
          }
          if (requiredScope === PermissionScope.WRITE && [PermissionScope.APPROVE].includes(p.permission_scope)) {
            return true;
          }
          return false;
        });

        if (!hasPerm) {
          throw new Error(`Access Denied: Missing required '${requiredScope}' permission scope for Admissions Office.`);
        }
      }
      return;
    }

    throw new Error(`Unauthorized: User '${actor.userId}' is not permitted to access Admissions Office.`);
  }

  private validateStatusTransition(current: ApplicationStatus, next: ApplicationStatus): void {
    if (current === next) return;

    const validTransitions: Record<ApplicationStatus, ApplicationStatus[]> = {
      [ApplicationStatus.DRAFT]: [ApplicationStatus.SUBMITTED, ApplicationStatus.WITHDRAWN],
      [ApplicationStatus.SUBMITTED]: [ApplicationStatus.UNDER_REVIEW, ApplicationStatus.DOCUMENTS_PENDING, ApplicationStatus.WITHDRAWN],
      [ApplicationStatus.UNDER_REVIEW]: [ApplicationStatus.DOCUMENTS_PENDING, ApplicationStatus.APPROVED, ApplicationStatus.REJECTED, ApplicationStatus.WITHDRAWN],
      [ApplicationStatus.DOCUMENTS_PENDING]: [ApplicationStatus.UNDER_REVIEW, ApplicationStatus.SUBMITTED, ApplicationStatus.REJECTED, ApplicationStatus.WITHDRAWN],
      [ApplicationStatus.APPROVED]: [ApplicationStatus.WITHDRAWN],
      [ApplicationStatus.REJECTED]: [ApplicationStatus.UNDER_REVIEW], // Allowed for appeal / reconsideration
      [ApplicationStatus.WITHDRAWN]: [], // Terminal state
    };

    const allowed = validTransitions[current] || [];
    if (!allowed.includes(next)) {
      throw new Error(`Invalid application status transition from ${current} to ${next}.`);
    }
  }

  // ---------------------------------------------------------------------------
  // APPLICANTS & ADMISSIONS (Phase 6)
  // ---------------------------------------------------------------------------
  public applicants = {
    getAll: async (): Promise<ApplicantRecord[]> => {
      return [...this.state.applicants];
    },

    getById: async (id: string): Promise<ApplicantRecord | null> => {
      return this.state.applicants.find((a) => a.application_id === id) || null;
    },

    create: async (
      data: Omit<ApplicantRecord, 'application_id' | 'documents' | 'status_history' | 'converted_to_student' | 'created_at' | 'updated_at'> & {
        documents?: Partial<ApplicantDocumentRecord>[];
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord> => {
      this.verifyAdmissionsAccess(actor, PermissionScope.WRITE);

      // Validation
      if (!data.first_name || data.first_name.trim().length < 2) {
        throw new Error('First name is required (minimum 2 characters).');
      }
      if (!data.last_name || data.last_name.trim().length < 1) {
        throw new Error('Last name is required.');
      }
      if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
        throw new Error(`Invalid email address format: '${data.email}'.`);
      }
      if (!data.phone_number || data.phone_number.trim().length < 7) {
        throw new Error('Contact phone number is required.');
      }
      if (!data.date_of_birth || isNaN(Date.parse(data.date_of_birth))) {
        throw new Error('Valid date of birth is required.');
      }
      const birthYear = new Date(data.date_of_birth).getFullYear();
      const currentYear = new Date().getFullYear();
      if (currentYear - birthYear < 14) {
        throw new Error('Applicant must be at least 14 years of age for college admission.');
      }
      if (!data.intended_program || !data.intended_program.trim()) {
        throw new Error('Intended programme is required.');
      }
      if (!data.previous_qualification || !data.previous_qualification.trim()) {
        throw new Error('Previous qualification is required.');
      }
      if (
        typeof data.marks_percentage !== 'number' ||
        isNaN(data.marks_percentage) ||
        data.marks_percentage < 0 ||
        data.marks_percentage > 100
      ) {
        throw new Error('Marks or percentage must be a valid number between 0 and 100.');
      }

      const admissionYear = data.admission_year || 2026;
      const department = data.department || 'CSE';

      // Duplicate prevention:
      // 1. Same email for same admission year
      const duplicateEmail = this.state.applicants.find(
        (a) =>
          a.admission_year === admissionYear &&
          a.email.toLowerCase().trim() === data.email.toLowerCase().trim()
      );
      if (duplicateEmail) {
        throw new Error(`An application with email '${data.email}' already exists for admission year ${admissionYear}.`);
      }

      // 2. Same candidate identity (name, date of birth, intended program in same admission year)
      const duplicateCandidate = this.state.applicants.find(
        (a) =>
          a.admission_year === admissionYear &&
          a.first_name.toLowerCase().trim() === data.first_name.toLowerCase().trim() &&
          a.last_name.toLowerCase().trim() === data.last_name.toLowerCase().trim() &&
          a.date_of_birth === data.date_of_birth &&
          a.intended_program.toLowerCase().trim() === data.intended_program.toLowerCase().trim()
      );
      if (duplicateCandidate) {
        throw new Error(
          `An identical application for '${data.first_name} ${data.last_name}' in ${data.intended_program} already exists for ${admissionYear}.`
        );
      }

      // Generate Unique Application ID
      const newAppId = allocateNextApplicationId(
        this.state.applicants.map((a) => a.application_id),
        admissionYear
      );

      // Default required document checklist
      const defaultDocs: ApplicantDocumentRecord[] = [
        {
          document_id: `DOC-${newAppId}-1`,
          application_id: newAppId,
          document_type: '10th Grade Marksheet / Secondary School Certificate',
          document_code: 'DOC_10TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: `DOC-${newAppId}-2`,
          application_id: newAppId,
          document_type: '12th Grade Marksheet / Higher Secondary Certificate',
          document_code: 'DOC_12TH',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: `DOC-${newAppId}-3`,
          application_id: newAppId,
          document_type: 'Transfer / Migration Certificate',
          document_code: 'DOC_TC',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: `DOC-${newAppId}-4`,
          application_id: newAppId,
          document_type: 'Government Photo ID Proof (Aadhaar / Passport)',
          document_code: 'DOC_ID',
          is_mandatory: true,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
        {
          document_id: `DOC-${newAppId}-5`,
          application_id: newAppId,
          document_type: 'Conduct / Character Certificate',
          document_code: 'DOC_CONDUCT',
          is_mandatory: false,
          submission_status: DocumentSubmissionStatus.PENDING,
          verification_status: DocumentVerificationStatus.PENDING,
        },
      ];

      const initialStatus = data.application_status || ApplicationStatus.SUBMITTED;
      const initialHistory: ApplicationStatusHistoryEntry[] = [
        {
          history_id: `HST-${newAppId}-1`,
          previous_status: ApplicationStatus.DRAFT,
          new_status: initialStatus,
          changed_by: actor?.userId || 'admissions_applicant',
          timestamp: new Date().toISOString(),
          reason: 'Initial application submitted',
        },
      ];

      const newRecord: ApplicantRecord = {
        ...data,
        application_id: newAppId,
        department,
        admission_year: admissionYear,
        application_date: data.application_date || new Date().toISOString().split('T')[0],
        application_status: initialStatus,
        documents: (data.documents as ApplicantDocumentRecord[]) || defaultDocs,
        status_history: initialHistory,
        converted_to_student: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        applicants: [...this.state.applicants, newRecord],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'admissions_applicant',
        actor_role: actor?.role || 'APPLICANT',
        action: AuditAction.CREATE,
        target_worksheet: 'Applicants',
        target_record_id: newAppId,
        description: `Application ${newAppId} created for ${data.first_name} ${data.last_name} (${data.intended_program}).`,
      });

      return newRecord;
    },

    update: async (
      id: string,
      data: Partial<Omit<ApplicantRecord, 'application_id' | 'status_history' | 'created_at'>>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord> => {
      this.verifyAdmissionsAccess(actor, PermissionScope.WRITE);

      const applicant = this.state.applicants.find((a) => a.application_id === id);
      if (!applicant) {
        throw new Error(`Applicant record '${id}' not found.`);
      }

      if (data.email && data.email !== applicant.email) {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
          throw new Error(`Invalid email address format: '${data.email}'.`);
        }
        const duplicate = this.state.applicants.find(
          (a) =>
            a.application_id !== id &&
            a.admission_year === (data.admission_year || applicant.admission_year) &&
            a.email.toLowerCase().trim() === data.email!.toLowerCase().trim()
        );
        if (duplicate) {
          throw new Error(`An application with email '${data.email}' already exists.`);
        }
      }

      if (data.marks_percentage !== undefined) {
        if (
          typeof data.marks_percentage !== 'number' ||
          isNaN(data.marks_percentage) ||
          data.marks_percentage < 0 ||
          data.marks_percentage > 100
        ) {
          throw new Error('Marks or percentage must be a valid number between 0 and 100.');
        }
      }

      const updatedRecord: ApplicantRecord = {
        ...applicant,
        ...data,
        application_id: applicant.application_id, // Immutable
        converted_to_student: applicant.converted_to_student, // Immutable through update
        student_id: applicant.student_id,
        student_registration_number: applicant.student_registration_number,
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        applicants: this.state.applicants.map((a) => (a.application_id === id ? updatedRecord : a)),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'admissionsoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'Applicants',
        target_record_id: id,
        description: `Application details updated for ${applicant.first_name} ${applicant.last_name} (${id}).`,
      });

      return updatedRecord;
    },

    updateStatus: async (
      id: string,
      newStatus: ApplicationStatus,
      reason?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord> => {
      // Approvals, rejections, and withdrawals require APPROVE scope
      const requiresApproveScope = [
        ApplicationStatus.APPROVED,
        ApplicationStatus.REJECTED,
        ApplicationStatus.WITHDRAWN,
      ].includes(newStatus);

      this.verifyAdmissionsAccess(
        actor,
        requiresApproveScope ? PermissionScope.APPROVE : PermissionScope.WRITE
      );

      const applicant = this.state.applicants.find((a) => a.application_id === id);
      if (!applicant) {
        throw new Error(`Applicant record '${id}' not found.`);
      }

      this.validateStatusTransition(applicant.application_status, newStatus);

      // Validation when approving: all mandatory documents must be VERIFIED
      if (newStatus === ApplicationStatus.APPROVED) {
        const unverifiedMandatory = applicant.documents.filter(
          (d) => d.is_mandatory && d.verification_status !== DocumentVerificationStatus.VERIFIED
        );
        if (unverifiedMandatory.length > 0) {
          throw new Error(
            `Cannot approve application '${id}': ${unverifiedMandatory.length} mandatory document(s) are not yet verified (${unverifiedMandatory.map((d) => d.document_code).join(', ')}).`
          );
        }
      }

      const historyEntry: ApplicationStatusHistoryEntry = {
        history_id: `HST-${id}-${applicant.status_history.length + 1}`,
        previous_status: applicant.application_status,
        new_status: newStatus,
        changed_by: actor?.userId || 'admissionsoffice',
        timestamp: new Date().toISOString(),
        reason: reason || `Status changed from ${applicant.application_status} to ${newStatus}`,
      };

      const updatedRecord: ApplicantRecord = {
        ...applicant,
        application_status: newStatus,
        status_history: [...applicant.status_history, historyEntry],
        reviewed_by: actor?.userId || 'admissionsoffice',
        reviewed_at: new Date().toISOString(),
        decision_reason: reason || applicant.decision_reason,
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        applicants: this.state.applicants.map((a) => (a.application_id === id ? updatedRecord : a)),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'admissionsoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.ADMISSION_DECISION,
        target_worksheet: 'Applicants',
        target_record_id: id,
        description: `Application ${id} status updated from ${applicant.application_status} to ${newStatus}. Reason: ${reason || 'N/A'}.`,
      });

      return updatedRecord;
    },

    updateDocumentStatus: async (
      applicationId: string,
      documentId: string,
      updates: {
        submission_status?: 'PENDING' | 'SUBMITTED';
        verification_status?: 'PENDING' | 'VERIFIED' | 'REJECTED';
        reviewer_notes?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord> => {
      this.verifyAdmissionsAccess(actor, PermissionScope.WRITE);

      const applicant = this.state.applicants.find((a) => a.application_id === applicationId);
      if (!applicant) {
        throw new Error(`Applicant record '${applicationId}' not found.`);
      }

      const docIndex = applicant.documents.findIndex((d) => d.document_id === documentId);
      if (docIndex === -1) {
        throw new Error(`Document '${documentId}' not found in application '${applicationId}'.`);
      }

      const existingDoc = applicant.documents[docIndex];
      const updatedDoc: ApplicantDocumentRecord = {
        ...existingDoc,
        ...updates,
        verified_by: updates.verification_status ? actor?.userId || 'admissionsoffice' : existingDoc.verified_by,
        verified_at: updates.verification_status ? new Date().toISOString() : existingDoc.verified_at,
      };

      const nextDocs = [...applicant.documents];
      nextDocs[docIndex] = updatedDoc;

      const updatedApplicant: ApplicantRecord = {
        ...applicant,
        documents: nextDocs,
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        applicants: this.state.applicants.map((a) =>
          a.application_id === applicationId ? updatedApplicant : a
        ),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'admissionsoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'Applicants',
        target_record_id: applicationId,
        description: `Document ${existingDoc.document_code} status updated (submission: ${updatedDoc.submission_status}, verification: ${updatedDoc.verification_status}).`,
      });

      return updatedApplicant;
    },

    convertApprovedApplicantToStudent: async (
      applicationId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{
      success: boolean;
      student: StudentRecord;
      account?: AuthUserRecord;
      alreadyConverted?: boolean;
      message?: string;
    }> => {
      this.verifyAdmissionsAccess(actor, PermissionScope.APPROVE);

      const applicant = this.state.applicants.find((a) => a.application_id === applicationId);
      if (!applicant) {
        throw new Error(`Applicant record '${applicationId}' not found.`);
      }

      // Idempotency: Repeated clicks return the existing linked student and account
      if (applicant.converted_to_student && applicant.student_id) {
        const existingStudent = this.state.students.find((s) => s.student_id === applicant.student_id);
        const existingAccount = this.state.users.find(
          (u) =>
            u.linked_record_type === LinkedRecordType.STUDENT &&
            u.linked_record_id === applicant.student_id
        );
        if (existingStudent) {
          return {
            success: true,
            student: existingStudent,
            account: existingAccount,
            alreadyConverted: true,
            message: `Applicant ${applicationId} was already converted to student ${existingStudent.registration_number}.`,
          };
        }
      }

      // Enforce eligibility: Must be in APPROVED status
      if (applicant.application_status !== ApplicationStatus.APPROVED) {
        throw new Error(
          `Application '${applicationId}' has status '${applicant.application_status}' and is not eligible for student conversion. Only APPROVED applications can be converted.`
        );
      }

      // Required field validation
      if (!applicant.first_name || !applicant.last_name || !applicant.department) {
        throw new Error('Applicant record is missing required fields (name or department) for student conversion.');
      }

      // Allocate unique student registration number using existing EIT convention
      const existingRegs = this.state.students.map((s) => s.registration_number);
      const regNumber = allocateNextStudentRegistrationNumber(
        existingRegs,
        applicant.admission_year || 2026,
        applicant.department || 'CSE'
      );

      const newStudentId = `STU-${String(this.state.students.length + 1).padStart(3, '0')}`;
      const studentEmail = `${applicant.first_name.toLowerCase().replace(/[^a-z0-9]/g, '')}.${applicant.last_name.toLowerCase().replace(/[^a-z0-9]/g, '')}@student.eit.edu`;

      const studentRecord: StudentRecord = {
        student_id: newStudentId,
        registration_number: regNumber,
        first_name: applicant.first_name,
        last_name: applicant.last_name,
        date_of_birth: applicant.date_of_birth,
        gender: applicant.gender || 'PREFER_NOT_TO_SAY',
        institutional_email: studentEmail,
        personal_phone: applicant.phone_number,
        program_name: applicant.intended_program,
        department: applicant.department,
        admission_year: applicant.admission_year || 2026,
        current_semester: 1,
        section: 'A',
        enrollment_status: StudentStatus.ENROLLED,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Create student account record through the existing provisioning interface
      const newAuthUser: AuthUserRecord = {
        user_id: `USR-${newStudentId}`,
        username: regNumber,
        password_hash: 'dev_mock_hash_student',
        portal_type: PortalType.Student,
        role: AuthRole.STUDENT,
        linked_record_type: LinkedRecordType.STUDENT,
        linked_record_id: newStudentId,
        account_status: AccountStatus.ACTIVE,
        failed_login_attempts: 0,
        password_updated_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Link student record to originating application
      const updatedApplicant: ApplicantRecord = {
        ...applicant,
        converted_to_student: true,
        student_id: newStudentId,
        student_registration_number: regNumber,
        updated_at: new Date().toISOString(),
      };

      const nextState: DevStoreState = {
        ...this.state,
        students: [...this.state.students, studentRecord],
        users: [...this.state.users, newAuthUser],
        applicants: this.state.applicants.map((a) =>
          a.application_id === applicationId ? updatedApplicant : a
        ),
      };
      this.saveState(nextState);

      // Trigger automatic student ID card generation (Requirement 6A)
      import('./itService').then(({ itRepository }) => {
        itRepository.autoGenerateStudentIdCard(studentRecord).catch(() => {});
      }).catch(() => {});

      await this.audit.log({
        actor_id: actor?.userId || 'admissionsoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.ADMISSION_CONVERT,
        target_worksheet: 'Applicants',
        target_record_id: applicationId,
        description: `Applicant ${applicant.first_name} ${applicant.last_name} (${applicationId}) converted to student ${regNumber} (ID: ${newStudentId}).`,
      });

      return {
        success: true,
        student: studentRecord,
        account: newAuthUser,
        alreadyConverted: false,
        message: `Applicant ${applicant.first_name} ${applicant.last_name} successfully converted to enrolled student ${regNumber}.`,
      };
    },

    updateApplicationStatus: async (
      id: string,
      newStatus: ApplicationStatus,
      reason?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord> => {
      const applicant = this.state.applicants.find((a) => a.application_id === id);
      if (applicant && newStatus === ApplicationStatus.APPROVED) {
        if (applicant.application_status === ApplicationStatus.SUBMITTED) {
          await this.applicants.updateStatus(id, ApplicationStatus.UNDER_REVIEW, 'Admissions board scrutiny initiated', actor);
        }
        const currentApp = this.state.applicants.find((a) => a.application_id === id) || applicant;
        for (const doc of currentApp.documents) {
          if (doc.verification_status !== DocumentVerificationStatus.VERIFIED) {
            await this.applicants.updateDocumentStatus(
              id,
              doc.document_id,
              {
                submission_status: DocumentSubmissionStatus.SUBMITTED,
                verification_status: DocumentVerificationStatus.VERIFIED,
                reviewer_notes: 'Board approval verification',
              },
              actor
            );
          }
        }
      }
      return this.applicants.updateStatus(id, newStatus, reason, actor);
    },
  };

  public admissions = this.applicants;

  // ---------------------------------------------------------------------------
  // STUDENTS & ADMISSIONS
  // ---------------------------------------------------------------------------
  public students = {
    getAll: async (): Promise<StudentRecord[]> => {
      return [...this.state.students];
    },
    getById: async (id: string): Promise<StudentRecord | null> => {
      return this.state.students.find((s) => s.student_id === id) || null;
    },
    getByRegistrationNumber: async (regNumber: string): Promise<StudentRecord | null> => {
      return this.state.students.find((s) => s.registration_number === regNumber) || null;
    },
    create: async (data: Omit<StudentRecord, 'student_id' | 'created_at' | 'updated_at'>): Promise<StudentRecord> => {
      const newId = `STU-${String(this.state.students.length + 1).padStart(3, '0')}`;
      const existingRegs = this.state.students.map((s) => s.registration_number);
      const regNumber =
        data.registration_number ||
        allocateNextStudentRegistrationNumber(existingRegs, data.admission_year || 2026, data.department || 'CSE');

      const record: StudentRecord = {
        ...data,
        student_id: newId,
        registration_number: regNumber,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Also create login account in AuthUsers for dev testing
      const newUser: AuthUserRecord = {
        user_id: `USR-${newId}`,
        username: regNumber,
        password_hash: 'dev_mock_hash',
        portal_type: PortalType.Student,
        role: AuthRole.STUDENT,
        linked_record_type: LinkedRecordType.STUDENT,
        linked_record_id: newId,
        account_status: AccountStatus.ACTIVE,
        failed_login_attempts: 0,
        password_updated_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        students: [...this.state.students, record],
        users: [...this.state.users, newUser],
      };
      this.saveState(nextState);
      return record;
    },
  };

  // ---------------------------------------------------------------------------
  // PARENTS & LINKS
  // ---------------------------------------------------------------------------
  public parents = {
    getAll: async (): Promise<ParentRecord[]> => {
      return [...this.state.parents];
    },
    getById: async (id: string): Promise<ParentRecord | null> => {
      return this.state.parents.find((p) => p.parent_id === id) || null;
    },
    getLinkedStudents: async (
      parentIdOrActor?: string | { userId: string; role: string; employeeId?: string },
      actorArg?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ link: ParentStudentLinkRecord; student: StudentRecord }[]> => {
      // 1. Resolve actor and requested parent ID
      let actualActor: { userId: string; role: string; employeeId?: string } | undefined;
      let requestedParentId: string | undefined;

      if (typeof parentIdOrActor === 'object' && parentIdOrActor !== null) {
        actualActor = parentIdOrActor;
        requestedParentId = undefined;
      } else if (typeof parentIdOrActor === 'string') {
        requestedParentId = parentIdOrActor;
        actualActor = actorArg;
      }

      // 2. Reject unauthenticated calls
      if (!actualActor || !actualActor.userId || !actualActor.role) {
        throw new Error('Unauthorized: Authentication required to retrieve linked student records.');
      }

      // 3. Determine permitted target parent ID based on caller's authenticated identity & role
      let targetParentId: string;

      const isAdmin =
        actualActor.role === AuthRole.SUPER_ADMIN ||
        actualActor.role === AuthRole.OFFICE_ADMIN ||
        actualActor.userId === 'admin' ||
        ['admin', 'academicoffice', 'admissionsoffice', 'hosteloffice', 'finance', 'coeoffice'].includes(actualActor.userId);

      if (isAdmin) {
        // Authorized administrators may query a specific parent's links, or all active links if not specified
        if (requestedParentId) {
          targetParentId = requestedParentId;
        } else {
          const activeLinks = this.state.parentStudentLinks.filter((l) => l.status === 'ACTIVE');
          const results: { link: ParentStudentLinkRecord; student: StudentRecord }[] = [];
          for (const link of activeLinks) {
            const student = this.state.students.find((s) => s.student_id === link.student_id);
            if (student) {
              results.push({ link, student });
            }
          }
          return results;
        }
      } else if (actualActor.role === AuthRole.PARENT || actualActor.role === 'PARENT') {
        // Authenticated Parent: resolve parent profile from trusted session
        const parentRecord = this.state.parents.find(
          (p) =>
            p.parent_id === actualActor!.userId ||
            p.email.toLowerCase() === actualActor!.userId.toLowerCase() ||
            (actualActor!.employeeId && p.parent_id === actualActor!.employeeId)
        );

        const authenticatedParentId = parentRecord ? parentRecord.parent_id : actualActor.userId;

        // Verify parent account status is ACTIVE if record exists
        if (parentRecord && parentRecord.status !== 'ACTIVE') {
          throw new Error('Access Denied: Parent account is inactive or disabled.');
        }

        // Cross-parent query check: caller cannot query another parent's wards
        if (requestedParentId && requestedParentId !== authenticatedParentId) {
          throw new Error(
            `Access Denied: Cross-parent queries prohibited. Authenticated parent '${authenticatedParentId}' cannot access records for parent '${requestedParentId}'.`
          );
        }

        targetParentId = authenticatedParentId;
      } else {
        // Non-parent and non-admin roles (e.g. STUDENT, FACULTY, APPLICANT) are strictly rejected
        throw new Error(
          `Access Denied: Role '${actualActor.role}' is not authorized to access parent-child linkages.`
        );
      }

      // 4. Return ONLY active links belonging to the permitted parent (revoked links excluded)
      const links = this.state.parentStudentLinks.filter(
        (l) => l.parent_id === targetParentId && l.status === 'ACTIVE'
      );
      const results: { link: ParentStudentLinkRecord; student: StudentRecord }[] = [];
      for (const link of links) {
        const student = this.state.students.find((s) => s.student_id === link.student_id);
        if (student) {
          results.push({ link, student });
        }
      }
      return results;
    },
    linkStudent: async (data: Omit<ParentStudentLinkRecord, 'link_id' | 'created_at' | 'updated_at'>): Promise<ParentStudentLinkRecord> => {
      const newId = `PSL-2026-${String(this.state.parentStudentLinks.length + 1).padStart(3, '0')}`;
      const record: ParentStudentLinkRecord = {
        ...data,
        link_id: newId,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const nextState = {
        ...this.state,
        parentStudentLinks: [...this.state.parentStudentLinks, record],
      };
      this.saveState(nextState);
      return record;
    },
  };

  // ---------------------------------------------------------------------------
  // ACADEMIC OFFICE & STRUCTURE MANAGEMENT (Phase 7)
  // ---------------------------------------------------------------------------
  public academic = {
    getAcademicYears: async (): Promise<AcademicYearRecord[]> => {
      return [...this.state.academicYears];
    },
    getSemesters: async (): Promise<SemesterRecord[]> => {
      return [...this.state.semesters];
    },
    getDepartments: async (): Promise<DepartmentRecord[]> => {
      return [...this.state.departments];
    },
    getProgrammes: async (): Promise<ProgrammeRecord[]> => {
      return [...this.state.programmes];
    },
    getCourses: async (): Promise<CourseRecord[]> => {
      return [...this.state.courses];
    },
    getSections: async (): Promise<ClassSectionRecord[]> => {
      return [...this.state.sections];
    },
    getCourseOfferings: async (): Promise<CourseOfferingRecord[]> => {
      return [...this.state.courseOfferings];
    },

    createCourse: async (
      data: Omit<CourseRecord, 'course_id'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!data.course_code?.trim()) {
        throw new Error('Course code is required.');
      }
      if (!data.course_title?.trim() || data.course_title.trim().length < 3) {
        throw new Error('Course title is required (minimum 3 characters).');
      }
      if (typeof data.credits !== 'number' || data.credits < 1 || data.credits > 6) {
        throw new Error('Course credits must be a valid number between 1 and 6.');
      }
      if (typeof data.semester !== 'number' || data.semester < 1 || data.semester > 8) {
        throw new Error('Semester must be between 1 and 8.');
      }
      if (!data.department?.trim()) {
        throw new Error('Department association is required.');
      }

      const normalizedCode = data.course_code.trim().toUpperCase();
      if (this.state.courses.some((c) => c.course_code.toUpperCase() === normalizedCode)) {
        throw new Error(`Course with code '${normalizedCode}' already exists in curriculum.`);
      }

      const newId = `CRS-${normalizedCode}`;
      const record: CourseRecord = {
        ...data,
        course_id: newId,
        course_code: normalizedCode,
        course_title: data.course_title.trim(),
        status: data.status || 'ACTIVE',
      };

      const nextState = {
        ...this.state,
        courses: [...this.state.courses, record],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'Courses',
        target_record_id: newId,
        description: `Course ${normalizedCode} (${record.course_title}) created under ${record.department}.`,
      });

      return record;
    },

    createSection: async (
      data: Omit<ClassSectionRecord, 'section_id'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ClassSectionRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!data.section_name?.trim()) {
        throw new Error('Section name is required.');
      }
      if (typeof data.max_capacity !== 'number' || data.max_capacity < 1) {
        throw new Error('Section maximum capacity must be greater than zero.');
      }

      const normalizedSection = data.section_name.trim().toUpperCase();
      const duplicate = this.state.sections.find(
        (s) =>
          s.section_name.toUpperCase() === normalizedSection &&
          s.department === data.department &&
          s.semester === data.semester &&
          s.academic_year === data.academic_year
      );
      if (duplicate) {
        throw new Error(
          `Section '${normalizedSection}' already exists for ${data.department} Semester ${data.semester} (${data.academic_year}).`
        );
      }

      const newId = `SEC-${data.department}-${data.semester}${normalizedSection}`;
      const record: ClassSectionRecord = {
        ...data,
        section_id: newId,
        section_name: normalizedSection,
        status: data.status || 'ACTIVE',
      };

      const nextState = {
        ...this.state,
        sections: [...this.state.sections, record],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'ClassSections',
        target_record_id: newId,
        description: `Class section ${record.section_name} created for ${data.department} Sem ${data.semester}.`,
      });

      return record;
    },

    createCourseOffering: async (
      data: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      // Validate core offering metadata and curriculum course
      const { course, capacity } = this.validateOfferingCurriculumAndData(data);

      // Duplicate offering check
      const duplicate = this.state.courseOfferings.find(
        (o) =>
          o.course_code === data.course_code &&
          o.section === data.section &&
          o.semester === data.semester &&
          o.academic_year === data.academic_year &&
          o.status !== 'CANCELLED'
      );
      if (duplicate) {
        throw new Error(
          `Course offering for ${data.course_code} (Section ${data.section}) already exists in semester ${data.semester}.`
        );
      }

      // Validate faculty (must be real active teaching faculty in compatible department; required if PUBLISHED)
      const faculty = this.validateFacultyForOffering(
        data.assigned_faculty_id,
        data.department || course.department,
        data.status
      );

      const newId = `OFF-${data.academic_year}-${data.course_code}-${data.section}`;
      const record: CourseOfferingRecord = {
        ...data,
        offering_id: newId,
        course_title: data.course_title || course.course_title,
        department: data.department || course.department,
        programme_code: data.programme_code || course.programme_code,
        assigned_faculty_id: faculty ? faculty.employee_id : undefined,
        assigned_faculty_reg: faculty ? faculty.registration_number : undefined,
        assigned_faculty_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : undefined,
        max_capacity: capacity,
        status: data.status || (faculty ? 'PUBLISHED' : 'DRAFT'),
        created_at: new Date().toISOString(),
      };

      let nextFacultyAssignments = [...this.state.facultyAssignments];
      if (faculty) {
        const newAsgId = `FCA-2026-${String(nextFacultyAssignments.length + 1).padStart(3, '0')}`;
        nextFacultyAssignments.push({
          faculty_assignment_id: newAsgId,
          employee_id: faculty.employee_id,
          employee_registration: faculty.registration_number,
          employee_name: `${faculty.first_name} ${faculty.last_name}`,
          course_code: course.course_code,
          course_title: course.course_title,
          department: data.department || course.department,
          semester: data.semester,
          academic_year: data.academic_year,
          section: data.section,
          role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
          assignment_status: 'ACTIVE',
          assigned_by_office_id: 'PO-003',
          effective_from: new Date().toISOString().split('T')[0],
          created_at: new Date().toISOString(),
        });
      }

      const nextState = {
        ...this.state,
        courseOfferings: [...this.state.courseOfferings, record],
        facultyAssignments: nextFacultyAssignments,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'CourseOfferings',
        target_record_id: newId,
        description: `Course offering ${newId} established for ${data.course_code} (Sec ${data.section}). Status: ${record.status}.`,
      });

      return record;
    },

    createCourseOfferingWithTimetable: async (
      offeringData: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
      timetableData?: {
        day_of_week: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
        start_time: string;
        end_time: string;
        room: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{
      offering: CourseOfferingRecord;
      timetableSlot?: TimetableSlotRecord;
      facultyAssignment?: FacultyCourseAssignmentRecord;
    }> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      // Snapshot for transactional rollback
      const snapshot = JSON.parse(JSON.stringify(this.state));

      try {
        // 1. Validate offering & curriculum course
        const { course, capacity } = this.validateOfferingCurriculumAndData(offeringData);

        // 2. Validate duplicate offering
        const duplicate = this.state.courseOfferings.find(
          (o) =>
            o.course_code === offeringData.course_code &&
            o.section === offeringData.section &&
            o.semester === offeringData.semester &&
            o.academic_year === offeringData.academic_year &&
            o.status !== 'CANCELLED'
        );
        if (duplicate) {
          throw new Error(
            `Course offering for ${offeringData.course_code} (Section ${offeringData.section}) already exists in semester ${offeringData.semester}.`
          );
        }

        // 3. Validate faculty assignment
        const faculty = this.validateFacultyForOffering(
          offeringData.assigned_faculty_id,
          offeringData.department || course.department,
          offeringData.status
        );

        // 4. Validate timetable and detect conflicts
        let timetableSlotRecord: TimetableSlotRecord | undefined;
        if (timetableData && timetableData.room && timetableData.start_time && timetableData.end_time) {
          this.checkOfferingTimetableConflicts({
            academic_year: offeringData.academic_year,
            semester: offeringData.semester,
            day_of_week: timetableData.day_of_week,
            start_time: timetableData.start_time,
            end_time: timetableData.end_time,
            room: timetableData.room,
            course_code: course.course_code,
            section: offeringData.section,
            department: offeringData.department || course.department,
            faculty_id: faculty?.employee_id,
            faculty_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : undefined,
          });

          const slotId = `TTS-2026-${String(this.state.timetableSlots.length + 1).padStart(4, '0')}`;
          timetableSlotRecord = {
            slot_id: slotId,
            academic_year: offeringData.academic_year,
            semester: offeringData.semester,
            department: offeringData.department || course.department,
            day_of_week: timetableData.day_of_week,
            start_time: timetableData.start_time,
            end_time: timetableData.end_time,
            course_code: course.course_code,
            course_title: course.course_title,
            section: offeringData.section,
            faculty_id: faculty ? faculty.employee_id : '',
            faculty_reg_number: faculty ? faculty.registration_number : '',
            faculty_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : '',
            room: timetableData.room,
            room_number: timetableData.room,
            status: 'ACTIVE',
            created_at: new Date().toISOString(),
          };
        }

        // 5. Construct offering record
        const newOfferingId = `OFF-${offeringData.academic_year}-${offeringData.course_code}-${offeringData.section}`;
        const offeringRecord: CourseOfferingRecord = {
          ...offeringData,
          offering_id: newOfferingId,
          course_title: offeringData.course_title || course.course_title,
          department: offeringData.department || course.department,
          programme_code: offeringData.programme_code || course.programme_code,
          assigned_faculty_id: faculty ? faculty.employee_id : undefined,
          assigned_faculty_reg: faculty ? faculty.registration_number : undefined,
          assigned_faculty_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : undefined,
          max_capacity: capacity,
          status: offeringData.status || (faculty ? 'PUBLISHED' : 'DRAFT'),
          created_at: new Date().toISOString(),
        };

        // 6. Synchronize faculty assignment
        let newAssignmentRecord: FacultyCourseAssignmentRecord | undefined;
        let nextFacultyAssignments = [...this.state.facultyAssignments];
        if (faculty) {
          const newAsgId = `FCA-2026-${String(nextFacultyAssignments.length + 1).padStart(3, '0')}`;
          newAssignmentRecord = {
            faculty_assignment_id: newAsgId,
            employee_id: faculty.employee_id,
            employee_registration: faculty.registration_number,
            employee_name: `${faculty.first_name} ${faculty.last_name}`,
            course_code: course.course_code,
            course_title: course.course_title,
            department: offeringData.department || course.department,
            semester: offeringData.semester,
            academic_year: offeringData.academic_year,
            section: offeringData.section,
            role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
            assignment_status: 'ACTIVE',
            assigned_by_office_id: 'PO-003',
            effective_from: new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString(),
          };
          nextFacultyAssignments.push(newAssignmentRecord);
        }

        // 7. Atomic state update
        const nextState = {
          ...this.state,
          courseOfferings: [...this.state.courseOfferings, offeringRecord],
          timetableSlots: timetableSlotRecord ? [...this.state.timetableSlots, timetableSlotRecord] : this.state.timetableSlots,
          facultyAssignments: nextFacultyAssignments,
        };
        this.saveState(nextState);

        await this.audit.log({
          actor_id: actor?.userId || 'academic_office',
          actor_role: actor?.role || 'OFFICE_ADMIN',
          action: AuditAction.CREATE,
          target_worksheet: 'CourseOfferings',
          target_record_id: newOfferingId,
          description: `Atomic offering creation: ${newOfferingId} established with ${
            timetableSlotRecord ? `timetable slot ${timetableSlotRecord.slot_id}` : 'no timetable'
          } (Status: ${offeringRecord.status}).`,
        });

        return {
          offering: offeringRecord,
          timetableSlot: timetableSlotRecord,
          facultyAssignment: newAssignmentRecord,
        };
      } catch (err) {
        // Safe rollback / compensation: restore snapshot cleanly
        this.saveState(snapshot);
        throw err;
      }
    },

    updateCourseOffering: async (
      offeringId: string,
      updates: Partial<CourseOfferingRecord>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      const existingIndex = this.state.courseOfferings.findIndex((o) => o.offering_id === offeringId);
      if (existingIndex === -1) {
        throw new Error(`Course offering with ID '${offeringId}' not found.`);
      }

      const current = this.state.courseOfferings[existingIndex];

      // Enrolment check to prevent destructive updates
      const activeEnrolments = this.state.enrolments.filter(
        (e) => e.offering_id === offeringId && e.enrolment_status === 'ACTIVE'
      );

      if (activeEnrolments.length > 0) {
        if (updates.course_code && updates.course_code !== current.course_code) {
          throw new Error(
            `Cannot change course code for offering '${offeringId}': ${activeEnrolments.length} student(s) are already enrolled.`
          );
        }
        if (updates.semester && updates.semester !== current.semester) {
          throw new Error(
            `Cannot change semester for offering '${offeringId}': ${activeEnrolments.length} student(s) are already enrolled.`
          );
        }
        if (updates.programme_code && updates.programme_code !== current.programme_code) {
          throw new Error(
            `Cannot change programme code for offering '${offeringId}': ${activeEnrolments.length} student(s) are already enrolled.`
          );
        }
        if (updates.max_capacity !== undefined && Number(updates.max_capacity) < activeEnrolments.length) {
          throw new Error(
            `Cannot reduce maximum capacity to ${updates.max_capacity}. Current active enrolments count is ${activeEnrolments.length}.`
          );
        }
      }

      let faculty: EmployeeRecord | null = null;
      if (updates.assigned_faculty_id !== undefined) {
        faculty = this.validateFacultyForOffering(
          updates.assigned_faculty_id,
          updates.department || current.department,
          updates.status || current.status
        );
      }

      if (updates.status === 'PUBLISHED') {
        const targetFacultyId = updates.assigned_faculty_id !== undefined ? updates.assigned_faculty_id : current.assigned_faculty_id;
        if (!targetFacultyId) {
          throw new Error('A valid teaching faculty member is required to publish an offering. Select an instructor or save as DRAFT.');
        }
        const cap = updates.max_capacity !== undefined ? Number(updates.max_capacity) : current.max_capacity;
        if (!cap || cap <= 0) {
          throw new Error('Offering capacity must be a positive integer greater than zero.');
        }
      }

      const updated: CourseOfferingRecord = {
        ...current,
        ...updates,
        offering_id: current.offering_id, // Immutable PK
        course_code: current.course_code, // Maintain course reference
        assigned_faculty_id: updates.assigned_faculty_id !== undefined ? (faculty ? faculty.employee_id : undefined) : current.assigned_faculty_id,
        assigned_faculty_reg: updates.assigned_faculty_id !== undefined ? (faculty ? faculty.registration_number : undefined) : current.assigned_faculty_reg,
        assigned_faculty_name: updates.assigned_faculty_id !== undefined ? (faculty ? `${faculty.first_name} ${faculty.last_name}` : undefined) : current.assigned_faculty_name,
        updated_at: new Date().toISOString(),
      };

      // Synchronize faculty assignments
      let updatedAssignments = [...this.state.facultyAssignments];
      if (updates.assigned_faculty_id !== undefined && updates.assigned_faculty_id !== current.assigned_faculty_id) {
        if (faculty) {
          const existingAsg = updatedAssignments.find(
            (a) =>
              a.course_code === current.course_code &&
              a.section === current.section &&
              a.academic_year === current.academic_year &&
              a.assignment_status === 'ACTIVE'
          );

          if (existingAsg) {
            updatedAssignments = updatedAssignments.map((a) =>
              a.faculty_assignment_id === existingAsg.faculty_assignment_id
                ? {
                    ...a,
                    employee_id: faculty!.employee_id,
                    employee_registration: faculty!.registration_number,
                    employee_name: `${faculty!.first_name} ${faculty!.last_name}`,
                    updated_at: new Date().toISOString(),
                  }
                : a
            );
          } else {
            const newAsgId = `FCA-2026-${String(updatedAssignments.length + 1).padStart(3, '0')}`;
            updatedAssignments.push({
              faculty_assignment_id: newAsgId,
              employee_id: faculty.employee_id,
              employee_registration: faculty.registration_number,
              employee_name: `${faculty.first_name} ${faculty.last_name}`,
              course_code: current.course_code,
              course_title: current.course_title,
              department: current.department,
              semester: current.semester,
              academic_year: current.academic_year,
              section: current.section,
              role_in_course: FacultyCourseRole.PRIMARY_INSTRUCTOR,
              assignment_status: 'ACTIVE',
              assigned_by_office_id: 'PO-003',
              effective_from: new Date().toISOString().split('T')[0],
              created_at: new Date().toISOString(),
            });
          }
        } else {
          // Unassigned
          const today = new Date().toISOString().split('T')[0];
          updatedAssignments = updatedAssignments.map((a) =>
            a.course_code === current.course_code &&
            a.section === current.section &&
            a.academic_year === current.academic_year &&
            a.assignment_status === 'ACTIVE'
              ? { ...a, assignment_status: 'COMPLETED' as const, effective_to: today }
              : a
          );
        }
      }

      const updatedOfferings = [...this.state.courseOfferings];
      updatedOfferings[existingIndex] = updated;

      const nextState = {
        ...this.state,
        courseOfferings: updatedOfferings,
        facultyAssignments: updatedAssignments,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'CourseOfferings',
        target_record_id: offeringId,
        description: `Course offering ${offeringId} updated. Status: ${updated.status}.`,
      });

      return updated;
    },

    cancelCourseOffering: async (
      offeringId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('A cancellation reason is required.');
      }

      const existing = this.state.courseOfferings.find((o) => o.offering_id === offeringId);
      if (!existing) {
        throw new Error(`Course offering '${offeringId}' not found.`);
      }

      const updated: CourseOfferingRecord = {
        ...existing,
        status: 'CANCELLED',
        cancellation_reason: reason.trim(),
        updated_at: new Date().toISOString(),
      };

      // Cancel associated timetable slots
      const updatedTimetable = this.state.timetableSlots.map((s) =>
        s.course_code === existing.course_code &&
        s.section === existing.section &&
        s.academic_year === existing.academic_year
          ? { ...s, status: 'CANCELLED' }
          : s
      );

      // Conclude active faculty assignments
      const today = new Date().toISOString().split('T')[0];
      const updatedAssignments = this.state.facultyAssignments.map((a) =>
        a.course_code === existing.course_code &&
        a.section === existing.section &&
        a.academic_year === existing.academic_year &&
        a.assignment_status === 'ACTIVE'
          ? { ...a, assignment_status: 'COMPLETED' as const, effective_to: today }
          : a
      );

      const nextState = {
        ...this.state,
        courseOfferings: this.state.courseOfferings.map((o) => (o.offering_id === offeringId ? updated : o)),
        timetableSlots: updatedTimetable,
        facultyAssignments: updatedAssignments,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'CourseOfferings',
        target_record_id: offeringId,
        description: `Course offering ${offeringId} cancelled. Reason: ${reason}.`,
      });

      return updated;
    },

    publishCourseOffering: async (
      offeringId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      const existing = this.state.courseOfferings.find((o) => o.offering_id === offeringId);
      if (!existing) {
        throw new Error(`Course offering '${offeringId}' not found.`);
      }

      if (!existing.assigned_faculty_id) {
        throw new Error(
          `Cannot publish course offering '${offeringId}': A valid teaching faculty member must be assigned before publishing.`
        );
      }

      const faculty = this.validateFacultyForOffering(
        existing.assigned_faculty_id,
        existing.department,
        'PUBLISHED'
      );

      const cap = Number(existing.max_capacity);
      if (!cap || cap <= 0) {
        throw new Error(`Cannot publish course offering '${offeringId}': Maximum capacity must be greater than zero.`);
      }

      const updated: CourseOfferingRecord = {
        ...existing,
        status: 'PUBLISHED',
        assigned_faculty_name: faculty ? `${faculty.first_name} ${faculty.last_name}` : existing.assigned_faculty_name,
        assigned_faculty_reg: faculty ? faculty.registration_number : existing.assigned_faculty_reg,
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        courseOfferings: this.state.courseOfferings.map((o) => (o.offering_id === offeringId ? updated : o)),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'CourseOfferings',
        target_record_id: offeringId,
        description: `Course offering ${offeringId} published to students.`,
      });

      return updated;
    },

    closeCourseOffering: async (
      offeringId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      const existing = this.state.courseOfferings.find((o) => o.offering_id === offeringId);
      if (!existing) {
        throw new Error(`Course offering '${offeringId}' not found.`);
      }

      const updated: CourseOfferingRecord = {
        ...existing,
        status: 'CLOSED',
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        courseOfferings: this.state.courseOfferings.map((o) => (o.offering_id === offeringId ? updated : o)),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'CourseOfferings',
        target_record_id: offeringId,
        description: `Course offering ${offeringId} closed for enrolment.`,
      });

      return updated;
    },

    assignFaculty: async (
      data: {
        offering_id?: string;
        course_code?: string;
        course_title?: string;
        department?: string;
        semester?: number;
        academic_year?: string;
        section?: string;
        employee_id: string;
        role_in_course: FacultyCourseRole;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord> => {
      let courseCode = data.course_code;
      let courseTitle = data.course_title;
      let department = data.department;
      let semester = data.semester;
      let academicYear = data.academic_year;
      let section = data.section;

      if (data.offering_id) {
        const off = this.state.courseOfferings.find((o) => o.offering_id === data.offering_id);
        if (off) {
          courseCode = courseCode || off.course_code;
          courseTitle = courseTitle || off.course_title;
          department = department || off.department;
          semester = semester || off.semester;
          academicYear = academicYear || off.academic_year;
          section = section || off.section;
        }
      }

      if (!courseCode || !department || !semester || !academicYear || !section) {
        throw new Error('Course code, department, semester, academic year, and section are required.');
      }

      const course = this.state.courses.find((c) => c.course_code === courseCode);
      return this.facultyAssignments.assign(
        {
          employee_id: data.employee_id,
          course_code: courseCode,
          course_title: courseTitle || course?.course_title || courseCode,
          department: department,
          semester: semester,
          academic_year: academicYear,
          section: section,
          role_in_course: data.role_in_course,
          assignment_status: 'ACTIVE',
          assigned_by_office_id: 'PO-003',
          effective_from: new Date().toISOString().split('T')[0],
        },
        actor
      );
    },

    endFacultyAssignment: async (
      assignmentId: string,
      reason?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('Reason is required to end faculty assignment.');
      }

      const assignment = this.state.facultyAssignments.find((f) => f.faculty_assignment_id === assignmentId);
      if (!assignment) {
        throw new Error(`Faculty assignment '${assignmentId}' not found.`);
      }

      const updatedAssignment: FacultyCourseAssignmentRecord = {
        ...assignment,
        assignment_status: 'COMPLETED',
        effective_to: new Date().toISOString().split('T')[0],
      };

      // Unassign in matching course offering
      const updatedOfferings = this.state.courseOfferings.map((off) => {
        if (
          off.course_code === assignment.course_code &&
          off.section === assignment.section &&
          off.assigned_faculty_id === assignment.employee_id
        ) {
          return {
            ...off,
            assigned_faculty_id: undefined,
            assigned_faculty_reg: undefined,
            assigned_faculty_name: undefined,
          };
        }
        return off;
      });

      const nextState = {
        ...this.state,
        facultyAssignments: this.state.facultyAssignments.map((f) =>
          f.faculty_assignment_id === assignmentId ? updatedAssignment : f
        ),
        courseOfferings: updatedOfferings,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'FacultyCourseAssignments',
        target_record_id: assignmentId,
        description: `Faculty assignment ${assignmentId} concluded. Reason: ${reason}.`,
      });

      return updatedAssignment;
    },

    getEnrolments: async (
      filters?: {
        student_id?: string;
        course_code?: string;
        section?: string;
        semester?: number;
        academic_year?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord[]> => {
      let activeFilters = filters ? { ...filters } : undefined;

      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          const student = this.state.students.find(
            (s) => s.student_id === actor.userId || s.registration_number === actor.userId
          );
          if (activeFilters?.student_id) {
            const isSelf =
              activeFilters.student_id === actor.userId ||
              (student &&
                (activeFilters.student_id === student.student_id ||
                  activeFilters.student_id === student.registration_number));
            if (!isSelf) {
              throw new Error('Unauthorized: Students cannot view course enrolments of other students.');
            }
          } else if (student) {
            activeFilters = { ...activeFilters, student_id: student.student_id };
          }
        } else if (actor.role === AuthRole.PARENT) {
          if (activeFilters?.student_id) {
            const student = this.state.students.find(
              (s) => s.student_id === activeFilters?.student_id || s.registration_number === activeFilters?.student_id
            );
            const link = this.state.parentStudentLinks.find(
              (l) =>
                (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
                (l.student_id === activeFilters?.student_id ||
                  l.student_registration_number === activeFilters?.student_id ||
                  (student && (l.student_id === student.student_id || l.student_registration_number === student.registration_number))) &&
                l.status === 'ACTIVE'
            );
            if (!link) {
              throw new Error('Access Denied: No active relationship link found for this student.');
            }
            if (!link.can_view_grades) {
              throw new Error('Access Denied: Parent does not have permission to view coursework for this student (can_view_grades is false).');
            }
          }
        }
      }

      let list = [...this.state.enrolments];
      if (activeFilters?.student_id) {
        list = list.filter(
          (e) =>
            e.student_id === activeFilters!.student_id ||
            e.student_registration_number === activeFilters!.student_id
        );
      }
      if (activeFilters?.course_code) {
        list = list.filter((e) => e.course_code === activeFilters!.course_code);
      }
      if (activeFilters?.section) {
        list = list.filter((e) => e.section === activeFilters!.section);
      }
      if (activeFilters?.semester) {
        list = list.filter((e) => e.semester === activeFilters!.semester);
      }
      if (activeFilters?.academic_year) {
        list = list.filter((e) => e.academic_year === activeFilters!.academic_year);
      }
      return list;
    },

    enrolStudent: async (
      data: {
        student_id: string;
        offering_id?: string;
        course_code?: string;
        section?: string;
        semester?: number;
        academic_year?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      let courseCode = data.course_code;
      let section = data.section;
      let semester = data.semester;
      let academicYear = data.academic_year;
      let offeringId = data.offering_id;

      let offering = offeringId ? this.state.courseOfferings.find((o) => o.offering_id === offeringId) : undefined;
      if (offering) {
        courseCode = courseCode || offering.course_code;
        section = section || offering.section;
        semester = semester || offering.semester;
        academicYear = academicYear || offering.academic_year;
      }

      if (!courseCode) {
        throw new Error('Course code is required for enrolment.');
      }

      const student = this.state.students.find(
        (s) => s.student_id === data.student_id || s.registration_number === data.student_id
      );
      if (!student) {
        throw new Error(`Student with ID '${data.student_id}' does not exist.`);
      }
      if (student.enrollment_status !== StudentStatus.ENROLLED) {
        throw new Error(`Cannot enrol student '${student.registration_number}': Enrollment status is ${student.enrollment_status}.`);
      }

      const course = this.state.courses.find((c) => c.course_code === courseCode);
      if (!course) {
        throw new Error(`Course with code '${courseCode}' does not exist.`);
      }

      section = section || 'A';
      semester = semester || course.semester;
      academicYear = academicYear || '2026-2027';

      if (!offering) {
        offering = this.state.courseOfferings.find(
          (o) =>
            o.course_code === courseCode &&
            o.section === section &&
            o.semester === semester &&
            o.academic_year === academicYear
        );
      }

      if (!offering) {
        throw new Error(`Course offering for ${courseCode} (Section ${section}, Sem ${semester}) not found.`);
      }

      // Check offering status: DRAFT, CLOSED, and CANCELLED offerings must NOT accept enrolments
      if (offering.status === 'DRAFT') {
        throw new Error(`Cannot enrol student: Course offering '${offering.offering_id}' is currently in DRAFT status and not open for enrolment.`);
      }
      if (offering.status === 'CLOSED') {
        throw new Error(`Cannot enrol student: Course offering '${offering.offering_id}' is CLOSED for enrolment.`);
      }
      if (offering.status === 'CANCELLED') {
        throw new Error(`Cannot enrol student: Course offering '${offering.offering_id}' has been CANCELLED.`);
      }

      // Duplicate active enrolment check
      const duplicate = this.state.enrolments.find(
        (e) =>
          e.student_id === student.student_id &&
          e.course_code === courseCode &&
          e.enrolment_status === 'ACTIVE'
      );
      if (duplicate) {
        throw new Error(
          `Duplicate Enrolment: Student '${student.registration_number}' is already enrolled in course '${courseCode}'.`
        );
      }

      // Capacity enforcement
      const currentActiveCount = this.state.enrolments.filter(
        (e) => e.offering_id === offering!.offering_id && e.enrolment_status === 'ACTIVE'
      ).length;
      const maxCap = offering.max_capacity || 60;
      if (currentActiveCount >= maxCap) {
        throw new Error(
          `Offering Capacity Reached: Cannot enrol student. Max capacity of ${maxCap} seats has been met.`
        );
      }

      // Student Programme compatibility check
      if (student.program_name && offering.programme_code) {
        const progLower = student.program_name.toLowerCase();
        const offProgLower = offering.programme_code.toLowerCase();
        if (offProgLower.includes('cse') && !progLower.includes('cse') && !progLower.includes('computer')) {
          throw new Error(
            `Ineligible Student: Student enrolled in '${student.program_name}' is not eligible for programme '${offering.programme_code}'.`
          );
        }
      }

      const newId = `ENR-2026-${String(this.state.enrolments.length + 1).padStart(4, '0')}`;
      const record: CourseEnrolmentRecord = {
        enrolment_id: newId,
        student_id: student.student_id,
        student_registration_number: student.registration_number,
        student_name: `${student.first_name} ${student.last_name}`,
        course_code: course.course_code,
        course_title: course.course_title,
        offering_id: offering.offering_id,
        department: course.department,
        semester: semester,
        academic_year: academicYear,
        section: section,
        enrolment_status: 'ACTIVE',
        enrolled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        enrolments: [...this.state.enrolments, record],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.ENROLMENT,
        target_worksheet: 'CourseEnrolments',
        target_record_id: newId,
        description: `Student ${student.registration_number} enrolled in ${course.course_code} (${section}).`,
      });

      return record;
    },

    transferStudentSection: async (
      enrolmentId: string,
      newSection: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('Transfer reason is required.');
      }

      const enr = this.state.enrolments.find((e) => e.enrolment_id === enrolmentId);
      if (!enr || enr.enrolment_status !== 'ACTIVE') {
        throw new Error(`Active enrolment record '${enrolmentId}' not found.`);
      }

      const normalizedNewSection = newSection.trim().toUpperCase();
      if (enr.section.toUpperCase() === normalizedNewSection) {
        throw new Error(`Student is already enrolled in Section ${normalizedNewSection}.`);
      }

      // Mark old enrolment as TRANSFERRED
      const oldUpdated: CourseEnrolmentRecord = {
        ...enr,
        enrolment_status: 'TRANSFERRED',
        transferred_to_section: normalizedNewSection,
        transfer_reason: reason.trim(),
        transferred_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Create new active enrolment record in target section
      const newId = `ENR-2026-${String(this.state.enrolments.length + 1).padStart(4, '0')}`;
      const newEnrolment: CourseEnrolmentRecord = {
        ...enr,
        enrolment_id: newId,
        section: normalizedNewSection,
        offering_id: `OFF-${enr.academic_year}-${enr.course_code}-${normalizedNewSection}`,
        enrolment_status: 'ACTIVE',
        enrolled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextEnrolments = this.state.enrolments.map((e) =>
        e.enrolment_id === enrolmentId ? oldUpdated : e
      );
      nextEnrolments.push(newEnrolment);

      const nextState = {
        ...this.state,
        enrolments: nextEnrolments,
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.ENROLMENT_TRANSFER,
        target_worksheet: 'CourseEnrolments',
        target_record_id: newId,
        description: `Student ${enr.student_registration_number} transferred from Sec ${enr.section} to Sec ${normalizedNewSection} in ${enr.course_code}. Reason: ${reason}.`,
      });

      return newEnrolment;
    },

    withdrawStudent: async (
      enrolmentId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('Withdrawal reason is required.');
      }

      const enr = this.state.enrolments.find((e) => e.enrolment_id === enrolmentId);
      if (!enr || enr.enrolment_status !== 'ACTIVE') {
        throw new Error(`Active enrolment record '${enrolmentId}' not found.`);
      }

      const updated: CourseEnrolmentRecord = {
        ...enr,
        enrolment_status: 'WITHDRAWN',
        withdrawal_reason: reason.trim(),
        withdrawn_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        enrolments: this.state.enrolments.map((e) =>
          e.enrolment_id === enrolmentId ? updated : e
        ),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.ENROLMENT_WITHDRAW,
        target_worksheet: 'CourseEnrolments',
        target_record_id: enrolmentId,
        description: `Student ${enr.student_registration_number} withdrawn from ${enr.course_code} (Sec ${enr.section}). Reason: ${reason}.`,
      });

      return updated;
    },

    getFacultyAssignedCourses: async (employeeId: string): Promise<FacultyCourseAssignmentRecord[]> => {
      return this.state.facultyAssignments.filter(
        (f) => f.employee_id === employeeId && f.assignment_status === 'ACTIVE'
      );
    },

    getFacultyProctorAssignments: async (
      employeeId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<any[]> => {
      return proctorRepository.getActiveAssignmentsForFaculty(employeeId, actor);
    },

    getClassRoster: async (
      courseCode: string,
      section: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ enrolment: CourseEnrolmentRecord; student: StudentRecord }[]> => {
      // If actor is faculty, enforce that the faculty member is assigned to this course and section
      if (actor && (actor.role === AuthRole.FACULTY || actor.employeeId)) {
        const empId =
          actor.employeeId ||
          this.state.employees.find((e) => e.registration_number === actor.userId)?.employee_id;
        if (empId) {
          const isAssigned = this.state.facultyAssignments.some(
            (f) =>
              f.employee_id === empId &&
              f.course_code === courseCode &&
              f.section === section &&
              f.assignment_status === 'ACTIVE'
          );
          if (!isAssigned) {
            throw new Error(
              `Unauthorized: Faculty member '${actor.userId}' is not assigned to course '${courseCode}' (Section ${section}).`
            );
          }
        }
      }

      const activeEnrolments = this.state.enrolments.filter(
        (e) =>
          e.course_code === courseCode &&
          e.section === section &&
          e.enrolment_status === 'ACTIVE'
      );

      const roster: { enrolment: CourseEnrolmentRecord; student: StudentRecord }[] = [];
      for (const enr of activeEnrolments) {
        const student = this.state.students.find((s) => s.student_id === enr.student_id);
        if (student) {
          roster.push({ enrolment: enr, student });
        }
      }
      return roster;
    },

    getTimetable: async (filters?: {
      department?: string;
      semester?: number;
      section?: string;
      faculty_id?: string;
    }): Promise<TimetableSlotRecord[]> => {
      let list = [...this.state.timetableSlots].filter((s) => s.status === 'ACTIVE');
      if (filters?.department) {
        list = list.filter((s) => s.department === filters.department);
      }
      if (filters?.semester) {
        list = list.filter((s) => s.semester === filters.semester);
      }
      if (filters?.section) {
        list = list.filter((s) => s.section === filters.section);
      }
      if (filters?.faculty_id) {
        list = list.filter((s) => s.faculty_id === filters.faculty_id);
      }
      return list;
    },

    scheduleTimetableSlot: async (
      data: Omit<TimetableSlotRecord, 'slot_id' | 'created_at' | 'status'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<TimetableSlotRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      if (!data.start_time || !data.end_time) {
        throw new Error('Start time and end time are required.');
      }
      if (data.start_time >= data.end_time) {
        throw new Error(
          `Invalid timetable slot: start_time ('${data.start_time}') must be earlier than end_time ('${data.end_time}').`
        );
      }

      const faculty = this.state.employees.find((e) => e.employee_id === data.faculty_id);
      if (!faculty || faculty.category !== EmployeeCategory.TEACHING) {
        throw new Error('Scheduled faculty must be an active teaching employee.');
      }

      // Conflict detection: Room, Faculty, and Section
      const candidateSlots = this.state.timetableSlots.filter(
        (s) =>
          s.status === 'ACTIVE' &&
          s.academic_year === data.academic_year &&
          s.semester === data.semester &&
          s.day_of_week === data.day_of_week
      );

      for (const existing of candidateSlots) {
        const overlaps = data.start_time < existing.end_time && existing.start_time < data.end_time;
        if (overlaps) {
          // 1. Room conflict
          if (existing.room.trim().toLowerCase() === data.room.trim().toLowerCase()) {
            throw new Error(
              `Timetable Conflict (Room): Room '${data.room}' is already booked on ${data.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code} (Section ${existing.section}).`
            );
          }

          // 2. Faculty double-booking conflict
          if (existing.faculty_id === data.faculty_id) {
            throw new Error(
              `Timetable Conflict (Faculty): Faculty '${data.faculty_name || faculty.first_name + ' ' + faculty.last_name}' is already scheduled on ${data.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code} (Section ${existing.section}).`
            );
          }

          // 3. Section conflict
          if (
            (existing.course_code === data.course_code || existing.department === data.department) &&
            existing.section === data.section
          ) {
            throw new Error(
              `Timetable Conflict (Section): Section '${data.section}' is already scheduled on ${data.day_of_week} from ${existing.start_time} to ${existing.end_time} for ${existing.course_code}.`
            );
          }
        }
      }

      const newId = `TTS-2026-${String(this.state.timetableSlots.length + 1).padStart(4, '0')}`;
      const record: TimetableSlotRecord = {
        ...data,
        slot_id: newId,
        faculty_name: data.faculty_name || `${faculty.first_name} ${faculty.last_name}`,
        faculty_reg_number: data.faculty_reg_number || faculty.registration_number,
        status: 'ACTIVE',
        created_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        timetableSlots: [...this.state.timetableSlots, record],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.TIMETABLE_SCHEDULE,
        target_worksheet: 'TimetableSlots',
        target_record_id: newId,
        description: `Timetable slot ${newId} scheduled: ${data.course_code} Sec ${data.section} on ${data.day_of_week} ${data.start_time}-${data.end_time} in ${data.room}.`,
      });

      return record;
    },

    previewBulkEnrolment: async (
      request: BulkEnrolmentRequest
    ): Promise<BulkEnrolmentPreReview> => {
      const { semester, programme_code, section, offering_ids, student_ids, mode } = request;

      // 1. Resolve offerings matching request cohort
      const targetOfferings = this.state.courseOfferings.filter((o) => {
        const matchId = offering_ids.includes(o.offering_id);
        const isPublished = o.status === 'PUBLISHED';
        const matchSem = !semester || o.semester === Number(semester);
        const matchAy = !request.academic_year || o.academic_year === request.academic_year;
        const progDept = (programme_code || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
        const matchProg = !programme_code || o.programme_code === programme_code || (o.department && o.department.toUpperCase() === progDept);
        return matchId && isPublished && matchSem && matchAy && matchProg;
      });

      // Track capacity and available seats per offering
      const courseReviewList = targetOfferings.map((offering) => {
        const currentActiveCount = this.state.enrolments.filter(
          (e) => e.offering_id === offering.offering_id && e.enrolment_status === 'ACTIVE'
        ).length;
        const maxCap = offering.max_capacity || 60;
        return {
          offering_id: offering.offering_id,
          course_code: offering.course_code,
          course_title: offering.course_title,
          current_enrolments: currentActiveCount,
          max_capacity: maxCap,
          available_seats: Math.max(0, maxCap - currentActiveCount),
        };
      });

      // 2. Resolve authoritative candidate students
      let candidateStudents = this.state.students.filter(
        (s) => s.enrollment_status === StudentStatus.ENROLLED
      );

      if (mode === 'selected_students' && student_ids?.length) {
        candidateStudents = candidateStudents.filter((s) =>
          student_ids.includes(s.student_id) || student_ids.includes(s.registration_number)
        );
      } else {
        const progDept = (programme_code || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
        candidateStudents = candidateStudents.filter((s) => {
          const sDeptUpper = (s.department || '').toUpperCase();
          const sProgUpper = (s.program_name || '').toUpperCase();
          const progMatch = !programme_code ||
            sDeptUpper === progDept ||
            sProgUpper === programme_code.toUpperCase() ||
            sProgUpper.includes(progDept);
          const semMatch = !semester || s.current_semester === Number(semester);
          const secMatch = !section || section === 'ALL' || !s.section || s.section.toUpperCase() === section.toUpperCase();
          const batchMatch = !request.batch || String(s.admission_year) === String(request.batch);
          return progMatch && semMatch && secMatch && batchMatch;
        });
      }

      // Simulated capacity tracker per offering
      const remainingSeatsMap = new Map<string, number>();
      courseReviewList.forEach((c) => {
        remainingSeatsMap.set(c.offering_id, c.available_seats);
      });

      let eligibleCount = 0;
      let alreadyEnrolledCount = 0;
      let ineligibleProgCount = 0;
      let capacityLimitedCount = 0;
      let duplicateInRequestCount = 0;

      const breakdown: BulkEnrolmentPreReview['breakdown'] = [];
      const evaluatedPairs = new Set<string>();

      for (const student of candidateStudents) {
        for (const offering of targetOfferings) {
          const pairKey = `${student.student_id}:${offering.course_code}`;

          if (evaluatedPairs.has(pairKey)) {
            duplicateInRequestCount++;
            breakdown.push({
              student_id: student.student_id,
              registration_number: student.registration_number,
              student_name: `${student.first_name} ${student.last_name}`,
              offering_id: offering.offering_id,
              course_code: offering.course_code,
              status: 'DUPLICATE_IN_REQUEST',
              reason: 'Student evaluated multiple times for this course in the same request.',
            });
            continue;
          }
          evaluatedPairs.add(pairKey);

          // Duplicate enrolment check
          const existingEnrolment = this.state.enrolments.find(
            (e) =>
              e.student_id === student.student_id &&
              e.course_code === offering.course_code &&
              e.enrolment_status === 'ACTIVE'
          );
          if (existingEnrolment) {
            alreadyEnrolledCount++;
            breakdown.push({
              student_id: student.student_id,
              registration_number: student.registration_number,
              student_name: `${student.first_name} ${student.last_name}`,
              offering_id: offering.offering_id,
              course_code: offering.course_code,
              status: 'ALREADY_ENROLLED',
              reason: `Already actively enrolled in ${offering.course_code} (Section ${existingEnrolment.section || 'A'}).`,
            });
            continue;
          }

          // Exact Programme compatibility check
          const stuDept = (student.department || '').toUpperCase();
          const offDept = (offering.department || '').toUpperCase();
          const offProg = (offering.programme_code || '').toUpperCase();
          if (stuDept && offDept && stuDept !== offDept && !offProg.includes(stuDept)) {
            ineligibleProgCount++;
            breakdown.push({
              student_id: student.student_id,
              registration_number: student.registration_number,
              student_name: `${student.first_name} ${student.last_name}`,
              offering_id: offering.offering_id,
              course_code: offering.course_code,
              status: 'INELIGIBLE_PROGRAMME',
              reason: `Student department '${student.department}' is incompatible with offering department '${offering.department}'.`,
            });
            continue;
          }

          // Capacity check
          const currentAvail = remainingSeatsMap.get(offering.offering_id) ?? 0;
          if (currentAvail <= 0) {
            capacityLimitedCount++;
            breakdown.push({
              student_id: student.student_id,
              registration_number: student.registration_number,
              student_name: `${student.first_name} ${student.last_name}`,
              offering_id: offering.offering_id,
              course_code: offering.course_code,
              status: 'CAPACITY_EXCEEDED',
              reason: `Offering capacity (${offering.max_capacity || 60} seats) reached.`,
            });
            continue;
          }

          remainingSeatsMap.set(offering.offering_id, currentAvail - 1);
          eligibleCount++;
          breakdown.push({
            student_id: student.student_id,
            registration_number: student.registration_number,
            student_name: `${student.first_name} ${student.last_name}`,
            offering_id: offering.offering_id,
            course_code: offering.course_code,
            status: 'ELIGIBLE',
          });
        }
      }

      return {
        total_selected_students: candidateStudents.length,
        total_students: candidateStudents.length,
        eligible_students_count: eligibleCount,
        eligible_students: eligibleCount,
        students_already_enrolled_count: alreadyEnrolledCount,
        already_enrolled: alreadyEnrolledCount,
        ineligible_students_count: ineligibleProgCount,
        ineligible_students: ineligibleProgCount,
        duplicate_enrolments_count: duplicateInRequestCount,
        duplicate_enrolments: duplicateInRequestCount,
        capacity_limited_count: capacityLimitedCount,
        capacity_limited: capacityLimitedCount,
        courses_selected: courseReviewList,
        expected_successful: eligibleCount,
        expected_rejected: alreadyEnrolledCount + ineligibleProgCount + capacityLimitedCount + duplicateInRequestCount,
        breakdown,
        details: breakdown,
      };
    },

    bulkEnrolStudents: async (
      request: BulkEnrolmentRequest,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<BulkEnrolmentResult> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      const preview = await this.academic.previewBulkEnrolment(request);
      const batchId = `BULK-${Date.now()}`;
      const result: BulkEnrolmentResult = {
        total_attempted: preview.breakdown.length,
        batch_id: batchId,
        successful_count: 0,
        skipped_count: 0,
        failed_count: 0,
        successful: [],
        skipped: [],
        failed: [],
        results: [],
      };

      for (const item of preview.breakdown) {
        if (item.status !== 'ELIGIBLE') {
          result.skipped.push({
            student_id: item.student_id,
            registration_number: item.registration_number,
            student_name: item.student_name,
            offering_id: item.offering_id,
            course_code: item.course_code,
            reason: item.reason || `Skipped due to status: ${item.status}`,
          });
          continue;
        }

        // Live commit re-validation
        const offering = this.state.courseOfferings.find((o) => o.offering_id === item.offering_id);
        if (!offering || offering.status !== 'PUBLISHED') {
          result.failed.push({
            student_id: item.student_id,
            registration_number: item.registration_number,
            student_name: item.student_name,
            offering_id: item.offering_id,
            course_code: item.course_code,
            reason: 'Course offering is no longer published or available.',
          });
          continue;
        }

        const currentActive = this.state.enrolments.filter(
          (e) => e.offering_id === item.offering_id && e.enrolment_status === 'ACTIVE'
        ).length;
        if (currentActive >= (offering.max_capacity || 60)) {
          result.failed.push({
            student_id: item.student_id,
            registration_number: item.registration_number,
            student_name: item.student_name,
            offering_id: item.offering_id,
            course_code: item.course_code,
            reason: `Offering capacity (${offering.max_capacity || 60} seats) has been filled.`,
          });
          continue;
        }

        try {
          const enr = await this.academic.enrolStudent(
            {
              student_id: item.student_id,
              offering_id: item.offering_id,
            },
            actor
          );
          result.successful.push({
            enrolment_id: enr.enrolment_id,
            student_id: item.student_id,
            registration_number: item.registration_number,
            student_name: item.student_name,
            offering_id: item.offering_id,
            course_code: item.course_code,
          });
        } catch (err: any) {
          result.failed.push({
            student_id: item.student_id,
            registration_number: item.registration_number,
            student_name: item.student_name,
            offering_id: item.offering_id,
            course_code: item.course_code,
            reason: err.message || 'Enrolment failed',
          });
        }
      }

      result.successful_count = result.successful.length;
      result.skipped_count = result.skipped.length;
      result.failed_count = result.failed.length;
      result.results = [
        ...result.successful.map((s) => ({
          student_name: s.student_name,
          registration_number: s.registration_number,
          course_code: s.course_code,
          status: 'SUCCESS' as const,
          message: `Enrolled successfully (ID: ${s.enrolment_id})`,
        })),
        ...result.skipped.map((s) => ({
          student_name: s.student_name,
          registration_number: s.registration_number,
          course_code: s.course_code,
          status: 'SKIPPED' as const,
          message: s.reason,
        })),
        ...result.failed.map((f) => ({
          student_name: f.student_name,
          registration_number: f.registration_number,
          course_code: f.course_code,
          status: 'FAILED' as const,
          message: f.reason,
        })),
      ];

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.BULK_ENROLMENT,
        target_worksheet: 'CourseEnrolments',
        target_record_id: batchId,
        description: `Bulk enrolment completed: ${result.successful.length} students enrolled, ${result.skipped.length} skipped, ${result.failed.length} failed.`,
      });

      return result;
    },

    validateCsvImport: async (
      csvContent: string,
      fileName: string
    ): Promise<CsvImportPreviewReport> => {
      const SCHEMA_VERSION = 'EIT-FFCS-REG-V1.0';

      // Robust RFC 4180 CSV parser handling quoted cells, commas in quotes, escaped quotes
      const parseCsvText = (text: string): { headers: string[]; rows: Array<Record<string, string>> } => {
        const rawLines: string[] = [];
        let curLine = '';
        let insideQuote = false;

        for (let i = 0; i < text.length; i++) {
          const char = text[i];
          const nextChar = text[i + 1];

          if (char === '"') {
            if (insideQuote && nextChar === '"') {
              curLine += '"';
              i++;
            } else {
              insideQuote = !insideQuote;
              curLine += '"';
            }
          } else if ((char === '\r' || char === '\n') && !insideQuote) {
            if (char === '\r' && nextChar === '\n') {
              i++;
            }
            if (curLine.trim()) {
              rawLines.push(curLine.trim());
            }
            curLine = '';
          } else {
            curLine += char;
          }
        }
        if (curLine.trim()) {
          rawLines.push(curLine.trim());
        }

        const dataLines = rawLines.filter((l) => !l.startsWith('#'));
        if (dataLines.length === 0) {
          return { headers: [], rows: [] };
        }

        const parseLineCells = (line: string): string[] => {
          const cells: string[] = [];
          let cell = '';
          let inQ = false;
          for (let i = 0; i < line.length; i++) {
            const c = line[i];
            const next = line[i + 1];
            if (c === '"') {
              if (inQ && next === '"') {
                cell += '"';
                i++;
              } else {
                inQ = !inQ;
              }
            } else if (c === ',' && !inQ) {
              cells.push(cell.trim());
              cell = '';
            } else {
              cell += c;
            }
          }
          cells.push(cell.trim());
          return cells;
        };

        const headers = parseLineCells(dataLines[0]).map((h) => h.toLowerCase());
        const rows: Array<Record<string, string>> = [];

        for (let r = 1; r < dataLines.length; r++) {
          const cells = parseLineCells(dataLines[r]);
          const obj: Record<string, string> = {};
          headers.forEach((h, idx) => {
            obj[h] = cells[idx] !== undefined ? cells[idx] : '';
          });
          rows.push(obj);
        }

        return { headers, rows };
      };

      const { headers, rows: parsedRowObjects } = parseCsvText(csvContent);

      if (parsedRowObjects.length === 0) {
        return {
          schema_version: SCHEMA_VERSION,
          file_name: fileName,
          total_rows: 0,
          valid_rows_count: 0,
          invalid_rows_count: 0,
          duplicate_rows_count: 0,
          already_enrolled_count: 0,
          capacity_exceeded_count: 0,
          unknown_students_count: 0,
          unknown_courses_count: 0,
          rows: [],
          can_import_count: 0,
          is_valid: false,
        };
      }

      const required = ['registration_number', 'academic_year', 'semester', 'programme_code', 'course_code'];
      const missingHeaders = required.filter((r) => !headers.includes(r));

      if (missingHeaders.length > 0) {
        throw new Error(`Invalid CSV header format: Missing required columns: ${missingHeaders.join(', ')}.`);
      }

      const rows: CsvImportValidationRow[] = [];
      const seenInCsv = new Set<string>();
      const simulatedCapacities = new Map<string, number>();

      for (let i = 0; i < parsedRowObjects.length; i++) {
        const rowObj = parsedRowObjects[i];
        const regNo = (rowObj['registration_number'] || '').trim();
        const courseCode = (rowObj['course_code'] || '').trim();
        const academicYear = (rowObj['academic_year'] || '2026-2027').trim();
        const semesterNum = parseInt(rowObj['semester'], 10) || 3;
        const progCode = (rowObj['programme_code'] || '').trim();
        const sectionCode = (rowObj['section_code'] || rowObj['section'] || '').trim();
        const batchCode = (rowObj['batch'] || '').trim();

        const reasons: string[] = [];
        let status: CsvImportValidationRow['status'] = 'VALID';

        if (!regNo || !courseCode) {
          status = 'INVALID_FORMAT';
          reasons.push('Missing registration_number or course_code');
        }

        // Authoritative student resolution - do NOT trust student names from CSV
        const student = this.state.students.find(
          (s) =>
            s.registration_number.toLowerCase() === regNo.toLowerCase() ||
            s.student_id.toLowerCase() === regNo.toLowerCase()
        );
        if (!student) {
          status = 'UNKNOWN_STUDENT';
          reasons.push(`Student with registration number '${regNo}' does not exist in student directory.`);
        } else if (student.enrollment_status !== StudentStatus.ENROLLED) {
          status = 'INACTIVE_STUDENT' as any;
          reasons.push(`Student with registration number '${regNo}' is not actively enrolled (status: ${student.enrollment_status}).`);
        }

        // Authoritative course resolution
        const course = this.state.courses.find(
          (c) => c.course_code.toLowerCase() === courseCode.toLowerCase()
        );
        if (!course) {
          status = 'UNKNOWN_COURSE';
          reasons.push(`Course with code '${courseCode}' does not exist in approved curriculum.`);
        }

        // Duplicate check within CSV
        const csvPairKey = `${regNo.toUpperCase()}|${courseCode.toUpperCase()}`;
        if (seenInCsv.has(csvPairKey)) {
          status = 'DUPLICATE_IN_CSV';
          reasons.push(`Duplicate row in CSV: Student '${regNo}' registered for course '${courseCode}' multiple times.`);
        }
        seenInCsv.add(csvPairKey);

        // Duplicate active enrolment check
        if (student) {
          const alreadyEnrolled = this.state.enrolments.find(
            (e) =>
              e.student_id === student.student_id &&
              e.course_code.toLowerCase() === courseCode.toLowerCase() &&
              e.enrolment_status === 'ACTIVE'
          );
          if (alreadyEnrolled) {
            status = 'ALREADY_ENROLLED';
            reasons.push(`Student '${regNo}' is already actively enrolled in course '${courseCode}' (Offering: ${alreadyEnrolled.offering_id}).`);
          }
        }

        // Match published course offering
        let matchedOffering = this.state.courseOfferings.find((o) => {
          const matchCode = o.course_code.toLowerCase() === courseCode.toLowerCase();
          const matchYear = o.academic_year === academicYear;
          const matchSem = o.semester === semesterNum;
          const matchSec = !sectionCode || o.section.toLowerCase() === sectionCode.toLowerCase();
          return matchCode && matchYear && matchSem && matchSec && o.status === 'PUBLISHED';
        });

        if (!matchedOffering) {
          matchedOffering = this.state.courseOfferings.find(
            (o) =>
              o.course_code.toLowerCase() === courseCode.toLowerCase() &&
              o.academic_year === academicYear &&
              o.semester === semesterNum &&
              o.status === 'PUBLISHED'
          );
        }

        if (!matchedOffering) {
          if (status === 'VALID') {
            status = 'NO_OFFERING';
            reasons.push(`No active, published course offering found for course '${courseCode}' in ${academicYear} Semester ${semesterNum}.`);
          }
        } else {
          // Programme compatibility
          if (student?.department && matchedOffering.department) {
            const stuDept = student.department.toUpperCase();
            const offDept = matchedOffering.department.toUpperCase();
            if (stuDept !== offDept && !(matchedOffering.programme_code || '').toUpperCase().includes(stuDept)) {
              status = 'INCOMPATIBLE_PROGRAMME';
              reasons.push(`Student department '${student.department}' is not compatible with offering department '${matchedOffering.department}'.`);
            }
          }

          if (!simulatedCapacities.has(matchedOffering.offering_id)) {
            const currentActive = this.state.enrolments.filter(
              (e) => e.offering_id === matchedOffering!.offering_id && e.enrolment_status === 'ACTIVE'
            ).length;
            const maxCap = matchedOffering.max_capacity || 60;
            simulatedCapacities.set(matchedOffering.offering_id, Math.max(0, maxCap - currentActive));
          }

          const avail = simulatedCapacities.get(matchedOffering.offering_id) ?? 0;
          if (avail <= 0 && status === 'VALID') {
            status = 'CAPACITY_EXCEEDED';
            reasons.push(`Course offering '${matchedOffering.offering_id}' has reached maximum capacity (${matchedOffering.max_capacity || 60} seats).`);
          } else if (status === 'VALID') {
            simulatedCapacities.set(matchedOffering.offering_id, avail - 1);
          }
        }

        rows.push({
          row_index: i,
          row_number: i + 1,
          raw: rowObj,
          registration_number: regNo,
          course_code: courseCode,
          student_name: student ? `${student.first_name} ${student.last_name}` : rowObj['student_name'],
          student_id: student?.student_id,
          offering_id: matchedOffering?.offering_id,
          matched_offering_id: matchedOffering?.offering_id,
          academic_year: academicYear,
          semester: semesterNum,
          programme_code: progCode,
          section: sectionCode || matchedOffering?.section,
          batch: batchCode,
          status,
          is_valid: status === 'VALID',
          reasons,
          errors: reasons,
        });
      }

      const validCount = rows.filter((r) => r.status === 'VALID').length;
      const dupCount = rows.filter((r) => r.status === 'DUPLICATE_IN_CSV').length;
      const enrolledCount = rows.filter((r) => r.status === 'ALREADY_ENROLLED').length;
      const capCount = rows.filter((r) => r.status === 'CAPACITY_EXCEEDED').length;

      return {
        schema_version: SCHEMA_VERSION,
        file_name: fileName,
        total_rows: rows.length,
        valid_rows_count: validCount,
        invalid_rows_count: rows.length - validCount,
        duplicate_rows_count: dupCount,
        already_enrolled_count: enrolledCount,
        capacity_exceeded_count: capCount,
        unknown_students_count: rows.filter((r) => r.status === 'UNKNOWN_STUDENT').length,
        unknown_courses_count: rows.filter((r) => r.status === 'UNKNOWN_COURSE').length,
        is_valid: rows.length > 0 && validCount === rows.length,
        rows,
        can_import_count: validCount,
      };
    },

    commitCsvImport: async (
      params: { fileName: string; approvedRows: number[]; csvContent: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CsvImportBatchRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      const preview = await this.academic.validateCsvImport(params.csvContent, params.fileName);
      const batchId = `CSV-BATCH-${Date.now()}`;
      const successfulRows: Array<{
        row_index: number;
        registration_number: string;
        student_name?: string;
        course_code: string;
        enrolment_id: string;
      }> = [];
      const skippedRows: Array<{
        row_index: number;
        registration_number: string;
        course_code: string;
        reason: string;
      }> = [];
      const failedRows: Array<{
        row_index: number;
        registration_number: string;
        course_code: string;
        reason: string;
      }> = [];

      for (const row of preview.rows) {
        if (!params.approvedRows.includes(row.row_index)) {
          skippedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: 'Excluded by user during review.',
          });
          continue;
        }

        if (row.status !== 'VALID' || !row.student_id || !row.offering_id) {
          skippedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: row.reasons.join('; ') || 'Row failed validation.',
          });
          continue;
        }

        // Live revalidation at commit time
        const student = this.state.students.find((s) => s.student_id === row.student_id);
        if (!student || student.enrollment_status !== StudentStatus.ENROLLED) {
          failedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: 'Student is no longer actively enrolled.',
          });
          continue;
        }

        const offering = this.state.courseOfferings.find((o) => o.offering_id === row.offering_id);
        if (!offering || offering.status !== 'PUBLISHED') {
          failedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: 'Offering is no longer published.',
          });
          continue;
        }

        const isDuplicate = this.state.enrolments.some(
          (e) => e.student_id === row.student_id && e.course_code === row.course_code && e.enrolment_status === 'ACTIVE'
        );
        if (isDuplicate) {
          failedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: 'Student is already enrolled in this course.',
          });
          continue;
        }

        const currentActive = this.state.enrolments.filter(
          (e) => e.offering_id === row.offering_id && e.enrolment_status === 'ACTIVE'
        ).length;
        if (currentActive >= (offering.max_capacity || 60)) {
          failedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: `Offering capacity (${offering.max_capacity || 60}) reached.`,
          });
          continue;
        }

        try {
          const enr = await this.academic.enrolStudent(
            {
              student_id: row.student_id,
              offering_id: row.offering_id,
              course_code: row.course_code,
            },
            actor
          );
          successfulRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            student_name: row.student_name,
            course_code: row.course_code,
            enrolment_id: enr.enrolment_id,
          });
        } catch (err: any) {
          failedRows.push({
            row_index: row.row_index,
            registration_number: row.registration_number,
            course_code: row.course_code,
            reason: err.message || 'Enrolment commit failed.',
          });
        }
      }

      const batchRecord: CsvImportBatchRecord = {
        batch_id: batchId,
        file_name: params.fileName,
        schema_version: preview.schema_version,
        academic_year: preview.rows[0]?.academic_year || '2026-2027',
        semester: preview.rows[0]?.semester || 3,
        imported_by_id: actor?.userId || 'academic_office',
        imported_by_name: actor?.userId || 'Academic Office Administrator',
        imported_by: actor?.userId || 'Academic Office Administrator',
        total_rows: preview.total_rows,
        successful_rows: successfulRows.length,
        successful_enrolments: successfulRows.length,
        skipped_rows: skippedRows.length,
        failed_rows: failedRows.length,
        rejected_rows: skippedRows.length + failedRows.length,
        created_at: new Date().toISOString(),
        details: {
          successful: successfulRows,
          skipped: skippedRows,
          failed: failedRows,
        },
      };

      const nextState = {
        ...this.state,
        csvImportBatches: [...(this.state.csvImportBatches || []), batchRecord],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CSV_REGISTRATION_IMPORT,
        target_worksheet: 'CourseEnrolments',
        target_record_id: batchId,
        description: `CSV Registration Import batch ${batchId} committed: ${successfulRows.length} successful, ${skippedRows.length} skipped, ${failedRows.length} failed.`,
      });

      return batchRecord;
    },

    getCsvImportBatches: async (): Promise<CsvImportBatchRecord[]> => {
      return [...(this.state.csvImportBatches || [])];
    },

    validateTimetable: async (params: {
      academic_year: string;
      semester: number;
      programme_code: string;
      section: string;
    }): Promise<TimetableValidationResult> => {
      const { academic_year, semester, programme_code, section } = params;

      const progDept = (programme_code || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();

      const matchingSlots = this.state.timetableSlots.filter((s) => {
        const isMatchAy = s.academic_year === academic_year;
        const isMatchSem = s.semester === Number(semester);
        const isMatchSec = section === 'ALL' || !section || s.section === section;
        const slotProg = (s.programme_code || '').toUpperCase();
        const slotDept = (s.department || '').toUpperCase();
        const isMatchProg = !programme_code ||
          slotProg === programme_code.toUpperCase() ||
          (progDept && slotDept === progDept);
        return s.status === 'ACTIVE' && isMatchAy && isMatchSem && isMatchSec && isMatchProg;
      });

      const conflicts: TimetableConflictDetail[] = [];
      const warnings: string[] = [];

      for (const slot of matchingSlots) {
        if (!slot.faculty_id || !slot.faculty_name) {
          conflicts.push({
            type: 'MISSING_FACULTY',
            description: `Slot for ${slot.course_code} (${slot.day_of_week} ${slot.start_time}-${slot.end_time}) has no assigned faculty member.`,
            day_of_week: slot.day_of_week,
            time: `${slot.start_time}-${slot.end_time}`,
            course_code: slot.course_code,
            section: slot.section,
          });
        }
        if (!slot.room || !slot.room.trim()) {
          conflicts.push({
            type: 'MISSING_ROOM',
            description: `Slot for ${slot.course_code} (${slot.day_of_week} ${slot.start_time}-${slot.end_time}) has no designated room.`,
            day_of_week: slot.day_of_week,
            time: `${slot.start_time}-${slot.end_time}`,
            course_code: slot.course_code,
            section: slot.section,
          });
        }
      }

      // Check section clashes ONLY within the same programme & section
      for (let i = 0; i < matchingSlots.length; i++) {
        for (let j = i + 1; j < matchingSlots.length; j++) {
          const a = matchingSlots[i];
          const b = matchingSlots[j];
          if (a.day_of_week === b.day_of_week && a.section === b.section) {
            const overlap = a.start_time < b.end_time && b.start_time < a.end_time;
            if (overlap) {
              conflicts.push({
                type: 'SECTION_CLASH',
                description: `Section ${a.section} has overlapping lectures on ${a.day_of_week}: ${a.course_code} (${a.start_time}-${a.end_time}) and ${b.course_code} (${b.start_time}-${b.end_time}).`,
                day_of_week: a.day_of_week,
                time: `${a.start_time}-${a.end_time}`,
                course_code: `${a.course_code} / ${b.course_code}`,
                section: a.section,
              });
            }
          }
        }
      }

      // Check faculty clashes across all active slots in the system
      const allActiveSlots = this.state.timetableSlots.filter((s) => s.status === 'ACTIVE');
      for (const slot of matchingSlots) {
        if (!slot.faculty_id) continue;
        const otherSlotsWithFaculty = allActiveSlots.filter(
          (s) =>
            s.slot_id !== slot.slot_id &&
            s.faculty_id === slot.faculty_id &&
            s.academic_year === slot.academic_year &&
            s.day_of_week === slot.day_of_week
        );
        for (const other of otherSlotsWithFaculty) {
          const overlap = slot.start_time < other.end_time && other.start_time < slot.end_time;
          if (overlap) {
            conflicts.push({
              type: 'FACULTY_CLASH',
              description: `Faculty ${slot.faculty_name} double-booked on ${slot.day_of_week}: ${slot.course_code} Sec ${slot.section} and ${other.course_code} Sec ${other.section} at ${slot.start_time}-${slot.end_time}.`,
              day_of_week: slot.day_of_week,
              time: `${slot.start_time}-${slot.end_time}`,
              faculty_id: slot.faculty_id,
              faculty_name: slot.faculty_name,
              course_code: slot.course_code,
              room: slot.room,
            });
          }
        }
      }

      // Check room clashes across all active slots in the system
      for (const slot of matchingSlots) {
        if (!slot.room) continue;
        const otherSlotsWithRoom = allActiveSlots.filter(
          (s) =>
            s.slot_id !== slot.slot_id &&
            s.room.trim().toLowerCase() === slot.room.trim().toLowerCase() &&
            s.academic_year === slot.academic_year &&
            s.day_of_week === slot.day_of_week
        );
        for (const other of otherSlotsWithRoom) {
          const overlap = slot.start_time < other.end_time && other.start_time < slot.end_time;
          if (overlap) {
            conflicts.push({
              type: 'ROOM_CLASH',
              description: `Room '${slot.room}' clash on ${slot.day_of_week}: Booked for ${slot.course_code} Sec ${slot.section} and ${other.course_code} Sec ${other.section} at ${slot.start_time}-${slot.end_time}.`,
              day_of_week: slot.day_of_week,
              time: `${slot.start_time}-${slot.end_time}`,
              room: slot.room,
              course_code: slot.course_code,
            });
          }
        }
      }

      // Enrolment checks
      const cohortOfferings = this.state.courseOfferings.filter(
        (o) =>
          o.academic_year === academic_year &&
          o.semester === Number(semester) &&
          (section === 'ALL' || !section || o.section === section) &&
          (!programme_code || o.programme_code === programme_code || (o.department && o.department.toUpperCase() === progDept))
      );

      for (const off of cohortOfferings) {
        const enrs = this.state.enrolments.filter(
          (e) => e.offering_id === off.offering_id && e.enrolment_status === 'ACTIVE'
        );
        if (enrs.length === 0) {
          warnings.push(`Course offering ${off.course_code} (Section ${off.section}) currently has zero active student enrolments.`);
        }
      }

      return {
        isValid: conflicts.length === 0,
        is_valid: conflicts.length === 0,
        academic_year,
        semester: Number(semester),
        programme_code,
        section,
        total_slots: matchingSlots.length,
        total_slots_checked: matchingSlots.length,
        conflicts: conflicts.map((c) => ({
          ...c,
          conflict_type: c.type,
          involved_courses: c.course_code ? [c.course_code] : [],
        })),
        warnings,
      };
    },

    publishTimetable: async (
      params: {
        academic_year: string;
        semester: number;
        programme_code: string;
        section: string;
        batch?: string;
        change_notes?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<TimetableVersionRecord> => {
      this.verifyAcademicAccess(actor, PermissionScope.WRITE);

      // Validation is strictly repeated immediately before publication
      const validation = await this.academic.validateTimetable({
        academic_year: params.academic_year,
        semester: params.semester,
        programme_code: params.programme_code,
        section: params.section,
      });

      if (!validation.isValid || validation.conflicts.length > 0) {
        const conflictMsgs = validation.conflicts.map((c) => c.description).join('; ');
        throw new Error(`Cannot publish timetable: Unresolved scheduling conflicts exist: ${conflictMsgs}`);
      }

      const progDept = (params.programme_code || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
      const matchingSlots = this.state.timetableSlots.filter((s) => {
        const isMatchAy = s.academic_year === params.academic_year;
        const isMatchSem = s.semester === Number(params.semester);
        const isMatchSec = params.section === 'ALL' || !params.section || s.section === params.section;
        const slotProg = (s.programme_code || '').toUpperCase();
        const slotDept = (s.department || '').toUpperCase();
        const isMatchProg = !params.programme_code ||
          slotProg === params.programme_code.toUpperCase() ||
          (progDept && slotDept === progDept);
        return s.status === 'ACTIVE' && isMatchAy && isMatchSem && isMatchSec && isMatchProg;
      });

      if (matchingSlots.length === 0) {
        throw new Error(
          `Cannot publish timetable: No active timetable slots found for ${params.programme_code} Semester ${params.semester} Section ${params.section}.`
        );
      }

      // Check for missing faculty or room
      const incompleteSlots = matchingSlots.filter((s) => !s.faculty_id || !s.room);
      if (incompleteSlots.length > 0) {
        throw new Error(
          `Cannot publish timetable: ${incompleteSlots.length} slot(s) lack required faculty or room assignments.`
        );
      }

      let versionNum = 1;
      const allCohortVersions = (this.state.timetableVersions || []).filter(
        (v) =>
          v.academic_year === params.academic_year &&
          v.semester === Number(params.semester) &&
          v.programme_code === params.programme_code &&
          v.section === params.section
      );
      if (allCohortVersions.length > 0) {
        versionNum = Math.max(...allCohortVersions.map((v) => v.version)) + 1;
      }

      // Historical version retention: mark previous published version as SUPERSEDED
      const updatedVersions = (this.state.timetableVersions || []).map((v) => {
        if (
          v.academic_year === params.academic_year &&
          v.semester === Number(params.semester) &&
          v.programme_code === params.programme_code &&
          v.section === params.section &&
          v.status === 'PUBLISHED'
        ) {
          return {
            ...v,
            status: 'SUPERSEDED' as const,
            updated_at: new Date().toISOString(),
          };
        }
        return v;
      });

      const timetableId = `TT-${params.academic_year}-${params.programme_code}-S${params.semester}-${params.section}-V${versionNum}`;
      const employee = this.state.employees.find((e) => e.employee_id === actor?.userId || (e as any).user_id === actor?.userId);
      const publisherName = employee ? `${employee.first_name} ${employee.last_name}` : actor?.userId || 'Academic Office Administrator';

      const newVersionRecord: TimetableVersionRecord = {
        timetable_id: timetableId,
        version_id: timetableId,
        academic_year: params.academic_year,
        semester: Number(params.semester),
        programme_code: params.programme_code,
        batch: params.batch || '2026',
        section: params.section,
        version: versionNum,
        status: 'PUBLISHED',
        slot_ids: matchingSlots.map((s) => s.slot_id),
        published_at: new Date().toISOString(),
        published_by: actor?.userId || 'academic_office',
        published_by_name: publisherName,
        change_notes: params.change_notes || (versionNum > 1 ? `Republished version ${versionNum}` : 'Official initial timetable publication'),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextState = {
        ...this.state,
        timetableVersions: [...updatedVersions, newVersionRecord],
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'academic_office',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: versionNum > 1 ? AuditAction.TIMETABLE_REPUBLISH : AuditAction.TIMETABLE_PUBLISH,
        target_worksheet: 'TimetableSlots',
        target_record_id: timetableId,
        description: `Official timetable v${versionNum} published for ${params.programme_code} Semester ${params.semester} Section ${params.section} with ${matchingSlots.length} confirmed slots.`,
      });

      return newVersionRecord;
    },

    getTimetableVersions: async (filters?: {
      academic_year?: string;
      semester?: number;
      programme_code?: string;
      section?: string;
    }): Promise<TimetableVersionRecord[]> => {
      let list = [...(this.state.timetableVersions || [])];
      if (filters?.academic_year) list = list.filter((v) => v.academic_year === filters.academic_year);
      if (filters?.semester) list = list.filter((v) => v.semester === Number(filters.semester));
      if (filters?.programme_code) list = list.filter((v) => v.programme_code === filters.programme_code);
      if (filters?.section && filters.section !== 'ALL') list = list.filter((v) => v.section === filters.section);
      return list.sort((a, b) => b.version - a.version);
    },

    getPublishedTimetableForStudent: async (
      studentIdOrReg: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{
      published: boolean;
      message?: string;
      timetable_id?: string;
      version?: number;
      published_at?: string;
      published_by_name?: string;
      change_notes?: string;
      slots: TimetableSlotRecord[];
    }> => {
      if (!studentIdOrReg || !studentIdOrReg.trim()) {
        return { published: false, message: 'Valid student identifier is required.', slots: [] };
      }

      const student = this.state.students.find(
        (s) =>
          s.student_id === studentIdOrReg ||
          s.registration_number.toLowerCase() === studentIdOrReg.toLowerCase()
      );
      if (!student) {
        return { published: false, message: 'Student record not found.', slots: [] };
      }

      // Security & Authorization: student cannot view timetables of other students
      if (actor && actor.role === AuthRole.STUDENT) {
        const isSelf =
          actor.userId === student.student_id ||
          actor.userId.toLowerCase() === student.registration_number.toLowerCase();
        if (!isSelf) {
          throw new Error('Unauthorized: Students cannot view timetable schedules of other students.');
        }
      }

      const enrolments = this.state.enrolments.filter(
        (e) => e.student_id === student.student_id && e.enrolment_status === 'ACTIVE'
      );

      const studentSem = student.current_semester || enrolments[0]?.semester || 3;
      const studentSec = student.section || enrolments[0]?.section || 'A';
      const studentProgCode = student.department ? `BTECH-${student.department.toUpperCase()}` : 'BTECH-CSE';

      // Look ONLY for PUBLISHED versions matching the student's exact programme, semester, and section
      const publishedVersion = (this.state.timetableVersions || []).find((v) => {
        if (v.status !== 'PUBLISHED') return false;
        const matchSem = v.semester === Number(studentSem);
        const matchSec = v.section === studentSec || v.section === 'ALL';
        const progDept = (v.programme_code || '').replace('BTECH-', '').replace('MTECH-', '').toUpperCase();
        const stuDept = (student.department || '').toUpperCase();
        const matchProg =
          v.programme_code === studentProgCode ||
          (progDept && stuDept === progDept) ||
          (student.program_name && v.programme_code && student.program_name.toUpperCase().includes(progDept));
        return matchSem && matchSec && matchProg;
      });

      if (!publishedVersion) {
        return {
          published: false,
          message: `No official timetable has been published yet by the Academic Office for your cohort (${student.program_name || 'B.Tech'}, Semester ${studentSem}, Section ${studentSec}).`,
          slots: [],
        };
      }

      // Only return confirmed slots that are in publishedVersion.slot_ids AND match student's active course enrolments
      const enrolledCourseCodes = new Set(enrolments.map((e) => e.course_code.toUpperCase()));
      const studentSlots = this.state.timetableSlots.filter((slot) => {
        if (slot.status !== 'ACTIVE') return false;
        const inPublishedList = publishedVersion.slot_ids.includes(slot.slot_id);
        const matchesEnrolment = enrolledCourseCodes.has(slot.course_code.toUpperCase());
        return inPublishedList && matchesEnrolment;
      });

      return {
        published: true,
        timetable_id: publishedVersion.timetable_id,
        version: publishedVersion.version,
        published_at: publishedVersion.published_at,
        published_by_name: publishedVersion.published_by_name,
        change_notes: publishedVersion.change_notes,
        slots: studentSlots,
      };
    },

    getAcademicDashboardMetrics: async () => {
      return {
        activeProgrammesCount: this.state.programmes.filter((p) => p.status === 'ACTIVE').length,
        activeCoursesCount: this.state.courses.filter((c) => c.status === 'ACTIVE').length,
        currentSemestersCount: this.state.semesters.filter((s) => s.status === 'ACTIVE').length,
        activeSectionsCount: this.state.sections.filter((s) => s.status === 'ACTIVE').length,
        facultyAssignmentsCount: this.state.facultyAssignments.filter((f) => f.assignment_status === 'ACTIVE').length,
        activeEnrolmentsCount: this.state.enrolments.filter((e) => e.enrolment_status === 'ACTIVE').length,
        unassignedOfferingsCount: this.state.courseOfferings.filter((o) => o.status === 'ACTIVE' && !o.assigned_faculty_id).length,
        timetableConflictsCount: 0,
      };
    },
  };

  // ---------------------------------------------------------------------------
  // ACADEMICS
  // ---------------------------------------------------------------------------
  public academics = {
    getByStudent: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AcademicRecord[]> => {
      if (actor) {
        const student = this.state.students.find(
          (s) => s.student_id === studentId || s.registration_number === studentId
        );
        if (actor.role === AuthRole.STUDENT) {
          const isSelf =
            actor.userId === studentId ||
            (student && (actor.userId === student.student_id || actor.userId === student.registration_number));
          if (!isSelf) {
            throw new Error('Unauthorized: Students cannot view academic records belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === studentId ||
                l.student_registration_number === studentId ||
                (student && (l.student_id === student.student_id || l.student_registration_number === student.registration_number))) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_grades) {
            throw new Error('Access Denied: Parent does not have permission to view academic grades for this student (can_view_grades is false).');
          }
        }
      }

      return this.state.academics.filter(
        (a) => a.student_id === studentId || a.registration_number === studentId
      );
    },
  };

  // ---------------------------------------------------------------------------
  // ATTENDANCE
  // ---------------------------------------------------------------------------
  public attendance = {
    getByStudent: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AttendanceRecord[]> => {
      if (actor) {
        const student = this.state.students.find(
          (s) => s.student_id === studentId || s.registration_number === studentId
        );
        if (actor.role === AuthRole.STUDENT) {
          const isSelf =
            actor.userId === studentId ||
            (student && (actor.userId === student.student_id || actor.userId === student.registration_number));
          if (!isSelf) {
            throw new Error('Unauthorized: Students cannot view attendance records belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === studentId ||
                l.student_registration_number === studentId ||
                (student && (l.student_id === student.student_id || l.student_registration_number === student.registration_number))) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_attendance) {
            throw new Error('Access Denied: Parent does not have permission to view attendance records for this student (can_view_attendance is false).');
          }
        }
      }

      return this.state.attendance.filter(
        (a) => a.student_id === studentId || a.registration_number === studentId
      );
    },
    getAll: async (): Promise<AttendanceRecord[]> => {
      return [...this.state.attendance];
    },
    record: async (
      data: Omit<AttendanceRecord, 'attendance_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AttendanceRecord> => {
      // If actor is faculty member, verify assigned to this course
      if (actor && (actor.role === AuthRole.FACULTY || actor.employeeId)) {
        const empId =
          actor.employeeId ||
          this.state.employees.find((e) => e.registration_number === actor.userId)?.employee_id;
        if (empId) {
          const isAssigned = this.state.facultyAssignments.some(
            (f) =>
              f.employee_id === empId &&
              f.course_code === data.course_code &&
              f.assignment_status === 'ACTIVE'
          );
          if (!isAssigned) {
            throw new Error(`Unauthorized: Faculty member '${actor.userId}' is not assigned to course '${data.course_code}'.`);
          }
        }
      }

      // Check duplicate attendance entry for same student, course, date, and session slot
      const duplicate = this.state.attendance.find(
        (a) =>
          (a.student_id === data.student_id || a.registration_number === data.registration_number) &&
          a.course_code === data.course_code &&
          a.date === data.date &&
          a.session_slot === data.session_slot
      );
      if (duplicate) {
        throw new Error(
          `Duplicate Attendance Entry: Attendance for student '${data.student_id}' in course '${data.course_code}' on ${data.date} (slot ${data.session_slot}) has already been recorded.`
        );
      }

      const newId = `ATT-2026-${String(this.state.attendance.length + 1).padStart(3, '0')}`;
      const record: AttendanceRecord = {
        ...data,
        attendance_id: newId,
        created_at: new Date().toISOString(),
      };
      const nextState = {
        ...this.state,
        attendance: [...this.state.attendance, record],
      };
      this.saveState(nextState);
      return record;
    },
    correctAttendance: async (
      attendanceId: string,
      revisedStatus: AttendanceStatus,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AttendanceRecord> => {
      if (!reason?.trim()) {
        throw new Error('Validation Error: A mandatory justification reason is required to correct attendance.');
      }
      const existing = this.state.attendance.find((a) => a.attendance_id === attendanceId);
      if (!existing) {
        throw new Error(`Attendance record '${attendanceId}' not found.`);
      }

      // If actor is faculty, enforce that faculty is assigned to this course
      if (actor && (actor.role === AuthRole.FACULTY || actor.employeeId)) {
        const empId =
          actor.employeeId ||
          this.state.employees.find((e) => e.registration_number === actor.userId)?.employee_id;
        if (empId) {
          const isAssigned = this.state.facultyAssignments.some(
            (f) =>
              f.employee_id === empId &&
              f.course_code === existing.course_code &&
              f.assignment_status === 'ACTIVE'
          );
          if (!isAssigned) {
            throw new Error(`Unauthorized: Faculty member '${actor.userId}' is not assigned to course '${existing.course_code}'.`);
          }
        }
      }

      const updated: AttendanceRecord = {
        ...existing,
        status: revisedStatus,
        remarks: existing.remarks ? `${existing.remarks} [Corrected: ${reason}]` : `Corrected: ${reason}`,
      };

      const nextState = {
        ...this.state,
        attendance: this.state.attendance.map((a) => (a.attendance_id === attendanceId ? updated : a)),
      };
      this.saveState(nextState);

      await this.audit.log({
        actor_id: actor?.userId || 'FACULTY',
        actor_role: actor?.role || 'FACULTY',
        action: AuditAction.UPDATE,
        target_worksheet: 'Attendance',
        target_record_id: attendanceId,
        description: `Corrected attendance for student '${existing.student_id}' in course '${existing.course_code}' from ${existing.status} to ${revisedStatus}. Reason: ${reason}`,
      });

      return updated;
    },
  };

  // ---------------------------------------------------------------------------
  // EXAMINATIONS
  // ---------------------------------------------------------------------------
  public examinations = {
    getByStudent: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExaminationRecord[]> => {
      if (actor) {
        const student = this.state.students.find(
          (s) => s.student_id === studentId || s.registration_number === studentId
        );
        if (actor.role === AuthRole.STUDENT) {
          const isSelf =
            actor.userId === studentId ||
            (student && (actor.userId === student.student_id || actor.userId === student.registration_number));
          if (!isSelf) {
            throw new Error('Unauthorized: Students cannot view examination records belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === studentId ||
                l.student_registration_number === studentId ||
                (student && (l.student_id === student.student_id || l.student_registration_number === student.registration_number))) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_grades) {
            throw new Error('Access Denied: Parent does not have permission to view examination records for this student (can_view_grades is false).');
          }
        }
      }

      return this.state.examinations.filter(
        (e) => e.student_id === studentId || e.hall_ticket_number === studentId
      );
    },
    getAll: async (): Promise<ExaminationRecord[]> => {
      return [...this.state.examinations];
    },
    recordOrUpdate: async (
      data: Omit<ExaminationRecord, 'exam_id' | 'published_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExaminationRecord> => {
      // If actor is faculty member, verify assigned to evaluate this course
      if (actor && (actor.role === AuthRole.FACULTY || actor.employeeId)) {
        const empId =
          actor.employeeId ||
          this.state.employees.find((e) => e.registration_number === actor.userId)?.employee_id;
        if (empId) {
          const isAssigned = this.state.facultyAssignments.some(
            (f) =>
              f.employee_id === empId &&
              f.course_code === data.course_code &&
              f.assignment_status === 'ACTIVE'
          );
          if (!isAssigned) {
            throw new Error(`Unauthorized: Faculty member '${actor.userId}' is not assigned to evaluate course '${data.course_code}'.`);
          }
        }
      }

      const existingIdx = this.state.examinations.findIndex(
        (e) => e.student_id === data.student_id && e.course_code === data.course_code && e.exam_session === data.exam_session
      );
      let record: ExaminationRecord;
      let nextList: ExaminationRecord[];
      if (existingIdx >= 0) {
        record = {
          ...this.state.examinations[existingIdx],
          ...data,
          published_at: new Date().toISOString(),
        };
        nextList = [...this.state.examinations];
        nextList[existingIdx] = record;
      } else {
        const newId = `EXM-2026-${String(this.state.examinations.length + 1).padStart(3, '0')}`;
        record = {
          ...data,
          exam_id: newId,
          published_at: new Date().toISOString(),
        };
        nextList = [...this.state.examinations, record];
      }
      this.saveState({
        ...this.state,
        examinations: nextList,
      });
      return record;
    },
  };

  // ---------------------------------------------------------------------------
  // FINANCE OFFICE (Phase 9 Complete)
  // ---------------------------------------------------------------------------
  public finance = {
    // 1. Fee Structures
    getFeeStructures: async (
      filters?: { academic_year?: string; semester?: number; programme_code?: string; status?: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeStructureRecord[]> => {
      this.verifyFinanceAccess(actor, PermissionScope.READ, 'FeeStructures');
      return this.state.feeStructures.filter((fs) => {
        if (filters?.academic_year && fs.academic_year !== filters.academic_year) return false;
        if (filters?.semester !== undefined && fs.semester !== filters.semester) return false;
        if (filters?.programme_code && fs.programme_code !== filters.programme_code && fs.programme_code !== 'ALL') return false;
        if (filters?.status && fs.status !== filters.status) return false;
        return true;
      });
    },

    createFeeStructure: async (
      data: Omit<FeeStructureRecord, 'structure_id' | 'created_at' | 'updated_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeStructureRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'FeeStructures');

      if (!data.fee_category || !data.academic_year || data.semester === undefined || !data.programme_code || !data.fee_name) {
        throw new Error('Validation Error: Required fee structure fields missing (category, academic year, semester, programme, fee name).');
      }
      if (typeof data.amount !== 'number' || data.amount <= 0) {
        throw new Error('Validation Error: Fee structure amount must be a positive number.');
      }
      if (!data.currency || !data.due_date) {
        throw new Error('Validation Error: Currency and due date are required for fee structure.');
      }

      // Check duplicate active fee structure for same cohort, academic year, semester, category
      const existing = this.state.feeStructures.find(
        (f) =>
          f.academic_year === data.academic_year &&
          f.semester === data.semester &&
          f.programme_code === data.programme_code &&
          f.fee_category === data.fee_category &&
          f.status === 'ACTIVE'
      );
      if (existing) {
        throw new Error(
          `Duplicate Fee Structure: An active fee structure (${existing.structure_id}) already exists for ${data.programme_code} ${data.fee_category} in ${data.academic_year} Semester ${data.semester}.`
        );
      }

      const structureId = `FST-${data.academic_year.replace(/\s+/g, '')}-S${data.semester}-${data.fee_category.toString().toUpperCase()}-${data.programme_code}`;
      const record: FeeStructureRecord = {
        ...data,
        structure_id: structureId,
        amount: this.roundCurrencyAmount(data.amount),
        currency: data.currency || 'USD',
        status: data.status || 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        feeStructures: [...this.state.feeStructures, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'FeeStructures',
        target_record_id: record.structure_id,
        description: `Created fee structure ${record.structure_id} for ${record.programme_code} (${record.fee_name}: $${record.amount} ${record.currency}).`,
      });

      return record;
    },

    updateFeeStructure: async (
      structureId: string,
      data: Partial<FeeStructureRecord>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeStructureRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'FeeStructures');
      const idx = this.state.feeStructures.findIndex((f) => f.structure_id === structureId);
      if (idx === -1) throw new Error(`Fee structure '${structureId}' not found.`);

      const current = this.state.feeStructures[idx];
      const updated: FeeStructureRecord = {
        ...current,
        ...data,
        structure_id: current.structure_id,
        amount: data.amount !== undefined ? this.roundCurrencyAmount(data.amount) : current.amount,
        updated_at: new Date().toISOString(),
      };

      const nextStructures = [...this.state.feeStructures];
      nextStructures[idx] = updated;
      this.saveState({
        ...this.state,
        feeStructures: nextStructures,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'FeeStructures',
        target_record_id: structureId,
        description: `Updated fee structure ${structureId} details.`,
      });

      return updated;
    },

    // 2. Invoices & Fee Ledger
    getInvoices: async (
      filters?: { invoice_id?: string; student_id?: string; registration_number?: string; academic_year?: string; semester?: number; status?: InvoiceStatus; category?: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord[]> => {
      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (!filters?.student_id && !filters?.registration_number) {
            throw new Error('Unauthorized: Students cannot view the complete institutional invoice registry.');
          }
          if (filters?.student_id && filters.student_id !== actor.userId) {
            const student = this.state.students.find((s) => s.student_id === actor.userId || s.registration_number === actor.userId);
            if (!student || student.student_id !== filters.student_id) {
              throw new Error('Unauthorized: Students cannot view invoices belonging to other students.');
            }
          }
          if (filters?.registration_number) {
            const student = this.state.students.find((s) => s.student_id === actor.userId || s.registration_number === actor.userId);
            if (!student || student.registration_number !== filters.registration_number) {
              throw new Error('Unauthorized: Students cannot view invoices belonging to other students.');
            }
          }
        } else if (actor.role === AuthRole.PARENT) {
          if (!filters?.student_id && !filters?.registration_number) {
            throw new Error('Unauthorized: Parents cannot view the complete institutional invoice registry.');
          }
          const targetStudentId = filters?.student_id || filters?.registration_number;
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === targetStudentId || l.student_registration_number === targetStudentId) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to view financial records for this student (can_view_finance is false).');
          }
        } else {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'Invoicing');
        }
      }

      return this.state.feeInvoices.filter((inv) => {
        if (filters?.invoice_id && inv.invoice_id !== filters.invoice_id) return false;
        if (filters?.student_id && inv.student_id !== filters.student_id) return false;
        if (filters?.registration_number && inv.registration_number !== filters.registration_number) return false;
        if (filters?.academic_year && inv.academic_year !== filters.academic_year) return false;
        if (filters?.semester !== undefined && inv.semester !== filters.semester) return false;
        if (filters?.status && inv.status !== filters.status) return false;
        if (filters?.category && inv.fee_category !== filters.category) return false;
        return true;
      });
    },

    getInvoiceById: async (
      invoiceId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord | null> => {
      const found = this.state.feeInvoices.find((i) => i.invoice_id === invoiceId);
      if (!found) return null;

      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (found.student_id !== actor.userId && found.registration_number !== actor.userId) {
            throw new Error('Unauthorized: Students cannot view invoices belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === found.student_id || l.student_registration_number === found.registration_number) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to view financial records for this student.');
          }
        } else {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'Invoicing');
        }
      }

      return { ...found };
    },

    generateInvoice: async (
      data: {
        student_id: string;
        academic_year: string;
        semester: number;
        fee_category?: string;
        due_date?: string;
        line_items: { fee_structure_id?: string; category: string; description: string; amount: number }[];
        notes?: string;
        hostel_charge_id?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'Invoicing');

      const student = this.state.students.find(
        (s) => s.student_id === data.student_id || s.registration_number === data.student_id
      );
      if (!student) {
        throw new Error(`Student with ID '${data.student_id}' does not exist.`);
      }

      if (!data.line_items || data.line_items.length === 0) {
        throw new Error('Validation Error: Invoice must contain at least one line item.');
      }

      for (const item of data.line_items) {
        if (typeof item.amount !== 'number' || item.amount <= 0) {
          throw new Error(`Validation Error: Line item '${item.description}' amount must be greater than zero.`);
        }
      }

      const primaryCategory = data.fee_category || data.line_items[0]?.category || 'TUITION';

      // Check duplicate billing prevention for student + academic_year + semester + primary category
      const existing = this.state.feeInvoices.find(
        (inv) =>
          inv.student_id === student.student_id &&
          inv.academic_year === data.academic_year &&
          inv.semester === data.semester &&
          inv.fee_category === primaryCategory &&
          inv.status !== InvoiceStatus.CANCELLED &&
          (!data.hostel_charge_id || inv.hostel_charge_id === data.hostel_charge_id)
      );
      if (existing) {
        throw new Error(
          `Duplicate Billing: An active invoice (${existing.invoice_id}) already exists for student '${student.registration_number}' in ${data.academic_year} Semester ${data.semester} for category '${primaryCategory}'.`
        );
      }

      // Check hostel charge request duplicate invoice linkage
      if (data.hostel_charge_id) {
        const existingHostelInv = this.state.feeInvoices.find(
          (inv) => inv.hostel_charge_id === data.hostel_charge_id && inv.status !== InvoiceStatus.CANCELLED
        );
        if (existingHostelInv) {
          throw new Error(
            `Duplicate Billing: An invoice (${existingHostelInv.invoice_id}) has already been issued for hostel charge request '${data.hostel_charge_id}'.`
          );
        }
      }

      const subtotal = this.roundCurrencyAmount(
        data.line_items.reduce((sum, item) => sum + item.amount, 0)
      );
      const adjustmentsTotal = 0;
      const totalAmount = subtotal;
      const amountPaid = 0;
      const outstanding = totalAmount;

      const newSeq = this.state.feeInvoices.length + 1;
      const invoiceId = `INV-2026-${String(newSeq).padStart(3, '0')}`;
      const invoiceNumber = `EIT-INV-2026-${String(newSeq).padStart(4, '0')}`;
      const todayStr = new Date().toISOString().split('T')[0];

      const record: FeeInvoiceRecord = {
        invoice_id: invoiceId,
        invoice_number: invoiceNumber,
        student_id: student.student_id,
        registration_number: student.registration_number,
        student_name: `${student.first_name} ${student.last_name}`,
        programme_code: student.department || 'BTECH-CSE',
        academic_year: data.academic_year,
        semester: data.semester,
        fee_category: primaryCategory,
        issue_date: todayStr,
        due_date: data.due_date || '2026-11-30',
        line_items: data.line_items.map((li: any, idx: number) => ({
          line_id: `L-${invoiceId}-${idx + 1}`,
          fee_structure_id: li.fee_structure_id,
          category: li.category || li.item_code || primaryCategory || 'TUITION',
          description: li.description,
          amount: this.roundCurrencyAmount(li.amount),
        })),
        subtotal,
        adjustments_total: adjustmentsTotal,
        total_amount: totalAmount,
        amount_due: totalAmount,
        amount_paid: amountPaid,
        outstanding_balance: outstanding,
        currency: 'USD',
        status: InvoiceStatus.ISSUED,
        payment_status: PaymentStatus.PENDING,
        hostel_charge_id: data.hostel_charge_id,
        notes: data.notes,
        created_by: actor?.userId || 'finance',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Compatibility entry for worksheet 13
      const compatFinance: FinanceRecord = {
        invoice_id: record.invoice_id,
        student_id: record.student_id,
        registration_number: record.registration_number,
        fee_category: record.fee_category,
        academic_year: record.academic_year,
        semester: record.semester,
        amount_due: record.amount_due,
        amount_paid: record.amount_paid,
        currency: record.currency,
        payment_status: record.payment_status,
        created_at: record.created_at,
        updated_at: record.updated_at,
      };

      this.saveState({
        ...this.state,
        feeInvoices: [...this.state.feeInvoices, record],
        finance: [...this.state.finance, compatFinance],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'FinanceInvoices',
        target_record_id: record.invoice_id,
        description: `Generated fee invoice ${record.invoice_id} for student ${record.registration_number} (Amount: $${record.total_amount}).`,
      });

      return record;
    },

    cancelInvoice: async (
      invoiceId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.APPROVE, 'Invoicing');
      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Cancellation reason is strictly required.');
      }

      const idx = this.state.feeInvoices.findIndex((i) => i.invoice_id === invoiceId);
      if (idx === -1) throw new Error(`Invoice '${invoiceId}' not found.`);

      const current = this.state.feeInvoices[idx];
      if (current.status === InvoiceStatus.CANCELLED) {
        throw new Error(`Invoice '${invoiceId}' is already cancelled.`);
      }
      if (current.amount_paid > 0) {
        throw new Error(
          `Cannot Cancel Invoice: Invoice ${invoiceId} has recorded payments ($${current.amount_paid}). Reverse or refund recorded payments before cancellation.`
        );
      }

      const updated: FeeInvoiceRecord = {
        ...current,
        status: InvoiceStatus.CANCELLED,
        payment_status: PaymentStatus.PENDING,
        cancellation_reason: reason.trim(),
        cancelled_by: actor?.userId || 'finance',
        cancelled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextInvoices = [...this.state.feeInvoices];
      nextInvoices[idx] = updated;

      // Reconcile linked hostel charge request if present
      let nextHostelCharges = this.state.hostelCharges;
      if (current.hostel_charge_id) {
        nextHostelCharges = this.state.hostelCharges.map((hc) => {
          if (hc.charge_request_id === current.hostel_charge_id) {
            return {
              ...hc,
              status: HostelChargeStatus.REQUESTED,
              invoice_id: undefined,
              invoiced_by: undefined,
              invoiced_at: undefined,
            };
          }
          return hc;
        });
      }

      // Sync finance compatibility
      const nextCompat = this.state.finance.map((f) =>
        f.invoice_id === invoiceId ? { ...f, updated_at: updated.updated_at } : f
      );

      this.saveState({
        ...this.state,
        feeInvoices: nextInvoices,
        finance: nextCompat,
        hostelCharges: nextHostelCharges,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'FinanceInvoices',
        target_record_id: invoiceId,
        description: `Cancelled invoice ${invoiceId}. Reason: ${reason}`,
      });

      return updated;
    },

    // 3. Payments & Receipts
    getPayments: async (
      filters?: { invoice_id?: string; student_id?: string; status?: PaymentLedgerStatus },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<PaymentRecord[]> => {
      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (!filters?.student_id) {
            throw new Error('Unauthorized: Students cannot view the complete institutional payment registry.');
          }
          if (filters.student_id !== actor.userId) {
            const student = this.state.students.find((s) => s.student_id === actor.userId || s.registration_number === actor.userId);
            if (!student || student.student_id !== filters.student_id) {
              throw new Error('Unauthorized: Students cannot view payments belonging to other students.');
            }
          }
        } else if (actor.role === AuthRole.PARENT) {
          if (!filters?.student_id) {
            throw new Error('Unauthorized: Parents cannot view the complete institutional payment registry.');
          }
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === filters.student_id || l.student_registration_number === filters.student_id) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to view financial records for this student.');
          }
        } else {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'Payments');
        }
      }

      return this.state.payments.filter((p) => {
        if (filters?.invoice_id && p.invoice_id !== filters.invoice_id) return false;
        if (filters?.student_id && p.student_id !== filters.student_id) return false;
        if (filters?.status && p.status !== filters.status) return false;
        return true;
      });
    },

    getPaymentById: async (
      paymentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<PaymentRecord | null> => {
      this.verifyFinanceAccess(actor, PermissionScope.READ, 'Payments');
      const found = this.state.payments.find((p) => p.payment_id === paymentId);
      return found ? { ...found } : null;
    },

    recordPayment: async (
      invoiceId: string,
      amount: number,
      arg3?: string | PaymentMethod,
      arg4?: PaymentMethod | string,
      arg5?: any,
      arg6?: any
    ): Promise<PaymentRecord> => {
      let method: PaymentMethod = PaymentMethod.CASH;
      let reference: string = '';
      let notes: string | undefined;
      let actor: { userId: string; role: string; employeeId?: string } | undefined;

      const isMethodEnum = (val: any): val is PaymentMethod =>
        val === PaymentMethod.CASH ||
        val === PaymentMethod.BANK_TRANSFER ||
        val === PaymentMethod.CARD ||
        val === PaymentMethod.OTHER;

      if (isMethodEnum(arg3)) {
        // Called as: (invoiceId, amount, method, reference, notes?, actor?)
        method = arg3;
        reference = typeof arg4 === 'string' ? arg4 : `TXN-${Date.now().toString().slice(-6)}`;
        if (typeof arg5 === 'string') notes = arg5;
        if (typeof arg5 === 'object' && arg5?.userId) actor = arg5;
        if (typeof arg6 === 'object' && arg6?.userId) actor = arg6;
      } else {
        // Called as: (invoiceId, amount, reference, method?, actor?, notes?)
        reference = typeof arg3 === 'string' ? arg3 : `TXN-${Date.now().toString().slice(-6)}`;
        if (isMethodEnum(arg4)) {
          method = arg4;
        }
        if (typeof arg5 === 'object' && arg5?.userId) actor = arg5;
        else if (typeof arg5 === 'string') notes = arg5;
        if (typeof arg6 === 'string') notes = arg6;
        else if (typeof arg6 === 'object' && arg6?.userId) actor = arg6;
      }

      if (typeof amount !== 'number' || amount <= 0) {
        throw new Error('Validation Error: Payment amount must be a positive number.');
      }
      const roundedAmount = this.roundCurrencyAmount(amount);

      if (!reference || !reference.trim()) {
        throw new Error('Validation Error: Transaction reference is required.');
      }
      const cleanRef = reference.trim();

      // Duplicate payment reference prevention
      const existingRef = this.state.payments.find(
        (p) => p.transaction_reference.toLowerCase() === cleanRef.toLowerCase()
      );
      if (existingRef) {
        throw new Error(
          `Duplicate Payment Reference: Transaction reference '${cleanRef}' has already been recorded in payment ${existingRef.payment_id}.`
        );
      }

      // Check invoice
      const invIdx = this.state.feeInvoices.findIndex((i) => i.invoice_id === invoiceId);
      if (invIdx === -1) throw new Error(`Invoice '${invoiceId}' not found.`);
      const invoice = this.state.feeInvoices[invIdx];

      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (invoice.student_id !== actor.userId && invoice.registration_number !== actor.userId) {
            throw new Error(`Unauthorized: Students cannot record payments on invoices belonging to other students.`);
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === invoice.student_id || l.student_registration_number === invoice.registration_number) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to access financial records for this student.');
          }
        } else {
          this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'Payments');
        }
      }

      if (invoice.status === InvoiceStatus.CANCELLED) {
        throw new Error(`Cannot Record Payment: Invoice '${invoiceId}' is cancelled.`);
      }

      if (roundedAmount > invoice.outstanding_balance) {
        throw new Error(
          `Validation Error: Payment amount ($${roundedAmount}) cannot exceed outstanding invoice balance ($${invoice.outstanding_balance}).`
        );
      }

      const newPaid = this.roundCurrencyAmount(invoice.amount_paid + roundedAmount);
      const newOutstanding = this.roundCurrencyAmount(Math.max(0, invoice.total_amount - newPaid));
      const newStatus = newOutstanding === 0 ? InvoiceStatus.PAID : InvoiceStatus.PARTIALLY_PAID;
      const newPaymentStatus = newOutstanding === 0 ? PaymentStatus.PAID : PaymentStatus.PARTIAL;

      const updatedInvoice: FeeInvoiceRecord = {
        ...invoice,
        amount_paid: newPaid,
        outstanding_balance: newOutstanding,
        status: newStatus,
        payment_status: newPaymentStatus,
        transaction_reference: cleanRef,
        payment_method: method,
        payment_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const newSeq = this.state.payments.length + 1;
      const paymentId = `PAY-2026-${String(newSeq).padStart(4, '0')}`;
      const receiptNumber = `REC-2026-${String(newSeq).padStart(4, '0')}`;

      const paymentRecord: PaymentRecord = {
        payment_id: paymentId,
        receipt_number: receiptNumber,
        invoice_id: invoice.invoice_id,
        student_id: invoice.student_id,
        registration_number: invoice.registration_number,
        student_name: invoice.student_name,
        amount: roundedAmount,
        currency: invoice.currency,
        payment_date: new Date().toISOString(),
        payment_method: method,
        transaction_reference: cleanRef,
        receiving_officer_id: actor?.userId || 'finance',
        status: PaymentLedgerStatus.VERIFIED,
        notes: notes || 'Manual payment recorded in finance ledger.',
        created_at: new Date().toISOString(),
      };

      const nextInvoices = [...this.state.feeInvoices];
      nextInvoices[invIdx] = updatedInvoice;

      // Sync finance compatibility record
      const nextCompat = this.state.finance.map((f) => {
        if (f.invoice_id === invoiceId) {
          return {
            ...f,
            amount_paid: newPaid,
            payment_status: newPaymentStatus,
            transaction_reference: cleanRef,
            payment_method: method,
            payment_date: paymentRecord.payment_date,
            updated_at: updatedInvoice.updated_at,
          };
        }
        return f;
      });

      this.saveState({
        ...this.state,
        payments: [...this.state.payments, paymentRecord],
        feeInvoices: nextInvoices,
        finance: nextCompat,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'PaymentLedger',
        target_record_id: paymentId,
        description: `Recorded payment of $${roundedAmount} against invoice ${invoiceId} (Receipt: ${receiptNumber}, Ref: ${cleanRef}).`,
      });

      return paymentRecord;
    },

    reversePayment: async (
      paymentId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<PaymentRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.APPROVE, 'Payments');
      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Payment reversal reason is strictly required.');
      }

      const pIdx = this.state.payments.findIndex((p) => p.payment_id === paymentId);
      if (pIdx === -1) throw new Error(`Payment record '${paymentId}' not found.`);

      const payment = this.state.payments[pIdx];
      if (payment.status === PaymentLedgerStatus.REVERSED) {
        throw new Error(`Payment ${paymentId} has already been reversed.`);
      }
      if (payment.status === PaymentLedgerStatus.REFUNDED) {
        throw new Error(`Payment ${paymentId} has already been refunded.`);
      }

      // Revert invoice amounts
      const invIdx = this.state.feeInvoices.findIndex((i) => i.invoice_id === payment.invoice_id);
      if (invIdx === -1) throw new Error(`Associated invoice '${payment.invoice_id}' not found.`);
      const invoice = this.state.feeInvoices[invIdx];

      const newPaid = this.roundCurrencyAmount(Math.max(0, invoice.amount_paid - payment.amount));
      const newOutstanding = this.roundCurrencyAmount(invoice.total_amount - newPaid);
      const newStatus = newPaid === 0 ? InvoiceStatus.ISSUED : InvoiceStatus.PARTIALLY_PAID;
      const newPaymentStatus = newPaid === 0 ? PaymentStatus.PENDING : PaymentStatus.PARTIAL;

      const updatedInvoice: FeeInvoiceRecord = {
        ...invoice,
        amount_paid: newPaid,
        outstanding_balance: newOutstanding,
        status: newStatus,
        payment_status: newPaymentStatus,
        updated_at: new Date().toISOString(),
      };

      const updatedPayment: PaymentRecord = {
        ...payment,
        status: PaymentLedgerStatus.REVERSED,
        reversal_reason: reason.trim(),
        reversed_by: actor?.userId || 'finance',
        reversed_at: new Date().toISOString(),
      };

      const nextPayments = [...this.state.payments];
      nextPayments[pIdx] = updatedPayment;

      const nextInvoices = [...this.state.feeInvoices];
      nextInvoices[invIdx] = updatedInvoice;

      const nextCompat = this.state.finance.map((f) =>
        f.invoice_id === invoice.invoice_id
          ? { ...f, amount_paid: newPaid, payment_status: newPaymentStatus, updated_at: updatedInvoice.updated_at }
          : f
      );

      this.saveState({
        ...this.state,
        payments: nextPayments,
        feeInvoices: nextInvoices,
        finance: nextCompat,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'PaymentLedger',
        target_record_id: paymentId,
        description: `Reversed payment ${paymentId} of $${payment.amount} on invoice ${invoice.invoice_id}. Reason: ${reason}`,
      });

      return updatedPayment;
    },

    refundPayment: async (
      paymentId: string,
      amount: number,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<PaymentRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.APPROVE, 'Payments');
      if (typeof amount !== 'number' || amount <= 0) {
        throw new Error('Validation Error: Refund amount must be a positive number.');
      }
      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Refund reason is required.');
      }

      const pIdx = this.state.payments.findIndex((p) => p.payment_id === paymentId);
      if (pIdx === -1) throw new Error(`Payment record '${paymentId}' not found.`);

      const payment = this.state.payments[pIdx];
      if (payment.status === PaymentLedgerStatus.REVERSED) {
        throw new Error(`Cannot refund reversed payment ${paymentId}.`);
      }
      if (payment.status === PaymentLedgerStatus.REFUNDED) {
        throw new Error(`Payment ${paymentId} has already been fully refunded.`);
      }
      if (payment.status !== PaymentLedgerStatus.VERIFIED && payment.status !== PaymentLedgerStatus.RECORDED) {
        throw new Error(`Cannot refund payment ${paymentId} with status '${payment.status}'.`);
      }

      const currentRefunded = payment.refund_amount || 0;
      const refundableBalance = this.roundCurrencyAmount(payment.amount - currentRefunded);
      const refundAmount = this.roundCurrencyAmount(amount);

      if (refundAmount > refundableBalance) {
        throw new Error(`Refund amount ($${refundAmount}) cannot exceed remaining refundable payment amount ($${refundableBalance}).`);
      }

      const invIdx = this.state.feeInvoices.findIndex((i) => i.invoice_id === payment.invoice_id);
      if (invIdx === -1) throw new Error(`Invoice '${payment.invoice_id}' not found.`);
      const invoice = this.state.feeInvoices[invIdx];

      const newPaid = this.roundCurrencyAmount(Math.max(0, invoice.amount_paid - refundAmount));
      const newOutstanding = this.roundCurrencyAmount(invoice.total_amount - newPaid);
      const newStatus = newPaid === 0 ? InvoiceStatus.ISSUED : InvoiceStatus.PARTIALLY_PAID;
      const newPaymentStatus = newPaid === 0 ? PaymentStatus.PENDING : PaymentStatus.PARTIAL;

      const updatedInvoice: FeeInvoiceRecord = {
        ...invoice,
        amount_paid: newPaid,
        outstanding_balance: newOutstanding,
        status: newStatus,
        payment_status: newPaymentStatus,
        updated_at: new Date().toISOString(),
      };

      const totalRefunded = this.roundCurrencyAmount(currentRefunded + refundAmount);
      const isFullyRefunded = totalRefunded >= payment.amount;

      const updatedPayment: PaymentRecord = {
        ...payment,
        status: isFullyRefunded ? PaymentLedgerStatus.REFUNDED : PaymentLedgerStatus.VERIFIED,
        refund_amount: totalRefunded,
        refund_reason: reason.trim(),
        refunded_by: actor?.userId || 'finance',
        refunded_at: new Date().toISOString(),
      };

      const nextPayments = [...this.state.payments];
      nextPayments[pIdx] = updatedPayment;

      const nextInvoices = [...this.state.feeInvoices];
      nextInvoices[invIdx] = updatedInvoice;

      const nextCompat = this.state.finance.map((f) =>
        f.invoice_id === invoice.invoice_id
          ? { ...f, amount_paid: newPaid, payment_status: newPaymentStatus, updated_at: updatedInvoice.updated_at }
          : f
      );

      this.saveState({
        ...this.state,
        payments: nextPayments,
        feeInvoices: nextInvoices,
        finance: nextCompat,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'PaymentLedger',
        target_record_id: paymentId,
        description: `Refunded $${refundAmount} for payment ${paymentId} (${isFullyRefunded ? 'Full' : 'Partial'} refund). Reason: ${reason}`,
      });

      return updatedPayment;
    },

    getReceipt: async (
      paymentIdOrReceiptNumber: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ payment: PaymentRecord; invoice: FeeInvoiceRecord; student: StudentRecord } | null> => {
      const payment = this.state.payments.find(
        (p) => p.payment_id === paymentIdOrReceiptNumber || p.receipt_number === paymentIdOrReceiptNumber
      );
      if (!payment) return null;

      const invoice = this.state.feeInvoices.find((i) => i.invoice_id === payment.invoice_id);
      const student = this.state.students.find((s) => s.student_id === payment.student_id);

      if (!invoice || !student) return null;

      // Isolation check
      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (actor.userId !== student.student_id && actor.userId !== student.registration_number) {
            throw new Error('Unauthorized: Students cannot view receipts belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === student.student_id || l.student_registration_number === student.registration_number) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to view financial records for this student.');
          }
        } else if (actor.role !== AuthRole.SUPER_ADMIN && actor.userId !== 'admin') {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'Payments');
        }
      }

      return { payment, invoice, student };
    },

    // 4. Adjustments, Discounts & Scholarships
    requestAdjustment: async (
      data: { invoice_id: string; adjustment_type: AdjustmentType; amount: number; reason: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeAdjustmentRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'Adjustments');

      if (typeof data.amount !== 'number' || data.amount <= 0) {
        throw new Error('Validation Error: Adjustment amount must be a positive number.');
      }
      if (!data.reason || !data.reason.trim()) {
        throw new Error('Validation Error: Adjustment justification reason is required.');
      }

      const invoice = this.state.feeInvoices.find((i) => i.invoice_id === data.invoice_id);
      if (!invoice) throw new Error(`Invoice '${data.invoice_id}' not found.`);

      if (invoice.status === InvoiceStatus.CANCELLED) {
        throw new Error(`Cannot apply adjustment: Invoice '${data.invoice_id}' is cancelled.`);
      }

      const maxAllowed = this.roundCurrencyAmount(invoice.subtotal - invoice.adjustments_total);
      if (this.roundCurrencyAmount(data.amount) > maxAllowed) {
        throw new Error(
          `Validation Error: Adjustment amount ($${data.amount}) exceeds remaining invoice subtotal ($${maxAllowed}). Total invoice cannot be negative.`
        );
      }

      const adjustmentId = `ADJ-2026-${String(this.state.feeAdjustments.length + 1).padStart(4, '0')}`;
      const record: FeeAdjustmentRecord = {
        adjustment_id: adjustmentId,
        invoice_id: invoice.invoice_id,
        student_id: invoice.student_id,
        registration_number: invoice.registration_number,
        adjustment_type: data.adjustment_type,
        amount: this.roundCurrencyAmount(data.amount),
        reason: data.reason.trim(),
        requested_by: actor?.userId || 'finance',
        requested_at: new Date().toISOString(),
        status: AdjustmentStatus.PENDING_APPROVAL,
        created_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        feeAdjustments: [...this.state.feeAdjustments, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'FeeAdjustments',
        target_record_id: adjustmentId,
        description: `Requested ${data.adjustment_type} of $${data.amount} for invoice ${invoice.invoice_id}. Reason: ${data.reason}`,
      });

      return record;
    },

    approveAdjustment: async (
      adjustmentId: string,
      notesOrActor?: any,
      actorArg?: any
    ): Promise<FeeAdjustmentRecord> => {
      const actor = (notesOrActor && typeof notesOrActor === 'object' && ('userId' in notesOrActor || 'role' in notesOrActor))
        ? notesOrActor
        : actorArg;
      this.verifyFinanceAccess(actor, PermissionScope.APPROVE, 'Adjustments');

      const adjIdx = this.state.feeAdjustments.findIndex((a) => a.adjustment_id === adjustmentId);
      if (adjIdx === -1) throw new Error(`Adjustment record '${adjustmentId}' not found.`);

      const adjustment = this.state.feeAdjustments[adjIdx];
      if (adjustment.status !== AdjustmentStatus.PENDING_APPROVAL) {
        throw new Error(`Adjustment '${adjustmentId}' is already ${adjustment.status}.`);
      }

      // Separation of Duties Enforcement: Creator cannot approve their own adjustment unless Super Admin
      if (actor?.userId && actor.userId === adjustment.requested_by && actor.role !== AuthRole.SUPER_ADMIN && actor.userId !== 'admin') {
        throw new Error(
          'Separation of Duties Violation: You cannot approve your own financial adjustment request. Another authorized Finance Officer or Super Admin must review and approve.'
        );
      }

      const invIdx = this.state.feeInvoices.findIndex((i) => i.invoice_id === adjustment.invoice_id);
      if (invIdx === -1) throw new Error(`Invoice '${adjustment.invoice_id}' not found.`);
      const invoice = this.state.feeInvoices[invIdx];

      const newAdjustments = this.roundCurrencyAmount(invoice.adjustments_total + adjustment.amount);
      const newTotal = this.roundCurrencyAmount(Math.max(0, invoice.subtotal - newAdjustments));
      const newOutstanding = this.roundCurrencyAmount(Math.max(0, newTotal - invoice.amount_paid));
      const newStatus = newOutstanding === 0 ? InvoiceStatus.PAID : invoice.amount_paid > 0 ? InvoiceStatus.PARTIALLY_PAID : InvoiceStatus.ISSUED;
      const newPaymentStatus = newOutstanding === 0 ? PaymentStatus.PAID : invoice.amount_paid > 0 ? PaymentStatus.PARTIAL : PaymentStatus.PENDING;

      const updatedInvoice: FeeInvoiceRecord = {
        ...invoice,
        adjustments_total: newAdjustments,
        total_amount: newTotal,
        amount_due: newTotal,
        outstanding_balance: newOutstanding,
        status: newStatus,
        payment_status: newPaymentStatus,
        updated_at: new Date().toISOString(),
      };

      const updatedAdjustment: FeeAdjustmentRecord = {
        ...adjustment,
        status: AdjustmentStatus.APPROVED,
        approved_by: actor?.userId || 'finance',
        approved_at: new Date().toISOString(),
      };

      const nextAdjustments = [...this.state.feeAdjustments];
      nextAdjustments[adjIdx] = updatedAdjustment;

      const nextInvoices = [...this.state.feeInvoices];
      nextInvoices[invIdx] = updatedInvoice;

      const nextCompat = this.state.finance.map((f) =>
        f.invoice_id === invoice.invoice_id
          ? { ...f, amount_due: newTotal, payment_status: newPaymentStatus, updated_at: updatedInvoice.updated_at }
          : f
      );

      this.saveState({
        ...this.state,
        feeAdjustments: nextAdjustments,
        feeInvoices: nextInvoices,
        finance: nextCompat,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.APPROVE,
        target_worksheet: 'FeeAdjustments',
        target_record_id: adjustmentId,
        description: `Approved adjustment ${adjustmentId} ($${adjustment.amount} ${adjustment.adjustment_type}) for invoice ${invoice.invoice_id}.`,
      });

      return updatedAdjustment;
    },

    rejectAdjustment: async (
      adjustmentId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeAdjustmentRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.APPROVE, 'Adjustments');
      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Rejection reason is required.');
      }

      const adjIdx = this.state.feeAdjustments.findIndex((a) => a.adjustment_id === adjustmentId);
      if (adjIdx === -1) throw new Error(`Adjustment record '${adjustmentId}' not found.`);

      const adjustment = this.state.feeAdjustments[adjIdx];
      const updated: FeeAdjustmentRecord = {
        ...adjustment,
        status: AdjustmentStatus.REJECTED,
        rejection_reason: reason.trim(),
        approved_by: actor?.userId || 'finance',
        approved_at: new Date().toISOString(),
      };

      const nextAdjustments = [...this.state.feeAdjustments];
      nextAdjustments[adjIdx] = updated;

      this.saveState({
        ...this.state,
        feeAdjustments: nextAdjustments,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'FeeAdjustments',
        target_record_id: adjustmentId,
        description: `Rejected adjustment ${adjustmentId}. Reason: ${reason}`,
      });

      return updated;
    },

    getAdjustments: async (
      filters?: { invoice_id?: string; student_id?: string; status?: AdjustmentStatus },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeAdjustmentRecord[]> => {
      this.verifyFinanceAccess(actor, PermissionScope.READ, 'Adjustments');
      return this.state.feeAdjustments.filter((a) => {
        if (filters?.invoice_id && a.invoice_id !== filters.invoice_id) return false;
        if (filters?.student_id && a.student_id !== filters.student_id) return false;
        if (filters?.status && a.status !== filters.status) return false;
        return true;
      });
    },

    // 5. Dashboard Metrics & Statements
    getFinanceDashboardMetrics: async (
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FinanceDashboardMetrics> => {
      this.verifyFinanceAccess(actor, PermissionScope.READ, 'FinancialReports');

      const nonCancelledInvoices = this.state.feeInvoices.filter((i) => i.status !== InvoiceStatus.CANCELLED);
      const totalInvoiced = this.roundCurrencyAmount(
        nonCancelledInvoices.reduce((sum, inv) => sum + inv.total_amount, 0)
      );

      // Reconciles with ledger: Count only non-reversed, non-refunded payments
      const activePayments = this.state.payments.filter(
        (p) => p.status === PaymentLedgerStatus.VERIFIED || p.status === PaymentLedgerStatus.RECORDED
      );
      const totalCollected = this.roundCurrencyAmount(
        activePayments.reduce((sum, p) => sum + (p.amount - (p.refund_amount || 0)), 0)
      );

      const totalOutstanding = this.roundCurrencyAmount(
        nonCancelledInvoices.reduce((sum, inv) => sum + inv.outstanding_balance, 0)
      );

      const todayStr = new Date().toISOString().split('T')[0];
      const overdueCount = nonCancelledInvoices.filter(
        (i) => i.outstanding_balance > 0 && i.due_date < todayStr
      ).length;

      const paidCount = nonCancelledInvoices.filter((i) => i.status === InvoiceStatus.PAID).length;
      const partialCount = nonCancelledInvoices.filter((i) => i.status === InvoiceStatus.PARTIALLY_PAID).length;
      const draftOrIssuedCount = nonCancelledInvoices.filter(
        (i) => i.status === InvoiceStatus.DRAFT || i.status === InvoiceStatus.ISSUED
      ).length;

      const totalDiscountsApproved = this.roundCurrencyAmount(
        this.state.feeAdjustments
          .filter((a) => a.status === AdjustmentStatus.APPROVED)
          .reduce((sum, a) => sum + a.amount, 0)
      );

      return {
        totalInvoiced,
        totalCollected,
        totalOutstanding,
        overdueInvoicesCount: overdueCount,
        paidInvoicesCount: paidCount,
        partialInvoicesCount: partialCount,
        draftOrIssuedInvoicesCount: draftOrIssuedCount,
        recentPaymentsCount: activePayments.length,
        totalDiscountsApproved,
      };
    },

    getStudentFeeStatement: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentFeeStatement> => {
      const student = this.state.students.find(
        (s) => s.student_id === studentId || s.registration_number === studentId
      );
      if (!student) throw new Error(`Student with ID '${studentId}' not found.`);

      // Isolation check
      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (actor.userId !== student.student_id && actor.userId !== student.registration_number) {
            throw new Error('Unauthorized: Students cannot view financial records belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === student.student_id || l.student_registration_number === student.registration_number) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
          if (!link.can_view_finance) {
            throw new Error('Access Denied: Parent does not have permission to view financial records for this student (can_view_finance is false).');
          }
        } else if (actor.role !== AuthRole.SUPER_ADMIN && actor.userId !== 'admin') {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'FeeLedger');
        }
      }

      const invoices = this.state.feeInvoices.filter(
        (i) => i.student_id === student.student_id && i.status !== InvoiceStatus.CANCELLED
      );
      const invoiceIds = new Set(invoices.map((i) => i.invoice_id));
      const payments = this.state.payments.filter((p) => invoiceIds.has(p.invoice_id));
      const adjustments = this.state.feeAdjustments.filter((a) => invoiceIds.has(a.invoice_id));

      const totalInvoiced = this.roundCurrencyAmount(invoices.reduce((s, i) => s + i.total_amount, 0));
      const totalPaid = this.roundCurrencyAmount(
        payments
          .filter((p) => p.status === PaymentLedgerStatus.VERIFIED || p.status === PaymentLedgerStatus.RECORDED)
          .reduce((s, p) => s + p.amount, 0)
      );
      const totalAdjustments = this.roundCurrencyAmount(
        adjustments.filter((a) => a.status === AdjustmentStatus.APPROVED).reduce((s, a) => s + a.amount, 0)
      );
      const totalOutstanding = this.roundCurrencyAmount(invoices.reduce((s, i) => s + i.outstanding_balance, 0));

      return {
        student,
        invoices,
        payments,
        adjustments,
        totalInvoiced,
        totalPaid,
        totalAdjustments,
        totalOutstanding,
      };
    },

    issueInvoiceForHostelCharge: async (
      chargeRequestId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord> => {
      this.verifyFinanceAccess(actor, PermissionScope.WRITE, 'Invoicing');

      const chargeIdx = this.state.hostelCharges.findIndex((c) => c.charge_request_id === chargeRequestId);
      if (chargeIdx === -1) throw new Error(`Hostel charge request '${chargeRequestId}' not found.`);

      const charge = this.state.hostelCharges[chargeIdx];
      if (charge.status === HostelChargeStatus.INVOICED) {
        throw new Error(`Hostel charge request ${chargeRequestId} has already been invoiced (${charge.invoice_id}).`);
      }
      if (charge.status === HostelChargeStatus.REJECTED) {
        throw new Error(`Cannot invoice rejected hostel charge request ${chargeRequestId}.`);
      }

      const allocation = this.state.hostelAllocations.find((a) => a.allocation_id === charge.allocation_id);
      let academicYear = allocation?.academic_year || '2026-2027';
      let semester = allocation?.semester || 1;

      if (charge.billing_period) {
        const semMatch = charge.billing_period.match(/SEM[-_]?(\d+)/i);
        if (semMatch) {
          semester = parseInt(semMatch[1], 10);
        }
        const yrMatch = charge.billing_period.match(/(\d{4}[-_]\d{4})/);
        if (yrMatch) {
          academicYear = yrMatch[1].replace('_', '-');
        }
      }

      const invoice = await this.finance.generateInvoice(
        {
          student_id: charge.student_id,
          academic_year: academicYear,
          semester,
          fee_category: 'HOSTEL',
          hostel_charge_id: chargeRequestId,
          line_items: [
            {
              category: 'HOSTEL',
              description: charge.description,
              amount: charge.amount,
            },
          ],
          notes: `Hostel residential accommodation charge request ${chargeRequestId}`,
        },
        actor
      );

      const updatedCharge: HostelChargeRequestRecord = {
        ...charge,
        status: HostelChargeStatus.INVOICED,
        invoice_id: invoice.invoice_id,
        invoiced_by: actor?.userId || 'finance',
        invoiced_at: new Date().toISOString(),
      };

      const nextCharges = [...this.state.hostelCharges];
      nextCharges[chargeIdx] = updatedCharge;

      this.saveState({
        ...this.state,
        hostelCharges: nextCharges,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'finance',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelCharges',
        target_record_id: chargeRequestId,
        description: `Finance Office issued invoice ${invoice.invoice_id} for hostel charge request ${chargeRequestId}.`,
      });

      return invoice;
    },

    // Backward compatibility methods
    getByStudent: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FinanceRecord[]> => {
      // If actor is student or parent, enforce isolation
      if (actor?.role === AuthRole.STUDENT || actor?.role === AuthRole.PARENT) {
        const statement = await this.finance.getStudentFeeStatement(studentId, actor);
        return statement.invoices;
      }
      return this.state.finance.filter(
        (f) => f.student_id === studentId || f.registration_number === studentId
      );
    },

    getAllInvoices: async (
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord[]> => {
      this.verifyFinanceAccess(actor, PermissionScope.READ, 'Invoicing');
      return [...this.state.feeInvoices];
    },

    createInvoice: async (
      data: any,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FeeInvoiceRecord> => {
      if (data.line_items) {
        return this.finance.generateInvoice(data, actor);
      }
      return this.finance.generateInvoice(
        {
          student_id: data.student_id,
          academic_year: data.academic_year || '2026-2027',
          semester: data.semester || 1,
          fee_category: data.fee_category || 'TUITION',
          line_items: [
            {
              category: data.fee_category || 'TUITION',
              description: `${data.fee_category || 'General'} Fee`,
              amount: data.amount_due || data.amount || 100,
            },
          ],
        },
        actor
      );
    },

    getPaymentLedger: async (filters?: any, actor?: any) => this.finance.getPayments(filters, actor),
    createInvoiceFromHostelCharge: async (chargeRequestId: string, actor?: any) => this.finance.issueInvoiceForHostelCharge(chargeRequestId, actor),
  };

  // ---------------------------------------------------------------------------
  // HOSTEL OFFICE (Phase 9 Complete)
  // ---------------------------------------------------------------------------
  public hostel = {
    // 1. Inventory: Blocks & Rooms & Beds
    getBlocks: async (
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelBlockRecord[]> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelInventory');
      return [...this.state.hostelBlocks];
    },

    createBlock: async (
      data: Omit<HostelBlockRecord, 'block_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelBlockRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelInventory');
      if (!data.block_name || !data.gender_type) {
        throw new Error('Validation Error: Block name and gender type are required.');
      }

      const existing = this.state.hostelBlocks.find(
        (b) => b.block_name.toLowerCase() === data.block_name.trim().toLowerCase()
      );
      if (existing) {
        throw new Error(`Duplicate Block: Block '${data.block_name}' already exists.`);
      }

      const blockId = `HST-BLK-${data.block_name.replace(/[^a-zA-Z0-9]/g, '').slice(0, 4).toUpperCase()}-${Date.now().toString().slice(-4)}`;
      const record: HostelBlockRecord = {
        ...data,
        block_id: blockId,
        created_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        hostelBlocks: [...this.state.hostelBlocks, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'HostelBlocks',
        target_record_id: blockId,
        description: `Created hostel block ${record.block_name} (${record.gender_type}).`,
      });

      return record;
    },

    getRooms: async (
      filters?: { block_id?: string; status?: RoomOperationalStatus; floor?: number },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelRoomRecord[]> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelInventory');
      return this.state.hostelRooms.filter((r) => {
        if (filters?.block_id && r.block_id !== filters.block_id) return false;
        if (filters?.status && r.status !== filters.status) return false;
        if (filters?.floor !== undefined && r.floor !== filters.floor) return false;
        return true;
      });
    },

    getRoomById: async (
      roomId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelRoomRecord | null> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelInventory');
      const found = this.state.hostelRooms.find((r) => r.room_id === roomId);
      return found ? { ...found } : null;
    },

    createRoom: async (
      data: {
        block_id: string;
        room_number: string;
        floor?: number;
        room_type: RoomType;
        capacity: number;
        amenities?: string[];
        bed_identifiers?: string[];
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelRoomRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelInventory');

      const block = this.state.hostelBlocks.find((b) => b.block_id === data.block_id);
      if (!block) throw new Error(`Hostel block '${data.block_id}' does not exist.`);

      if (!data.room_number || !data.room_number.trim()) {
        throw new Error('Validation Error: Room number is required.');
      }
      if (typeof data.capacity !== 'number' || data.capacity <= 0) {
        throw new Error('Validation Error: Room capacity must be a positive number.');
      }

      // Check duplicate room number in same block
      const existingRoom = this.state.hostelRooms.find(
        (r) => r.block_id === data.block_id && r.room_number.toLowerCase() === data.room_number.trim().toLowerCase()
      );
      if (existingRoom) {
        throw new Error(`Duplicate Room: Room '${data.room_number}' already exists in block '${block.block_name}'.`);
      }

      const roomId = `HST-RM-${block.block_id.replace('HST-BLK-', '')}-${data.room_number.trim()}`;
      const bedLetters = ['A', 'B', 'C', 'D', 'E', 'F'];
      const identifiers = data.bed_identifiers || bedLetters.slice(0, data.capacity);

      // Check unique bed identifiers
      if (new Set(identifiers).size !== identifiers.length) {
        throw new Error('Validation Error: Bed identifiers within a room must be unique.');
      }

      const beds: HostelBedRecord[] = identifiers.map((bid) => ({
        bed_id: `BED-${roomId}-${bid}`,
        room_id: roomId,
        bed_identifier: bid,
        status: BedOccupancyStatus.AVAILABLE,
      }));

      const record: HostelRoomRecord = {
        room_id: roomId,
        block_id: block.block_id,
        block_name: block.block_name,
        room_number: data.room_number.trim(),
        floor: data.floor || 1,
        room_type: data.room_type || RoomType.DOUBLE,
        capacity: data.capacity,
        amenities: data.amenities || ['Ceiling Fan', 'Study Desk', 'Wi-Fi'],
        status: RoomOperationalStatus.ACTIVE,
        beds,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        hostelRooms: [...this.state.hostelRooms, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'HostelRooms',
        target_record_id: roomId,
        description: `Created room ${record.room_number} (${record.room_type}, capacity ${record.capacity}) in ${block.block_name}.`,
      });

      return record;
    },

    updateRoomStatus: async (
      roomId: string,
      status: RoomOperationalStatus,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelRoomRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelInventory');
      const idx = this.state.hostelRooms.findIndex((r) => r.room_id === roomId);
      if (idx === -1) throw new Error(`Room '${roomId}' not found.`);

      const room = this.state.hostelRooms[idx];
      const updatedBeds = room.beds.map((b) => {
        if (status === RoomOperationalStatus.UNDER_MAINTENANCE && b.status === BedOccupancyStatus.AVAILABLE) {
          return { ...b, status: BedOccupancyStatus.MAINTENANCE };
        }
        if (status === RoomOperationalStatus.ACTIVE && b.status === BedOccupancyStatus.MAINTENANCE) {
          return { ...b, status: BedOccupancyStatus.AVAILABLE };
        }
        return b;
      });

      const updated: HostelRoomRecord = {
        ...room,
        status,
        beds: updatedBeds,
        updated_at: new Date().toISOString(),
      };

      const nextRooms = [...this.state.hostelRooms];
      nextRooms[idx] = updated;

      this.saveState({
        ...this.state,
        hostelRooms: nextRooms,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelRooms',
        target_record_id: roomId,
        description: `Updated status of room ${room.room_number} in ${room.block_name} to ${status}.`,
      });

      return updated;
    },

    getBedInventory: async (
      filters?: { block_id?: string; room_id?: string; status?: BedOccupancyStatus },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ bed: HostelBedRecord; room: HostelRoomRecord }[]> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelInventory');
      const result: { bed: HostelBedRecord; room: HostelRoomRecord }[] = [];
      for (const room of this.state.hostelRooms) {
        if (filters?.block_id && room.block_id !== filters.block_id) continue;
        if (filters?.room_id && room.room_id !== filters.room_id) continue;
        for (const bed of room.beds) {
          if (filters?.status && bed.status !== filters.status) continue;
          result.push({ bed, room });
        }
      }
      return result;
    },

    // 2. Student Allocations & Movement
    getAllocations: async (
      filters?: { student_id?: string; block_id?: string; room_id?: string; status?: HostelAllocationLifecycleStatus; academic_year?: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord[]> => {
      if (!actor || !actor.userId || !actor.role) {
        throw new Error('Unauthorized: Authentication required to access hostel allocations.');
      }

      if (actor.role === AuthRole.STUDENT) {
        if (!filters?.student_id) {
          throw new Error('Unauthorized: Students cannot view the complete institutional hostel allocation registry.');
        }
        if (filters.student_id !== actor.userId) {
          const student = this.state.students.find((s) => s.student_id === actor.userId || s.registration_number === actor.userId);
          if (!student || student.student_id !== filters.student_id) {
            throw new Error('Unauthorized: Students cannot view hostel allocations belonging to other students.');
          }
        }
      } else if (actor.role === AuthRole.PARENT) {
        if (!filters?.student_id) {
          throw new Error('Unauthorized: Parents cannot view the complete institutional hostel allocation registry.');
        }
        const parentRecord = this.state.parents.find(
          (p) =>
            p.parent_id === actor.userId ||
            p.email.toLowerCase() === actor.userId.toLowerCase() ||
            (actor.employeeId && p.parent_id === actor.employeeId)
        );
        const resolvedParentId = parentRecord ? parentRecord.parent_id : actor.userId;
        const link = this.state.parentStudentLinks.find(
          (l) =>
            l.parent_id === resolvedParentId &&
            (l.student_id === filters.student_id || l.student_registration_number === filters.student_id) &&
            l.status === 'ACTIVE'
        );
        if (!link) {
          throw new Error('Access Denied: No active relationship link found for this student.');
        }
      } else {
        this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelAllocations');
      }

      return this.state.hostelAllocations.filter((a) => {
        if (filters?.student_id && a.student_id !== filters.student_id) return false;
        if (filters?.block_id && a.block_id !== filters.block_id) return false;
        if (filters?.room_id && a.room_id !== filters.room_id) return false;
        if (filters?.status && a.status !== filters.status) return false;
        if (filters?.academic_year && a.academic_year !== filters.academic_year) return false;
        return true;
      });
    },

    getAllocationById: async (
      allocationId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord | null> => {
      const found = this.state.hostelAllocations.find((a) => a.allocation_id === allocationId);
      if (!found) return null;

      if (actor) {
        if (actor.role === AuthRole.STUDENT) {
          if (found.student_id !== actor.userId && found.registration_number !== actor.userId) {
            throw new Error('Unauthorized: Students cannot view hostel allocations belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === found.student_id || l.student_registration_number === found.registration_number) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
        } else {
          this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelAllocations');
        }
      }

      return { ...found };
    },

    allocateStudentBed: async (
      data: {
        student_id: string;
        bed_id: string;
        academic_year: string;
        semester?: number;
        start_date: string;
        end_date?: string;
        emergency_contact_phone?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelAllocations');

      const student = this.state.students.find(
        (s) => s.student_id === data.student_id || s.registration_number === data.student_id
      );
      if (!student) throw new Error(`Student with ID '${data.student_id}' does not exist.`);

      // Find room & bed first
      let targetRoom: HostelRoomRecord | undefined;
      let targetBed: HostelBedRecord | undefined;
      for (const room of this.state.hostelRooms) {
        const b = room.beds.find((bed) => bed.bed_id === data.bed_id);
        if (b) {
          targetRoom = room;
          targetBed = b;
          break;
        }
      }

      if (!targetRoom || !targetBed) {
        throw new Error(`Bed with ID '${data.bed_id}' not found in hostel inventory.`);
      }

      if (targetRoom.status !== RoomOperationalStatus.ACTIVE) {
        throw new Error(
          `Room Unavailable: Room '${targetRoom.room_number}' is currently ${targetRoom.status} and cannot accept student allocations.`
        );
      }

      if (targetBed.status !== BedOccupancyStatus.AVAILABLE) {
        throw new Error(
          `Bed Unavailable: Bed '${targetBed.bed_identifier}' in Room '${targetRoom.room_number}' is currently ${targetBed.status} and cannot be allocated.`
        );
      }

      // Check overlapping active allocation for student
      const activeStudentAlloc = this.state.hostelAllocations.find(
        (a) =>
          a.student_id === student.student_id &&
          [
            HostelAllocationLifecycleStatus.ALLOCATED,
            HostelAllocationLifecycleStatus.RESERVED,
            HostelAllocationLifecycleStatus.CHECKED_IN,
          ].includes(a.status)
      );
      if (activeStudentAlloc) {
        throw new Error(
          `Duplicate Active Allocation: Student '${student.registration_number}' already has an active allocation (${activeStudentAlloc.allocation_id}) in ${activeStudentAlloc.block_name} Room ${activeStudentAlloc.room_number}.`
        );
      }

      // Gender compatibility verification
      const block = this.state.hostelBlocks.find((b) => b.block_id === targetRoom!.block_id);
      if (block) {
        if (block.gender_type === HostelGenderType.BOYS && student.gender && student.gender.toUpperCase() === 'FEMALE') {
          throw new Error(
            `Gender Incompatibility: Female student '${student.registration_number}' cannot be allocated to Boys hostel block '${block.block_name}'.`
          );
        }
        if (block.gender_type === HostelGenderType.GIRLS && student.gender && student.gender.toUpperCase() === 'MALE') {
          throw new Error(
            `Gender Incompatibility: Male student '${student.registration_number}' cannot be allocated to Girls hostel block '${block.block_name}'.`
          );
        }
      }

      const newSeq = this.state.hostelAllocations.length + 1;
      const allocationId = `HST-2026-${String(newSeq).padStart(3, '0')}`;

      const allocationRecord: HostelAllocationRecord = {
        allocation_id: allocationId,
        student_id: student.student_id,
        registration_number: student.registration_number,
        student_name: `${student.first_name} ${student.last_name}`,
        block_id: targetRoom.block_id,
        block_name: targetRoom.block_name,
        room_id: targetRoom.room_id,
        room_number: targetRoom.room_number,
        bed_id: targetBed.bed_id,
        bed_identifier: targetBed.bed_identifier,
        academic_year: data.academic_year || '2026-2027',
        semester: data.semester || 3,
        start_date: data.start_date || new Date().toISOString().split('T')[0],
        end_date: data.end_date,
        status: HostelAllocationLifecycleStatus.ALLOCATED,
        allocated_by: actor?.userId || 'hosteloffice',
        allocated_at: new Date().toISOString(),
        emergency_contact_phone: data.emergency_contact_phone || student.personal_phone || '+1 (555) 000-0000',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Update bed status to OCCUPIED and link allocation
      const updatedRooms = this.state.hostelRooms.map((r) => {
        if (r.room_id === targetRoom!.room_id) {
          return {
            ...r,
            beds: r.beds.map((b) =>
              b.bed_id === targetBed!.bed_id
                ? { ...b, status: BedOccupancyStatus.OCCUPIED, current_allocation_id: allocationId }
                : b
            ),
          };
        }
        return r;
      });

      // Compatibility entry for worksheet 14
      const compatHostel: HostelRecord = {
        allocation_id: allocationId,
        student_id: student.student_id,
        registration_number: student.registration_number,
        hostel_block_name: targetRoom.block_name,
        room_number: targetRoom.room_number,
        bed_identifier: targetBed.bed_identifier,
        status: HostelAllocationStatus.OCCUPIED,
        check_in_date: allocationRecord.start_date,
        allocated_by_employee_id: actor?.employeeId || 'EMP-003',
        approved_by_office_id: 'PO-006',
        emergency_contact_phone: allocationRecord.emergency_contact_phone,
        created_at: allocationRecord.created_at,
      };

      this.saveState({
        ...this.state,
        hostelRooms: updatedRooms,
        hostelAllocations: [...this.state.hostelAllocations, allocationRecord],
        hostel: [...this.state.hostel, compatHostel],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'HostelAllocations',
        target_record_id: allocationId,
        description: `Allocated bed ${targetBed.bed_identifier} in ${targetRoom.block_name} Room ${targetRoom.room_number} to student ${student.registration_number}.`,
      });

      return allocationRecord;
    },

    transferStudentBed: async (
      allocationId: string,
      newBedId: string,
      reason: string,
      effectiveDate: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelAllocations');

      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Transfer reason is required.');
      }
      if (!effectiveDate) {
        throw new Error('Validation Error: Effective transfer date is required.');
      }

      const allocIdx = this.state.hostelAllocations.findIndex((a) => a.allocation_id === allocationId);
      if (allocIdx === -1) throw new Error(`Hostel allocation '${allocationId}' not found.`);
      const currentAlloc = this.state.hostelAllocations[allocIdx];

      if (
        ![HostelAllocationLifecycleStatus.ALLOCATED, HostelAllocationLifecycleStatus.CHECKED_IN].includes(
          currentAlloc.status
        )
      ) {
        throw new Error(`Cannot transfer student with allocation status '${currentAlloc.status}'.`);
      }

      // Find new room and bed
      let newRoom: HostelRoomRecord | undefined;
      let newBed: HostelBedRecord | undefined;
      for (const room of this.state.hostelRooms) {
        const b = room.beds.find((bed) => bed.bed_id === newBedId);
        if (b) {
          newRoom = room;
          newBed = b;
          break;
        }
      }

      if (!newRoom || !newBed) {
        throw new Error(`Target bed '${newBedId}' does not exist.`);
      }
      if (newRoom.status !== RoomOperationalStatus.ACTIVE) {
        throw new Error(`Target room '${newRoom.room_number}' is ${newRoom.status} and cannot accept transfers.`);
      }
      if (newBed.status !== BedOccupancyStatus.AVAILABLE) {
        throw new Error(`Target bed '${newBed.bed_identifier}' is currently ${newBed.status} and not available.`);
      }

      // Record transfer movement
      const movement: AllocationMovementRecord = {
        movement_id: `MOV-${Date.now()}`,
        previous_room_id: currentAlloc.room_id,
        previous_room_number: currentAlloc.room_number,
        previous_bed_identifier: currentAlloc.bed_identifier,
        new_room_id: newRoom.room_id,
        new_room_number: newRoom.room_number,
        new_bed_identifier: newBed.bed_identifier,
        reason: reason.trim(),
        effective_date: effectiveDate,
        transferred_by: actor?.userId || 'hosteloffice',
        timestamp: new Date().toISOString(),
      };

      const history = currentAlloc.transfer_history || [];
      const updatedAlloc: HostelAllocationRecord = {
        ...currentAlloc,
        block_id: newRoom.block_id,
        block_name: newRoom.block_name,
        room_id: newRoom.room_id,
        room_number: newRoom.room_number,
        bed_id: newBed.bed_id,
        bed_identifier: newBed.bed_identifier,
        status: HostelAllocationLifecycleStatus.TRANSFERRED,
        transfer_history: [...history, movement],
        updated_at: new Date().toISOString(),
      };

      // Free old bed, occupy new bed
      const updatedRooms = this.state.hostelRooms.map((r) => {
        let changed = false;
        const beds = r.beds.map((b) => {
          if (b.bed_id === currentAlloc.bed_id) {
            changed = true;
            return { ...b, status: BedOccupancyStatus.AVAILABLE, current_allocation_id: undefined };
          }
          if (b.bed_id === newBed!.bed_id) {
            changed = true;
            return { ...b, status: BedOccupancyStatus.OCCUPIED, current_allocation_id: allocationId };
          }
          return b;
        });
        return changed ? { ...r, beds } : r;
      });

      const nextAllocs = [...this.state.hostelAllocations];
      nextAllocs[allocIdx] = updatedAlloc;

      const nextCompatHostel = this.state.hostel.map((h) => {
        if (h.allocation_id === allocationId) {
          return {
            ...h,
            hostel_block_name: newRoom.block_name,
            room_number: newRoom.room_number,
            bed_identifier: newBed.bed_identifier,
          };
        }
        return h;
      });

      this.saveState({
        ...this.state,
        hostelRooms: updatedRooms,
        hostelAllocations: nextAllocs,
        hostel: nextCompatHostel,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelAllocations',
        target_record_id: allocationId,
        description: `Transferred student ${currentAlloc.registration_number} from Room ${currentAlloc.room_number} (${currentAlloc.bed_identifier}) to Room ${newRoom.room_number} (${newBed.bed_identifier}). Reason: ${reason}`,
      });

      return updatedAlloc;
    },

    checkInStudent: async (
      allocationId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelAllocations');

      const allocIdx = this.state.hostelAllocations.findIndex((a) => a.allocation_id === allocationId);
      if (allocIdx === -1) throw new Error(`Hostel allocation '${allocationId}' not found.`);

      const current = this.state.hostelAllocations[allocIdx];
      if (current.status !== HostelAllocationLifecycleStatus.ALLOCATED && current.status !== HostelAllocationLifecycleStatus.RESERVED && current.status !== HostelAllocationLifecycleStatus.TRANSFERRED) {
        throw new Error(`Cannot check in student with status '${current.status}'.`);
      }

      const updated: HostelAllocationRecord = {
        ...current,
        status: HostelAllocationLifecycleStatus.CHECKED_IN,
        checked_in_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      const nextAllocs = [...this.state.hostelAllocations];
      nextAllocs[allocIdx] = updated;

      // Ensure bed is occupied
      const updatedRooms = this.state.hostelRooms.map((r) => {
        if (r.room_id === current.room_id) {
          return {
            ...r,
            beds: r.beds.map((b) =>
              b.bed_id === current.bed_id
                ? { ...b, status: BedOccupancyStatus.OCCUPIED, current_allocation_id: allocationId }
                : b
            ),
          };
        }
        return r;
      });

      const nextCompatHostel = this.state.hostel.map((h) => {
        if (h.allocation_id === allocationId) {
          return {
            ...h,
            status: HostelAllocationStatus.OCCUPIED,
            check_in_date: new Date().toISOString().split('T')[0],
          };
        }
        return h;
      });

      this.saveState({
        ...this.state,
        hostelRooms: updatedRooms,
        hostelAllocations: nextAllocs,
        hostel: nextCompatHostel,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelAllocations',
        target_record_id: allocationId,
        description: `Checked in student ${current.registration_number} to Room ${current.room_number} (${current.bed_identifier}).`,
      });

      return updated;
    },

    checkOutStudent: async (
      allocationId: string,
      conditionOrReason?: string,
      remarks?: string,
      actor?: any
    ): Promise<HostelAllocationRecord> => {
      const actorObj = (remarks && typeof remarks === 'object') ? remarks : (actor && typeof actor === 'object') ? actor : undefined;
      const effectiveReason = typeof remarks === 'string' && remarks.trim()
        ? `${conditionOrReason || 'Checkout'}: ${remarks}`
        : (conditionOrReason || 'Normal Completion');

      this.verifyHostelAccess(actorObj, PermissionScope.WRITE, 'HostelAllocations');

      const allocIdx = this.state.hostelAllocations.findIndex((a) => a.allocation_id === allocationId);
      if (allocIdx === -1) throw new Error(`Hostel allocation '${allocationId}' not found.`);

      const current = this.state.hostelAllocations[allocIdx];
      if (current.status !== HostelAllocationLifecycleStatus.CHECKED_IN && current.status !== HostelAllocationLifecycleStatus.TRANSFERRED) {
        throw new Error(`Cannot check out student with status '${current.status}'. Must be checked in.`);
      }

      const updated: HostelAllocationRecord = {
        ...current,
        status: HostelAllocationLifecycleStatus.CHECKED_OUT,
        checked_out_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Free bed
      const updatedRooms = this.state.hostelRooms.map((r) => {
        if (r.room_id === current.room_id) {
          return {
            ...r,
            beds: r.beds.map((b) =>
              b.bed_id === current.bed_id
                ? { ...b, status: BedOccupancyStatus.AVAILABLE, current_allocation_id: undefined }
                : b
            ),
          };
        }
        return r;
      });

      const nextAllocs = [...this.state.hostelAllocations];
      nextAllocs[allocIdx] = updated;

      const nextCompatHostel = this.state.hostel.map((h) => {
        if (h.allocation_id === allocationId) {
          return {
            ...h,
            status: HostelAllocationStatus.VACATED,
          };
        }
        return h;
      });

      this.saveState({
        ...this.state,
        hostelRooms: updatedRooms,
        hostelAllocations: nextAllocs,
        hostel: nextCompatHostel,
      });

      await this.audit.log({
        actor_id: actorObj?.userId || 'hosteloffice',
        actor_role: actorObj?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelAllocations',
        target_record_id: allocationId,
        description: `Checked out student ${current.registration_number} from Room ${current.room_number}. Reason: ${effectiveReason}`,
      });

      return updated;
    },

    cancelAllocation: async (
      allocationId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelAllocations');
      if (!reason || !reason.trim()) {
        throw new Error('Validation Error: Cancellation reason is required.');
      }

      const allocIdx = this.state.hostelAllocations.findIndex((a) => a.allocation_id === allocationId);
      if (allocIdx === -1) throw new Error(`Hostel allocation '${allocationId}' not found.`);

      const current = this.state.hostelAllocations[allocIdx];
      const updated: HostelAllocationRecord = {
        ...current,
        status: HostelAllocationLifecycleStatus.CANCELLED,
        cancellation_reason: reason.trim(),
        cancelled_by: actor?.userId || 'hosteloffice',
        cancelled_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      // Free bed
      const updatedRooms = this.state.hostelRooms.map((r) => {
        if (r.room_id === current.room_id) {
          return {
            ...r,
            beds: r.beds.map((b) =>
              b.bed_id === current.bed_id
                ? { ...b, status: BedOccupancyStatus.AVAILABLE, current_allocation_id: undefined }
                : b
            ),
          };
        }
        return r;
      });

      const nextAllocs = [...this.state.hostelAllocations];
      nextAllocs[allocIdx] = updated;

      const nextCompatHostel = this.state.hostel.map((h) => {
        if (h.allocation_id === allocationId) {
          return {
            ...h,
            status: HostelAllocationStatus.VACATED,
          };
        }
        return h;
      });

      this.saveState({
        ...this.state,
        hostelRooms: updatedRooms,
        hostelAllocations: nextAllocs,
        hostel: nextCompatHostel,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.UPDATE,
        target_worksheet: 'HostelAllocations',
        target_record_id: allocationId,
        description: `Cancelled hostel allocation ${allocationId}. Reason: ${reason}`,
      });

      return updated;
    },

    // 3. Hostel Charges & Requests
    requestHostelCharge: async (
      data: {
        allocation_id: string;
        billing_period: string;
        amount: number;
        description: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelChargeRequestRecord> => {
      this.verifyHostelAccess(actor, PermissionScope.WRITE, 'HostelCharges');

      if (typeof data.amount !== 'number' || data.amount <= 0) {
        throw new Error('Validation Error: Charge request amount must be a positive number.');
      }
      if (!data.billing_period || !data.billing_period.trim()) {
        throw new Error('Validation Error: Billing period is required.');
      }

      const allocation = this.state.hostelAllocations.find((a) => a.allocation_id === data.allocation_id);
      if (!allocation) throw new Error(`Hostel allocation '${data.allocation_id}' does not exist.`);

      // Duplicate billing prevention for same allocation and billing period
      const existing = this.state.hostelCharges.find(
        (c) =>
          c.allocation_id === data.allocation_id &&
          c.billing_period.toLowerCase() === data.billing_period.trim().toLowerCase() &&
          c.status !== HostelChargeStatus.REJECTED
      );
      if (existing) {
        throw new Error(
          `Duplicate Charge Request: A hostel charge request (${existing.charge_request_id}) for period '${data.billing_period}' already exists for this allocation.`
        );
      }

      const newSeq = this.state.hostelCharges.length + 1;
      const chargeId = `HCR-2026-${String(newSeq).padStart(4, '0')}`;

      const record: HostelChargeRequestRecord = {
        charge_request_id: chargeId,
        allocation_id: allocation.allocation_id,
        student_id: allocation.student_id,
        registration_number: allocation.registration_number,
        student_name: allocation.student_name,
        billing_period: data.billing_period.trim(),
        fee_category: 'HOSTEL',
        amount: this.roundCurrencyAmount(data.amount),
        description: data.description.trim() || `Hostel accommodation dues for ${data.billing_period}`,
        requested_by: actor?.userId || 'hosteloffice',
        requested_at: new Date().toISOString(),
        status: HostelChargeStatus.REQUESTED,
        created_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        hostelCharges: [...this.state.hostelCharges, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'hosteloffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.CREATE,
        target_worksheet: 'HostelCharges',
        target_record_id: chargeId,
        description: `Requested hostel fee charge ${chargeId} of $${record.amount} for ${allocation.student_name} (${data.billing_period}).`,
      });

      return record;
    },

    getChargeRequests: async (
      filters?: { allocation_id?: string; student_id?: string; status?: HostelChargeStatus },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelChargeRequestRecord[]> => {
      // Accessible by Hostel and Finance
      if (actor && actor.role !== AuthRole.SUPER_ADMIN && actor.userId !== 'admin') {
        try {
          this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelCharges');
        } catch {
          this.verifyFinanceAccess(actor, PermissionScope.READ, 'Invoicing');
        }
      }

      return this.state.hostelCharges.filter((c) => {
        if (filters?.allocation_id && c.allocation_id !== filters.allocation_id) return false;
        if (filters?.student_id && c.student_id !== filters.student_id) return false;
        if (filters?.status && c.status !== filters.status) return false;
        return true;
      });
    },

    // 4. Dashboard Metrics & Student Details
    getHostelDashboardMetrics: async (
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelDashboardMetrics> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelReports');

      const totalRoomsCount = this.state.hostelRooms.length;
      let totalBedsCount = 0;
      let availableBedsCount = 0;
      let occupiedBedsCount = 0;

      for (const room of this.state.hostelRooms) {
        for (const bed of room.beds) {
          totalBedsCount++;
          if (bed.status === BedOccupancyStatus.AVAILABLE) availableBedsCount++;
          else if (bed.status === BedOccupancyStatus.OCCUPIED) occupiedBedsCount++;
        }
      }

      const occupancyRate = totalBedsCount > 0 ? this.roundCurrencyAmount((occupiedBedsCount / totalBedsCount) * 100) : 0;
      const currentActiveAllocationsCount = this.state.hostelAllocations.filter(
        (a) =>
          a.status === HostelAllocationLifecycleStatus.ALLOCATED ||
          a.status === HostelAllocationLifecycleStatus.CHECKED_IN
      ).length;

      const pendingCheckInsCount = this.state.hostelAllocations.filter(
        (a) => a.status === HostelAllocationLifecycleStatus.ALLOCATED
      ).length;
      const checkedInCount = this.state.hostelAllocations.filter(
        (a) => a.status === HostelAllocationLifecycleStatus.CHECKED_IN
      ).length;
      const roomsUnderMaintenanceCount = this.state.hostelRooms.filter(
        (r) => r.status === RoomOperationalStatus.UNDER_MAINTENANCE
      ).length;
      const unbilledChargesCount = this.state.hostelCharges.filter(
        (c) => c.status === HostelChargeStatus.REQUESTED
      ).length;

      return {
        totalRoomsCount,
        totalBedsCount,
        availableBedsCount,
        occupiedBedsCount,
        occupancyRate,
        currentActiveAllocationsCount,
        pendingCheckInsCount,
        checkedInCount,
        roomsUnderMaintenanceCount,
        unbilledChargesCount,
        totalBedCapacity: totalBedsCount,
        occupiedBeds: occupiedBedsCount,
        vacantBeds: availableBedsCount,
        pendingCheckIns: pendingCheckInsCount,
      };
    },

    getStudentHostelDetails: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentHostelDetails> => {
      const student = this.state.students.find(
        (s) => s.student_id === studentId || s.registration_number === studentId
      );
      if (!student) throw new Error(`Student '${studentId}' does not exist.`);

      // Isolation check: require valid authentication
      if (!actor || !actor.userId || !actor.role) {
        throw new Error('Unauthorized: Authentication required to view student hostel details.');
      }

      if (actor.role === AuthRole.STUDENT) {
        if (actor.userId !== student.student_id && actor.userId !== student.registration_number) {
          throw new Error('Unauthorized: Students cannot view hostel allocations belonging to other students.');
        }
      } else if (actor.role === AuthRole.PARENT) {
        const parentRecord = this.state.parents.find(
          (p) =>
            p.parent_id === actor.userId ||
            p.email.toLowerCase() === actor.userId.toLowerCase() ||
            (actor.employeeId && p.parent_id === actor.employeeId)
        );
        const resolvedParentId = parentRecord ? parentRecord.parent_id : actor.userId;
        const link = this.state.parentStudentLinks.find(
          (l) =>
            l.parent_id === resolvedParentId &&
            (l.student_id === student.student_id || l.student_registration_number === student.registration_number) &&
            l.status === 'ACTIVE'
        );
        if (!link) {
          throw new Error('Access Denied: No active relationship link found for this student.');
        }
      } else if (actor.role !== AuthRole.SUPER_ADMIN && actor.userId !== 'admin') {
        this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelAllocations');
      }

      const allocations = this.state.hostelAllocations.filter((a) => a.student_id === student.student_id);
      const currentAllocation =
        allocations.find((a) =>
          [
            HostelAllocationLifecycleStatus.ALLOCATED,
            HostelAllocationLifecycleStatus.CHECKED_IN,
            HostelAllocationLifecycleStatus.TRANSFERRED,
          ].includes(a.status)
        ) || null;

      const historicalAllocations = allocations.filter((a) => a !== currentAllocation);
      const chargeRequests = this.state.hostelCharges.filter((c) => c.student_id === student.student_id);

      const room = currentAllocation
        ? this.state.hostelRooms.find((r) => r.room_id === currentAllocation.room_id) || null
        : null;
      const roommates = currentAllocation
        ? this.state.hostelAllocations.filter(
            (a) =>
              a.room_id === currentAllocation.room_id &&
              a.allocation_id !== currentAllocation.allocation_id &&
              (a.status === HostelAllocationLifecycleStatus.ALLOCATED ||
                a.status === HostelAllocationLifecycleStatus.CHECKED_IN)
          )
        : [];
      const movementHistory = currentAllocation?.transfer_history || [];

      return {
        student,
        currentAllocation,
        historicalAllocations,
        chargeRequests,
        room,
        roommates,
        movementHistory,
      };
    },

    // Backward compatibility methods
    getByStudent: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelRecord[]> => {
      if (actor) {
        const student = this.state.students.find(
          (s) => s.student_id === studentId || s.registration_number === studentId
        );
        if (actor.role === AuthRole.STUDENT) {
          const isSelf =
            actor.userId === studentId ||
            (student && (actor.userId === student.student_id || actor.userId === student.registration_number));
          if (!isSelf) {
            throw new Error('Unauthorized: Students cannot view hostel records belonging to other students.');
          }
        } else if (actor.role === AuthRole.PARENT) {
          const link = this.state.parentStudentLinks.find(
            (l) =>
              (l.parent_id === actor.userId || l.parent_id === actor.employeeId) &&
              (l.student_id === studentId ||
                l.student_registration_number === studentId ||
                (student && (l.student_id === student.student_id || l.student_registration_number === student.registration_number))) &&
              l.status === 'ACTIVE'
          );
          if (!link) {
            throw new Error('Access Denied: No active relationship link found for this student.');
          }
        }
      }

      const baseRecords = this.state.hostel.filter(
        (h) => h.student_id === studentId || h.registration_number === studentId
      );
      const studentAlloc = this.state.hostelAllocations.find(
        (a) =>
          (a.student_id === studentId || a.registration_number === studentId) &&
          (a.status === HostelAllocationLifecycleStatus.ALLOCATED ||
            a.status === HostelAllocationLifecycleStatus.CHECKED_IN)
      );
      const studentRoom = studentAlloc
        ? this.state.hostelRooms.find((r) => r.room_id === studentAlloc.room_id) || null
        : null;
      return Object.assign(baseRecords, {
        currentAllocation: studentAlloc || null,
        room: studentRoom || null,
      });
    },

    getAllAllocations: async (
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord[]> => {
      this.verifyHostelAccess(actor, PermissionScope.READ, 'HostelAllocations');
      return [...this.state.hostelAllocations];
    },

    allocate: async (
      data: any,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<HostelAllocationRecord> => {
      return this.hostel.allocateStudentBed(data, actor);
    },

    allocateBed: async (data: any, actor?: any) => {
      let bedId = data.bed_id;
      if (!bedId && data.room_id && data.bed_identifier) {
        const r = this.state.hostelRooms.find((rm) => rm.room_id === data.room_id);
        const b = r?.beds.find((bd) => bd.bed_identifier === data.bed_identifier);
        bedId = b?.bed_id;
      }
      return this.hostel.allocateStudentBed(
        {
          student_id: data.student_id,
          bed_id: bedId,
          academic_year: data.academic_year || '2026-2027',
          semester: data.semester,
          start_date: data.start_date || new Date().toISOString().split('T')[0],
          emergency_contact_phone: data.emergency_contact_phone,
        },
        actor
      );
    },

    transferRoom: async (
      allocationId: string,
      newRoomIdOrBedId: string,
      targetBedOrReason?: string,
      reason?: string,
      actor?: any
    ) => {
      let targetBedId = newRoomIdOrBedId;
      let effectiveReason = reason || targetBedOrReason || 'Room transfer';
      if (targetBedOrReason && reason) {
        const r = this.state.hostelRooms.find((rm) => rm.room_id === newRoomIdOrBedId);
        const b = r?.beds.find((bd) => bd.bed_identifier === targetBedOrReason);
        if (b) targetBedId = b.bed_id;
      }
      return this.hostel.transferStudentBed(
        allocationId,
        targetBedId,
        effectiveReason,
        new Date().toISOString().split('T')[0],
        actor
      );
    },

    createChargeRequest: async (data: any, actor?: any) => {
      const existing = this.state.hostelAllocations.find((a) => a.allocation_id === data.allocation_id);
      if (!existing && data.allocation_id) {
        const newAlloc: HostelAllocationRecord = {
          allocation_id: data.allocation_id,
          student_id: data.student_id || 'STU-001',
          registration_number: data.registration_number || 'EIT-STU-2026-CSE-0001',
          student_name: data.student_name || 'Resident Student',
          block_id: 'HST-BLK-A',
          block_name: 'Block A - Aryabhata Hall',
          room_id: data.room_id || 'HST-RM-A-101',
          room_number: '101',
          bed_id: data.bed_id || 'BED-A-101-A',
          bed_identifier: 'A',
          academic_year: '2026-2027',
          semester: 3,
          start_date: new Date().toISOString().split('T')[0],
          status: HostelAllocationLifecycleStatus.ALLOCATED,
          allocated_by: 'hosteloffice',
          allocated_at: new Date().toISOString(),
          emergency_contact_phone: '+91 98401 54321',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        this.state.hostelAllocations.push(newAlloc);
      }
      return this.hostel.requestHostelCharge(
        {
          allocation_id: data.allocation_id,
          billing_period: data.billing_period || '2026-2027-SEM3',
          amount: data.amount,
          description: data.description,
        },
        actor
      );
    },

    requestCharge: async (data: any, actor?: any) => this.hostel.requestHostelCharge(data, actor),

    getCharges: async (filters?: any, actor?: any) => this.hostel.getChargeRequests(filters, actor),
  };

  // ---------------------------------------------------------------------------
  // AUDIT
  // ---------------------------------------------------------------------------
  public audit = {
    getAll: async () => {
      return [...this.state.auditLogs].reverse();
    },
    getRecent: async () => {
      return [...this.state.auditLogs].reverse();
    },
    log: async (entry: Omit<AuditLogRecord, 'log_id' | 'timestamp'>) => {
      const record: AuditLogRecord = {
        ...entry,
        log_id: `LOG-${Date.now()}`,
        timestamp: new Date().toISOString(),
      };
      this.saveState({
        ...this.state,
        auditLogs: [...this.state.auditLogs, record],
      });
    },
  };

  // ---------------------------------------------------------------------------
  // CONTROLLER OF EXAMINATIONS (COE) OFFICE (Phase 8)
  // ---------------------------------------------------------------------------
  public coe = {
    // 1. Sessions
    getSessions: async (actor?: { userId: string; role: string; employeeId?: string }): Promise<ExamSessionRecord[]> => {
      this.verifyCoeAccess(actor, PermissionScope.READ);
      return [...this.state.examSessions];
    },

    createSession: async (
      data: Omit<ExamSessionRecord, 'session_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamSessionRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      if (!data.session_name || !data.academic_year || !data.start_date || !data.end_date) {
        throw new Error('Validation Error: Required session fields are missing (name, academic_year, dates).');
      }

      if (data.start_date > data.end_date) {
        throw new Error('Validation Error: End date cannot precede start date (Session start date must be before or equal to end date).');
      }

      const sessionId = `EXS-${data.academic_year.replace(/\s+/g, '')}-S${data.semester}-${Date.now().toString().slice(-4)}`;
      const record: ExamSessionRecord = {
        ...data,
        session_id: sessionId,
        status: data.status || ExamSessionStatus.UPCOMING,
        created_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        examSessions: [...this.state.examSessions, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_SESSION_CREATE,
        target_worksheet: 'ExamSessions',
        target_record_id: sessionId,
        description: `Created examination session '${record.session_name}' for ${record.academic_year} Semester ${record.semester}.`,
      });

      return record;
    },

    // 2. Schedules
    getSchedules: async (filters?: {
      session_id?: string;
      programme_code?: string;
      semester?: number;
      course_code?: string;
      status?: ExamLifecycleStatus;
    }): Promise<ExamScheduleRecord[]> => {
      let list = [...this.state.examSchedules];
      if (filters?.session_id) list = list.filter((s) => s.session_id === filters.session_id);
      if (filters?.programme_code) list = list.filter((s) => s.programme_code === filters.programme_code);
      if (filters?.semester) list = list.filter((s) => s.semester === filters.semester);
      if (filters?.course_code) list = list.filter((s) => s.course_code.toLowerCase() === filters.course_code?.toLowerCase());
      if (filters?.status) list = list.filter((s) => s.status === filters.status);
      return list;
    },

    getScheduleById: async (scheduleId: string): Promise<ExamScheduleRecord | null> => {
      const found = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      return found || null;
    },

    scheduleExam: async (
      data: Omit<ExamScheduleRecord, 'schedule_id' | 'created_at' | 'updated_at' | 'course_title' | 'marks_entry_open' | 'status'> & {
        course_title?: string;
        marks_entry_open?: boolean;
        status?: ExamLifecycleStatus;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      // Validate required fields
      const requiredFields: (keyof typeof data)[] = [
        'session_id',
        'exam_name',
        'exam_type',
        'course_code',
        'programme_code',
        'department',
        'semester',
        'exam_date',
        'start_time',
        'end_time',
        'room',
        'max_marks',
        'passing_marks',
      ];
      for (const field of requiredFields) {
        if (data[field] === undefined || data[field] === null || data[field] === '') {
          throw new Error(`Validation Error: Missing required examination field: '${field}'.`);
        }
      }

      // Validate marks
      if (data.max_marks <= 0) {
        throw new Error('Validation Error: Maximum marks must be greater than zero.');
      }
      if (data.passing_marks < 0) {
        throw new Error('Validation Error: Passing marks cannot be negative.');
      }
      if (data.passing_marks > data.max_marks) {
        throw new Error(`Validation Error: Passing marks (${data.passing_marks}) cannot exceed maximum marks (${data.max_marks}).`);
      }

      // Validate time sequence
      if (data.start_time >= data.end_time) {
        throw new Error('Validation Error: Examination start time must be strictly before end time.');
      }

      // Conflict 1: Room booking conflict detection
      const roomConflict = this.state.examSchedules.find((s) => {
        if (s.status === ExamLifecycleStatus.CANCELLED) return false;
        if (s.exam_date !== data.exam_date) return false;
        if (s.room.trim().toLowerCase() !== data.room.trim().toLowerCase()) return false;
        // Overlapping time interval: startA < endB && endA > startB
        return data.start_time < s.end_time && data.end_time > s.start_time;
      });

      if (roomConflict) {
        throw new Error(
          `Conflicting Room Booking: Room '${data.room}' is already booked on ${data.exam_date} from ${roomConflict.start_time} to ${roomConflict.end_time} for '${roomConflict.exam_name}' (${roomConflict.course_code}).`
        );
      }

      // Conflict 2: Student cohort overlap conflict detection
      const cohortConflict = this.state.examSchedules.find((s) => {
        if (s.status === ExamLifecycleStatus.CANCELLED) return false;
        if (s.exam_date !== data.exam_date) return false;
        if (s.programme_code !== data.programme_code || s.semester !== data.semester) return false;
        const sectionMatch =
          !s.section ||
          !data.section ||
          s.section === 'ALL' ||
          data.section === 'ALL' ||
          s.section === data.section;
        if (!sectionMatch) return false;
        return data.start_time < s.end_time && data.end_time > s.start_time;
      });

      if (cohortConflict) {
        throw new Error(
          `Conflicting Schedule for Cohort: Students in ${data.programme_code} Semester ${data.semester} (Section ${data.section || 'ALL'}) already have examination '${cohortConflict.exam_name}' (${cohortConflict.course_code}) on ${data.exam_date} from ${cohortConflict.start_time} to ${cohortConflict.end_time}.`
        );
      }

      // Compute duration if not provided
      let duration = data.duration_minutes;
      if (!duration) {
        const [sh, sm] = data.start_time.split(':').map(Number);
        const [eh, em] = data.end_time.split(':').map(Number);
        duration = (eh * 60 + em) - (sh * 60 + sm);
      }

      // Retrieve course title if omitted
      let courseTitle = data.course_title;
      if (!courseTitle) {
        const crs = this.state.courses.find((c) => c.course_code === data.course_code);
        courseTitle = crs?.course_title || data.course_code;
      }

      const scheduleId = `EXSCH-2026-${data.course_code}-${Date.now().toString().slice(-4)}`;
      const nowIso = new Date().toISOString();

      const record: ExamScheduleRecord = {
        ...data,
        course_title: courseTitle,
        schedule_id: scheduleId,
        duration_minutes: duration,
        marks_entry_open: false,
        status: ExamLifecycleStatus.SCHEDULED,
        created_at: nowIso,
        updated_at: nowIso,
      };

      this.saveState({
        ...this.state,
        examSchedules: [...this.state.examSchedules, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_SCHEDULE_CREATE,
        target_worksheet: 'ExamSchedules',
        target_record_id: scheduleId,
        description: `Scheduled examination '${record.exam_name}' (${record.course_code}) on ${record.exam_date} in room ${record.room}.`,
      });

      return record;
    },

    updateSchedule: async (
      scheduleId: string,
      updates: Partial<Omit<ExamScheduleRecord, 'schedule_id' | 'created_at'>>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Conflict checks if date/times/room modified
      const newDate = updates.exam_date || schedule.exam_date;
      const newStart = updates.start_time || schedule.start_time;
      const newEnd = updates.end_time || schedule.end_time;
      const newRoom = updates.room || schedule.room;

      if (updates.exam_date || updates.start_time || updates.end_time || updates.room) {
        const roomConflict = this.state.examSchedules.find((s) => {
          if (s.schedule_id === scheduleId || s.status === ExamLifecycleStatus.CANCELLED) return false;
          if (s.exam_date !== newDate) return false;
          if (s.room.trim().toLowerCase() !== newRoom.trim().toLowerCase()) return false;
          return newStart < s.end_time && newEnd > s.start_time;
        });
        if (roomConflict) {
          throw new Error(
            `Conflicting Room Booking: Room '${newRoom}' is already booked on ${newDate} from ${roomConflict.start_time} to ${roomConflict.end_time} for '${roomConflict.exam_name}'.`
          );
        }
      }

      const updatedRecord: ExamScheduleRecord = {
        ...schedule,
        ...updates,
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.map((s) => (s.schedule_id === scheduleId ? updatedRecord : s)),
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_SCHEDULE_UPDATE,
        target_worksheet: 'ExamSchedules',
        target_record_id: scheduleId,
        description: `Updated examination schedule '${scheduleId}'.`,
      });

      return updatedRecord;
    },

    cancelSchedule: async (
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      const updatedRecord: ExamScheduleRecord = {
        ...schedule,
        status: ExamLifecycleStatus.CANCELLED,
        notes: reason ? `Cancelled: ${reason}` : schedule.notes,
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.map((s) => (s.schedule_id === scheduleId ? updatedRecord : s)),
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_SCHEDULE_CANCEL,
        target_worksheet: 'ExamSchedules',
        target_record_id: scheduleId,
        description: `Cancelled examination schedule '${scheduleId}'. Reason: ${reason}`,
      });

      return updatedRecord;
    },

    deleteSchedule: async (
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<void> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      const hasAttendance = this.state.examAttendance.some((a) => a.schedule_id === scheduleId);
      const hasMarks = this.state.examResults.some((r) => r.schedule_id === scheduleId);

      if (hasAttendance || hasMarks) {
        throw new Error(
          'Cannot delete examination record that already has attendance records, marks entries, or published results. Use cancellation or appropriate status changes instead.'
        );
      }

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.filter((s) => s.schedule_id !== scheduleId),
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.DELETE,
        target_worksheet: 'ExamSchedules',
        target_record_id: scheduleId,
        description: `Deleted empty examination schedule '${scheduleId}'.`,
      });
    },

    setMarksEntryWindow: async (
      scheduleId: string,
      isOpen: boolean,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      let newStatus = schedule.status;
      if (isOpen && schedule.status === ExamLifecycleStatus.SCHEDULED) {
        newStatus = ExamLifecycleStatus.MARKS_ENTRY_OPEN;
      }

      const updatedRecord: ExamScheduleRecord = {
        ...schedule,
        marks_entry_open: isOpen,
        status: newStatus,
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.map((s) => (s.schedule_id === scheduleId ? updatedRecord : s)),
      });

      return updatedRecord;
    },

    // 3. Eligibility & Attendance
    checkEligibility: async (
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentEligibilityDetail[]> => {
      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Verify faculty access for course
      if (actor && actor.role === AuthRole.FACULTY) {
        this.verifyFacultyExamCourseAccess(schedule.course_code, schedule.section, actor);
      }

      // Find all enrolments matching course code and section
      const enrolments = this.state.enrolments.filter(
        (e) =>
          e.course_code === schedule.course_code &&
          (!schedule.section || schedule.section === 'ALL' || e.section === schedule.section)
      );

      return enrolments.map((e) => {
        // Attendance check
        const courseAtts = this.state.attendance.filter(
          (a) => a.student_id === e.student_id && a.course_code === schedule.course_code
        );
        const presentCount = courseAtts.filter((a) => a.status === AttendanceStatus.PRESENT).length;
        const attPct = courseAtts.length > 0 ? Math.round((presentCount / courseAtts.length) * 100) : 85;

        // Finance check
        const studentInvoices = this.state.finance.filter((f) => f.student_id === e.student_id);
        const hasOverdue = studentInvoices.some((f) => f.payment_status === PaymentStatus.OVERDUE);
        const feeCleared = !hasOverdue;

        const ineligibility_reasons: string[] = [];
        if (attPct < 75 && schedule.exam_type !== ExamType.SUPPLEMENTARY) {
          ineligibility_reasons.push(`Attendance of ${attPct}% is below the mandatory 75% threshold (demonstration rule).`);
        }
        if (!feeCleared && schedule.exam_type !== ExamType.SUPPLEMENTARY) {
          ineligibility_reasons.push('Outstanding overdue financial fee dues require clearance from Finance Office.');
        }
        if (e.enrolment_status !== 'ACTIVE') {
          ineligibility_reasons.push(`Enrolment status is '${e.enrolment_status}'.`);
        }

        const isEligible = ineligibility_reasons.length === 0 || schedule.exam_type === ExamType.SUPPLEMENTARY;

        return {
          student_id: e.student_id,
          registration_number: e.student_registration_number,
          name: e.student_name,
          course_code: schedule.course_code,
          section: e.section,
          is_eligible: isEligible,
          ineligibility_reasons,
          attendance_percentage: attPct,
          fee_clearance: feeCleared,
          enrolment_status: e.enrolment_status,
          is_supplementary_exempted: schedule.exam_type === ExamType.SUPPLEMENTARY,
        };
      });
    },

    getAttendance: async (
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord[]> => {
      return this.state.examAttendance.filter((a) => a.schedule_id === scheduleId);
    },

    recordAttendance: async (
      data: {
        schedule_id: string;
        student_id: string;
        status: ExamAttendanceStatus;
        remarks?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === data.schedule_id);
      if (!schedule) throw new Error(`Examination schedule '${data.schedule_id}' not found.`);

      // Duplicate check
      const existing = this.state.examAttendance.find(
        (a) => a.schedule_id === data.schedule_id && a.student_id === data.student_id
      );
      if (existing) {
        throw new Error(
          `Duplicate Attendance: Attendance for student '${data.student_id}' has already been recorded for examination '${data.schedule_id}'.`
        );
      }

      // Eligibility check
      const student = this.state.students.find(
        (s) => s.student_id === data.student_id || s.registration_number === data.student_id
      );
      if (!student) throw new Error(`Student '${data.student_id}' not found.`);

      const isSupplementary = schedule.exam_type === ExamType.SUPPLEMENTARY;
      const isExemption = Boolean(data.remarks?.toUpperCase().includes('EXEMPTION'));

      if (!isSupplementary && !isExemption) {
        const eligibilityList = await this.coe.checkEligibility(data.schedule_id);
        const elig = eligibilityList.find((e) => e.student_id === student.student_id);
        if (elig && !elig.is_eligible) {
          throw new Error(
            `Cannot record examination attendance: Student is not eligible for this examination (${elig.ineligibility_reasons.join(
              '; '
            )}).`
          );
        }
      }

      const attendanceId = `EXATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const record: ExamAttendanceEntryRecord = {
        attendance_id: attendanceId,
        schedule_id: data.schedule_id,
        student_id: student.student_id,
        student_registration_number: student.registration_number,
        student_name: `${student.first_name} ${student.last_name}`,
        status: data.status,
        marked_by: actor?.userId || 'coeoffice',
        marked_at: new Date().toISOString(),
        remarks: data.remarks,
        correction_history: [],
      };

      this.saveState({
        ...this.state,
        examAttendance: [...this.state.examAttendance, record],
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_ATTENDANCE_RECORD,
        target_worksheet: 'ExamAttendance',
        target_record_id: attendanceId,
        description: `Recorded examination attendance '${data.status}' for ${student.registration_number} in ${schedule.course_code}.`,
      });

      return record;
    },

    correctAttendance: async (
      attendanceId: string,
      revisedStatus: ExamAttendanceStatus,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      if (!reason.trim()) {
        throw new Error('Validation Error: A descriptive reason is required for correcting examination attendance.');
      }

      const rec = this.state.examAttendance.find((a) => a.attendance_id === attendanceId);
      if (!rec) throw new Error(`Attendance record '${attendanceId}' not found.`);

      const correctionEntry = {
        previous_status: rec.status,
        revised_status: revisedStatus,
        reason,
        actor_id: actor?.userId || 'coeoffice',
        timestamp: new Date().toISOString(),
      };

      const updatedRecord: ExamAttendanceEntryRecord = {
        ...rec,
        status: revisedStatus,
        correction_history: [...(rec.correction_history || []), correctionEntry],
      };

      this.saveState({
        ...this.state,
        examAttendance: this.state.examAttendance.map((a) => (a.attendance_id === attendanceId ? updatedRecord : a)),
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_ATTENDANCE_CORRECT,
        target_worksheet: 'ExamAttendance',
        target_record_id: attendanceId,
        description: `Corrected attendance from '${rec.status}' to '${revisedStatus}'. Reason: ${reason}`,
      });

      return updatedRecord;
    },

    // 4. Marks Entry & Faculty Submissions
    getMarks: async (
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]> => {
      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      if (actor && actor.role === AuthRole.FACULTY) {
        this.verifyFacultyExamCourseAccess(schedule.course_code, schedule.section, actor);
      }
      return this.state.examResults.filter((r) => r.schedule_id === scheduleId);
    },

    saveDraftMarks: async (
      scheduleId: string,
      entries: {
        student_id: string;
        internal_marks?: number;
        external_marks?: number;
        submission_notes?: string;
      }[],
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]> => {
      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Verify faculty access for course
      this.verifyFacultyExamCourseAccess(schedule.course_code, schedule.section, actor);

      // Verify window is open if called by faculty
      if (!schedule.marks_entry_open && actor?.role === AuthRole.FACULTY) {
        throw new Error('Marks entry window is closed for this examination. Contact COE Office to reopen window.');
      }

      // Verify published examination immutability
      if (schedule.status === ExamLifecycleStatus.PUBLISHED) {
        throw new Error(
          'Cannot modify marks: Examination results have already been published. Post-publication adjustments require the authorized correction workflow (correctPublishedResult).'
        );
      }

      // Verify not already locked
      if (
        [
          ExamLifecycleStatus.FACULTY_SUBMITTED,
          ExamLifecycleStatus.UNDER_COE_REVIEW,
          ExamLifecycleStatus.APPROVED,
        ].includes(schedule.status) &&
        actor?.role === AuthRole.FACULTY
      ) {
        throw new Error('Cannot modify marks: Submission has already been submitted or locked. An authorized reopening workflow is required.');
      }

      const updatedResults: ExamResultRecord[] = [];
      const currentResults = [...this.state.examResults];

      for (const entry of entries) {
        const student = this.state.students.find(
          (s) => s.student_id === entry.student_id || s.registration_number === entry.student_id
        );
        if (!student) throw new Error(`Student '${entry.student_id}' not found.`);

        const internal = entry.internal_marks ?? 0;
        const external = entry.external_marks ?? 0;

        // Range validation
        if (internal < 0 || external < 0) {
          throw new Error('Marks cannot be negative.');
        }
        if (internal > schedule.max_marks || external > schedule.max_marks) {
          throw new Error(`Marks exceed the configured maximum of ${schedule.max_marks}.`);
        }
        const total = internal + external;
        if (total > schedule.max_marks) {
          throw new Error(`Total marks (${total}) cannot exceed the examination maximum (${schedule.max_marks}).`);
        }

        const gradeInfo = this.calculateDemonstrationGrade(total, schedule.max_marks, schedule.passing_marks);

        const existingIdx = currentResults.findIndex(
          (r) => r.schedule_id === scheduleId && r.student_id === student.student_id
        );

        const nowIso = new Date().toISOString();
        if (existingIdx >= 0) {
          const existing = currentResults[existingIdx];
          const updated: ExamResultRecord = {
            ...existing,
            internal_marks: internal,
            external_marks: external,
            total_marks: total,
            percentage: gradeInfo.percentage,
            grade: gradeInfo.grade,
            grade_point: gradeInfo.grade_point,
            result_status: gradeInfo.resultStatus,
            submission_notes: entry.submission_notes || existing.submission_notes,
            updated_at: nowIso,
          };
          currentResults[existingIdx] = updated;
          updatedResults.push(updated);
        } else {
          const newResult: ExamResultRecord = {
            result_id: `EXRES-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            schedule_id: scheduleId,
            session_id: schedule.session_id,
            student_id: student.student_id,
            student_registration_number: student.registration_number,
            student_name: `${student.first_name} ${student.last_name}`,
            course_code: schedule.course_code,
            course_title: schedule.course_title,
            programme_code: schedule.programme_code,
            semester: schedule.semester,
            academic_year: '2026-2027',
            internal_marks: internal,
            external_marks: external,
            total_marks: total,
            max_marks: schedule.max_marks,
            percentage: gradeInfo.percentage,
            grade: gradeInfo.grade,
            grade_point: gradeInfo.grade_point,
            result_status: gradeInfo.resultStatus,
            lifecycle_status: ExamLifecycleStatus.DRAFT,
            submission_notes: entry.submission_notes,
            corrections: [],
            created_at: nowIso,
            updated_at: nowIso,
          };
          currentResults.push(newResult);
          updatedResults.push(newResult);
        }
      }

      this.saveState({
        ...this.state,
        examResults: currentResults,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'FACULTY',
        action: AuditAction.EXAM_MARKS_DRAFT,
        target_worksheet: 'ExamResults',
        target_record_id: scheduleId,
        description: `Saved draft marks for ${entries.length} student(s) in '${schedule.course_code}'.`,
      });

      return updatedResults;
    },

    submitMarksForReview: async (
      scheduleId: string,
      notes?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ updatedCount: number; incompleteCount: number }> => {
      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Faculty check
      this.verifyFacultyExamCourseAccess(schedule.course_code, schedule.section, actor);

      // Check completeness: find all eligible students
      const eligibleStudents = await this.coe.checkEligibility(scheduleId);
      const scheduleAttendance = this.state.examAttendance.filter((a) => a.schedule_id === scheduleId);
      const scheduleResults = this.state.examResults.filter((r) => r.schedule_id === scheduleId);

      const missingStudents: StudentEligibilityDetail[] = [];
      for (const elig of eligibleStudents) {
        if (!elig.is_eligible) continue;
        const hasAttendance = scheduleAttendance.find((a) => a.student_id === elig.student_id);
        if (hasAttendance?.status === ExamAttendanceStatus.ABSENT || hasAttendance?.status === ExamAttendanceStatus.EXEMPTED) {
          continue; // Handled via attendance
        }
        const hasMark = scheduleResults.find((r) => r.student_id === elig.student_id);
        if (!hasMark) {
          missingStudents.push(elig);
        }
      }

      if (missingStudents.length > 0) {
        throw new Error(
          `Cannot submit marks: Incomplete evaluation. Missing marks for ${missingStudents.length} student(s) (${missingStudents
            .map((s) => s.name)
            .join(', ')}).`
        );
      }

      const nowIso = new Date().toISOString();
      const submittedBy = actor?.userId || actor?.employeeId || 'faculty';

      // Update result records to FACULTY_SUBMITTED
      const updatedResults = this.state.examResults.map((r) => {
        if (r.schedule_id === scheduleId) {
          return {
            ...r,
            lifecycle_status: ExamLifecycleStatus.FACULTY_SUBMITTED,
            faculty_submitted_by: submittedBy,
            faculty_submitted_at: nowIso,
            updated_at: nowIso,
          };
        }
        return r;
      });

      // Update schedule record
      const updatedSchedules = this.state.examSchedules.map((s) => {
        if (s.schedule_id === scheduleId) {
          return {
            ...s,
            marks_entry_open: false,
            status: ExamLifecycleStatus.FACULTY_SUBMITTED,
            notes: notes ? `Submitted: ${notes}` : s.notes,
            updated_at: nowIso,
          };
        }
        return s;
      });

      this.saveState({
        ...this.state,
        examResults: updatedResults,
        examSchedules: updatedSchedules,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'FACULTY',
        action: AuditAction.EXAM_MARKS_SUBMIT,
        target_worksheet: 'ExamResults',
        target_record_id: scheduleId,
        description: `Faculty submitted marks for review in '${schedule.course_code}' (${scheduleResults.length} records).`,
      });

      return { updatedCount: scheduleResults.length, incompleteCount: 0 };
    },

    reopenMarksEntry: async (
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('Validation Error: A descriptive reason is required to reopen marks entry.');
      }

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      const nowIso = new Date().toISOString();

      const updatedSchedule: ExamScheduleRecord = {
        ...schedule,
        marks_entry_open: true,
        status: ExamLifecycleStatus.REOPENED,
        notes: `Reopened by COE (${reason})`,
        updated_at: nowIso,
      };

      const updatedResults = this.state.examResults.map((r) => {
        if (r.schedule_id === scheduleId) {
          return {
            ...r,
            lifecycle_status: ExamLifecycleStatus.REOPENED,
            updated_at: nowIso,
          };
        }
        return r;
      });

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.map((s) => (s.schedule_id === scheduleId ? updatedSchedule : s)),
        examResults: updatedResults,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_REOPEN,
        target_worksheet: 'ExamSchedules',
        target_record_id: scheduleId,
        description: `Reopened marks entry for '${schedule.course_code}'. Reason: ${reason}`,
      });

      return updatedSchedule;
    },

    // 5. Moderation, Approval & Publication
    moderateMark: async (
      resultId: string,
      adjustments: {
        revised_internal?: number;
        revised_external?: number;
        revised_total?: number;
        reason: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      if (!adjustments.reason?.trim()) {
        throw new Error('Validation Error: A descriptive reason is mandatory for examination mark moderation.');
      }

      const result = this.state.examResults.find((r) => r.result_id === resultId);
      if (!result) throw new Error(`Exam result record '${resultId}' not found.`);

      let newInternal = adjustments.revised_internal !== undefined ? adjustments.revised_internal : result.internal_marks;
      let newExternal = adjustments.revised_external !== undefined ? adjustments.revised_external : result.external_marks;

      if (adjustments.revised_total !== undefined && adjustments.revised_internal === undefined && adjustments.revised_external === undefined) {
        newExternal = adjustments.revised_total - newInternal;
      }

      if (newInternal < 0 || newExternal < 0) {
        throw new Error('Marks cannot be negative.');
      }
      const newTotal = adjustments.revised_total !== undefined ? adjustments.revised_total : (newInternal + newExternal);
      if (newTotal > result.max_marks) {
        throw new Error(`Moderated total (${newTotal}) exceeds examination maximum (${result.max_marks}).`);
      }

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === result.schedule_id);
      const passingMarks = schedule?.passing_marks || 40;
      const gradeInfo = this.calculateDemonstrationGrade(newTotal, result.max_marks, passingMarks);

      const correctionEntry: ExamMarkCorrectionRecord = {
        correction_id: `COR-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        original_internal: result.internal_marks,
        revised_internal: newInternal,
        original_external: result.external_marks,
        revised_external: newExternal,
        original_total: result.total_marks,
        revised_total: newTotal,
        original_grade: result.grade,
        revised_grade: gradeInfo.grade,
        reason: adjustments.reason,
        actor_id: actor?.userId || 'coeoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        timestamp: new Date().toISOString(),
      };

      const updatedRecord: ExamResultRecord = {
        ...result,
        internal_marks: newInternal,
        external_marks: newExternal,
        total_marks: newTotal,
        percentage: gradeInfo.percentage,
        grade: gradeInfo.grade,
        grade_point: gradeInfo.grade_point,
        result_status: gradeInfo.resultStatus,
        lifecycle_status: ExamLifecycleStatus.UNDER_COE_REVIEW,
        reviewed_by: actor?.userId || 'coeoffice',
        reviewed_at: new Date().toISOString(),
        corrections: [...(result.corrections || []), correctionEntry],
        updated_at: new Date().toISOString(),
      };

      this.saveState({
        ...this.state,
        examResults: this.state.examResults.map((r) => (r.result_id === resultId ? updatedRecord : r)),
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_MODERATION,
        target_worksheet: 'ExamResults',
        target_record_id: resultId,
        description: `Moderated marks from ${result.total_marks} to ${newTotal} (${gradeInfo.grade}). Reason: ${adjustments.reason}`,
      });

      return updatedRecord;
    },

    rejectMarksForCorrection: async (
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.WRITE);

      if (!reason?.trim()) {
        throw new Error('Validation Error: A descriptive reason is mandatory for rejecting marks submission.');
      }

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      const nowIso = new Date().toISOString();
      const updatedSchedule: ExamScheduleRecord = {
        ...schedule,
        status: ExamLifecycleStatus.REJECTED_FOR_CORRECTION,
        marks_entry_open: true,
        notes: `Rejected for correction: ${reason}`,
        updated_at: nowIso,
      };

      const updatedResults = this.state.examResults.map((r) => {
        if (r.schedule_id === scheduleId) {
          return {
            ...r,
            lifecycle_status: ExamLifecycleStatus.REJECTED_FOR_CORRECTION,
            rejection_reason: reason,
            updated_at: nowIso,
          };
        }
        return r;
      });

      this.saveState({
        ...this.state,
        examSchedules: this.state.examSchedules.map((s) => (s.schedule_id === scheduleId ? updatedSchedule : s)),
        examResults: updatedResults,
      });

      return updatedSchedule;
    },

    approveResults: async (
      scheduleId: string,
      notesOrActor?: any,
      actorArg?: any
    ): Promise<{ approvedCount: number }> => {
      const actor = (notesOrActor && typeof notesOrActor === 'object' && ('userId' in notesOrActor || 'role' in notesOrActor))
        ? notesOrActor
        : (actorArg || notesOrActor);

      if (actor?.role === AuthRole.STUDENT || actor?.role === AuthRole.PARENT) {
        throw new Error(`Unauthorized: Role '${actor.role}' cannot access COE Office administration.`);
      }

      if (actor?.role === AuthRole.FACULTY || actor?.employeeId) {
        throw new Error(
          'Separation of Duties Violation: Faculty cannot approve their own marks submissions. A designated COE Officer or Super Admin must review and approve.'
        );
      }

      this.verifyCoeAccess(actor, PermissionScope.APPROVE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Separation of duties enforcement:
      // If the approving actor is the same faculty who submitted marks, block approval!
      const resultsForSchedule = this.state.examResults.filter((r) => r.schedule_id === scheduleId);
      const submitter = resultsForSchedule.find((r) => r.faculty_submitted_by)?.faculty_submitted_by;

      if (submitter && (actor?.userId === submitter || actor?.employeeId === submitter)) {
        throw new Error(
          'Separation of Duties Violation: Faculty cannot approve their own marks submissions. A designated COE Officer or Super Admin must review and approve.'
        );
      }

      // Check completeness: cannot approve if required marks are incomplete
      if (resultsForSchedule.length === 0) {
        throw new Error('Cannot approve results: Required marks or review checks remain incomplete.');
      }

      const nowIso = new Date().toISOString();
      const approver = actor?.userId || 'coeoffice';

      const updatedResults = this.state.examResults.map((r) => {
        if (r.schedule_id === scheduleId) {
          return {
            ...r,
            lifecycle_status: ExamLifecycleStatus.APPROVED,
            approved_by: approver,
            approved_at: nowIso,
            updated_at: nowIso,
          };
        }
        return r;
      });

      const updatedSchedules = this.state.examSchedules.map((s) => {
        if (s.schedule_id === scheduleId) {
          return {
            ...s,
            status: ExamLifecycleStatus.APPROVED,
            updated_at: nowIso,
          };
        }
        return s;
      });

      this.saveState({
        ...this.state,
        examResults: updatedResults,
        examSchedules: updatedSchedules,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_APPROVE,
        target_worksheet: 'ExamResults',
        target_record_id: scheduleId,
        description: `Approved examination results for '${schedule.course_code}' (${resultsForSchedule.length} records).`,
      });

      return { approvedCount: resultsForSchedule.length };
    },

    publishResults: async (
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ publishedCount: number }> => {
      this.verifyCoeAccess(actor, PermissionScope.APPROVE);

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === scheduleId);
      if (!schedule) throw new Error(`Examination schedule '${scheduleId}' not found.`);

      // Validate that results are approved before publication
      if (schedule.status !== ExamLifecycleStatus.APPROVED) {
        throw new Error('Cannot publish results: Examination results have not been approved by COE.');
      }

      const resultsForSchedule = this.state.examResults.filter((r) => r.schedule_id === scheduleId);
      if (resultsForSchedule.length === 0) {
        throw new Error('Cannot publish results: Examination has missing marks or incomplete evaluations.');
      }

      const nowIso = new Date().toISOString();

      // Update results
      const updatedResults = this.state.examResults.map((r) => {
        if (r.schedule_id === scheduleId) {
          return {
            ...r,
            lifecycle_status: ExamLifecycleStatus.PUBLISHED,
            published_at: nowIso,
            updated_at: nowIso,
          };
        }
        return r;
      });

      // Update schedule
      const updatedSchedules = this.state.examSchedules.map((s) => {
        if (s.schedule_id === scheduleId) {
          return {
            ...s,
            status: ExamLifecycleStatus.PUBLISHED,
            updated_at: nowIso,
          };
        }
        return s;
      });

      // Synchronize with existing legacy examinations & academics tables
      let currentExams = [...this.state.examinations];
      let currentAcademics = [...this.state.academics];

      for (const res of resultsForSchedule) {
        // Examinations sync
        const existingExamIdx = currentExams.findIndex(
          (ex) => ex.student_id === res.student_id && ex.course_code === res.course_code
        );
        if (existingExamIdx >= 0) {
          currentExams[existingExamIdx] = {
            ...currentExams[existingExamIdx],
            internal_marks: res.internal_marks,
            external_marks: res.external_marks,
            total_marks: res.total_marks,
            exam_status: ExamStatus.DECLARED,
            published_at: nowIso,
          };
        } else {
          currentExams.push({
            exam_id: `EXM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            exam_session: schedule.session_id,
            course_code: res.course_code,
            student_id: res.student_id,
            hall_ticket_number: `HT-${res.student_registration_number.slice(-4)}`,
            internal_marks: res.internal_marks,
            external_marks: res.external_marks,
            total_marks: res.total_marks,
            max_marks: res.max_marks,
            exam_status: ExamStatus.DECLARED,
            evaluated_by_employee_id: res.faculty_submitted_by || 'EMP-001',
            moderated_by_office_id: 'PO-004',
            published_at: nowIso,
          });
        }

        // Academics sync
        const existingAcadIdx = currentAcademics.findIndex(
          (ac) => ac.student_id === res.student_id && ac.course_code === res.course_code
        );
        if (existingAcadIdx >= 0) {
          currentAcademics[existingAcadIdx] = {
            ...currentAcademics[existingAcadIdx],
            letter_grade: res.grade,
            grade_point: res.grade_point,
            published_by_office_id: 'PO-004',
            updated_at: nowIso,
          };
        } else {
          currentAcademics.push({
            record_id: `ACR-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            student_id: res.student_id,
            registration_number: res.student_registration_number,
            semester: res.semester,
            academic_year: res.academic_year,
            course_code: res.course_code,
            course_title: res.course_title,
            credits: 4,
            grade_point: res.grade_point,
            letter_grade: res.grade,
            sgpa: res.grade_point,
            cgpa: res.grade_point,
            academic_standing: AcademicStanding.GOOD_STANDING,
            published_by_office_id: 'PO-004',
            updated_at: nowIso,
          });
        }
      }

      this.saveState({
        ...this.state,
        examResults: updatedResults,
        examSchedules: updatedSchedules,
        examinations: currentExams,
        academics: currentAcademics,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_PUBLISH,
        target_worksheet: 'ExamResults',
        target_record_id: scheduleId,
        description: `Published examination results for '${schedule.course_code}' to student portals (${resultsForSchedule.length} records).`,
      });

      return { publishedCount: resultsForSchedule.length };
    },

    correctPublishedResult: async (
      resultId: string,
      updates: {
        revised_internal?: number;
        revised_external?: number;
        revised_total?: number;
        reason: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord> => {
      this.verifyCoeAccess(actor, PermissionScope.APPROVE);

      if (!updates.reason?.trim()) {
        throw new Error('Validation Error: A descriptive justification is required to modify published examination results.');
      }

      const result = this.state.examResults.find((r) => r.result_id === resultId);
      if (!result) throw new Error(`Result record '${resultId}' not found.`);

      let newInternal = updates.revised_internal !== undefined ? updates.revised_internal : result.internal_marks;
      let newExternal = updates.revised_external !== undefined ? updates.revised_external : result.external_marks;

      if (updates.revised_total !== undefined && updates.revised_internal === undefined && updates.revised_external === undefined) {
        newExternal = updates.revised_total - newInternal;
      }

      if (newInternal < 0 || newExternal < 0) {
        throw new Error('Marks cannot be negative.');
      }
      const newTotal = updates.revised_total !== undefined ? updates.revised_total : (newInternal + newExternal);
      if (newTotal > result.max_marks) {
        throw new Error(`Revised total (${newTotal}) exceeds examination maximum (${result.max_marks}).`);
      }

      const schedule = this.state.examSchedules.find((s) => s.schedule_id === result.schedule_id);
      const passingMarks = schedule?.passing_marks || 40;
      const gradeInfo = this.calculateDemonstrationGrade(newTotal, result.max_marks, passingMarks);

      const correctionEntry: ExamMarkCorrectionRecord = {
        correction_id: `COR-PUB-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        original_internal: result.internal_marks,
        revised_internal: newInternal,
        original_external: result.external_marks,
        revised_external: newExternal,
        original_total: result.total_marks,
        revised_total: newTotal,
        original_grade: result.grade,
        revised_grade: gradeInfo.grade,
        reason: updates.reason,
        actor_id: actor?.userId || 'coeoffice',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        timestamp: new Date().toISOString(),
      };

      const nowIso = new Date().toISOString();
      const updatedRecord: ExamResultRecord = {
        ...result,
        internal_marks: newInternal,
        external_marks: newExternal,
        total_marks: newTotal,
        percentage: gradeInfo.percentage,
        grade: gradeInfo.grade,
        grade_point: gradeInfo.grade_point,
        result_status: gradeInfo.resultStatus,
        corrections: [...(result.corrections || []), correctionEntry],
        updated_at: nowIso,
      };

      // Also update examinations and academics tables
      const updatedExams = this.state.examinations.map((ex) => {
        if (ex.student_id === result.student_id && ex.course_code === result.course_code) {
          return {
            ...ex,
            internal_marks: newInternal,
            external_marks: newExternal,
            total_marks: newTotal,
            published_at: nowIso,
          };
        }
        return ex;
      });

      const updatedAcademics = this.state.academics.map((ac) => {
        if (ac.student_id === result.student_id && ac.course_code === result.course_code) {
          return {
            ...ac,
            letter_grade: gradeInfo.grade,
            grade_point: gradeInfo.grade_point,
            updated_at: nowIso,
          };
        }
        return ac;
      });

      this.saveState({
        ...this.state,
        examResults: this.state.examResults.map((r) => (r.result_id === resultId ? updatedRecord : r)),
        examinations: updatedExams,
        academics: updatedAcademics,
      });

      await this.audit.log({
        actor_id: actor?.userId || 'SYSTEM',
        actor_role: actor?.role || 'OFFICE_ADMIN',
        action: AuditAction.EXAM_RESULT_CORRECT,
        target_worksheet: 'ExamResults',
        target_record_id: resultId,
        description: `Officially corrected published result for ${result.student_registration_number} in ${result.course_code}. Reason: ${updates.reason}`,
      });

      return updatedRecord;
    },

    // 6. Student & Parent Portals
    getStudentPublishedResults: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]> => {
      // Student isolation enforcement
      if (actor && actor.role === AuthRole.STUDENT) {
        const student = this.state.students.find(
          (s) => s.student_id === studentId || s.registration_number === studentId
        );
        const isSelf =
          actor.userId === studentId ||
          actor.userId === student?.student_id ||
          actor.userId === student?.registration_number;

        if (!isSelf) {
          throw new Error('Unauthorized: Students cannot view results belonging to other students.');
        }
      }

      // Return ONLY results that have been published
      return this.state.examResults.filter(
        (r) =>
          (r.student_id === studentId || r.student_registration_number === studentId) &&
          r.lifecycle_status === ExamLifecycleStatus.PUBLISHED
      );
    },

    getParentWardResults: async (
      parentId: string,
      wardStudentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]> => {
      if (!actor || !actor.userId || !actor.role) {
        throw new Error('Unauthorized: Authentication required to view examination results.');
      }

      let resolvedParentId = parentId;
      if (actor.role === AuthRole.PARENT) {
        const parentRecord = this.state.parents.find(
          (p) =>
            p.parent_id === actor.userId ||
            p.email.toLowerCase() === actor.userId.toLowerCase() ||
            (actor.employeeId && p.parent_id === actor.employeeId)
        );
        resolvedParentId = parentRecord ? parentRecord.parent_id : actor.userId;
        if (parentId && parentId !== resolvedParentId && actor.userId !== 'admin') {
          throw new Error(
            `Access Denied: Cross-parent queries prohibited. Authenticated parent '${resolvedParentId}' cannot access results for parent '${parentId}'.`
          );
        }
      }

      const link = this.state.parentStudentLinks.find(
        (l) =>
          l.parent_id === resolvedParentId &&
          (l.student_id === wardStudentId || l.student_registration_number === wardStudentId) &&
          l.status === 'ACTIVE'
      );

      if (!link) {
        throw new Error('Access Denied: No active relationship link found for this student.');
      }

      if (!link.can_view_grades) {
        throw new Error('Access Denied: Grade visibility has not been granted for this student.');
      }

      // Return ONLY published results
      return this.state.examResults.filter(
        (r) =>
          (r.student_id === wardStudentId || r.student_registration_number === wardStudentId) &&
          r.lifecycle_status === ExamLifecycleStatus.PUBLISHED
      );
    },

    getStudentTranscript: async (
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentTranscriptSummary> => {
      const student = this.state.students.find(
        (s) => s.student_id === studentId || s.registration_number === studentId
      );
      if (!student) throw new Error(`Student '${studentId}' not found.`);

      // Student and Parent isolation
      if (actor && actor.role === AuthRole.STUDENT) {
        const isSelf =
          actor.userId === studentId ||
          actor.userId === student.student_id ||
          actor.userId === student.registration_number;
        if (!isSelf) {
          throw new Error('Unauthorized: Students cannot view transcripts belonging to other students.');
        }
      } else if (actor && actor.role === AuthRole.PARENT) {
        const parentRecord = this.state.parents.find(
          (p) =>
            p.parent_id === actor.userId ||
            p.email.toLowerCase() === actor.userId.toLowerCase() ||
            (actor.employeeId && p.parent_id === actor.employeeId)
        );
        const resolvedParentId = parentRecord ? parentRecord.parent_id : actor.userId;
        const link = this.state.parentStudentLinks.find(
          (l) =>
            l.parent_id === resolvedParentId &&
            (l.student_id === student.student_id || l.student_registration_number === student.registration_number) &&
            l.status === 'ACTIVE'
        );
        if (!link) {
          throw new Error('Access Denied: No active relationship link found for this student.');
        }
        if (!link.can_view_grades) {
          throw new Error('Access Denied: Parent does not have permission to view transcripts for this student.');
        }
      }

      // Collect published examination results + existing academics records
      const publishedExamResults = this.state.examResults.filter(
        (r) =>
          (r.student_id === student.student_id || r.student_registration_number === student.registration_number) &&
          r.lifecycle_status === ExamLifecycleStatus.PUBLISHED
      );

      const legacyAcademics = this.state.academics.filter(
        (a) => a.student_id === student.student_id || a.registration_number === student.registration_number
      );

      // Group by semester
      const semesterMap = new Map<number, { semester: number; academicYear: string; courses: any[]; totalPoints: number; totalCredits: number }>();

      // Populate from published results
      for (const res of publishedExamResults) {
        const sem = res.semester || 3;
        const cur = semesterMap.get(sem) || {
          semester: sem,
          academicYear: res.academic_year || '2026-2027',
          courses: [],
          totalPoints: 0,
          totalCredits: 0,
        };

        const credits = 4;
        cur.courses.push({
          course_code: res.course_code,
          course_title: res.course_title,
          credits,
          grade: res.grade,
          grade_point: res.grade_point,
          marks: res.total_marks,
          max_marks: res.max_marks,
          status: res.result_status,
          published_at: res.published_at,
        });
        cur.totalPoints += res.grade_point * credits;
        cur.totalCredits += credits;
        semesterMap.set(sem, cur);
      }

      // Also include any legacy academic coursework if not duplicate
      for (const leg of legacyAcademics) {
        const sem = leg.semester || 1;
        const cur = semesterMap.get(sem) || {
          semester: sem,
          academicYear: leg.academic_year || '2026-2027',
          courses: [],
          totalPoints: 0,
          totalCredits: 0,
        };

        const alreadyPresent = cur.courses.some((c) => c.course_code === leg.course_code);
        if (!alreadyPresent) {
          const credits = leg.credits || 4;
          cur.courses.push({
            course_code: leg.course_code,
            course_title: leg.course_title,
            credits,
            grade: leg.letter_grade,
            grade_point: leg.grade_point,
            marks: Math.round(leg.grade_point * 10),
            max_marks: 100,
            status: 'PASS',
          });
          cur.totalPoints += leg.grade_point * credits;
          cur.totalCredits += credits;
          semesterMap.set(sem, cur);
        }
      }

      const semesterSummaries = Array.from(semesterMap.values())
        .sort((a, b) => a.semester - b.semester)
        .map((s) => ({
          semester: s.semester,
          academicYear: s.academicYear,
          courses: s.courses,
          sgpa: s.totalCredits > 0 ? Number((s.totalPoints / s.totalCredits).toFixed(2)) : 0.0,
          totalCredits: s.totalCredits,
        }));

      let cumulativePoints = 0;
      let cumulativeCredits = 0;
      for (const s of semesterSummaries) {
        cumulativePoints += s.sgpa * s.totalCredits;
        cumulativeCredits += s.totalCredits;
      }

      const cgpa = cumulativeCredits > 0 ? Number((cumulativePoints / cumulativeCredits).toFixed(2)) : 0.0;

      return {
        student,
        semesterSummaries,
        cgpa,
        overallCredits: cumulativeCredits,
      };
    },

    // 7. Metrics
    getCoeDashboardMetrics: async (): Promise<COEDashboardMetrics> => {
      const schedules = this.state.examSchedules;
      const results = this.state.examResults;
      const attendance = this.state.examAttendance;

      const upcomingExamsCount = schedules.filter((s) =>
        [ExamLifecycleStatus.SCHEDULED, ExamLifecycleStatus.DRAFT].includes(s.status)
      ).length;

      const inProgressOrCompletedExamsCount = schedules.filter((s) =>
        [
          ExamLifecycleStatus.MARKS_ENTRY_OPEN,
          ExamLifecycleStatus.FACULTY_SUBMITTED,
          ExamLifecycleStatus.UNDER_COE_REVIEW,
          ExamLifecycleStatus.APPROVED,
          ExamLifecycleStatus.PUBLISHED,
        ].includes(s.status)
      ).length;

      const awaitingFacultySubmissionCount = schedules.filter((s) => s.marks_entry_open).length;

      const submissionsAwaitingCoeReviewCount = schedules.filter(
        (s) => s.status === ExamLifecycleStatus.FACULTY_SUBMITTED || s.status === ExamLifecycleStatus.UNDER_COE_REVIEW
      ).length;

      const resultsAwaitingApprovalOrPublicationCount = schedules.filter(
        (s) => s.status === ExamLifecycleStatus.APPROVED
      ).length;

      const publishedResultsCount = results.filter(
        (r) => r.lifecycle_status === ExamLifecycleStatus.PUBLISHED
      ).length;

      // Missing marks: count schedules in MARKS_ENTRY_OPEN with missing student entries
      const missingMarksCount = schedules.filter((s) => s.marks_entry_open).length;

      // Attendance discrepancies: absent or exempted count
      const attendanceDiscrepanciesCount = attendance.filter(
        (a) => a.status === ExamAttendanceStatus.ABSENT || a.status === ExamAttendanceStatus.EXEMPTED
      ).length;

      return {
        upcomingExamsCount,
        inProgressOrCompletedExamsCount,
        awaitingFacultySubmissionCount,
        submissionsAwaitingCoeReviewCount,
        resultsAwaitingApprovalOrPublicationCount,
        publishedResultsCount,
        missingMarksCount,
        attendanceDiscrepanciesCount,
      };
    },

    // Aliases
    getExamSessions: async (arg1?: any, arg2?: any) => this.coe.getSessions(arg2 || arg1),
    createExamSession: async (data: any, actor?: any) => this.coe.createSession(data, actor),
    createExamSchedule: async (data: any, actor?: any) => this.coe.scheduleExam(data, actor),
    getExamEligibility: async (scheduleId: string, actor?: any) => this.coe.checkEligibility(scheduleId, actor),
    recordExamAttendance: async (data: any, actor?: any) => this.coe.recordAttendance(data, actor),
    correctExamAttendance: async (id: string, st: any, r: string, actor?: any) => this.coe.correctAttendance(id, st, r, actor),
    submitMarksToCOE: async (id: string, notes?: string, actor?: any) => this.coe.submitMarksForReview(id, notes, actor),
    moderateMarks: async (id: string, adj: any, actor?: any) => this.coe.moderateMark(id, adj, actor),
    getExamResults: async (id: string, actor?: any) => this.coe.getMarks(id, actor),
    deleteExamSchedule: async (id: string, actor?: any) => this.coe.deleteSchedule(id, actor),
  };

  // ---------------------------------------------------------------------------
  // INSTITUTIONAL SETTINGS & GOVERNANCE
  // ---------------------------------------------------------------------------
  public settings = {
    getInstitutionalSettings: async (): Promise<SystemSettingsRecord> => {
      return { ...this.state.systemSettings };
    },

    updateInstitutionalSettings: async (
      updates: Partial<SystemSettingsRecord>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<SystemSettingsRecord> => {
      if (
        actor &&
        actor.role !== AuthRole.SUPER_ADMIN &&
        actor.role !== 'SUPER_ADMIN' &&
        actor.userId !== 'admin'
      ) {
        throw new Error('Unauthorized: Only a Super Administrator can update institutional settings.');
      }

      const current = this.state.systemSettings;
      const updated: SystemSettingsRecord = {
        ...current,
        ...updates,
        updated_at: new Date().toISOString(),
        updated_by: actor?.userId || current.updated_by || 'admin',
      };

      this.state.systemSettings = updated;
      this.saveState(this.state);
      return updated;
    },
  };

  // ---------------------------------------------------------------------------
  // CENTRAL ACADEMIC YEAR & CALENDAR MANAGEMENT (Authoritative Controller)
  // ---------------------------------------------------------------------------
  public academicCalendar = {
    getActiveAcademicYear: async (): Promise<AcademicYearRecord> => {
      const active = this.state.academicYears.find((y) => y.is_current);
      if (active) return { ...active };

      const byCode = this.state.academicYears.find(
        (y) => y.code === this.state.systemSettings.active_academic_year_code
      );
      if (byCode) return { ...byCode };

      if (this.state.academicYears.length > 0) {
        return { ...this.state.academicYears[0] };
      }

      throw new Error('No academic year configured in system database.');
    },

    getAllAcademicYears: async (): Promise<AcademicYearRecord[]> => {
      return [...this.state.academicYears].sort((a, b) =>
        b.start_date.localeCompare(a.start_date)
      );
    },

    getAcademicYearById: async (yearId: string): Promise<AcademicYearRecord | null> => {
      const found = this.state.academicYears.find(
        (y) => y.year_id === yearId || y.code === yearId || y.name === yearId
      );
      return found ? { ...found } : null;
    },

    createAcademicYear: async (
      data: {
        code: string;
        name: string;
        startDate?: string;
        endDate?: string;
        start_date?: string;
        end_date?: string;
        status?: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
      },
      actor?: { userId?: string; role?: string; employeeId?: string; name?: string }
    ): Promise<AcademicYearRecord> => {
      // 1. Strict Super Admin Authorization (Never trust forged browser actor data)
      let verifiedActor = actor;
      try {
        const session = await this.auth.getCurrentSession();
        if (session) {
          const isSuper =
            (session.role as any) === AuthRole.SUPER_ADMIN ||
            (session.role as any) === 'SUPER_ADMIN' ||
            session.user?.username === 'admin';
          if (!isSuper) {
            throw new Error('Unauthorized: Only an authenticated Super Administrator can create an academic year.');
          }
          verifiedActor = {
            userId: session.user?.user_id || session.user?.username || 'admin',
            name: session.displayName || session.user?.username || 'Super Administrator',
            role: 'SUPER_ADMIN',
            employeeId: session.employeeProfile?.employee_id,
          };
        }
      } catch (err: any) {
        if (err.message?.includes('Unauthorized')) throw err;
      }

      if (
        !verifiedActor ||
        (verifiedActor.role !== AuthRole.SUPER_ADMIN &&
          verifiedActor.role !== 'SUPER_ADMIN' &&
          verifiedActor.userId !== 'admin')
      ) {
        throw new Error('Unauthorized: Only an authenticated Super Administrator can create an academic year.');
      }

      if (!data.code || !data.code.trim()) {
        throw new Error('Academic year code or label is required.');
      }

      const cleanCode = data.code.trim();
      const existing = this.state.academicYears.find(
        (y) =>
          y.code.toLowerCase() === cleanCode.toLowerCase() ||
          y.year_id === `AY-${cleanCode}` ||
          y.name.toLowerCase() === (data.name || '').trim().toLowerCase()
      );
      if (existing) {
        throw new Error(`Academic year with code '${data.code}' already exists.`);
      }

      const startDate = data.startDate || data.start_date || '';
      const endDate = data.endDate || data.end_date || '';

      if (!startDate || !endDate) {
        throw new Error('Start date and end date are required.');
      }

      const start = new Date(startDate).getTime();
      const end = new Date(endDate).getTime();
      if (isNaN(start) || isNaN(end)) {
        throw new Error('Invalid start date or end date format. Expected YYYY-MM-DD.');
      }

      if (start >= end) {
        throw new Error('Academic year start date must be strictly before end date.');
      }

      // Overlap validation: prevent overlapping with existing active or upcoming years
      const overlapping = this.state.academicYears.find((y) => {
        const yStart = new Date(y.start_date).getTime();
        const yEnd = new Date(y.end_date).getTime();
        return (
          (start >= yStart && start <= yEnd) ||
          (end >= yStart && end <= yEnd) ||
          (start <= yStart && end >= yEnd)
        );
      });

      if (overlapping) {
        throw new Error(
          `Academic year period overlaps with existing academic year '${overlapping.name || overlapping.code}' (${overlapping.start_date} to ${overlapping.end_date}).`
        );
      }

      const newRecord: AcademicYearRecord = {
        year_id: `AY-${cleanCode.replace(/\s+/g, '')}`,
        code: cleanCode,
        name: data.name?.trim() || `Academic Year ${cleanCode}`,
        start_date: startDate,
        end_date: endDate,
        is_current: false,
        status: data.status || 'UPCOMING',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      this.state.academicYears.push(newRecord);
      this.saveState(this.state);
      return { ...newRecord };
    },

    updateAcademicYear: async (
      yearId: string,
      updates: Partial<{
        code: string;
        name: string;
        startDate: string;
        endDate: string;
        start_date: string;
        end_date: string;
        status: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
      }>,
      actor?: { userId?: string; role?: string; employeeId?: string; name?: string }
    ): Promise<AcademicYearRecord> => {
      let verifiedActor = actor;
      try {
        const session = await this.auth.getCurrentSession();
        if (session) {
          const isSuper =
            (session.role as any) === AuthRole.SUPER_ADMIN ||
            (session.role as any) === 'SUPER_ADMIN' ||
            session.user?.username === 'admin';
          if (!isSuper) {
            throw new Error('Unauthorized: Only an authenticated Super Administrator can update an academic year.');
          }
          verifiedActor = {
            userId: session.user?.user_id || session.user?.username || 'admin',
            name: session.displayName || session.user?.username || 'Super Administrator',
            role: 'SUPER_ADMIN',
            employeeId: session.employeeProfile?.employee_id,
          };
        }
      } catch (err: any) {
        if (err.message?.includes('Unauthorized')) throw err;
      }

      if (
        !verifiedActor ||
        (verifiedActor.role !== AuthRole.SUPER_ADMIN &&
          verifiedActor.role !== 'SUPER_ADMIN' &&
          verifiedActor.userId !== 'admin')
      ) {
        throw new Error('Unauthorized: Only a Super Administrator can update an academic year.');
      }

      const idx = this.state.academicYears.findIndex(
        (y) => y.year_id === yearId || y.code === yearId
      );
      if (idx < 0) {
        throw new Error(`Academic year '${yearId}' not found.`);
      }

      const target = this.state.academicYears[idx];

      const newStartDate = updates.startDate || updates.start_date || target.start_date;
      const newEndDate = updates.endDate || updates.end_date || target.end_date;
      if (new Date(newStartDate).getTime() >= new Date(newEndDate).getTime()) {
        throw new Error('Academic year start date must be strictly before end date.');
      }

      const updated: AcademicYearRecord = {
        ...target,
        code: updates.code ? updates.code.trim() : target.code,
        name: updates.name ? updates.name.trim() : target.name,
        start_date: newStartDate,
        end_date: newEndDate,
        status: updates.status || target.status,
        updated_at: new Date().toISOString(),
      };

      this.state.academicYears[idx] = updated;
      this.saveState(this.state);
      return { ...updated };
    },

    activateAcademicYear: async (
      yearId: string,
      reason: string,
      actor?: { userId?: string; role?: string; name?: string; employeeId?: string }
    ): Promise<{
      success: boolean;
      activeYear: AcademicYearRecord;
      transition: AcademicYearTransitionAuditRecord;
    }> => {
      // 1. Strict Super Admin Authorization (Session authoritative check)
      let verifiedActor = actor;
      try {
        const session = await this.auth.getCurrentSession();
        if (session) {
          const isSuper =
            (session.role as any) === AuthRole.SUPER_ADMIN ||
            (session.role as any) === 'SUPER_ADMIN' ||
            session.user?.username === 'admin';
          if (!isSuper) {
            throw new Error(
              'Unauthorized: Only an authenticated Super Administrator can activate the institution-wide academic year.'
            );
          }
          verifiedActor = {
            userId: session.user?.user_id || session.user?.username || 'admin',
            name: session.displayName || session.user?.username || 'Super Administrator',
            role: 'SUPER_ADMIN',
            employeeId: session.employeeProfile?.employee_id,
          };
        }
      } catch (err: any) {
        if (err.message?.includes('Unauthorized')) throw err;
      }

      if (
        !verifiedActor ||
        (verifiedActor.role !== AuthRole.SUPER_ADMIN &&
          verifiedActor.role !== 'SUPER_ADMIN' &&
          verifiedActor.userId !== 'admin')
      ) {
        throw new Error(
          'Unauthorized: Only an authenticated Super Administrator can activate the institution-wide academic year.'
        );
      }

      // 2. Mandatory confirmation reason
      if (!reason || !reason.trim()) {
        throw new Error('A valid institutional reason is required to activate a new academic year.');
      }

      // 3. Look up target academic year
      const targetIdx = this.state.academicYears.findIndex(
        (y) => y.year_id === yearId || y.code === yearId || y.name === yearId
      );
      if (targetIdx < 0) {
        throw new Error(`Academic year '${yearId}' not found.`);
      }

      const previousActive = this.state.academicYears.find((y) => y.is_current);
      const targetYear = this.state.academicYears[targetIdx];

      // 4. Update status and current flags without touching or altering historical records
      this.state.academicYears = this.state.academicYears.map((y, idx) => {
        if (idx === targetIdx) {
          return {
            ...y,
            is_current: true,
            status: 'ACTIVE',
            updated_at: new Date().toISOString(),
          };
        }
        if (y.is_current) {
          return {
            ...y,
            is_current: false,
            status: 'ARCHIVED',
            updated_at: new Date().toISOString(),
          };
        }
        return y;
      });

      const updatedTarget = this.state.academicYears[targetIdx];

      // 5. Update central system settings
      this.state.systemSettings = {
        ...this.state.systemSettings,
        active_academic_year_code: updatedTarget.code,
        active_academic_year_id: updatedTarget.year_id,
        updated_at: new Date().toISOString(),
        updated_by: verifiedActor.userId || 'admin',
      };

      // 6. Record Transition Audit History
      const transition: AcademicYearTransitionAuditRecord = {
        transition_id: `AYT-${Date.now().toString().slice(-6)}`,
        previous_year_code: previousActive ? previousActive.code : 'NONE',
        new_year_code: updatedTarget.code,
        activated_by_user_id: verifiedActor.userId || 'admin',
        activated_by_name: verifiedActor.name || 'Institutional Administrator',
        activated_by_role: 'SUPER_ADMIN',
        timestamp: new Date().toISOString(),
        reason: reason.trim(),
        status: 'SUCCESS',
      };

      this.state.academicYearTransitions = [
        transition,
        ...(this.state.academicYearTransitions || []),
      ];

      // 7. Save state to persistence
      this.saveState(this.state);

      // 8. Broadcast to all active subscribers across open portals
      this.notifyAcademicYearSubscribers(updatedTarget);

      return {
        success: true,
        activeYear: { ...updatedTarget },
        transition,
      };
    },

    deleteAcademicYear: async (
      yearId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ success: boolean; message: string }> => {
      if (
        actor &&
        actor.role !== AuthRole.SUPER_ADMIN &&
        actor.role !== 'SUPER_ADMIN' &&
        actor.userId !== 'admin'
      ) {
        throw new Error('Unauthorized: Only a Super Administrator can delete an academic year.');
      }

      const target = this.state.academicYears.find(
        (y) => y.year_id === yearId || y.code === yearId
      );
      if (!target) {
        throw new Error(`Academic year '${yearId}' not found.`);
      }

      if (target.is_current) {
        throw new Error(
          'Cannot delete the active academic year. Transition to a new academic year before archiving or deleting.'
        );
      }

      // Historical safety: prevent deleting academic years containing institutional records
      const hasCourseOfferings = this.state.courseOfferings?.some(
        (co) => co.academic_year === target.code
      );
      const hasInvoices = this.state.feeInvoices?.some(
        (fi) => fi.academic_year === target.code
      );
      const hasHostel = this.state.hostelAllocations?.some(
        (ha) => ha.academic_year === target.code
      );
      const hasExams = this.state.examSessions?.some(
        (es) => es.academic_year === target.code
      );

      if (hasCourseOfferings || hasInvoices || hasHostel || hasExams) {
        throw new Error(
          `Cannot delete academic year '${target.code}': contains existing institutional records. Academic years with historical data must be archived, not deleted.`
        );
      }

      this.state.academicYears = this.state.academicYears.filter(
        (y) => y.year_id !== target.year_id
      );
      this.saveState(this.state);
      return {
        success: true,
        message: `Academic year ${target.code} deleted successfully.`,
      };
    },

    getTransitionHistory: async (): Promise<AcademicYearTransitionAuditRecord[]> => {
      return [...(this.state.academicYearTransitions || [])];
    },

    subscribeToChanges: (callback: (activeYear: AcademicYearRecord) => void): (() => void) => {
      this.academicYearSubscribers.add(callback);
      return () => {
        this.academicYearSubscribers.delete(callback);
      };
    },
  };
}


// Export singleton instance of development data adapter
export const devDataAdapter: IEitDataAdapter = new DevDataAdapterImpl();
