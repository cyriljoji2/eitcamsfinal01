import { EmployeeCategory } from '../types/database';

/**
 * EIT Registration Number Generation & Safe Allocation Service
 *
 * Guaranteed Unique Registration Formats:
 * - Student:                EIT-STU-{YEAR}-{PROGRAM_CODE}-{0001}
 *   Example:                EIT-STU-2026-CSE-0042
 *
 * - Teaching Employee:      EIT-TCH-{DEPT_CODE}-{YEAR}-{001}
 *   Example:                EIT-TCH-CSE-2026-015
 *
 * - Non-Teaching Employee:  EIT-NTC-{DEPT_CODE}-{YEAR}-{001}
 *   Example:                EIT-NTC-ADM-2026-008
 */

export interface StudentRegParams {
  year: number;
  programCode: string;
  sequenceNumber: number;
}

export interface EmployeeRegParams {
  category: EmployeeCategory;
  departmentCode: string;
  year: number;
  sequenceNumber: number;
}

export function generateStudentRegistrationNumber({
  year,
  programCode,
  sequenceNumber,
}: StudentRegParams): string {
  const sanitizedProg = programCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  const paddedSeq = String(sequenceNumber).padStart(4, '0');
  return `EIT-STU-${year}-${sanitizedProg}-${paddedSeq}`;
}

export function generateEmployeeRegistrationNumber({
  category,
  departmentCode,
  year,
  sequenceNumber,
}: EmployeeRegParams): string {
  const prefix = category === EmployeeCategory.TEACHING ? 'TCH' : 'NTC';
  const sanitizedDept = departmentCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  const paddedSeq = String(sequenceNumber).padStart(3, '0');
  return `EIT-${prefix}-${sanitizedDept}-${year}-${paddedSeq}`;
}

/**
 * Parses and validates an existing registration number to identify entity type and sequence.
 */
export function parseRegistrationNumber(regNum: string): {
  isValid: boolean;
  type?: 'STUDENT' | 'TEACHING_EMPLOYEE' | 'NON_TEACHING_EMPLOYEE';
  year?: number;
  code?: string;
  sequence?: number;
} {
  const studentRegex = /^EIT-STU-(\d{4})-([A-Z0-9]+)-(\d{4})$/;
  const employeeRegex = /^EIT-(TCH|NTC)-([A-Z0-9]+)-(\d{4})-(\d{3})$/;

  const stuMatch = regNum.trim().toUpperCase().match(studentRegex);
  if (stuMatch) {
    return {
      isValid: true,
      type: 'STUDENT',
      year: parseInt(stuMatch[1], 10),
      code: stuMatch[2],
      sequence: parseInt(stuMatch[3], 10),
    };
  }

  const empMatch = regNum.trim().toUpperCase().match(employeeRegex);
  if (empMatch) {
    return {
      isValid: true,
      type: empMatch[1] === 'TCH' ? 'TEACHING_EMPLOYEE' : 'NON_TEACHING_EMPLOYEE',
      code: empMatch[2],
      year: parseInt(empMatch[3], 10),
      sequence: parseInt(empMatch[4], 10),
    };
  }

  return { isValid: false };
}

/**
 * Computes the next guaranteed unique registration number by scanning existing allocated numbers.
 * Prevents race conditions and duplicate assignments.
 */
export function allocateNextStudentRegistrationNumber(
  existingRegNumbers: readonly string[],
  year: number,
  programCode: string
): string {
  const sanitizedProg = programCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  let maxSeq = 0;

  for (const reg of existingRegNumbers) {
    const parsed = parseRegistrationNumber(reg);
    if (parsed.isValid && parsed.type === 'STUDENT' && parsed.year === year && parsed.code === sanitizedProg) {
      if (parsed.sequence && parsed.sequence > maxSeq) {
        maxSeq = parsed.sequence;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return generateStudentRegistrationNumber({ year, programCode: sanitizedProg, sequenceNumber: nextSeq });
}

/**
 * Computes the next guaranteed unique employee registration number (Teaching or Non-Teaching).
 */
export function allocateNextEmployeeRegistrationNumber(
  existingRegNumbers: readonly string[],
  category: EmployeeCategory,
  departmentCode: string,
  year: number
): string {
  const targetType = category === EmployeeCategory.TEACHING ? 'TEACHING_EMPLOYEE' : 'NON_TEACHING_EMPLOYEE';
  const sanitizedDept = departmentCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  let maxSeq = 0;

  for (const reg of existingRegNumbers) {
    const parsed = parseRegistrationNumber(reg);
    if (parsed.isValid && parsed.type === targetType && parsed.year === year && parsed.code === sanitizedDept) {
      if (parsed.sequence && parsed.sequence > maxSeq) {
        maxSeq = parsed.sequence;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return generateEmployeeRegistrationNumber({ category, departmentCode: sanitizedDept, year, sequenceNumber: nextSeq });
}

/**
 * Computes the next guaranteed unique application ID for Admissions Office.
 * Format: EIT-APP-{YEAR}-{0001}
 */
export function allocateNextApplicationId(
  existingApplicationIds: readonly string[],
  year: number = 2026
): string {
  let maxSeq = 0;
  for (const id of existingApplicationIds) {
    const match = id.trim().toUpperCase().match(/^(?:EIT-)?APP-(\d{4})-(\d{1,5})$/);
    if (match && parseInt(match[1], 10) === year) {
      const seq = parseInt(match[2], 10);
      if (seq > maxSeq) {
        maxSeq = seq;
      }
    }
  }
  const nextSeq = maxSeq + 1;
  const paddedSeq = String(nextSeq).padStart(4, '0');
  return `EIT-APP-${year}-${paddedSeq}`;
}

