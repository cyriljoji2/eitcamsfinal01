/**
 * Repository and Data Adapter Interface for EIT Academic Management System
 *
 * This abstract interface decouples the UI from the storage layer.
 * A real Google Sheets repository will swap into this interface later
 * without rewriting any frontend component or view.
 */

import { PortalType } from '../types/portal';
import {
  AuthRole,
  AuthUserRecord,
  PermanentOfficeRecord,
  EmployeeRecord,
  FacultyCourseAssignmentRecord,
  OfficeAssignmentRecord,
  OfficePermissionRecord,
  StudentRecord,
  ParentRecord,
  ParentStudentLinkRecord,
  AcademicRecord,
  AttendanceRecord,
  AttendanceStatus,
  ExaminationRecord,
  FinanceRecord,
  HostelRecord,
  AuditLogRecord,
  ApplicantRecord,
  ApplicantDocumentRecord,
  ApplicationStatus,
  AcademicYearRecord,
  AcademicYearTransitionAuditRecord,
  SystemSettingsRecord,
  SemesterRecord,
  DepartmentRecord,
  ProgrammeRecord,
  CourseRecord,
  ClassSectionRecord,
  CourseOfferingRecord,
  CourseEnrolmentRecord,
  TimetableSlotRecord,
  FacultyCourseRole,
  ExamType,
  ExamSessionStatus,
  ExamLifecycleStatus,
  ExamAttendanceStatus,
  ExamResultStatus,
  ExamSessionRecord,
  ExamScheduleRecord,
  ExamAttendanceEntryRecord,
  ExamMarkCorrectionRecord,
  ExamResultRecord,
  StudentEligibilityDetail,
  COEDashboardMetrics,
  StudentTranscriptSummary,
  FeeCategory,
  FeeStructureRecord,
  InvoiceStatus,
  InvoiceLineItem,
  FeeInvoiceRecord,
  PaymentMethod,
  PaymentLedgerStatus,
  PaymentRecord,
  AdjustmentType,
  AdjustmentStatus,
  FeeAdjustmentRecord,
  FinanceDashboardMetrics,
  StudentFeeStatement,
  HostelGenderType,
  RoomType,
  RoomOperationalStatus,
  BedOccupancyStatus,
  HostelBedRecord,
  HostelRoomRecord,
  HostelBlockRecord,
  HostelAllocationLifecycleStatus,
  AllocationMovementRecord,
  HostelAllocationRecord,
  HostelChargeStatus,
  HostelChargeRequestRecord,
  HostelDashboardMetrics,
  StudentHostelDetails,
} from '../types/database';

export interface AuthSession {
  user: AuthUserRecord;
  token: string;
  displayName: string;
  portalType: PortalType;
  role: AuthRole;
  permanentOffice?: PermanentOfficeRecord;
  employeeProfile?: EmployeeRecord;
  studentProfile?: StudentRecord;
  parentProfile?: ParentRecord;
  availableOffices: PermanentOfficeRecord[];
  activeOfficeKey?: string;
  username?: string;
  userId?: string;
}

export interface LoginResult {
  success: boolean;
  session?: AuthSession;
  error?: string;
}

export interface IEitDataAdapter {
  // Identity & Auth
  auth: {
    login(username: string, passwordAttempt: string, portalType: PortalType): Promise<LoginResult>;
    getCurrentSession(): Promise<AuthSession | null>;
    logout(): Promise<void>;
  };

  // Offices & Governance
  offices: {
    getAllPermanent(): Promise<PermanentOfficeRecord[]>;
    getByUsername(username: string): Promise<PermanentOfficeRecord | null>;
  };

  // Staff & Employees
  employees: {
    getAll(): Promise<EmployeeRecord[]>;
    getById(id: string): Promise<EmployeeRecord | null>;
    create(data: Omit<EmployeeRecord, 'employee_id' | 'created_at' | 'updated_at'>): Promise<EmployeeRecord>;
    update(id: string, data: Partial<Omit<EmployeeRecord, 'employee_id' | 'registration_number' | 'category' | 'created_at'>>): Promise<EmployeeRecord>;
    provisionAccount(employeeId: string): Promise<{ success: boolean; user?: AuthUserRecord; message?: string; error?: string }>;
  };

  // Faculty Course Allocations (Teaching Only)
  facultyAssignments: {
    getAll(): Promise<FacultyCourseAssignmentRecord[]>;
    getByFaculty(employeeId: string): Promise<FacultyCourseAssignmentRecord[]>;
    assign(
      data: Omit<FacultyCourseAssignmentRecord, 'faculty_assignment_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord>;
  };

  // Office Assignments (Non-Teaching Staff)
  officeAssignments: {
    getAll(): Promise<OfficeAssignmentRecord[]>;
    getByEmployee(employeeId: string): Promise<OfficeAssignmentRecord[]>;
    getByOffice(officeId: string): Promise<OfficeAssignmentRecord[]>;
    assign(data: Omit<OfficeAssignmentRecord, 'assignment_id' | 'created_at'>): Promise<OfficeAssignmentRecord>;
    transfer(assignmentId: string, newOfficeId: string, newRoleTitle?: string): Promise<OfficeAssignmentRecord>;
    revoke(assignmentId: string): Promise<void>;
  };

  // Office Permissions
  officePermissions: {
    getByOffice(officeId: string): Promise<OfficePermissionRecord[]>;
    getByEmployee?(employeeId: string): Promise<OfficePermissionRecord[]>;
    grant(data: Omit<OfficePermissionRecord, 'permission_id' | 'granted_at'>): Promise<OfficePermissionRecord>;
    revoke(permissionId: string): Promise<void>;
  };

  // Admissions & Applicant Management (Phase 6)
  applicants: {
    getAll(): Promise<ApplicantRecord[]>;
    getById(id: string): Promise<ApplicantRecord | null>;
    create(
      data: Omit<ApplicantRecord, 'application_id' | 'documents' | 'status_history' | 'converted_to_student' | 'created_at' | 'updated_at'> & {
        documents?: Partial<ApplicantDocumentRecord>[];
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord>;
    update(
      id: string,
      data: Partial<Omit<ApplicantRecord, 'application_id' | 'status_history' | 'created_at'>>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord>;
    updateStatus(
      id: string,
      newStatus: ApplicationStatus,
      reason?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord>;
    updateDocumentStatus(
      applicationId: string,
      documentId: string,
      updates: {
        submission_status?: 'PENDING' | 'SUBMITTED';
        verification_status?: 'PENDING' | 'VERIFIED' | 'REJECTED';
        reviewer_notes?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ApplicantRecord>;
    convertApprovedApplicantToStudent(
      applicationId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{
      success: boolean;
      student: StudentRecord;
      account?: AuthUserRecord;
      alreadyConverted?: boolean;
      message?: string;
    }>;
  };

  // Students Master
  students: {
    getAll(): Promise<StudentRecord[]>;
    getById(id: string): Promise<StudentRecord | null>;
    getByRegistrationNumber(regNumber: string): Promise<StudentRecord | null>;
    create(data: Omit<StudentRecord, 'student_id' | 'created_at' | 'updated_at' | 'registration_number'> & { registration_number?: string }): Promise<StudentRecord>;
  };

  // Parents & Family Links
  parents: {
    getAll(): Promise<ParentRecord[]>;
    getById(id: string): Promise<ParentRecord | null>;
    getLinkedStudents(
      parentIdOrActor?: string | { userId: string; role: string; employeeId?: string },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ link: ParentStudentLinkRecord; student: StudentRecord }[]>;
    linkStudent(data: Omit<ParentStudentLinkRecord, 'link_id' | 'created_at' | 'updated_at'>): Promise<ParentStudentLinkRecord>;
  };

  // Academic Structure & Office Operations (Phase 7)
  academic: {
    // Structure queries
    getAcademicYears(): Promise<AcademicYearRecord[]>;
    getSemesters(): Promise<SemesterRecord[]>;
    getDepartments(): Promise<DepartmentRecord[]>;
    getProgrammes(): Promise<ProgrammeRecord[]>;
    getCourses(): Promise<CourseRecord[]>;
    getSections(): Promise<ClassSectionRecord[]>;
    getCourseOfferings(): Promise<CourseOfferingRecord[]>;

    // Structure management
    createCourse(
      data: Omit<CourseRecord, 'course_id'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseRecord>;
    createSection(
      data: Omit<ClassSectionRecord, 'section_id'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ClassSectionRecord>;
    createCourseOffering(
      data: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord>;
    updateCourseOffering?(
      offeringId: string,
      updates: Partial<CourseOfferingRecord>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord>;
    cancelCourseOffering?(
      offeringId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord>;
    publishCourseOffering?(
      offeringId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord>;
    createCourseOfferingWithTimetable?(
      offeringData: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
      timetableData?: {
        day_of_week: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
        start_time: string;
        end_time: string;
        room: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{
      offering: CourseOfferingRecord;
      timetableSlot?: TimetableSlotRecord;
      facultyAssignment?: FacultyCourseAssignmentRecord;
    }>;
    closeCourseOffering?(
      offeringId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseOfferingRecord>;

    // Faculty course assignment governance
    assignFaculty(
      data: {
        offering_id?: string;
        course_code?: string;
        course_title?: string;
        department?: string;
        semester?: number;
        academic_year?: string;
        section?: string;
        employee_id: string;
        role_in_course: FacultyCourseRole;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord>;
    endFacultyAssignment(
      assignmentId: string,
      reason?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<FacultyCourseAssignmentRecord>;

    // Student Course Enrolment
    getEnrolments(
      filters?: {
        student_id?: string;
        course_code?: string;
        section?: string;
        semester?: number;
        academic_year?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord[]>;
    enrolStudent(
      data: {
        offering_id?: string;
        student_id: string;
        course_code?: string;
        section?: string;
        semester?: number;
        academic_year?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord>;
    transferStudentSection(
      enrolmentId: string,
      newSection: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord>;
    withdrawStudent(
      enrolmentId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<CourseEnrolmentRecord>;

    // Faculty Teaching Workspace
    getFacultyAssignedCourses(employeeId: string): Promise<FacultyCourseAssignmentRecord[]>;
    getClassRoster(
      courseCode: string,
      section: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ enrolment: CourseEnrolmentRecord; student: StudentRecord }[]>;
    getFacultyProctorAssignments?(
      employeeId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<any[]>;

    // Timetable / Calendar Management
    getTimetable(filters?: {
      department?: string;
      semester?: number;
      section?: string;
      faculty_id?: string;
    }): Promise<TimetableSlotRecord[]>;
    scheduleTimetableSlot(
      data: Omit<TimetableSlotRecord, 'slot_id' | 'created_at' | 'status'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<TimetableSlotRecord>;

    // Bulk Enrolment & CSV Import (Enhanced Manual Course Offerings)
    previewBulkEnrolment?(request: any): Promise<any>;
    bulkEnrolStudents?(request: any, actor?: any): Promise<any>;
    validateCsvImport?(csvContent: string, fileName: string): Promise<any>;
    commitCsvImport?(params: { fileName: string; approvedRows: number[]; csvContent: string }, actor?: any): Promise<any>;
    getCsvImportBatches?(): Promise<any[]>;

    // Timetable Validation, Publication & Student Schedule
    validateTimetable?(params: { academic_year: string; semester: number; programme_code: string; section: string }): Promise<any>;
    publishTimetable?(params: { academic_year: string; semester: number; programme_code: string; section: string; change_notes?: string }, actor?: any): Promise<any>;
    getTimetableVersions?(filters?: { academic_year?: string; semester?: number; programme_code?: string; section?: string }): Promise<any[]>;
    getPublishedTimetableForStudent?(studentIdOrReg: string, actor?: any): Promise<any>;

    // Metrics
    getAcademicDashboardMetrics(): Promise<{
      activeProgrammesCount: number;
      activeCoursesCount: number;
      currentSemestersCount: number;
      activeSectionsCount: number;
      facultyAssignmentsCount: number;
      activeEnrolmentsCount: number;
      unassignedOfferingsCount: number;
      timetableConflictsCount: number;
    }>;
  };

  // Academic Records & Grades
  academics: {
    getByStudent(studentId: string, actor?: { userId: string; role: string; employeeId?: string }): Promise<AcademicRecord[]>;
  };

  // Attendance
  attendance: {
    getByStudent(studentId: string, actor?: { userId: string; role: string; employeeId?: string }): Promise<AttendanceRecord[]>;
    getAll?(): Promise<AttendanceRecord[]>;
    record(
      data: Omit<AttendanceRecord, 'attendance_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AttendanceRecord>;
    correctAttendance?(
      attendanceId: string,
      revisedStatus: AttendanceStatus,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AttendanceRecord>;
  };

  // Examinations
  examinations: {
    getByStudent(studentId: string, actor?: { userId: string; role: string; employeeId?: string }): Promise<ExaminationRecord[]>;
    getAll?(): Promise<ExaminationRecord[]>;
    recordOrUpdate?(
      data: Omit<ExaminationRecord, 'exam_id' | 'published_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExaminationRecord>;
  };

  // Finance & Accounts (Phase 9 Complete)
  finance: {
    // Backward-compatible query
    getByStudent(studentId: string, actor?: { userId: string; role: string; employeeId?: string }): Promise<FinanceRecord[]>;
    getAllInvoices(actor?: { userId: string; role: string; employeeId?: string }): Promise<FeeInvoiceRecord[]>;
    createInvoice(data: any, actor?: any): Promise<FeeInvoiceRecord>;
    createInvoiceFromHostelCharge?: (chargeRequestId: string, actor?: any) => Promise<FeeInvoiceRecord>;
    recordPayment(
      invoiceId: string,
      amount: number,
      arg3?: string | PaymentMethod,
      arg4?: PaymentMethod | string,
      arg5?: any,
      arg6?: any
    ): Promise<PaymentRecord>;

    // Fee Structures
    getFeeStructures(filters?: { academic_year?: string; semester?: number; programme_code?: string; status?: string }, actor?: any): Promise<FeeStructureRecord[]>;
    createFeeStructure(data: Omit<FeeStructureRecord, 'structure_id' | 'created_at' | 'updated_at'>, actor?: any): Promise<FeeStructureRecord>;
    updateFeeStructure(structureId: string, data: Partial<FeeStructureRecord>, actor?: any): Promise<FeeStructureRecord>;

    // Invoices & Ledger
    getInvoices(filters?: { invoice_id?: string; student_id?: string; registration_number?: string; academic_year?: string; semester?: number; status?: InvoiceStatus; category?: string }, actor?: any): Promise<FeeInvoiceRecord[]>;
    getInvoiceById(invoiceId: string, actor?: any): Promise<FeeInvoiceRecord | null>;
    generateInvoice(
      data: {
        student_id: string;
        academic_year: string;
        semester: number;
        fee_category?: string;
        due_date?: string;
        line_items: { fee_structure_id?: string; category: string; description: string; amount: number }[];
        notes?: string;
        hostel_charge_id?: string;
      },
      actor?: any
    ): Promise<FeeInvoiceRecord>;
    cancelInvoice(invoiceId: string, reason: string, actor?: any): Promise<FeeInvoiceRecord>;

    // Payments & Receipts
    getPayments(filters?: { invoice_id?: string; student_id?: string; status?: PaymentLedgerStatus }, actor?: any): Promise<PaymentRecord[]>;
    getPaymentById(paymentId: string, actor?: any): Promise<PaymentRecord | null>;
    reversePayment(paymentId: string, reason: string, actor?: any): Promise<PaymentRecord>;
    refundPayment(paymentId: string, amount: number, reason: string, actor?: any): Promise<PaymentRecord>;
    getReceipt(paymentIdOrReceiptNumber: string, actor?: any): Promise<{ payment: PaymentRecord; invoice: FeeInvoiceRecord; student: StudentRecord } | null>;

    // Adjustments, Discounts & Scholarships
    requestAdjustment(
      data: { invoice_id: string; adjustment_type: AdjustmentType; amount: number; reason: string },
      actor?: any
    ): Promise<FeeAdjustmentRecord>;
    approveAdjustment(adjustmentId: string, notesOrActor?: any, actor?: any): Promise<FeeAdjustmentRecord>;
    rejectAdjustment(adjustmentId: string, reason: string, actor?: any): Promise<FeeAdjustmentRecord>;
    getAdjustments(filters?: { invoice_id?: string; student_id?: string; status?: AdjustmentStatus }, actor?: any): Promise<FeeAdjustmentRecord[]>;

    // Statements, Metrics & Inter-Office Integration
    getFinanceDashboardMetrics(actor?: any): Promise<FinanceDashboardMetrics>;
    getStudentFeeStatement(studentId: string, actor?: any): Promise<StudentFeeStatement>;
    issueInvoiceForHostelCharge(chargeRequestId: string, actor?: any): Promise<FeeInvoiceRecord>;
    getPaymentLedger(filters?: any, actor?: any): Promise<PaymentRecord[]>;
  };

  // Hostel & Residential Operations (Phase 9 Complete)
  hostel: {
    // Backward-compatible query
    getByStudent(studentId: string, actor?: any): Promise<HostelRecord[]>;
    getAllAllocations(actor?: any): Promise<HostelAllocationRecord[]>;
    allocate?(data: any, actor?: any): Promise<HostelAllocationRecord>;

    // Inventory: Blocks & Rooms & Beds
    getBlocks(actor?: any): Promise<HostelBlockRecord[]>;
    createBlock(data: Omit<HostelBlockRecord, 'block_id' | 'created_at'>, actor?: any): Promise<HostelBlockRecord>;
    getRooms(filters?: { block_id?: string; status?: RoomOperationalStatus; floor?: number }, actor?: any): Promise<HostelRoomRecord[]>;
    getRoomById(roomId: string, actor?: any): Promise<HostelRoomRecord | null>;
    createRoom(
      data: {
        block_id: string;
        room_number: string;
        floor?: number;
        room_type: RoomType;
        capacity: number;
        amenities?: string[];
        bed_identifiers?: string[];
      },
      actor?: any
    ): Promise<HostelRoomRecord>;
    updateRoomStatus(roomId: string, status: RoomOperationalStatus, actor?: any): Promise<HostelRoomRecord>;
    getBedInventory(filters?: { block_id?: string; room_id?: string; status?: BedOccupancyStatus }, actor?: any): Promise<{ bed: HostelBedRecord; room: HostelRoomRecord }[]>;

    // Student Allocations & Movement
    getAllocations(filters?: { student_id?: string; block_id?: string; room_id?: string; status?: HostelAllocationLifecycleStatus; academic_year?: string }, actor?: any): Promise<HostelAllocationRecord[]>;
    getAllocationById(allocationId: string, actor?: any): Promise<HostelAllocationRecord | null>;
    allocateStudentBed(
      data: {
        student_id: string;
        bed_id: string;
        academic_year: string;
        semester?: number;
        start_date: string;
        end_date?: string;
        emergency_contact_phone?: string;
      },
      actor?: any
    ): Promise<HostelAllocationRecord>;
    allocateBed(data: any, actor?: any): Promise<HostelAllocationRecord>;
    transferStudentBed(
      allocationId: string,
      newBedId: string,
      reason: string,
      effectiveDate: string,
      actor?: any
    ): Promise<HostelAllocationRecord>;
    transferRoom(allocationId: string, newRoomIdOrBedId: string, targetBedOrReason?: string, reason?: string, actor?: any): Promise<HostelAllocationRecord>;
    checkInStudent(allocationId: string, remarksOrActor?: any, actor?: any): Promise<HostelAllocationRecord>;
    checkOutStudent(allocationId: string, conditionOrReason?: string, remarks?: string, actor?: any): Promise<HostelAllocationRecord>;
    cancelAllocation(allocationId: string, reason: string, actor?: any): Promise<HostelAllocationRecord>;

    // Hostel Charges & Requests
    requestHostelCharge(
      data: {
        allocation_id: string;
        billing_period: string;
        amount: number;
        description: string;
      },
      actor?: any
    ): Promise<HostelChargeRequestRecord>;
    requestCharge?: (data: any, actor?: any) => Promise<HostelChargeRequestRecord>;
    createChargeRequest(data: any, actor?: any): Promise<HostelChargeRequestRecord>;
    getChargeRequests(filters?: { allocation_id?: string; student_id?: string; status?: HostelChargeStatus }, actor?: any): Promise<HostelChargeRequestRecord[]>;
    getCharges(filters?: any, actor?: any): Promise<HostelChargeRequestRecord[]>;

    // Reports & Statements
    getHostelDashboardMetrics(actor?: any): Promise<HostelDashboardMetrics>;
    getStudentHostelDetails(studentId: string, actor?: any): Promise<StudentHostelDetails>;
  };

  // Audit Logs
  audit: {
    getRecent(): Promise<AuditLogRecord[]>;
    getAll(): Promise<AuditLogRecord[]>;
    log(entry: Omit<AuditLogRecord, 'log_id' | 'timestamp'>): Promise<void>;
  };

  // Controller of Examinations (COE) Office (Phase 8)
  coe: {
    // Sessions
    getSessions(actor?: { userId: string; role: string; employeeId?: string }): Promise<ExamSessionRecord[]>;
    createSession(
      data: Omit<ExamSessionRecord, 'session_id' | 'created_at'>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamSessionRecord>;

    // Schedules
    getSchedules(filters?: {
      session_id?: string;
      programme_code?: string;
      semester?: number;
      course_code?: string;
      status?: ExamLifecycleStatus;
    }): Promise<ExamScheduleRecord[]>;
    getScheduleById(scheduleId: string): Promise<ExamScheduleRecord | null>;
    scheduleExam(
      data: Omit<ExamScheduleRecord, 'schedule_id' | 'created_at' | 'updated_at' | 'course_title' | 'marks_entry_open' | 'status'> & {
        course_title?: string;
        marks_entry_open?: boolean;
        status?: ExamLifecycleStatus;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;
    updateSchedule(
      scheduleId: string,
      data: Partial<Omit<ExamScheduleRecord, 'schedule_id' | 'created_at'>>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;
    cancelSchedule(
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;
    deleteSchedule(
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<void>;
    setMarksEntryWindow(
      scheduleId: string,
      isOpen: boolean,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;

    // Eligibility & Attendance
    checkEligibility(
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentEligibilityDetail[]>;
    getAttendance(
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord[]>;
    recordAttendance(
      data: {
        schedule_id: string;
        student_id: string;
        status: ExamAttendanceStatus;
        remarks?: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord>;
    correctAttendance(
      attendanceId: string,
      revisedStatus: ExamAttendanceStatus,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamAttendanceEntryRecord>;

    // Marks Entry & Faculty Submissions
    getMarks(
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]>;
    saveDraftMarks(
      scheduleId: string,
      entries: {
        student_id: string;
        internal_marks?: number;
        external_marks?: number;
        submission_notes?: string;
      }[],
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]>;
    submitMarksForReview(
      scheduleId: string,
      notes?: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ updatedCount: number; incompleteCount: number }>;
    reopenMarksEntry(
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;

    // Moderation, Approval & Publication
    moderateMark(
      resultId: string,
      adjustments: {
        revised_internal?: number;
        revised_external?: number;
        revised_total?: number;
        reason: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord>;
    rejectMarksForCorrection(
      scheduleId: string,
      reason: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamScheduleRecord>;
    approveResults(
      scheduleId: string,
      notesOrActor?: any,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ approvedCount: number }>;
    publishResults(
      scheduleId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ publishedCount: number }>;
    correctPublishedResult(
      resultId: string,
      updates: {
        revised_internal?: number;
        revised_external?: number;
        revised_total?: number;
        reason: string;
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord>;

    // Student & Parent Portal
    getStudentPublishedResults(
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]>;
    getParentWardResults(
      parentId: string,
      wardStudentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<ExamResultRecord[]>;
    getStudentTranscript(
      studentId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<StudentTranscriptSummary>;

    // Metrics
    getCoeDashboardMetrics(): Promise<COEDashboardMetrics>;

    // Aliases
    getExamSessions?(arg1?: any, arg2?: any): Promise<ExamSessionRecord[]>;
    createExamSession?(data: any, actor?: any): Promise<ExamSessionRecord>;
    createExamSchedule?(data: any, actor?: any): Promise<ExamScheduleRecord>;
    getExamEligibility?(scheduleId: string, actor?: any): Promise<StudentEligibilityDetail[]>;
    recordExamAttendance?(data: any, actor?: any): Promise<ExamAttendanceEntryRecord>;
    correctExamAttendance?(id: string, st: any, r: string, actor?: any): Promise<ExamAttendanceEntryRecord>;
    submitMarksToCOE?(id: string, notes?: string, actor?: any): Promise<any>;
    moderateMarks?(id: string, adj: any, actor?: any): Promise<ExamResultRecord>;
    getExamResults?(id: string, actor?: any): Promise<ExamResultRecord[]>;
    deleteExamSchedule?(id: string, actor?: any): Promise<void>;
  };

  // Institutional Settings & Governance
  settings: {
    getInstitutionalSettings(): Promise<SystemSettingsRecord>;
    updateInstitutionalSettings(
      updates: Partial<SystemSettingsRecord>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<SystemSettingsRecord>;
  };

  // Central Academic Year & Calendar Management (Authoritative)
  academicCalendar: {
    getActiveAcademicYear(): Promise<AcademicYearRecord>;
    getAllAcademicYears(): Promise<AcademicYearRecord[]>;
    getAcademicYearById(yearId: string): Promise<AcademicYearRecord | null>;
    createAcademicYear(
      data: {
        code: string;
        name: string;
        startDate: string;
        endDate: string;
        status?: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
      },
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AcademicYearRecord>;
    updateAcademicYear(
      yearId: string,
      updates: Partial<{
        code: string;
        name: string;
        startDate: string;
        endDate: string;
        status: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
      }>,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<AcademicYearRecord>;
    activateAcademicYear(
      yearId: string,
      reason: string,
      actor: { userId: string; role: string; name?: string; employeeId?: string }
    ): Promise<{
      success: boolean;
      activeYear: AcademicYearRecord;
      transition: AcademicYearTransitionAuditRecord;
    }>;
    deleteAcademicYear(
      yearId: string,
      actor?: { userId: string; role: string; employeeId?: string }
    ): Promise<{ success: boolean; message: string }>;
    getTransitionHistory(): Promise<AcademicYearTransitionAuditRecord[]>;
    subscribeToChanges(callback: (activeYear: AcademicYearRecord) => void): () => void;
  };

  // Top-level aliases and testing helpers
  admissions?: any;
  getState?: () => any;
  saveState?: (state: any) => void;
}

