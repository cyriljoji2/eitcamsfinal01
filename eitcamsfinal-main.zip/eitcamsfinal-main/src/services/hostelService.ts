/**
 * EIT CAMS — Hostel Office Authoritative Service & Repository
 * Full University Adaptation for Campus Residential Hall Administration
 */

import { devDataAdapter } from './devDataAdapter';
import {
  Hostel,
  HostelBlock,
  HostelFloor,
  HostelRoom,
  HostelBed,
  HostelAllotment,
  HostelAllotmentHistory,
  HostelDashboardMetrics,
} from '../types/hostel';

type Listener = () => void;
const listeners = new Set<Listener>();

function notify() {
  listeners.forEach((fn) => {
    try {
      fn();
    } catch (e) {
      console.error('Hostel listener error:', e);
    }
  });
}

// =============================================================================
// INITIAL SEED DATA FOR EIT CAMPUS RESIDENTIAL HALLS
// =============================================================================

let hostelsStore: Hostel[] = [
  {
    id: 'HST-001',
    hostelName: 'Nilgiri Men’s Residence Hall',
    hostelCode: 'EIT-HST-001',
    hostelType: 'Boys',
    category: 'Standard',
    status: 'active',
    address: 'North Campus Zone, EIT Main Campus Road',
    description: 'Premier undergraduate and postgraduate men’s residence with attached mess and sports quad.',
    wardenName: 'Prof. K. Narayanan',
    wardenContact: '+91 98401 54321',
    wardenPhone: '+91 98401 54321',
    createdAt: '2026-01-01T00:00:00Z',
    name: 'Nilgiri Men’s Residence Hall',
    blockName: 'Nilgiri Wing A',
    type: 'Boys',
  },
  {
    id: 'HST-002',
    hostelName: 'Sarabhai Women’s Residence Hall',
    hostelCode: 'EIT-HST-002',
    hostelType: 'Girls',
    category: 'Standard',
    status: 'active',
    address: 'South Campus Quadrangle, EIT Campus',
    description: 'Secure women’s residential hall equipped with indoor recreation, study commons and biometric access.',
    wardenName: 'Dr. Ananya Roy',
    wardenContact: '+91 98401 54322',
    wardenPhone: '+91 98401 54322',
    createdAt: '2026-01-01T00:00:00Z',
    name: 'Sarabhai Women’s Residence Hall',
    blockName: 'Sarabhai Wing C',
    type: 'Girls',
  },
  {
    id: 'HST-003',
    hostelName: 'Kalam International Residence',
    hostelCode: 'EIT-HST-003',
    hostelType: 'Co-ed',
    category: 'Deluxe',
    status: 'active',
    address: 'East Campus Innovation Zone, EIT Campus',
    description: 'International student and scholar residence featuring climate-controlled suites and independent wings.',
    wardenName: 'Dr. Vikram Seth',
    wardenContact: '+91 98401 54323',
    wardenPhone: '+91 98401 54323',
    createdAt: '2026-01-01T00:00:00Z',
    name: 'Kalam International Residence',
    blockName: 'Kalam Wing E',
    type: 'Co-ed',
  },
];

let blocksStore: HostelBlock[] = [
  {
    id: 'BLK-001',
    hostelId: 'HST-001',
    blockName: 'Block A - Aryabhata Wing',
    blockCode: 'BLK-A',
    status: 'active',
    description: 'Undergraduate CSE and Engineering cohort wing.',
    wardenName: 'Prof. K. Narayanan',
    contactPhone: '+91 98401 54321',
    totalFloors: 4,
  },
  {
    id: 'BLK-002',
    hostelId: 'HST-001',
    blockName: 'Block B - Ramanujan Wing',
    blockCode: 'BLK-B',
    status: 'active',
    description: 'Senior and Postgraduate engineering wing.',
    wardenName: 'Prof. Rajesh Rao',
    contactPhone: '+91 98401 54324',
    totalFloors: 4,
  },
  {
    id: 'BLK-003',
    hostelId: 'HST-002',
    blockName: 'Block C - Sarabhai Wing',
    blockCode: 'BLK-C',
    status: 'active',
    description: 'Women’s undergraduate and engineering wing.',
    wardenName: 'Dr. Ananya Roy',
    contactPhone: '+91 98401 54322',
    totalFloors: 4,
  },
  {
    id: 'BLK-004',
    hostelId: 'HST-002',
    blockName: 'Block D - Gargi Wing',
    blockCode: 'BLK-D',
    status: 'active',
    description: 'Women’s research scholars and postgraduate wing.',
    wardenName: 'Prof. Meera Sen',
    contactPhone: '+91 98401 54325',
    totalFloors: 4,
  },
  {
    id: 'BLK-005',
    hostelId: 'HST-003',
    blockName: 'Block E - Kalam Wing',
    blockCode: 'BLK-E',
    status: 'active',
    description: 'Climate-controlled deluxe international suites.',
    wardenName: 'Dr. Vikram Seth',
    contactPhone: '+91 98401 54323',
    totalFloors: 4,
  },
];

let floorsStore: HostelFloor[] = [
  {
    id: 'FLR-A-1',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorNumber: 1,
    floorName: 'Ground Floor',
    status: 'active',
    description: 'Main residential wing with wheelchair access.',
  },
  {
    id: 'FLR-A-2',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorNumber: 2,
    floorName: 'First Floor',
    status: 'active',
    description: 'Second year cohort rooms.',
  },
  {
    id: 'FLR-A-3',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorNumber: 3,
    floorName: 'Second Floor',
    status: 'active',
    description: 'Third year cohort rooms.',
  },
  {
    id: 'FLR-B-1',
    hostelId: 'HST-001',
    blockId: 'BLK-002',
    floorNumber: 1,
    floorName: 'Ground Floor',
    status: 'active',
    description: 'Ramanujan wing ground floor.',
  },
  {
    id: 'FLR-C-1',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorNumber: 1,
    floorName: 'Ground Floor',
    status: 'active',
    description: 'Sarabhai ground floor with reading lounge.',
  },
  {
    id: 'FLR-C-2',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorNumber: 2,
    floorName: 'First Floor',
    status: 'active',
    description: 'Sarabhai upper floor.',
  },
  {
    id: 'FLR-E-1',
    hostelId: 'HST-003',
    blockId: 'BLK-005',
    floorNumber: 1,
    floorName: 'First Floor',
    status: 'active',
    description: 'Kalam suites floor 1.',
  },
];

let roomsStore: HostelRoom[] = [
  {
    id: 'RM-A-101',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-1',
    roomNumber: '101',
    roomType: 'Double',
    capacity: 2,
    status: 'active',
    monthlyRent: 1200,
    amenities: ['Attached Bath', 'Study Desks', 'High-Speed Wi-Fi', 'Wardrobe'],
    description: 'Standard double occupancy room.',
  },
  {
    id: 'RM-A-102',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-1',
    roomNumber: '102',
    roomType: 'Single',
    capacity: 1,
    status: 'active',
    monthlyRent: 1800,
    amenities: ['Balcony', 'Study Desk', 'Wi-Fi', 'Wardrobe'],
    description: 'Single occupancy study suite.',
  },
  {
    id: 'RM-A-201',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-2',
    roomNumber: '201',
    roomType: 'Double',
    capacity: 2,
    status: 'active',
    monthlyRent: 1200,
    amenities: ['Attached Bath', 'Study Desks', 'Wi-Fi'],
    description: 'Standard double room.',
  },
  {
    id: 'RM-A-304',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-3',
    roomNumber: '304',
    roomType: 'Double',
    capacity: 2,
    status: 'active',
    monthlyRent: 1200,
    amenities: ['Study Desks', 'Ceiling Fan', 'Attached Bath'],
    description: 'Double room near study hall.',
  },
  {
    id: 'RM-B-101',
    hostelId: 'HST-001',
    blockId: 'BLK-002',
    floorId: 'FLR-B-1',
    roomNumber: '101',
    roomType: 'Triple',
    capacity: 3,
    status: 'active',
    monthlyRent: 1000,
    amenities: ['Attached Bath', 'Wi-Fi', '3 Desks'],
    description: 'Triple sharing spacious room.',
  },
  {
    id: 'RM-C-101',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorId: 'FLR-C-1',
    roomNumber: '101',
    roomType: 'Double',
    capacity: 2,
    status: 'active',
    monthlyRent: 1200,
    amenities: ['Attached Bath', 'Study Desks', 'Wi-Fi'],
    description: 'Sarabhai double room.',
  },
  {
    id: 'RM-C-201',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorId: 'FLR-C-2',
    roomNumber: '201',
    roomType: 'Single',
    capacity: 1,
    status: 'active',
    monthlyRent: 1800,
    amenities: ['Air Conditioning', 'Study Desk', 'Attached Bath'],
    description: 'Sarabhai single room.',
  },
  {
    id: 'RM-E-101',
    hostelId: 'HST-003',
    blockId: 'BLK-005',
    floorId: 'FLR-E-1',
    roomNumber: '101',
    roomType: 'Double',
    capacity: 2,
    status: 'active',
    monthlyRent: 2200,
    amenities: ['Climate Control', 'Attached Bath', 'Balcony', 'Wi-Fi'],
    description: 'Deluxe double international suite.',
  },
];

let bedsStore: HostelBed[] = [
  // RM-A-101 (Double)
  {
    id: 'BED-A-101-A',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-1',
    roomId: 'RM-A-101',
    bedNumber: 'A',
    status: 'OCCUPIED',
    currentStudentId: 'STU-001',
    currentStudentName: 'Arjun Kumar',
    currentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    currentAllocationId: 'ALT-2026-001',
  },
  {
    id: 'BED-A-101-B',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-1',
    roomId: 'RM-A-101',
    bedNumber: 'B',
    status: 'AVAILABLE',
  },
  // RM-A-102 (Single)
  {
    id: 'BED-A-102-A',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-1',
    roomId: 'RM-A-102',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  // RM-A-201 (Double)
  {
    id: 'BED-A-201-A',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-2',
    roomId: 'RM-A-201',
    bedNumber: 'A',
    status: 'OCCUPIED',
    currentStudentId: 'STU-002',
    currentStudentName: 'Rohan Verma',
    currentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
    currentAllocationId: 'ALT-2026-002',
  },
  {
    id: 'BED-A-201-B',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-2',
    roomId: 'RM-A-201',
    bedNumber: 'B',
    status: 'AVAILABLE',
  },
  // RM-A-304 (Double)
  {
    id: 'BED-A-304-A',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-3',
    roomId: 'RM-A-304',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  {
    id: 'BED-A-304-B',
    hostelId: 'HST-001',
    blockId: 'BLK-001',
    floorId: 'FLR-A-3',
    roomId: 'RM-A-304',
    bedNumber: 'B',
    status: 'BLOCKED',
  },
  // RM-B-101 (Triple)
  {
    id: 'BED-B-101-A',
    hostelId: 'HST-001',
    blockId: 'BLK-002',
    floorId: 'FLR-B-1',
    roomId: 'RM-B-101',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  {
    id: 'BED-B-101-B',
    hostelId: 'HST-001',
    blockId: 'BLK-002',
    floorId: 'FLR-B-1',
    roomId: 'RM-B-101',
    bedNumber: 'B',
    status: 'AVAILABLE',
  },
  {
    id: 'BED-B-101-C',
    hostelId: 'HST-001',
    blockId: 'BLK-002',
    floorId: 'FLR-B-1',
    roomId: 'RM-B-101',
    bedNumber: 'C',
    status: 'AVAILABLE',
  },
  // RM-C-101 (Double)
  {
    id: 'BED-C-101-A',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorId: 'FLR-C-1',
    roomId: 'RM-C-101',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  {
    id: 'BED-C-101-B',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorId: 'FLR-C-1',
    roomId: 'RM-C-101',
    bedNumber: 'B',
    status: 'AVAILABLE',
  },
  // RM-C-201 (Single)
  {
    id: 'BED-C-201-A',
    hostelId: 'HST-002',
    blockId: 'BLK-003',
    floorId: 'FLR-C-2',
    roomId: 'RM-C-201',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  // RM-E-101 (Double)
  {
    id: 'BED-E-101-A',
    hostelId: 'HST-003',
    blockId: 'BLK-005',
    floorId: 'FLR-E-1',
    roomId: 'RM-E-101',
    bedNumber: 'A',
    status: 'AVAILABLE',
  },
  {
    id: 'BED-E-101-B',
    hostelId: 'HST-003',
    blockId: 'BLK-005',
    floorId: 'FLR-E-1',
    roomId: 'RM-E-101',
    bedNumber: 'B',
    status: 'AVAILABLE',
  },
];

let allotmentsStore: HostelAllotment[] = [
  {
    id: 'ALT-2026-001',
    studentId: 'STU-001',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    studentName: 'Arjun Kumar',
    studentGender: 'Male',
    studentClass: 'B.Tech Computer Science & Engineering',
    studentSection: 'A',
    programmeName: 'B.Tech Computer Science & Engineering',
    batchYear: '2026',
    hostelId: 'HST-001',
    hostelName: 'Nilgiri Men’s Residence Hall',
    blockId: 'BLK-001',
    blockName: 'Block A - Aryabhata Wing',
    floorId: 'FLR-A-1',
    floorName: 'Ground Floor',
    roomId: 'RM-A-101',
    roomNumber: '101',
    bedId: 'BED-A-101-A',
    bedNumber: 'A',
    allotmentDate: '2026-08-01',
    academicSession: '2026–2027',
    status: 'Active',
    monthlyRent: 1200,
    allottedBy: 'Hostel Administration Office',
  },
  {
    id: 'ALT-2026-002',
    studentId: 'STU-002',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
    studentName: 'Rohan Verma',
    studentGender: 'Male',
    studentClass: 'B.Tech Computer Science & Engineering',
    studentSection: 'A',
    programmeName: 'B.Tech Computer Science & Engineering',
    batchYear: '2026',
    hostelId: 'HST-001',
    hostelName: 'Nilgiri Men’s Residence Hall',
    blockId: 'BLK-001',
    blockName: 'Block A - Aryabhata Wing',
    floorId: 'FLR-A-2',
    floorName: 'First Floor',
    roomId: 'RM-A-201',
    roomNumber: '201',
    bedId: 'BED-A-201-A',
    bedNumber: 'A',
    allotmentDate: '2026-08-01',
    academicSession: '2026–2027',
    status: 'Active',
    monthlyRent: 1200,
    allottedBy: 'Hostel Administration Office',
  },
];

let allotmentHistoryStore: HostelAllotmentHistory[] = [
  {
    id: 'HST-LOG-001',
    allotmentId: 'ALT-2026-001',
    studentId: 'STU-001',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0001',
    studentName: 'Arjun Kumar',
    action: 'ALLOTMENT',
    previousDetails: 'None',
    newDetails: 'Nilgiri Men’s Residence Hall, Block A, Room 101, Bed A',
    reason: 'Fresh academic session room allocation',
    actorName: 'Hostel Administration Office',
    timestamp: '2026-08-01T09:30:00Z',
  },
  {
    id: 'HST-LOG-002',
    allotmentId: 'ALT-2026-002',
    studentId: 'STU-002',
    studentRegistrationNumber: 'EIT-STU-2026-CSE-0002',
    studentName: 'Rohan Verma',
    action: 'ALLOTMENT',
    previousDetails: 'None',
    newDetails: 'Nilgiri Men’s Residence Hall, Block A, Room 201, Bed A',
    reason: 'Fresh academic session room allocation',
    actorName: 'Hostel Administration Office',
    timestamp: '2026-08-01T10:15:00Z',
  },
];

// Helper to derive counts
function calculateDashboardMetrics(): HostelDashboardMetrics {
  const totalHostels = hostelsStore.length;
  const totalBlocks = blocksStore.length;
  const totalFloors = floorsStore.length;
  const totalRooms = roomsStore.length;
  const totalBeds = bedsStore.length;
  const occupiedBeds = bedsStore.filter((b) => b.status === 'OCCUPIED').length;
  const availableBeds = bedsStore.filter((b) => b.status === 'AVAILABLE').length;
  const blockedBeds = bedsStore.filter((b) => b.status === 'BLOCKED').length;
  const occupancyPercentage =
    totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
  const studentsCurrentlyAllotted = allotmentsStore.filter(
    (a) => a.status === 'Active' || a.status === 'CHECKED_IN'
  ).length;

  return {
    totalHostels,
    totalBlocks,
    totalFloors,
    totalRooms,
    totalBeds,
    occupiedBeds,
    availableBeds,
    blockedBeds,
    occupancyPercentage,
    studentsCurrentlyAllotted,
  };
}

export const hostelRepository = {
  subscribe(listener: Listener) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  async sync(): Promise<void> {
    notify();
  },

  // 1. Dashboard Metrics
  async getDashboardMetrics(): Promise<HostelDashboardMetrics> {
    return calculateDashboardMetrics();
  },

  // 2. Query Collections
  async getAllHostels(): Promise<Hostel[]> {
    return [...hostelsStore];
  },

  async getAllBlocks(): Promise<HostelBlock[]> {
    return [...blocksStore];
  },

  async getAllFloors(): Promise<HostelFloor[]> {
    return [...floorsStore];
  },

  async getAllRooms(): Promise<HostelRoom[]> {
    return [...roomsStore];
  },

  async getAllBeds(): Promise<HostelBed[]> {
    return [...bedsStore];
  },

  async getAllAllotments(): Promise<HostelAllotment[]> {
    return [...allotmentsStore];
  },

  async getAllotmentHistory(): Promise<HostelAllotmentHistory[]> {
    return [...allotmentHistoryStore];
  },

  // 3. Hostel CRUD
  async createHostel(data: Partial<Hostel>, _actor?: any): Promise<Hostel> {
    if (!data.hostelName?.trim()) throw new Error('Hostel name is required.');
    if (!data.hostelCode?.trim()) throw new Error('Hostel code is required.');

    const newHostel: Hostel = {
      id: `HST-${Date.now().toString().slice(-4)}`,
      hostelName: data.hostelName.trim(),
      hostelCode: data.hostelCode.trim().toUpperCase(),
      hostelType: data.hostelType || 'Boys',
      category: data.category || 'Standard',
      status: data.status || 'active',
      address: data.address?.trim() || 'EIT Main Campus',
      description: data.description?.trim(),
      wardenName: data.wardenName?.trim(),
      wardenContact: data.wardenContact?.trim(),
      wardenPhone: data.wardenContact?.trim(),
      name: data.hostelName.trim(),
      blockName: `${data.hostelName.trim()} Main`,
      type: data.hostelType || 'Boys',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    hostelsStore = [...hostelsStore, newHostel];
    notify();
    return newHostel;
  },

  async updateHostel(id: string, data: Partial<Hostel>, _actor?: any): Promise<Hostel> {
    const idx = hostelsStore.findIndex((h) => h.id === id);
    if (idx === -1) throw new Error(`Hostel '${id}' not found.`);

    const updated: Hostel = {
      ...hostelsStore[idx],
      ...data,
      id,
      updatedAt: new Date().toISOString(),
    };
    if (data.hostelName) {
      updated.name = data.hostelName;
    }
    if (data.hostelType) {
      updated.type = data.hostelType;
    }

    hostelsStore = hostelsStore.map((h) => (h.id === id ? updated : h));
    notify();
    return updated;
  },

  async toggleHostelStatus(id: string, _actor?: any): Promise<Hostel> {
    const hostel = hostelsStore.find((h) => h.id === id);
    if (!hostel) throw new Error(`Hostel '${id}' not found.`);
    const nextStatus = hostel.status === 'active' ? 'inactive' : 'active';
    return this.updateHostel(id, { status: nextStatus });
  },

  async deleteHostel(id: string, _actor?: any): Promise<void> {
    // Prevent deletion if referenced by active allotments
    const hasActiveAllotments = allotmentsStore.some(
      (a) => a.hostelId === id && a.status === 'Active'
    );
    if (hasActiveAllotments) {
      throw new Error(
        'Integrity Violation: Cannot delete hostel with active student bed allotments. Vacate or transfer residents first.'
      );
    }

    hostelsStore = hostelsStore.filter((h) => h.id !== id);
    blocksStore = blocksStore.filter((b) => b.hostelId !== id);
    floorsStore = floorsStore.filter((f) => f.hostelId !== id);
    roomsStore = roomsStore.filter((r) => r.hostelId !== id);
    bedsStore = bedsStore.filter((b) => b.hostelId !== id);
    notify();
  },

  // 4. Block CRUD
  async createBlock(data: Partial<HostelBlock>, _actor?: any): Promise<HostelBlock> {
    if (!data.hostelId) throw new Error('Hostel is required to create a block.');
    if (!data.blockName?.trim()) throw new Error('Block name is required.');

    const newBlock: HostelBlock = {
      id: `BLK-${Date.now().toString().slice(-4)}`,
      hostelId: data.hostelId,
      blockName: data.blockName.trim(),
      blockCode: (data.blockCode || data.blockName.slice(0, 3)).trim().toUpperCase(),
      status: data.status || 'active',
      description: data.description?.trim(),
      wardenName: data.wardenName?.trim(),
      contactPhone: data.contactPhone?.trim(),
      totalFloors: data.totalFloors || 1,
    };

    blocksStore = [...blocksStore, newBlock];
    notify();
    return newBlock;
  },

  async updateBlock(id: string, data: Partial<HostelBlock>, _actor?: any): Promise<HostelBlock> {
    const idx = blocksStore.findIndex((b) => b.id === id);
    if (idx === -1) throw new Error(`Block '${id}' not found.`);

    const updated: HostelBlock = { ...blocksStore[idx], ...data, id };
    blocksStore = blocksStore.map((b) => (b.id === id ? updated : b));
    notify();
    return updated;
  },

  async deleteBlock(id: string, _actor?: any): Promise<void> {
    const hasActiveAllotments = allotmentsStore.some(
      (a) => a.blockId === id && a.status === 'Active'
    );
    if (hasActiveAllotments) {
      throw new Error(
        'Integrity Violation: Cannot delete block with active student bed allotments.'
      );
    }

    blocksStore = blocksStore.filter((b) => b.id !== id);
    floorsStore = floorsStore.filter((f) => f.blockId !== id);
    roomsStore = roomsStore.filter((r) => r.blockId !== id);
    bedsStore = bedsStore.filter((b) => b.blockId !== id);
    notify();
  },

  // 5. Floor CRUD
  async createFloor(data: Partial<HostelFloor>, _actor?: any): Promise<HostelFloor> {
    if (!data.blockId) throw new Error('Block is required to create a floor.');
    const block = blocksStore.find((b) => b.id === data.blockId);
    if (!block) throw new Error(`Block '${data.blockId}' not found.`);

    const newFloor: HostelFloor = {
      id: `FLR-${Date.now().toString().slice(-4)}`,
      hostelId: data.hostelId || block.hostelId,
      blockId: data.blockId,
      floorNumber: Number(data.floorNumber) || 1,
      floorName: data.floorName?.trim() || `Floor ${data.floorNumber || 1}`,
      status: data.status || 'active',
      description: data.description?.trim(),
    };

    floorsStore = [...floorsStore, newFloor];
    notify();
    return newFloor;
  },

  async updateFloor(id: string, data: Partial<HostelFloor>, _actor?: any): Promise<HostelFloor> {
    const idx = floorsStore.findIndex((f) => f.id === id);
    if (idx === -1) throw new Error(`Floor '${id}' not found.`);

    const updated: HostelFloor = { ...floorsStore[idx], ...data, id };
    floorsStore = floorsStore.map((f) => (f.id === id ? updated : f));
    notify();
    return updated;
  },

  async deleteFloor(id: string, _actor?: any): Promise<void> {
    const hasActiveAllotments = allotmentsStore.some(
      (a) => a.floorId === id && a.status === 'Active'
    );
    if (hasActiveAllotments) {
      throw new Error('Integrity Violation: Cannot delete floor with active student bed allotments.');
    }

    floorsStore = floorsStore.filter((f) => f.id !== id);
    roomsStore = roomsStore.filter((r) => r.floorId !== id);
    bedsStore = bedsStore.filter((b) => b.floorId !== id);
    notify();
  },

  // 6. Room CRUD
  async createRoom(data: Partial<HostelRoom>, _actor?: any): Promise<HostelRoom> {
    if (!data.floorId) throw new Error('Floor is required to create a room.');
    if (!data.roomNumber?.trim()) throw new Error('Room number is required.');

    const floor = floorsStore.find((f) => f.id === data.floorId);
    if (!floor) throw new Error(`Floor '${data.floorId}' not found.`);
    const block = blocksStore.find((b) => b.id === floor.blockId);
    if (!block) throw new Error(`Block '${floor.blockId}' not found.`);

    // Check duplicate room in block
    const duplicate = roomsStore.find(
      (r) => r.blockId === floor.blockId && r.roomNumber.toLowerCase() === data.roomNumber!.trim().toLowerCase()
    );
    if (duplicate) {
      throw new Error(`Room '${data.roomNumber}' already exists in this block.`);
    }

    const roomId = `RM-${block.blockCode || 'BLK'}-${data.roomNumber.trim()}`;
    const capacity = Number(data.capacity) || 2;

    const newRoom: HostelRoom = {
      id: roomId,
      hostelId: block.hostelId,
      blockId: floor.blockId,
      floorId: floor.id,
      roomNumber: data.roomNumber.trim(),
      roomType: data.roomType || 'Double',
      capacity,
      status: data.status || 'active',
      monthlyRent: Number(data.monthlyRent) || 1200,
      amenities: data.amenities || ['Attached Bath', 'Study Desks', 'Wi-Fi'],
      description: data.description?.trim(),
    };

    roomsStore = [...roomsStore, newRoom];

    // Automatically create configured beds matching room capacity
    const bedLabels = ['A', 'B', 'C', 'D', 'E', 'F'];
    const newBeds: HostelBed[] = [];
    for (let i = 0; i < capacity; i++) {
      const bLabel = bedLabels[i] || `${i + 1}`;
      newBeds.push({
        id: `BED-${roomId}-${bLabel}`,
        hostelId: block.hostelId,
        blockId: floor.blockId,
        floorId: floor.id,
        roomId: newRoom.id,
        bedNumber: bLabel,
        status: 'AVAILABLE',
      });
    }
    bedsStore = [...bedsStore, ...newBeds];

    notify();
    return newRoom;
  },

  async updateRoom(id: string, data: Partial<HostelRoom>, _actor?: any): Promise<HostelRoom> {
    const idx = roomsStore.findIndex((r) => r.id === id);
    if (idx === -1) throw new Error(`Room '${id}' not found.`);

    const room = roomsStore[idx];
    const updated: HostelRoom = { ...room, ...data, id };

    // If room is placed under maintenance, toggle available beds
    if (data.status === 'maintenance') {
      bedsStore = bedsStore.map((b) =>
        b.roomId === id && b.status === 'AVAILABLE' ? { ...b, status: 'BLOCKED' } : b
      );
    } else if (data.status === 'active' && room.status === 'maintenance') {
      bedsStore = bedsStore.map((b) =>
        b.roomId === id && b.status === 'BLOCKED' ? { ...b, status: 'AVAILABLE' } : b
      );
    }

    roomsStore = roomsStore.map((r) => (r.id === id ? updated : r));
    notify();
    return updated;
  },

  async deleteRoom(id: string, _actor?: any): Promise<void> {
    const hasActiveAllotments = allotmentsStore.some(
      (a) => a.roomId === id && a.status === 'Active'
    );
    if (hasActiveAllotments) {
      throw new Error('Integrity Violation: Cannot delete room with active student bed allotments.');
    }

    roomsStore = roomsStore.filter((r) => r.id !== id);
    bedsStore = bedsStore.filter((b) => b.roomId !== id);
    notify();
  },

  // 7. Bed CRUD
  async createBed(data: Partial<HostelBed>, _actor?: any): Promise<HostelBed> {
    if (!data.roomId) throw new Error('Room is required to configure a bed.');
    const room = roomsStore.find((r) => r.id === data.roomId);
    if (!room) throw new Error(`Room '${data.roomId}' not found.`);

    const roomBeds = bedsStore.filter((b) => b.roomId === room.id);
    if (roomBeds.length >= room.capacity) {
      throw new Error(
        `Room Capacity Reached: Room ${room.roomNumber} already has ${roomBeds.length} bed(s) matching maximum capacity (${room.capacity}). Increase room capacity first.`
      );
    }

    const bedNumber = (data.bedNumber || String.fromCharCode(65 + roomBeds.length)).toUpperCase();
    const duplicate = roomBeds.find((b) => b.bedNumber.toUpperCase() === bedNumber);
    if (duplicate) {
      throw new Error(`Bed '${bedNumber}' already exists in Room ${room.roomNumber}.`);
    }

    const newBed: HostelBed = {
      id: `BED-${room.id}-${bedNumber}`,
      hostelId: room.hostelId,
      blockId: room.blockId,
      floorId: room.floorId,
      roomId: room.id,
      bedNumber,
      status: data.status || 'AVAILABLE',
    };

    bedsStore = [...bedsStore, newBed];
    notify();
    return newBed;
  },

  async updateBed(id: string, data: Partial<HostelBed>, _actor?: any): Promise<HostelBed> {
    const idx = bedsStore.findIndex((b) => b.id === id);
    if (idx === -1) throw new Error(`Bed '${id}' not found.`);

    const bed = bedsStore[idx];
    if (bed.status === 'OCCUPIED' && data.status && data.status !== 'OCCUPIED') {
      throw new Error('Cannot change status of an occupied bed. Vacate student allotment first.');
    }

    const updated: HostelBed = { ...bed, ...data, id };
    bedsStore = bedsStore.map((b) => (b.id === id ? updated : b));
    notify();
    return updated;
  },

  async deleteBed(id: string, _actor?: any): Promise<void> {
    const bed = bedsStore.find((b) => b.id === id);
    if (!bed) throw new Error(`Bed '${id}' not found.`);
    if (bed.status === 'OCCUPIED') {
      throw new Error('Integrity Violation: Cannot delete bed currently occupied by an active student.');
    }

    bedsStore = bedsStore.filter((b) => b.id !== id);
    notify();
  },

  // 8. Allotment Operations (University Integrated)
  async createAllotment(data: any, actor?: any): Promise<HostelAllotment> {
    const studentId = data.studentId;
    const studentRegistrationNumber = data.studentRegistrationNumber;
    const bedId = data.bedId;

    if (!studentId || !studentRegistrationNumber) {
      throw new Error('Validation Error: Student identity and official registration number are required.');
    }
    if (!bedId) {
      throw new Error('Validation Error: Please select an available bed.');
    }

    // Check if bed is available
    const bed = bedsStore.find((b) => b.id === bedId);
    if (!bed) throw new Error(`Bed '${bedId}' not found.`);
    if (bed.status === 'BLOCKED') {
      throw new Error('Cannot allocate bed: Bed is blocked for maintenance.');
    }
    if (bed.status === 'OCCUPIED') {
      throw new Error('Cannot allocate bed: Bed is already occupied.');
    }

    // Guard: Check student does not already hold an active allotment
    const existing = allotmentsStore.find(
      (a) =>
        (a.studentId === studentId || a.studentRegistrationNumber === studentRegistrationNumber) &&
        a.status === 'Active'
    );
    if (existing) {
      throw new Error(
        `Duplicate Allotment Guard: Student '${studentRegistrationNumber}' already holds an active allotment in Room ${existing.roomNumber}, Bed ${existing.bedNumber}. Transfer accommodation instead.`
      );
    }

    const room = roomsStore.find((r) => r.id === bed.roomId);
    if (!room) throw new Error('Designated room record not found.');
    const block = blocksStore.find((b) => b.id === room.blockId);
    const floor = floorsStore.find((f) => f.id === room.floorId);
    const hostel = hostelsStore.find((h) => h.id === room.hostelId);

    const allotmentId = `ALT-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`;
    const allottedBy =
      data.allottedBy || actor?.name || actor?.username || 'Hostel Administration Office';

    const newAllotment: HostelAllotment = {
      id: allotmentId,
      studentId,
      studentRegistrationNumber,
      studentName: data.studentName || 'Resident Student',
      studentGender: data.studentGender,
      studentClass: data.studentClass || 'B.Tech',
      studentSection: data.studentSection || 'A',
      programmeName: data.programmeName || data.studentClass || 'B.Tech',
      batchYear: data.batchYear || '2026',
      hostelId: room.hostelId,
      hostelName: hostel?.hostelName || 'EIT Residence Hall',
      blockId: room.blockId,
      blockName: block?.blockName || 'Residential Block',
      floorId: room.floorId,
      floorName: floor?.floorName || 'Floor 1',
      roomId: room.id,
      roomNumber: room.roomNumber,
      bedId: bed.id,
      bedNumber: bed.bedNumber,
      allotmentDate: data.allotmentDate || new Date().toISOString().split('T')[0],
      academicSession: data.academicSession || '2026–2027',
      status: 'Active',
      monthlyRent: room.monthlyRent || 1200,
      allottedBy,
      remarks: data.remarks || 'Standard hostel allocation',
    };

    allotmentsStore = [newAllotment, ...allotmentsStore];

    // Mark bed as OCCUPIED
    bedsStore = bedsStore.map((b) =>
      b.id === bed.id
        ? {
            ...b,
            status: 'OCCUPIED',
            currentStudentId: studentId,
            currentStudentName: data.studentName,
            currentRegistrationNumber: studentRegistrationNumber,
            currentAllocationId: allotmentId,
          }
        : b
    );

    // Record movement history
    const historyEntry: HostelAllotmentHistory = {
      id: `HST-LOG-${Date.now().toString().slice(-6)}`,
      allotmentId,
      studentId,
      studentRegistrationNumber,
      studentName: data.studentName || 'Resident Student',
      action: 'ALLOTMENT',
      previousDetails: 'None (Fresh Allotment)',
      newDetails: `${hostel?.hostelName || 'Hostel'}, ${block?.blockName || 'Block'}, Room ${room.roomNumber}, Bed ${bed.bedNumber}`,
      reason: data.remarks || 'Fresh student residential allotment',
      actorName: allottedBy,
      timestamp: new Date().toISOString(),
    };
    allotmentHistoryStore = [historyEntry, ...allotmentHistoryStore];

    // Forward hostel fee charge request to Finance Office workflow (Stage G)
    try {
      if (devDataAdapter?.hostel?.createChargeRequest) {
        await devDataAdapter.hostel.createChargeRequest(
          {
            allocation_id: allotmentId,
            student_id: studentId,
            registration_number: studentRegistrationNumber,
            amount: room.monthlyRent || 1200,
            description: `Hostel Room & Residence Charge - ${newAllotment.academicSession} (${newAllotment.roomNumber}-${newAllotment.bedNumber})`,
          },
          { userId: 'hosteloffice', role: 'OFFICE_ADMIN' }
        );
      }
    } catch (e) {
      console.warn('Finance hostel charge request sync:', e);
    }

    notify();
    return newAllotment;
  },

  async transferAllotment(
    dataOrId: any,
    newBedIdArg?: string,
    reasonArg?: string,
    actor?: any
  ): Promise<HostelAllotment> {
    const allotmentId = typeof dataOrId === 'string' ? dataOrId : dataOrId?.allotmentId;
    const newBedId = typeof dataOrId === 'string' ? newBedIdArg : dataOrId?.newBedId;
    const reason = typeof dataOrId === 'string' ? reasonArg : (dataOrId?.reason || dataOrId?.actionReason);
    const transferredBy =
      (typeof dataOrId === 'object' && dataOrId?.transferredBy) ||
      actor?.name ||
      actor?.username ||
      'Hostel Administration Office';

    if (!reason || !reason.trim()) {
      throw new Error('Validation Error: A mandatory administrative reason is required for room transfer.');
    }
    if (!newBedId) {
      throw new Error('Validation Error: Destination bed selection is required.');
    }

    const allocIdx = allotmentsStore.findIndex((a) => a.id === allotmentId);
    if (allocIdx === -1) throw new Error(`Hostel allotment '${allotmentId}' not found.`);
    const currentAlloc = allotmentsStore[allocIdx];

    if (currentAlloc.status !== 'Active') {
      throw new Error(`Cannot transfer student with allotment status '${currentAlloc.status}'.`);
    }

    const targetBed = bedsStore.find((b) => b.id === newBedId);
    if (!targetBed) throw new Error(`Destination bed '${newBedId}' not found.`);
    if (targetBed.status === 'BLOCKED') {
      throw new Error('Cannot transfer to blocked bed.');
    }
    if (targetBed.status === 'OCCUPIED') {
      throw new Error('Cannot transfer to already occupied bed.');
    }

    const oldBedId = currentAlloc.bedId;
    const newRoom = roomsStore.find((r) => r.id === targetBed.roomId);
    const newBlock = blocksStore.find((b) => b.id === newRoom?.blockId);
    const newFloor = floorsStore.find((f) => f.id === newRoom?.floorId);
    const newHostel = hostelsStore.find((h) => h.id === newRoom?.hostelId);

    // Release old bed
    bedsStore = bedsStore.map((b) =>
      b.id === oldBedId
        ? {
            ...b,
            status: 'AVAILABLE',
            currentStudentId: undefined,
            currentStudentName: undefined,
            currentRegistrationNumber: undefined,
            currentAllocationId: undefined,
          }
        : b
    );

    // Occupy new bed
    bedsStore = bedsStore.map((b) =>
      b.id === targetBed.id
        ? {
            ...b,
            status: 'OCCUPIED',
            currentStudentId: currentAlloc.studentId,
            currentStudentName: currentAlloc.studentName,
            currentRegistrationNumber: currentAlloc.studentRegistrationNumber,
            currentAllocationId: currentAlloc.id,
          }
        : b
    );

    const prevDetails = `${currentAlloc.hostelName}, ${currentAlloc.blockName}, Room ${currentAlloc.roomNumber}, Bed ${currentAlloc.bedNumber}`;
    const nextDetails = `${newHostel?.hostelName || 'Hostel'}, ${newBlock?.blockName || 'Block'}, Room ${newRoom?.roomNumber}, Bed ${targetBed.bedNumber}`;

    const updatedAlloc: HostelAllotment = {
      ...currentAlloc,
      hostelId: newRoom?.hostelId || currentAlloc.hostelId,
      hostelName: newHostel?.hostelName || currentAlloc.hostelName,
      blockId: newRoom?.blockId || currentAlloc.blockId,
      blockName: newBlock?.blockName || currentAlloc.blockName,
      floorId: newRoom?.floorId || currentAlloc.floorId,
      floorName: newFloor?.floorName || currentAlloc.floorName,
      roomId: newRoom?.id || currentAlloc.roomId,
      roomNumber: newRoom?.roomNumber || currentAlloc.roomNumber,
      bedId: targetBed.id,
      bedNumber: targetBed.bedNumber,
      transferDate: new Date().toISOString().split('T')[0],
      transferReason: reason.trim(),
    };

    allotmentsStore = allotmentsStore.map((a) => (a.id === allotmentId ? updatedAlloc : a));

    // Record movement history
    const historyEntry: HostelAllotmentHistory = {
      id: `HST-LOG-${Date.now().toString().slice(-6)}`,
      allotmentId: currentAlloc.id,
      studentId: currentAlloc.studentId,
      studentRegistrationNumber: currentAlloc.studentRegistrationNumber,
      studentName: currentAlloc.studentName,
      action: 'TRANSFER',
      previousDetails: prevDetails,
      newDetails: nextDetails,
      reason: reason.trim(),
      actorName: transferredBy,
      timestamp: new Date().toISOString(),
    };
    allotmentHistoryStore = [historyEntry, ...allotmentHistoryStore];

    notify();
    return updatedAlloc;
  },

  async vacateAllotment(
    dataOrId: any,
    reasonArg?: string,
    actor?: any
  ): Promise<HostelAllotment> {
    const allotmentId = typeof dataOrId === 'string' ? dataOrId : dataOrId?.allotmentId;
    const reason = typeof dataOrId === 'string' ? reasonArg : (dataOrId?.reason || dataOrId?.actionReason);
    const vacatedBy =
      (typeof dataOrId === 'object' && dataOrId?.vacatedBy) ||
      actor?.name ||
      actor?.username ||
      'Hostel Administration Office';

    if (!reason || !reason.trim()) {
      throw new Error('Validation Error: A vacate clearance reason is required.');
    }

    const allocIdx = allotmentsStore.findIndex((a) => a.id === allotmentId);
    if (allocIdx === -1) throw new Error(`Hostel allotment '${allotmentId}' not found.`);
    const currentAlloc = allotmentsStore[allocIdx];

    // Release bed
    bedsStore = bedsStore.map((b) =>
      b.id === currentAlloc.bedId
        ? {
            ...b,
            status: 'AVAILABLE',
            currentStudentId: undefined,
            currentStudentName: undefined,
            currentRegistrationNumber: undefined,
            currentAllocationId: undefined,
          }
        : b
    );

    const updatedAlloc: HostelAllotment = {
      ...currentAlloc,
      status: 'Vacated',
      vacateDate: new Date().toISOString().split('T')[0],
      vacateReason: reason.trim(),
    };

    allotmentsStore = allotmentsStore.map((a) => (a.id === allotmentId ? updatedAlloc : a));

    // Record movement history
    const historyEntry: HostelAllotmentHistory = {
      id: `HST-LOG-${Date.now().toString().slice(-6)}`,
      allotmentId: currentAlloc.id,
      studentId: currentAlloc.studentId,
      studentRegistrationNumber: currentAlloc.studentRegistrationNumber,
      studentName: currentAlloc.studentName,
      action: 'VACATE',
      previousDetails: `${currentAlloc.hostelName}, Room ${currentAlloc.roomNumber}, Bed ${currentAlloc.bedNumber}`,
      newDetails: 'Accommodation Vacated & Released',
      reason: reason.trim(),
      actorName: vacatedBy,
      timestamp: new Date().toISOString(),
    };
    allotmentHistoryStore = [historyEntry, ...allotmentHistoryStore];

    notify();
    return updatedAlloc;
  },

  // Student Portal Compatibility Lookups
  async getActiveAllotmentForStudent(studentIdOrReg: string): Promise<HostelAllotment | null> {
    if (!studentIdOrReg) return null;
    const clean = studentIdOrReg.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

    const found = allotmentsStore.find((a) => {
      if (a.status !== 'Active') return false;
      const sId = (a.studentId || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      const sReg = (a.studentRegistrationNumber || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      return sId === clean || sReg === clean;
    });

    return found ? { ...found } : null;
  },

  async getHostelById(hostelId: string): Promise<Hostel | null> {
    const found = hostelsStore.find((h) => h.id === hostelId);
    return found ? { ...found } : null;
  },
};
