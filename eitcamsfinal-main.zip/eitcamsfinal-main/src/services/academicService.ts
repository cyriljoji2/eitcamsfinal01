import { devDataAdapter } from './devDataAdapter';
import {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  FacultyAssignment,
  AcademicDepartment,
  AcademicCurriculumEntry,
  CsvCurriculumValidationResult,
  StudentAcademicSummary,
  BulkEnrolmentRequest,
  BulkEnrolmentPreReview,
  BulkEnrolmentResult,
  CsvImportPreviewReport,
  TimetableValidationResult,
} from '../types/academic';
import {
  AttendanceRecord,
  CourseOfferingRecord,
  CourseEnrolmentRecord,
  TimetableSlotRecord,
  FacultyCourseRole,
  TimetableVersionRecord,
  CsvImportBatchRecord,
  AuthRole,
} from '../types/database';
import { proctorRepository } from './proctorService';

export const academicRepository = {
  // --- Departments ---
  async getAllDepartments(): Promise<AcademicDepartment[]> {
    const depts = await devDataAdapter.academic.getDepartments();
    const emps = await devDataAdapter.employees.getAll();

    return depts.map((d) => {
      const hod = d.head_of_department_id
        ? emps.find((e) => e.employee_id === d.head_of_department_id)
        : null;
      return {
        id: d.department_id,
        code: d.code,
        name: d.name,
        headOfDepartmentId: d.head_of_department_id,
        headOfDepartmentName: hod ? `${hod.first_name} ${hod.last_name}` : undefined,
        description: d.description,
        status: d.status === 'ACTIVE' ? 'active' : 'inactive',
      };
    });
  },

  async createDepartment(data: Omit<AcademicDepartment, 'id' | 'createdAt'>): Promise<AcademicDepartment> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    const newId = `DEPT-${data.code.toUpperCase()}`;
    const newDept = {
      department_id: newId,
      code: data.code.toUpperCase(),
      name: data.name,
      description: data.description || '',
      head_of_department_id: data.headOfDepartmentId,
      status: (data.status === 'active' ? 'ACTIVE' : 'INACTIVE') as 'ACTIVE' | 'INACTIVE',
    };
    if (state) {
      state.departments = [...(state.departments || []), newDept];
      (devDataAdapter as any).saveState(state);
    }
    return {
      id: newId,
      code: newDept.code,
      name: newDept.name,
      headOfDepartmentId: newDept.head_of_department_id,
      description: newDept.description,
      status: data.status,
    };
  },

  async updateDepartment(id: string, data: Partial<AcademicDepartment>): Promise<AcademicDepartment> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.departments) {
      state.departments = state.departments.map((d: any) =>
        d.department_id === id
          ? {
              ...d,
              ...(data.name ? { name: data.name } : {}),
              ...(data.code ? { code: data.code.toUpperCase() } : {}),
              ...(data.description !== undefined ? { description: data.description } : {}),
              ...(data.headOfDepartmentId !== undefined ? { head_of_department_id: data.headOfDepartmentId } : {}),
              ...(data.status ? { status: data.status === 'active' ? 'ACTIVE' : 'INACTIVE' } : {}),
            }
          : d
      );
      (devDataAdapter as any).saveState(state);
    }
    const all = await this.getAllDepartments();
    return all.find((d) => d.id === id) || (data as any);
  },

  async toggleDepartmentStatus(id: string): Promise<AcademicDepartment> {
    const depts = await this.getAllDepartments();
    const target = depts.find((d) => d.id === id);
    if (!target) throw new Error(`Department ${id} not found.`);
    const newStatus = target.status === 'active' ? 'inactive' : 'active';
    return this.updateDepartment(id, { status: newStatus });
  },

  async deleteDepartment(id: string): Promise<boolean> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.departments) {
      state.departments = state.departments.filter((d: any) => d.department_id !== id);
      (devDataAdapter as any).saveState(state);
    }
    return true;
  },

  // --- Sessions ---
  async getSessions(): Promise<AcademicSession[]> {
    const years = await devDataAdapter.academic.getAcademicYears();
    return years.map((y) => ({
      id: y.year_id || y.code,
      name: y.name || y.code,
      isCurrent: y.is_current,
      startDate: y.start_date,
      endDate: y.end_date,
      status: y.is_current ? 'active' : 'upcoming',
    }));
  },

  async getAllSessions(): Promise<AcademicSession[]> {
    return this.getSessions();
  },

  async createSession(data: Omit<AcademicSession, 'id' | 'isCurrent'> & { id?: string }): Promise<AcademicSession> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    const newId = data.id || `AY-${data.name.replace(/[^0-9-]/g, '')}`;
    const newYear = {
      year_id: newId,
      code: data.name,
      name: `Academic Year ${data.name}`,
      start_date: data.startDate || '2026-07-01',
      end_date: data.endDate || '2027-05-31',
      is_current: false,
    };
    if (state) {
      state.academicYears = [...(state.academicYears || []), newYear];
      (devDataAdapter as any).saveState(state);
    }
    return {
      id: newId,
      name: data.name,
      isCurrent: false,
      startDate: newYear.start_date,
      endDate: newYear.end_date,
      status: 'upcoming',
    };
  },

  async setCurrentSession(id: string): Promise<AcademicSession> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.academicYears) {
      state.academicYears = state.academicYears.map((y: any) => ({
        ...y,
        is_current: y.year_id === id || y.code === id,
      }));
      (devDataAdapter as any).saveState(state);
    }
    const sessions = await this.getSessions();
    return sessions.find((s) => s.id === id) || sessions[0];
  },

  // --- Classes / Programs ---
  async getClasses(): Promise<AcademicClass[]> {
    const progs = await devDataAdapter.academic.getProgrammes();
    return progs.map((p) => ({
      id: p.programme_id,
      name: p.name,
      code: p.code,
      department: p.department,
      programType: p.degree_level === 'UNDERGRADUATE' ? 'Undergraduate' : 'Postgraduate',
      durationYears: Math.round(p.duration_semesters / 2),
      totalSemesters: p.duration_semesters,
      currentNumericClass: 1,
      stream: p.department,
      status: p.status === 'ACTIVE' ? 'active' : 'inactive',
    }));
  },

  async getAllClasses(): Promise<AcademicClass[]> {
    return this.getClasses();
  },

  async createClass(data: Omit<AcademicClass, 'id' | 'createdAt'>): Promise<AcademicClass> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    const newCode = (data.code || data.name.toUpperCase().replace(/\s+/g, '-')).slice(0, 15);
    const newId = `PRG-${newCode}`;
    const newProg: any = {
      programme_id: newId,
      code: newCode,
      name: data.name,
      department: data.department || 'CSE',
      degree_level: (data.programType?.includes('Post') ? 'POSTGRADUATE' : 'UNDERGRADUATE'),
      duration_semesters: data.totalSemesters || ((data.durationYears || 4) * 2),
      total_credits_required: 160,
      status: (data.status === 'inactive' ? 'INACTIVE' : 'ACTIVE') as 'ACTIVE' | 'INACTIVE',
    };
    if (state) {
      state.programmes = [...(state.programmes || []), newProg];
      (devDataAdapter as any).saveState(state);
    }
    return {
      id: newId,
      name: newProg.name,
      code: newProg.code,
      department: newProg.department,
      programType: data.programType || 'Undergraduate',
      durationYears: Math.round(newProg.duration_semesters / 2),
      totalSemesters: newProg.duration_semesters,
      status: data.status || 'active',
    };
  },

  async updateClass(id: string, data: Partial<AcademicClass>): Promise<AcademicClass> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.programmes) {
      state.programmes = state.programmes.map((p: any) =>
        p.programme_id === id
          ? {
              ...p,
              ...(data.name ? { name: data.name } : {}),
              ...(data.code ? { code: data.code } : {}),
              ...(data.department ? { department: data.department } : {}),
              ...(data.totalSemesters ? { duration_semesters: data.totalSemesters } : {}),
              ...(data.status ? { status: data.status === 'active' ? 'ACTIVE' : 'INACTIVE' } : {}),
            }
          : p
      );
      (devDataAdapter as any).saveState(state);
    }
    const all = await this.getClasses();
    return all.find((c) => c.id === id) || (data as any);
  },

  async toggleClassStatus(id: string): Promise<AcademicClass> {
    const all = await this.getClasses();
    const target = all.find((c) => c.id === id);
    if (!target) throw new Error(`Class ${id} not found.`);
    const newStatus = target.status === 'active' ? 'inactive' : 'active';
    return this.updateClass(id, { status: newStatus });
  },

  async deleteClass(id: string): Promise<boolean> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.programmes) {
      state.programmes = state.programmes.filter((p: any) => p.programme_id !== id);
      (devDataAdapter as any).saveState(state);
    }
    return true;
  },

  // --- Sections ---
  async getSections(): Promise<AcademicSection[]> {
    const secs = await devDataAdapter.academic.getSections();
    return secs.map((s) => ({
      id: s.section_id,
      name: s.section_name,
      classId: s.programme_code,
      className: s.programme_code,
      batchYear: s.academic_year?.split('-')[0] || '2026',
      currentSemester: `Semester ${s.semester}`,
      academicSession: s.academic_year,
      capacity: s.max_capacity,
      status: s.status === 'ACTIVE' ? 'active' : 'inactive',
    }));
  },

  async getAllSections(): Promise<AcademicSection[]> {
    return this.getSections();
  },

  async createSection(data: any): Promise<AcademicSection> {
    const record = await devDataAdapter.academic.createSection({
      section_name: data.name || data.section_name || 'A',
      department: data.department || 'CSE',
      programme_code: data.classId || data.programme_code || 'BTECH-CSE',
      academic_year: data.academicSession || data.academic_year || '2026-2027',
      semester: typeof data.semester === 'number' ? data.semester : 1,
      max_capacity: data.capacity || data.max_capacity || 60,
      status: data.status === 'inactive' ? 'ARCHIVED' : 'ACTIVE',
    });
    return {
      id: record.section_id,
      name: record.section_name,
      classId: record.programme_code,
      className: record.programme_code,
      capacity: record.max_capacity,
      status: record.status === 'ACTIVE' ? 'active' : 'inactive',
    };
  },

  async updateSection(id: string, data: Partial<AcademicSection>): Promise<AcademicSection> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.sections) {
      state.sections = state.sections.map((s: any) =>
        s.section_id === id
          ? {
              ...s,
              ...(data.name ? { section_name: data.name } : {}),
              ...(data.capacity ? { max_capacity: data.capacity } : {}),
              ...(data.status ? { status: data.status === 'active' ? 'ACTIVE' : 'ARCHIVED' } : {}),
            }
          : s
      );
      (devDataAdapter as any).saveState(state);
    }
    const all = await this.getSections();
    return all.find((s) => s.id === id) || (data as any);
  },

  async toggleSectionStatus(id: string): Promise<AcademicSection> {
    const all = await this.getSections();
    const target = all.find((s) => s.id === id);
    if (!target) throw new Error(`Section ${id} not found.`);
    const newStatus = target.status === 'active' ? 'inactive' : 'active';
    return this.updateSection(id, { status: newStatus });
  },

  async deleteSection(id: string): Promise<boolean> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.sections) {
      state.sections = state.sections.filter((s: any) => s.section_id !== id);
      (devDataAdapter as any).saveState(state);
    }
    return true;
  },

  // --- Subjects / Courses ---
  async getSubjects(): Promise<AcademicSubject[]> {
    const courses = await devDataAdapter.academic.getCourses();
    return courses.map((c) => ({
      id: c.course_id,
      code: c.course_code,
      name: c.course_title,
      credits: c.credits,
      type: c.course_type,
      category: c.department,
      department: c.department,
      semester: c.semester,
      classId: c.programme_code,
      className: c.programme_code,
      status: c.status === 'ACTIVE' ? 'active' : 'inactive',
    }));
  },

  async createSubject(data: any): Promise<AcademicSubject> {
    const record = await devDataAdapter.academic.createCourse({
      course_code: data.code || data.course_code,
      course_title: data.name || data.course_title,
      department: data.department || data.category || 'CSE',
      programme_code: data.classId || data.programme_code || 'BTECH-CSE',
      semester: typeof data.semester === 'number' ? data.semester : 1,
      credits: Number(data.credits) || 4,
      course_type: data.type || data.course_type || 'Theory',
      status: (data.status === 'inactive' ? 'ARCHIVED' : 'ACTIVE') as 'ACTIVE' | 'ARCHIVED',
    });
    return {
      id: record.course_id,
      code: record.course_code,
      name: record.course_title,
      credits: record.credits,
      type: record.course_type,
      department: record.department,
      status: record.status === 'ACTIVE' ? 'active' : 'inactive',
    };
  },

  async updateSubject(id: string, data: Partial<AcademicSubject>): Promise<AcademicSubject> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.courses) {
      state.courses = state.courses.map((c: any) =>
        c.course_id === id
          ? {
              ...c,
              ...(data.name ? { course_title: data.name } : {}),
              ...(data.credits ? { credits: Number(data.credits) } : {}),
              ...(data.type ? { course_type: data.type } : {}),
              ...(data.department ? { department: data.department } : {}),
              ...(data.status ? { status: data.status === 'active' ? 'ACTIVE' : 'ARCHIVED' } : {}),
            }
          : c
      );
      (devDataAdapter as any).saveState(state);
    }
    const all = await this.getSubjects();
    return all.find((s) => s.id === id) || (data as any);
  },

  async toggleSubjectStatus(id: string): Promise<AcademicSubject> {
    const all = await this.getSubjects();
    const target = all.find((s) => s.id === id);
    if (!target) throw new Error(`Subject ${id} not found.`);
    const newStatus = target.status === 'active' ? 'inactive' : 'active';
    return this.updateSubject(id, { status: newStatus });
  },

  async deleteSubject(id: string): Promise<boolean> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.courses) {
      state.courses = state.courses.filter((c: any) => c.course_id !== id);
      (devDataAdapter as any).saveState(state);
    }
    return true;
  },

  // --- Faculty Assignments ---
  async getFacultyAssignments(): Promise<FacultyAssignment[]> {
    const asgs = await devDataAdapter.facultyAssignments.getAll();
    const emps = await devDataAdapter.employees.getAll();
    return asgs.map((a) => {
      const emp = emps.find((e) => e.employee_id === a.employee_id);
      return {
        id: a.faculty_assignment_id,
        facultyId: a.employee_id,
        facultyName: emp ? `${emp.first_name} ${emp.last_name}` : a.employee_id,
        facultyEmail: emp?.institutional_email,
        subjectCode: a.course_code,
        subjectName: a.course_title,
        section: a.section,
        semester: a.semester,
        academicYear: a.academic_year,
        department: a.department,
        status: a.assignment_status === 'ACTIVE' ? 'active' : 'completed',
        roleInCourse: a.role_in_course,
      };
    });
  },

  async getAllFacultyAssignments(): Promise<FacultyAssignment[]> {
    return this.getFacultyAssignments();
  },

  async createFacultyAssignment(data: any): Promise<FacultyAssignment> {
    const record = await devDataAdapter.academic.assignFaculty({
      employee_id: data.facultyId || data.employee_id,
      course_code: data.subjectCode || data.course_code,
      course_title: data.subjectName || data.course_title,
      department: data.department || 'CSE',
      semester: typeof data.semester === 'number' ? data.semester : 3,
      academic_year: data.academicYear || data.academic_year || '2026-2027',
      section: data.section || 'A',
      role_in_course: (data.roleInCourse || 'PRIMARY_INSTRUCTOR') as FacultyCourseRole,
    });
    const emps = await devDataAdapter.employees.getAll();
    const emp = emps.find((e) => e.employee_id === record.employee_id);
    return {
      id: record.faculty_assignment_id,
      facultyId: record.employee_id,
      facultyName: emp ? `${emp.first_name} ${emp.last_name}` : record.employee_id,
      facultyEmail: emp?.institutional_email,
      subjectCode: record.course_code,
      subjectName: record.course_title,
      section: record.section,
      semester: record.semester,
      academicYear: record.academic_year,
      department: record.department,
      status: 'active',
    };
  },

  async updateFacultyAssignment(id: string, data: Partial<FacultyAssignment>): Promise<FacultyAssignment> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.facultyAssignments) {
      state.facultyAssignments = state.facultyAssignments.map((f: any) =>
        f.faculty_assignment_id === id
          ? {
              ...f,
              ...(data.facultyId ? { employee_id: data.facultyId } : {}),
              ...(data.section ? { section: data.section } : {}),
            }
          : f
      );
      (devDataAdapter as any).saveState(state);
    }
    const all = await this.getFacultyAssignments();
    return all.find((a) => a.id === id) || (data as any);
  },

  async deleteFacultyAssignment(id: string): Promise<boolean> {
    await devDataAdapter.academic.endFacultyAssignment(id, 'Deallocated by Academic Office');
    return true;
  },

  // --- Attendance ---
  async getAttendanceRecords(): Promise<AttendanceRecord[]> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    return state?.attendance || [];
  },

  async saveBatchAttendance(records: Omit<AttendanceRecord, 'id' | 'recordedAt'>[]): Promise<AttendanceRecord[]> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    const created: AttendanceRecord[] = [];
    if (state) {
      for (const r of records) {
        const attId = `ATT-2026-${String((state.attendance?.length || 0) + 1).padStart(4, '0')}`;
        const rec = {
          attendance_id: attId,
          student_id: (r as any).studentId || (r as any).student_id,
          student_registration_number: (r as any).studentRegistrationNumber || (r as any).student_registration_number,
          course_code: (r as any).course_code || (r as any).subjectCode || 'CS201',
          section: (r as any).section || 'A',
          date: (r as any).date || new Date().toISOString().split('T')[0],
          session_slot: (r as any).session_slot || 'SLOT-1',
          status: (r as any).status || 'PRESENT',
          remarks: (r as any).remarks || '',
          created_at: new Date().toISOString(),
        };
        state.attendance = [...(state.attendance || []), rec];
        created.push(rec as any);
      }
      (devDataAdapter as any).saveState(state);
    }
    return created;
  },

  // --- Student Reassignment & Profile ---
  async reassignStudent(studentIdOrRegNo: string, newClassName: string, newSectionName: string): Promise<any> {
    const students = await devDataAdapter.students.getAll();
    const st = students.find(
      (s) => s.student_id === studentIdOrRegNo || s.registration_number === studentIdOrRegNo
    );
    if (!st) throw new Error(`Student ${studentIdOrRegNo} not found.`);

    // If active enrolment exists, transfer section
    const enrolments = await devDataAdapter.academic.getEnrolments({ student_id: st.student_id });
    if (enrolments.length > 0) {
      for (const enr of enrolments) {
        if (enr.enrolment_status === 'ACTIVE' && enr.section !== newSectionName) {
          await devDataAdapter.academic.transferStudentSection(
            enr.enrolment_id,
            newSectionName,
            `Academic Office Reassignment to ${newClassName} Sec ${newSectionName}`
          );
        }
      }
    }
    return st;
  },

  async getStudentAcademicProfile(
    registrationNumber: string,
    actor?: { userId?: string; role?: string; employeeId?: string }
  ): Promise<StudentAcademicSummary> {
    const students = await devDataAdapter.students.getAll();
    const student = students.find(
      (s) => s.registration_number.toLowerCase() === registrationNumber.toLowerCase() || s.student_id === registrationNumber
    );
    if (!student) throw new Error(`Student with registration ${registrationNumber} not found.`);

    const enrolments = await devDataAdapter.academic.getEnrolments({ student_id: student.student_id });
    const faculty = await devDataAdapter.facultyAssignments.getAll();
    const courses = await devDataAdapter.academic.getCourses();
    const proctorAsg = await proctorRepository.getActiveAssignmentForStudent(student.registration_number);

    // Enforce faculty data scoping: Faculty can only view academic profile if the student is in their assigned course/section or their active proctee
    if (actor && (actor.role === AuthRole.FACULTY || actor.role === 'FACULTY')) {
      const empId = (actor.employeeId || actor.userId || '').toLowerCase();
      const isProctor =
        proctorAsg &&
        proctorAsg.status === 'active' &&
        (proctorAsg.facultyId.toLowerCase() === empId ||
          (actor.employeeId && proctorAsg.facultyId.toLowerCase() === actor.employeeId.toLowerCase()) ||
          (actor.userId && proctorAsg.facultyName.toLowerCase().includes(actor.userId.toLowerCase())));

      const isEnrolledInFacultyCourse = enrolments.some((e) => {
        if (e.enrolment_status !== 'ACTIVE') return false;
        return faculty.some(
          (fac) =>
            fac.employee_id.toLowerCase() === empId &&
            fac.course_code === e.course_code &&
            fac.section === e.section &&
            fac.assignment_status === 'ACTIVE'
        );
      });

      if (!isProctor && !isEnrolledInFacultyCourse) {
        throw new Error(
          `Unauthorized: Faculty member '${actor.userId || actor.employeeId}' is not authorized to access academic profile for student '${registrationNumber}'.`
        );
      }
    }

    const enrolledCourses = enrolments
      .filter((e) => e.enrolment_status === 'ACTIVE')
      .map((e) => {
        const c = courses.find((course) => course.course_code === e.course_code);
        const f = faculty.find(
          (fac) => fac.course_code === e.course_code && fac.section === e.section && fac.assignment_status === 'ACTIVE'
        );
        return {
          code: e.course_code,
          title: e.course_title,
          credits: c?.credits || 4,
          section: e.section,
          facultyName: f?.employee_name,
        };
      });

    const totalCredits = enrolledCourses.reduce((sum, item) => sum + item.credits, 0);

    const attRecords = await this.getAttendanceRecords();
    const studentAtt = attRecords.filter(
      (a: any) =>
        a.student_id === student.student_id ||
        a.student_registration_number === student.registration_number ||
        a.studentId === student.student_id
    );
    const presentCount = studentAtt.filter((a: any) => a.status === 'Present' || a.status === 'PRESENT').length;
    const attendanceRate = studentAtt.length > 0 ? Math.round((presentCount / studentAtt.length) * 100) : 95;

    return {
      studentId: student.student_id,
      fullName: `${student.first_name} ${student.last_name}`,
      registrationNumber: student.registration_number,
      program: student.program_name || 'B.Tech CSE',
      batch: student.current_semester ? `Semester ${student.current_semester}` : '2026',
      currentSemester: `Semester ${student.current_semester || 3}`,
      section: enrolments[0]?.section || 'A',
      status: student.enrollment_status,
      email: student.institutional_email,
      mobile: student.personal_phone,
      enrolledCourses,
      totalCredits,
      proctor: proctorAsg
        ? {
            name: proctorAsg.facultyName,
            email: proctorAsg.facultyEmail,
            phone: proctorAsg.facultyPhone,
            department: proctorAsg.facultyDepartment,
          }
        : null,
      attendanceRate,
    };
  },

  // --- Curriculum Methods ---
  async getAllCurriculum(): Promise<AcademicCurriculumEntry[]> {
    const courses = await devDataAdapter.academic.getCourses();
    return courses.map((c) => ({
      id: c.course_id,
      courseCode: c.course_code,
      courseTitle: c.course_title,
      courseName: c.course_title,
      credits: c.credits,
      courseType: c.course_type,
      type: c.course_type,
      category: c.department,
      basket: 'Programme Core',
      semester: c.semester,
      department: c.department,
      programme: c.programme_code,
    }));
  },

  async getCurriculumByProgramAndBatch(_program: string, _batch: string): Promise<AcademicCurriculumEntry[]> {
    return this.getAllCurriculum();
  },

  async importCurriculumEntries(entries: any[]): Promise<{ added: number; updated: number }> {
    let added = 0;
    let updated = 0;
    const existing = await devDataAdapter.academic.getCourses();
    for (const item of entries) {
      const match = existing.find((c) => c.course_code.toUpperCase() === item.course_code.toUpperCase());
      if (match) {
        await this.updateSubject(match.course_id, {
          name: item.course_title || match.course_title,
          credits: Number(item.credits) || match.credits,
          department: item.department || match.department,
        });
        updated++;
      } else {
        await devDataAdapter.academic.createCourse({
          course_code: item.course_code.toUpperCase(),
          course_title: item.course_title,
          department: item.department || 'CSE',
          programme_code: item.programme || 'BTECH-CSE',
          semester: Number(item.semester) || 1,
          credits: Number(item.credits) || 4,
          course_type: item.course_type || 'Theory',
          status: 'ACTIVE',
        });
        added++;
      }
    }
    return { added, updated };
  },

  async createCurriculumEntry(data: any): Promise<any> {
    const created = await devDataAdapter.academic.createCourse({
      course_code: data.courseCode || `CRS-${Date.now().toString().slice(-4)}`,
      course_title: data.courseName || 'Curriculum Course',
      department: data.program || data.department || 'CSE',
      programme_code: data.program || 'BTECH-CSE',
      semester: 1,
      credits: Number(data.credits) || 3,
      course_type: data.type || 'Core',
      status: 'ACTIVE',
    });
    return created;
  },

  async deleteCurriculumEntry(id: string): Promise<boolean> {
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    if (state && state.courses) {
      state.courses = state.courses.filter((c: any) => c.course_id !== id && c.course_code !== id);
      (devDataAdapter as any).saveState(state);
    }
    return true;
  },

  subscribe(_callback: () => void): () => void {
    return () => {};
  },

  async importCurriculum(validRows: any[]): Promise<{ added: number; updated: number }> {
    return this.importCurriculumEntries(validRows);
  },

  // --- Manual Course Offerings (Core Module 11) ---
  async getCourseOfferings(): Promise<CourseOfferingRecord[]> {
    return devDataAdapter.academic.getCourseOfferings();
  },

  async createCourseOffering(
    data: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
    actor?: any
  ): Promise<CourseOfferingRecord> {
    return devDataAdapter.academic.createCourseOffering(data, actor);
  },

  async createCourseOfferingWithTimetable(
    offeringData: Omit<CourseOfferingRecord, 'offering_id' | 'created_at'>,
    timetableData?: {
      day_of_week: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
      start_time: string;
      end_time: string;
      room: string;
    },
    actor?: any
  ): Promise<{
    offering: CourseOfferingRecord;
    timetableSlot?: TimetableSlotRecord;
    facultyAssignment?: any;
  }> {
    if (typeof devDataAdapter.academic.createCourseOfferingWithTimetable === 'function') {
      return devDataAdapter.academic.createCourseOfferingWithTimetable(offeringData, timetableData, actor);
    }
    const offering = await devDataAdapter.academic.createCourseOffering(offeringData, actor);
    return { offering };
  },

  async updateCourseOffering(
    offeringId: string,
    updates: Partial<CourseOfferingRecord>,
    actor?: any
  ): Promise<CourseOfferingRecord> {
    if (typeof devDataAdapter.academic.updateCourseOffering === 'function') {
      return devDataAdapter.academic.updateCourseOffering(offeringId, updates, actor);
    }
    throw new Error('updateCourseOffering not supported on adapter');
  },

  async cancelCourseOffering(offeringId: string, reason: string, actor?: any): Promise<CourseOfferingRecord> {
    if (typeof devDataAdapter.academic.cancelCourseOffering === 'function') {
      return devDataAdapter.academic.cancelCourseOffering(offeringId, reason, actor);
    }
    throw new Error('cancelCourseOffering not supported on adapter');
  },

  async publishCourseOffering(offeringId: string, actor?: any): Promise<CourseOfferingRecord> {
    if (typeof devDataAdapter.academic.publishCourseOffering === 'function') {
      return devDataAdapter.academic.publishCourseOffering(offeringId, actor);
    }
    throw new Error('publishCourseOffering not supported on adapter');
  },

  async closeCourseOffering(offeringId: string, actor?: any): Promise<CourseOfferingRecord> {
    if (typeof devDataAdapter.academic.closeCourseOffering === 'function') {
      return devDataAdapter.academic.closeCourseOffering(offeringId, actor);
    }
    throw new Error('closeCourseOffering not supported on adapter');
  },

  // Enrolments
  async getEnrolments(filters?: any, actor?: any): Promise<CourseEnrolmentRecord[]> {
    return devDataAdapter.academic.getEnrolments(filters, actor);
  },

  async enrolStudent(data: any, actor?: any): Promise<CourseEnrolmentRecord> {
    return devDataAdapter.academic.enrolStudent(data, actor);
  },

  async transferStudentSection(enrolmentId: string, newSection: string, reason: string, actor?: any): Promise<CourseEnrolmentRecord> {
    return devDataAdapter.academic.transferStudentSection(enrolmentId, newSection, reason, actor);
  },

  async withdrawStudent(enrolmentId: string, reason: string, actor?: any): Promise<CourseEnrolmentRecord> {
    return devDataAdapter.academic.withdrawStudent(enrolmentId, reason, actor);
  },

  // Timetable
  async getTimetable(filters?: any): Promise<TimetableSlotRecord[]> {
    return devDataAdapter.academic.getTimetable(filters);
  },

  async scheduleTimetableSlot(data: any, actor?: any): Promise<TimetableSlotRecord> {
    return devDataAdapter.academic.scheduleTimetableSlot(data, actor);
  },

  // Bulk Enrolment
  async previewBulkEnrolment(request: BulkEnrolmentRequest): Promise<BulkEnrolmentPreReview> {
    if (typeof (devDataAdapter.academic as any).previewBulkEnrolment === 'function') {
      return (devDataAdapter.academic as any).previewBulkEnrolment(request);
    }
    throw new Error('previewBulkEnrolment is not implemented on adapter.');
  },

  async bulkEnrolStudents(request: BulkEnrolmentRequest, actor?: any): Promise<BulkEnrolmentResult> {
    if (typeof (devDataAdapter.academic as any).bulkEnrolStudents === 'function') {
      return (devDataAdapter.academic as any).bulkEnrolStudents(request, actor);
    }
    throw new Error('bulkEnrolStudents is not implemented on adapter.');
  },

  // CSV Registration Import
  async validateCsvImport(csvContent: string, fileName: string): Promise<CsvImportPreviewReport> {
    if (typeof (devDataAdapter.academic as any).validateCsvImport === 'function') {
      return (devDataAdapter.academic as any).validateCsvImport(csvContent, fileName);
    }
    throw new Error('validateCsvImport is not implemented on adapter.');
  },

  async commitCsvImport(params: { fileName: string; approvedRows: number[]; csvContent: string }, actor?: any): Promise<CsvImportBatchRecord> {
    if (typeof (devDataAdapter.academic as any).commitCsvImport === 'function') {
      return (devDataAdapter.academic as any).commitCsvImport(params, actor);
    }
    throw new Error('commitCsvImport is not implemented on adapter.');
  },

  async getCsvImportBatches(): Promise<CsvImportBatchRecord[]> {
    if (typeof (devDataAdapter.academic as any).getCsvImportBatches === 'function') {
      return (devDataAdapter.academic as any).getCsvImportBatches();
    }
    return [];
  },

  // Timetable Validation, Publication & Student Schedule
  async validateTimetable(params: { academic_year: string; semester: number; programme_code: string; section: string }): Promise<TimetableValidationResult> {
    if (typeof (devDataAdapter.academic as any).validateTimetable === 'function') {
      return (devDataAdapter.academic as any).validateTimetable(params);
    }
    throw new Error('validateTimetable is not implemented on adapter.');
  },

  async publishTimetable(params: { academic_year: string; semester: number; programme_code: string; section: string; batch?: string; change_notes?: string }, actor?: any): Promise<TimetableVersionRecord> {
    if (typeof (devDataAdapter.academic as any).publishTimetable === 'function') {
      return (devDataAdapter.academic as any).publishTimetable(params, actor);
    }
    throw new Error('publishTimetable is not implemented on adapter.');
  },

  async getTimetableVersions(filters?: any): Promise<TimetableVersionRecord[]> {
    if (typeof (devDataAdapter.academic as any).getTimetableVersions === 'function') {
      return (devDataAdapter.academic as any).getTimetableVersions(filters);
    }
    return [];
  },

  async getPublishedTimetableForStudent(studentIdOrReg: string, actor?: any) {
    if (typeof (devDataAdapter.academic as any).getPublishedTimetableForStudent === 'function') {
      return (devDataAdapter.academic as any).getPublishedTimetableForStudent(studentIdOrReg, actor);
    }
    throw new Error('getPublishedTimetableForStudent is not implemented on adapter.');
  },
};

// Contract: FFCS Registration CSV Template
export function generateFfcsCsvTemplate(): string {
  return [
    '# Electrix Institute of Technology (EIT) — FFCS Course Registration Import',
    '# Schema Version: EIT-FFCS-REG-V1.0',
    '# Identity Rule: registration_number and course_code are primary authoritative identifiers.',
    'registration_number,student_name,academic_year,semester,programme_code,batch,section_code,course_code,course_name,preference_rank,registration_status',
    'EIT-STU-2026-CSE-0001,Arjun Kumar,2026-2027,3,BTECH-CSE,2026,A,CS201,Data Structures & Algorithms,1,REGISTERED',
    'EIT-STU-2026-CSE-0002,Neha Verma,2026-2027,3,BTECH-CSE,2026,A,CS201,Data Structures & Algorithms,1,REGISTERED',
  ].join('\n');
}

// CSV Helpers for Curriculum Import
export function generateCurriculumCsvTemplate(): string {
  return [
    'course_code,course_title,credits,department,programme,semester,course_type,prerequisites,description',
    'CS201,Data Structures & Algorithms,4,CSE,BTECH-CSE,3,Theory,,Core algorithmic structures and complexity',
    'CS202,Computer Organization & Architecture,4,CSE,BTECH-CSE,3,Theory,,Digital logic and processor design',
    'EC304,Digital Signal Processing,4,ECE,BTECH-ECE,5,Theory,,Discrete signals and transform analysis',
    'ME202,Fluid Mechanics,3,MECH,BTECH-MECH,3,Theory,,Fluid dynamics and continuum mechanics',
  ].join('\n');
}

export function parseCurriculumCsvText(text: string): any[] {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const rows: any[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cells = lines[i].split(',').map((c) => c.trim());
    if (cells.length === headers.length) {
      const obj: any = {};
      headers.forEach((h, idx) => {
        obj[h] = cells[idx];
      });
      rows.push(obj);
    }
  }
  return rows;
}

export function validateCsvCurriculumRows(rows: any[], _programs?: any[]): CsvCurriculumValidationResult {
  const errors: string[] = [];
  const validRows: any[] = [];
  const invalidRows: { rowNumber: number; data: any; errors: string[] }[] = [];

  rows.forEach((row, idx) => {
    const rowNum = idx + 2;
    const rowErrors: string[] = [];
    const code = row.course_code || row.CourseCode || row.code;
    const title = row.course_title || row.CourseName || row.title || row.name;
    const creditsNum = Number(row.credits || row.Credits || 4);

    if (!code) {
      rowErrors.push("Missing 'course_code'.");
    }
    if (!title) {
      rowErrors.push("Missing 'course_title'.");
    }
    if (isNaN(creditsNum) || creditsNum < 1 || creditsNum > 10) {
      rowErrors.push("'credits' must be a valid number between 1 and 10.");
    }

    if (rowErrors.length > 0) {
      errors.push(`Row ${rowNum}: ${rowErrors.join(', ')}`);
      invalidRows.push({
        rowNumber: rowNum,
        data: row,
        errors: rowErrors,
      });
    } else {
      validRows.push({
        ...row,
        course_code: code,
        course_title: title,
        credits: creditsNum,
      });
    }
  });

  return {
    isValid: invalidRows.length === 0,
    errors,
    parsedRows: rows,
    validRows,
    invalidRows,
    totalCount: rows.length,
    totalRows: rows.length,
  };
}
