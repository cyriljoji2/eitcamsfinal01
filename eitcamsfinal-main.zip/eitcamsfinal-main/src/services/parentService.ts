import { devDataAdapter } from './devDataAdapter';
import { academicRepository } from './academicService';
import { financeRepository } from './financeService';
import { examinationRepository } from './examinationService';
import { proctorRepository } from './proctorService';
import {
  adaptStudentRecordToStudent,
  studentPortalService,
} from './studentPortalService';
import {
  ParentRecord,
  ParentStudentLinkRecord,
  StudentRecord,
  StudentHostelDetails,
  AuthRole,
} from '../types/database';
import {
  Student,
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  FacultyAssignment,
  FeeAssignment,
  FeeReceipt,
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
  ProctorAssignment,
  LeaveOutingRequest,
} from '../types/studentPortalTypes';
import { PaymentRecordItem } from '../types/finance';
import { AttendanceRecord } from '../types/database';
import { UserSession } from '../types/auth';

export interface LinkedWardEntry {
  link: ParentStudentLinkRecord;
  rawStudent: StudentRecord;
  student: Student;
  permissions: {
    can_view_grades: boolean;
    can_view_attendance: boolean;
    can_view_finance: boolean;
  };
}

export const parentService = {
  /**
   * Resolves officially linked students for the authenticated parent session.
   * Enforces service-layer authorization and cross-parent protection.
   */
  async getLinkedStudents(userSession: UserSession | any): Promise<Student[]> {
    const wards = await this.getLinkedWards(userSession);
    return wards.map((w) => w.student);
  },

  /**
   * Resolves complete linked ward entries with raw records and permissions.
   */
  async getLinkedWards(userSession: UserSession | any): Promise<LinkedWardEntry[]> {
    if (!userSession) return [];

    const parentId =
      userSession.parentProfile?.parent_id ||
      userSession.parent_id ||
      userSession.employeeId ||
      userSession.userId ||
      userSession.id ||
      userSession.username;

    if (!parentId) return [];

    const actor = {
      userId: parentId,
      role: (userSession.role ? userSession.role.toUpperCase() : AuthRole.PARENT) as AuthRole,
    };

    try {
      const links = await devDataAdapter.parents.getLinkedStudents(parentId, actor);
      const parentRecord = await devDataAdapter.parents.getById(parentId);

      return links.map(({ link, student }) => {
        const adaptedStudent = adaptStudentRecordToStudent(student, parentRecord);
        return {
          link,
          rawStudent: student,
          student: adaptedStudent,
          permissions: {
            can_view_grades: Boolean(link.can_view_grades),
            can_view_attendance: Boolean(link.can_view_attendance),
            can_view_finance: Boolean(link.can_view_finance),
          },
        };
      });
    } catch (err) {
      console.error('Failed to resolve linked wards for parent', err);
      return [];
    }
  },

  /**
   * Retrieves assigned Proctor for a student.
   * Omits confidential notes, private mentoring comments or internal office records.
   */
  async getProctorForStudent(registrationNumber: string): Promise<ProctorAssignment | null> {
    try {
      return await proctorRepository.getActiveAssignmentForStudent(registrationNumber);
    } catch {
      return null;
    }
  },

  /**
   * Retrieves official hostel residency details for a linked ward.
   */
  async getHostelDetailsForWard(
    studentId: string,
    userSession: UserSession | any
  ): Promise<StudentHostelDetails | null> {
    if (!studentId || !userSession) return null;
    const parentId =
      userSession.parentProfile?.parent_id ||
      userSession.userId ||
      userSession.id ||
      userSession.username;
    const actor = {
      userId: parentId,
      role: (userSession.role ? userSession.role.toUpperCase() : AuthRole.PARENT) as AuthRole,
    };

    try {
      return await devDataAdapter.hostel.getStudentHostelDetails(studentId, actor);
    } catch {
      return null;
    }
  },

  /**
   * Retrieves permitted hostel leave/outing requests for a student.
   */
  getLeaveRequestsForWard(registrationNumber: string): LeaveOutingRequest[] {
    try {
      return studentPortalService.getLeaveRequests(registrationNumber);
    } catch {
      return [];
    }
  },

  /**
   * Aggregates domain data collections from authoritative repositories.
   */
  async getDomainDatasets() {
    const [
      sessionsData,
      classesData,
      sectionsData,
      subjectsData,
      assignmentsData,
      attendanceData,
      feesData,
      paymentsData,
      receiptsData,
      examsData,
      schedulesData,
      hallTicketsData,
      resultsData,
    ] = await Promise.all([
      academicRepository.getSessions(),
      academicRepository.getClasses(),
      academicRepository.getSections(),
      academicRepository.getSubjects(),
      academicRepository.getFacultyAssignments(),
      academicRepository.getAttendanceRecords(),
      financeRepository.getFeeAssignments(),
      financeRepository.getPayments(),
      financeRepository.getReceipts(),
      examinationRepository.getExaminations(),
      examinationRepository.getSchedules(),
      examinationRepository.getHallTickets(),
      examinationRepository.getResults(),
    ]);

    return {
      sessions: sessionsData,
      classes: classesData,
      sections: sectionsData,
      subjects: subjectsData,
      facultyAssignments: assignmentsData,
      attendance: attendanceData,
      feeAssignments: feesData,
      payments: paymentsData,
      receipts: receiptsData,
      examinations: examsData,
      schedules: schedulesData,
      hallTickets: hallTicketsData,
      results: resultsData,
    };
  },
};

export const getLinkedStudents = parentService.getLinkedStudents.bind(parentService);
export const getLinkedWards = parentService.getLinkedWards.bind(parentService);
export const getProctorForStudent = parentService.getProctorForStudent.bind(parentService);
export const getHostelDetailsForWard = parentService.getHostelDetailsForWard.bind(parentService);
export const getLeaveRequestsForWard = parentService.getLeaveRequestsForWard.bind(parentService);
export const getDomainDatasets = parentService.getDomainDatasets.bind(parentService);
