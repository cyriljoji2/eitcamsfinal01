import { devDataAdapter } from './devDataAdapter';
import {
  Employee,
  EmployeeFormData,
  SystemSettings,
  CsvValidationResult,
  CsvValidationItem,
  GenderType,
  EmployeeStatus,
} from '../types/employee';
import {
  EmployeeCategory,
  EmployeeRecord,
  EmploymentStatus,
  AuthRole,
  LinkedRecordType,
  AccountStatus,
  OfficeAssignmentStatus,
} from '../types/database';
import { allocateNextEmployeeRegistrationNumber } from './regNumberGenerator';
import { SIX_PERMANENT_OFFICES } from '../config/permanentOffices';
import { academicCalendarService, formatAcademicYear } from './academicCalendarService';

export const EMPLOYEE_ROLES: Record<
  string,
  { id: string; title: string; description: string; officeId?: string; isTeaching?: boolean }
> = {
  super_admin: {
    id: 'super_admin',
    title: 'Super Administrator',
    description: 'Full institutional authority, system configuration, staff management, and academic calendar control (PO-001).',
    officeId: 'PO-001',
  },
  academic: {
    id: 'academic',
    title: 'Academic Affairs Officer',
    description: 'Curriculum structuring, class scheduling, course offerings, and faculty workload assignments (PO-003).',
    officeId: 'PO-003',
  },
  admission: {
    id: 'admission',
    title: 'Admissions Officer',
    description: 'Candidate applications, credential verification, merit evaluation, and student onboarding (PO-002).',
    officeId: 'PO-002',
  },
  finance: {
    id: 'finance',
    title: 'Finance & Accounts Officer',
    description: 'Fee structures, invoices, payment collections, ledger audits, and student financial accounts (PO-005).',
    officeId: 'PO-005',
  },
  examination: {
    id: 'examination',
    title: 'Controller of Examinations',
    description: 'Exam scheduling, hall tickets, marks moderation, grade publication, and transcripts (PO-004).',
    officeId: 'PO-004',
  },
  hostel: {
    id: 'hostel',
    title: 'Hostel & Residential Warden',
    description: 'Hostel block rooms, bed allocations, resident directory, and leave permissions (PO-006).',
    officeId: 'PO-006',
  },
  faculty: {
    id: 'faculty',
    title: 'Teaching Faculty / Professor',
    description: 'Instruction, lecture delivery, student attendance marking, and internal assessment grading.',
    isTeaching: true,
  },
  staff: {
    id: 'staff',
    title: 'Administrative Officer',
    description: 'General administrative support and departmental coordination across university divisions.',
  },
};

const employeeSubscribers = new Set<(employees: Employee[]) => void>();

function notifyEmployeeSubscribers(employees: Employee[]) {
  employeeSubscribers.forEach((cb) => {
    try {
      cb(employees);
    } catch (e) {
      console.error('Subscriber error in employeeRepository:', e);
    }
  });
}

function mapRecordToEmployee(rec: EmployeeRecord, users: any[], assignments: any[]): Employee {
  const user = users.find(
    (u) =>
      u.linked_record_id === rec.employee_id ||
      u.username.toLowerCase() === rec.registration_number.toLowerCase() ||
      u.username.toLowerCase() === `${rec.first_name.toLowerCase()}.${rec.last_name.toLowerCase()}`
  );

  const assignment = assignments.find(
    (a) => a.employee_id === rec.employee_id && a.assignment_status === 'ACTIVE'
  );

  let roleKey = 'faculty';
  if (rec.category === EmployeeCategory.TEACHING) {
    roleKey = 'faculty';
  } else if (assignment) {
    if (assignment.office_id === 'PO-001') roleKey = 'super_admin';
    else if (assignment.office_id === 'PO-002') roleKey = 'admission';
    else if (assignment.office_id === 'PO-003') roleKey = 'academic';
    else if (assignment.office_id === 'PO-004') roleKey = 'examination';
    else if (assignment.office_id === 'PO-005') roleKey = 'finance';
    else if (assignment.office_id === 'PO-006') roleKey = 'hostel';
    else roleKey = 'staff';
  } else {
    roleKey = 'staff';
  }

  const isTeaching = rec.category === EmployeeCategory.TEACHING;
  const username = user?.username || rec.registration_number;

  return {
    id: rec.registration_number || rec.employee_id,
    employeeId: rec.employee_id,
    registrationNumber: rec.registration_number,
    fullName: `${rec.first_name} ${rec.last_name}`,
    firstName: rec.first_name,
    lastName: rec.last_name,
    dateOfBirth: '1988-06-15',
    gender: 'Other',
    mobile: rec.phone_number,
    phoneNumber: rec.phone_number,
    email: rec.institutional_email,
    institutionalEmail: rec.institutional_email,
    address: 'Campus Residential Quarter / Academic City',
    department: rec.primary_department,
    primaryDepartment: rec.primary_department,
    designation: rec.designation,
    role: roleKey,
    roles: [isTeaching ? 'FACULTY' : 'NON_TEACHING_STAFF'],
    category: rec.category,
    isTeachingStaff: isTeaching,
    joiningDate: rec.date_of_joining,
    status: rec.employment_status === EmploymentStatus.ACTIVE ? 'active' : 'inactive',
    username,
    isTemporaryPassword: user ? !user.password_updated_at || user.password_updated_at === user.created_at : true,
    createdAt: rec.created_at,
    updatedAt: rec.updated_at,
  };
}

export const employeeRepository = {
  async getAll(): Promise<Employee[]> {
    const list = await devDataAdapter.employees.getAll();
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
    const users = state?.users || [];
    const assignments = state?.officeAssignments || [];

    return list.map((rec) => mapRecordToEmployee(rec, users, assignments));
  },

  async getById(id: string): Promise<Employee | null> {
    const all = await this.getAll();
    return all.find((e) => e.id === id || e.employeeId === id || e.username === id) || null;
  },

  async create(formData: EmployeeFormData): Promise<{ employee: Employee; temporaryPassword: string }> {
    const all = await this.getAll();
    const existingRegs = all.map((e) => e.registrationNumber || e.id);

    // Derive names
    let firstName = formData.firstName;
    let lastName = formData.lastName;
    if (!firstName || !lastName) {
      const parts = formData.fullName.trim().split(' ');
      firstName = parts[0] || 'Staff';
      lastName = parts.slice(1).join(' ') || 'Member';
    }

    const isTeaching =
      formData.role === 'faculty' ||
      formData.category === EmployeeCategory.TEACHING ||
      formData.designation.toLowerCase().includes('professor') ||
      formData.designation.toLowerCase().includes('lecturer');

    const category = isTeaching ? EmployeeCategory.TEACHING : EmployeeCategory.NON_TEACHING;
    const joiningYear = parseInt(formData.joiningDate?.split('-')[0], 10) || 2026;

    const regNumber = allocateNextEmployeeRegistrationNumber(
      existingRegs,
      category,
      formData.department,
      joiningYear
    );

    const email =
      formData.email?.trim() ||
      `${firstName.toLowerCase()}.${lastName.toLowerCase()}@eit.edu`;

    const createdRec = await devDataAdapter.employees.create({
      registration_number: regNumber,
      category,
      first_name: firstName,
      last_name: lastName,
      institutional_email: email,
      phone_number: formData.mobile,
      primary_department: formData.department,
      designation: formData.designation,
      employment_status: formData.status === 'active' ? EmploymentStatus.ACTIVE : EmploymentStatus.TERMINATED,
      date_of_joining: formData.joiningDate || new Date().toISOString().split('T')[0],
    });

    // Provision auth user with temporary password
    const temporaryPassword = `EIT#${Math.floor(100000 + Math.random() * 900000)}!`;
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;

    if (state) {
      const existingUserIdx = state.users.findIndex(
        (u: any) => u.username.toLowerCase() === regNumber.toLowerCase() || u.linked_record_id === createdRec.employee_id
      );

      const roleEnum =
        formData.role === 'super_admin'
          ? AuthRole.SUPER_ADMIN
          : isTeaching
          ? AuthRole.FACULTY
          : AuthRole.OFFICE_ADMIN;

      if (existingUserIdx >= 0) {
        state.users[existingUserIdx].password_hash = `hash_${temporaryPassword}`;
        state.users[existingUserIdx].account_status = AccountStatus.ACTIVE;
      } else {
        state.users.push({
          user_id: `USR-${createdRec.employee_id}`,
          username: regNumber,
          password_hash: `hash_${temporaryPassword}`,
          portal_type: 'employee' as any,
          role: roleEnum,
          linked_record_type: LinkedRecordType.EMPLOYEE,
          linked_record_id: createdRec.employee_id,
          account_status: AccountStatus.ACTIVE,
          failed_login_attempts: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }

      // Assign to permanent office if non-teaching institutional office role
      const roleDef = EMPLOYEE_ROLES[formData.role as string];
      if (roleDef?.officeId) {
        const alreadyAssigned = state.officeAssignments.some(
          (a: any) => a.employee_id === createdRec.employee_id && a.office_id === roleDef.officeId
        );
        if (!alreadyAssigned) {
          state.officeAssignments.push({
            assignment_id: `OAS-AUTO-${Date.now().toString().slice(-5)}`,
            employee_id: createdRec.employee_id,
            office_id: roleDef.officeId,
            assigned_role_title: formData.designation || roleDef.title,
            assignment_status: OfficeAssignmentStatus.ACTIVE,
            assigned_by_employee_id: 'USR-PO-001',
            effective_from: formData.joiningDate || new Date().toISOString().split('T')[0],
            created_at: new Date().toISOString(),
          });
        }
      }

      (devDataAdapter as any).saveState(state);
    }

    const updatedList = await this.getAll();
    notifyEmployeeSubscribers(updatedList);

    const employee = (await this.getById(regNumber)) || mapRecordToEmployee(createdRec, state?.users || [], state?.officeAssignments || []);
    return { employee, temporaryPassword };
  },

  async update(id: string, updates: Partial<EmployeeFormData>): Promise<Employee> {
    const existing = await this.getById(id);
    if (!existing) {
      throw new Error(`Employee ${id} not found.`);
    }

    const recUpdates: any = {};
    if (updates.mobile) recUpdates.phone_number = updates.mobile;
    if (updates.email) recUpdates.institutional_email = updates.email;
    if (updates.department) recUpdates.primary_department = updates.department;
    if (updates.designation) recUpdates.designation = updates.designation;
    if (updates.status) {
      recUpdates.employment_status =
        updates.status === 'active' ? EmploymentStatus.ACTIVE : EmploymentStatus.TERMINATED;
    }

    if (updates.fullName) {
      const parts = updates.fullName.trim().split(' ');
      recUpdates.first_name = parts[0];
      recUpdates.last_name = parts.slice(1).join(' ');
    }

    const updatedRec = await devDataAdapter.employees.update(existing.employeeId, recUpdates);

    // Update state user status if status was changed
    if (updates.status) {
      const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;
      if (state) {
        const u = state.users.find(
          (user: any) => user.linked_record_id === existing.employeeId || user.username === existing.username
        );
        if (u) {
          u.account_status = updates.status === 'active' ? AccountStatus.ACTIVE : AccountStatus.SUSPENDED;
          (devDataAdapter as any).saveState(state);
        }
      }
    }

    const updatedList = await this.getAll();
    notifyEmployeeSubscribers(updatedList);

    const refreshed = await this.getById(id);
    return refreshed || existing;
  },

  async toggleStatus(id: string): Promise<Employee> {
    const existing = await this.getById(id);
    if (!existing) throw new Error(`Employee ${id} not found.`);

    const nextStatus = existing.status === 'active' ? 'inactive' : 'active';
    return this.update(id, { status: nextStatus });
  },

  async resetPassword(id: string): Promise<{ employee: Employee; temporaryPassword: string }> {
    const existing = await this.getById(id);
    if (!existing) throw new Error(`Employee ${id} not found.`);

    const temporaryPassword = `EIT#${Math.floor(100000 + Math.random() * 900000)}!`;
    const state = typeof (devDataAdapter as any).getState === 'function' ? (devDataAdapter as any).getState() : null;

    if (state) {
      const u = state.users.find(
        (user: any) => user.linked_record_id === existing.employeeId || user.username === existing.username
      );
      if (u) {
        u.password_hash = `hash_${temporaryPassword}`;
        u.account_status = AccountStatus.ACTIVE;
        u.password_updated_at = new Date().toISOString();
        (devDataAdapter as any).saveState(state);
      }
    }

    const updatedList = await this.getAll();
    notifyEmployeeSubscribers(updatedList);

    const refreshed = (await this.getById(id)) || existing;
    return { employee: refreshed, temporaryPassword };
  },

  async bulkCreate(
    payloads: EmployeeFormData[]
  ): Promise<{ employees: Employee[]; temporaryPasswords: Record<string, string> }> {
    const createdList: Employee[] = [];
    const temporaryPasswords: Record<string, string> = {};

    for (const item of payloads) {
      const res = await this.create(item);
      createdList.push(res.employee);
      temporaryPasswords[res.employee.id] = res.temporaryPassword;
    }

    return { employees: createdList, temporaryPasswords };
  },

  subscribe(callback: (employees: Employee[]) => void): () => void {
    employeeSubscribers.add(callback);
    return () => {
      employeeSubscribers.delete(callback);
    };
  },
};

export const settingsRepository = {
  async getSettings(): Promise<SystemSettings> {
    const central = await devDataAdapter.settings.getInstitutionalSettings();
    const activeAY = await academicCalendarService.getActiveAcademicYear();

    return {
      schoolName: central.institution_name || 'Electrix Institute of Technology (EIT)',
      schoolAddress: central.campus_address || '1000 Academic Parkway, Boston, MA 02115',
      contactNumber: central.contact_phone || '+1 (555) 019-2830',
      email: central.contact_email || 'administration@eit.edu',
      academicYear: formatAcademicYear(activeAY.code),
      activeAcademicYearId: activeAY.year_id,
      campusCode: central.campus_code || 'EIT-BOS',
      sessionTimeout: central.session_timeout || '60',
      passwordMinLength: central.password_min_length || '8',
    };
  },

  async updateSettings(updates: Partial<SystemSettings>): Promise<SystemSettings> {
    const payload: any = {};
    if (updates.schoolName) payload.institution_name = updates.schoolName;
    if (updates.schoolAddress) payload.campus_address = updates.schoolAddress;
    if (updates.contactNumber) payload.contact_phone = updates.contactNumber;
    if (updates.email) payload.contact_email = updates.email;
    if (updates.campusCode) payload.campus_code = updates.campusCode;
    if (updates.sessionTimeout) payload.session_timeout = updates.sessionTimeout;
    if (updates.passwordMinLength) payload.password_min_length = updates.passwordMinLength;

    if (Object.keys(payload).length > 0) {
      await devDataAdapter.settings.updateInstitutionalSettings(payload);
    }

    return this.getSettings();
  },
};

// ---------------------------------------------------------------------------
// CSV IMPORT UTILITIES
// ---------------------------------------------------------------------------

export function generateCsvTemplate(): string {
  return [
    'FullName,DateOfBirth,Gender,Mobile,Email,Address,Department,Designation,Role,JoiningDate',
    'Dr. David Miller,1984-05-12,Male,+1 (555) 789-0123,david.miller@eit.edu,"100 Academic Way, Boston, MA",CSE,Assistant Professor,faculty,2026-08-01',
    'Prof. Elena Rostova,1980-11-20,Female,+1 (555) 890-1234,elena.rostova@eit.edu,"102 Academic Way, Boston, MA",ECE,Associate Professor,faculty,2026-08-01',
    'Marcus Thorne,1988-03-15,Male,+1 (555) 901-2345,marcus.thorne@eit.edu,"204 Beacon St, Boston, MA",Central Administration,Campus Facilities Officer,staff,2026-08-15',
    'Kavita Patel,1992-09-08,Female,+1 (555) 012-3456,kavita.patel@eit.edu,"305 Commonwealth Ave, Boston, MA",Bursar & Accounts Management,Payroll Specialist,finance,2026-09-01',
  ].join('\n');
}

export function parseCsvText(csvText: string): Array<Record<string, string>> {
  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length <= 1) return [];

  // Parse header
  const headers = lines[0].split(',').map((h) => h.trim().replace(/^["']|["']$/g, ''));
  const rows: Array<Record<string, string>> = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const values: string[] = [];
    let cur = '';
    let insideQuotes = false;

    for (let c = 0; c < line.length; c++) {
      const char = line[c];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        values.push(cur.trim().replace(/^["']|["']$/g, ''));
        cur = '';
      } else {
        cur += char;
      }
    }
    values.push(cur.trim().replace(/^["']|["']$/g, ''));

    const rowObj: Record<string, string> = {};
    headers.forEach((h, idx) => {
      rowObj[h] = values[idx] || '';
    });
    rows.push(rowObj);
  }

  return rows;
}

export function validateCsvEmployeeRows(
  rawRows: Array<Record<string, string>>,
  existingEmployees: Employee[]
): CsvValidationResult {
  const existingEmails = new Set(existingEmployees.map((e) => e.email?.toLowerCase()));
  const existingPhones = new Set(existingEmployees.map((e) => (e.mobile || '').replace(/\D/g, '')));
  const seenEmailsInFile = new Set<string>();

  const items: CsvValidationItem[] = [];
  let validCount = 0;
  let invalidCount = 0;
  let duplicateCount = 0;

  rawRows.forEach((row, idx) => {
    const rowNumber = idx + 2; // accounts for 1-based index and header line
    const fullName = (row['FullName'] || row['fullName'] || row['Name'] || '').trim();
    const dob = (row['DateOfBirth'] || row['dateOfBirth'] || row['DOB'] || '1990-01-01').trim();
    const gender = (row['Gender'] || row['gender'] || 'Male').trim() as GenderType;
    const mobile = (row['Mobile'] || row['mobile'] || row['Phone'] || '').trim();
    const email = (row['Email'] || row['email'] || '').trim().toLowerCase();
    const address = (row['Address'] || row['address'] || '').trim();
    const department = (row['Department'] || row['department'] || 'CSE').trim();
    const designation = (row['Designation'] || row['designation'] || 'Assistant Professor').trim();
    const rawRole = (row['Role'] || row['role'] || 'faculty').trim().toLowerCase();
    const joiningDate = (row['JoiningDate'] || row['joiningDate'] || new Date().toISOString().split('T')[0]).trim();

    const errors: string[] = [];
    let isDuplicate = false;

    if (!fullName) {
      errors.push('Full Name is required');
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errors.push('Valid institutional email is required');
    } else if (existingEmails.has(email)) {
      errors.push(`Email '${email}' is already registered`);
      isDuplicate = true;
    } else if (seenEmailsInFile.has(email)) {
      errors.push(`Duplicate email '${email}' repeated in this file`);
      isDuplicate = true;
    }

    if (!mobile) {
      errors.push('Mobile phone number is required');
    } else if (existingPhones.has(mobile.replace(/\D/g, ''))) {
      errors.push(`Phone number '${mobile}' is already registered`);
      isDuplicate = true;
    }

    if (!designation) {
      errors.push('Designation is required');
    }

    const isValid = errors.length === 0;

    let parsedData: EmployeeFormData | null = null;
    if (isValid) {
      seenEmailsInFile.add(email);
      validCount++;
      parsedData = {
        fullName,
        dateOfBirth: dob,
        gender: ['Male', 'Female', 'Other', 'Prefer not to say'].includes(gender) ? gender : 'Other',
        mobile,
        email,
        address,
        department,
        designation,
        role: EMPLOYEE_ROLES[rawRole] ? rawRole : 'faculty',
        joiningDate,
        status: 'active',
      };
    } else {
      invalidCount++;
      if (isDuplicate) duplicateCount++;
    }

    items.push({
      rowNumber,
      raw: row,
      parsedData,
      isValid,
      isDuplicate,
      errors,
    });
  });

  return {
    totalRows: rawRows.length,
    validCount,
    invalidCount,
    duplicateCount,
    items,
  };
}
