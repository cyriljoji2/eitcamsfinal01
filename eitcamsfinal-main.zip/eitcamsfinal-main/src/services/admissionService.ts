/**
 * University Admissions Service & Domain Operations
 * Electrix Institute of Technology (EIT) CAMS
 *
 * Implements university business logic, CSV parsing & validation,
 * document verification helpers, and student conversion workflows.
 */

import { devDataAdapter } from './devDataAdapter';
import { adaptStudentRecordToStudent } from './studentPortalService';
import { Student } from '../types/studentPortalTypes';
import {
  ApplicantRecord,
  ApplicationStatus,
  DocumentSubmissionStatus,
  DocumentVerificationStatus,
  DepartmentRecord,
  ProgrammeRecord,
  StudentRecord,
} from '../types/database';
import {
  UniversityAdmissionFormData,
  UniversityAdmissionMetrics,
  CsvUniversityApplicantRow,
  CsvUniversityValidationResult,
  UniversityDocumentRow,
} from '../types/admission';

/**
 * Standard University Admissions Document Types
 */
export const UNIVERSITY_DOCUMENT_TEMPLATES = [
  { documentCode: 'DOC_PHOTO', documentType: 'Passport Size Photograph', isMandatory: true },
  { documentCode: 'DOC_ID', documentType: 'National Identity / Passport Copy', isMandatory: true },
  { documentCode: 'DOC_10TH', documentType: 'Secondary School (10th) Certificate & Marksheet', isMandatory: true },
  { documentCode: 'DOC_12TH', documentType: 'Higher Secondary (12th / Diploma) Marksheet', isMandatory: true },
  { documentCode: 'DOC_ENTRANCE', documentType: 'Entrance Examination Scorecard (JEE / CET / GATE)', isMandatory: false },
  { documentCode: 'DOC_TRANSFER', documentType: 'Transfer / Leaving Certificate', isMandatory: false },
  { documentCode: 'DOC_MIGRATION', documentType: 'Migration Certificate', isMandatory: false },
];

/**
 * University Entry Quotas / Categories
 */
export const UNIVERSITY_ADMISSION_CATEGORIES = [
  'General Merit',
  'State Domicile Quota',
  'All India Seats',
  'Management Quota',
  'Sports & Extracurricular Quota',
  'NRI / International Quota',
  'Lateral Entry (Direct 2nd Year)',
];

/**
 * University Study Modes
 */
export const UNIVERSITY_STUDY_MODES = [
  'Full-Time On-Campus',
  'Part-Time / Evening',
  'Industry Sponsored',
  'Research Scholar',
];

/**
 * RFC 4180 Compliant CSV text parser that handles quotes and embedded commas.
 */
export function parseUniversityCsvText(csvText: string): Record<string, string>[] {
  const clean = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
  if (!clean) return [];

  const lines = clean.split('\n');
  if (lines.length < 2) return [];

  const parseCsvLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  const headers = parseCsvLine(lines[0]).map((h) => h.replace(/^["']|["']$/g, '').trim());

  const rows: Record<string, string>[] = [];
  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;

    const values = parseCsvLine(rawLine);
    const rowObj: Record<string, string> = {};
    headers.forEach((header, idx) => {
      let val = values[idx] ?? '';
      // Strip outer quotes if still present
      if (val.startsWith('"') && val.endsWith('"')) {
        val = val.substring(1, val.length - 1);
      }
      rowObj[header] = val.trim();
    });
    rows.push(rowObj);
  }

  return rows;
}

/**
 * Validates CSV Applicant Rows against university departments, active programmes, and rules.
 */
export function validateUniversityCsvRows(
  parsedRows: Record<string, string>[],
  existingApplicants: ApplicantRecord[],
  existingStudents: StudentRecord[],
  departments: DepartmentRecord[],
  programmes: ProgrammeRecord[]
): CsvUniversityValidationResult {
  const deptCodes = new Set(departments.map((d) => d.code.toUpperCase()));
  const progNames = new Set(programmes.map((p) => p.name.toLowerCase()));
  const progCodes = new Set(programmes.map((p) => p.code.toLowerCase()));

  const rows: CsvUniversityApplicantRow[] = [];
  let validCount = 0;
  let invalidCount = 0;

  parsedRows.forEach((row, idx) => {
    const rowNumber = idx + 2; // Line 1 is header
    const errors: string[] = [];

    // Header extraction (support multiple casing styles)
    const fullName =
      row['FullName'] ||
      row['Full Name'] ||
      row['Name'] ||
      `${row['FirstName'] || row['First Name'] || ''} ${row['LastName'] || row['Last Name'] || ''}`.trim();
    const dob = row['DateOfBirth'] || row['Date of Birth'] || row['DOB'] || '';
    const gender = (row['Gender'] || 'PREFER_NOT_TO_SAY').toUpperCase();
    const email = (row['Email'] || row['Applicant Email'] || '').toLowerCase().trim();
    const mobile = row['Mobile'] || row['Phone'] || row['Contact'] || '';
    const dept = (row['Department'] || row['Dept'] || '').toUpperCase().trim();
    const program = row['Program'] || row['Programme'] || row['Intended Program'] || '';
    const admissionYearRaw = row['AdmissionYear'] || row['Admission Year'] || row['Year'] || '2026';
    const admissionYear = parseInt(admissionYearRaw, 10) || 2026;
    const previousQual = row['PreviousQualification'] || row['Qualification'] || 'Higher Secondary (10+2)';
    const marksRaw = row['MarksPercentage'] || row['Marks'] || row['Percentage'] || '80';
    const marksPercentage = parseFloat(marksRaw) || 0;
    const guardianName = row['GuardianName'] || row['Guardian Name'] || row['FatherName'] || '';
    const guardianPhone = row['GuardianPhone'] || row['Guardian Mobile'] || '';
    const entranceExam = row['EntranceExam'] || row['Entrance Examination'] || '';
    const entranceScore = row['EntranceScore'] || row['Score'] || row['Rank'] || '';

    // Validation checks
    if (!fullName || fullName.length < 2) {
      errors.push('Full name is required (minimum 2 characters).');
    }

    if (!dob) {
      errors.push('Date of birth is required.');
    } else {
      const birthDate = new Date(dob);
      if (isNaN(birthDate.getTime())) {
        errors.push(`Invalid date format for Date of Birth: '${dob}' (expected YYYY-MM-DD).`);
      } else {
        const ageDifMs = Date.now() - birthDate.getTime();
        const ageDate = new Date(ageDifMs);
        const age = Math.abs(ageDate.getUTCFullYear() - 1970);
        if (age < 14) {
          errors.push('Applicant must be at least 14 years of age for university admission.');
        }
      }
    }

    if (!email) {
      errors.push('Applicant email address is required.');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errors.push(`Invalid email format: '${email}'.`);
    }

    if (!mobile) {
      errors.push('Contact mobile number is required.');
    }

    if (!dept) {
      errors.push('Department code is required.');
    } else if (deptCodes.size > 0 && !deptCodes.has(dept)) {
      errors.push(`Department code '${dept}' does not exist in active academic departments.`);
    }

    if (!program) {
      errors.push('Intended university programme is required.');
    } else if (
      programmes.length > 0 &&
      !progNames.has(program.toLowerCase()) &&
      !progCodes.has(program.toLowerCase())
    ) {
      errors.push(`Programme '${program}' does not match any approved university programme.`);
    }

    if (isNaN(marksPercentage) || marksPercentage < 0 || marksPercentage > 100) {
      errors.push(`Marks percentage must be a number between 0 and 100 (got '${marksRaw}').`);
    }

    // Duplicate detection
    let duplicateReason: string | undefined;
    const existingApplicantWithEmail = existingApplicants.find(
      (a) => a.email.toLowerCase() === email && a.admission_year === admissionYear
    );
    if (existingApplicantWithEmail) {
      duplicateReason = `Duplicate: An application (${existingApplicantWithEmail.application_id}) with email '${email}' already exists for admission year ${admissionYear}.`;
      errors.push(duplicateReason);
    }

    const existingStudentWithEmail = existingStudents.find(
      (s) => s.institutional_email?.toLowerCase() === email
    );
    if (existingStudentWithEmail) {
      duplicateReason = `Conflict: A student with registration number '${existingStudentWithEmail.registration_number}' is already enrolled with this email.`;
      errors.push(duplicateReason);
    }

    const isValid = errors.length === 0;
    if (isValid) validCount++;
    else invalidCount++;

    rows.push({
      rowNumber,
      fullName,
      dateOfBirth: dob,
      gender,
      email,
      mobile,
      department: dept,
      program,
      admissionYear,
      previousQualification: previousQual,
      marksPercentage,
      guardianName,
      guardianPhone,
      entranceExam,
      entranceScore,
      raw: row,
      isValid,
      validationErrors: errors,
      duplicateReason,
    });
  });

  return {
    fileName: 'university_admission_batch.csv',
    totalRows: parsedRows.length,
    validRowsCount: validCount,
    invalidRowsCount: invalidCount,
    rows,
    departmentsAvailable: Array.from(deptCodes),
    programmesAvailable: programmes.map((p) => p.name),
  };
}

/**
 * Computes university admission statistics from authoritative records
 */
export function computeUniversityAdmissionMetrics(
  applicants: ApplicantRecord[],
  students: StudentRecord[]
): UniversityAdmissionMetrics {
  const totalApplications = applicants.length;
  let newApplications = 0;
  let underReview = 0;
  let documentsPending = 0;
  let approved = 0;
  let rejected = 0;
  let waitlisted = 0;
  let convertedStudents = 0;
  let docsPendingVerificationCount = 0;

  const byDepartment: Record<string, number> = {};
  const byProgramme: Record<string, number> = {};

  for (const app of applicants) {
    // Stage counts
    if (app.application_status === ApplicationStatus.SUBMITTED) newApplications++;
    else if (app.application_status === ApplicationStatus.UNDER_REVIEW) underReview++;
    else if (app.application_status === ApplicationStatus.DOCUMENTS_PENDING) documentsPending++;
    else if (app.application_status === ApplicationStatus.APPROVED) approved++;
    else if (app.application_status === ApplicationStatus.REJECTED) rejected++;
    else if (app.application_status === ApplicationStatus.WITHDRAWN) waitlisted++;

    if (app.converted_to_student) convertedStudents++;

    // Dept & Programme
    if (app.department) {
      byDepartment[app.department] = (byDepartment[app.department] || 0) + 1;
    }
    if (app.intended_program) {
      byProgramme[app.intended_program] = (byProgramme[app.intended_program] || 0) + 1;
    }

    // Docs pending
    for (const doc of app.documents || []) {
      if (
        doc.submission_status === DocumentSubmissionStatus.SUBMITTED &&
        doc.verification_status !== DocumentVerificationStatus.VERIFIED
      ) {
        docsPendingVerificationCount++;
      }
    }
  }

  return {
    totalApplications,
    newApplications,
    underReview,
    documentsPending,
    approved,
    rejected,
    waitlisted,
    convertedStudents,
    byDepartment,
    byProgramme,
    docsPendingVerificationCount,
  };
}

/**
 * Global repository facade for Admission Office
 */
export const admissionRepository = {
  // Existing adapter queries
  async getAll(): Promise<Student[]> {
    const list = await devDataAdapter.students.getAll();
    return list.map((s) => adaptStudentRecordToStudent(s));
  },

  async getAllStudents(): Promise<Student[]> {
    return this.getAll();
  },

  async getStudents(): Promise<Student[]> {
    return this.getAll();
  },

  async getStudentById(id: string): Promise<Student | null> {
    const s = await devDataAdapter.students.getById(id);
    if (!s) return null;
    return adaptStudentRecordToStudent(s);
  },

  async getAllApplicants(): Promise<ApplicantRecord[]> {
    return devDataAdapter.applicants.getAll();
  },

  async getApplicantById(id: string): Promise<ApplicantRecord | null> {
    return devDataAdapter.applicants.getById(id);
  },

  async createUniversityAdmission(
    data: UniversityAdmissionFormData,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<ApplicantRecord> {
    const applicantRecord = await devDataAdapter.applicants.create(
      {
        first_name: data.firstName.trim(),
        last_name: data.lastName.trim(),
        date_of_birth: data.dateOfBirth,
        gender: data.gender,
        email: data.email.trim(),
        phone_number: data.mobile.trim(),
        address: data.currentAddress.trim(),
        intended_program: data.intendedProgram,
        department: data.departmentCode,
        admission_year: data.admissionAcademicYear,
        previous_qualification: data.previousQualification,
        marks_percentage: data.marksPercentage,
        application_date: new Date().toISOString().split('T')[0],
        application_status: data.applicationStatus || ApplicationStatus.SUBMITTED,
        // University Dossier Extension
        nationality: data.nationality,
        alternate_phone: data.alternatePhone,
        current_address: data.currentAddress,
        permanent_address: data.permanentAddress,
        guardian_name: data.guardianName,
        guardian_relationship: data.guardianRelationship,
        guardian_phone: data.guardianMobile,
        guardian_email: data.guardianEmail,
        guardian_address: data.guardianAddress,
        previous_institution: data.previousInstitution,
        institution_type: data.institutionType,
        board_or_university: data.boardOrUniversity,
        completion_year: data.completionYear,
        exam_roll_number: data.examRollNumber,
        cgpa: data.cgpa,
        degree_level: data.degreeLevel,
        admission_category: data.admissionCategory,
        study_mode: data.studyMode,
        entrance_exam_name: data.entranceExamName,
        entrance_exam_roll: data.entranceExamRoll,
        entrance_exam_year: data.entranceExamYear,
        entrance_exam_score: data.entranceExamScore,
        documents: data.documents.map((d, index) => ({
          document_id: `DOC-APP-${Date.now().toString(36)}-${index + 1}`,
          application_id: '',
          document_type: d.documentType,
          document_code: d.documentCode,
          is_mandatory: d.isMandatory,
          submission_status: d.submissionStatus,
          verification_status: DocumentVerificationStatus.PENDING,
          reviewer_notes: d.fileName ? `Uploaded: ${d.fileName}` : undefined,
        })),
      },
      actor
    );

    return applicantRecord;
  },

  async convertApprovedApplicantToStudent(
    applicationId: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ) {
    return devDataAdapter.applicants.convertApprovedApplicantToStudent(applicationId, actor);
  },

  async updateApplicantStatus(
    id: string,
    status: ApplicationStatus,
    reason?: string,
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<ApplicantRecord> {
    return devDataAdapter.applicants.updateStatus(id, status, reason, actor);
  },

  async updateDocumentStatus(
    applicationId: string,
    documentId: string,
    updates: {
      submission_status?: 'PENDING' | 'SUBMITTED';
      verification_status?: 'PENDING' | 'VERIFIED' | 'REJECTED';
      reviewer_notes?: string;
    },
    actor?: { userId: string; role: string; employeeId?: string }
  ): Promise<ApplicantRecord> {
    return devDataAdapter.applicants.updateDocumentStatus(applicationId, documentId, updates, actor);
  },

  async getAcademicMasters() {
    const [departments, programmes, academicYears] = await Promise.all([
      devDataAdapter.academic.getDepartments(),
      devDataAdapter.academic.getProgrammes(),
      devDataAdapter.academic.getAcademicYears(),
    ]);
    return { departments, programmes, academicYears };
  },

  async getAuditLogs() {
    return devDataAdapter.audit.getRecent();
  },

  async update(id: string, updates: any): Promise<Student> {
    if (updates.temporaryPassword) {
      const adapterAny = devDataAdapter as any;
      if (typeof adapterAny.getState === 'function' && typeof adapterAny.saveState === 'function') {
        const state = adapterAny.getState();
        const user = state?.authUsers?.find((u: any) => u.linked_record_id === id);
        if (user) {
          user.password_hash = updates.temporaryPassword;
          user.password_updated_at = new Date().toISOString();
          adapterAny.saveState(state);
        }
      }
    }
    const s = await devDataAdapter.students.getById(id);
    return adaptStudentRecordToStudent(s || ({} as any));
  },
};
