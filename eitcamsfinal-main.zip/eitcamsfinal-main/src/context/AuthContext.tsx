/**
 * Authentication Context & Route Guard Provider
 *
 * Exposes active session state, role validation, login, logout, and office switching
 * through the IEitDataAdapter abstraction.
 */

import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { PortalType } from '../types/portal';
import { AuthSession, IEitDataAdapter, LoginResult } from '../services/dataAdapter';
import { devDataAdapter } from '../services/devDataAdapter';

export interface UserSessionInfo {
  id: string;
  username: string;
  name: string;
  email?: string;
  displayName?: string;
  role: string;
  roleTitle: string;
  portalType: PortalType | string;
}

export type LoginPayload =
  | { identifier: string; password: string; portalType: PortalType | string }
  | { username: string; password: string; portalType: PortalType | string };

interface AuthContextValue {
  session: AuthSession | null;
  user: UserSessionInfo | null;
  viewState: { type: 'home' | 'login' | 'dashboard'; portal?: PortalType };
  isAuthenticated: boolean;
  isLoading: boolean;
  activePortal: PortalType | null;
  activeOfficeKey: string | null;
  dataAdapter: IEitDataAdapter;
  isDevMode: boolean;
  login: (
    usernameOrPayload: string | LoginPayload,
    passwordAttempt?: string,
    portalType?: PortalType
  ) => Promise<LoginResult & { errorMessage?: string }>;
  logout: () => Promise<void>;
  switchActiveOffice: (officeKey: string) => void;
  navigateToLanding: () => void;
  navigateToLogin: (portal: PortalType) => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeOfficeKey, setActiveOfficeKey] = useState<string | null>(null);

  const [viewState, setViewState] = useState<{ type: 'home' | 'login' | 'dashboard'; portal?: PortalType }>(() => {
    const norm = typeof window !== 'undefined' ? window.location.hash.replace(/^#\/?/, '').trim().toLowerCase() : '';
    if (norm.startsWith('dashboard/')) {
      return { type: 'dashboard', portal: norm.split('/')[1] as PortalType };
    }
    if (norm.startsWith('login/')) {
      return { type: 'login', portal: norm.split('/')[1] as PortalType };
    }
    return { type: 'home' };
  });

  useEffect(() => {
    const handleHash = () => {
      const norm = window.location.hash.replace(/^#\/?/, '').trim().toLowerCase();
      if (norm.startsWith('dashboard/')) {
        setViewState({ type: 'dashboard', portal: norm.split('/')[1] as PortalType });
      } else if (norm.startsWith('login/')) {
        setViewState({ type: 'login', portal: norm.split('/')[1] as PortalType });
      } else {
        setViewState({ type: 'home' });
      }
    };

    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // Swappable adapter: current development adapter, replaceable by GoogleSheetsDataAdapter later
  const dataAdapter: IEitDataAdapter = devDataAdapter;

  useEffect(() => {
    let isMounted = true;
    const restoreSession = async () => {
      try {
        const existing = await dataAdapter.auth.getCurrentSession();
        if (isMounted && existing) {
          setSession(existing);
          setActiveOfficeKey(existing.activeOfficeKey || existing.permanentOffice?.office_key || null);
        }
      } catch {
        // Fallback silently if storage unavailable
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    restoreSession();
    return () => {
      isMounted = false;
    };
  }, [dataAdapter]);

  const login = useCallback(
    async (
      usernameOrPayload: string | LoginPayload,
      passwordAttempt?: string,
      portalType?: PortalType
    ): Promise<LoginResult & { errorMessage?: string }> => {
      setIsLoading(true);
      try {
        let username = '';
        let password = '';
        let portal: PortalType = PortalType.Student;

        if (typeof usernameOrPayload === 'object') {
          username = (usernameOrPayload as any).identifier || (usernameOrPayload as any).username || '';
          password = usernameOrPayload.password || '';
          portal = (usernameOrPayload.portalType as PortalType) || PortalType.Student;
        } else {
          username = usernameOrPayload || '';
          password = passwordAttempt || '';
          portal = portalType || PortalType.Student;
        }

        const result = await dataAdapter.auth.login(username, password, portal);
        const enhancedResult: LoginResult & { errorMessage?: string } = {
          ...result,
          errorMessage: result.error || (result.success ? undefined : 'Authentication failed. Please verify credentials.'),
        };

        if (result.success && result.session) {
          setSession(result.session);
          setActiveOfficeKey(
            result.session.activeOfficeKey || result.session.permanentOffice?.office_key || null
          );
        }
        return enhancedResult;
      } finally {
        setIsLoading(false);
      }
    },
    [dataAdapter]
  );

  const logout = useCallback(async () => {
    setIsLoading(true);
    try {
      await dataAdapter.auth.logout();
      setSession(null);
      setActiveOfficeKey(null);
    } finally {
      setIsLoading(false);
    }
  }, [dataAdapter]);

  const switchActiveOffice = useCallback((officeKey: string) => {
    setActiveOfficeKey(officeKey);
  }, []);

  const navigateToLanding = useCallback(() => {
    if (window.location.hash) {
      window.history.pushState(null, '', window.location.pathname + window.location.search);
    }
    window.location.hash = '#/';
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const navigateToLogin = useCallback((portal: PortalType) => {
    window.location.hash = `#/login/${portal}`;
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);

  const user: UserSessionInfo | null = session
    ? {
        id: session.user.user_id || session.userId || session.user.username,
        username: session.user.username,
        name: session.displayName || session.user.username,
        role: session.role,
        roleTitle: session.employeeProfile?.designation || session.role.replace('_', ' '),
        portalType: session.portalType,
      }
    : null;

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        viewState,
        isAuthenticated: Boolean(session),
        isLoading,
        activePortal: session?.portalType || null,
        activeOfficeKey,
        dataAdapter,
        isDevMode: true,
        login,
        logout,
        switchActiveOffice,
        navigateToLanding,
        navigateToLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
