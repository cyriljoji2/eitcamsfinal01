/**
 * EIT CAMS — Hostel Office Type Definitions & Data Models
 * University Adaptation of Residential Hall Infrastructure
 */

import {
  LeaveOutingRequestType,
  LeaveReasonCategory,
  LeaveApprovalStatus,
  LeaveOutingRequest,
} from './studentPortalTypes';

export type HostelType = 'Boys' | 'Girls' | 'Co-ed';
export type HostelCategory = 'Standard' | 'Deluxe' | 'AC' | 'Non-AC' | string;
export type HostelStatus = 'active' | 'inactive' | 'maintenance';

export type RoomType = 'Single' | 'Double' | 'Triple' | 'Dormitory' | string;
export type RoomStatus = 'active' | 'maintenance' | 'inactive';
export type BedStatus = 'AVAILABLE' | 'OCCUPIED' | 'BLOCKED';

export interface Hostel {
  id: string;
  hostelName: string;
  hostelCode: string;
  hostelType: HostelType;
  category: HostelCategory;
  status: HostelStatus;
  address: string;
  description?: string;
  wardenName?: string;
  wardenContact?: string;
  wardenPhone?: string;
  totalBlocks?: number;
  totalRooms?: number;
  totalBeds?: number;
  occupiedBeds?: number;
  createdAt?: string;
  updatedAt?: string;

  // Student Portal compatibility aliases
  name?: string;
  blockName?: string;
  type?: string;
}

export interface HostelBlock {
  id: string;
  hostelId: string;
  blockName: string;
  blockCode: string;
  status: HostelStatus;
  description?: string;
  wardenName?: string;
  contactPhone?: string;
  totalFloors?: number;
  totalRooms?: number;
  totalBeds?: number;
  occupiedBeds?: number;
}

export interface HostelFloor {
  id: string;
  hostelId: string;
  blockId: string;
  floorNumber: number | string;
  floorName: string;
  status: HostelStatus;
  description?: string;
}

export interface HostelRoom {
  id: string;
  hostelId: string;
  blockId: string;
  floorId: string;
  roomNumber: string;
  roomType: RoomType;
  capacity: number;
  status: RoomStatus;
  floor?: number;
  monthlyRent?: number;
  amenities?: string[];
  description?: string;
}

export interface HostelBed {
  id: string;
  hostelId: string;
  blockId: string;
  floorId: string;
  roomId: string;
  bedNumber: string;
  status: BedStatus;
  currentStudentId?: string;
  currentStudentName?: string;
  currentRegistrationNumber?: string;
  currentAllocationId?: string;
}

export interface HostelAllotment {
  id: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName: string;
  studentGender?: string;
  studentClass?: string;
  studentSection?: string;
  programmeName?: string;
  batchYear?: string;
  hostelId: string;
  hostelName: string;
  blockId: string;
  blockName: string;
  floorId: string;
  floorName: string;
  roomId: string;
  roomNumber: string;
  bedId: string;
  bedNumber: string;
  allotmentDate: string;
  academicSession?: string;
  status: 'Active' | 'Transferred' | 'Vacated' | 'Pending' | string;
  monthlyRent?: number;
  allottedBy: string;
  vacateDate?: string;
  vacateReason?: string;
  transferDate?: string;
  transferReason?: string;
  remarks?: string;
  notes?: string;
}

export interface HostelAllotmentHistory {
  id: string;
  allotmentId: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName: string;
  action: 'ALLOTMENT' | 'TRANSFER' | 'VACATE';
  previousDetails?: string;
  newDetails?: string;
  previousHostelName?: string;
  previousRoomNumber?: string;
  previousBedNumber?: string;
  newHostelName?: string;
  newRoomNumber?: string;
  newBedNumber?: string;
  reason?: string;
  actor?: string;
  actorName: string;
  timestamp: string;
}

export interface HostelDashboardMetrics {
  totalHostels: number;
  totalBlocks: number;
  totalFloors: number;
  totalRooms: number;
  totalBeds: number;
  occupiedBeds: number;
  availableBeds: number;
  blockedBeds: number;
  occupancyPercentage: number;
  studentsCurrentlyAllotted: number;
}

export interface HostelLeaveMetrics {
  pendingHostel: number;
  approvedToday: number;
  rejected: number;
  activeLeaveOuting: number;
  totalRequests: number;
}

export type LeaveOutingStatus = LeaveApprovalStatus;
export type {
  LeaveOutingRequestType,
  LeaveReasonCategory,
  LeaveApprovalStatus,
  LeaveOutingRequest,
};
