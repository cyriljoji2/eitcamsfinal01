import {
  FeeCategory,
  FeeInvoiceRecord,
  FeeStructureRecord,
  FeeAdjustmentRecord,
  FinanceDashboardMetrics as DbFinanceDashboardMetrics,
  InvoiceStatus,
  InvoiceLineItem,
  PaymentLedgerStatus,
  PaymentMethod,
  PaymentRecord as DbPaymentRecord,
  AdjustmentType,
  AdjustmentStatus,
  StudentFeeStatement,
} from './database';
import { FeeAssignment, FeeReceipt, PaymentRecordItem } from './studentPortalTypes';

export type PaymentRecord = PaymentRecordItem;
export type {
  FeeAssignment,
  FeeReceipt,
  PaymentRecordItem,
  FeeInvoiceRecord,
  DbPaymentRecord,
  FeeStructureRecord,
  FeeAdjustmentRecord,
  InvoiceLineItem,
  StudentFeeStatement,
};
export {
  FeeCategory,
  InvoiceStatus,
  PaymentMethod,
  PaymentLedgerStatus,
  AdjustmentType,
  AdjustmentStatus,
};

export type PaymentMode =
  | 'Cash'
  | 'Bank Transfer'
  | 'Credit Card'
  | 'Debit Card'
  | 'Cheque'
  | 'Demand Draft'
  | 'Online Gateway'
  | 'UPI'
  | string;

export interface FeeStructureItem {
  id: string;
  name: string;
  feeCategory: FeeCategory | string;
  amount: number;
  currency: string;
  academicSession: string;
  semester: number;
  programmeCode: string;
  applicableClassNames: string[];
  frequency: 'Annual' | 'Per Semester' | 'One-Time' | 'Monthly' | string;
  dueDate: string;
  status: 'active' | 'inactive' | 'ACTIVE' | 'INACTIVE';
  description?: string;
  applicability?: string;
}

export interface StudentFeeSummary {
  studentRegistrationNumber: string;
  studentName: string;
  className: string;
  programName: string;
  department: string;
  semester: number;
  section: string;
  academicSession: string;
  totalDue: number;
  totalPaid: number;
  totalWaived: number;
  totalOutstanding: number;
  totalBilled?: number;
  outstandingBalance?: number;
  status: 'Paid' | 'Partial' | 'Partially Paid' | 'Unpaid' | 'Overdue' | string;
  assignments: FeeAssignment[];
  payments: PaymentRecord[];
  receipts: FeeReceipt[];
}

export interface FinanceDashboardMetrics {
  totalFeesAssigned: number;
  totalAmountCollected: number;
  totalOutstanding: number;
  totalWaived: number;
  studentsWithOutstandingCount: number;
  totalStudentsAssignedCount: number;
  todayCollection: number;
  recentPayments: PaymentRecord[];
  recentReceipts: FeeReceipt[];
  categoryCollectionBreakdown: { name: string; count: number; total: number; percentage: number }[];
  paymentModeBreakdown: { name: string; count: number; total: number; percentage: number }[];
}

export type FinanceTab =
  | 'overview'
  | 'structure'
  | 'assignments'
  | 'student-fees'
  | 'payments'
  | 'receipts'
  | 'outstanding'
  | 'refunds-adjustments'
  | 'scholarships'
  | 'hostel-fees'
  | 'reports'
  | 'audit-settings';


