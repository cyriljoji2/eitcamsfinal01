import { AuthSession } from '../services/dataAdapter';
import { PortalType } from './portal';

export interface UserSession {
  id: string;
  username: string;
  name?: string;
  email?: string;
  displayName?: string;
  role: string;
  employeeRole?: string;
  roleTitle?: string;
  department?: string;
  portalType: string | PortalType;
  employeeId?: string;
  permanentOffice?: any;
}

export type EmployeeRole =
  | 'super_admin'
  | 'academic'
  | 'admission'
  | 'finance'
  | 'examination'
  | 'hostel'
  | 'faculty'
  | 'staff';

export type { AuthSession };
export { PortalType };

