export * from './database';
export * from './auth';
export * from './portal';
export * from './itDepartment';
export type {
  FeeAssignment,
  FeeReceipt,
  PaymentRecordItem,
} from './studentPortalTypes';
export type {
  PaymentMode,
  FeeStructureItem,
  StudentFeeSummary,
  FinanceTab,
} from './finance';
export type { FinanceDashboardMetrics as OfficeFinanceDashboardMetrics } from './finance';

export interface AuditLogEntry {
  id?: string;
  log_id?: string;
  timestamp: string;
  actorId?: string;
  actor_id?: string;
  actorOffice?: string;
  actor_role?: string;
  action: string;
  entityType?: string;
  entityId?: string;
  target_worksheet?: string;
  target_record_id?: string;
  description?: string;
  details?: any;
}
