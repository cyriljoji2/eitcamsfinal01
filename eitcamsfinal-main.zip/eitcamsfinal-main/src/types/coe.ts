/**
 * University Controller of Examinations (COE) Data Types
 * Electrix Institute of Technology (EIT) Autonomous University Management System
 */

import {
  ExamType,
  ExamSessionStatus,
  ExamLifecycleStatus,
  ExamAttendanceStatus,
  ExamResultStatus,
  ExamSessionRecord,
  ExamScheduleRecord,
  ExamAttendanceEntryRecord,
  ExamMarkCorrectionRecord,
  ExamResultRecord,
  StudentEligibilityDetail,
  COEDashboardMetrics,
  StudentTranscriptSummary,
} from './database';

export type CoeTab =
  | 'overview'
  | 'exams'
  | 'exam-management'
  | 'schedule'
  | 'exam-schedule'
  | 'eligibility'
  | 'hall-tickets'
  | 'mark-entry'
  | 'verification'
  | 'marks-verification'
  | 'results'
  | 'reports';

export interface UniversityExamSession extends ExamSessionRecord {
  department?: string;
  programme_code?: string;
  registration_deadline?: string;
}

export interface UniversityHallTicket {
  id: string;
  hallTicketNumber: string;
  examinationId: string;
  examinationName: string;
  academicSession: string;
  studentRegistrationNumber: string;
  studentName: string;
  programmeName: string;
  department: string;
  semester: number;
  section: string;
  dateOfBirth?: string;
  institutionName: string;
  institutionAddress: string;
  candidatePhotoUrl?: string;
  schedules: Array<{
    courseCode: string;
    courseName: string;
    examDate: string;
    startTime: string;
    endTime: string;
    room: string;
    examType: string;
    maxMarks?: number;
  }>;
  instructions: string[];
  issuedAt: string;
  isEligible: boolean;
}

export interface UniversityEligibilityRecord extends Omit<StudentEligibilityDetail, 'section'> {
  examinationId: string;
  academicYear: string;
  semester: number;
  programmeName?: string;
  department?: string;
  section?: string;
  attendanceThreshold: number;
  feeClearanceStatus: 'CLEARED' | 'PENDING' | 'EXEMPTED';
  overrideReason?: string;
  overriddenBy?: string;
  overriddenAt?: string;
}

export interface UniversityMarkEntryRow {
  student_id: string;
  registration_number: string;
  student_name: string;
  course_code: string;
  course_title: string;
  internal_marks: number;
  external_marks: number;
  total_marks: number;
  max_marks: number;
  passing_marks: number;
  grade?: string;
  attendance_status: ExamAttendanceStatus;
  submission_status: ExamLifecycleStatus;
  faculty_notes?: string;
}

export interface UniversityReportFilter {
  sessionId?: string;
  academicYear?: string;
  programmeCode?: string;
  department?: string;
  semester?: number;
  courseCode?: string;
}
