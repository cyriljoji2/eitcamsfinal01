import { CourseOfferingRecord } from './database';
export type {
  AcademicClass,
  AcademicSection,
  AcademicSession,
  AcademicSubject,
  FacultyAssignment,
  ProctorAssignment,
} from './studentPortalTypes';

export type { CourseOfferingRecord };

export type AttendanceStatus =
  | 'Present'
  | 'Absent'
  | 'Late'
  | 'Leave'
  | 'PRESENT'
  | 'ABSENT'
  | 'EXCUSED'
  | 'LATE';

export interface AttendanceRecord {
  id?: string;
  attendance_id?: string;
  date: string;
  course_code?: string;
  session_slot?: string;
  student_id?: string;
  studentId?: string;
  studentName?: string;
  registration_number?: string;
  registrationNumber?: string;
  status: AttendanceStatus;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  recordedBy?: string;
  recordedById?: string;
  recorded_by_employee_id?: string;
  remarks?: string;
  academic_year?: string;
  academicSession?: string;
  semester?: number | string;
  created_at?: string;
  recordedAt?: string;
}

export type DepartmentStatus = 'active' | 'inactive';

export interface AcademicDepartment {
  id: string;
  code: string;
  name: string;
  headOfDepartmentId?: string;
  headOfDepartmentName?: string;
  headOfDepartment?: string;
  description?: string;
  status: DepartmentStatus;
  createdAt?: string;
}

export type ClassStatus = 'active' | 'inactive';
export type SectionStatus = 'active' | 'inactive';
export type SubjectStatus = 'active' | 'inactive';
export type SubjectType = 'Theory' | 'Practical' | 'Both' | 'Elective' | string;
export type AssignmentStatus = 'active' | 'completed';

export interface AcademicCurriculumEntry {
  id: string;
  courseCode: string;
  courseTitle: string;
  courseName?: string;
  credits: number;
  courseType?: string;
  type?: string;
  category?: string;
  basket?: string;
  semester?: number;
  department?: string;
  programme?: string;
  program?: string;
  batch?: string;
  prerequisites?: string[];
  syllabusDescription?: string;
}

export interface CsvCurriculumValidationResult {
  isValid: boolean;
  errors: string[];
  parsedRows: any[];
  validRows: any[];
  invalidRows: { rowNumber: number; data: any; errors: string[] }[];
  totalCount: number;
  totalRows: number;
}

export interface StudentAcademicSummary {
  studentId: string;
  fullName: string;
  registrationNumber: string;
  program: string;
  batch: string;
  currentSemester: string;
  section: string;
  className?: string;
  sectionName?: string;
  status: string;
  email: string;
  mobile: string;
  accountStatus?: string;
  admissionDate?: string;
  guardianName?: string;
  enrolledCourses: {
    code: string;
    title: string;
    credits: number;
    section: string;
    facultyName?: string;
  }[];
  subjects?: any[];
  facultyAssignments?: any[];
  totalCredits: number;
  proctor?: {
    name: string;
    email?: string;
    phone?: string;
    department?: string;
  } | null;
  attendanceRate?: number;
  attendancePercentage?: number;
  attendancePresent?: number;
  attendanceTotal?: number;
  attendanceLate?: number;
  attendanceLeave?: number;
  attendanceAbsent?: number;
}

export interface AcademicActivityLog {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  actor: string;
  type: string;
  action?: string;
  details?: string;
  performedBy?: string;
}

// =============================================================================
// Manual Course Offerings: Bulk Enrolment & CSV Import Contracts
// =============================================================================

export interface BulkEnrolmentRequest {
  academic_year: string;
  semester: number;
  programme_code: string;
  batch?: string;
  section?: string;
  section_code?: string;
  offering_ids: string[];
  student_ids?: string[]; // Used in 'selected_students' mode
  selected_student_ids?: string[]; // Alias for student_ids
  mode: 'programme_section' | 'selected_students' | 'cohort';
}

export interface BulkEnrolmentPreReview {
  total_selected_students: number;
  total_students?: number;
  eligible_students_count: number;
  eligible_students?: number;
  students_already_enrolled_count: number;
  already_enrolled?: number;
  ineligible_students_count: number;
  ineligible_students?: number;
  duplicate_enrolments_count: number;
  duplicate_enrolments?: number;
  capacity_limited_count: number;
  capacity_limited?: number;
  courses_selected: Array<{
    offering_id: string;
    course_code: string;
    course_title: string;
    current_enrolments: number;
    max_capacity: number;
    available_seats: number;
  }>;
  expected_successful: number;
  expected_rejected: number;
  breakdown: Array<{
    student_id: string;
    registration_number: string;
    student_name: string;
    offering_id: string;
    course_code: string;
    section?: string;
    status: 'ELIGIBLE' | 'ALREADY_ENROLLED' | 'INELIGIBLE_PROGRAMME' | 'CAPACITY_EXCEEDED' | 'DUPLICATE_IN_REQUEST' | 'INELIGIBLE' | 'DUPLICATE' | 'CAPACITY_FULL';
    reason?: string;
  }>;
  details?: Array<{
    student_id: string;
    registration_number: string;
    student_name: string;
    offering_id: string;
    course_code: string;
    section?: string;
    status: string;
    reason?: string;
  }>;
}

export interface BulkEnrolmentResult {
  total_attempted: number;
  batch_id?: string;
  successful_count?: number;
  skipped_count?: number;
  failed_count?: number;
  successful: Array<{
    enrolment_id: string;
    student_id: string;
    registration_number: string;
    student_name: string;
    offering_id: string;
    course_code: string;
  }>;
  skipped: Array<{
    student_id: string;
    registration_number: string;
    student_name: string;
    offering_id: string;
    course_code: string;
    reason: string;
  }>;
  failed: Array<{
    student_id: string;
    registration_number: string;
    student_name: string;
    offering_id: string;
    course_code: string;
    reason: string;
  }>;
  results?: Array<{
    student_name?: string;
    registration_number?: string;
    course_code: string;
    status: 'SUCCESS' | 'SKIPPED' | 'FAILED' | string;
    message: string;
  }>;
}

export interface FfcsCsvRow {
  registration_number: string;
  student_name?: string;
  academic_year: string;
  semester: number | string;
  programme_code: string;
  batch?: string;
  section_code?: string;
  course_code: string;
  course_name?: string;
  preference_rank?: number | string;
  registration_status?: string;
}

export interface CsvImportValidationRow {
  row_index: number;
  row_number?: number;
  raw: Record<string, string>;
  registration_number: string;
  course_code: string;
  course_name?: string;
  student_name?: string;
  student_id?: string;
  offering_id?: string;
  matched_offering_id?: string;
  academic_year: string;
  semester: number;
  programme_code: string;
  section?: string;
  batch?: string;
  status: 'VALID' | 'UNKNOWN_STUDENT' | 'UNKNOWN_COURSE' | 'NO_OFFERING' | 'INCOMPATIBLE_PROGRAMME' | 'INCOMPATIBLE_SEMESTER' | 'DUPLICATE_IN_CSV' | 'ALREADY_ENROLLED' | 'CAPACITY_EXCEEDED' | 'INVALID_FORMAT';
  is_valid?: boolean;
  reasons: string[];
  errors?: string[];
}

export interface CsvImportPreviewReport {
  schema_version: string; // e.g. "EIT-FFCS-REG-V1.0"
  file_name: string;
  total_rows: number;
  valid_rows_count: number;
  invalid_rows_count: number;
  duplicate_rows_count: number;
  already_enrolled_count: number;
  capacity_exceeded_count: number;
  unknown_students_count?: number;
  unknown_courses_count?: number;
  is_valid?: boolean;
  rows: CsvImportValidationRow[];
  can_import_count: number;
}

export interface TimetableConflictDetail {
  type: 'ROOM_CLASH' | 'FACULTY_CLASH' | 'SECTION_CLASH' | 'STUDENT_CLASH' | 'MISSING_FACULTY' | 'MISSING_ROOM' | 'NO_OFFERING' | 'NO_ENROLMENTS';
  conflict_type?: string;
  description: string;
  day_of_week?: string;
  time?: string;
  room?: string;
  faculty_id?: string;
  faculty_name?: string;
  course_code?: string;
  involved_courses?: string[];
  student_id?: string;
  section?: string;
}

export interface TimetableValidationResult {
  isValid: boolean;
  is_valid?: boolean;
  academic_year: string;
  semester: number;
  programme_code: string;
  section: string;
  batch?: string;
  total_slots: number;
  total_slots_checked?: number;
  conflicts: TimetableConflictDetail[];
  warnings: string[];
}
