export type {
  Examination,
  ExamSubjectSchedule,
  HallTicket,
  StudentExamResult,
  StudentSubjectMark,
} from './studentPortalTypes';
