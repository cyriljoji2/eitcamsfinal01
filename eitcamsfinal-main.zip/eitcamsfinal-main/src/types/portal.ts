export enum PortalType {
  Student = 'student',
  Employee = 'employee',
  Parent = 'parent',
}

export type ActiveRoute =
  | { view: 'home' }
  | { view: 'login'; portal: PortalType }
  | { view: 'dashboard'; portal: PortalType };

export interface PortalGatewayConfig {
  id: PortalType;
  title: string;
  description: string;
  buttonLabel: string;
  loginHeading: string;
  loginSubtitle: string;
  usernameLabel: string;
  usernamePlaceholder: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}
