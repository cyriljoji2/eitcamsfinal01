export type {
  ProctorAssignment,
  ProctorMessage,
  LeaveOutingRequestType,
  LeaveReasonCategory,
  LeaveOutingRequest,
} from './studentPortalTypes';

export type ProctorRemarkCategory =
  | 'academic'
  | 'attendance'
  | 'disciplinary'
  | 'personal'
  | 'general';

export interface ProctorRemark {
  id: string;
  proctorId: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName?: string;
  category: ProctorRemarkCategory;
  remark: string;
  actionRequired?: boolean;
  status?: 'open' | 'resolved';
  createdAt: string;
}

