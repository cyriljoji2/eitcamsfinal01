export interface FFCSRegisteredCourse {
  offeringId: string;
  courseCode: string;
  courseName: string;
  credits: number;
  slot: string;
  facultyName?: string;
  timeSlotLabel?: string;
  room?: string;
  status: string;
  slotCode?: string;
  courseType?: string;
  ltpc?: string;
  category?: string;
  courseOption?: string;
}

export interface FFCSStudentRegistration {
  registrationId: string;
  studentRegistrationNumber: string;
  totalCredits: number;
  status: string;
  semester?: string;
  registeredCourses: FFCSRegisteredCourse[];
}

export type FFCSRegistrationWindowStatus = 'Open' | 'Closed' | 'Upcoming' | 'Disabled';

export interface FFCSRegistrationWindow {
  windowId: string;
  id?: string;
  name?: string;
  program: string;
  batch: string;
  semester: string;
  startDate: string;
  endDate: string;
  minCredits: number;
  maxCredits: number;
}

export function getRegistrationWindowStatus(
  window?: FFCSRegistrationWindow | null,
  currentDate?: Date
): FFCSRegistrationWindowStatus {
  if (!window) return 'Disabled';
  const now = (currentDate || new Date()).getTime();
  const start = new Date(window.startDate).getTime();
  const end = new Date(window.endDate).getTime();
  if (now >= start && now <= end) return 'Open';
  if (now < start) return 'Upcoming';
  return 'Closed';
}

export interface FFCSCourse {
  courseId: string;
  courseCode: string;
  courseTitle: string;
  credits: number;
  courseType?: string;
  type?: string;
  semester?: string | number;
  prerequisites?: string[];
  coRequisites?: string[];
  antiRequisites?: string[];
  department?: string;
  description?: string;
  id?: string;
  code?: string;
  name?: string;
  program?: string;
}

export interface FFCSCourseOffering {
  offeringId: string;
  id?: string;
  courseCode: string;
  courseName?: string;
  facultyName: string;
  slot: string;
  slotCode?: string;
  timeSlotLabel?: string;
  room: string;
  credits?: number;
  registeredCount?: number;
  capacity?: number;
}

export interface FFCSWindowBasket {
  id: string;
  name: string;
  basketCode?: string;
  shortCode?: string;
  minCredits?: number;
  maxCredits?: number;
  category?: string;
  required?: boolean;
  isMandatory?: boolean;
  selectionRule?: string;
}

export interface FFCSWindowCourse {
  id: string;
  windowId: string;
  courseId: string;
  basketId?: string;
  courseCode: string;
  courseTitle: string;
  credits: number;
}
