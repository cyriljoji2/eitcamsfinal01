import { EmployeeRole } from './auth';

export type GenderType = 'Male' | 'Female' | 'Other' | 'Prefer not to say';

export type EmployeeStatus = 'active' | 'inactive' | 'probation' | 'terminated' | 'resigned' | 'retired';

export interface Employee {
  id: string; // e.g. "EMP-001" or registration_number
  employeeId: string;
  registrationNumber?: string;
  fullName: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  gender?: GenderType | string;
  mobile: string;
  phoneNumber?: string;
  email: string;
  institutionalEmail?: string;
  address?: string;
  department: string;
  primaryDepartment?: string;
  designation: string;
  role: string;
  roles?: string[];
  category?: 'TEACHING' | 'NON_TEACHING';
  isTeachingStaff: boolean;
  joiningDate?: string;
  status: EmployeeStatus | string;
  username: string;
  isTemporaryPassword?: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface EmployeeFormData {
  fullName: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth: string;
  gender: GenderType;
  mobile: string;
  email: string;
  address?: string;
  department: string;
  designation: string;
  role: EmployeeRole | string;
  category?: 'TEACHING' | 'NON_TEACHING';
  joiningDate: string;
  status: 'active' | 'inactive';
}

export interface SystemSettings {
  schoolName: string;
  schoolAddress: string;
  contactNumber: string;
  email: string;
  academicYear: string;
  activeAcademicYearId?: string;
  campusCode?: string;
  sessionTimeout?: string;
  passwordMinLength?: string;
}

export interface CsvValidationItem {
  rowNumber: number;
  raw: Record<string, string>;
  parsedData: EmployeeFormData | null;
  isValid: boolean;
  isDuplicate?: boolean;
  errors: string[];
}

export interface CsvValidationResult {
  totalRows: number;
  validCount: number;
  invalidCount: number;
  duplicateCount: number;
  items: CsvValidationItem[];
}

export interface AcademicYearItem {
  yearId: string;
  code: string;
  name: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  status: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
  createdAt?: string;
}

export interface AcademicYearTransitionItem {
  transitionId: string;
  previousYearCode: string;
  newYearCode: string;
  activatedByUserId: string;
  activatedByName: string;
  activatedByRole: string;
  timestamp: string;
  reason: string;
  status: 'SUCCESS' | 'REVERTED';
}
