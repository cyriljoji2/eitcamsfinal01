/**
 * University Admissions & Enrollment Type Definitions
 * Electrix Institute of Technology (EIT) CAMS
 *
 * Mapped authoritatively to EIT database models and enterprise governance.
 */

import {
  ApplicantRecord,
  ApplicantDocumentRecord,
  ApplicationStatus,
  StudentRecord,
  DepartmentRecord,
  ProgrammeRecord,
  AcademicYearRecord,
} from './database';

export type { Student } from './studentPortalTypes';

export type AdmissionTab = 'overview' | 'applications' | 'students' | 'documents' | 'import';

export const UNIVERSITY_DOCUMENT_TEMPLATES = [
  { documentCode: 'DOC_PHOTO', documentType: 'Passport Size Photograph', isMandatory: true },
  { documentCode: 'DOC_ID', documentType: 'National Identity / Passport Copy', isMandatory: true },
  { documentCode: 'DOC_10TH', documentType: 'Secondary School (10th) Certificate & Marksheet', isMandatory: true },
  { documentCode: 'DOC_12TH', documentType: 'Higher Secondary (12th / Diploma) Marksheet', isMandatory: true },
  { documentCode: 'DOC_ENTRANCE', documentType: 'Entrance Examination Scorecard (JEE / CET / GATE)', isMandatory: false },
  { documentCode: 'DOC_TRANSFER', documentType: 'Transfer / Leaving Certificate', isMandatory: false },
  { documentCode: 'DOC_MIGRATION', documentType: 'Migration Certificate', isMandatory: false },
];

export const UNIVERSITY_ADMISSION_CATEGORIES = [
  'General Merit',
  'State Domicile Quota',
  'All India Seats',
  'Management Quota',
  'Sports & Extracurricular Quota',
  'NRI / International Quota',
  'Lateral Entry (Direct 2nd Year)',
];

export const UNIVERSITY_STUDY_MODES = [
  'Full-Time On-Campus',
  'Part-Time / Evening',
  'Industry Sponsored',
  'Research Scholar',
];

export interface UniversityAdmissionFormData {
  // Step 1: Personal Information
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: string;
  nationality: string;
  email: string;
  mobile: string;
  alternatePhone?: string;
  currentAddress: string;
  permanentAddress?: string;

  // Step 2: Parent / Guardian Information
  guardianName: string;
  guardianRelationship: string;
  guardianMobile: string;
  guardianEmail?: string;
  guardianAddress?: string;

  // Step 3: Previous Education
  previousInstitution: string;
  institutionType: string;
  country: string;
  boardOrUniversity: string;
  previousQualification: string;
  completionYear: number;
  examRollNumber?: string;
  marksPercentage: number;
  cgpa?: number;

  // Step 4: University Programme Selection
  admissionAcademicYear: number;
  departmentCode: string;
  programmeCode: string;
  intendedProgram: string;
  degreeLevel: string;
  admissionCategory: string;
  studyMode: string;

  // Step 5: Entrance Examination & Eligibility
  entranceExamName?: string;
  entranceExamRoll?: string;
  entranceExamYear?: number;
  entranceExamScore?: string;
  eligibilityNotes?: string;

  // Step 6: Documents
  documents: Array<{
    documentCode: string;
    documentType: string;
    isMandatory: boolean;
    fileName?: string;
    submissionStatus: 'PENDING' | 'SUBMITTED';
  }>;

  // Step 7: Application Status at Submission
  applicationStatus: ApplicationStatus;
}

export interface UniversityDocumentRow {
  documentId: string;
  applicationId: string;
  applicantName: string;
  applicantEmail: string;
  department: string;
  intendedProgram: string;
  documentType: string;
  documentCode: string;
  isMandatory: boolean;
  submissionStatus: 'PENDING' | 'SUBMITTED';
  verificationStatus: 'PENDING' | 'VERIFIED' | 'REJECTED';
  reviewerNotes?: string;
  verifiedBy?: string;
  verifiedAt?: string;
  applicant: ApplicantRecord;
}

export interface CsvUniversityApplicantRow {
  rowNumber: number;
  fullName: string;
  dateOfBirth: string;
  gender: string;
  email: string;
  mobile: string;
  department: string;
  program: string;
  admissionYear: number;
  previousQualification: string;
  marksPercentage: number;
  guardianName?: string;
  guardianPhone?: string;
  entranceExam?: string;
  entranceScore?: string;
  raw: Record<string, string>;
  isValid: boolean;
  validationErrors: string[];
  duplicateReason?: string;
}

export interface CsvUniversityValidationResult {
  fileName: string;
  totalRows: number;
  validRowsCount: number;
  invalidRowsCount: number;
  rows: CsvUniversityApplicantRow[];
  departmentsAvailable: string[];
  programmesAvailable: string[];
}

export interface UniversityAdmissionMetrics {
  totalApplications: number;
  newApplications: number;
  underReview: number;
  documentsPending: number;
  approved: number;
  rejected: number;
  waitlisted: number;
  convertedStudents: number;
  byDepartment: Record<string, number>;
  byProgramme: Record<string, number>;
  docsPendingVerificationCount: number;
}
