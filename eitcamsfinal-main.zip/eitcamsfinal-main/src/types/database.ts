/**
 * Database Schema and Type Definitions for Electrix Institute of Technology (EIT)
 * Academic & Administrative Management System — Google Sheets Database Layer (Phase 2 & Phase 3 Ready)
 */

import { PortalType } from './portal';
export { PortalType };

// -----------------------------------------------------------------------------
// The Six Permanent Office Keys
// -----------------------------------------------------------------------------
export enum PermanentOfficeKey {
  ADMINISTRATION = 'ADMINISTRATION',
  ADMISSIONS = 'ADMISSIONS',
  ACADEMIC = 'ACADEMIC',
  COE = 'COE',
  FINANCE = 'FINANCE',
  HOSTEL = 'HOSTEL',
  IT = 'IT',
}

// -----------------------------------------------------------------------------
// Authentication & Identity Enums
// -----------------------------------------------------------------------------
export enum AuthRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  OFFICE_ADMIN = 'OFFICE_ADMIN',
  FACULTY = 'FACULTY',
  NON_TEACHING_STAFF = 'NON_TEACHING_STAFF',
  STUDENT = 'STUDENT',
  PARENT = 'PARENT',
}

export enum AccountStatus {
  ACTIVE = 'ACTIVE',
  LOCKED = 'LOCKED',
  SUSPENDED = 'SUSPENDED',
  PASSWORD_RESET_REQUIRED = 'PASSWORD_RESET_REQUIRED',
}

export enum LinkedRecordType {
  PERMANENT_OFFICE = 'PERMANENT_OFFICE',
  EMPLOYEE = 'EMPLOYEE',
  STUDENT = 'STUDENT',
  PARENT = 'PARENT',
}

// -----------------------------------------------------------------------------
// Employee & Staff Enums
// -----------------------------------------------------------------------------
export enum EmployeeCategory {
  TEACHING = 'TEACHING',
  NON_TEACHING = 'NON_TEACHING',
}

export enum EmploymentStatus {
  ACTIVE = 'ACTIVE',
  ON_LEAVE = 'ON_LEAVE',
  PROBATION = 'PROBATION',
  RESIGNED = 'RESIGNED',
  RETIRED = 'RETIRED',
  TERMINATED = 'TERMINATED',
}

export enum FacultyCourseRole {
  PRIMARY_INSTRUCTOR = 'PRIMARY_INSTRUCTOR',
  CO_INSTRUCTOR = 'CO_INSTRUCTOR',
  LAB_FACULTY = 'LAB_FACULTY',
  TEACHING_ASSISTANT = 'TEACHING_ASSISTANT',
}

export enum OfficeAssignmentStatus {
  ACTIVE = 'ACTIVE',
  REVOKED = 'REVOKED',
  EXPIRED = 'EXPIRED',
  TRANSFERRED = 'TRANSFERRED',
}

export enum PermissionScope {
  READ = 'READ',
  WRITE = 'WRITE',
  APPROVE = 'APPROVE',
  AUDIT = 'AUDIT',
  ADMIN = 'ADMIN',
}

// -----------------------------------------------------------------------------
// Student & Academic Enums
// -----------------------------------------------------------------------------
export enum StudentStatus {
  ENROLLED = 'ENROLLED',
  SUSPENDED = 'SUSPENDED',
  GRADUATED = 'GRADUATED',
  WITHDRAWN = 'WITHDRAWN',
  ON_LEAVE = 'ON_LEAVE',
}

export enum AcademicStanding {
  GOOD_STANDING = 'GOOD_STANDING',
  ACADEMIC_PROBATION = 'ACADEMIC_PROBATION',
  DEANS_LIST = 'DEANS_LIST',
  HONORS = 'HONORS',
}

export enum ParentRelationship {
  FATHER = 'FATHER',
  MOTHER = 'MOTHER',
  LEGAL_GUARDIAN = 'LEGAL_GUARDIAN',
  OTHER = 'OTHER',
}

export enum AttendanceStatus {
  PRESENT = 'PRESENT',
  ABSENT = 'ABSENT',
  EXCUSED = 'EXCUSED',
  LATE = 'LATE',
}

export enum ExamStatus {
  SCHEDULED = 'SCHEDULED',
  APPEARED = 'APPEARED',
  ABSENT = 'ABSENT',
  MALPRACTICE = 'MALPRACTICE',
  WITHHELD = 'WITHHELD',
  DECLARED = 'DECLARED',
}

export enum PaymentStatus {
  PENDING = 'PENDING',
  PARTIAL = 'PARTIAL',
  PAID = 'PAID',
  REFUNDED = 'REFUNDED',
  OVERDUE = 'OVERDUE',
  WAIVED = 'WAIVED',
}

export enum HostelAllocationStatus {
  REQUESTED = 'REQUESTED',
  ALLOCATED = 'ALLOCATED',
  OCCUPIED = 'OCCUPIED',
  VACATED = 'VACATED',
  SUSPENDED = 'SUSPENDED',
}

export enum AuditAction {
  LOGIN_ATTEMPT = 'LOGIN_ATTEMPT',
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  PERMISSION_GRANT = 'PERMISSION_GRANT',
  PERMISSION_REVOKE = 'PERMISSION_REVOKE',
  OFFICE_ASSIGN = 'OFFICE_ASSIGN',
  COURSE_ASSIGN = 'COURSE_ASSIGN',
  PAYMENT_RECEIPT = 'PAYMENT_RECEIPT',
  GRADE_SUBMIT = 'GRADE_SUBMIT',
  GRADE_APPROVE = 'GRADE_APPROVE',
  ADMISSION_DECISION = 'ADMISSION_DECISION',
  ADMISSION_CONVERT = 'ADMISSION_CONVERT',
  ENROLMENT = 'ENROLMENT',
  ENROLMENT_TRANSFER = 'ENROLMENT_TRANSFER',
  ENROLMENT_WITHDRAW = 'ENROLMENT_WITHDRAW',
  TIMETABLE_SCHEDULE = 'TIMETABLE_SCHEDULE',
  EXAM_SESSION_CREATE = 'EXAM_SESSION_CREATE',
  EXAM_SCHEDULE_CREATE = 'EXAM_SCHEDULE_CREATE',
  EXAM_SCHEDULE_UPDATE = 'EXAM_SCHEDULE_UPDATE',
  EXAM_SCHEDULE_CANCEL = 'EXAM_SCHEDULE_CANCEL',
  EXAM_ATTENDANCE_RECORD = 'EXAM_ATTENDANCE_RECORD',
  EXAM_ATTENDANCE_CORRECT = 'EXAM_ATTENDANCE_CORRECT',
  EXAM_MARKS_DRAFT = 'EXAM_MARKS_DRAFT',
  EXAM_MARKS_SUBMIT = 'EXAM_MARKS_SUBMIT',
  EXAM_MODERATION = 'EXAM_MODERATION',
  EXAM_APPROVE = 'EXAM_APPROVE',
  EXAM_PUBLISH = 'EXAM_PUBLISH',
  EXAM_REOPEN = 'EXAM_REOPEN',
  EXAM_RESULT_CORRECT = 'EXAM_RESULT_CORRECT',
  APPROVE = 'APPROVE',
  TIMETABLE_VALIDATE = 'TIMETABLE_VALIDATE',
  TIMETABLE_PUBLISH = 'TIMETABLE_PUBLISH',
  TIMETABLE_REPUBLISH = 'TIMETABLE_REPUBLISH',
  BULK_ENROLMENT = 'BULK_ENROLMENT',
  CSV_REGISTRATION_IMPORT = 'CSV_REGISTRATION_IMPORT',
  IT_PASSWORD_RESET = 'IT_PASSWORD_RESET',
  IT_ID_CARD_GENERATE = 'IT_ID_CARD_GENERATE',
  IT_ID_CARD_REISSUE = 'IT_ID_CARD_REISSUE',
  IT_ID_CARD_STATUS_UPDATE = 'IT_ID_CARD_STATUS_UPDATE',
  IT_TEST_ACCOUNT_TOGGLE = 'IT_TEST_ACCOUNT_TOGGLE',
  IT_TICKET_CREATE = 'IT_TICKET_CREATE',
  IT_TICKET_UPDATE = 'IT_TICKET_UPDATE',
  IT_TICKET_ASSIGN = 'IT_TICKET_ASSIGN',
  IT_TICKET_RESOLVE = 'IT_TICKET_RESOLVE',
  IT_SLA_POLICY_UPDATE = 'IT_SLA_POLICY_UPDATE',
  IT_CONTACT_SETTINGS_UPDATE = 'IT_CONTACT_SETTINGS_UPDATE',
  IT_BACKUP_EXECUTE = 'IT_BACKUP_EXECUTE',
  IT_PERMISSION_CHANGE = 'IT_PERMISSION_CHANGE',
}

// =============================================================================
// Worksheet 1: PermanentOffices (Fixed 6 Institutional Accounts)
// =============================================================================
export interface PermanentOfficeRecord {
  office_id: string; // PK: e.g. "PO-001"
  office_key: PermanentOfficeKey; // Unique enum
  office_name: string; // e.g. "Administration Office"
  canonical_username: string; // UK: e.g. "admin", "admissionsoffice", "academicoffice", "coeoffice", "financeoffice", "hosteloffice"
  office_code: string; // UK: "ADM", "ADM-OFF", "ACA", "COE", "FIN", "HOS"
  description: string;
  is_super_admin: boolean; // TRUE for Administration Office
  is_system_reserved: boolean; // Always TRUE, prevents application duplication
  allow_self_registration: boolean; // Always FALSE
  primary_contact_email: string;
  created_at: string;
  status: 'ACTIVE' | 'ARCHIVED';
}

// =============================================================================
// Worksheet 2: AuthUsers (Authentication, Identity, Password Hashes, Security)
// =============================================================================
export interface AuthUserRecord {
  user_id: string; // PK: e.g. "USR-0001" or UUID
  username: string; // UK: lowercase unique identifier (e.g. "admin", "EIT-STU-2026-CSE-0042")
  password_hash: string; // Securely salted bcrypt / argon2 hash. NEVER plaintext!
  password_salt?: string; // Optional cryptographic salt
  portal_type: PortalType; // 'student' | 'employee' | 'parent'
  role: AuthRole; // 'SUPER_ADMIN' | 'OFFICE_ADMIN' | 'FACULTY' | 'NON_TEACHING_STAFF' | 'STUDENT' | 'PARENT'
  linked_record_type: LinkedRecordType; // Which table this identity anchors to
  linked_record_id: string; // FK to PermanentOffices.office_id, Employees.employee_id, Students.student_id, or Parents.parent_id
  account_status: AccountStatus; // 'ACTIVE' | 'LOCKED' | 'SUSPENDED' | 'PASSWORD_RESET_REQUIRED'
  failed_login_attempts: number; // Counter for rate limiting & account locking
  lockout_until?: string; // ISO 8601 UTC timestamp if account is temporarily locked
  last_login_at?: string; // ISO 8601 UTC timestamp of last successful authentication
  password_updated_at: string; // ISO 8601 UTC timestamp for password aging policy
  created_at: string; // ISO 8601 UTC timestamp
  updated_at: string; // ISO 8601 UTC timestamp
}

// =============================================================================
// Worksheet 3: Employees (Teaching and Non-Teaching Staff Directory)
// =============================================================================
export interface EmployeeRecord {
  employee_id: string; // PK: Internal UUID or "EMP-XXXX"
  registration_number: string; // UK: e.g. "EIT-TCH-CSE-2026-001" or "EIT-NTC-ADM-2026-001"
  category: EmployeeCategory; // 'TEACHING' | 'NON_TEACHING'
  first_name: string;
  last_name: string;
  institutional_email: string; // UK: e.g. "j.smith@eit.edu"
  phone_number: string;
  primary_department: string; // e.g. "Computer Science & Engineering", "Finance Division"
  designation: string; // e.g. "Associate Professor", "Accounts Executive"
  employment_status: EmploymentStatus;
  date_of_joining: string; // ISO Date YYYY-MM-DD
  reporting_manager_id?: string; // FK -> Employees.employee_id
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 4: FacultyCourseAssignments (Teaching Faculty Assigned to Courses)
// =============================================================================
export interface FacultyCourseAssignmentRecord {
  faculty_assignment_id: string; // PK: e.g. "FCA-2026-0001"
  employee_id: string; // FK -> Employees.employee_id (Must be category === 'TEACHING')
  course_code: string; // e.g. "CS201"
  course_title: string; // e.g. "Data Structures & Algorithms"
  department: string; // e.g. "CSE"
  semester: number; // 1-8
  academic_year: string; // e.g. "2026-2027"
  section: string; // e.g. "A"
  role_in_course: FacultyCourseRole;
  assignment_status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  assigned_by_office_id: string; // FK -> PermanentOffices.office_id (Must be ACADEMIC office)
  effective_from: string; // ISO Date YYYY-MM-DD
  effective_to?: string; // ISO Date YYYY-MM-DD
  created_at: string;
  employee_name?: string;
  employee_registration?: string;
  updated_at?: string;
}

// =============================================================================
// Worksheet 5: OfficeAssignments (Administration Assigns Non-Teaching Staff)
// =============================================================================
export interface OfficeAssignmentRecord {
  assignment_id: string; // PK: e.g. "OAS-2026-0001"
  employee_id: string; // FK -> Employees.employee_id (Must be category === 'NON_TEACHING')
  office_id: string; // FK -> PermanentOffices.office_id
  assigned_role_title: string; // e.g. "Junior Accountant", "Assistant Registrar", "Hostel Warden"
  assignment_status: OfficeAssignmentStatus;
  assigned_by_employee_id: string; // FK -> Employees.employee_id (Must hold ADMINISTRATION office role)
  effective_from: string; // ISO Date YYYY-MM-DD
  effective_to?: string; // ISO Date YYYY-MM-DD or empty
  created_at: string;
}

// =============================================================================
// Worksheet 6: OfficePermissions (Managed Exclusively by Respective Authorized Office)
// =============================================================================
export interface OfficePermissionRecord {
  permission_id: string; // PK: e.g. "OPM-2026-0001"
  assignment_id: string; // FK -> OfficeAssignments.assignment_id
  office_id: string; // FK -> PermanentOffices.office_id
  employee_id: string; // FK -> Employees.employee_id
  module_name: string; // e.g. "FeeCollections", "MarksEntry", "RoomAllocation", "AdmissionsIntake"
  permission_scope: PermissionScope; // 'READ' | 'WRITE' | 'APPROVE' | 'AUDIT' | 'ADMIN'
  granted_by_employee_id: string; // FK -> Employees.employee_id (Must have ADMIN scope in this office)
  granted_at: string; // ISO 8601 UTC
  expires_at?: string; // ISO 8601 UTC
  status: 'ACTIVE' | 'REVOKED';
}

// =============================================================================
// Worksheet 7: Students (Student Master Directory)
// =============================================================================
export interface StudentRecord {
  student_id: string; // PK: Internal UUID or "STU-XXXX"
  registration_number: string; // UK: e.g. "EIT-STU-2026-CSE-0042"
  first_name: string;
  last_name: string;
  date_of_birth: string; // ISO Date YYYY-MM-DD
  gender: string;
  institutional_email: string; // UK: e.g. "stu.2026.cse042@student.eit.edu"
  personal_phone: string;
  program_name: string; // e.g. "B.Tech Computer Science & Engineering"
  department: string; // e.g. "CSE"
  admission_year: number; // e.g. 2026
  current_semester: number; // 1-8
  section: string; // e.g. "A"
  enrollment_status: StudentStatus;
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 8: Parents (Parent/Guardian Profile Directory)
// =============================================================================
export interface ParentRecord {
  parent_id: string; // PK: e.g. "PAR-2026-0001"
  first_name: string;
  last_name: string;
  email: string; // UK: official parent communication email
  primary_phone: string; // UK: primary contact phone
  alternate_phone?: string;
  residential_address: string;
  status: 'ACTIVE' | 'INACTIVE';
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 9: ParentStudentLinks (Many-to-Many Association Matrix)
// =============================================================================
export interface ParentStudentLinkRecord {
  link_id: string; // PK: e.g. "PSL-2026-0001"
  parent_id: string; // FK -> Parents.parent_id
  student_id: string; // FK -> Students.student_id
  student_registration_number: string; // FK -> Students.registration_number
  relationship: ParentRelationship; // 'FATHER' | 'MOTHER' | 'LEGAL_GUARDIAN' | 'OTHER'
  is_primary_contact: boolean; // Flag if this parent is the primary emergency contact
  can_view_grades: boolean; // Granular permission: academic reports access
  can_view_attendance: boolean; // Granular permission: attendance tracking access
  can_view_finance: boolean; // Granular permission: invoices and dues access
  emergency_priority: number; // 1 = First call, 2 = Second call
  status: 'ACTIVE' | 'REVOKED';
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 10: AcademicRecords (Coursework, Credits, Semesters, CGPA)
// =============================================================================
export interface AcademicRecord {
  record_id: string; // PK: e.g. "ACR-2026-0001"
  student_id: string; // FK -> Students.student_id
  registration_number: string; // FK -> Students.registration_number
  semester: number; // 1-8
  academic_year: string; // e.g. "2026-2027"
  course_code: string; // e.g. "CS201"
  course_title: string; // e.g. "Data Structures & Algorithms"
  credits: number; // e.g. 4
  grade_point: number; // e.g. 9.0
  letter_grade: string; // e.g. "A+"
  sgpa: number; // Semester GPA
  cgpa: number; // Cumulative GPA
  academic_standing: AcademicStanding;
  published_by_office_id: string; // FK -> PermanentOffices.office_id (Must be COE office)
  updated_at: string;
}

// =============================================================================
// Worksheet 11: Attendance (Daily/Session-wise Attendance Tracking)
// =============================================================================
export interface AttendanceRecord {
  attendance_id: string; // PK: e.g. "ATT-2026-0001"
  id?: string;
  date: string; // ISO Date YYYY-MM-DD
  course_code: string; // e.g. "CS201"
  session_slot: string; // e.g. "09:00-10:00 AM"
  student_id: string; // FK -> Students.student_id
  registration_number: string; // FK -> Students.registration_number
  registrationNumber?: string;
  student_registration_number?: string;
  section?: string;
  status: AttendanceStatus | string; // 'PRESENT' | 'ABSENT' | 'EXCUSED' | 'LATE'
  recorded_by_employee_id: string; // FK -> Employees.employee_id (Must be TEACHING faculty assigned to course)
  recordedBy?: string;
  remarks?: string;
  academic_year?: string;
  academicSession?: string;
  className?: string;
  sectionName?: string;
  semester?: number | string;
  created_at: string;
}

// =============================================================================
// Worksheet 12: Examinations (Exam Sessions, Hall Tickets, Marks, Moderation)
// =============================================================================
export interface ExaminationRecord {
  exam_id: string; // PK: e.g. "EXM-2026-0001"
  exam_session: string; // e.g. "MID_SEM_FALL_2026" | "END_SEM_SPRING_2027"
  course_code: string;
  student_id: string; // FK -> Students.student_id
  hall_ticket_number: string;
  internal_marks: number;
  external_marks: number;
  total_marks: number;
  max_marks: number;
  exam_status: ExamStatus;
  evaluated_by_employee_id: string; // FK -> Employees.employee_id (Assigned faculty)
  moderated_by_office_id: string; // FK -> PermanentOffices.office_id (Must be COE office)
  published_at?: string;
}

// =============================================================================
// Worksheet 13: Finance (Fee Structures, Invoices, Payments, Receipts)
// =============================================================================
export interface FinanceRecord {
  invoice_id: string; // PK: e.g. "INV-2026-0001"
  student_id: string; // FK -> Students.student_id
  registration_number: string;
  fee_category: string; // e.g. "TUITION", "HOSTEL", "EXAM", "LIBRARY", "LABORATORY"
  academic_year: string;
  semester: number;
  amount_due: number;
  amount_paid: number;
  currency: string; // e.g. "USD" or "INR"
  payment_status: PaymentStatus;
  transaction_reference?: string;
  payment_method?: string; // e.g. "ONLINE_GATEWAY", "BANK_TRANSFER", "DEMAND_DRAFT"
  payment_date?: string;
  verified_by_employee_id?: string; // FK -> Employees.employee_id (Finance office staff)
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 14: Hostel (Blocks, Rooms, Bed Allocations, Warden Approvals)
// =============================================================================
export interface HostelRecord {
  allocation_id: string; // PK: e.g. "HST-2026-0001"
  student_id: string; // FK -> Students.student_id
  registration_number: string;
  hostel_block_name: string; // e.g. "Block A - Aryabhata Hall"
  room_number: string; // e.g. "304"
  bed_identifier: string; // e.g. "A", "B"
  status: HostelAllocationStatus;
  check_in_date: string;
  check_out_date?: string;
  allocated_by_employee_id: string; // FK -> Employees.employee_id (Hostel warden / non-teaching staff)
  approved_by_office_id: string; // FK -> PermanentOffices.office_id (Must be HOSTEL office)
  emergency_contact_phone: string;
  created_at: string;
}

// =============================================================================
// Worksheet 15: AuditLogs (Immutable System Traceability & Compliance)
// =============================================================================
export interface AuditLogRecord {
  log_id: string; // PK: e.g. "LOG-2026-0001"
  timestamp: string; // ISO 8601 UTC
  actor_id: string; // User ID, Employee ID, Student ID, or "SYSTEM"
  actor_role: string; // e.g. "SUPER_ADMIN", "OFFICE_ADMIN", "FACULTY", "STUDENT", "PARENT"
  action: AuditAction;
  target_worksheet: string; // Worksheet affected
  target_record_id: string; // PK of affected row
  description: string;
  client_ip?: string;
  user_agent?: string;
}

// =============================================================================
// Worksheet 16: Applicants (Phase 6 Admissions Office Management)
// =============================================================================
export enum ApplicationStatus {
  DRAFT = 'DRAFT',
  SUBMITTED = 'SUBMITTED',
  UNDER_REVIEW = 'UNDER_REVIEW',
  DOCUMENTS_PENDING = 'DOCUMENTS_PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  WITHDRAWN = 'WITHDRAWN',
}

export enum DocumentSubmissionStatus {
  PENDING = 'PENDING',
  SUBMITTED = 'SUBMITTED',
}

export enum DocumentVerificationStatus {
  PENDING = 'PENDING',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
}

export interface ApplicantDocumentRecord {
  document_id: string; // e.g. "DOC-APP-001-1"
  application_id: string; // FK -> Applicants.application_id
  document_type: string; // e.g. "10th Grade Marksheet"
  document_code: string; // e.g. "DOC_10TH"
  is_mandatory: boolean;
  submission_status: DocumentSubmissionStatus | 'PENDING' | 'SUBMITTED';
  verification_status: DocumentVerificationStatus | 'PENDING' | 'VERIFIED' | 'REJECTED';
  reviewer_notes?: string;
  verified_by?: string;
  verified_at?: string;
}

export interface ApplicationStatusHistoryEntry {
  history_id: string;
  previous_status: ApplicationStatus;
  new_status: ApplicationStatus;
  changed_by: string; // Actor ID or username
  timestamp: string; // ISO 8601
  reason?: string;
  notes?: string;
}

export interface ApplicantRecord {
  application_id: string; // PK: e.g. "EIT-APP-2026-0001"
  first_name: string;
  last_name: string;
  date_of_birth: string; // ISO Date YYYY-MM-DD
  gender: string;
  email: string;
  phone_number: string;
  address: string;
  intended_program: string; // e.g. "B.Tech Computer Science & Engineering"
  department: string; // e.g. "CSE"
  admission_year: number; // e.g. 2026
  previous_qualification: string; // e.g. "Higher Secondary School Certificate (10+2)"
  marks_percentage: number; // 0.0 - 100.0
  application_date: string; // ISO Date YYYY-MM-DD
  application_status: ApplicationStatus;
  documents: ApplicantDocumentRecord[];
  status_history: ApplicationStatusHistoryEntry[];
  review_notes?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  decision_reason?: string;
  // Student conversion linkage
  converted_to_student: boolean;
  student_id?: string; // FK -> Students.student_id
  student_registration_number?: string; // e.g. "EIT-STU-2026-CSE-0003"
  // University Extended Admission Dossier Fields
  nationality?: string;
  alternate_phone?: string;
  current_address?: string;
  permanent_address?: string;
  guardian_name?: string;
  guardian_relationship?: string;
  guardian_phone?: string;
  guardian_email?: string;
  guardian_address?: string;
  previous_institution?: string;
  institution_type?: string;
  board_or_university?: string;
  completion_year?: number;
  exam_roll_number?: string;
  cgpa?: number;
  degree_level?: string;
  admission_category?: string;
  study_mode?: string;
  entrance_exam_name?: string;
  entrance_exam_roll?: string;
  entrance_exam_year?: number;
  entrance_exam_score?: string;
  created_at: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 17: AcademicYears & Semesters (Phase 7 Academic Office Management)
// =============================================================================
export interface AcademicYearRecord {
  year_id: string; // PK: e.g. "AY-2026-2027"
  code: string; // UK: e.g. "2026-2027"
  name: string; // e.g. "Academic Year 2026-2027"
  start_date: string; // ISO Date YYYY-MM-DD
  end_date: string; // ISO Date YYYY-MM-DD
  is_current: boolean;
  status: 'ACTIVE' | 'UPCOMING' | 'ARCHIVED';
  created_at?: string;
  updated_at?: string;
}

export interface AcademicYearTransitionAuditRecord {
  transition_id: string;
  previous_year_code: string;
  new_year_code: string;
  activated_by_user_id: string;
  activated_by_name: string;
  activated_by_role: string;
  timestamp: string;
  reason: string;
  status: 'SUCCESS' | 'REVERTED';
}

export interface SystemSettingsRecord {
  institution_name: string;
  campus_code: string;
  campus_address: string;
  contact_phone: string;
  contact_email: string;
  active_academic_year_code: string;
  active_academic_year_id: string;
  session_timeout?: string;
  password_min_length?: string;
  updated_at?: string;
  updated_by?: string;
}


export interface SemesterRecord {
  semester_id: string; // PK: e.g. "SEM-2026-F3"
  academic_year: string; // FK -> AcademicYears.code
  semester_number: number; // 1-8
  term: 'FALL' | 'SPRING' | 'SUMMER';
  name: string; // e.g. "Fall 2026 (Semester 3)"
  start_date: string; // ISO Date YYYY-MM-DD
  end_date: string; // ISO Date YYYY-MM-DD
  is_current: boolean;
  status: 'ACTIVE' | 'ARCHIVED';
}

// =============================================================================
// Worksheet 18: Departments & Programmes
// =============================================================================
export interface DepartmentRecord {
  department_id: string; // PK: e.g. "DEPT-CSE"
  code: string; // UK: e.g. "CSE"
  name: string; // e.g. "Computer Science & Engineering"
  head_of_department_id?: string; // FK -> Employees.employee_id
  description?: string;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface ProgrammeRecord {
  programme_id: string; // PK: e.g. "PROG-BTECH-CSE"
  code: string; // UK: e.g. "BTECH-CSE"
  name: string; // e.g. "B.Tech Computer Science & Engineering"
  department: string; // e.g. "CSE"
  degree_level: 'UNDERGRADUATE' | 'POSTGRADUATE' | 'DOCTORAL';
  duration_semesters: number; // e.g. 8
  total_credits_required: number; // e.g. 160
  status: 'ACTIVE' | 'INACTIVE';
}

// =============================================================================
// Worksheet 19: Courses (Subjects / Curriculum Master)
// =============================================================================
export interface CourseRecord {
  course_id: string; // PK: e.g. "CRS-CS201"
  course_code: string; // UK: e.g. "CS201"
  course_title: string; // e.g. "Data Structures & Algorithms"
  department: string; // e.g. "CSE"
  programme_code: string; // e.g. "BTECH-CSE"
  semester: number; // 1-8
  credits: number; // e.g. 4
  course_type: 'THEORY' | 'PRACTICAL' | 'INTEGRATED';
  description?: string;
  status: 'ACTIVE' | 'ARCHIVED';
}

// =============================================================================
// Worksheet 20: ClassSections
// =============================================================================
export interface ClassSectionRecord {
  section_id: string; // PK: e.g. "SEC-CSE-3A"
  section_name: string; // e.g. "A"
  department: string; // e.g. "CSE"
  programme_code: string; // e.g. "BTECH-CSE"
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8
  max_capacity: number; // e.g. 60
  status: 'ACTIVE' | 'ARCHIVED';
}

// =============================================================================
// Worksheet 21: CourseOfferings (Term Offerings Linking Course, Section, Faculty)
// =============================================================================
export interface CourseOfferingRecord {
  offering_id: string; // PK: e.g. "OFF-2026-CS201-A"
  course_code: string; // FK -> Courses.course_code
  course_title: string;
  department: string;
  programme_code: string;
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8
  section: string; // e.g. "A"
  assigned_faculty_id?: string; // FK -> Employees.employee_id
  assigned_faculty_reg?: string; // e.g. "EIT-TCH-CSE-2026-001"
  assigned_faculty_name?: string;
  status: 'ACTIVE' | 'ARCHIVED' | 'DRAFT' | 'PUBLISHED' | 'CLOSED' | 'CANCELLED';
  created_at: string;
  credits?: number;
  course_type?: string;
  batch?: string;
  max_capacity?: number;
  enrolled_count?: number;
  room?: string;
  timetable_slots?: string[];
  start_date?: string;
  end_date?: string;
  cancellation_reason?: string;
  updated_at?: string;
}

// =============================================================================
// Worksheet 22: CourseEnrolments (Student Course & Section Enrolment Ledger)
// =============================================================================
export interface CourseEnrolmentRecord {
  enrolment_id: string; // PK: e.g. "ENR-2026-0001"
  student_id: string; // FK -> Students.student_id
  student_registration_number: string; // FK -> Students.registration_number
  student_name: string;
  course_code: string; // FK -> Courses.course_code
  course_title: string;
  offering_id: string; // FK -> CourseOfferings.offering_id
  department: string;
  semester: number;
  academic_year: string;
  section: string; // e.g. "A"
  enrolment_status: 'ACTIVE' | 'TRANSFERRED' | 'WITHDRAWN' | 'COMPLETED';
  enrolled_at: string; // ISO 8601
  transfer_reason?: string;
  transferred_to_section?: string;
  transferred_at?: string;
  withdrawal_reason?: string;
  withdrawn_at?: string;
  updated_at: string;
}

// =============================================================================
// Worksheet 23: TimetableSlots (Classroom, Faculty, Section Schedule Matrix)
// =============================================================================
export interface TimetableSlotRecord {
  slot_id: string; // PK: e.g. "TTS-2026-0001"
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8
  department: string; // e.g. "CSE"
  programme_code?: string;
  day_of_week: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';
  start_time: string; // e.g. "09:00"
  end_time: string; // e.g. "10:00"
  course_code: string;
  course_title: string;
  course_name?: string;
  section: string; // e.g. "A"
  faculty_id: string; // FK -> Employees.employee_id
  faculty_reg_number: string; // e.g. "EIT-TCH-CSE-2026-001"
  faculty_name: string;
  room: string; // e.g. "LH-101", "Lab-2B"
  room_number?: string;
  status: 'ACTIVE' | 'CANCELLED' | 'SCHEDULED' | string;
  created_at: string;
}

export enum TimetableLifecycleStatus {
  DRAFT = 'DRAFT',
  VALIDATED = 'VALIDATED',
  PUBLISHED = 'PUBLISHED',
  SUPERSEDED = 'SUPERSEDED',
}

export interface TimetableVersionRecord {
  timetable_id: string; // PK: e.g. "TT-2026-BTECH-CSE-S3-A-V1"
  version_id?: string; // Alias for timetable_id
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8
  programme_code: string; // e.g. "BTECH-CSE"
  batch?: string; // e.g. "2026"
  section: string; // e.g. "A"
  version: number; // 1, 2, 3...
  status: TimetableLifecycleStatus | 'DRAFT' | 'VALIDATED' | 'PUBLISHED' | 'SUPERSEDED';
  slot_ids: string[];
  validation_issues?: string[];
  validated_at?: string;
  validated_by?: string;
  published_at?: string;
  published_by?: string;
  published_by_name?: string;
  change_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CsvImportBatchRecord {
  batch_id: string; // PK: e.g. "CSV-BATCH-20261103-0001"
  file_name: string;
  schema_version: string; // e.g. "EIT-FFCS-REG-V1.0"
  academic_year: string;
  semester: number;
  programme_code?: string;
  imported_by_id: string;
  imported_by_name: string;
  imported_by?: string;
  total_rows: number;
  successful_rows: number;
  successful_enrolments?: number;
  skipped_rows: number;
  failed_rows: number;
  rejected_rows?: number;
  created_at: string;
  details?: {
    successful: Array<{
      row_index: number;
      registration_number: string;
      student_name?: string;
      course_code: string;
      enrolment_id: string;
    }>;
    skipped: Array<{
      row_index: number;
      registration_number: string;
      course_code: string;
      reason: string;
    }>;
    failed: Array<{
      row_index: number;
      registration_number: string;
      course_code: string;
      reason: string;
    }>;
  };
}

// =============================================================================
// Worksheet 24+: Controller of Examinations (COE) Office (Phase 8)
// =============================================================================
export enum ExamType {
  INTERNAL = 'INTERNAL',
  MIDTERM = 'MIDTERM',
  PRACTICAL = 'PRACTICAL',
  END_SEMESTER = 'END_SEMESTER',
  SUPPLEMENTARY = 'SUPPLEMENTARY',
}

export enum ExamSessionStatus {
  UPCOMING = 'UPCOMING',
  ONGOING = 'ONGOING',
  COMPLETED = 'COMPLETED',
  ARCHIVED = 'ARCHIVED',
}

export enum ExamLifecycleStatus {
  DRAFT = 'DRAFT',
  SCHEDULED = 'SCHEDULED',
  MARKS_ENTRY_OPEN = 'MARKS_ENTRY_OPEN',
  FACULTY_SUBMITTED = 'FACULTY_SUBMITTED',
  UNDER_COE_REVIEW = 'UNDER_COE_REVIEW',
  REJECTED_FOR_CORRECTION = 'REJECTED_FOR_CORRECTION',
  APPROVED = 'APPROVED',
  PUBLISHED = 'PUBLISHED',
  REOPENED = 'REOPENED',
  CANCELLED = 'CANCELLED',
}

export enum ExamAttendanceStatus {
  PRESENT = 'PRESENT',
  ABSENT = 'ABSENT',
  EXEMPTED = 'EXEMPTED',
}

export enum ExamResultStatus {
  PASS = 'PASS',
  FAIL = 'FAIL',
  ABSENT = 'ABSENT',
  EXEMPTED = 'EXEMPTED',
  INCOMPLETE = 'INCOMPLETE',
  WITHHELD = 'WITHHELD',
}

export interface ExamSessionRecord {
  session_id: string; // e.g. "EXS-2026-FALL"
  session_name: string; // e.g. "Fall 2026 End-Semester Examinations"
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8
  start_date: string; // YYYY-MM-DD
  end_date: string; // YYYY-MM-DD
  status: ExamSessionStatus;
  created_at: string;
}

export interface ExamScheduleRecord {
  schedule_id: string; // e.g. "EXSCH-2026-CS201-END"
  session_id: string; // FK -> ExamSessions.session_id
  exam_name: string; // e.g. "Data Structures & Algorithms - End Semester"
  exam_type: ExamType;
  course_code: string; // FK -> Courses.course_code
  course_title: string;
  programme_code: string;
  department: string;
  semester: number;
  section: string; // e.g. "A" or "ALL"
  exam_date: string; // YYYY-MM-DD
  start_time: string; // HH:mm
  end_time: string; // HH:mm
  duration_minutes: number;
  room: string;
  max_marks: number;
  passing_marks: number;
  marks_entry_open: boolean;
  status: ExamLifecycleStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface ExamAttendanceCorrectionEntry {
  previous_status: ExamAttendanceStatus;
  revised_status: ExamAttendanceStatus;
  reason: string;
  actor_id: string;
  timestamp: string;
}

export interface ExamAttendanceEntryRecord {
  attendance_id: string; // e.g. "EXATT-2026-0001"
  schedule_id: string;
  student_id: string;
  student_registration_number: string;
  student_name: string;
  status: ExamAttendanceStatus;
  marked_by: string;
  marked_at: string;
  remarks?: string;
  correction_history?: ExamAttendanceCorrectionEntry[];
}

export interface ExamMarkCorrectionRecord {
  correction_id: string;
  original_internal?: number;
  revised_internal?: number;
  original_external?: number;
  revised_external?: number;
  original_total?: number;
  revised_total?: number;
  original_grade?: string;
  revised_grade?: string;
  reason: string;
  actor_id: string;
  actor_role: string;
  timestamp: string;
}

export interface ExamResultRecord {
  result_id: string; // e.g. "EXRES-2026-0001"
  schedule_id: string;
  session_id: string;
  student_id: string;
  student_registration_number: string;
  student_name: string;
  course_code: string;
  course_title: string;
  programme_code: string;
  semester: number;
  academic_year: string;
  internal_marks: number;
  external_marks: number;
  total_marks: number;
  max_marks: number;
  percentage: number;
  grade: string;
  grade_point: number;
  result_status: ExamResultStatus;
  lifecycle_status: ExamLifecycleStatus;
  submission_notes?: string;
  rejection_reason?: string;
  faculty_submitted_by?: string;
  faculty_submitted_at?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  approved_by?: string;
  approved_at?: string;
  published_at?: string;
  corrections?: ExamMarkCorrectionRecord[];
  created_at: string;
  updated_at: string;
}

export interface StudentEligibilityDetail {
  student_id: string;
  registration_number: string;
  name: string;
  course_code: string;
  section: string;
  is_eligible: boolean;
  ineligibility_reasons: string[];
  attendance_percentage: number;
  fee_clearance: boolean;
  enrolment_status: string;
  is_supplementary_exempted?: boolean;
}

export interface COEDashboardMetrics {
  upcomingExamsCount: number;
  inProgressOrCompletedExamsCount: number;
  awaitingFacultySubmissionCount: number;
  submissionsAwaitingCoeReviewCount: number;
  resultsAwaitingApprovalOrPublicationCount: number;
  publishedResultsCount: number;
  missingMarksCount: number;
  attendanceDiscrepanciesCount: number;
}

export interface StudentTranscriptSummary {
  student: StudentRecord;
  semesterSummaries: {
    semester: number;
    academicYear: string;
    courses: {
      course_code: string;
      course_title: string;
      credits: number;
      grade: string;
      grade_point: number;
      marks: number;
      max_marks: number;
      status: string;
      published_at?: string;
    }[];
    sgpa: number;
    totalCredits: number;
  }[];
  cgpa: number;
  overallCredits: number;
}

// =============================================================================
// Worksheet 18 & 19: Phase 9 Finance Office (Fee Structures, Invoices, Payments, Adjustments)
// =============================================================================

export enum FeeCategory {
  TUITION = 'TUITION',
  EXAMINATION = 'EXAMINATION',
  LABORATORY = 'LABORATORY',
  LIBRARY = 'LIBRARY',
  HOSTEL = 'HOSTEL',
  TRANSPORT = 'TRANSPORT',
  MISCELLANEOUS = 'MISCELLANEOUS',
}

export interface FeeStructureRecord {
  structure_id: string; // e.g. "FST-2026-TUITION-CSE"
  academic_year: string; // e.g. "2026-2027"
  semester: number; // 1-8, or 0 for annual/generic
  programme_code: string; // e.g. "BTECH-CSE", "BTECH-ECE", "ALL"
  fee_category: FeeCategory | string;
  fee_name: string;
  name?: string; // UI alias
  amount: number; // Positive demonstration currency amount
  currency: string; // "USD" (Clearly labelled demonstration currency)
  due_date: string; // ISO Date YYYY-MM-DD
  default_due_date?: string; // UI alias
  applicability: string; // Description or cohort note
  cohort_year?: string; // UI alias
  status: 'ACTIVE' | 'INACTIVE';
  is_active?: boolean; // UI alias
  created_at: string;
  updated_at: string;
}

export enum InvoiceStatus {
  DRAFT = 'DRAFT',
  ISSUED = 'ISSUED',
  PARTIALLY_PAID = 'PARTIALLY_PAID',
  PAID = 'PAID',
  OVERDUE = 'OVERDUE',
  CANCELLED = 'CANCELLED',
  DISPUTED = 'DISPUTED',
}

export interface InvoiceLineItem {
  line_id: string;
  fee_structure_id?: string;
  category: FeeCategory | string;
  description: string;
  amount: number;
}

export interface FeeInvoiceRecord {
  invoice_id: string; // e.g. "INV-2026-0001"
  invoice_number: string; // e.g. "EIT-INV-2026-0001"
  student_id: string;
  registration_number: string;
  student_registration_number?: string;
  student_name: string;
  programme_code?: string;
  academic_year: string;
  semester: number;
  fee_category: string; // Primary category or summary
  issue_date: string;
  due_date: string;
  line_items: InvoiceLineItem[];
  subtotal: number;
  adjustments_total: number; // Discounts, scholarships applied
  total_amount: number; // subtotal - adjustments_total
  amount_due: number; // Alias for total_amount (compatibility with FinanceRecord)
  amount_paid: number;
  outstanding_balance: number; // total_amount - amount_paid
  currency: string;
  status: InvoiceStatus;
  payment_status: PaymentStatus; // Compatibility with FinanceRecord
  hostel_charge_id?: string; // Stable reference to hostel charge request
  transaction_reference?: string; // Last payment reference
  payment_method?: string;
  payment_date?: string;
  notes?: string;
  cancellation_reason?: string;
  cancelled_by?: string;
  cancelled_at?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export enum PaymentMethod {
  CASH = 'CASH',
  BANK_TRANSFER = 'BANK_TRANSFER',
  CARD = 'CARD',
  OTHER = 'OTHER',
  ONLINE_GATEWAY = 'ONLINE_GATEWAY',
}

export enum PaymentLedgerStatus {
  RECORDED = 'RECORDED',
  VERIFIED = 'VERIFIED',
  REVERSED = 'REVERSED',
  REFUNDED = 'REFUNDED',
}

export interface PaymentRecord {
  payment_id: string; // e.g. "PAY-2026-0001"
  receipt_number: string; // e.g. "REC-2026-0001"
  invoice_id: string;
  student_id: string;
  registration_number: string;
  student_registration_number?: string;
  student_name: string;
  amount: number;
  currency: string;
  payment_date: string;
  payment_method: PaymentMethod;
  transaction_reference: string; // UK: Unique transaction reference
  receiving_officer_id: string; // Actor who recorded
  received_by?: string; // UI alias
  status: PaymentLedgerStatus;
  notes?: string;
  reversal_reason?: string;
  reversed_by?: string;
  reversed_at?: string;
  refund_amount?: number;
  refund_reason?: string;
  refunded_by?: string;
  refunded_at?: string;
  created_at: string;
}

export enum AdjustmentType {
  SCHOLARSHIP = 'SCHOLARSHIP',
  MERIT_DISCOUNT = 'MERIT_DISCOUNT',
  FEE_WAIVER = 'FEE_WAIVER',
  WAIVER = 'FEE_WAIVER',
  FINANCIAL_AID = 'FINANCIAL_AID',
  CONCESSION = 'CONCESSION',
  CORRECTION = 'CORRECTION',
}

export enum AdjustmentStatus {
  PENDING_APPROVAL = 'PENDING_APPROVAL',
  REQUESTED = 'PENDING_APPROVAL',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
}

export interface FeeAdjustmentRecord {
  adjustment_id: string; // e.g. "ADJ-2026-0001"
  invoice_id: string;
  student_id: string;
  registration_number: string;
  student_registration_number?: string;
  adjustment_type: AdjustmentType;
  amount: number;
  reason: string;
  requested_by: string;
  requested_at: string;
  approved_by?: string;
  approved_at?: string;
  rejected_by?: string;
  rejected_at?: string;
  rejection_reason?: string;
  status: AdjustmentStatus;
  created_at: string;
}

export interface FinanceDashboardMetrics {
  totalInvoiced: number;
  totalCollected: number;
  totalOutstanding: number;
  overdueInvoicesCount: number;
  paidInvoicesCount: number;
  partialInvoicesCount: number;
  draftOrIssuedInvoicesCount: number;
  recentPaymentsCount: number;
  totalDiscountsApproved: number;
}

export interface StudentFeeStatement {
  student: StudentRecord;
  invoices: FeeInvoiceRecord[];
  payments: PaymentRecord[];
  adjustments: FeeAdjustmentRecord[];
  totalInvoiced: number;
  totalPaid: number;
  totalAdjustments: number;
  totalOutstanding: number;
}

// =============================================================================
// Worksheet 20 & 21: Phase 9 Hostel Office (Blocks, Rooms, Beds, Allocations, Charges)
// =============================================================================

export enum HostelGenderType {
  BOYS = 'BOYS',
  GIRLS = 'GIRLS',
  CO_ED = 'CO_ED',
}

export enum RoomType {
  SINGLE = 'SINGLE',
  DOUBLE = 'DOUBLE',
  TRIPLE = 'TRIPLE',
  DORMITORY = 'DORMITORY',
}

export enum RoomOperationalStatus {
  ACTIVE = 'ACTIVE',
  UNDER_MAINTENANCE = 'UNDER_MAINTENANCE',
  INACTIVE = 'INACTIVE',
}

export enum BedOccupancyStatus {
  AVAILABLE = 'AVAILABLE',
  OCCUPIED = 'OCCUPIED',
  RESERVED = 'RESERVED',
  MAINTENANCE = 'MAINTENANCE',
}

export interface HostelBedRecord {
  bed_id: string; // e.g. "BED-A-101-A"
  room_id: string; // FK -> HostelRooms.room_id
  bed_identifier: string; // "A", "B", "1", "2"
  status: BedOccupancyStatus;
  current_allocation_id?: string;
}

export interface HostelRoomRecord {
  room_id: string; // e.g. "HST-RM-A-101"
  block_id: string; // FK -> HostelBlocks.block_id
  block_name: string;
  room_number: string; // "101"
  floor: number;
  room_type: RoomType;
  capacity: number;
  amenities: string[];
  status: RoomOperationalStatus;
  beds: HostelBedRecord[];
  created_at: string;
  updated_at: string;
}

export interface HostelBlockRecord {
  block_id: string; // e.g. "HST-BLK-A"
  block_name: string; // "Block A - Aryabhata Hall"
  gender_type: HostelGenderType;
  total_floors: number;
  status: 'ACTIVE' | 'MAINTENANCE' | 'INACTIVE';
  warden_name?: string;
  contact_phone?: string;
  created_at: string;
}

export enum HostelAllocationLifecycleStatus {
  RESERVED = 'RESERVED',
  ALLOCATED = 'ALLOCATED',
  CHECKED_IN = 'CHECKED_IN',
  CHECKED_OUT = 'CHECKED_OUT',
  CANCELLED = 'CANCELLED',
  TRANSFERRED = 'TRANSFERRED',
}

export interface AllocationMovementRecord {
  movement_id: string;
  previous_room_id: string;
  previous_room_number: string;
  previous_bed_identifier: string;
  new_room_id: string;
  new_room_number: string;
  new_bed_identifier: string;
  reason: string;
  effective_date: string;
  transferred_by: string;
  timestamp: string;
}

export interface HostelAllocationRecord {
  allocation_id: string; // e.g. "HST-2026-0001"
  student_id: string;
  registration_number: string;
  student_registration_number?: string;
  student_name: string;
  block_id: string;
  block_name: string;
  hostel_block_name?: string;
  room_id: string;
  room_number: string;
  bed_id: string;
  bed_identifier: string;
  academic_year: string;
  semester?: number;
  start_date: string; // ISO Date YYYY-MM-DD
  end_date?: string; // ISO Date YYYY-MM-DD
  status: HostelAllocationLifecycleStatus;
  allocated_by: string;
  allocated_at: string;
  allocated_by_employee_id?: string;
  approved_by_office_id?: string;
  check_in_date?: string;
  checked_in_at?: string;
  checked_out_at?: string;
  cancellation_reason?: string;
  cancelled_by?: string;
  cancelled_at?: string;
  transfer_history?: AllocationMovementRecord[];
  emergency_contact_phone: string;
  created_at: string;
  updated_at: string;
}

export enum HostelChargeStatus {
  REQUESTED = 'REQUESTED',
  INVOICED = 'INVOICED',
  REJECTED = 'REJECTED',
}

export interface HostelChargeRequestRecord {
  charge_request_id: string; // e.g. "HCR-2026-0001"
  allocation_id: string;
  student_id: string;
  registration_number: string;
  student_registration_number?: string;
  student_name: string;
  billing_period: string; // e.g. "FALL_2026", "2026-2027-SEM3"
  fee_category: 'HOSTEL';
  amount: number;
  description: string;
  requested_by: string;
  requested_at: string;
  status: HostelChargeStatus;
  invoice_id?: string; // Stable reference to Finance invoice once generated
  invoiced_by?: string;
  invoiced_at?: string;
  rejection_reason?: string;
  created_at: string;
}

export interface HostelDashboardMetrics {
  totalRoomsCount: number;
  totalBedsCount: number;
  availableBedsCount: number;
  occupiedBedsCount: number;
  occupancyRate: number; // e.g. 75.5 (%)
  currentActiveAllocationsCount: number;
  pendingCheckInsCount: number;
  checkedInCount: number;
  roomsUnderMaintenanceCount: number;
  unbilledChargesCount: number;
  totalBedCapacity?: number;
  occupiedBeds?: number;
  vacantBeds?: number;
  pendingCheckIns?: number;
}

export interface StudentHostelDetails {
  student: StudentRecord;
  currentAllocation: HostelAllocationRecord | null;
  historicalAllocations: HostelAllocationRecord[];
  chargeRequests: HostelChargeRequestRecord[];
  room?: HostelRoomRecord | null;
  roommates?: HostelAllocationRecord[];
  movementHistory?: AllocationMovementRecord[];
}



