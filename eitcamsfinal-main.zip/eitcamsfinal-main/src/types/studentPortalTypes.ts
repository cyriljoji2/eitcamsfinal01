/**
 * Student Portal Compatibility & Integration Types
 * Bridges EIT CAMS University ERP models with the Student Portal reference components.
 */

import {
  StudentRecord,
  AcademicRecord,
  AttendanceRecord,
  ExamResultRecord,
  ExamScheduleRecord,
  FeeInvoiceRecord,
  PaymentRecord,
  StudentFeeStatement,
  StudentHostelDetails,
  TimetableSlotRecord,
  EmployeeRecord,
  ParentRecord,
} from './database';

export interface Student {
  id: string;
  fullName: string;
  registrationNumber: string;
  admissionClass: string;
  section: string;
  admissionDate: string;
  admissionType: string;
  admissionStatus?: string;
  academicSession?: string;
  accountStatus: 'active' | 'inactive';
  status?: string;
  email: string;
  mobile: string;
  emergencyContact: string;
  dateOfBirth: string;
  gender: string;
  bloodGroup: string;
  category: string;
  nationality: string;
  religion?: string;
  presentAddress: string;
  permanentAddress: string;
  fatherName: string;
  fatherPhone: string;
  fatherOccupation?: string;
  motherName: string;
  motherPhone?: string;
  guardianName: string;
  currentSemester: string;
  program: string;
  batch: string;
  rollNumber: string;
  username?: string;
  temporaryPassword?: string;
  isTemporaryPassword?: boolean;
  passwordChangedAt?: string;
  documents?: any[];
  previousSchool?: string;
  previousClass?: string;
  address?: string;
  // Aliases for cross-subsystem compatibility
  student_id?: string;
  first_name?: string;
  last_name?: string;
  institutional_email?: string;
  registration_number?: string;
  phone?: string;
  photo_url?: string;
  photoUrl?: string;
  course_code?: string;
  admission_batch?: string;
  department?: string;
}

export interface AcademicClass {
  id: string;
  name: string;
  code?: string;
  department?: string;
  departmentId?: string;
  programType?: string;
  durationYears?: number;
  totalSemesters?: number;
  currentNumericClass?: number;
  numericLevel?: number;
  stream?: string;
  description?: string;
  status?: 'active' | 'inactive';
  createdAt?: string;
}

export interface AcademicSection {
  id: string;
  name: string;
  classId?: string;
  className?: string;
  classTeacherId?: string;
  classTeacherName?: string;
  batchYear?: string;
  currentSemester?: string;
  academicSession?: string;
  room?: string;
  roomNumber?: string;
  capacity?: number;
  status?: 'active' | 'inactive';
  createdAt?: string;
}

export interface AcademicSession {
  id: string;
  name: string;
  isCurrent: boolean;
  startDate?: string;
  endDate?: string;
  status?: 'active' | 'archived' | 'upcoming';
}

export interface AcademicSubject {
  id: string;
  code: string;
  name: string;
  credits: number;
  type?: string;
  category?: string;
  department?: string;
  semester?: number | string;
  description?: string;
  className?: string;
  classId?: string;
  creditsOrPeriodsPerWeek?: number;
  periodsPerWeek?: number;
  electiveGroup?: string;
  prerequisites?: string[];
  status?: 'active' | 'inactive';
  createdAt?: string;
}

export interface FacultyAssignment {
  id: string;
  facultyId?: string;
  facultyName: string;
  facultyEmail?: string;
  subjectCode: string;
  subjectName: string;
  section: string;
  sectionName?: string;
  sectionId?: string;
  semester?: number;
  academicYear?: string;
  academicSession?: string;
  className?: string;
  classId?: string;
  employeeId?: string;
  department?: string;
  subjectId?: string;
  status?: 'active' | 'completed';
  roleInCourse?: string;
  assignedAt?: string;
}

export interface Employee {
  id: string;
  employeeId: string;
  fullName: string;
  email: string;
  mobile: string;
  department: string;
  designation: string;
  roles?: string[];
  status: string;
  isTeachingStaff: boolean;
  role?: string;
}

export interface ProctorAssignment {
  id: string;
  studentId: string;
  facultyId: string;
  facultyName: string;
  facultyEmail: string;
  facultyPhone: string;
  facultyDepartment: string;
  academicYear: string;
  academicSession?: string;
  status?: 'active' | 'deactivated' | 'completed' | string;
  studentRegistrationNumber?: string;
  studentName?: string;
  studentClass?: string;
  studentSection?: string;
  assignedDate?: string;
  assignedBy?: string;
  updatedAt?: string;
  notes?: string;
  deactivatedDate?: string;
  deactivatedBy?: string;
  deactivationReason?: string;
}

export interface ProctorMessage {
  id: string;
  proctorId: string;
  studentId: string;
  facultyName: string;
  proctorName?: string;
  title: string;
  message: string;
  date: string;
  createdAt?: string;
  priority?: 'normal' | 'important' | 'urgent';
  category?: string;
}

export interface Examination {
  id: string;
  name: string;
  session: string;
  academicSession?: string;
  status: 'Active' | 'Mark Entry Open' | 'Draft' | 'Published' | 'Archived';
  startDate?: string;
  endDate?: string;
  termType?: string;
  instructions?: string[];
}

export interface ExamSubjectSchedule {
  id: string;
  examinationId: string;
  courseCode: string;
  courseName: string;
  examDate: string;
  startTime: string;
  endTime: string;
  room: string;
  examType: string;
  maxMarks?: number;
  className?: string;
  section?: string;
  roomVenue?: string;
  subjectName?: string;
  subjectCode?: string;
  passMarks?: number;
}

export interface HallTicketSchedule {
  courseCode: string;
  courseName: string;
  subjectName?: string;
  examDate: string;
  timeSlot: string;
  room: string;
}

export interface HallTicket {
  id: string;
  hallTicketNumber: string;
  examinationId: string;
  examinationName: string;
  academicSession: string;
  studentRegistrationNumber: string;
  studentName: string;
  className: string;
  section: string;
  dateOfBirth?: string;
  fatherName?: string;
  motherName?: string;
  schoolName: string;
  schoolAddress: string;
  schedules: HallTicketSchedule[];
  status?: string;
  generatedAt?: string;
}

export interface StudentExamResult {
  id: string;
  examinationId: string;
  examinationName?: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName: string;
  subjectCode: string;
  subjectName: string;
  marksObtained: number;
  maxMarks: number;
  percentage: number;
  grade: string;
  gradePoint: number;
  status: 'Passed' | 'Failed' | 'Absent';
  isPublished: boolean;
  publishedAt?: string;
  internalMarks?: number;
  externalMarks?: number;
  credits?: number;
  semester?: string;
  academicSession?: string;
  className?: string;
  section?: string;
  verificationStatus?: string;
  resultStatus?: string;
  overallGrade?: string;
  calculatedAt?: string;
  totalMarksObtained?: number;
  totalMaxMarks?: number;
  classRank?: number | string;
  subjectMarks?: any[];
}

export interface StudentSubjectMark {
  id: string;
  examinationId: string;
  subjectCode: string;
  subjectName: string;
  studentRegistrationNumber: string;
  component: string;
  marksObtained: number;
  maxMarks: number;
  grade?: string;
  semester?: string;
  passMarks?: number;
  attendanceStatus?: string;
  isPassed?: boolean;
  updatedAt?: string;
  enteredAt?: string;
}

export interface FeeAssignment {
  id: string;
  studentRegistrationNumber: string;
  feeTypeName: string;
  amountDue: number;
  amountPaid: number;
  discountOrWaiver: number;
  balanceDue: number;
  balance?: number;
  dueDate: string;
  status: 'Paid' | 'Partial' | 'Partially Paid' | 'Unpaid' | 'Overdue' | 'Waived' | string;
  category?: string;
  academicSession?: string;
  remarks?: string;
}

export interface PaymentRecordItem {
  id: string;
  studentRegistrationNumber: string;
  studentName?: string;
  receiptNumber: string;
  feeTypeName: string;
  academicSession?: string;
  amountPaid: number;
  paymentMode: string;
  paymentDate: string;
  transactionReference?: string;
  receivedBy?: string;
  isVoided: boolean;
  voidReason?: string;
  notes?: string;
}

export interface FeeReceipt {
  receiptNumber: string;
  paymentId: string;
  receiptDate: string;
  studentRegistrationNumber: string;
  studentName: string;
  className: string;
  section: string;
  academicSession: string;
  feeTypeName: string;
  amountPaid: number;
  amountInWords: string;
  paymentMode: string;
  transactionReference?: string;
  outstandingBalanceAfterPayment: number;
  receivedBy: string;
  isVoided: boolean;
  voidReason?: string;
  schoolDetails: {
    name: string;
    address: string;
    phone?: string;
    email?: string;
    affiliation?: string;
  };
}

export interface Hostel {
  id: string;
  name: string;
  blockName: string;
  type: string;
  wardenName: string;
  wardenPhone: string;
  wardenContact?: string;
  category?: string;
  address?: string;
}

export interface HostelAllotment {
  id: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName?: string;
  hostelId: string;
  hostelName?: string;
  blockId?: string;
  blockName: string;
  floorName?: string;
  roomNumber: string;
  roomId?: string;
  bedNumber: string;
  bedId?: string;
  allotmentDate: string;
  status: 'Active' | 'Vacated' | 'Pending';
  monthlyRent: number;
  academicSession?: string;
  allottedBy?: string;
}

export type LeaveOutingRequestType = 'leave' | 'outing';
export type LeaveReasonCategory = 'medical' | 'family' | 'academic' | 'emergency' | 'vacation' | 'other';
export type LeaveApprovalStatus =
  | 'PENDING'
  | 'PENDING_PROCTOR'
  | 'APPROVED_BY_PROCTOR'
  | 'REJECTED_BY_PROCTOR'
  | 'PENDING_HOSTEL'
  | 'APPROVED'
  | 'REJECTED_BY_HOSTEL'
  | 'REJECTED'
  | 'CANCELLED'
  | string;

export interface LeaveOutingRequest {
  id: string;
  studentId: string;
  studentRegistrationNumber: string;
  studentName: string;
  studentClass?: string;
  studentSection?: string;
  program?: string;
  batch?: string;
  roomNumber: string;
  blockName: string;
  hostelName?: string;
  hostelBlock?: string;
  hostelAllotmentId?: string;
  hostelId?: string;
  blockId?: string;
  floorName?: string;
  roomId?: string;
  bedId?: string;
  bedNumber?: string;
  requestType: LeaveOutingRequestType;
  requestNumber?: string;
  fromDate: string;
  fromTime: string;
  toDate: string;
  toTime: string;
  reasonCategory: LeaveReasonCategory;
  reason: string;
  purpose?: string;
  destination: string;
  destinationAddress?: string;
  contactNumber: string;
  emergencyContact: string;
  parentContactNumber?: string;
  remarks?: string;
  approvalStatus: LeaveApprovalStatus;
  status?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectionReason?: string;
  proctorId?: string;
  proctorName?: string;
  proctorDepartment?: string;
  proctorRemarks?: string;
  proctorActionDate?: string;
  hostelRemarks?: string;
  hostelActionBy?: string;
  hostelActionDate?: string;
  gateOutTime?: string;
  gateInTime?: string;
  securityGuardName?: string;
  slipNumber?: string;
  auditTrail?: any[];
  createdAt: string;
}

// Number to Words Converter for Indian/International Institutional Receipts
export function convertNumberToWords(amount: number): string {
  const ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  const num = Math.floor(amount);
  if (num === 0) return 'Zero Dollars Only';

  function convertChunk(n: number): string {
    let str = '';
    if (n >= 100) {
      str += ones[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    if (n >= 20) {
      str += tens[Math.floor(n / 10)] + ' ';
      n %= 10;
    }
    if (n > 0) {
      str += ones[n] + ' ';
    }
    return str.trim();
  }

  let words = '';
  if (num >= 1000000) {
    words += convertChunk(Math.floor(num / 1000000)) + ' Million ';
  }
  const thousands = Math.floor((num % 1000000) / 1000);
  if (thousands > 0) {
    words += convertChunk(thousands) + ' Thousand ';
  }
  const remainder = num % 1000;
  if (remainder > 0) {
    words += convertChunk(remainder);
  }

  return `${words.trim()} Dollars Only`;
}
