/**
 * IT Department Type Definitions for Electrix Institute of Technology (EIT) CAMS
 * Office: PO-007 (IT Department)
 */

export enum ItPermission {
  IT_DASHBOARD_VIEW = 'IT_DASHBOARD_VIEW',
  IT_SYSTEM_MONITOR_VIEW = 'IT_SYSTEM_MONITOR_VIEW',
  IT_USER_ACCESS_VIEW = 'IT_USER_ACCESS_VIEW',
  IT_PERMISSION_MANAGE = 'IT_PERMISSION_MANAGE',
  IT_PASSWORD_RESET = 'IT_PASSWORD_RESET',
  IT_ID_CARD_MANAGE = 'IT_ID_CARD_MANAGE',
  IT_TEST_ACCOUNT_MANAGE = 'IT_TEST_ACCOUNT_MANAGE',
  IT_SECURITY_AUDIT_VIEW = 'IT_SECURITY_AUDIT_VIEW',
  IT_DATABASE_MONITOR = 'IT_DATABASE_MONITOR',
  IT_INFRASTRUCTURE_MANAGE = 'IT_INFRASTRUCTURE_MANAGE',
  IT_CONFIGURATION_MANAGE = 'IT_CONFIGURATION_MANAGE',
  IT_INTEGRATION_MANAGE = 'IT_INTEGRATION_MANAGE',
  IT_SUPPORT_MANAGE = 'IT_SUPPORT_MANAGE',
  IT_SLA_MANAGE = 'IT_SLA_MANAGE',
  IT_CONTACT_SETTINGS_MANAGE = 'IT_CONTACT_SETTINGS_MANAGE',
  IT_BACKUP_MANAGE = 'IT_BACKUP_MANAGE',
  IT_REPORTS_VIEW = 'IT_REPORTS_VIEW',
}

export type ItTab =
  | 'overview'
  | 'system_health'
  | 'user_access'
  | 'password_reset'
  | 'id_cards'
  | 'test_accounts'
  | 'security_audit'
  | 'database'
  | 'infrastructure'
  | 'configuration'
  | 'integrations'
  | 'app_monitoring'
  | 'tickets'
  | 'backup'
  | 'contact_settings'
  | 'sla_policies'
  | 'reports';

// -----------------------------------------------------------------------------
// ID Card Management
// -----------------------------------------------------------------------------

export type IdCardType = 'STUDENT' | 'EMPLOYEE';

export type IdCardStatus =
  | 'ACTIVE'
  | 'SUSPENDED'
  | 'EXPIRED'
  | 'LOST'
  | 'DAMAGED'
  | 'REPLACED';

export interface IdCardRecord {
  card_id: string; // e.g. "IDC-STU-2026-0001" or "IDC-EMP-2026-0001"
  card_type: IdCardType;
  owner_id: string; // student_id or employee_id
  registration_number: string;
  full_name: string;
  photo_url?: string;
  department: string;
  designation_or_program: string; // Program for student, Designation for employee
  office_or_year: string; // Academic Year for student, Primary Office / Dept for employee
  blood_group?: string;
  emergency_contact?: string;
  issue_date: string; // YYYY-MM-DD
  expiry_date: string; // YYYY-MM-DD
  status: IdCardStatus;
  qr_code_payload: string; // Cryptographic verification URL / token
  reissue_count: number;
  last_reissued_at?: string;
  reissue_reason?: string;
  created_at: string;
  updated_at: string;
  batch_year?: string;
  course_name?: string;
  valid_until?: string;
}

// -----------------------------------------------------------------------------
// Test Account Management
// -----------------------------------------------------------------------------

export interface TestAccountConfig {
  account_id: string;
  username: string;
  display_name: string;
  is_enabled: boolean;
  permitted_test_roles: string[];
  last_enabled_at?: string;
  last_disabled_at?: string;
  last_operator_id?: string;
  last_operator_name?: string;
  last_reason?: string;
  active_sessions_count: number;
  history: TestAccountAuditEntry[];
}

export interface TestAccountAuditEntry {
  entry_id: string;
  action: 'ENABLED' | 'DISABLED' | 'SESSIONS_REVOKED';
  operator_id: string;
  operator_name: string;
  timestamp: string;
  reason: string;
}

// -----------------------------------------------------------------------------
// IT Support & Ticket Management
// -----------------------------------------------------------------------------

export type TicketCategory =
  | 'LOGIN_ACCESS'
  | 'PASSWORD_RESET'
  | 'ID_CARD'
  | 'PORTAL_MALFUNCTION'
  | 'NETWORK'
  | 'HARDWARE'
  | 'SOFTWARE'
  | 'EMAIL'
  | 'PERMISSION_ACCESS'
  | 'SECURITY_INCIDENT'
  | 'OTHER';

export type TicketPriority = 'CRITICAL' | 'HIGH' | 'NORMAL' | 'LOW';

export type TicketStatus =
  | 'OPEN'
  | 'ASSIGNED'
  | 'IN_PROGRESS'
  | 'AWAITING_REQUESTER'
  | 'AWAITING_THIRD_PARTY'
  | 'ESCALATED'
  | 'RESOLVED'
  | 'CLOSED'
  | 'REOPENED';

export interface TicketResponse {
  response_id: string;
  ticket_id: string;
  author_id: string;
  author_name: string;
  author_role: string;
  is_internal_note: boolean;
  message: string;
  timestamp: string;
  attachments?: string[];
}

export interface TicketActivityEntry {
  activity_id: string;
  ticket_id: string;
  actor_id: string;
  actor_name: string;
  actor_role: string;
  action_type:
    | 'CREATED'
    | 'STATUS_CHANGE'
    | 'ASSIGNED'
    | 'REASSIGNED'
    | 'NOTE_ADDED'
    | 'REPLY_ADDED'
    | 'RESOLVED'
    | 'CLOSED'
    | 'REOPENED'
    | 'ESCALATED'
    | 'SLA_PAUSED'
    | 'SLA_RESUMED';
  details: string;
  previous_status?: TicketStatus;
  new_status?: TicketStatus;
  previous_assignee?: string;
  new_assignee?: string;
  timestamp: string;
}

export const ALLOWED_STATUS_TRANSITIONS: Record<TicketStatus, readonly TicketStatus[]> = {
  OPEN: ['ASSIGNED', 'IN_PROGRESS', 'AWAITING_REQUESTER', 'AWAITING_THIRD_PARTY', 'ESCALATED', 'RESOLVED', 'CLOSED'],
  ASSIGNED: ['OPEN', 'IN_PROGRESS', 'AWAITING_REQUESTER', 'AWAITING_THIRD_PARTY', 'ESCALATED', 'RESOLVED', 'CLOSED'],
  IN_PROGRESS: ['ASSIGNED', 'AWAITING_REQUESTER', 'AWAITING_THIRD_PARTY', 'ESCALATED', 'RESOLVED', 'CLOSED'],
  AWAITING_REQUESTER: ['IN_PROGRESS', 'ASSIGNED', 'AWAITING_THIRD_PARTY', 'ESCALATED', 'RESOLVED', 'CLOSED'],
  AWAITING_THIRD_PARTY: ['IN_PROGRESS', 'ASSIGNED', 'AWAITING_REQUESTER', 'ESCALATED', 'RESOLVED', 'CLOSED'],
  ESCALATED: ['IN_PROGRESS', 'ASSIGNED', 'AWAITING_REQUESTER', 'AWAITING_THIRD_PARTY', 'RESOLVED', 'CLOSED'],
  RESOLVED: ['CLOSED', 'REOPENED'],
  CLOSED: ['REOPENED'],
  REOPENED: ['ASSIGNED', 'IN_PROGRESS', 'AWAITING_REQUESTER', 'AWAITING_THIRD_PARTY', 'ESCALATED', 'RESOLVED', 'CLOSED'],
};

export interface TicketRecord {
  ticket_id: string; // e.g. "TKT-2026-0001"
  ticket_number: string; // UK: e.g. "EIT-IT-2026-0001"
  requester_id: string; // User ID / Student ID / Employee ID
  requester_name: string;
  requester_account_type: 'STUDENT' | 'EMPLOYEE' | 'PARENT' | 'OFFICE';
  requester_email: string;
  requester_phone?: string;
  category: TicketCategory;
  subject: string;
  description: string;
  priority: TicketPriority;
  status: TicketStatus;
  assigned_to_employee_id?: string;
  assigned_to_name?: string;
  created_at: string;
  updated_at: string;
  resolved_at?: string;
  closed_at?: string;
  resolution_notes?: string;
  escalation_reason?: string;
  reopen_reason?: string;
  close_notes?: string;
  requester_rating?: number; // 1-5
  requester_feedback?: string;
  attachments?: string[];
  activity_history?: TicketActivityEntry[];
  // SLA Engine linkage
  sla_policy_id: string;
  sla_policy_version: number;
  sla_response_deadline: string; // ISO 8601
  sla_resolution_deadline: string; // ISO 8601
  sla_response_breached: boolean;
  sla_resolution_breached: boolean;
  sla_first_responded_at?: string;
  sla_paused: boolean;
  sla_pause_reason?: string;
  sla_paused_at?: string;
  sla_breach_history?: {
    type: 'RESPONSE' | 'RESOLUTION';
    breached_at: string;
    target_deadline: string;
  }[];
  responses: TicketResponse[];
}

// -----------------------------------------------------------------------------
// SLA Policies & Configuration
// -----------------------------------------------------------------------------

export interface SlaTarget {
  response_time_minutes: number;
  resolution_time_minutes: number;
}

export interface SlaPolicyRecord {
  policy_id: string; // e.g. "SLA-POLICY-DEFAULT"
  policy_name: string;
  version: number;
  is_active: boolean;
  applicable_category?: TicketCategory | 'ALL';
  targets: {
    CRITICAL: SlaTarget;
    HIGH: SlaTarget;
    NORMAL: SlaTarget;
    LOW: SlaTarget;
  };
  business_hours: {
    start: string; // "08:00"
    end: string; // "17:00"
  };
  working_days: number[]; // 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri
  holidays: string[]; // ['2026-11-26', '2026-12-25', ...]
  timezone: string; // "America/New_York" or "UTC"
  warning_threshold_percent: number; // e.g. 75 (%)
  escalation_rules: {
    priority: TicketPriority;
    after_minutes: number;
    escalate_to_role: string;
  }[];
  created_at: string;
  updated_at: string;
  updated_by: string;
}

// -----------------------------------------------------------------------------
// Institutional IT Contact & Support Settings
// -----------------------------------------------------------------------------

export interface ItContactSettings {
  support_email: string;
  support_phone: string;
  support_hours: string;
  emergency_phone: string;
  working_days_text: string;
  institutional_timezone: string;
  after_hours_info: string;
  public_support_instructions: string;
  updated_at: string;
  updated_by: string;
  history: ContactSettingHistoryEntry[];
  broadcast_banner_enabled?: boolean;
  broadcast_message?: string;
  primary_support_email?: string;
  primary_phone?: string;
  footer_support_text?: string;
  helpdesk_hours?: string;
}

export interface ContactSettingHistoryEntry {
  entry_id: string;
  updated_at: string;
  updated_by: string;
  reason: string;
  field_name: string;
  previous_value: string;
  new_value: string;
}

// -----------------------------------------------------------------------------
// System Health & Monitoring
// -----------------------------------------------------------------------------

export type ServiceHealthStatus = 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE' | 'NOT_CONFIGURED';

export interface SystemHealthMetric {
  service_key: string;
  service_name: string;
  category: 'APPLICATION' | 'DATABASE' | 'SECURITY' | 'API' | 'NETWORK';
  status: ServiceHealthStatus;
  latency_ms: number;
  uptime_percentage: number;
  last_checked: string;
  details: string;
  is_simulated: boolean;
}

// -----------------------------------------------------------------------------
// Database Management & Google Sheets Readiness
// -----------------------------------------------------------------------------

export interface DatabaseManagementReport {
  current_adapter: 'DevDataAdapter' | 'GoogleSheetsAdapter';
  google_sheets_connected: boolean; // Must be false for Phase 10, planned for Phase 11
  status: ServiceHealthStatus;
  tables_count: number;
  table_statistics: {
    table_name: string;
    record_count: number;
    last_modified: string;
    status: 'OPTIMAL' | 'DEGRADED' | 'EMPTY';
  }[];
  integrity_checks_passed: boolean;
  integrity_issues: string[];
  migration_readiness_score: number; // 0-100
  phase_11_prerequisites_met: boolean;
  notes: string;
}

// -----------------------------------------------------------------------------
// Infrastructure & Deployment
// -----------------------------------------------------------------------------

export interface InfrastructureInfo {
  environment: 'development' | 'staging' | 'production';
  app_name: string;
  app_version: string;
  node_version: string;
  platform_os: string;
  deployment_provider: 'Local/DevContainer' | 'Vercel (Planned Phase 12)';
  vercel_deployed: boolean; // Must be false for Phase 10, planned for Phase 12
  build_status: 'SUCCESS' | 'FAILED' | 'PENDING';
  maintenance_mode: boolean;
  maintenance_message?: string;
  feature_flags: Record<string, boolean>;
  last_deployment_date: string;
}

// -----------------------------------------------------------------------------
// API & Integration Registry
// -----------------------------------------------------------------------------

export interface IntegrationRegistryItem {
  integration_id: string;
  name: string;
  category: 'DATABASE' | 'DEPLOYMENT' | 'AI' | 'COMMUNICATION' | 'BIOMETRICS';
  purpose: string;
  target_phase: string;
  status: ServiceHealthStatus;
  is_active: boolean;
  last_successful_check?: string;
  last_error?: string;
  responsible_service: string;
  api_endpoint?: string;
}

// -----------------------------------------------------------------------------
// Backup & Recovery
// -----------------------------------------------------------------------------

export interface BackupRecord {
  backup_id: string; // e.g. "BKP-2026-0001"
  backup_type: 'STATE_SNAPSHOT' | 'JSON_EXPORT' | 'CONFIG_ONLY';
  size_kb: number;
  status: 'SUCCESS' | 'FAILED' | 'IN_PROGRESS';
  retention_days: number;
  created_at: string;
  created_by: string;
  notes?: string;
  is_simulated: boolean;
}

// -----------------------------------------------------------------------------
// Password Reset Audit & Request
// -----------------------------------------------------------------------------

export interface PasswordResetAuditRecord {
  reset_id: string;
  target_user_id: string;
  target_username: string;
  target_account_type: 'STUDENT' | 'EMPLOYEE' | 'PARENT' | 'OFFICE';
  target_full_name: string;
  reset_by_operator_id: string;
  reset_by_operator_name: string;
  reason: string;
  temp_credential_issued: boolean;
  force_password_change_on_login: boolean;
  sessions_revoked: boolean;
  timestamp: string;
  outcome: 'SUCCESS' | 'REJECTED';
}

// -----------------------------------------------------------------------------
// IT Overview Dashboard Metrics
// -----------------------------------------------------------------------------

export interface ItDashboardMetrics {
  totalItEmployees: number;
  activeItEmployees: number;
  openTickets: number;
  criticalTickets: number;
  approachingSlaTickets: number;
  slaBreaches: number;
  passwordResetsCount: number;
  idCardsGenerated: number;
  pendingIdReissues: number;
  testAccountEnabled: boolean;
  overallSystemHealth: ServiceHealthStatus;
  applicationAvailability: number; // e.g. 99.9 (%)
  latestAlertsCount: number;
  recentActivityCount: number;
  backupStatus: 'UP_TO_DATE' | 'PENDING' | 'FAILED';
  integrationStatus: 'OPERATIONAL' | 'DEGRADED';
}
