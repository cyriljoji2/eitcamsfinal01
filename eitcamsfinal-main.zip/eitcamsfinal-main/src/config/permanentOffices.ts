import { PermanentOfficeKey, PermanentOfficeRecord } from '../types/database';

/**
 * The Exact Six Permanent Institutional Office Accounts for Electrix Institute of Technology (EIT).
 *
 * SPECIFICATION & RESTRICTIONS:
 * 1. Administration Office — username: admin — Super Admin
 * 2. Admissions Office — username: admissionsoffice
 * 3. Academic Office — username: academicoffice
 * 4. COE Office — username: coeoffice
 * 5. Finance Office — username: finance
 * 6. Hostel Office — username: hosteloffice
 *
 * CRITICAL IMMUTABILITY RULES:
 * - These 6 accounts are permanent system fixtures; they cannot be deleted, renamed, or re-registered.
 * - Self-registration is strictly blocked (`allow_self_registration: false`).
 * - Any user registration or account creation attempt matching these canonical usernames or office codes is rejected.
 * - Teaching faculty assignments are strictly managed separately (via FacultyCourseAssignments).
 * - Non-teaching employees may be assigned to these offices by Administration via OfficeAssignments.
 * - Granular permissions within each office are managed exclusively by that office's authorized admin.
 */
export const SIX_PERMANENT_OFFICES: readonly PermanentOfficeRecord[] = [
  {
    office_id: 'PO-001',
    office_key: PermanentOfficeKey.ADMINISTRATION,
    office_name: 'Administration Office',
    canonical_username: 'admin',
    office_code: 'ADM',
    description: 'Central administrative and governance authority. Holds Super Admin privileges, staff assignments, and institute policies.',
    is_super_admin: true,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'admin@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-002',
    office_key: PermanentOfficeKey.ADMISSIONS,
    office_name: 'Admissions Office',
    canonical_username: 'admissionsoffice',
    office_code: 'ADM-OFF',
    description: 'Manages candidate intake, applicant verification, program enrollment quotas, and onboarding of new cohorts.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'admissions@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-003',
    office_key: PermanentOfficeKey.ACADEMIC,
    office_name: 'Academic Office',
    canonical_username: 'academicoffice',
    office_code: 'ACA',
    description: 'Coordinates curriculum governance, academic calendar, teaching faculty course assignments, and departmental oversight.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'academic@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-004',
    office_key: PermanentOfficeKey.COE,
    office_name: 'COE Office',
    canonical_username: 'coeoffice',
    office_code: 'COE',
    description: 'Autonomous Controller of Examinations office. Oversees exam timetables, hall tickets, marks moderation, SGPA/CGPA, and transcripts.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'coe@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-005',
    office_key: PermanentOfficeKey.FINANCE,
    office_name: 'Finance Office',
    canonical_username: 'finance',
    office_code: 'FIN',
    description: 'Manages tuition fee billing, student dues, online/offline payment reconciliations, payroll, and financial receipts.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'finance@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-006',
    office_key: PermanentOfficeKey.HOSTEL,
    office_name: 'Hostel Office',
    canonical_username: 'hosteloffice',
    office_code: 'HOS',
    description: 'Supervises residential hall inventory, room allocations, bed availability, warden authorizations, and student living welfare.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'hostel@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
  {
    office_id: 'PO-007',
    office_key: PermanentOfficeKey.IT,
    office_name: 'IT Department',
    canonical_username: 'itoffice',
    office_code: 'IT',
    description: 'Institutional technology infrastructure, identity & access systems, student/staff ID cards, IT helpdesk, SLA management, and security governance.',
    is_super_admin: false,
    is_system_reserved: true,
    allow_self_registration: false,
    primary_contact_email: 'it-support@eit.edu',
    created_at: '2026-01-01T00:00:00Z',
    status: 'ACTIVE',
  },
] as const;

/**
 * Validates if a given username, key, or code belongs to any of the 6 protected permanent offices.
 */
export function isReservedOfficeIdentifier(identifier: string): boolean {
  const normalized = identifier.trim().toLowerCase();
  return SIX_PERMANENT_OFFICES.some(
    (office) =>
      office.canonical_username.toLowerCase() === normalized ||
      office.office_id.toLowerCase() === normalized ||
      office.office_key.toLowerCase() === normalized ||
      office.office_code.toLowerCase() === normalized ||
      office.office_name.toLowerCase() === normalized
  );
}

/**
 * Retrieves the permanent office record for a canonical username.
 */
export function getPermanentOfficeByUsername(username: string): PermanentOfficeRecord | undefined {
  const normalized = username.trim().toLowerCase();
  return SIX_PERMANENT_OFFICES.find(
    (office) => office.canonical_username.toLowerCase() === normalized
  );
}
