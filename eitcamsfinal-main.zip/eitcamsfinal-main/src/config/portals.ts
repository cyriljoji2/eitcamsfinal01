import { PortalGatewayConfig, PortalType } from '../types/portal';

export const INSTITUTE_INFO = {
  name: 'Electrix Institute of Technology (EIT)',
  shortCode: 'EIT',
  badge: 'ERP',
  gatewaySubtitle: 'College Academic & Administrative Management Gateway',
  welcomeHeading: 'Welcome to Electrix Institute of Technology (EIT)',
  welcomeSubtitle: 'Please select your gateway to continue into your academic space.',
} as const;

export const PORTAL_GATEWAYS: readonly PortalGatewayConfig[] = [
  {
    id: PortalType.Student,
    title: 'Student',
    description: 'Access grades, attendance, coursework, and learning materials.',
    buttonLabel: 'Student Login',
    loginHeading: 'Student Login',
    loginSubtitle: 'Enter your student credentials to access grades, attendance, coursework, and learning materials.',
    usernameLabel: 'Username',
    usernamePlaceholder: 'Enter your student username or ID',
  },
  {
    id: PortalType.Employee,
    title: 'Employee',
    description: 'Access your authorized office and academic functions.',
    buttonLabel: 'Employee Login',
    loginHeading: 'Employee Login',
    loginSubtitle: 'Enter your employee credentials to access authorized office and academic functions.',
    usernameLabel: 'Username',
    usernamePlaceholder: 'Enter your employee or office username',
  },
  {
    id: PortalType.Parent,
    title: 'Parent/Guardian',
    description: "Monitor your child's progress, attendance, and updates.",
    buttonLabel: 'Parent Login',
    loginHeading: 'Parent Login',
    loginSubtitle: "Sign in as a Parent or Guardian to monitor your child's progress, attendance, and updates.",
    usernameLabel: 'Username',
    usernamePlaceholder: 'Enter your parent or guardian username',
  },
] as const;

export function getPortalConfig(portalId: PortalType): PortalGatewayConfig {
  const found = PORTAL_GATEWAYS.find((gateway) => gateway.id === portalId);
  if (!found) {
    return PORTAL_GATEWAYS[0];
  }
  return found;
}
