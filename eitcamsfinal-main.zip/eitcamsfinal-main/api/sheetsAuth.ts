/**
 * Google Cloud Workload Identity Federation (WIF) & Vercel OIDC Authentication Service
 * Electrix Institute of Technology (EIT) Academic & Administrative Management Gateway
 *
 * NOTE: This module implements enterprise keyless authentication conforming to
 * organizational policy `iam.disableServiceAccountKeyCreation`. No service account
 * JSON keys, private keys, or static secrets are used or permitted.
 *
 * All operations are strictly server-side. Browser execution is authoritatively rejected.
 */

import { IdentityPoolClient } from 'google-auth-library';
import { getVercelOidcToken } from '@vercel/oidc';

/**
 * Authoritative Environment Variable Contract for Keyless Google Sheets Integration
 */
export const SHEETS_ENV_KEYS = {
  GOOGLE_SERVICE_ACCOUNT_EMAIL: 'GOOGLE_SERVICE_ACCOUNT_EMAIL',
  GOOGLE_SHEETS_SPREADSHEET_ID: 'GOOGLE_SHEETS_SPREADSHEET_ID',
  GCP_PROJECT_ID: 'GCP_PROJECT_ID',
  GCP_PROJECT_NUMBER: 'GCP_PROJECT_NUMBER',
  GCP_WORKLOAD_IDENTITY_POOL_ID: 'GCP_WORKLOAD_IDENTITY_POOL_ID',
  GCP_WORKLOAD_IDENTITY_PROVIDER_ID: 'GCP_WORKLOAD_IDENTITY_PROVIDER_ID',
} as const;

/**
 * Forbidden Private Key / JSON variables rejected per organizational policy
 */
export const PROHIBITED_PRIVATE_KEY_VARS = [
  'GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY',
  'GOOGLE_SERVICE_ACCOUNT_JSON',
  'GOOGLE_PRIVATE_KEY',
  'SERVICE_ACCOUNT_PRIVATE_KEY',
  'GCP_PRIVATE_KEY',
  'GCP_SERVICE_ACCOUNT_KEY',
] as const;

export interface SheetsWifConfig {
  serviceAccountEmail: string;
  spreadsheetId: string;
  projectId: string;
  projectNumber: string;
  poolId: string;
  providerId: string;
  providerResourceName: string;
  stsAudience: string;
  vercelAudience: string;
  impersonationUrl: string;
}

export interface ConfigurationValidationResult {
  isValid: boolean;
  isPending: boolean;
  missingVariables: string[];
  prohibitedVariablesFound: string[];
  config?: SheetsWifConfig;
  statusMessage: string;
}

/**
 * Assert that execution is taking place strictly in a server-side runtime.
 * Throws a security error if invoked within a browser context.
 */
export function assertServerEnvironment(): void {
  if (typeof window !== 'undefined') {
    throw new Error(
      'SECURITY VIOLATION: Google Sheets authentication and WIF operations are strictly server-side and MUST NOT be executed in the browser.'
    );
  }
}

/**
 * Validates the server environment configuration for Workload Identity Federation.
 * Explicitly rejects any legacy private-key variables and verifies the 6 required WIF keys.
 */
export function validateEnvironmentConfiguration(env: Record<string, string | undefined> = process.env): ConfigurationValidationResult {
  assertServerEnvironment();

  // Check for prohibited private keys / JSON blobs
  const prohibitedFound: string[] = [];
  for (const key of PROHIBITED_PRIVATE_KEY_VARS) {
    if (env[key] && env[key]!.trim().length > 0) {
      prohibitedFound.push(key);
    }
  }

  const email = env[SHEETS_ENV_KEYS.GOOGLE_SERVICE_ACCOUNT_EMAIL]?.trim();
  const spreadsheetId = env[SHEETS_ENV_KEYS.GOOGLE_SHEETS_SPREADSHEET_ID]?.trim();
  const projectId = env[SHEETS_ENV_KEYS.GCP_PROJECT_ID]?.trim();
  const projectNumber = env[SHEETS_ENV_KEYS.GCP_PROJECT_NUMBER]?.trim();
  const poolId = env[SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_POOL_ID]?.trim();
  const providerId = env[SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_PROVIDER_ID]?.trim();

  const missing: string[] = [];
  if (!email) missing.push(SHEETS_ENV_KEYS.GOOGLE_SERVICE_ACCOUNT_EMAIL);
  if (!spreadsheetId) missing.push(SHEETS_ENV_KEYS.GOOGLE_SHEETS_SPREADSHEET_ID);
  if (!projectId) missing.push(SHEETS_ENV_KEYS.GCP_PROJECT_ID);
  if (!projectNumber) missing.push(SHEETS_ENV_KEYS.GCP_PROJECT_NUMBER);
  if (!poolId) missing.push(SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_POOL_ID);
  if (!providerId) missing.push(SHEETS_ENV_KEYS.GCP_WORKLOAD_IDENTITY_PROVIDER_ID);

  if (prohibitedFound.length > 0) {
    return {
      isValid: false,
      isPending: false,
      missingVariables: missing,
      prohibitedVariablesFound: prohibitedFound,
      statusMessage: `REJECTED: Legacy private key variables (${prohibitedFound.join(', ')}) detected. ` +
        `Google Cloud organizational policy 'iam.disableServiceAccountKeyCreation' prohibits service account keys. ` +
        `Remove private keys and use Workload Identity Federation (WIF).`,
    };
  }

  if (missing.length > 0) {
    return {
      isValid: false,
      isPending: true,
      missingVariables: missing,
      prohibitedVariablesFound: [],
      statusMessage: `Pending configuration: Missing required keyless environment variables: ${missing.join(', ')}.`,
    };
  }

  // Canonical resource names for GCP STS and Vercel OIDC
  const providerResourceName = `projects/${projectNumber}/locations/global/workloadIdentityPools/${poolId}/providers/${providerId}`;
  const stsAudience = `//iam.googleapis.com/${providerResourceName}`;
  const vercelAudience = `https://iam.googleapis.com/${providerResourceName}`;
  const impersonationUrl = `https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts/${email}:generateAccessToken`;

  return {
    isValid: true,
    isPending: false,
    missingVariables: [],
    prohibitedVariablesFound: [],
    config: {
      serviceAccountEmail: email!,
      spreadsheetId: spreadsheetId!,
      projectId: projectId!,
      projectNumber: projectNumber!,
      poolId: poolId!,
      providerId: providerId!,
      providerResourceName,
      stsAudience,
      vercelAudience,
      impersonationUrl,
    },
    statusMessage: 'Workload Identity Federation environment configuration is complete and valid.',
  };
}

/**
 * Sanitizes error messages to ensure that no tokens, credentials, or private headers are leaked.
 */
export function sanitizeAuthError(error: unknown): string {
  if (!error) return 'Unknown authentication error';
  const msg = error instanceof Error ? error.message : String(error);
  return msg
    .replace(/bearer\s+ya29\.[A-Za-z0-9-_=]+/gi, 'Bearer [REDACTED_ACCESS_TOKEN]')
    .replace(/bearer\s+ey[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+/gi, 'Bearer [REDACTED_JWT]')
    .replace(/ey[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+/g, '[REDACTED_JWT]')
    .replace(/ya29\.[A-Za-z0-9-_=]+/g, '[REDACTED_ACCESS_TOKEN]')
    .replace(/-----BEGIN[\s\S]+?END[^\-]+-----/g, '[REDACTED_PRIVATE_KEY]')
    .replace(/bearer\s+[A-Za-z0-9-_=.]+/gi, 'Bearer [REDACTED_TOKEN]');
}

/**
 * Creates a Google IdentityPoolClient configured for Vercel OIDC and Workload Identity Federation.
 *
 * Uses:
 * 1. `@vercel/oidc` `getVercelOidcToken` with audience matching Google Cloud OIDC provider.
 * 2. `google-auth-library` `IdentityPoolClient` with external account configuration.
 * 3. Short-lived Service Account Impersonation for `https://www.googleapis.com/auth/spreadsheets`.
 */
export function createGoogleWorkloadIdentityClient(config: SheetsWifConfig): IdentityPoolClient {
  assertServerEnvironment();

  return new IdentityPoolClient({
    type: 'external_account',
    audience: config.stsAudience,
    subject_token_type: 'urn:ietf:params:oauth:token-type:jwt',
    token_url: 'https://sts.googleapis.com/v1/token',
    service_account_impersonation_url: config.impersonationUrl,
    service_account_impersonation: {
      token_lifetime_seconds: 3600,
    },
    subject_token_supplier: {
      getSubjectToken: async () => {
        try {
          // Request OIDC token specifically minted for Google Cloud Workload Identity Provider audience
          const oidcToken = await getVercelOidcToken({ audience: config.vercelAudience });
          if (!oidcToken) {
            throw new Error('Vercel OIDC token could not be obtained from execution context.');
          }
          return oidcToken;
        } catch (err: any) {
          throw new Error(`Failed to acquire Vercel OIDC token: ${sanitizeAuthError(err)}`);
        }
      },
    },
  });
}
