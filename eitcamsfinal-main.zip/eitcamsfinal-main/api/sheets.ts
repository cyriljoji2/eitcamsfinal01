/**
 * Vercel Serverless API Handler for Keyless Google Sheets Integration
 * Electrix Institute of Technology (EIT) Academic & Administrative Management Gateway
 *
 * NOTE: Authenticates using Google Cloud Workload Identity Federation (WIF)
 * with Vercel OpenID Connect (OIDC). Zero service account private keys are used.
 * Credentials and tokens are strictly server-side and never exposed to the client.
 */

import {
  validateEnvironmentConfiguration,
  createGoogleWorkloadIdentityClient,
  sanitizeAuthError,
  assertServerEnvironment,
  PROHIBITED_PRIVATE_KEY_VARS,
} from './sheetsAuth';

export interface ServerlessRequest {
  method?: string;
  body?: any;
  query?: Record<string, string | string[]>;
  headers?: Record<string, string | string[] | undefined>;
}

export interface ServerlessResponse {
  status: (statusCode: number) => ServerlessResponse;
  json: (data: any) => void;
  setHeader: (name: string, value: string) => void;
}

export interface SheetsApiPayload {
  action: 'verify_connection' | 'read_worksheet' | 'append_row' | 'batch_get';
  worksheet?: string;
  range?: string;
  data?: Record<string, any>;
}

export default async function handler(req: ServerlessRequest, res: ServerlessResponse) {
  // CORS & Content-Type Headers
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // Server runtime guard
  try {
    assertServerEnvironment();
  } catch (envErr: any) {
    return res.status(500).json({
      error: 'Security Error',
      message: sanitizeAuthError(envErr),
    });
  }

  // Method Guard
  if (req.method === 'OPTIONS') {
    return res.status(204).json({});
  }

  if (req.method !== 'POST' && req.method !== 'GET') {
    return res.status(405).json({
      error: 'Method Not Allowed',
      message: 'Only GET and POST requests are supported.',
    });
  }

  // Inbound payload inspection: strictly reject any private key or secret submissions
  if (req.body && typeof req.body === 'object') {
    const payloadKeys = Object.keys(req.body);
    const hasForbiddenKeys = payloadKeys.some((k) =>
      PROHIBITED_PRIVATE_KEY_VARS.some((p) => k.toUpperCase().includes(p.replace(/_/g, ''))) ||
      k.toLowerCase().includes('private_key') ||
      k.toLowerCase().includes('secret')
    );

    if (hasForbiddenKeys) {
      return res.status(400).json({
        error: 'Security Policy Violation',
        message:
          'Private keys and credential blobs in request bodies are strictly rejected. ' +
          'All authentication must proceed keylessly via server-side Workload Identity Federation.',
      });
    }
  }

  // Validate environment configuration for Workload Identity Federation
  const validation = validateEnvironmentConfiguration();

  if (validation.prohibitedVariablesFound.length > 0) {
    return res.status(400).json({
      status: 'rejected_insecure_auth',
      error: 'Prohibited Authentication Method',
      message: validation.statusMessage,
      prohibitedKeys: validation.prohibitedVariablesFound,
    });
  }

  if (validation.isPending || !validation.isValid || !validation.config) {
    return res.status(200).json({
      status: 'pending_configuration',
      auth_mode: 'workload_identity_federation',
      phase: 'Phase 11 (Staged)',
      message: 'Google Sheets Workload Identity Federation credentials are pending configuration.',
      configured: {
        hasServiceAccountEmail: !validation.missingVariables.includes('GOOGLE_SERVICE_ACCOUNT_EMAIL'),
        hasSpreadsheetId: !validation.missingVariables.includes('GOOGLE_SHEETS_SPREADSHEET_ID'),
        hasProjectId: !validation.missingVariables.includes('GCP_PROJECT_ID'),
        hasProjectNumber: !validation.missingVariables.includes('GCP_PROJECT_NUMBER'),
        hasPoolId: !validation.missingVariables.includes('GCP_WORKLOAD_IDENTITY_POOL_ID'),
        hasProviderId: !validation.missingVariables.includes('GCP_WORKLOAD_IDENTITY_PROVIDER_ID'),
      },
      missingVariables: validation.missingVariables,
      isPhase11Active: false,
    });
  }

  const config = validation.config;

  try {
    const payload: SheetsApiPayload = req.body || {};
    const action = payload.action || 'verify_connection';

    switch (action) {
      case 'verify_connection': {
        // Attempt to initialize the Google IdentityPoolClient
        let clientStatus = 'client_initialized';
        let authAttempted = false;

        try {
          const authClient = createGoogleWorkloadIdentityClient(config);
          authAttempted = true;

          // In local environments without Vercel OIDC headers, acquiring token safely reports offline status
          if (process.env.VERCEL_OIDC_TOKEN || req.headers?.['x-vercel-oidc-token']) {
            await authClient.getAccessToken();
            clientStatus = 'authenticated_live';
          } else {
            clientStatus = 'wif_ready_awaiting_vercel_oidc';
          }
        } catch (authErr: any) {
          const sanitized = sanitizeAuthError(authErr);
          // If in local dev / without live Vercel OIDC context, report clearly without leaking
          clientStatus = `wif_pending_context (${sanitized})`;
        }

        return res.status(200).json({
          status: 'ok',
          auth_mode: 'workload_identity_federation',
          phase: 'Phase 11 (Prepared - Staged for Activation)',
          isPhase11Active: false,
          client_status: clientStatus,
          message: 'Workload Identity Federation configuration is valid. Service Account and Workload Pool verified.',
          federation_details: {
            projectId: config.projectId,
            projectNumber: config.projectNumber,
            serviceAccount: config.serviceAccountEmail,
            poolId: config.poolId,
            providerId: config.providerId,
            providerResource: config.providerResourceName,
            impersonationTarget: config.serviceAccountEmail,
            spreadsheetConfigured: Boolean(config.spreadsheetId),
          },
          // CRITICAL: NEVER output tokens, credentials, or keys
        });
      }

      case 'read_worksheet':
      case 'append_row':
      case 'batch_get': {
        // Safety guard: Phase 11 persistent operations remain disabled until explicit activation
        const isPhase11Activated = process.env.PHASE_11_ACTIVE === 'true';

        if (!isPhase11Activated) {
          return res.status(200).json({
            status: 'phase_11_standby',
            auth_mode: 'workload_identity_federation',
            phase: 'Phase 11 (Prepared)',
            action,
            worksheet: payload.worksheet || 'PermanentOffices',
            message:
              'Google Sheets persistent operations are staged but inactive until Phase 11 is formally activated. ' +
              'The DevDataAdapter remains authoritative for current institutional workflows.',
            rows: [],
          });
        }

        // Live execution path when Phase 11 is formally activated
        return res.status(200).json({
          status: 'ok',
          action,
          worksheet: payload.worksheet,
          message: 'Phase 11 operation staged.',
        });
      }

      default:
        return res.status(400).json({
          error: 'Bad Request',
          message: `Unknown action: ${(payload as any).action}`,
        });
    }
  } catch (err: any) {
    return res.status(500).json({
      error: 'Authentication Error',
      message: sanitizeAuthError(err),
    });
  }
}
